# ADR-001 — Optional provenance fields as JSON null

| Field | Value |
| ----- | ----- |
| Status | Accepted (pending physical retest confirmation) |
| Date | 2026-07-24 |
| Incident | P1R-001 |
| Deciders | Capture runtime maintainers |

## Context

`CaptureDeviceProvenance.asDictionary()` must feed `CanonicalJSON` for `capture_device.json`. Phase 1 `DeviceProvenanceService` leaves several fields nil (`lidar_available`, attestation, calibration identifiers) until asserted. Boxing `Optional.none as Any` is not a JSON value and caused `CANONICALIZATION_FAILED` on physical device (P1R-001).

## Decision

Encode absent **optional** provenance fields as JSON `null` via `NSNull()` in `asDictionary()` (and equivalent sites). Do **not** silently drop required identity fields. Do **not** dump arbitrary AVCapture metadata dictionaries into the package unless a contract field explicitly requires them.

## Alternatives considered

1. **Omit nil keys** — also JSON-valid; rejected for Phase 1 because existing dictionary shape and consumers expect stable key sets with explicit nulls for unknowns.
2. **Force placeholder strings** (`"UNKNOWN"`) — rejected; invents evidence semantics.
3. **Teach CanonicalJSON to coerce all Optionals** — rejected as a silent footgun; producers should emit JSON-safe values; encoder may diagnose Optionals but must not hide producer bugs without tests.
4. **Ordinary JSONEncoder** — rejected; breaks canonical determinism contract.

## Determinism

Sorted-key compact UTF-8 canonicalization unchanged. Null is a stable scalar. Required string fields remain strings. Optional→null is explicit and tested.

## Implications

* Future optional fields added to provenance must use `?? NSNull()` (or contract-documented omission) — never `as Any` on Optional.
* Non-contract camera metadata stays out of canonical payloads unless a schema field is added with tests.
* Physical retest still required before closing P1R-001.
