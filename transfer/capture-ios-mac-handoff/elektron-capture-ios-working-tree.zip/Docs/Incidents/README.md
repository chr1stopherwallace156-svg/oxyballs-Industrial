# Runtime Incidents

Permanent engineering records for **elektron-capture-ios** runtime failures that reached (or nearly reached) physical-device validation.

These documents are **append-only history**. Do **not** overwrite closed incident files to rewrite the past. Open a new `PHASE_1_RUNTIME_INCIDENT_NNN.md` (or amend only the *Status / Acceptance Evidence* sections of an open incident with dated addenda).

| ID | Title | Status | Document |
|----|-------|--------|----------|
| P1R-001 | Physical Device Canonicalization Failure | `PENDING_PHYSICAL_DEVICE_RETEST` | [PHASE_1_RUNTIME_INCIDENT_001.md](./PHASE_1_RUNTIME_INCIDENT_001.md) |

Related ADR: [ADR-001 — Optional provenance fields as JSON null](./ADR-001-optional-provenance-json-null.md)
