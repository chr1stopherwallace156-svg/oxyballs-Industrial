# PHASE_1_RUNTIME_INCIDENT_001.md

## Incident Metadata

```text
Incident ID:
P1R-001

Title:
Physical Device Canonicalization Failure

Repository:
elektron-capture-ios

Branch:
cursor/canonicalization-failed-repair-d881
(based on feature/phase1-single-still-runtime @ c3581d04)

HEAD before repair:
c3581d04c0eacb0790e80b52a794eb5a3251b2cc

HEAD after repair:
1b132f4183d66d791ef94773201e3387cd2da747

Date discovered:
2026-07-24 (physical-device validation session; cloud investigation same day)

Reporter:
Physical-device operator (iPhone validation) + cloud agent investigation

Device:
iPhone (exact model identifier not captured in cloud logs — record on retest)

iOS Version:
Not recorded in this environment — record on retest
(physical path uses UIDevice.current.systemVersion / DeviceProvenanceService)

Xcode Version:
Not recorded in this environment — record on retest

Investigation status:
CANONICALIZATION_DEFECT_UNDER_INVESTIGATION → code repair landed;
acceptance = PENDING_PHYSICAL_DEVICE_RETEST

Phase 0 / Phase 1 baseline tags (unchanged):
capture-ios-phase0-approved-v0.1.3 @ d867137877817de0369d749a64201cad01886227
capture-ios-phase1-directive-v0.1.4 @ 61502eb3ccc0336c52e6dfbbb58f38a66eeaad7c
```

---

## Executive Summary

During first physical iPhone validation of Phase1StillCapture, the app launched, obtained camera permission, and started Capture & Export, then displayed **`FAIL CANONICALIZATION_FAILED`** with empty Package ID, Evidence ID, Artifact SHA-256, and package path.

Investigation traced the displayed string to `Phase1RuntimeError.canonicalizationFailed` → reason code `CANONICALIZATION_FAILED`, thrown from `CanonicalJSONEncoder.encode` when encoding **`capture_device.json`**. Pre-repair `CaptureDeviceProvenance.asDictionary()` boxed nil Swift `Optional`s as `Any` (`Optional.none`). `CanonicalJSON` rejects that type.

**Severity:** High for Phase 1 physical gate (blocks first verified capture artifact on device).  
**Impact:** No `.edts-pkg` export on device; no evidence package for EDTS ingest.  
**Current status:** Code repair + regression tests on `1b132f4`; **not** closed until physical retest produces non-empty IDs/hash/path. Simulator/`swift test` green alone is insufficient.

---

## Timeline

```text
Simulator / Linux fixture validation (package path with overrides)
↓
Physical device deployed (Phase1StillCapture signed + installed)
↓
Camera permission granted
↓
Capture button pressed → UI Working
↓
FAIL CANONICALIZATION_FAILED (package fields empty)
↓
Investigation (status registry + encoder + provenance asDictionary)
↓
Root cause isolated: nil Optional boxed as Any in capture_device.json
↓
Repair: NSNull() for absent optional provenance fields + diagnostics + UI defer
↓
Regression tests (pre-fix pattern FAIL / post-fix PASS)
↓
Physical retest  ← PENDING (acceptance gate)
```

---

## Symptoms

```text
App launched successfully.
Camera permission requested and granted.
Capture & Export initiated.
Working indicator shown.
FAIL CANONICALIZATION_FAILED displayed.
Package ID empty.
Evidence ID empty.
Artifact SHA-256 empty.
Package path empty.
Button appeared stuck on Working (pre-repair UI hid detail; Working reset not audibly confirmed on device).
Xcode console dominated by Fig / FigCaptureSourceRemote / FBSSceneSnapshot noise.
Literal search for CANONICALIZATION_FAILED did not land on a single call site (value is enum reasonCode).
```

---

## Environment

```text
iPhone model:        (record on retest — hw.machine via DeviceProvenanceService)
iOS version:         (record on retest)
Xcode version:       (record on retest)
Swift version:       5.9+ (Package.swift); cloud verification used Swift 5.10.1 Linux
Branch:              cursor/canonicalization-failed-repair-d881
Commit before repair: c3581d04c0eacb0790e80b52a794eb5a3251b2cc
Commit after repair:  1b132f4183d66d791ef94773201e3387cd2da747
Cloud agent:         Linux (no Xcode / no physical camera)
```

---

## Console Logs

### Non-root-cause framework diagnostics

```text
Fig / FigCaptureSourceRemote …
FBSSceneSnapshot …
```

These are system camera/scene messages. They did **not** encode the application failure reason.

### Actual application diagnostics (after instrumentation)

Encoder / UI path logs (stderr / console), pattern:

```text
[Phase1Capture] stage=capture_device.json event=canonicalization_failed
  stage=capture_device.json
  | swiftErrorType=CaptureError
  | describing=packageInvalid("Unsupported JSON type Optional<…> …")
  | unsupportedValues=<keyPath> type=Optional<…> describing=nil
```

UI after repair shows:

```text
FAIL CANONICALIZATION_FAILED
Error detail: stage=… | describing=… | unsupportedValues=…
```

Photo-path instrumentation (byteCount / metadataKeyCount only; **no** full JPEG or sensitive EXIF dump) added for device retest distinguishability — see Code Changes.

---

## Stage Analysis

Evidence mix: **OBS** = physical observation; **INF** = inferred from distinct reason codes / builder order; **EXE** = reproduced in tests/harness.

| Stage | Result | Basis |
| ----- | ------ | ----- |
| Launch | PASS | OBS |
| Camera Authorization | PASS | OBS |
| AVCapture Session | PASS | OBS (capture starts) |
| Photo Delegate | PASS | INF — failure was not `PHOTO_CAPTURE_FAILED` |
| JPEG Extraction (`fileDataRepresentation`) | PASS | INF — not `FILE_REPRESENTATION_UNAVAILABLE`; builder reaches provenance encode |
| Persist / hash artifact | PASS | INF — encode order places artifact persist before device JSON |
| Manifest canonical encode | PASS | INF — enrollment is non-nil String; next stage is device JSON |
| **Canonical JSON (`capture_device.json`)** | **FAIL** | EXE — first failing encode; Optional nil key paths |
| Remaining package JSON / ZIP | NOT REACHED | EXE — builder catch cleans partial package |
| Export / Share | NOT REACHED | OBS — empty path |
| UI field population | FAIL | OBS |
| UI Working reset | Ambiguous OBS; fixed in code via `defer` | code review |

**Failure class:** canonicalization failure (not capture, metadata adaptation, manifest schema validation, or filesystem export).

---

## Root Cause

```text
Exact file:
  App/Domain/Models/CaptureDeviceProvenance.swift

Exact function:
  CaptureDeviceProvenance.asDictionary()

Exact pre-repair pattern:
  d["lidar_available"] = lidarAvailable as Any   // and siblings
  when lidarAvailable == nil → value type Optional<Bool>.none boxed in Any

Exact key paths proven (physical DeviceProvenanceService nils):
  app_attest_key_id     → Optional<String> (nil)
  calibration_profile_id → Optional<String> (nil)
  lidar_available       → Optional<Bool> (nil)
  (dictionary walk order may surface any of these first)

Exact throw site:
  CanonicalJSON.normalize(_:) default → CaptureError.packageInvalid("Unsupported JSON type …")
  wrapped by CanonicalJSONEncoder.encode → Phase1RuntimeError.canonicalizationFailed(…)

Exact displayed status:
  Phase1RuntimeError.reasonCode == "CANONICALIZATION_FAILED"
  (Apps/Phase1StillCapture/Phase1CaptureRootView.swift: "FAIL \(e.reasonCode)")

Producer of nils:
  App/Phase1/DeviceProvenanceService.currentProvenance(…)
  sets lidarAvailable: nil (and leaves attest/calibration nil by default)
```

**Contract note:** These provenance fields are **optional** in the capture-device contract sense (may be absent/unknown at Phase 1). Encoding them as JSON `null` preserves key presence and determinism. This is **not** a license to serialize arbitrary undocumented AVCapture metadata dictionaries into the package.

---

## Why Simulator / Fixture Tests Didn't Catch It

```text
Simulator / Linux fixture path:
  Phase1RuntimeTests often used CaptureDeviceProvenance(...) with enrollment set,
  OR full coordinator with hardwareModelOverride / iosVersionOverride.
  Golden manifest tests encode EvidenceManifestBuilder output only — not
  provenance.asDictionary() with the full nil-optional matrix from DeviceProvenanceService.

Physical device path:
  Always uses DeviceProvenanceService.currentProvenance() which intentionally
  leaves lidarAvailable (and related optionals) nil until asserted.

Difference:
  Physical path systematically produces Optional.none entries in asDictionary().
  Fixture/golden paths often omitted those keys' nil matrix or never encoded
  capture_device.json through the failing asDictionary implementation in isolation.

Why coverage missed it:
  No regression that built DeviceProvenanceService().currentProvenance()-shaped
  dictionaries (nil lidar/attest/calibration) and required CanonicalJSONEncoder
  success before physical deployment.
  UI mapped errors to reasonCode only, hiding Unsupported JSON type Optional<…>.
```

Fields **simulated in regression (not observed from a captured on-device package dump):** exact iPhone `hw.machine` string, exact iOS marketing version, live AVCapture metadata key set, real JPEG byte count from the failing session.  
Fields **evidence-backed:** nil optional matrix from `DeviceProvenanceService` source; encoder rejection of `Optional.none as Any`; builder encode order; reason-code mapping.

---

## Code Changes

| File | Reason | Change | Risk |
| ---- | ------ | ------ | ---- |
| `App/Domain/Models/CaptureDeviceProvenance.swift` | Root cause | `?? NSNull()` for optional fields in `asDictionary()` | Low — JSON null for unknowns |
| `App/Phase1/EvidenceManifestBuilder.swift` | Same Optional boxing | `device_enrollment_id: … ?? NSNull()` | Low |
| `App/Phase1/CaptureClockService.swift` | Harden leaf types | `monotonic_ns` as Int64/NSNumber | Low |
| `App/Application/CanonicalJSON.swift` | Diagnostics + leaf types + Bool/NSNumber order + solidus normalize | Clearer Optional errors; UInt64; Darwin-safe Bool | Medium — review Bool/NSNumber carefully |
| `App/Phase1/CanonicalJSONEncoder.swift` | Preserve root cause | Stage name + describing/reflecting + unsupported key paths | Low |
| `App/Phase1/EvidencePackageBuilder.swift` | Stage isolation | Per-file `stage:` on encode | Low |
| `App/Phase1/Phase1RuntimeError.swift` | UI/diagnostics | `detailMessage` | Low |
| `Apps/Phase1StillCapture/Phase1CaptureRootView.swift` | UI safety | `defer { busy = false }`, show detail | Low |
| `App/Export/FileEvidenceExporter.swift` | Same Optional pattern | `?? NSNull()` | Low |
| `App/Provenance/ContentHasher.swift` / `ArtifactHashingService.swift` | Linux CI only | CryptoKit fallback for `swift test` on Linux | Low on Apple (CryptoKit unchanged) |
| `Tests/Unit/Phase1RuntimeTests.swift` | Prevention | Physical nil-optional + buggy Optional regression | Low |
| `App/Capture/AVFoundation/Phase1CameraServices.swift` | Retest diagnostics | Log byteCount / metadataKeyCount only | Low |
| `App/Phase1/Phase1CaptureCoordinator.swift` | Retest diagnostics | Log received JPEG byteCount | Low |

ADR: [ADR-001-optional-provenance-json-null.md](./ADR-001-optional-provenance-json-null.md)

---

## Diff Summary

```text
Added:
  Docs/Incidents/* (this record, README, ADR-001)
  Phase1 physical-nil regression tests
  CanonicalJSON.unsupportedValues diagnostics
  Stage-labeled encode + UI error detail

Modified:
  CaptureDeviceProvenance.asDictionary (NSNull)
  CanonicalJSON / CanonicalJSONEncoder
  EvidencePackageBuilder, EvidenceManifestBuilder, CaptureClockService
  Phase1CaptureRootView, Phase1RuntimeError
  FileEvidenceExporter
  Photo capture diagnostics (byte/key counts)
  CHANGELOG [Unreleased] Fixed section
  ContentHasher Linux fallback (CI)

Removed:
  (none intentional — no deletion of evidence fields; nils become JSON null)
```

---

## Tests

### Before (pre-repair `asDictionary` pattern / parent semantics)

```text
FAILED — CanonicalJSON / CanonicalJSONEncoder on DeviceProvenanceService-shaped
         dictionary with nil lidar_available / app_attest_key_id /
         calibration_profile_id
         → Unsupported JSON type Optional<…>
         → Phase1RuntimeError.canonicalizationFailed → CANONICALIZATION_FAILED
```

### After (`1b132f4` + tip tests)

```text
PASS — testPhysicalDeviceProvenanceDictionaryCanonicalizes
PASS — testCanonicalJSONRejectsBoxedNilOptional (still rejects buggy Optional boxing)
PASS — testEndToEndPackageWithPhysicalDeviceNilOptionals
PASS — testPhysicalDeviceStatusPayloadWithClockCanonicalizes
PASS — testCanonicalManifestMatchesPythonGoldenBytes
PASS — package / inventory / capture-side validator suite
```

| Class | Name / notes |
| ----- | ------------ |
| Regression | Physical DeviceProvenanceService nil matrix + intentional buggy Optional re-injection |
| Golden | Canonical manifest Python golden bytes |
| Runtime | Phase1CaptureCoordinator fixture JPEG e2e |
| Package | Inventory self-hash policy, calibration NOT_AVAILABLE |

`swift test` (Linux cloud): 47 tests, 0 failures (1 skipped: cross-language corpus on Linux Foundation bool collapse).  
`xcodebuild`: not run in cloud — **Mac required**.

---

## Evidence

### Physical successful export (acceptance)

```text
Package ID:     (PENDING_PHYSICAL_DEVICE_RETEST)
Evidence ID:    (PENDING_PHYSICAL_DEVICE_RETEST)
SHA-256:        (PENDING_PHYSICAL_DEVICE_RETEST)
Package path:   (PENDING_PHYSICAL_DEVICE_RETEST)
```

Do **not** treat Linux fixture package IDs as physical acceptance evidence.

### Code / harness evidence (investigation)

```text
Pre-fix unsupported keyPaths: app_attest_key_id, calibration_profile_id, lidar_available
Post-fix: unsupported_count=0; capture_device.json encodes with JSON nulls
Repair commit: 1b132f4183d66d791ef94773201e3387cd2da747
```

---

## Lessons Learned

```text
Never map pipeline errors to generic reason codes without preserving the underlying Swift error.
Always reset UI busy/Working via defer (or equivalent).
Physical-device payloads (DeviceProvenanceService nil matrix) need dedicated regression fixtures.
Optional.none boxed as Any is not JSON — prefer NSNull() or omit per contract.
Simulator/fixture success ≠ physical acceptance for Phase 1.
Literal string search can miss enum-backed status codes.
```

---

## Preventive Actions

* Every `Phase1RuntimeError` associated value / UI path must preserve underlying error text.
* Every canonical encode site must pass a **stage** name into diagnostics.
* Every physical-only producer path must have a regression fixture labeled `OBS` vs `SIMULATED_NOT_OBSERVED`.
* No bare `CANONICALIZATION_FAILED` in UI without detail/stage/unsupported key path when available.
* Physical-device validation required before Phase 1 implementation complete.
* Incident records live under `Docs/Incidents/` and are not overwritten; open incidents get dated addenda.

---

## ADR

See [ADR-001-optional-provenance-json-null.md](./ADR-001-optional-provenance-json-null.md).

---

## Acceptance Evidence

Checklist for physical retest (fill on device; do not check off from cloud):

* [ ] App launched
* [ ] Camera authorized
* [ ] Photo captured (`fileDataRepresentation` byteCount > 0 in logs)
* [ ] Package created (non-empty Package ID / Evidence ID)
* [ ] SHA generated (non-empty Artifact SHA-256)
* [ ] Package exported (non-empty path / Share available)
* [ ] Physical-device retest passed

**Until then:** `PENDING_PHYSICAL_DEVICE_RETEST`.

### Addendum log

| Date (UTC) | Note |
| ---------- | ---- |
| 2026-07-24 | Incident opened; repair `1b132f4`; awaiting physical retest evidence |
