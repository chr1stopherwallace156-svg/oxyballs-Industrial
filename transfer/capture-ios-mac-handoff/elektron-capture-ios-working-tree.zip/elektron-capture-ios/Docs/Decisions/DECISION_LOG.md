# Decision Log — elektron-capture-ios

Append-only engineering decisions. Do not rewrite prior entries; supersede with a new ID.

---

## P1-001 — Canonical non-ASCII serialization

| Field | Value |
|---|---|
| Decision ID | **P1-001** |
| Pass | 1 |
| Question | Should canonical JSON emit raw UTF-8 non-ASCII or ASCII `\uXXXX` escapes? |
| Alternatives | **A:** Raw UTF-8 (`"électron"`) — regenerate Python golden + EDTS to `ensure_ascii=False`. **B:** Mandatory `\uXXXX` escaping — match existing Python `ensure_ascii=True` golden. |
| Chosen | **B** |
| Reason | Observed failure was escaping-policy mismatch, not NFC/NFD. Shared golden already uses `ensure_ascii=True`. Byte-identity gate must remain byte-for-byte, not object-equivalence. |
| Affected files | `App/Application/CanonicalJSON.swift`, `Docs/Validation/CANONICAL_NON_ASCII_POLICY.md`, `Docs/Validation/CANONICAL_JSON.md`, `Tests/Unit/Pass1CanonicalInventoryTests.swift`, corpus under `Tests/Unit/Fixtures/canonical_corpus/` |
| Future impact | Swift, Python, and goldens must stay on one escaping policy. Changing policy requires regenerating goldens + dual-side review. |
| Contract version | Canonical JSON binding 1.0.0 (escaping rule clarified 2026-07-24) |
| Commit | `4a954b7`, docs `f739c36` |

---

## P1-002 — Package inventory completeness and self-hash

| Field | Value |
|---|---|
| Decision ID | **P1-002** |
| Pass | 1 |
| Question | How should inventory treat self-reference and Darwin `byte_size` typing? |
| Alternatives | **A:** Include self with two-pass empty sha. **B:** Omit `package_inventory.json` from `entries` (existing Phase 1 default). **C:** Weaken tests / exclude paths to green. |
| Chosen | **B** + accept `Int`/`NSNumber` for `byte_size` + flag undeclared on-disk paths |
| Reason | Root cause class D (NSNumber bridging) and class E (completeness gap). Self-hash omit already in `EDTS_PKG_FORMAT.md`. Must not delete/weaken inventory completeness assertions. |
| Affected files | `App/Phase1/CaptureSidePackageValidator.swift`, `App/Phase1/PackageInventoryBuilder.swift` (unchanged policy), `Docs/Evidence/PACKAGE_INVENTORY_PASS1_CLASSIFICATION.md`, `Tests/Unit/Pass1CanonicalInventoryTests.swift` |
| Future impact | Every package file except inventory itself must be declared. Changing self-hash policy needs versioned contract change. |
| Contract version | PackageInventory 1.0.0 / Phase 1 self-hash omit |
| Commit | `4a954b7`, docs `f739c36` |

---

## P1-003 — Pass 1 public-contract freeze

| Field | Value |
|---|---|
| Decision ID | **P1-003** |
| Pass | 1 |
| Question | May Pass 1 alter public evidence contracts to make tests pass? |
| Alternatives | **A:** Allow silent schema/layout/status/canonical changes. **B:** Freeze public contracts unless separately documented, justified, versioned, and operator-approved. |
| Chosen | **B** |
| Reason | Fixes that change the contract are not “bugfixes”; they are protocol changes. |
| Affected files | manifest schema, inventory schema, status registry, canonical JSON, package layout |
| Future impact | Pass 2/3 must not mutate these without a new Decision ID + approval. |
| Contract version | As of baseline `31513ac` + P1-001/P1-002 clarifications only |
| Commit | this Decision Log entry |

---

## P1-004 — Approval evidence standard

| Field | Value |
|---|---|
| Decision ID | **P1-004** |
| Pass | all |
| Question | Is a summary line (`swift test: N passed`) sufficient for operator approval? |
| Alternatives | **A:** Trust agent summaries. **B:** Require reproducible evidence package with every approval request. |
| Chosen | **B** |
| Reason | Prior discrepancy between claimed and local results. |
| Required evidence | See `Docs/Capture/PASS_APPROVAL_EVIDENCE_STANDARD.md` |
| Future impact | No pass may be marked operator-approved without the evidence package. |
| Commit | this Decision Log entry |
