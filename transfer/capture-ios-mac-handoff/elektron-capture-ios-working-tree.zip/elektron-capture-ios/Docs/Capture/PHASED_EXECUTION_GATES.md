# Phase 1 professional capture — phased execution gates

## HARD STOP AFTER PASS 1

After Pass 1 is committed and all baseline tests pass, **STOP**.

Do **not** begin Pass 2 until the operator explicitly approves:

1. the Pass 1 diff (`git diff --stat` + file list),
2. the **full** `swift test` terminal output (not a one-line summary),
3. the Pass 1 commit SHA **and parent SHA**,
4. the canonical non-ASCII policy doc,
5. the inventory root-cause classification doc,
6. Decision Log entries P1-001…P1-004,
7. the evidence package required by `PASS_APPROVAL_EVIDENCE_STANDARD.md`.

Reading this whole roadmap is **not** authorization to continue through Pass 2/3.

---

## Integrity guardrail (all passes)

> Passing tests is not sufficient if achieved by weakening byte-identity, inventory completeness, status ownership, or artifact-integrity assertions.

## Public contract freeze

> Public evidence contracts may not change during Pass 1 unless the change is separately documented, justified, versioned, and approved.

## No deleted / weakened tests

> Existing tests may not be deleted or weakened without an accompanying engineering justification and explicit operator approval.

---

## Pass status

| Pass | Intent | Status |
|---|---|---|
| 0 | Baseline verification | **DONE** @ parent `31513ac` |
| 1 | Restore automated test truth (canonical + inventory) | **DONE** — evidence package required for operator approval; **HARD STOP** |
| 2 | Preview, state machine, review gate, post-delegate hash freeze | **NOT STARTED** — await approval |
| 3A | Camera controls + torch lifecycle | **NOT STARTED** |
| 3B | Normalized metadata sidecar + quality warning/override | **NOT STARTED** |

See also: `Docs/Decisions/DECISION_LOG.md`, `Docs/Capture/PASS_APPROVAL_EVIDENCE_STANDARD.md`.

---

## Pass 2 requirements (when approved — do not start yet)

State map (minimum):

```text
permissionRequired? → starting → previewing → capturing → reviewing
  → approved → exporting → exported
(+ interrupted, failed(reasonCode))
```

Hash timing:

```text
photo delegate returns
  → freeze original bytes in pending review object
  → compute SHA-256 immediately (before review rendering)
Use Photo
  → promote pending → approved (no recalculate / no replace)
Export Package
  → assemble package only in exporting → exported
Export write failure
  → fall back to approved; keep frozen bytes
```

---

## Pass 3 requirements (when approved)

- Flash vs torch; torch OFF on review / background / lens switch / failed
- Lens discovery = physical devices only
- Metadata: supported JSON leaf types only; omit unsupported with **diagnostic accounting of omitted keys**
- Quality: `WARNING_EFFECTIVELY_BLACK` + Retake / Use Anyway + `operator_override` record
- Cursor may split 3A/3B if the diff is large

---

## Policy references (Pass 1)

- `Docs/Validation/CANONICAL_NON_ASCII_POLICY.md`
- `Docs/Evidence/PACKAGE_INVENTORY_PASS1_CLASSIFICATION.md`
