import Foundation

/// Canonical JSON for signed/bound structured metadata.
/// See Docs/Validation/CANONICAL_JSON.md — do **not** rely on Dictionary iteration order.
public enum CanonicalJSON {
  /// Deterministic JSON: UTF-8, sorted keys, compact separators, normalized scalars.
  ///
  /// Non-ASCII string content is emitted as `\uXXXX` escapes (`ensure_ascii=True` parity with
  /// the Python golden / EDTS). Do not substitute object-equality after parse for byte identity.
  public static func data(_ object: Any) throws -> Data {
    let normalized = try normalize(object)
    // .sortedKeys is the sole key-order authority — never enumerate Dictionary for output order.
    var data = try JSONSerialization.data(withJSONObject: normalized, options: [.sortedKeys])
    // Canonical form: do not escape solidus. Linux Foundation emits `\/`; Apple/Python do not.
    // Replacing keeps byte identity with the Python golden and Darwin JSONSerialization.
    if let s = String(data: data, encoding: .utf8) {
      let unescaped = s.replacingOccurrences(of: "\\/", with: "/")
      if unescaped != s {
        guard let rewritten = unescaped.data(using: .utf8) else {
          throw CaptureError.packageInvalid("Canonical JSON solidus normalize not UTF-8")
        }
        data = rewritten
      }
    }
    return try ensureAsciiEscapes(data)
  }

  /// Match Python `json.dumps(..., ensure_ascii=True)` for cross-language byte identity.
  /// Already-escaped JSON control sequences (`\n`, `\"`, `\\`, …) are left intact; only raw
  /// Unicode scalar values above U+007F are rewritten as `\uXXXX` (or surrogate pairs).
  private static func ensureAsciiEscapes(_ data: Data) throws -> Data {
    guard let text = String(data: data, encoding: .utf8) else {
      throw CaptureError.packageInvalid("Canonical JSON ensure_ascii input not UTF-8")
    }
    var out = String()
    out.reserveCapacity(text.utf8.count + 16)
    for scalar in text.unicodeScalars {
      let v = scalar.value
      if v <= 0x7F {
        out.unicodeScalars.append(scalar)
      } else if v <= 0xFFFF {
        out.append(String(format: "\\u%04x", v))
      } else {
        let u = v - 0x10000
        let high = 0xD800 + (u >> 10)
        let low = 0xDC00 + (u & 0x3FF)
        out.append(String(format: "\\u%04x\\u%04x", high, low))
      }
    }
    guard let rewritten = out.data(using: .utf8) else {
      throw CaptureError.packageInvalid("Canonical JSON ensure_ascii output not UTF-8")
    }
    return rewritten
  }

  public static func string(_ object: Any) throws -> String {
    let d = try data(object)
    guard let s = String(data: d, encoding: .utf8) else {
      throw CaptureError.packageInvalid("Canonical JSON not UTF-8")
    }
    return s
  }

  /// Recursively reports values the canonical encoder cannot serialize.
  /// Useful for physical-device debugging before encode.
  public static func unsupportedValues(in value: Any, path: String = "$") -> [CanonicalJSONUnsupportedValue] {
    if let dict = value as? [String: Any] {
      return dict.keys.sorted().flatMap { key in
        unsupportedValues(in: dict[key]!, path: path == "$" ? key : "\(path).\(key)")
      }
    }
    if let arr = value as? [Any] {
      return arr.enumerated().flatMap { idx, element in
        unsupportedValues(in: element, path: "\(path)[\(idx)]")
      }
    }
    if isSupportedLeaf(value) {
      return []
    }
    return [
      CanonicalJSONUnsupportedValue(
        keyPath: path,
        runtimeType: String(describing: type(of: value)),
        describing: String(describing: value),
        reflecting: String(reflecting: value)
      )
    ]
  }

  private static func isSupportedLeaf(_ value: Any) -> Bool {
    switch value {
    case is String, is Bool, is NSNull, is Int, is Int64, is Int32, is UInt, is UInt64, is UInt32,
      is Double, is Float, is NSNumber:
      return true
    default:
      return false
    }
  }

  private static func normalize(_ value: Any) throws -> Any {
    switch value {
    case let dict as [String: Any]:
      var out: [String: Any] = [:]
      for (k, v) in dict {
        out[k] = try normalize(v)
      }
      return out
    case let arr as [Any]:
      return try arr.map { try normalize($0) }
    case let s as String:
      return s
    case is NSNull:
      return NSNull()
    default:
      // Pure Swift Bool must be detected before NSNumber — Bool bridges to NSNumber (true→1).
      if type(of: value) == Bool.self, let b = value as? Bool {
        return b
      }
      if let n = value as? NSNumber {
        #if os(iOS) || os(macOS) || os(tvOS) || os(watchOS) || os(visionOS)
        if CFGetTypeID(n as CFTypeRef) == CFBooleanGetTypeID() {
          return n.boolValue
        }
        #endif
        let d = n.doubleValue
        if d.isNaN || d.isInfinite {
          throw CaptureError.packageInvalid("Canonical JSON rejects non-finite numbers")
        }
        if floor(d) == d, let i = Int64(exactly: n.int64Value), Double(i) == d {
          return NSNumber(value: i)
        }
        return n
      }
      if let i = value as? Int { return i }
      if let i = value as? Int64 { return i }
      if let i = value as? Int32 { return Int64(i) }
      if let u = value as? UInt64 {
        guard let i = Int64(exactly: u) else {
          throw CaptureError.packageInvalid("Canonical JSON rejects UInt64 outside Int64 range at value \(u)")
        }
        return i
      }
      if let u = value as? UInt32 { return Int64(u) }
      if let u = value as? UInt {
        guard let i = Int64(exactly: u) else {
          throw CaptureError.packageInvalid("Canonical JSON rejects UInt outside Int64 range at value \(u)")
        }
        return i
      }
      if let d = value as? Double {
        if d.isNaN || d.isInfinite {
          throw CaptureError.packageInvalid("Canonical JSON rejects non-finite numbers")
        }
        if floor(d) == d, let i = Int64(exactly: d) {
          return i
        }
        return d
      }
      if let f = value as? Float {
        return try normalize(Double(f))
      }
      let typeName = String(describing: type(of: value))
      if typeName.hasPrefix("Optional<") {
        throw CaptureError.packageInvalid(
          "Unsupported JSON type \(typeName) (nil Optional boxed as Any; use NSNull() or omit the key). value=\(String(describing: value))"
        )
      }
      throw CaptureError.packageInvalid("Unsupported JSON type \(typeName)")
    }
  }
}

public struct CanonicalJSONUnsupportedValue: Equatable, Sendable {
  public var keyPath: String
  public var runtimeType: String
  public var describing: String
  public var reflecting: String

  public init(keyPath: String, runtimeType: String, describing: String, reflecting: String) {
    self.keyPath = keyPath
    self.runtimeType = runtimeType
    self.describing = describing
    self.reflecting = reflecting
  }
}
