import SwiftUI
import Combine

#if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
import AVFoundation
import UIKit
#endif

/// Pass 2 operator UI: live preview → Take Photo → review (Retake / Use Photo) → Export Package.
/// Pass 3 advanced controls are intentionally absent.
struct Phase1CaptureRootView: View {
  @StateObject private var model = Phase1CaptureViewModel()

  var body: some View {
    ZStack {
      Color.black.ignoresSafeArea()

      #if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
      content
      #else
      Text("Phase 1 still capture requires iOS UIKit + AVFoundation.")
        .foregroundStyle(.white)
        .padding()
      #endif
    }
    .preferredColorScheme(.dark)
    #if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
    .task {
      await model.bootstrap()
    }
    .onDisappear {
      model.teardown()
    }
    #endif
  }

  #if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
  @ViewBuilder
  private var content: some View {
    switch model.uiState {
    case .permissionRequired:
      statusPane(
        title: "Camera Access Required",
        detail: model.statusDetail,
        primary: ("Open Settings", { model.openSettings() }),
        secondary: ("Retry", { Task { await model.bootstrap() } })
      )

    case .starting:
      statusPane(title: "Starting Camera", detail: model.statusDetail, primary: nil, secondary: nil)

    case .previewing, .capturing:
      previewStage

    case .reviewing:
      reviewStage

    case .approved:
      approvedStage

    case .exporting:
      statusPane(title: "Exporting Package", detail: "Writing CapturePackageV1…", primary: nil, secondary: nil)

    case .exported:
      exportedStage

    case .interrupted:
      statusPane(
        title: "Camera Interrupted",
        detail: model.statusDetail,
        primary: ("Resume", { Task { await model.resumeAfterInterrupt() } }),
        secondary: nil
      )

    case .failed:
      statusPane(
        title: "Capture Failed",
        detail: model.statusDetail,
        primary: ("Back to Preview", { Task { await model.recoverFromFailure() } }),
        secondary: nil
      )
    }
  }

  private var previewStage: some View {
    ZStack {
      if let session = model.previewSession {
        CameraPreviewView(session: session)
          .ignoresSafeArea()
          .onAppear { model.markPreviewAttached(true) }
          .onDisappear { model.markPreviewAttached(false) }
      } else {
        Color.black.ignoresSafeArea()
      }

      VStack {
        Spacer()
        Text(model.uiState == .capturing ? "Capturing…" : model.readinessText)
          .font(.headline)
          .foregroundStyle(.white)
          .shadow(radius: 4)
          .padding(.bottom, 8)

        Button {
          Task { await model.takePhoto() }
        } label: {
          Text("Take Photo")
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
        }
        .buttonStyle(.borderedProminent)
        .disabled(model.uiState == .capturing || !model.canTakePhoto)
        .padding(.horizontal, 24)
        .padding(.bottom, 36)
      }
    }
  }

  private var reviewStage: some View {
    ZStack {
      if let image = model.reviewImage {
        Image(uiImage: image)
          .resizable()
          .scaledToFill()
          .ignoresSafeArea()
      } else {
        Color.black.ignoresSafeArea()
        Text("Review image unavailable")
          .foregroundStyle(.white)
      }

      VStack {
        Spacer()
        Text("Review")
          .font(.headline)
          .foregroundStyle(.white)
          .shadow(radius: 4)
        if let pending = model.pendingCapture {
          Text("sha256 \(String(pending.sha256.prefix(12)))…")
            .font(.caption.monospaced())
            .foregroundStyle(.white.opacity(0.85))
            .padding(.bottom, 8)
        }

        HStack(spacing: 16) {
          Button("Retake") {
            model.retake()
          }
          .buttonStyle(.bordered)
          .tint(.white)

          Button("Use Photo") {
            model.usePhoto()
          }
          .buttonStyle(.borderedProminent)
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 36)
      }
    }
  }

  private var approvedStage: some View {
    VStack(spacing: 16) {
      Spacer()
      if let image = model.reviewImage {
        Image(uiImage: image)
          .resizable()
          .scaledToFit()
          .frame(maxHeight: 360)
          .padding(.horizontal, 16)
      }
      Text("Photo Approved")
        .font(.title2.bold())
        .foregroundStyle(.white)
      if let approved = model.approvedCapture {
        Text("Frozen sha256 \(String(approved.sha256.prefix(16)))…")
          .font(.caption.monospaced())
          .foregroundStyle(.white.opacity(0.8))
      }
      Text("Export writes CapturePackageV1 using these frozen bytes only.")
        .font(.footnote)
        .foregroundStyle(.white.opacity(0.75))
        .multilineTextAlignment(.center)
        .padding(.horizontal, 24)

      Button {
        Task { await model.exportPackage() }
      } label: {
        Text("Export Package")
          .font(.headline)
          .frame(maxWidth: .infinity)
          .padding(.vertical, 16)
      }
      .buttonStyle(.borderedProminent)
      .padding(.horizontal, 24)

      Button("Retake") {
        model.retake()
      }
      .buttonStyle(.bordered)
      .tint(.white)
      .padding(.bottom, 36)
      Spacer()
    }
  }

  private var exportedStage: some View {
    VStack(spacing: 16) {
      Spacer()
      Text("Package Exported")
        .font(.title2.bold())
        .foregroundStyle(.white)
      if let path = model.lastExportPath {
        Text(path)
          .font(.caption.monospaced())
          .foregroundStyle(.white.opacity(0.85))
          .multilineTextAlignment(.center)
          .padding(.horizontal, 20)
      }
      if let sha = model.lastExportSha {
        Text("artifact sha256 \(sha)")
          .font(.caption2.monospaced())
          .foregroundStyle(.white.opacity(0.7))
          .padding(.horizontal, 20)
      }
      Button("Capture Another") {
        model.retake()
      }
      .buttonStyle(.borderedProminent)
      .padding(.bottom, 36)
      Spacer()
    }
  }

  private func statusPane(
    title: String,
    detail: String,
    primary: (String, () -> Void)?,
    secondary: (String, () -> Void)?
  ) -> some View {
    VStack(spacing: 16) {
      Spacer()
      Text(title)
        .font(.title2.bold())
        .foregroundStyle(.white)
        .multilineTextAlignment(.center)
      Text(detail)
        .font(.body)
        .foregroundStyle(.white.opacity(0.8))
        .multilineTextAlignment(.center)
        .padding(.horizontal, 24)
      if let primary {
        Button(primary.0, action: primary.1)
          .buttonStyle(.borderedProminent)
      }
      if let secondary {
        Button(secondary.0, action: secondary.1)
          .buttonStyle(.bordered)
          .tint(.white)
      }
      Spacer()
    }
  }
  #endif
}

#if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
@MainActor
final class Phase1CaptureViewModel: ObservableObject {
  @Published private(set) var uiState: Phase1StillCaptureUIState = .starting
  @Published private(set) var statusDetail: String = "Preparing camera…"
  @Published private(set) var previewSession: AVCaptureSession?
  @Published private(set) var pendingCapture: PendingStillCapture?
  @Published private(set) var approvedCapture: ApprovedStillCapture?
  @Published private(set) var reviewImage: UIImage?
  @Published private(set) var canTakePhoto: Bool = false
  @Published private(set) var readinessText: String = "Starting Camera"
  @Published private(set) var lastExportPath: String?
  @Published private(set) var lastExportSha: String?

  private let controller = InteractiveStillCaptureController()
  private var cancellables = Set<AnyCancellable>()
  private var exportDirectoryURL: URL {
    FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
      .appendingPathComponent("CapturePackages", isDirectory: true)
  }

  private var appVersion: String {
    Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0.1.4"
  }

  init() {
    bindController()
  }

  func bootstrap() async {
    transition(to: .starting, detail: "Checking camera permission…")
    pendingCapture = nil
    approvedCapture = nil
    reviewImage = nil
    lastExportPath = nil
    lastExportSha = nil

    do {
      try await controller.prepareSession()
      previewSession = controller.session
      transition(to: .previewing, detail: "Live preview ready.")
    } catch let error as Phase1RuntimeError {
      previewSession = nil
      canTakePhoto = false
      if error == .cameraPermissionDenied {
        transition(to: .permissionRequired, detail: error.detailMessage)
      } else {
        transition(to: .failed(reasonCode: error.reasonCode), detail: error.detailMessage)
      }
    } catch {
      previewSession = nil
      canTakePhoto = false
      transition(
        to: .failed(reasonCode: Phase1RuntimeError.cameraConfigurationFailed("").reasonCode),
        detail: String(describing: error)
      )
    }
  }

  func teardown() {
    controller.stopSession()
    previewSession = nil
    canTakePhoto = false
  }

  func markPreviewAttached(_ attached: Bool) {
    controller.markPreviewAttached(attached)
  }

  func openSettings() {
    guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
    UIApplication.shared.open(url)
  }

  func takePhoto() async {
    guard uiState == .previewing, canTakePhoto else { return }
    transition(to: .capturing, detail: "Capturing still…")
    do {
      let pending = try await controller.capturePendingStill()
      // Bytes + SHA already frozen inside the photo delegate before this returns.
      pendingCapture = pending
      // Throwaway decode for review UI only — never replaces authoritative bytes.
      reviewImage = UIImage(data: pending.jpegBytes)
      canTakePhoto = false
      transition(to: .reviewing, detail: "Review captured still. SHA frozen.")
    } catch let error as Phase1RuntimeError {
      transition(to: .failed(reasonCode: error.reasonCode), detail: error.detailMessage)
    } catch {
      transition(
        to: .failed(reasonCode: Phase1RuntimeError.photoCaptureFailed("").reasonCode),
        detail: String(describing: error)
      )
    }
  }

  func usePhoto() {
    guard uiState == .reviewing, let pending = pendingCapture else { return }
    approvedCapture = pending.promoteToApproved()
    transition(to: .approved, detail: "Photo approved. Ready to export.")
  }

  func retake() {
    pendingCapture = nil
    approvedCapture = nil
    reviewImage = nil
    lastExportPath = nil
    lastExportSha = nil
    // Session remains running; return to live preview without reconfiguration.
    transition(to: .previewing, detail: "Live preview ready.")
    canTakePhoto = controller.shutterEnabled
  }

  func exportPackage() async {
    guard uiState == .approved, let approved = approvedCapture else { return }
    transition(to: .exporting, detail: "Writing CapturePackageV1…")
    do {
      try FileManager.default.createDirectory(at: exportDirectoryURL, withIntermediateDirectories: true)
      // photoCapture unused by exportApproved; fixture satisfies coordinator init.
      let coordinator = Phase1CaptureCoordinator(
        appVersion: appVersion,
        photoCapture: FixtureStillPhotoCaptureService(jpegBytes: Data([0xFF, 0xD8, 0xFF, 0xD9])),
        workRoot: exportDirectoryURL
      )
      let result = try coordinator.exportApproved(approved)
      lastExportPath = result.packageDirectoryURL.path
      lastExportSha = result.artifactSha256
      transition(to: .exported, detail: "PACKAGE_EXPORTED")
    } catch let error as Phase1RuntimeError {
      // Export failure returns to approved — frozen bytes retained.
      transition(to: .approved, detail: "Export failed; approved photo retained. \(error.detailMessage)")
    } catch {
      transition(to: .approved, detail: "Export failed; approved photo retained. \(error)")
    }
  }

  func resumeAfterInterrupt() async {
    do {
      // Re-prepare session after interruption.
      controller.stopSession()
      try await controller.prepareSession()
      previewSession = controller.session
      pendingCapture = nil
      approvedCapture = nil
      reviewImage = nil
      transition(to: .previewing, detail: "Preview resumed after interruption.")
    } catch let error as Phase1RuntimeError {
      transition(to: .failed(reasonCode: error.reasonCode), detail: error.detailMessage)
    } catch {
      transition(
        to: .failed(reasonCode: Phase1RuntimeError.cameraConfigurationFailed("").reasonCode),
        detail: String(describing: error)
      )
    }
  }

  func recoverFromFailure() async {
    await bootstrap()
  }

  private func bindController() {
    controller.$shutterEnabled
      .receive(on: RunLoop.main)
      .sink { [weak self] enabled in
        guard let self else { return }
        if self.uiState == .previewing {
          self.canTakePhoto = enabled
        }
      }
      .store(in: &cancellables)

    controller.$readinessText
      .receive(on: RunLoop.main)
      .assign(to: &$readinessText)

    controller.$wasInterrupted
      .receive(on: RunLoop.main)
      .sink { [weak self] interrupted in
        guard let self else { return }
        if interrupted {
          switch self.uiState {
          case .previewing, .capturing, .reviewing:
            self.canTakePhoto = false
            self.transition(to: .interrupted, detail: "Camera session interrupted.")
          default:
            break
          }
        }
      }
      .store(in: &cancellables)
  }

  private func transition(to next: Phase1StillCaptureUIState, detail: String) {
    if uiState == next {
      statusDetail = detail
      return
    }
    do {
      uiState = try Phase1StillCaptureUIStateMachine.transition(from: uiState, to: next)
      statusDetail = detail
    } catch {
      statusDetail = "Illegal UI transition \(uiState.label) → \(next.label): \(error)"
      if case .failed = uiState {
        return
      }
      uiState = .failed(reasonCode: Phase1RuntimeError.statusAuthorityViolation("illegal_ui_transition").reasonCode)
    }
  }
}
#endif

#Preview {
  Phase1CaptureRootView()
}
