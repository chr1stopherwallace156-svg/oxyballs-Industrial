#if canImport(UIKit) && !os(macOS)
import SwiftUI
import UIKit
import UniformTypeIdentifiers

/// UIActivityViewController wrapper for sharing file URLs (AirDrop / Files / Mail).
struct ActivityShareView: UIViewControllerRepresentable {
  let items: [Any]
  var onComplete: ((Bool) -> Void)? = nil

  func makeUIViewController(context: Context) -> UIActivityViewController {
    let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
    controller.completionWithItemsHandler = { _, completed, _, _ in
      onComplete?(completed)
    }
    return controller
  }

  func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

/// Document picker export (Save to Files) — reliable when Share Sheet omits Files for custom UTI.
struct DocumentExportPicker: UIViewControllerRepresentable {
  let urls: [URL]
  var onFinish: (() -> Void)? = nil

  func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
    let picker: UIDocumentPickerViewController
    if #available(iOS 14.0, *) {
      picker = UIDocumentPickerViewController(forExporting: urls, asCopy: true)
    } else {
      picker = UIDocumentPickerViewController(urls: urls, in: .exportToService)
    }
    picker.delegate = context.coordinator
    return picker
  }

  func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

  func makeCoordinator() -> Coordinator {
    Coordinator(onFinish: onFinish)
  }

  final class Coordinator: NSObject, UIDocumentPickerDelegate {
    let onFinish: (() -> Void)?
    init(onFinish: (() -> Void)?) {
      self.onFinish = onFinish
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
      onFinish?()
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
      onFinish?()
    }
  }
}

/// Preferred UTType for `.edts-pkg` — conforms to zip so AirDrop/Files treat it as an archive.
enum EdtsPkgUTType {
  static var edtsPkg: UTType {
    if let t = UTType(filenameExtension: "edts-pkg") {
      return t
    }
    return .zip
  }
}
#endif
