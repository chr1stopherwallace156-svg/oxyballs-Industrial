import SwiftUI
import ElektronCapture

@main
struct Phase1StillCaptureApp: App {
  var body: some Scene {
    WindowGroup {
      #if canImport(UIKit) && !os(macOS)
      Phase1MainTabView()
      #else
      Phase1CaptureRootView()
      #endif
    }
  }
}
