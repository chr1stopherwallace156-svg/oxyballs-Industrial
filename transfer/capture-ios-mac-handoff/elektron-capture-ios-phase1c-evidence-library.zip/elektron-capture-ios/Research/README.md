# Research — Elektron Capture Lab

Isolated from SPM production targets (`App/`, `Tests/`).

```text
Research/
├── References/          # Upstream clones, vendor SDKs, papers (not production)
│   ├── Apple/
│   ├── GitHub/
│   ├── VendorSDKs/
│   └── Papers/
├── Spikes/              # Throwaway experiments
├── IntegrationReports/  # Atomic IR-0001+
└── Deferred/            # ML / YOLO / interpretation — NO production interfaces
```

## Provenance decisions (mandatory in every IR)

`REFERENCE ONLY` | `ALGORITHM REIMPLEMENTATION` | `WRAPPED DEPENDENCY` | `VENDOR SDK INTEGRATION`
