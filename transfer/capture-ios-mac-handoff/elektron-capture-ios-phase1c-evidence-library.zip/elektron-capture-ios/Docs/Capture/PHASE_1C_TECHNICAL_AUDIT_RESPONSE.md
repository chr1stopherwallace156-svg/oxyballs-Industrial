# Phase 1C Technical Clarifications & Verification Audit Response

**Classification:** `PHASE_1C_IMPLEMENTED_PENDING_MAC_AND_DEVICE_VALIDATION`  
**Tip:** `ae327452135abfedc1b3f6e6b063103ec3aec5ae`  
**ZIP SHA-256:** `9ac2dedcc8d1c4b49012c967f6a51977173fe3ccef9dbfda27cded405872d485`

> Earlier tip `8bf0e17` used a flat `EvidenceLibrary/<id>/` layout. **Current tip uses the approved staging architecture.** Do not audit against the superseded layout.

---

## 1A. Atomic commit protocol

**Layout (current):**

```text
EvidenceLibrary/
  .staging/<capture-id>-<uuid>/
  .quarantine/
  captures/<capture-id>/
  index.json
```

**Crash avoidance:** JPEG/JSON writes occur only under `.staging/`. `captures/<id>/` appears only via directory rename after the storage gate. Abandoned staging is quarantined on launch and never indexed as `STORED_LOCALLY`.

**Storage gate → STORED_LOCALLY** (`EvidenceLibraryStore.storeApproved`):

```171:209:App/Phase1/EvidenceLibrary/EvidenceLibraryStore.swift
      // 4. Read-back & verify — storage gate (exact code path for STORED_LOCALLY eligibility)
      let readback = try Data(contentsOf: stagedOriginal)
      guard !readback.isEmpty else {
        throw EvidenceLibraryError.storageGateFailed("read-back empty")
      }
      let onDisk = try hasher.sha256HexOfFile(at: stagedOriginal)
      guard onDisk == sha256, readback.count == jpegBytes.count else {
        throw EvidenceLibraryError.storageGateFailed(
          "read-back sha=\(onDisk) expected=\(sha256) size=\(readback.count)/\(jpegBytes.count)"
        )
      }

      // 5. Commit rename → captures/<id>/
      ...
      // 6. Index update ONLY after rename — storageState = STORED_LOCALLY
        state: LocalEvidenceRecordState(
          ...
          storageState: .storedLocally,
```

Tests: `testStoreApprovedUsesStagingCommitAndRelativePaths`, `testPartialStagingNeverAppearsAsStoredLocally`.

---

## 1B. Index independence

Yes — `library_status.json` inside each `captures/<id>/` stores capture ID, timestamp, frozen SHA-256, byte count, session/artifact/record IDs, states, format version, and `committed`.

Rebuild rejects uncommitted / pending directories (`rebuildRecordFromDirectory`).

**Test:** `testIndexDeleteRebuildsFromLibraryStatusNotMtime` — deletes `index.json`, rebuilds IDs/timestamps/hashes/paths/states from directories alone.

---

## 1C. Orthogonal state schema

```18:71:App/Phase1/EvidenceLibrary/EvidenceLibraryModels.swift
public enum EvidenceCaptureState: ...
public enum EvidenceStorageState: ...
public enum EvidencePackageState: ...
public enum EvidenceExportState: ...
public enum EvidenceIntegrityState: ...

public struct LocalEvidenceRecordState: Codable, Sendable, Equatable {
  public var captureState: EvidenceCaptureState
  public var storageState: EvidenceStorageState
  public var packageState: EvidencePackageState
  public var exportState: EvidenceExportState
  public var integrityState: EvidenceIntegrityState
}
```

Not a single combined lifecycle enum.

---

## 1D. Package attachment gates

Before `packageState = .created`, `attachPackage`:

1. Source ZIP non-empty + PK-readable (`verifyPackageFile`)
2. Payload present + payload SHA == canonical local JPEG
3. Staged copy re-verified, then renamed to final `.edts-pkg`
4. Writes `<id>.edts-pkg.sha256`
5. Re-checks original untouched

Failed verification sets `creationFailed` / integrity corruption and does not delete the original JPEG.

---

## 1E. Decode-only UI + raw JPEG export

Detail view: `UIImage(data:)` from disk bytes for display only — no write-back.

`copyOriginalJPEG`: `FileManager.copyItem` of `artifact_original.jpg`, then SHA equality vs record (`testJpegCopyExportIsByteIdentical`). No `UIImage.jpegData` re-encode path.

---

## 2. Verification status matrix (updated)

| Gate | Status | Method |
|---|---|---|
| Phase 1A contract preservation | **PASS** | `git diff e03fbc6..HEAD` on builder/hash/canonical/inventory/zip/coordinator = **empty** |
| Linux unit tests | **PASS** | 80 tests, 1 skip, 0 failures |
| Exact JPEG byte preservation | **PASS** | unit tests |
| Index rebuild after deleting index.json | **PASS** | `testIndexDeleteRebuildsFromLibraryStatusNotMtime` |
| Atomic staging directory commit | **PASS** (Linux-proven) | staging→rename + partial-staging test |
| Xcode macOS app compilation | **PENDING** | `HANDOFF_XCODE_BUILD_SKIPPED` on Linux |
| iPhone physical-device matrix | **PENDING** | operator-owned |

---

## 3–5. Still required for `PHASE_1C_COMPLETE`

Cannot be produced from this Linux cloud agent:

1. Successful Xcode app-target build log (`open Phase1StillCapture.xcworkspace` → Build)
2. Physical-device acceptance log (force-quit, reboot, Airplane Mode, multi-capture, re-export SHA, Share cancel) signed with tip + ZIP SHA

### Operator Mac order

```bash
shasum -a 256 DOWNLOAD-elektron-capture-ios-phase1c-evidence-library.zip
# expect 9ac2dedcc8d1c4b49012c967f6a51977173fe3ccef9dbfda27cded405872d485
unzip ... && cd elektron-capture-ios
git rev-parse HEAD   # expect ae327452135abfedc1b3f6e6b063103ec3aec5ae (if .git present) or match identity
make doctor && make verify && swift test
open Phase1StillCapture.xcworkspace
# Build & Run on iPhone → execute §4 device matrix
```

Download:

```text
https://github.com/chr1stopherwallace156-svg/oxyballs-Industrial/raw/cursor/phase1c-evidence-library-handoff-d881/DOWNLOAD-elektron-capture-ios-phase1c-evidence-library.zip
```
