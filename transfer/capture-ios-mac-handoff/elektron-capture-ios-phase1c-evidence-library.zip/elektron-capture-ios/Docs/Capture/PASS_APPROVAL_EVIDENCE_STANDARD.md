# Pass approval evidence standard

| Field | Value |
|---|---|
| Status | **BINDING** |
| Decision | P1-004 |

## HARD STOP reminder

After Pass 1 is committed and baseline tests pass, **STOP**.  
Do not begin Pass 2 until the operator explicitly approves the Pass 1 evidence package.

## Integrity guardrail

> Passing tests is not sufficient if achieved by weakening byte-identity, inventory completeness, status ownership, or artifact-integrity assertions.

## Public contract freeze (Pass 1)

> Public evidence contracts may not change during Pass 1 unless the change is separately documented, justified, versioned, and approved.

Includes: manifest schema, inventory schema, status registry, canonical JSON, package layout.

## No deleted / weakened tests

> Existing tests may not be deleted or weakened without an accompanying engineering justification and explicit operator approval.

## Required evidence with every approval request

Summaries alone are **not** acceptable. Each request must include:

1. **HEAD commit** (full SHA)
2. **Parent commit** (full SHA)
3. `git log -1 --format=fuller`
4. `git show --summary HEAD`
5. `git diff --stat PARENT..HEAD` (and full diff available)
6. **List of files changed** with one-line purpose each
7. **Explanation for every modified production file**
8. **Explanation for every modified / added test** (and confirmation none deleted without approval)
9. **Full `swift test` terminal output** (not a one-line summary)
10. For each repaired bug: Problem → Root cause → Fix → Evidence → Regression test
11. Decision Log IDs touched
12. Bundle SHA-256 if a handoff artifact is minted

## Operator independent verification (recommended before approval)

1. Fresh clone of the Pass tip / bundle into a new directory
2. `git rev-parse HEAD` matches claimed SHA
3. Rerun `swift test` locally (Darwin for CrossLanguage parse path)
4. Rerun `./Scripts/verify-xcode-handoff.sh` when applicable
5. Physical-device smoke only after Pass 2+ (not required to *claim* Pass 1 code correctness, but required before trusting capture UX)

## Pass 2 hash timing (Decision P2-001)

```text
AVCapture delegate
  → immutable Data
  → SHA-256 immediately
  → review UI (throwaway decode only)
  → Use Photo promotes immutable pending → approved
  → Export Package (no re-encode / no rehash of artifact bytes)
  → export write failure → approved (frozen bytes retained)
```

Pass 2 must not weaken Pass 1 byte-identity, inventory completeness, status ownership, or artifact-integrity gates.
