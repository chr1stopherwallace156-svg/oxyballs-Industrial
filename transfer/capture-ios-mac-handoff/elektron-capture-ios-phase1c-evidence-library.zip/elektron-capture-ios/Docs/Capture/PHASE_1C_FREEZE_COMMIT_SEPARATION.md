# Phase 1C — Commit Separation & Equivalence Protocol

**Current status:**  
`PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE`

Mixing Phase 1 freeze evidence with Capture v2 specification files in a single commit would pollute tag `v1.0.0-phase1c` and invalidate it as a clean Phase 1 baseline.

## Status pipeline

```text
[Current]
PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE
       │
       ├── 1. Inventory integrity & equivalence check (ZIP vs Git checkout)
       ├── 2. Commit A — PHASE_1C_FINAL_VALIDATION.md only (+ this protocol already on branch)
       ├── 3. Tag v1.0.0-phase1c & push
       │
       ▼
PHASE_1C_COMPLETE_PENDING_REMOTE_TAG_CONFIRMATION
       │
       ├── 4. Verify remote tag on origin / GitHub
       │
       ▼
PHASE_1C_COMPLETE / PHASE_1_FROZEN  (tag: v1.0.0-phase1c)
       │
       ├── 5. Commit B — Research/ + Specifications/ (Specs 1–3 hardened)
       ├── 6. Draft Specs 4–6 (separate commit after B)
       └── 7. Isolated spike IR-0001 under Research/Spikes/IR-0001/
```

## Branch intent (this freeze-prep tree)

| Item | Rule |
|---|---|
| Baseline tip | `88d9a9b` (Canonical Identity / Phase 1C code — **no** `Specifications/` or `Research/`) |
| Commit A contents | Validation record only (see below) — **no** v2 specs |
| Tag `v1.0.0-phase1c` | Must point at Commit A |
| Commit B | Applied **after** remote tag confirmation only |

**Do not** add `Specifications/` or `Research/` until Commit B.

---

## Step 1 — Verification & equivalence (authoritative Mac clone)

### 1A. Host & device metadata

```bash
sw_vers
uname -m
xcrun devicectl list devices
```

Record exact outputs into `PHASE_1C_FINAL_VALIDATION.md`. Do not invent models, OS builds, or IDs.

### 1B. Git identity

```bash
cd /path/to/actual/elektron-capture-ios-git-repository

git status --short
git branch --show-current
git rev-parse HEAD
git remote -v
git remote get-url origin
```

### 1C. SHA-256 inventory equivalence (ZIP vs Git)

Exclude `.git`, `.build`, DerivedData, and the validation doc itself (it is Commit A’s payload):

```bash
# Authoritative Git working tree
find . \
  -type f \
  ! -path './.git/*' \
  ! -path './.build/*' \
  ! -path './Docs/Evidence/*/DerivedData/*' \
  ! -name 'PHASE_1C_FINAL_VALIDATION.md' \
  -print0 |
sort -z |
xargs -0 shasum -a 256 > /tmp/authoritative-repo-inventory.sha256

# Validated unzipped snapshot (89/0 Mac suite)
find /path/to/unzipped/validated-snapshot \
  -type f \
  ! -path '*/.git/*' \
  ! -path '*/.build/*' \
  ! -path '*/Docs/Evidence/*/DerivedData/*' \
  ! -name 'PHASE_1C_FINAL_VALIDATION.md' \
  -print0 |
sort -z |
xargs -0 shasum -a 256 > /tmp/validated-zip-inventory.sha256

diff -u /tmp/validated-zip-inventory.sha256 /tmp/authoritative-repo-inventory.sha256
```

**Gate:** `diff -u` must show **zero** structural/code payload drift before Commit A.  
If the validated ZIP still contains accidental `Specifications/` / `Research/` from a polluted handoff, use a Phase 1–only snapshot (this freeze-prep tip) as the equivalence reference — never tag a tree that mixes v2 scaffolding into Commit A.

---

## Step 2 — Commit A (Phase 1 baseline lock)

Fill `PHASE_1C_FINAL_VALIDATION.md` with **real** terminal/device evidence only (full 64-char digests; no truncated hashes; no placeholder paths marked as `VERIFIED_PASS`).

Then:

```bash
cd /path/to/actual/elektron-capture-ios-git-repository

# Stage ONLY the validation document (root pointer and/or Docs path — validation record only)
git add PHASE_1C_FINAL_VALIDATION.md Docs/Capture/PHASE_1C_FINAL_VALIDATION.md

git commit -m "docs: complete Phase 1C final validation record"

git tag -a v1.0.0-phase1c -m "Freeze Phase 1C Still Capture baseline"

git show --stat --decorate v1.0.0-phase1c
git rev-parse 'v1.0.0-phase1c^{commit}'
git status --short

git push origin HEAD
git push origin v1.0.0-phase1c
```

**Checkpoint:** Confirm on GitHub that `v1.0.0-phase1c` exists and points at Commit A.  
Then set status → `PHASE_1C_COMPLETE` / `PHASE_1_FROZEN` and enable branch/tag protection.  
There is **no** `git lock-branch` command.

After Commit A lands locally (before or after push), interim status may be recorded as:

`PHASE_1C_COMPLETE_PENDING_REMOTE_TAG_CONFIRMATION`

---

## Step 3 — Commit B (Capture v2 scaffolding — after remote tag)

Only after remote tag confirmation:

```bash
mkdir -p \
  Research/References \
  Research/Spikes \
  Research/IntegrationReports \
  Research/Deferred \
  Specifications

# Copy hardened Specs 1–3 (+ research tree) from the prepared Commit B staging tip / bundle
# Do NOT invent content at freeze time.

git add Research/ Specifications/
git commit -m "docs: initialize Capture v2 specifications and research structure"
git push origin HEAD
```

Commit B = Specs **1–3** (hardened) + Research structure.  
Specs **4–6** and isolated IR-0001 spike = **later commits**, not Commit A and not the freeze tag.

---

## Prepared staging (not in this freeze-prep branch)

Capture v2 hardened Specs 1–3, drafted Specs 4–6, and `Research/Spikes/IR-0001/` were prepared on branch `cursor/phase1c-evidence-library-d881` for **post-tag** application.  
**Do not merge those files into Commit A or into tag `v1.0.0-phase1c`.**
