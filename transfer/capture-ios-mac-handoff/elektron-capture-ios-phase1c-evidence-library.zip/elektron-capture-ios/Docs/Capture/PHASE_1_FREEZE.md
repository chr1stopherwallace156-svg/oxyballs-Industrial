# Phase 1 Freeze Notice

| Field | Value |
|---|---|
| Status | **PENDING** — equivalence + Commit A + remote tag not complete |
| Milestone | `PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE` |
| Tag | *None* until Commit A is tagged `v1.0.0-phase1c` on `origin` |
| Validation | `Docs/Capture/PHASE_1C_FINAL_VALIDATION.md` |
| Protocol | `Docs/Capture/PHASE_1C_FREEZE_COMMIT_SEPARATION.md` |

## Hard rules

1. **Equivalence first** — SHA-256 inventory `diff -u` vs validated ZIP must pass (excluding the validation doc).  
2. **Commit A only** — filled `PHASE_1C_FINAL_VALIDATION.md` (+ Docs copy). No `Specifications/`, no `Research/`.  
3. **Tag A** — annotated `v1.0.0-phase1c` points at Commit A only.  
4. **Remote confirm** — then `PHASE_1C_COMPLETE` / `PHASE_1_FROZEN`.  
5. **Commit B** — Capture v2 Specs 1–3 + Research tree **after** remote tag confirmation.  
6. Specs 4–6 and IR-0001 spike are **not** Commit A and **not** the freeze tag.

There is **no** `git lock-branch` command. Use GitHub branch/tag protection.

## Intended frozen contracts (when freeze completes)

- Phase 1A `.edts-pkg` layout and PackageInventory self-hash omit policy  
- Canonical JSON byte-identity rules  
- Artifact JPEG write-once / SHA-256 freeze semantics  
- Capture-side status ownership  
- Canonical Identity Pattern for package-relative paths (`PackageRelativePath`)
