# Phase 1 Freeze Notice

| Field | Value |
|---|---|
| Status | **FROZEN** |
| Milestone | `PHASE_1C_COMPLETE` |
| Tag | `v1.0.0-phase1c` |
| Validation record | `Docs/Capture/PHASE_1C_FINAL_VALIDATION.md` |

## Frozen contracts (do not change without versioned ADR)

- Phase 1A `.edts-pkg` layout and PackageInventory self-hash omit policy
- Canonical JSON byte-identity rules
- Artifact JPEG write-once / SHA-256 freeze semantics
- Capture-side status ownership (no EDTS-owned status assignment)
- Canonical Identity Pattern for package-relative paths (`PackageRelativePath`)

## Allowed after freeze

- Capture v2 specifications under `Specifications/`
- Research spikes and Integration Reports under `Research/`
- New production modules only when an approved IR + spec gate says so

There is no `git lock-branch` mechanism in this repository; freeze is enforced by tag + this notice + review policy.
