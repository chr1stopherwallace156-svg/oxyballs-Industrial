# Phase 1C Architecture Clarification

**Status:** `PHASE_1C_IMPLEMENTED_PENDING_MAC_AND_DEVICE_VALIDATION`  
**Not:** `PHASE_1C_COMPLETE`

> Note: Tip `8bf0e17` described an earlier flat layout. Current tip uses the approved **staging + captures** layout.

## 1. Record-level commit protocol

```text
Application Support/EvidenceLibrary/
  .staging/<capture-id>-<uuid>/     # incomplete only
  .quarantine/                      # failed/abandoned (never auto-deleted)
  captures/<capture-id>/            # committed only
  index.json                        # rebuildable catalog
```

Sequence in `EvidenceLibraryStore.storeApproved`:

1. Validate capture-id (no `/`, `\`, `..`, empty, leading `.`)
2. Create unique `.staging/<id>-<uuid>/`
3. Exclusive-create `artifact_original.jpg`
4. Write authoritative `library_status.json` with `committed:false`, `storage_state:PENDING`
5. Optional thumbnail (failure cannot delete original)
6. **Storage gate:** reopen JPEG from disk → non-empty → SHA-256 == frozen approved hash
7. `rename` staging → `captures/<id>/` (fails if destination exists)
8. Rewrite `library_status.json` with `committed:true`, `storage_state:STORED_LOCALLY`
9. Update `index.json`

Crash boundaries:

| Crash point | Detection |
|---|---|
| During staging write | Remains under `.staging/`; launch reconcile quarantines staging; never indexed as STORED |
| After write, before rename | Same — staging only |
| After rename, before index | Directory has `committed:true` + hashable original → rebuild from disk recovers record |
| Partial `captures/<id>/` without committed status | `rebuildRecordFromDirectory` throws; not listed as STORED |

`STORED_LOCALLY` is impossible until steps 6–7 succeed.

## 2. Storage gate (code)

Exact gate in `EvidenceLibraryStore.storeApproved` after staging write:

- `Data(contentsOf: stagedOriginal)` non-empty
- `hasher.sha256HexOfFile(at: stagedOriginal) == approved.sha256`
- byte count match
- Then directory rename
- Then index `storageState = .storedLocally`

## 3. Index independence

`library_status.json` fields (authoritative per capture directory):

- `evidence_id`, `session_id`, `artifact_id`, `record_id`
- `capture_timestamp`, `stored_at`
- `capture_state`, `storage_state`
- `original_sha256`, `original_byte_count`
- `vehicle_or_session_label`
- `storage_format_version`, `schema_version`
- `committed`, `phase_status`

Rebuild test: delete `index.json` → `rebuildIndexFromDisk()` reconstructs IDs, timestamps, hashes, relative paths, and states from capture directories + `library_status.json` + on-disk JPEG hash (not mtime inference).

## 4. State model (orthogonal)

```swift
EvidenceCaptureState   // captured | approved
EvidenceStorageState   // pending | storedLocally | missing | unrecognized
EvidencePackageState   // none | created | creationFailed
EvidenceExportState    // notExported | exportedToFiles | shared
EvidenceIntegrityState // unverified | verifiedPass | corruptedHashMismatch | corruptedPackage | missingArtifact
LocalEvidenceRecordState // holds all five independently
```

## 5. Package attachment

`attachPackage` production path:

1. Canonical local JPEG hash must match record
2. `packageResult.artifactSha256` must match
3. `verifyPackageFile` on **source** ZIP: non-empty, PK readable, payload present, payload SHA == canonical
4. Copy to staging file under `exports/`, re-verify, then rename to final `.edts-pkg`
5. Write `.edts-pkg.sha256`
6. Re-check original untouched
7. Only then `packageState = .created`

Failed attach does not delete the original JPEG; prior valid export paths are preserved when verification fails before replace.

## 6. Path safety

- Persistent index stores only library-root-relative paths
- `resolve(_:)` rejects absolute paths, `..`, NUL, and escapes outside `EvidenceLibrary/`
- Capture IDs validated before any directory create

## 7. Runtime-boundary

No intentional changes to JPEG capture freeze, approval hashing, canonical JSON schemas, `EvidencePackageBuilder` inventory semantics, or Documents `.edts-pkg` export contract. Library **copies** packages; it does not replace the export builder.

## 8. Pending for COMPLETE

Mac `xcodebuild` + physical-device matrix (force-quit, reboot, Airplane Mode, two-capture isolation, payload SHA, Share cancel).
