# Phase 1 professional capture — phased execution gates

## HARD STOP AFTER EACH PASS

After each pass is committed and baseline tests pass, **STOP**.

Do **not** begin the next pass until the operator explicitly approves the evidence package for the completed pass.

Reading this whole roadmap is **not** authorization to continue through later passes.

---

## Integrity guardrail (all passes)

> Passing tests is not sufficient if achieved by weakening byte-identity, inventory completeness, status ownership, or artifact-integrity assertions.

## Public contract freeze

> Public evidence contracts may not change unless the change is separately documented, justified, versioned, and approved (Decision Log).

## No deleted / weakened tests

> Existing tests may not be deleted or weakened without an accompanying engineering justification and explicit operator approval.

---

## Pass status

| Pass | Intent | Status |
|---|---|---|
| 0 | Baseline verification | **DONE** @ parent `31513ac` |
| 1 | Restore automated test truth (canonical + inventory) | **OPERATOR-APPROVED** @ tip `9c35de6` / Industrial merge `caeb8a8` |
| 2 | Preview, state machine, review gate, post-delegate hash freeze | **SUBMITTED FOR APPROVAL — HARD STOP** (await operator) |
| 3A | Camera controls + torch lifecycle | **NOT STARTED** — await Pass 2 approval |
| 3B | Normalized metadata sidecar + quality warning/override | **NOT STARTED** |

See also: `Docs/Decisions/DECISION_LOG.md`, `Docs/Capture/PASS_APPROVAL_EVIDENCE_STANDARD.md`, `Docs/Evidence/PASS2_APPROVAL_EVIDENCE/`.

---

## Pass 2 requirements (this pass)

State map (minimum):

```text
permissionRequired? → starting → previewing → capturing → reviewing
  → approved → exporting → exported
(+ interrupted, failed(reasonCode))
```

Hash timing (Decision P2-001):

```text
photo delegate returns
  → freeze original bytes in pending review object
  → compute SHA-256 immediately (before review rendering)
Use Photo
  → promote pending → approved (no recalculate / no replace)
Export Package
  → assemble package only in exporting → exported
Export write failure
  → fall back to approved; keep frozen bytes
```

Pass 3 controls (flash/torch/lens/quality) are **out of scope** for Pass 2 (Decision P2-002).

---

## Pass 3 requirements (when approved)

- Flash vs torch; torch OFF on review / background / lens switch / failed
- Lens discovery = physical devices only
- Metadata: supported JSON leaf types only; omit unsupported with **diagnostic accounting of omitted keys**
- Quality: `WARNING_EFFECTIVELY_BLACK` + Retake / Use Anyway + `operator_override` record
- Cursor may split 3A/3B if the diff is large

---

## Policy references

- `Docs/Validation/CANONICAL_NON_ASCII_POLICY.md` (Pass 1 — preserved)
- `Docs/Evidence/PACKAGE_INVENTORY_PASS1_CLASSIFICATION.md` (Pass 1 — preserved)
- `Docs/Evidence/PASS2_DEVICE_VALIDATION.md` (Pass 2 Mac device procedure)
