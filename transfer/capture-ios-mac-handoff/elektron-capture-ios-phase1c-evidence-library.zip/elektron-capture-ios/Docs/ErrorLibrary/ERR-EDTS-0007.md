# ERR-EDTS-0007 — Inventory undeclared-path false positives (path aliasing)

| Field | Value |
|---|---|
| **Code** | `ERR-EDTS-0007` |
| **Error class** | `RELATIVE_PATH_DERIVATION` |
| **Phase** | Phase 1 `.edts-pkg` inventory completeness |
| **Status** | **FIXED** (`PackageRelativePath.key`) |
| **Related** | Mac `testPackageBuildInventoryAndExtension` — 8 undeclared asserts in one test |

## Symptom

Every on-disk package file is reported undeclared, including `package_inventory.json`, `manifest.json`, payload, status, device, and sidecars — even when `package_inventory.json` lists the correct relative paths.

## Root cause

Package-relative derivation used `standardizedFileURL.path` prefix-strip **without** `resolvingSymlinksInPath()`. On macOS, `/var/...` and `/private/var/...` can identify the same directory with different strings. Prefix strip then fails and discovery keys remain absolute, so they never match relative inventory entries.

## Diagnosis evidence

See:

- `Docs/Evidence/INVENTORY_VALIDATION_FAILURE_EVIDENCE_REPORT.md`
- `Docs/Evidence/INVENTORY_VALIDATION_DIAG_CAPTURE.txt`

Key printed facts: `declaration_set_empty = false`, `decoded_inventory_entries = 7`, `raw_ne_resolved = true`.

## Fix

Central helper `App/Phase1/PackageRelativePath.swift` — `PackageRelativePath.key(for:packageRoot:)` — used by:

- `EvidencePackageBuilder`
- `CaptureSidePackageValidator`
- `ZipPackageWriter`
- inventory tests / `CanonicalPathInvariantTests`

## Prohibited

- Adding inventory entries ad hoc to green tests
- Weakening undeclared-path assertions
- Special-casing the eight filenames
- Changing Phase 1 package contract / schema for this class

## Proof of resolution

```bash
swift test --filter CanonicalPathInvariantTests
swift test --filter Phase1RuntimeTests/testPackageBuildInventoryAndExtension
swift test
```

Optional path dump: `EDTS_INV_PATH_DIAG=1`.

## Permanent guardrail

`Tests/Unit/CanonicalPathInvariantTests.swift` — `canonical(discovered) == canonical(declared)` across absolute, standardized, symlink-resolved, and aliased roots.
