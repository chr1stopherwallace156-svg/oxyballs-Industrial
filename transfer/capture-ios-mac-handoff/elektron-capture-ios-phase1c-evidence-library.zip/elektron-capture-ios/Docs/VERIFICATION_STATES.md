# Verification state machine — elektron-capture-ios

Statuses are **monotonic claims**. A status never implies a later status.

| State | Meaning | How proven |
|---|---|---|
| `SOURCE_PRESENT` | Repo tree / identity present | `doctor` / unzip |
| `PACKAGE_BUILDS` | SPM `ElektronCapture` compiles | `swift build` |
| `TESTS_PASS` | Package tests green | `swift test` |
| `XCODE_APP_BUILDS` | App target compiles for iOS | Mac `xcodebuild` / `HANDOFF_XCODE_BUILD_OK` |
| `DEVICE_SIGNING_READY` | Development team / signing usable for iphoneos | Mac doctor / preflight |
| `DEVICE_APP_LAUNCHED` | App installed and launched on a physical iPhone | **Manual** record |
| `CAMERA_CAPTURE_VERIFIED` | Live preview + Take Photo produced real bytes | **Manual** |
| `PHOTO_APPROVAL_VERIFIED` | Review → Use Photo with frozen hash | **Manual** |
| `PACKAGE_CREATED` | `.edts-pkg` written | Manual + file existence |
| `SHARE_SHEET_VERIFIED` | Share UI presented for `.edts-pkg` | **Manual** |
| `FILES_EXPORT_VERIFIED` | Save to Files / AirDrop delivered a file | **Manual** |
| `PACKAGE_CONTENTS_VERIFIED` | Manifest/inventory/JPEG inspected; JPEG hash matches freeze | Manual + `package-check` |
| `PHASE_APPROVED` | Operator approval recorded | **Never automatic** |

## Rules

1. Automated scripts must **never** write `DEVICE_APP_LAUNCHED` … `PHASE_APPROVED` unless driven by `record-device-validation.sh` answers.
2. `XCODE_APP_BUILDS` does not imply any device/runtime state.
3. `PACKAGE_CREATED` does not imply `SHARE_SHEET_VERIFIED` or `FILES_EXPORT_VERIFIED`.
4. Machine-readable current claims: `Docs/Verification/status.json` (updated by workflows; human-editable for corrections).

## Example (Pass 2 Mac session — illustrative, not automatic)

If the operator recorded launch, capture, approval, package creation, and Files export:

```text
XCODE_APP_BUILDS
DEVICE_APP_LAUNCHED
CAMERA_CAPTURE_VERIFIED
PHOTO_APPROVAL_VERIFIED
PACKAGE_CREATED
FILES_EXPORT_VERIFIED
```

`PHASE_APPROVED` remains unset until explicit operator approval.
