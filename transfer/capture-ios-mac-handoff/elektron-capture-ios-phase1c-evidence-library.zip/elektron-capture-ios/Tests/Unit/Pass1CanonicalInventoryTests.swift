import Foundation
import XCTest
@testable import ElektronCapture

/// Pass 1 — Unicode canonical byte policy + inventory declaration robustness.
/// No UI / camera feature coverage here.
final class Pass1CanonicalInventoryTests: XCTestCase {
  func testUnicodeEnsureAsciiEscapes() throws {
    let bytes = try CanonicalJSON.data(["unicode": "électron"])
    let s = try XCTUnwrap(String(data: bytes, encoding: .utf8))
    XCTAssertTrue(s.contains("\\u00e9"), "expected ensure_ascii escape, got: \(s)")
    XCTAssertFalse(s.contains("é"), "raw non-ASCII must not appear in canonical bytes")
  }

  /// Platform-independent byte-identity check: build the corpus with Swift Bool literals
  /// (never reparsed JSON) and compare to the Python `ensure_ascii=True` golden.
  func testSwiftLiteralCorpusMatchesPythonGoldenBytes() throws {
    let corpus: [String: Any] = [
      "z_last": "should-sort-first-alphabetically-wait-z-is-last",
      "ascii": "Elektron",
      "unicode": "électron",
      "escaped": "line\nquote\"slash\\",
      "empty_string": "",
      "null_value": NSNull(),
      "true_value": true,
      "false_value": false,
      "integer": 42,
      "negative_integer": -42,
      "zero": 0,
      "array": [3, 2, 1],
      "nested": ["z": 1, "a": 2] as [String: Any],
      "empty_object": [:] as [String: Any],
      "empty_array": [] as [Any],
      "timestamp_utc": "2026-07-23T05:00:00.000Z",
      "finite_float": 1.5,
    ]
    let swiftBytes = try CanonicalJSON.data(corpus)
    let goldenURL = try XCTUnwrap(
      Bundle.module.url(forResource: "corpus.python.canonical", withExtension: "json", subdirectory: "Fixtures/canonical_corpus")
        ?? Bundle.module.url(forResource: "corpus.python.canonical", withExtension: "json", subdirectory: "canonical_corpus")
        ?? Bundle.module.url(forResource: "corpus.python.canonical", withExtension: "json")
    )
    let golden = try Data(contentsOf: goldenURL)
    if swiftBytes != golden {
      XCTFail(
        """
        CROSS_LANGUAGE_CANONICAL_JSON_BYTE_IDENTITY FAILED (Swift literals → Python golden)
        swift=\(String(data: swiftBytes, encoding: .utf8) ?? "<bin>")
        python=\(String(data: golden, encoding: .utf8) ?? "<bin>")
        """
      )
    }
    let shaURL = try XCTUnwrap(
      Bundle.module.url(forResource: "corpus.python.canonical", withExtension: "sha256", subdirectory: "Fixtures/canonical_corpus")
        ?? Bundle.module.url(forResource: "corpus.python.canonical", withExtension: "sha256", subdirectory: "canonical_corpus")
        ?? Bundle.module.url(forResource: "corpus.python.canonical", withExtension: "sha256")
    )
    let expectedDigest = try String(contentsOf: shaURL, encoding: .utf8)
      .trimmingCharacters(in: .whitespacesAndNewlines)
    XCTAssertEqual(ContentHasher.sha256Hex(swiftBytes), expectedDigest)
  }

  func testInventoryValidatorFlagsUndeclaredPath() throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("inv-undeclared-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: root) }

    // Minimal package tree with inventory that omits an on-disk file.
    let jpeg = Data(repeating: 0x11, count: 32)
    try FileManager.default.createDirectory(
      at: root.appendingPathComponent("payload"),
      withIntermediateDirectories: true
    )
    try jpeg.write(to: root.appendingPathComponent("payload/artifact_original.jpg"))
    try Data("{}".utf8).write(to: root.appendingPathComponent("manifest.json"))
    try Data("{}".utf8).write(to: root.appendingPathComponent("capture_device.json"))
    try Data(
      #"{"asserted_statuses":["PACKAGE_EXPORTED"],"capture_side_status":"PACKAGE_EXPORTED"}"#.utf8
    ).write(to: root.appendingPathComponent("package_status.json"))
    // Undeclared sidecar
    try FileManager.default.createDirectory(
      at: root.appendingPathComponent("sidecars"),
      withIntermediateDirectories: true
    )
    try Data("{\"x\":1}".utf8).write(to: root.appendingPathComponent("sidecars/extra.json"))

    let artHash = ArtifactHashingService().sha256HexOfData(jpeg)
    let inv: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_format_version": "1.0.0",
      "package_id": "EVD-TEST",
      "entries": [
        [
          "path": "payload/artifact_original.jpg",
          "byte_size": jpeg.count,
          "sha256": artHash,
        ],
        [
          "path": "manifest.json",
          "byte_size": 2,
          "sha256": ArtifactHashingService().sha256HexOfData(Data("{}".utf8)),
        ],
        [
          "path": "capture_device.json",
          "byte_size": 2,
          "sha256": ArtifactHashingService().sha256HexOfData(Data("{}".utf8)),
        ],
        [
          "path": "package_status.json",
          "byte_size": 78,
          "sha256": ArtifactHashingService().sha256HexOfData(
            Data(
              #"{"asserted_statuses":["PACKAGE_EXPORTED"],"capture_side_status":"PACKAGE_EXPORTED"}"#.utf8
            )
          ),
        ],
      ],
      "notes": [] as [String],
    ]
    let invBytes = try CanonicalJSON.data(inv)
    try invBytes.write(to: root.appendingPathComponent("package_inventory.json"))

    let result = CaptureSidePackageValidator.validate(packageDirectory: root)
    XCTAssertFalse(result.ok)
    XCTAssertTrue(
      result.reasonCodes.contains("INVENTORY_UNDECLARED_PATH"),
      "got \(result.reasonCodes)"
    )
  }

  /// Empty `entries` must not silently validate as OK (declaration-set construction guard).
  func testInventoryEmptyEntriesFailsUndeclaredCompleteness() throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("inv-empty-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: root) }

    let jpeg = Data(repeating: 0x33, count: 8)
    try FileManager.default.createDirectory(
      at: root.appendingPathComponent("payload"),
      withIntermediateDirectories: true
    )
    try jpeg.write(to: root.appendingPathComponent("payload/artifact_original.jpg"))
    try Data("{}".utf8).write(to: root.appendingPathComponent("manifest.json"))
    try Data("{}".utf8).write(to: root.appendingPathComponent("capture_device.json"))
    try Data(
      #"{"asserted_statuses":["PACKAGE_EXPORTED"],"capture_side_status":"PACKAGE_EXPORTED"}"#.utf8
    ).write(to: root.appendingPathComponent("package_status.json"))

    let inv: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_format_version": "1.0.0",
      "package_id": "EVD-EMPTY",
      "entries": [] as [[String: Any]],
      "notes": [] as [String],
    ]
    try CanonicalJSON.data(inv).write(to: root.appendingPathComponent("package_inventory.json"))

    let result = CaptureSidePackageValidator.validate(packageDirectory: root)
    XCTAssertFalse(result.ok, "empty declaration set must not pass")
    XCTAssertTrue(
      result.reasonCodes.contains("INVENTORY_UNDECLARED_PATH"),
      "got \(result.reasonCodes)"
    )
  }

  func testInventoryValidatorAcceptsNSNumberByteSize() throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("inv-nsnumber-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: root) }

    let jpeg = Data(repeating: 0x22, count: 16)
    try FileManager.default.createDirectory(
      at: root.appendingPathComponent("payload"),
      withIntermediateDirectories: true
    )
    let files: [(String, Data)] = [
      ("payload/artifact_original.jpg", jpeg),
      ("manifest.json", Data("{}".utf8)),
      ("capture_device.json", Data("{}".utf8)),
      (
        "package_status.json",
        Data(
          #"{"asserted_statuses":["PACKAGE_EXPORTED"],"capture_side_status":"PACKAGE_EXPORTED"}"#.utf8
        )
      ),
    ]
    var entries: [[String: Any]] = []
    for (path, data) in files {
      try data.write(to: root.appendingPathComponent(path))
      entries.append([
        "path": path,
        "byte_size": NSNumber(value: data.count),
        "sha256": ArtifactHashingService().sha256HexOfData(data),
      ])
    }
    let inv: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_format_version": "1.0.0",
      "package_id": "EVD-TEST",
      "entries": entries,
      "notes": [] as [String],
    ]
    // Write via JSONSerialization so byte_size round-trips as NSNumber on Darwin.
    let invData = try JSONSerialization.data(withJSONObject: inv, options: [.sortedKeys])
    try invData.write(to: root.appendingPathComponent("package_inventory.json"))

    let result = CaptureSidePackageValidator.validate(packageDirectory: root)
    XCTAssertTrue(result.ok, "reasonCodes=\(result.reasonCodes) notes=\(result.notes)")
    XCTAssertFalse(result.reasonCodes.contains("INVENTORY_ENTRY_INVALID"))
  }
}
