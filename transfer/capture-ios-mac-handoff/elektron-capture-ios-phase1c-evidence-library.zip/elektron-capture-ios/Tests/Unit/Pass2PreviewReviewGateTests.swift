import Foundation
import XCTest
@testable import ElektronCapture

/// Pass 2: still UI state machine + post-delegate hash freeze + export invariance.
final class Pass2PreviewReviewGateTests: XCTestCase {
  private var workRoot: URL!

  override func setUp() {
    super.setUp()
    workRoot = FileManager.default.temporaryDirectory
      .appendingPathComponent("pass2-tests-\(UUID().uuidString)", isDirectory: true)
    try? FileManager.default.createDirectory(at: workRoot, withIntermediateDirectories: true)
  }

  override func tearDown() {
    try? FileManager.default.removeItem(at: workRoot)
    super.tearDown()
  }

  private var fixtureJPEG: Data {
    let url = Bundle.module.url(forResource: "synthetic_phase1", withExtension: "jpg", subdirectory: "Fixtures")
      ?? Bundle.module.url(forResource: "synthetic_phase1", withExtension: "jpg")
    if let url, let data = try? Data(contentsOf: url) {
      return data
    }
    return Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
      0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14,
      0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7F, 0xFF, 0xD9,
    ])
  }

  func testHappyPathTransitions() throws {
    var state = Phase1StillCaptureUIState.starting
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .previewing)
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .capturing)
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .reviewing)
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .approved)
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .exporting)
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .exported)
    XCTAssertEqual(state, .exported)
  }

  func testRetakeFromReviewAndApproved() throws {
    var state = Phase1StillCaptureUIState.reviewing
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .previewing)
    XCTAssertEqual(state, .previewing)

    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .capturing)
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .reviewing)
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .approved)
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .previewing)
    XCTAssertEqual(state, .previewing)
  }

  func testExportFailureReturnsToApproved() throws {
    var state = Phase1StillCaptureUIState.exporting
    state = try Phase1StillCaptureUIStateMachine.transition(from: state, to: .approved)
    XCTAssertEqual(state, .approved)
  }

  func testIllegalSkipReviewRejected() {
    XCTAssertThrowsError(
      try Phase1StillCaptureUIStateMachine.transition(from: .capturing, to: .approved)
    )
    XCTAssertThrowsError(
      try Phase1StillCaptureUIStateMachine.transition(from: .previewing, to: .exporting)
    )
    XCTAssertThrowsError(
      try Phase1StillCaptureUIStateMachine.transition(from: .reviewing, to: .exported)
    )
  }

  func testPackageWriteOnlyViaExporting() {
    // Cannot jump previewing/approved → exported without exporting.
    XCTAssertFalse(Phase1StillCaptureUIStateMachine.canTransition(from: .approved, to: .exported))
    XCTAssertTrue(Phase1StillCaptureUIStateMachine.canTransition(from: .approved, to: .exporting))
    XCTAssertTrue(Phase1StillCaptureUIStateMachine.canTransition(from: .exporting, to: .exported))
  }

  func testFreezeFromDelegateBytesComputesShaImmediately() throws {
    let pending = try PendingStillCapture.freezeFromDelegateBytes(fixtureJPEG)
    let expected = ArtifactHashingService().sha256HexOfData(fixtureJPEG)
    XCTAssertEqual(pending.sha256, expected)
    XCTAssertEqual(pending.jpegBytes, fixtureJPEG)
    XCTAssertEqual(pending.byteCount, fixtureJPEG.count)
    XCTAssertEqual(pending.jpegSha256Hex, expected)
  }

  func testFreezeRejectsEmptyBytes() {
    XCTAssertThrowsError(try PendingStillCapture.freezeFromDelegateBytes(Data()))
  }

  func testPromoteDoesNotRecalculateOrReplaceBytes() throws {
    let pending = try PendingStillCapture.freezeFromDelegateBytes(fixtureJPEG)
    let approved = pending.promoteToApproved()
    XCTAssertEqual(approved.jpegBytes, pending.jpegBytes)
    XCTAssertEqual(approved.sha256, pending.sha256)
    // Identity: same buffer contents; promote must not mutate pending.
    XCTAssertEqual(pending.jpegBytes, fixtureJPEG)

    let viaInit = ApprovedStillCapture(promoting: pending)
    XCTAssertEqual(viaInit, approved)
  }

  func testExportApprovedHashInvariance() throws {
    let pending = try PendingStillCapture.freezeFromDelegateBytes(fixtureJPEG)
    let approved = pending.promoteToApproved()
    let frozenSha = approved.sha256

    let coordinator = Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: Data([0x00])),
      workRoot: workRoot
    )

    let defaults = UserDefaults(suiteName: "pass2-export-\(UUID().uuidString)")!

    let result = try coordinator.exportApproved(
      approved,
      ids: Phase1CaptureIdentifiers(
        evidenceId: "EVD-PASS2-001",
        sessionId: "SESSION-PASS2-001",
        artifactId: "ART-PASS2-001",
        recordId: "REC-PASS2-001"
      ),
      motionInjected: .unavailable,
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "fixture",
      defaults: defaults
    )

    XCTAssertEqual(result.artifactSha256, frozenSha)
    XCTAssertEqual(result.artifactByteSize, fixtureJPEG.count)
    XCTAssertEqual(result.captureSideStatus, .packageExported)

    // Re-read on-disk artifact must still match frozen SHA (byte identity).
    let artURL = result.packageDirectoryURL.appendingPathComponent("payload/artifact_original.jpg")
    let onDisk = try Data(contentsOf: artURL)
    XCTAssertEqual(onDisk, fixtureJPEG)
    XCTAssertEqual(ArtifactHashingService().sha256HexOfData(onDisk), frozenSha)
  }

  func testExportApprovedDetectsTamperedFrozenSha() throws {
    let pending = try PendingStillCapture.freezeFromDelegateBytes(fixtureJPEG)
    let tampered = ApprovedStillCapture(jpegBytes: pending.jpegBytes, sha256: "deadbeef")
    let coordinator = Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: fixtureJPEG),
      workRoot: workRoot
    )
    XCTAssertThrowsError(try coordinator.exportApproved(tampered)) { err in
      let e = err as? Phase1RuntimeError
      XCTAssertEqual(e?.reasonCode, "HASH_READBACK_MISMATCH")
    }
  }
}
