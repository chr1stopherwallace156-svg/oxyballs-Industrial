import Foundation
import XCTest
@testable import ElektronCapture

/// Permanent CI guardrail: package path identity must collapse to one canonical
/// package-relative key regardless of absolute/standardized/symlink-aliased URL form.
final class CanonicalPathInvariantTests: XCTestCase {
  /// Proves every URL representation of a file inside a package yields the same key.
  func testCanonicalPathInvariantAcrossAliasesAndPrefixes() throws {
    let fm = FileManager.default
    let tempDir = fm.temporaryDirectory
      .appendingPathComponent("invariant-test-\(UUID().uuidString)", isDirectory: true)
    let rootURL = tempDir.appendingPathComponent("pkg-root", isDirectory: true)
    let payloadURL = rootURL.appendingPathComponent("payload", isDirectory: true)
    let targetFileURL = payloadURL.appendingPathComponent("artifact_original.jpg")

    try fm.createDirectory(at: payloadURL, withIntermediateDirectories: true)
    try Data("test-bytes".utf8).write(to: targetFileURL)
    defer { try? fm.removeItem(at: tempDir) }

    let expectedKey = "payload/artifact_original.jpg"

    // 1. Raw absolute URL
    let keyFromAbsolute = PackageRelativePath.key(for: targetFileURL, packageRoot: rootURL)
    // 2. Standardized URL
    let keyFromStandardized = PackageRelativePath.key(
      for: targetFileURL.standardizedFileURL,
      packageRoot: rootURL.standardizedFileURL
    )
    // 3. Symlink-resolved URL
    let keyFromResolved = PackageRelativePath.key(
      for: targetFileURL.resolvingSymlinksInPath(),
      packageRoot: rootURL.resolvingSymlinksInPath()
    )

    // 4. Symlink-aliased package root (macOS `/var` vs `/private/var` class)
    let aliasRoot = tempDir.appendingPathComponent("pkg-root-alias", isDirectory: true)
    try fm.createSymbolicLink(at: aliasRoot, withDestinationURL: rootURL)
    let aliasFile = aliasRoot.appendingPathComponent("payload/artifact_original.jpg")
    let keyFromAliasRoot = PackageRelativePath.key(for: aliasFile, packageRoot: aliasRoot)
    let keyFromMixed = PackageRelativePath.key(
      for: targetFileURL.resolvingSymlinksInPath(),
      packageRoot: aliasRoot
    )

    // Declared inventory form (relative string) must equal the canonical key.
    // PackageRelativePath.key accepts URLs only; inventory stores the relative string directly.
    let declaredInventoryKey = expectedKey

    XCTAssertEqual(keyFromAbsolute, expectedKey, "Absolute path failed canonical invariant")
    XCTAssertEqual(keyFromStandardized, expectedKey, "Standardized path failed canonical invariant")
    XCTAssertEqual(keyFromResolved, expectedKey, "Symlink-resolved path failed canonical invariant")
    XCTAssertEqual(keyFromAliasRoot, expectedKey, "Aliased package root failed canonical invariant")
    XCTAssertEqual(keyFromMixed, expectedKey, "Mixed alias/resolved pair failed canonical invariant")
    XCTAssertEqual(
      keyFromAbsolute,
      declaredInventoryKey,
      "canonical(discovered) must equal canonical(declared)"
    )
    XCTAssertFalse(PackageRelativePath.isAbsoluteFilesystemPath(keyFromAbsolute))
    XCTAssertFalse(keyFromAbsolute.contains(tempDir.path))
  }

  /// Scanner-side and inventory-side keys must match under the same package root.
  func testDiscoveredEqualsDeclaredUnderSymlinkedWorkRoot() throws {
    let fm = FileManager.default
    let real = fm.temporaryDirectory
      .appendingPathComponent("inv-real-\(UUID().uuidString)", isDirectory: true)
    try fm.createDirectory(
      at: real.appendingPathComponent("payload", isDirectory: true),
      withIntermediateDirectories: true
    )
    let file = real.appendingPathComponent("payload/artifact_original.jpg")
    try Data([0xFF, 0xD9]).write(to: file)
    defer { try? fm.removeItem(at: real) }

    let alias = fm.temporaryDirectory
      .appendingPathComponent("inv-alias-\(UUID().uuidString)", isDirectory: true)
    try fm.createSymbolicLink(at: alias, withDestinationURL: real)
    defer { try? fm.removeItem(at: alias) }

    let declared = "payload/artifact_original.jpg"
    let discovered = PackageRelativePath.key(
      for: alias.appendingPathComponent(declared),
      packageRoot: alias
    )
    XCTAssertEqual(discovered, declared)
  }
}
