import Foundation
import XCTest
@testable import ElektronCapture

/// Canonical Identity Pattern guardrail for package-relative path keys.
/// Covers equivalence across URL variants, idempotence, hierarchy preservation,
/// and redundant-component collapsing (`./`, `../`).
final class CanonicalPackageIdentityTests: XCTestCase {
  /// All valid representations of a package item collapse to the same canonical key.
  func testCanonicalIdentityEquivalenceAcrossVariants() throws {
    let fm = FileManager.default
    let tempDir = fm.temporaryDirectory
      .appendingPathComponent("canonical-identity-test-\(UUID().uuidString)", isDirectory: true)
    let rootURL = tempDir.appendingPathComponent("pkg-root", isDirectory: true)
    let nestedPayloadURL = rootURL.appendingPathComponent("payload/subfolder", isDirectory: true)
    let targetFileURL = nestedPayloadURL.appendingPathComponent("artifact_original.jpg")

    try fm.createDirectory(at: nestedPayloadURL, withIntermediateDirectories: true)
    try Data("test-bytes".utf8).write(to: targetFileURL)
    defer { try? fm.removeItem(at: tempDir) }

    let expectedCanonicalKey = "payload/subfolder/artifact_original.jpg"

    let variants: [URL] = [
      targetFileURL,
      targetFileURL.standardizedFileURL,
      targetFileURL.resolvingSymlinksInPath(),
      rootURL.appendingPathComponent("payload/./subfolder/../subfolder/artifact_original.jpg"),
    ]

    for (index, variant) in variants.enumerated() {
      let computedKey = PackageRelativePath.key(for: variant, packageRoot: rootURL)
      XCTAssertEqual(
        computedKey,
        expectedCanonicalKey,
        "Variant at index \(index) failed canonical key computation: \(variant.path)"
      )
    }

    // Declared inventory string form (after canonicalRelativeKey) matches discovery.
    XCTAssertEqual(
      PackageRelativePath.canonicalRelativeKey("payload/./subfolder/../subfolder/artifact_original.jpg"),
      expectedCanonicalKey
    )
  }

  /// Idempotence: canonicalizing an already-canonical key returns the same string.
  func testCanonicalKeyIdempotence() {
    let rawPath = "payload/sidecars/camera_calibration.json"
    let firstPass = PackageRelativePath.canonicalRelativeKey(rawPath)
    let secondPass = PackageRelativePath.canonicalRelativeKey(firstPass)
    XCTAssertEqual(firstPass, rawPath, "First pass modified an already valid canonical key")
    XCTAssertEqual(firstPass, secondPass, "Canonical key transformation is not idempotent")

    let messy = "payload/./sidecars/../sidecars/camera_calibration.json"
    let once = PackageRelativePath.canonicalRelativeKey(messy)
    let twice = PackageRelativePath.canonicalRelativeKey(once)
    XCTAssertEqual(once, "payload/sidecars/camera_calibration.json")
    XCTAssertEqual(once, twice)
  }

  /// Hierarchy preservation: nested structures retain relative path depth.
  func testCanonicalKeyPreservesDirectoryHierarchy() {
    let deepRelativePath = "payload/level1/level2/level3/evidence.jpg"
    let computedKey = PackageRelativePath.canonicalRelativeKey(deepRelativePath)
    XCTAssertEqual(
      computedKey,
      deepRelativePath,
      "Hierarchy was collapsed or truncated during canonicalization"
    )
    XCTAssertFalse(
      computedKey.hasPrefix("/"),
      "Canonical key incorrectly retained a leading slash"
    )
    XCTAssertEqual(computedKey.split(separator: "/").count, 5)
  }

  /// Symlink-aliased package roots (macOS `/var` vs `/private/var` class) stay equivalent.
  func testCanonicalIdentityUnderSymlinkAliasedRoot() throws {
    let fm = FileManager.default
    let real = fm.temporaryDirectory
      .appendingPathComponent("canon-real-\(UUID().uuidString)", isDirectory: true)
    try fm.createDirectory(
      at: real.appendingPathComponent("payload", isDirectory: true),
      withIntermediateDirectories: true
    )
    let file = real.appendingPathComponent("payload/artifact_original.jpg")
    try Data([0xFF, 0xD9]).write(to: file)
    defer { try? fm.removeItem(at: real) }

    let alias = fm.temporaryDirectory
      .appendingPathComponent("canon-alias-\(UUID().uuidString)", isDirectory: true)
    try fm.createSymbolicLink(at: alias, withDestinationURL: real)
    defer { try? fm.removeItem(at: alias) }

    let expected = "payload/artifact_original.jpg"
    XCTAssertEqual(PackageRelativePath.key(for: file, packageRoot: real), expected)
    XCTAssertEqual(
      PackageRelativePath.key(for: alias.appendingPathComponent(expected), packageRoot: alias),
      expected
    )
    XCTAssertEqual(
      PackageRelativePath.key(for: file.resolvingSymlinksInPath(), packageRoot: alias),
      expected
    )
  }
}
