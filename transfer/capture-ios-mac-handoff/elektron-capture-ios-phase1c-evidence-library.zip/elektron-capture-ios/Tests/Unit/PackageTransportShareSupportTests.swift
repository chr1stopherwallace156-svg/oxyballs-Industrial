import Foundation
import XCTest
@testable import ElektronCapture

final class PackageTransportShareSupportTests: XCTestCase {
  private var workRoot: URL!

  override func setUp() {
    super.setUp()
    workRoot = FileManager.default.temporaryDirectory
      .appendingPathComponent("share-support-\(UUID().uuidString)", isDirectory: true)
    try? FileManager.default.createDirectory(at: workRoot, withIntermediateDirectories: true)
  }

  override func tearDown() {
    try? FileManager.default.removeItem(at: workRoot)
    super.tearDown()
  }

  private func writeFakeEdtsPkg(named name: String = "EVD-SHARE-001.edts-pkg", bytes: Data = Data([0x50, 0x4B, 0x03, 0x04, 0x66, 0x61, 0x6B, 0x65])) throws -> URL {
    let url = workRoot.appendingPathComponent(name)
    try bytes.write(to: url)
    return url
  }

  func testRequireEdtsPkgRejectsDirectory() throws {
    let dir = workRoot.appendingPathComponent("EVD-DIR.edts-pkg", isDirectory: true)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    XCTAssertThrowsError(try PackageTransportShareSupport.requireEdtsPkgFile(at: dir))
  }

  func testRequireEdtsPkgRejectsWrongExtension() throws {
    let url = workRoot.appendingPathComponent("EVD.bin")
    try Data([0x01]).write(to: url)
    XCTAssertThrowsError(try PackageTransportShareSupport.requireEdtsPkgFile(at: url))
  }

  func testPrepareShareableStagesCopyWithoutMutatingCanonical() throws {
    let originalBytes = Data("canonical-edts-pkg-bytes-\(UUID().uuidString)".utf8)
    let canonical = try writeFakeEdtsPkg(bytes: originalBytes)
    let staging = workRoot.appendingPathComponent("staging", isDirectory: true)
    let staged = try PackageTransportShareSupport.prepareShareableEdtsPkg(
      from: canonical,
      stagingDirectory: staging
    )
    XCTAssertEqual(staged.pathExtension, "edts-pkg")
    XCTAssertEqual(try Data(contentsOf: staged), originalBytes)
    XCTAssertEqual(try Data(contentsOf: canonical), originalBytes)
    XCTAssertNotEqual(staged.standardizedFileURL.path, canonical.standardizedFileURL.path)
  }

  func testDiagnosticZipCopyIsByteIdenticalAndPreservesCanonical() throws {
    let originalBytes = Data("diagnostic-copy-payload-\(UUID().uuidString)".utf8)
    let canonical = try writeFakeEdtsPkg(bytes: originalBytes)
    let zipURL = PackageTransportShareSupport.diagnosticZipURL(beside: canonical)
    let written = try PackageTransportShareSupport.writeDiagnosticZipCopy(ofEdtsPkg: canonical, to: zipURL)

    XCTAssertEqual(written.pathExtension, "zip")
    XCTAssertTrue(FileManager.default.fileExists(atPath: canonical.path))
    XCTAssertEqual(try Data(contentsOf: canonical), originalBytes)
    XCTAssertEqual(try Data(contentsOf: written), originalBytes)
    XCTAssertEqual(
      ArtifactHashingService().sha256HexOfData(try Data(contentsOf: canonical)),
      ArtifactHashingService().sha256HexOfData(try Data(contentsOf: written))
    )
  }

  func testDiagnosticZipDoesNotTouchPackageDirectoryArtifact() throws {
    // Build a real package, then make diagnostic zip; artifact bytes must be unchanged.
    let jpeg = Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
      0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14,
      0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7F, 0xFF, 0xD9,
    ])
    let pending = try PendingStillCapture.freezeFromDelegateBytes(jpeg)
    let approved = pending.promoteToApproved()
    let coordinator = Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: jpeg),
      workRoot: workRoot
    )
    let result = try coordinator.exportApproved(
      approved,
      ids: Phase1CaptureIdentifiers(
        evidenceId: "EVD-SHARE-ART-001",
        sessionId: "SESSION-SHARE-001",
        artifactId: "ART-SHARE-001",
        recordId: "REC-SHARE-001"
      ),
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "fixture",
      defaults: UserDefaults(suiteName: UUID().uuidString)!
    )

    let artifactURL = result.packageDirectoryURL.appendingPathComponent("payload/artifact_original.jpg")
    let before = try Data(contentsOf: artifactURL)
    XCTAssertEqual(before, jpeg)

    let zipCopy = try PackageTransportShareSupport.writeDiagnosticZipCopy(
      ofEdtsPkg: result.packageZipURL,
      to: PackageTransportShareSupport.diagnosticZipURL(beside: result.packageZipURL)
    )
    let after = try Data(contentsOf: artifactURL)
    XCTAssertEqual(after, before)
    XCTAssertEqual(try Data(contentsOf: zipCopy), try Data(contentsOf: result.packageZipURL))
    try PackageTransportShareSupport.requireEdtsPkgFile(at: result.packageZipURL)
  }
}
