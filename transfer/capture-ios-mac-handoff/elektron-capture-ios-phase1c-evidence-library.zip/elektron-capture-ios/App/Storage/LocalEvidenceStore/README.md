# LocalEvidenceStore

Phase 1C Evidence Library is implemented under:

`App/Phase1/EvidenceLibrary/`

Use `EvidenceLibraryStore` (Application Support / EvidenceLibrary).
This README folder remains scaffolding-only and is excluded from the SPM target.
