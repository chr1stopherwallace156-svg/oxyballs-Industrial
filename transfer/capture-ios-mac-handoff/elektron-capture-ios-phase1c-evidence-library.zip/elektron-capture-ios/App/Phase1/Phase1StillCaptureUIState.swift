import Foundation

/// Pass 2 still-camera UI / pipeline states.
/// Distinct from repository `CaptureSessionState` (plan/session lifecycle).
public enum Phase1StillCaptureUIState: Equatable, Sendable {
  case permissionRequired
  case starting
  case previewing
  case capturing
  case reviewing
  case approved
  case exporting
  case exported
  case interrupted
  case failed(reasonCode: String)

  public var label: String {
    switch self {
    case .permissionRequired: return "PERMISSION_REQUIRED"
    case .starting: return "STARTING"
    case .previewing: return "PREVIEWING"
    case .capturing: return "CAPTURING"
    case .reviewing: return "REVIEWING"
    case .approved: return "APPROVED"
    case .exporting: return "EXPORTING"
    case .exported: return "EXPORTED"
    case .interrupted: return "INTERRUPTED"
    case .failed(let code): return "FAILED(\(code))"
    }
  }
}

public enum Phase1StillCaptureUITransitionError: Error, Equatable, Sendable {
  case illegal(from: String, to: String, reason: String)
}

/// Enforces Take → Use Photo → Export. Package write only in `.exporting` → `.exported`.
public enum Phase1StillCaptureUIStateMachine {
  public static func canTransition(from: Phase1StillCaptureUIState, to: Phase1StillCaptureUIState) -> Bool {
    switch (from, to) {
    case (.permissionRequired, .starting),
      (.permissionRequired, .failed),
      (.starting, .previewing),
      (.starting, .permissionRequired),
      (.starting, .failed),
      (.previewing, .capturing),
      (.previewing, .interrupted),
      (.previewing, .failed),
      (.previewing, .permissionRequired),
      (.capturing, .reviewing),
      (.capturing, .previewing), // capture failure → live again
      (.capturing, .failed),
      (.capturing, .interrupted),
      (.reviewing, .previewing), // Retake
      (.reviewing, .approved), // Use Photo
      (.reviewing, .failed),
      (.reviewing, .interrupted),
      (.approved, .exporting),
      (.approved, .previewing), // abandon / new capture
      (.approved, .failed),
      (.exporting, .exported),
      (.exporting, .approved), // export write failure — keep frozen bytes
      (.exporting, .failed),
      (.exported, .previewing), // New Capture
      (.interrupted, .previewing),
      (.interrupted, .starting),
      (.interrupted, .failed),
      (.failed, .permissionRequired),
      (.failed, .starting),
      (.failed, .previewing):
      return true
    default:
      return false
    }
  }

  @discardableResult
  public static func transition(
    from: Phase1StillCaptureUIState,
    to: Phase1StillCaptureUIState
  ) throws -> Phase1StillCaptureUIState {
    guard canTransition(from: from, to: to) else {
      throw Phase1StillCaptureUITransitionError.illegal(
        from: from.label,
        to: to.label,
        reason: "illegal Pass 2 still UI transition \(from.label) → \(to.label)"
      )
    }
    return to
  }
}

/// Immutable pending capture created **immediately** when the photo delegate returns.
/// Review UI may decode a throwaway preview; it must never replace these bytes or rehash for authority.
public struct PendingStillCapture: Equatable, Sendable {
  public let jpegBytes: Data
  public let sha256: String
  public let byteCount: Int

  public init(jpegBytes: Data, sha256: String) {
    self.jpegBytes = jpegBytes
    self.sha256 = sha256
    self.byteCount = jpegBytes.count
  }

  /// Freeze bytes + hash at delegate receipt (before any review rendering).
  public static func freezeFromDelegateBytes(_ jpegBytes: Data, hasher: ArtifactHashingService = ArtifactHashingService()) throws -> PendingStillCapture {
    guard !jpegBytes.isEmpty else {
      throw Phase1RuntimeError.fileRepresentationUnavailable
    }
    let digest = hasher.sha256HexOfData(jpegBytes)
    Phase1CaptureDiagnostics.log(
      stage: "artifact_hash",
      event: "post_delegate_freeze",
      detail: "sha256=\(digest) byteCount=\(jpegBytes.count)"
    )
    return PendingStillCapture(jpegBytes: jpegBytes, sha256: digest)
  }

  /// Promote to approved without recalculating or replacing bytes.
  public func promoteToApproved() -> ApprovedStillCapture {
    ApprovedStillCapture(jpegBytes: jpegBytes, sha256: sha256)
  }

  /// Alias used by review UI copy (same value as `sha256`).
  public var jpegSha256Hex: String { sha256 }
}

/// Approved artifact: byte-stable until export. Export must assert hash invariance.
public struct ApprovedStillCapture: Equatable, Sendable {
  public let jpegBytes: Data
  public let sha256: String
  public var byteCount: Int { jpegBytes.count }

  public init(jpegBytes: Data, sha256: String) {
    self.jpegBytes = jpegBytes
    self.sha256 = sha256
  }

  /// Promote pending → approved without rehash or byte replace.
  public init(promoting pending: PendingStillCapture) {
    self.jpegBytes = pending.jpegBytes
    self.sha256 = pending.sha256
  }

  /// Alias used by approved UI copy (same value as `sha256`).
  public var jpegSha256Hex: String { sha256 }
}
