import Foundation

/// Actor-safe Evidence Library repository.
///
/// **Authority:** immutable `artifact_original.jpg` on disk is the local source of truth.
/// The index is a rebuildable catalog only.
///
/// **Persistence transaction:** stage → write → read-back SHA → rename into `captures/` → index.
/// `storageState = STORED_LOCALLY` is set only after read-back + successful commit rename.
public actor EvidenceLibraryStore {
  public let paths: EvidenceLibraryPaths
  private let fileManager: FileManager
  private let hasher: ArtifactHashingService
  private let integrity: EvidenceLibraryIntegrityService
  private var cachedIndex: EvidenceLibraryIndexDocument?

  public init(
    libraryRoot: URL,
    fileManager: FileManager = .default,
    hasher: ArtifactHashingService = ArtifactHashingService()
  ) {
    self.paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    self.fileManager = fileManager
    self.hasher = hasher
    self.integrity = EvidenceLibraryIntegrityService(hasher: hasher)
    try? EvidenceLibraryPaths.ensureLibraryLayout(at: libraryRoot, fileManager: fileManager)
  }

  public static func makeDefault() async throws -> EvidenceLibraryStore {
    let root = try EvidenceLibraryPaths.defaultLibraryRoot()
    let store = EvidenceLibraryStore(libraryRoot: root)
    _ = try await store.reconcileOnLaunch()
    return store
  }

  // MARK: - Index (non-authoritative catalog)

  public func loadIndex() throws -> EvidenceLibraryIndexDocument {
    if let cachedIndex { return cachedIndex }
    let url = paths.indexURL
    if !fileManager.fileExists(atPath: url.path) {
      let empty = EvidenceLibraryIndexDocument()
      try persistIndex(empty)
      cachedIndex = empty
      return empty
    }
    let data = try Data(contentsOf: url)
    let dec = JSONDecoder()
    dec.dateDecodingStrategy = .iso8601
    let doc = try dec.decode(EvidenceLibraryIndexDocument.self, from: data)
    cachedIndex = doc
    return doc
  }

  private func persistIndex(_ doc: EvidenceLibraryIndexDocument) throws {
    var mutable = doc
    mutable.updatedAt = Date()
    mutable.phaseStatus = Phase1CStatus.current
    let enc = JSONEncoder()
    enc.outputFormatting = [.prettyPrinted, .sortedKeys]
    enc.dateEncodingStrategy = .iso8601
    let data = try enc.encode(mutable)
    try EvidenceLibraryAtomicIO.writeAtomically(data, to: paths.indexURL, fileManager: fileManager)
    cachedIndex = mutable
  }

  public func listRecordsNewestFirst() throws -> [EvidenceLibraryIndexRecord] {
    try loadIndex().records.sorted { $0.captureTimestamp > $1.captureTimestamp }
  }

  public func record(id: String) throws -> EvidenceLibraryIndexRecord {
    guard let r = try loadIndex().records.first(where: { $0.id == id }) else {
      throw EvidenceLibraryError.recordNotFound(id)
    }
    return r
  }

  // MARK: - Staging commit protocol

  /// Persist approved JPEG via staging transaction.
  /// Retakes must use a **new** capture-id.
  @discardableResult
  public func storeApproved(
    jpegBytes: Data,
    sha256: String,
    ids: Phase1CaptureIdentifiers,
    captureTimestamp: Date = Date(),
    vehicleOrSessionLabel: String? = nil
  ) throws -> EvidenceLibraryIndexRecord {
    try EvidenceLibraryPaths.validateCaptureId(ids.evidenceId)
    let recomputed = hasher.sha256HexOfData(jpegBytes)
    guard recomputed == sha256 else {
      throw EvidenceLibraryError.integrityFailed("approved bytes hash mismatch before store")
    }

    // If canonical already exists, compare hashes and fail safely — never overwrite.
    let finalArtifact = paths.artifactOriginalURL(id: ids.evidenceId)
    if fileManager.fileExists(atPath: finalArtifact.path) {
      let existing = try hasher.sha256HexOfFile(at: finalArtifact)
      throw EvidenceLibraryError.refusingOverwrite(
        "captures/\(ids.evidenceId)/artifact_original.jpg exists (sha=\(existing)); retake requires new capture-id"
      )
    }

    // 1. Stage
    let stagingDir = paths.stagingDirectory(captureId: ids.evidenceId)
    try fileManager.createDirectory(at: stagingDir, withIntermediateDirectories: true)
    try fileManager.createDirectory(
      at: stagingDir.appendingPathComponent("exports", isDirectory: true),
      withIntermediateDirectories: true
    )
    try fileManager.createDirectory(
      at: stagingDir.appendingPathComponent("sidecars", isDirectory: true),
      withIntermediateDirectories: true
    )

    do {
      // 2. Write original (exclusive)
      let stagedOriginal = stagingDir.appendingPathComponent("artifact_original.jpg")
      try EvidenceLibraryAtomicIO.writeOnceExact(jpegBytes, to: stagedOriginal, fileManager: fileManager)

      // 3. Authoritative per-directory metadata (rebuild source of truth — not index)
      let iso = ISO8601DateFormatter()
      iso.formatOptions = [.withInternetDateTime]
      var statusObj: [String: Any] = [
        "schema_id": "EvidenceLibraryLocalStatus",
        "schema_version": "1.1.0",
        "storage_format_version": "1.1.0",
        "evidence_id": ids.evidenceId,
        "session_id": ids.sessionId,
        "artifact_id": ids.artifactId,
        "record_id": ids.recordId,
        "capture_timestamp": iso.string(from: captureTimestamp),
        "capture_state": EvidenceCaptureState.approved.rawValue,
        "storage_state": EvidenceStorageState.pending.rawValue,
        "original_sha256": sha256,
        "original_byte_count": jpegBytes.count,
        "phase_status": Phase1CStatus.current,
        "committed": false,
      ]
      if let label = vehicleOrSessionLabel {
        statusObj["vehicle_or_session_label"] = label
      } else {
        statusObj["vehicle_or_session_label"] = NSNull()
      }
      let statusData = try JSONSerialization.data(
        withJSONObject: statusObj,
        options: [.sortedKeys, .prettyPrinted]
      )
      try EvidenceLibraryAtomicIO.writeAtomically(
        statusData,
        to: stagingDir.appendingPathComponent("library_status.json"),
        fileManager: fileManager
      )

      do {
        let thumb = try EvidenceLibraryThumbnailBuilder.makeThumbnailJPEG(fromOriginal: jpegBytes)
        try EvidenceLibraryAtomicIO.writeAtomically(
          thumb,
          to: stagingDir.appendingPathComponent("thumbnail.jpg"),
          fileManager: fileManager
        )
      } catch {
        Phase1CaptureDiagnostics.log(
          stage: "evidence_library",
          event: "thumbnail_deferred",
          detail: String(describing: error)
        )
      }

      // 4. Read-back & verify — storage gate (exact code path for STORED_LOCALLY eligibility)
      let readback = try Data(contentsOf: stagedOriginal)
      guard !readback.isEmpty else {
        throw EvidenceLibraryError.storageGateFailed("read-back empty")
      }
      let onDisk = try hasher.sha256HexOfFile(at: stagedOriginal)
      guard onDisk == sha256, readback.count == jpegBytes.count else {
        throw EvidenceLibraryError.storageGateFailed(
          "read-back sha=\(onDisk) expected=\(sha256) size=\(readback.count)/\(jpegBytes.count)"
        )
      }

      // 5. Commit rename → captures/<id>/
      let captureDir = paths.captureDirectory(id: ids.evidenceId)
      if fileManager.fileExists(atPath: captureDir.path) {
        throw EvidenceLibraryError.refusingOverwrite(captureDir.path)
      }
      do {
        try fileManager.moveItem(at: stagingDir, to: captureDir)
      } catch {
        throw EvidenceLibraryError.stagingCommitFailed(String(describing: error))
      }

      // 6. Index update ONLY after rename — storageState = STORED_LOCALLY
      let now = Date()
      let record = EvidenceLibraryIndexRecord(
        id: ids.evidenceId,
        captureTimestamp: captureTimestamp,
        sessionId: ids.sessionId,
        artifactId: ids.artifactId,
        recordId: ids.recordId,
        vehicleOrSessionLabel: vehicleOrSessionLabel,
        originalRelativePath: EvidenceLibraryPaths.relativeOriginalPath(id: ids.evidenceId),
        thumbnailRelativePath: EvidenceLibraryPaths.relativeThumbnailPath(id: ids.evidenceId),
        originalSha256: sha256,
        originalByteCount: jpegBytes.count,
        state: LocalEvidenceRecordState(
          captureState: .approved,
          storageState: .storedLocally,
          packageState: .none,
          exportState: .notExported,
          integrityState: .verifiedPass
        ),
        lastIntegrityCheckAt: now,
        storedAt: now,
        updatedAt: now
      )

      var committedStatus = statusObj
      committedStatus["storage_state"] = EvidenceStorageState.storedLocally.rawValue
      committedStatus["committed"] = true
      committedStatus["stored_at"] = iso.string(from: now)
      if let data = try? JSONSerialization.data(
        withJSONObject: committedStatus,
        options: [.sortedKeys, .prettyPrinted]
      ) {
        try EvidenceLibraryAtomicIO.writeAtomically(
          data,
          to: captureDir.appendingPathComponent("library_status.json"),
          fileManager: fileManager
        )
      }

      var doc = try loadIndex()
      doc.records.removeAll { $0.id == record.id }
      doc.records.append(record)
      try persistIndex(doc)
      return record
    } catch {
      try? quarantine(url: stagingDir, reason: "storeApproved_failed")
      if let e = error as? EvidenceLibraryError { throw e }
      throw EvidenceLibraryError.stagingCommitFailed(String(describing: error))
    }
  }

  /// Attempting to overwrite an existing approved original must throw.
  public func assertCannotOverwriteOriginal(id: String, newBytes: Data) throws {
    let url = paths.artifactOriginalURL(id: id)
    try EvidenceLibraryAtomicIO.writeOnceExact(newBytes, to: url, fileManager: fileManager)
  }

  // MARK: - Attach package (non-destructive to original)

  @discardableResult
  public func attachPackage(
    evidenceId: String,
    packageResult: Phase1PackageResult,
    markExported: Bool
  ) throws -> EvidenceLibraryIndexRecord {
    try EvidenceLibraryPaths.validateCaptureId(evidenceId)
    var record = try record(id: evidenceId)

    // Snapshot prior package paths so a failed attach leaves them untouched
    let priorPackageRel = record.packageRelativePath
    let priorPackageSha = record.packageSha256
    let priorPackageState = record.state.packageState
    let priorExportState = record.state.exportState

    // Invariant 6: package must match canonical local JPEG
    let canonicalURL = try paths.resolve(record.originalRelativePath)
    let canonicalHash = try hasher.sha256HexOfFile(at: canonicalURL)
    guard canonicalHash == record.originalSha256 else {
      record.state.integrityState = .corruptedHashMismatch
      try upsert(record)
      throw EvidenceLibraryError.integrityFailed("canonical original hash drifted before package attach")
    }
    guard packageResult.artifactSha256 == record.originalSha256 else {
      record.state.packageState = .creationFailed
      record.state.integrityState = .corruptedHashMismatch
      try upsert(record)
      throw EvidenceLibraryError.integrityFailed(
        "package artifact hash \(packageResult.artifactSha256) != library \(record.originalSha256)"
      )
    }

    // Verify source package BEFORE mutating library exports
    let sourceCheck = try integrity.verifyPackageFile(
      at: packageResult.packageZipURL,
      expectedOriginalSha256: record.originalSha256,
      fileManager: fileManager
    )
    guard sourceCheck.isAcceptable else {
      record.state.packageState = .creationFailed
      record.state.integrityState = .corruptedPackage
      try upsert(record)
      throw EvidenceLibraryError.packageAttachFailed(
        "source package gate failed zip=\(sourceCheck.zipReadable) empty=\(!sourceCheck.nonEmpty) payload=\(sourceCheck.payloadPresent) match=\(sourceCheck.payloadMatchesCanonical)"
      )
    }

    let captureDir = paths.captureDirectory(id: evidenceId)
    let fm = fileManager

    let copyNames = [
      "manifest.json",
      "package_inventory.json",
      "package_status.json",
      "capture_device.json",
    ]
    for name in copyNames {
      let src = packageResult.packageDirectoryURL.appendingPathComponent(name)
      let dst = captureDir.appendingPathComponent(name)
      guard fm.fileExists(atPath: src.path) else { continue }
      if fm.fileExists(atPath: dst.path) { try fm.removeItem(at: dst) }
      try fm.copyItem(at: src, to: dst)
    }

    let srcSide = packageResult.packageDirectoryURL.appendingPathComponent("sidecars", isDirectory: true)
    let dstSide = paths.sidecarsDirectory(id: evidenceId)
    if fm.fileExists(atPath: srcSide.path) {
      try fm.createDirectory(at: dstSide, withIntermediateDirectories: true)
      if let en = fm.enumerator(at: srcSide, includingPropertiesForKeys: [.isRegularFileKey]) {
        for case let src as URL in en {
          let vals = try src.resourceValues(forKeys: [.isRegularFileKey])
          guard vals.isRegularFile == true else { continue }
          let dst = dstSide.appendingPathComponent(src.lastPathComponent)
          if fm.fileExists(atPath: dst.path) { try fm.removeItem(at: dst) }
          try fm.copyItem(at: src, to: dst)
        }
      }
    }

    try fm.createDirectory(at: paths.exportsDirectory(id: evidenceId), withIntermediateDirectories: true)
    let exportURL = paths.exportPackageURL(id: evidenceId)
    // Stage package copy beside destination, verify, then replace
    let stagedPkg = paths.exportsDirectory(id: evidenceId)
      .appendingPathComponent(".\(evidenceId).edts-pkg.staging-\(UUID().uuidString)")
    do {
      try fm.copyItem(at: packageResult.packageZipURL, to: stagedPkg)
      let copiedCheck = try integrity.verifyPackageFile(
        at: stagedPkg,
        expectedOriginalSha256: record.originalSha256,
        fileManager: fm
      )
      guard copiedCheck.isAcceptable, let pkgHash = copiedCheck.packageSha256 else {
        try? fm.removeItem(at: stagedPkg)
        record.state.packageState = .creationFailed
        record.state.integrityState = .corruptedPackage
        // Restore prior package state dimensions if we had a previous good package
        record.packageRelativePath = priorPackageRel
        record.packageSha256 = priorPackageSha
        record.state.packageState = priorPackageRel == nil ? .creationFailed : priorPackageState
        record.state.exportState = priorExportState
        try upsert(record)
        throw EvidenceLibraryError.packageAttachFailed("copied package failed verification gate")
      }

      if fm.fileExists(atPath: exportURL.path) { try fm.removeItem(at: exportURL) }
      try fm.moveItem(at: stagedPkg, to: exportURL)

      let shaFile = paths.exportPackageSha256URL(id: evidenceId)
      try EvidenceLibraryAtomicIO.writeAtomically(
        Data("\(pkgHash)\n".utf8),
        to: shaFile,
        fileManager: fm
      )

      // Confirm original untouched
      let artHash = try hasher.sha256HexOfFile(at: canonicalURL)
      guard artHash == record.originalSha256 else {
        record.state.integrityState = .corruptedHashMismatch
        record.state.packageState = .creationFailed
        try upsert(record)
        throw EvidenceLibraryError.corruptedArtifact("canonical original changed during attachPackage")
      }

      record.packageRelativePath = EvidenceLibraryPaths.relativePackagePath(id: evidenceId)
      record.packageSha256 = pkgHash
      record.packageSha256RelativePath = EvidenceLibraryPaths.relativePackageSha256Path(id: evidenceId)
      record.state.packageState = .created
      if markExported {
        record.state.exportState = .exportedToFiles
      }
      record.state.integrityState = .verifiedPass
      record.updatedAt = Date()
      try upsert(record)
      return record
    } catch {
      try? fm.removeItem(at: stagedPkg)
      throw error
    }
  }

  public func copyExportPackage(id: String, to destination: URL) throws -> URL {
    let record = try record(id: id)
    guard let rel = record.packageRelativePath else {
      throw EvidenceLibraryError.packageAttachFailed("no package on record \(id)")
    }
    let src = try paths.resolve(rel)
    guard fileManager.fileExists(atPath: src.path) else {
      throw EvidenceLibraryError.missingArtifact(rel)
    }
    try fileManager.createDirectory(
      at: destination.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if fileManager.fileExists(atPath: destination.path) {
      try fileManager.removeItem(at: destination)
    }
    try fileManager.copyItem(at: src, to: destination)
    return destination
  }

  public func copyOriginalJPEG(id: String, to destination: URL) throws -> URL {
    let record = try record(id: id)
    let src = try paths.resolve(record.originalRelativePath)
    guard fileManager.fileExists(atPath: src.path) else {
      throw EvidenceLibraryError.missingArtifact(id)
    }
    try fileManager.createDirectory(
      at: destination.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if fileManager.fileExists(atPath: destination.path) {
      try fileManager.removeItem(at: destination)
    }
    try fileManager.copyItem(at: src, to: destination)
    // Byte equality: destination must match canonical
    let srcHash = try hasher.sha256HexOfFile(at: src)
    let dstHash = try hasher.sha256HexOfFile(at: destination)
    guard srcHash == dstHash, srcHash == record.originalSha256 else {
      try? fileManager.removeItem(at: destination)
      throw EvidenceLibraryError.integrityFailed("JPEG copy hash mismatch")
    }
    return destination
  }

  // MARK: - Integrity & reconcile

  @discardableResult
  public func verifyIntegrity(id: String) throws -> EvidenceLibraryIntegrityService.VerificationResult {
    var record = try record(id: id)
    let result = try integrity.verify(record: record, paths: paths, fileManager: fileManager)
    record.lastIntegrityCheckAt = Date()
    record.state.integrityState = result.integrityState
    if let hint = result.storageStateHint, hint == .missing {
      record.state.storageState = .missing
    }
    // Never promote storageState from integrity alone if still pending
    record.updatedAt = Date()
    try upsert(record)
    return result
  }

  /// Scan `captures/`, index orphans, quarantine unrecognized staging.
  /// Never deletes questionable capture directories.
  @discardableResult
  public func reconcileOnLaunch() throws -> EvidenceLibraryIndexDocument {
    try EvidenceLibraryPaths.ensureLibraryLayout(at: paths.libraryRoot, fileManager: fileManager)
    var doc = try loadIndex()
    var byId = Dictionary(uniqueKeysWithValues: doc.records.map { ($0.id, $0) })

    // Quarantine abandoned staging (incomplete writes) — do not delete
    let stagingItems = (try? fileManager.contentsOfDirectory(
      at: paths.stagingRoot,
      includingPropertiesForKeys: [.isDirectoryKey],
      options: [.skipsHiddenFiles]
    )) ?? []
    for url in stagingItems {
      try? quarantine(url: url, reason: "abandoned_staging_on_launch")
    }

    let captureItems = (try? fileManager.contentsOfDirectory(
      at: paths.capturesRoot,
      includingPropertiesForKeys: [.isDirectoryKey],
      options: [.skipsHiddenFiles]
    )) ?? []

    for url in captureItems {
      var isDir: ObjCBool = false
      guard fileManager.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else {
        continue
      }
      let name = url.lastPathComponent
      let artifact = url.appendingPathComponent("artifact_original.jpg")
      if !fileManager.fileExists(atPath: artifact.path) {
        // Invariant 9: never delete. If indexed or has library_status, keep in place as MISSING.
        if byId[name] != nil || fileManager.fileExists(atPath: url.appendingPathComponent("library_status.json").path) {
          if var existing = byId[name] {
            existing.state.storageState = .missing
            existing.state.integrityState = .missingArtifact
            existing.updatedAt = Date()
            byId[name] = existing
          }
          continue
        }
        // Truly unrecognized folder with no original — quarantine without destroying bytes
        try? quarantine(url: url, reason: "unrecognized_capture_missing_original")
        continue
      }
      if byId[name] == nil {
        if let orphan = try? rebuildRecordFromDirectory(id: name) {
          byId[name] = orphan
        }
      }
    }

    // Also migrate legacy flat layout (EvidenceLibrary/<id>/) if present
    let legacy = (try? fileManager.contentsOfDirectory(
      at: paths.libraryRoot,
      includingPropertiesForKeys: [.isDirectoryKey],
      options: [.skipsHiddenFiles]
    )) ?? []
    for url in legacy {
      let name = url.lastPathComponent
      if name == "captures" || name == ".staging" || name == ".quarantine" || name == "index.json" {
        continue
      }
      var isDir: ObjCBool = false
      guard fileManager.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else { continue }
      let legacyArt = url.appendingPathComponent("artifact_original.jpg")
      guard fileManager.fileExists(atPath: legacyArt.path) else {
        try? quarantine(url: url, reason: "unrecognized_legacy")
        continue
      }
      let dest = paths.captureDirectory(id: name)
      if !fileManager.fileExists(atPath: dest.path) {
        try? fileManager.moveItem(at: url, to: dest)
      } else {
        try? quarantine(url: url, reason: "legacy_duplicate")
      }
      if byId[name] == nil, let orphan = try? rebuildRecordFromDirectory(id: name) {
        byId[name] = orphan
      }
    }

    var updated: [EvidenceLibraryIndexRecord] = []
    for (_, var rec) in byId {
      let result = try integrity.verify(record: rec, paths: paths, fileManager: fileManager)
      rec.lastIntegrityCheckAt = Date()
      rec.state.integrityState = result.integrityState
      if let hint = result.storageStateHint, hint == .missing {
        rec.state.storageState = .missing
      }
      updated.append(rec)
    }

    doc.records = updated
    try persistIndex(doc)
    return doc
  }

  public func rebuildIndexFromDisk() throws -> EvidenceLibraryIndexDocument {
    try EvidenceLibraryPaths.ensureLibraryLayout(at: paths.libraryRoot, fileManager: fileManager)
    var records: [EvidenceLibraryIndexRecord] = []
    let contents = (try? fileManager.contentsOfDirectory(
      at: paths.capturesRoot,
      includingPropertiesForKeys: [.isDirectoryKey],
      options: [.skipsHiddenFiles]
    )) ?? []
    for url in contents {
      var isDir: ObjCBool = false
      guard fileManager.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else { continue }
      if let rec = try? rebuildRecordFromDirectory(id: url.lastPathComponent) {
        records.append(rec)
      }
    }
    let doc = EvidenceLibraryIndexDocument(records: records)
    try persistIndex(doc)
    return doc
  }

  // MARK: - Helpers

  private func upsert(_ record: EvidenceLibraryIndexRecord) throws {
    var doc = try loadIndex()
    if let idx = doc.records.firstIndex(where: { $0.id == record.id }) {
      doc.records[idx] = record
    } else {
      doc.records.append(record)
    }
    try persistIndex(doc)
  }

  private func quarantine(url: URL, reason: String) throws {
    try fileManager.createDirectory(at: paths.quarantineRoot, withIntermediateDirectories: true)
    let dest = paths.quarantineRoot.appendingPathComponent(
      "\(url.lastPathComponent)-\(reason)-\(UUID().uuidString)",
      isDirectory: true
    )
    if fileManager.fileExists(atPath: url.path) {
      try fileManager.moveItem(at: url, to: dest)
      Phase1CaptureDiagnostics.log(
        stage: "evidence_library",
        event: "quarantined",
        detail: "reason=\(reason) path=\(dest.lastPathComponent)"
      )
    }
  }

  private func rebuildRecordFromDirectory(id: String) throws -> EvidenceLibraryIndexRecord {
    try EvidenceLibraryPaths.validateCaptureId(id)
    let artifact = paths.artifactOriginalURL(id: id)
    guard fileManager.fileExists(atPath: artifact.path) else {
      throw EvidenceLibraryError.missingArtifact(id)
    }
    let sha = try hasher.sha256HexOfFile(at: artifact)
    let size = try fileManager.attributesOfItem(atPath: artifact.path)[.size] as? Int ?? 0

    // Prefer authoritative library_status.json over filenames / mtimes
    let statusURL = paths.captureDirectory(id: id).appendingPathComponent("library_status.json")
    var captureTimestamp = Date()
    var sessionId = "SESSION-REBUILT"
    var artifactId = "ART-REBUILT"
    var recordId = "REC-REBUILT"
    var label: String?
    var captureState: EvidenceCaptureState = .approved
    var storageState: EvidenceStorageState = .storedLocally
    var expectedSha = sha
    var expectedBytes = size
    var committed = true
    var storedAt: Date?

    if let data = try? Data(contentsOf: statusURL),
       let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
    {
      if let eid = obj["evidence_id"] as? String, eid != id {
        throw EvidenceLibraryError.integrityFailed("library_status evidence_id mismatch dir=\(id) status=\(eid)")
      }
      if let ts = obj["capture_timestamp"] as? String {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime]
        captureTimestamp = iso.date(from: ts) ?? captureTimestamp
      }
      sessionId = obj["session_id"] as? String ?? sessionId
      artifactId = obj["artifact_id"] as? String ?? artifactId
      recordId = obj["record_id"] as? String ?? recordId
      if let s = obj["vehicle_or_session_label"] as? String { label = s }
      if let raw = obj["capture_state"] as? String,
         let cs = EvidenceCaptureState(rawValue: raw) { captureState = cs }
      if let raw = obj["storage_state"] as? String,
         let ss = EvidenceStorageState(rawValue: raw) { storageState = ss }
      if let h = obj["original_sha256"] as? String { expectedSha = h }
      if let b = obj["original_byte_count"] as? Int { expectedBytes = b }
      if let c = obj["committed"] as? Bool { committed = c }
      if let sa = obj["stored_at"] as? String {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime]
        storedAt = iso.date(from: sa)
      }
    }

    // Partial / uncommitted directories must not appear as STORED_LOCALLY
    if !committed || storageState == .pending {
      throw EvidenceLibraryError.storageGateFailed("capture directory not committed: \(id)")
    }
    guard sha == expectedSha, size == expectedBytes, size > 0 else {
      throw EvidenceLibraryError.corruptedArtifact(
        "rebuild hash/size mismatch id=\(id) file=\(sha)/\(size) status=\(expectedSha)/\(expectedBytes)"
      )
    }

    let exportURL = paths.exportPackageURL(id: id)
    var packageRel: String?
    var packageSha: String?
    var packageShaRel: String?
    var packageState: EvidencePackageState = .none
    var exportState: EvidenceExportState = .notExported
    if fileManager.fileExists(atPath: exportURL.path) {
      let pkgCheck = try integrity.verifyPackageFile(
        at: exportURL,
        expectedOriginalSha256: sha,
        fileManager: fileManager
      )
      if pkgCheck.isAcceptable {
        packageRel = EvidenceLibraryPaths.relativePackagePath(id: id)
        packageSha = pkgCheck.packageSha256
        packageShaRel = EvidenceLibraryPaths.relativePackageSha256Path(id: id)
        packageState = .created
        exportState = .exportedToFiles
      }
    }

    return EvidenceLibraryIndexRecord(
      id: id,
      captureTimestamp: captureTimestamp,
      sessionId: sessionId,
      artifactId: artifactId,
      recordId: recordId,
      vehicleOrSessionLabel: label,
      originalRelativePath: EvidenceLibraryPaths.relativeOriginalPath(id: id),
      thumbnailRelativePath: EvidenceLibraryPaths.relativeThumbnailPath(id: id),
      originalSha256: sha,
      originalByteCount: size,
      packageRelativePath: packageRel,
      packageSha256: packageSha,
      packageSha256RelativePath: packageShaRel,
      state: LocalEvidenceRecordState(
        captureState: captureState,
        storageState: .storedLocally,
        packageState: packageState,
        exportState: exportState,
        integrityState: .unverified
      ),
      storedAt: storedAt ?? captureTimestamp
    )
  }
}
