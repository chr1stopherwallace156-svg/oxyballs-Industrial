import Foundation

/// Integrity verification — updates **integrityState** only; does not rewrite originals.
public struct EvidenceLibraryIntegrityService: Sendable {
  public var hasher: ArtifactHashingService

  public init(hasher: ArtifactHashingService = ArtifactHashingService()) {
    self.hasher = hasher
  }

  public struct VerificationResult: Equatable, Sendable {
    public var integrityState: EvidenceIntegrityState
    public var storageStateHint: EvidenceStorageState?
    public var detail: String
    public var currentOriginalSha256: String?
    public var packageZipOk: Bool?
    public var packagePayloadMatchesOriginal: Bool?

    public init(
      integrityState: EvidenceIntegrityState,
      storageStateHint: EvidenceStorageState? = nil,
      detail: String,
      currentOriginalSha256: String? = nil,
      packageZipOk: Bool? = nil,
      packagePayloadMatchesOriginal: Bool? = nil
    ) {
      self.integrityState = integrityState
      self.storageStateHint = storageStateHint
      self.detail = detail
      self.currentOriginalSha256 = currentOriginalSha256
      self.packageZipOk = packageZipOk
      self.packagePayloadMatchesOriginal = packagePayloadMatchesOriginal
    }
  }

  public func verify(
    record: EvidenceLibraryIndexRecord,
    paths: EvidenceLibraryPaths,
    fileManager: FileManager = .default
  ) throws -> VerificationResult {
    let artifactURL = try paths.resolve(record.originalRelativePath)

    guard fileManager.fileExists(atPath: artifactURL.path) else {
      return VerificationResult(
        integrityState: .missingArtifact,
        storageStateHint: .missing,
        detail: "artifact_original.jpg missing at \(record.originalRelativePath)"
      )
    }

    let attrs = try fileManager.attributesOfItem(atPath: artifactURL.path)
    let size = (attrs[.size] as? NSNumber)?.intValue ?? 0
    guard size > 0 else {
      return VerificationResult(
        integrityState: .missingArtifact,
        storageStateHint: .missing,
        detail: "artifact_original.jpg empty"
      )
    }

    let currentHash: String
    do {
      currentHash = try hasher.sha256HexOfFile(at: artifactURL)
    } catch {
      return VerificationResult(
        integrityState: .corruptedHashMismatch,
        detail: "hash failed: \(error)"
      )
    }

    if currentHash != record.originalSha256 {
      return VerificationResult(
        integrityState: .corruptedHashMismatch,
        detail: "SHA-256 mismatch expected=\(record.originalSha256) actual=\(currentHash)",
        currentOriginalSha256: currentHash
      )
    }

    let manifestURL = paths.captureDirectory(id: record.id).appendingPathComponent("manifest.json")
    if fileManager.fileExists(atPath: manifestURL.path),
       let data = try? Data(contentsOf: manifestURL),
       let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
    {
      let manifestHash =
        (obj["artifact"] as? [String: Any])?["sha256"] as? String
        ?? obj["sha256"] as? String
      if let manifestHash, manifestHash != currentHash {
        return VerificationResult(
          integrityState: .corruptedHashMismatch,
          detail: "manifest sha256 mismatch manifest=\(manifestHash) file=\(currentHash)",
          currentOriginalSha256: currentHash
        )
      }
    }

    var zipOk: Bool?
    var payloadMatch: Bool?

    if let rel = record.packageRelativePath {
      let pkgURL = try paths.resolve(rel)
      if fileManager.fileExists(atPath: pkgURL.path) {
        zipOk = verifyZipReadable(pkgURL)
        if zipOk == true {
          payloadMatch = try? payloadOriginalMatches(
            packageURL: pkgURL,
            expectedSha256: currentHash,
            fileManager: fileManager
          )
          if payloadMatch == false {
            return VerificationResult(
              integrityState: .corruptedPackage,
              detail: "package payload hash != local canonical",
              currentOriginalSha256: currentHash,
              packageZipOk: zipOk,
              packagePayloadMatchesOriginal: false
            )
          }
        } else {
          return VerificationResult(
            integrityState: .corruptedPackage,
            detail: "package ZIP unreadable",
            currentOriginalSha256: currentHash,
            packageZipOk: false
          )
        }
      } else if record.state.packageState == .created {
        return VerificationResult(
          integrityState: .missingArtifact,
          detail: "package path recorded but file missing: \(rel)",
          currentOriginalSha256: currentHash
        )
      }
    }

    return VerificationResult(
      integrityState: .verifiedPass,
      storageStateHint: .storedLocally,
      detail: "artifact SHA-256 matches; package checks \(zipOk == nil ? "skipped" : "ok")",
      currentOriginalSha256: currentHash,
      packageZipOk: zipOk,
      packagePayloadMatchesOriginal: payloadMatch
    )
  }

  /// Production gate for package attachment / creation.
  public struct PackageVerification: Equatable, Sendable {
    public var zipReadable: Bool
    public var nonEmpty: Bool
    public var payloadPresent: Bool
    public var payloadMatchesCanonical: Bool
    public var packageSha256: String?

    public var isAcceptable: Bool {
      zipReadable && nonEmpty && payloadPresent && payloadMatchesCanonical
    }
  }

  public func verifyPackageFile(
    at packageURL: URL,
    expectedOriginalSha256: String,
    fileManager: FileManager = .default
  ) throws -> PackageVerification {
    let attrs = try? fileManager.attributesOfItem(atPath: packageURL.path)
    let size = (attrs?[.size] as? NSNumber)?.intValue ?? 0
    let nonEmpty = size > 0 && fileManager.fileExists(atPath: packageURL.path)
    let zipReadable = nonEmpty && verifyZipReadable(packageURL)
    var payloadPresent = false
    var payloadMatches = false
    if zipReadable {
      let match = try payloadOriginalMatches(
        packageURL: packageURL,
        expectedSha256: expectedOriginalSha256,
        fileManager: fileManager
      )
      payloadPresent = match || listContainsPayload(packageURL, fileManager: fileManager)
      payloadMatches = match
    }
    let sha = nonEmpty ? try? hasher.sha256HexOfFile(at: packageURL) : nil
    return PackageVerification(
      zipReadable: zipReadable,
      nonEmpty: nonEmpty,
      payloadPresent: payloadPresent,
      payloadMatchesCanonical: payloadMatches,
      packageSha256: sha
    )
  }

  private func listContainsPayload(_ packageURL: URL, fileManager: FileManager) -> Bool {
    #if os(macOS) || os(Linux)
    let proc = Process()
    proc.executableURL = URL(fileURLWithPath: "/usr/bin/unzip")
    proc.arguments = ["-l", packageURL.path]
    let out = Pipe()
    proc.standardOutput = out
    proc.standardError = Pipe()
    do {
      try proc.run()
      proc.waitUntilExit()
      let data = out.fileHandleForReading.readDataToEndOfFile()
      let text = String(data: data, encoding: .utf8) ?? ""
      return text.contains("payload/artifact_original.jpg") || text.contains("artifact_original.jpg")
    } catch {
      return false
    }
    #else
    return true
    #endif
  }

  private func verifyZipReadable(_ url: URL) -> Bool {
    guard let fh = try? FileHandle(forReadingFrom: url) else { return false }
    defer { try? fh.close() }
    let head = fh.readData(ofLength: 4)
    return head.count == 4 && head[0] == 0x50 && head[1] == 0x4B
      && (head[2] == 0x03 || head[2] == 0x05 || head[2] == 0x07)
  }

  private func payloadOriginalMatches(
    packageURL: URL,
    expectedSha256: String,
    fileManager: FileManager
  ) throws -> Bool {
    let tmp = fileManager.temporaryDirectory
      .appendingPathComponent("EvidenceLibraryIntegrity-\(UUID().uuidString)", isDirectory: true)
    try fileManager.createDirectory(at: tmp, withIntermediateDirectories: true)
    defer { try? fileManager.removeItem(at: tmp) }

    #if os(macOS) || os(Linux)
    let proc = Process()
    proc.executableURL = URL(fileURLWithPath: "/usr/bin/unzip")
    proc.arguments = ["-qq", packageURL.path, "payload/artifact_original.jpg", "-d", tmp.path]
    proc.standardError = Pipe()
    proc.standardOutput = Pipe()
    do {
      try proc.run()
      proc.waitUntilExit()
    } catch {
      return false
    }
    let extracted = tmp.appendingPathComponent("payload/artifact_original.jpg")
    if fileManager.fileExists(atPath: extracted.path) {
      return try hasher.sha256HexOfFile(at: extracted) == expectedSha256
    }
    if let en = fileManager.enumerator(at: tmp, includingPropertiesForKeys: nil) {
      for case let u as URL in en where u.lastPathComponent == "artifact_original.jpg" {
        return try hasher.sha256HexOfFile(at: u) == expectedSha256
      }
    }
    return false
    #else
    return true
    #endif
  }
}
