import Foundation

/// Canonical package-relative path identity for inventory listing, validation, and ZIP names.
///
/// **Canonical Identity Pattern:** one implementation, invariant tests, ADR, error library entry.
/// Comparison keys must not depend on:
/// - temporary-directory prefixes
/// - macOS `/var` vs `/private/var` (or other symlink aliases)
/// - machine-specific absolute paths
/// - redundant `.` / `..` components
public enum PackageRelativePath {
  /// Symlink-resolved, standardized, forward-slash path relative to `packageRoot`.
  /// Returns an empty string only if `file` is the package root itself.
  public static func key(for file: URL, packageRoot: URL) -> String {
    let root = packageRoot.resolvingSymlinksInPath().standardizedFileURL
    let resolved = file.resolvingSymlinksInPath().standardizedFileURL
    let rootComponents = root.pathComponents
    let fileComponents = resolved.pathComponents
    let relative: String
    if fileComponents.starts(with: rootComponents) {
      relative = fileComponents.dropFirst(rootComponents.count).joined(separator: "/")
    } else {
      // Fallback: string prefix on resolved absolute paths (same resolution on both sides).
      let rootPath = root.path
      var filePath = resolved.path
      if filePath.hasPrefix(rootPath) {
        filePath = String(filePath.dropFirst(rootPath.count))
        if filePath.hasPrefix("/") { filePath = String(filePath.dropFirst()) }
        relative = filePath
      } else {
        // Unresolvable — return resolved absolute path so callers fail loudly (never silently match).
        return resolved.path
      }
    }
    if isAbsoluteFilesystemPath(relative) { return relative }
    return canonicalRelativeKey(relative)
  }

  /// Canonicalize a package-relative key string (inventory `path` field form).
  /// Idempotent: `canonicalRelativeKey(canonicalRelativeKey(x)) == canonicalRelativeKey(x)`.
  /// Collapses `.` / `..`, normalizes separators, strips a single leading `./` or `/`.
  public static func canonicalRelativeKey(_ path: String) -> String {
    var s = path.replacingOccurrences(of: "\\", with: "/")
    while s.hasPrefix("./") { s = String(s.dropFirst(2)) }
    while s.hasPrefix("/") { s = String(s.dropFirst()) }
    while s.hasSuffix("/") && s.count > 1 { s = String(s.dropLast()) }
    return collapseDotSegments(s)
  }

  /// Whether `path` looks like an absolute filesystem path (not a package-relative key).
  public static func isAbsoluteFilesystemPath(_ path: String) -> Bool {
    path.hasPrefix("/") || (path.count > 1 && path[path.index(path.startIndex, offsetBy: 1)] == ":")
  }

  /// Collapse `.` and `..` without escaping above the package root (excess `..` dropped).
  private static func collapseDotSegments(_ path: String) -> String {
    var stack: [String] = []
    for part in path.split(separator: "/", omittingEmptySubsequences: true) {
      if part == "." { continue }
      if part == ".." {
        if !stack.isEmpty { stack.removeLast() }
        continue
      }
      stack.append(String(part))
    }
    return stack.joined(separator: "/")
  }
}
