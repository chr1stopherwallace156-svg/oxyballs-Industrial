import Foundation

/// Canonical package-relative path keys for inventory listing, validation, and ZIP names.
///
/// Comparison keys must not depend on:
/// - temporary-directory prefixes
/// - macOS `/var` vs `/private/var` (or other symlink aliases)
/// - machine-specific absolute paths
public enum PackageRelativePath {
  /// Symlink-resolved, standardized, forward-slash path relative to `packageRoot`.
  /// Returns an empty string only if `file` is the package root itself.
  public static func key(for file: URL, packageRoot: URL) -> String {
    let root = packageRoot.resolvingSymlinksInPath().standardizedFileURL
    let resolved = file.resolvingSymlinksInPath().standardizedFileURL
    let rootComponents = root.pathComponents
    let fileComponents = resolved.pathComponents
    if fileComponents.starts(with: rootComponents) {
      return fileComponents.dropFirst(rootComponents.count).joined(separator: "/")
    }
    // Fallback: string prefix on resolved absolute paths (same resolution on both sides).
    let rootPath = root.path
    var filePath = resolved.path
    if filePath.hasPrefix(rootPath) {
      filePath = String(filePath.dropFirst(rootPath.count))
      if filePath.hasPrefix("/") { filePath = String(filePath.dropFirst()) }
      return filePath
    }
    // Unresolvable — return resolved absolute path so callers fail loudly (never silently match).
    return resolved.path
  }

  /// Whether `path` looks like an absolute filesystem path (not a package-relative key).
  public static func isAbsoluteFilesystemPath(_ path: String) -> Bool {
    path.hasPrefix("/") || (path.count > 1 && path[path.index(path.startIndex, offsetBy: 1)] == ":")
  }
}
