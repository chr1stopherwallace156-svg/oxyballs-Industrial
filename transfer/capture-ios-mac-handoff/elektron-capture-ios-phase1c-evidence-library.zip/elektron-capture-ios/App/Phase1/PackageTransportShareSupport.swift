import Foundation

/// Share / transfer helpers for Phase 1 `.edts-pkg` transport.
///
/// Does **not** touch package directory contents (including `artifact_original.jpg`).
/// The canonical transport remains the `.edts-pkg` file; a `.zip` copy is diagnostic only.
public enum PackageTransportShareSupport {
  public static let edtsPkgPathExtension = "edts-pkg"
  public static let diagnosticZipPathExtension = "zip"

  /// Validates that `url` is an existing regular file with `.edts-pkg` extension (ZIP transport).
  public static func requireEdtsPkgFile(at url: URL) throws {
    let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isDirectoryKey, .fileSizeKey])
    guard values.isDirectory != true else {
      throw Phase1RuntimeError.exportFailed(
        "share target is a directory; expected .\(edtsPkgPathExtension) file at \(url.path)"
      )
    }
    guard values.isRegularFile == true else {
      throw Phase1RuntimeError.exportFailed("share target missing or not a file: \(url.path)")
    }
    guard url.pathExtension.lowercased() == edtsPkgPathExtension else {
      throw Phase1RuntimeError.exportFailed(
        "share target extension must be .\(edtsPkgPathExtension), got .\((url.pathExtension))"
      )
    }
    let size = values.fileSize ?? 0
    guard size > 0 else {
      throw Phase1RuntimeError.exportFailed("share target is empty: \(url.path)")
    }
  }

  /// Stages a copy of the canonical `.edts-pkg` for Share Sheet / AirDrop / Files.
  /// Staging avoids handing UIActivityViewController a path that may be mid-write or
  /// confused with the package *directory* of the same stem.
  public static func prepareShareableEdtsPkg(
    from packageZipURL: URL,
    stagingDirectory: URL,
    fileManager: FileManager = .default
  ) throws -> URL {
    try requireEdtsPkgFile(at: packageZipURL)
    try fileManager.createDirectory(at: stagingDirectory, withIntermediateDirectories: true)
    let staged = stagingDirectory.appendingPathComponent(packageZipURL.lastPathComponent)
    if fileManager.fileExists(atPath: staged.path) {
      try fileManager.removeItem(at: staged)
    }
    try fileManager.copyItem(at: packageZipURL, to: staged)
    try requireEdtsPkgFile(at: staged)
    // Exclude staging copies from backup; canonical Documents export remains authoritative.
    var resourceValues = URLResourceValues()
    resourceValues.isExcludedFromBackup = true
    var mutable = staged
    try mutable.setResourceValues(resourceValues)
    return staged
  }

  /// Byte-identical diagnostic copy with `.zip` extension for receivers that reject custom UTI.
  /// Canonical `.edts-pkg` is left untouched. Package payload bytes are not re-encoded.
  @discardableResult
  public static func writeDiagnosticZipCopy(
    ofEdtsPkg packageZipURL: URL,
    to zipURL: URL,
    fileManager: FileManager = .default
  ) throws -> URL {
    try requireEdtsPkgFile(at: packageZipURL)
    guard zipURL.pathExtension.lowercased() == diagnosticZipPathExtension else {
      throw Phase1RuntimeError.exportFailed(
        "diagnostic copy must use .\(diagnosticZipPathExtension) extension"
      )
    }
    try fileManager.createDirectory(
      at: zipURL.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if fileManager.fileExists(atPath: zipURL.path) {
      try fileManager.removeItem(at: zipURL)
    }
    try fileManager.copyItem(at: packageZipURL, to: zipURL)
    let original = try Data(contentsOf: packageZipURL)
    let copy = try Data(contentsOf: zipURL)
    guard original == copy else {
      throw Phase1RuntimeError.exportFailed("diagnostic zip copy bytes diverge from .edts-pkg")
    }
    return zipURL
  }

  /// Default diagnostic zip path beside the canonical transport file.
  public static func diagnosticZipURL(beside packageZipURL: URL) -> URL {
    packageZipURL
      .deletingPathExtension()
      .appendingPathExtension(diagnosticZipPathExtension)
  }
}
