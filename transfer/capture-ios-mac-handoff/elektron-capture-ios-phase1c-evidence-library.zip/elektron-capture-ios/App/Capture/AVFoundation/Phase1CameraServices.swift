#if canImport(AVFoundation) && canImport(UIKit)
import AVFoundation
import Combine
import Foundation
import UIKit

public final class CameraAuthorizationService: @unchecked Sendable {
  public init() {}

  public func authorizationStatus() -> AVAuthorizationStatus {
    AVCaptureDevice.authorizationStatus(for: .video)
  }

  public func requestAccessIfNeeded() async throws {
    switch authorizationStatus() {
    case .authorized:
      return
    case .notDetermined:
      let granted = await AVCaptureDevice.requestAccess(for: .video)
      if !granted { throw Phase1RuntimeError.cameraPermissionDenied }
    case .denied, .restricted:
      throw Phase1RuntimeError.cameraPermissionDenied
    @unknown default:
      throw Phase1RuntimeError.cameraPermissionDenied
    }
  }
}

public final class CameraSessionController: NSObject, @unchecked Sendable {
  public let session = AVCaptureSession()
  private let sessionQueue = DispatchQueue(label: "elektron.capture.session")

  public override init() {
    super.init()
  }

  public func configureForStillCapture() throws {
    session.beginConfiguration()
    defer { session.commitConfiguration() }
    session.sessionPreset = .photo

    session.inputs.forEach { session.removeInput($0) }
    session.outputs.forEach { session.removeOutput($0) }

    guard
      let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
    else {
      throw Phase1RuntimeError.cameraConfigurationFailed("no rear wide camera")
    }
    let input: AVCaptureDeviceInput
    do {
      input = try AVCaptureDeviceInput(device: device)
    } catch {
      throw Phase1RuntimeError.cameraConfigurationFailed(String(describing: error))
    }
    guard session.canAddInput(input) else {
      throw Phase1RuntimeError.cameraConfigurationFailed("cannot add camera input")
    }
    session.addInput(input)
  }

  public func start() {
    sessionQueue.async { [session] in
      if !session.isRunning { session.startRunning() }
    }
  }

  public func stop() {
    sessionQueue.async { [session] in
      if session.isRunning { session.stopRunning() }
    }
  }
}

/// Pass 2 interactive session: live preview + warm-up shutter. No Pass 3 flash/torch/lens UI.
@MainActor
public final class InteractiveStillCaptureController: NSObject, ObservableObject {
  public let sessionController: CameraSessionController
  public let warmUpNanoseconds: UInt64

  private let auth: CameraAuthorizationService
  private let photoOutput = AVCapturePhotoOutput()
  private var continuation: CheckedContinuation<PendingStillCapture, Error>?
  private var runningObs: NSObjectProtocol?
  private var stoppedObs: NSObjectProtocol?
  private var interruptedObs: NSObjectProtocol?
  private var resumedObs: NSObjectProtocol?
  private var warmUpTask: Task<Void, Never>?

  @Published public private(set) var sessionRunning = false
  @Published public private(set) var previewAttached = false
  @Published public private(set) var warmUpElapsed = false
  @Published public private(set) var shutterEnabled = false
  @Published public private(set) var readinessText = "Starting Camera"
  @Published public private(set) var fatalConfigError: String?
  @Published public private(set) var wasInterrupted = false

  public var session: AVCaptureSession { sessionController.session }

  public init(
    auth: CameraAuthorizationService = CameraAuthorizationService(),
    sessionController: CameraSessionController = CameraSessionController(),
    warmUpNanoseconds: UInt64 = 1_500_000_000
  ) {
    self.auth = auth
    self.sessionController = sessionController
    self.warmUpNanoseconds = warmUpNanoseconds
    super.init()
  }

  public func prepareSession() async throws {
    fatalConfigError = nil
    wasInterrupted = false
    readinessText = "Starting Camera"
    let status = auth.authorizationStatus()
    if status == .denied || status == .restricted {
      throw Phase1RuntimeError.cameraPermissionDenied
    }
    try await auth.requestAccessIfNeeded()
    do {
      try sessionController.configureForStillCapture()
      sessionController.session.beginConfiguration()
      if sessionController.session.canAddOutput(photoOutput) {
        sessionController.session.addOutput(photoOutput)
      } else if !sessionController.session.outputs.contains(where: { $0 === photoOutput }) {
        throw Phase1RuntimeError.cameraConfigurationFailed("cannot add photo output")
      }
      if #available(iOS 16.0, *) {
        photoOutput.maxPhotoQualityPrioritization = .quality
      }
      sessionController.session.commitConfiguration()
    } catch {
      fatalConfigError = (error as? Phase1RuntimeError)?.detailMessage ?? String(describing: error)
      readinessText = "Error"
      refreshShutterGate()
      throw error
    }
    observeSessionLifecycle()
    sessionController.start()
    scheduleWarmUp()
    refreshShutterGate()
  }

  public func markPreviewAttached(_ attached: Bool = true) {
    previewAttached = attached
    refreshShutterGate()
  }

  /// Capture still; freezes pending bytes+SHA immediately in the delegate path.
  public func capturePendingStill() async throws -> PendingStillCapture {
    guard shutterEnabled else {
      throw Phase1RuntimeError.cameraConfigurationFailed(
        "shutter not enabled (sessionRunning=\(sessionRunning) previewAttached=\(previewAttached) warmUpElapsed=\(warmUpElapsed))"
      )
    }
    return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<PendingStillCapture, Error>) in
      self.continuation = cont
      let settings: AVCapturePhotoSettings
      if photoOutput.availablePhotoCodecTypes.contains(.jpeg) {
        settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
      } else {
        settings = AVCapturePhotoSettings()
      }
      self.photoOutput.capturePhoto(with: settings, delegate: self)
    }
  }

  public func stopSession() {
    warmUpTask?.cancel()
    warmUpTask = nil
    removeObservers()
    sessionController.stop()
    sessionRunning = false
    shutterEnabled = false
    refreshShutterGate()
  }

  private func scheduleWarmUp() {
    warmUpTask?.cancel()
    warmUpElapsed = false
    let ns = warmUpNanoseconds
    warmUpTask = Task { [weak self] in
      try? await Task.sleep(nanoseconds: ns)
      guard let self, !Task.isCancelled else { return }
      await MainActor.run {
        self.warmUpElapsed = true
        self.refreshShutterGate()
      }
    }
  }

  private func removeObservers() {
    if let runningObs { NotificationCenter.default.removeObserver(runningObs) }
    if let stoppedObs { NotificationCenter.default.removeObserver(stoppedObs) }
    if let interruptedObs { NotificationCenter.default.removeObserver(interruptedObs) }
    if let resumedObs { NotificationCenter.default.removeObserver(resumedObs) }
    runningObs = nil
    stoppedObs = nil
    interruptedObs = nil
    resumedObs = nil
  }

  private func observeSessionLifecycle() {
    removeObservers()
    runningObs = NotificationCenter.default.addObserver(
      forName: .AVCaptureSessionDidStartRunning,
      object: sessionController.session,
      queue: .main
    ) { [weak self] _ in
      Task { @MainActor in
        self?.sessionRunning = true
        self?.wasInterrupted = false
        self?.refreshShutterGate()
      }
    }
    stoppedObs = NotificationCenter.default.addObserver(
      forName: .AVCaptureSessionDidStopRunning,
      object: sessionController.session,
      queue: .main
    ) { [weak self] _ in
      Task { @MainActor in
        self?.sessionRunning = false
        self?.refreshShutterGate()
      }
    }
    interruptedObs = NotificationCenter.default.addObserver(
      forName: .AVCaptureSessionWasInterrupted,
      object: sessionController.session,
      queue: .main
    ) { [weak self] _ in
      Task { @MainActor in
        self?.wasInterrupted = true
        self?.refreshShutterGate()
      }
    }
    resumedObs = NotificationCenter.default.addObserver(
      forName: .AVCaptureSessionInterruptionEnded,
      object: sessionController.session,
      queue: .main
    ) { [weak self] _ in
      Task { @MainActor in
        self?.wasInterrupted = false
        self?.refreshShutterGate()
      }
    }
  }

  private func refreshShutterGate() {
    if let fatalConfigError {
      shutterEnabled = false
      readinessText = "Error: \(fatalConfigError)"
      return
    }
    if wasInterrupted {
      shutterEnabled = false
      readinessText = "Interrupted"
      return
    }
    let ready = sessionRunning && previewAttached && warmUpElapsed
    shutterEnabled = ready
    if ready {
      readinessText = "Ready"
    } else if !sessionRunning {
      readinessText = "Starting Camera"
    } else if !previewAttached {
      readinessText = "Starting Camera"
    } else {
      readinessText = "Adjusting"
    }
  }
}

extension InteractiveStillCaptureController: AVCapturePhotoCaptureDelegate {
  public nonisolated func photoOutput(
    _ output: AVCapturePhotoOutput,
    didFinishProcessingPhoto photo: AVCapturePhoto,
    error: Error?
  ) {
    Task { @MainActor in
      self.handlePhoto(photo, error: error)
    }
  }

  private func handlePhoto(_ photo: AVCapturePhoto, error: Error?) {
    if let error {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "capture_failure",
        detail: String(describing: error)
      )
      continuation?.resume(throwing: Phase1RuntimeError.photoCaptureFailed(error.localizedDescription))
      continuation = nil
      return
    }
    guard let data = photo.fileDataRepresentation() else {
      continuation?.resume(throwing: Phase1RuntimeError.fileRepresentationUnavailable)
      continuation = nil
      return
    }
    do {
      // Freeze bytes + SHA-256 **before** any review UI decode.
      let pending = try PendingStillCapture.freezeFromDelegateBytes(data)
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "fileDataRepresentation_ok",
        detail: "byteCount=\(data.count) sha256=\(pending.sha256) note=JPEG bytes not logged"
      )
      continuation?.resume(returning: pending)
    } catch {
      continuation?.resume(throwing: error)
    }
    continuation = nil
  }
}

/// One-shot still capture for unit tests / legacy coordinator path.
public final class StillPhotoCaptureService: NSObject, StillPhotoCaptureProviding, @unchecked Sendable {
  private let auth: CameraAuthorizationService
  private let controller: CameraSessionController
  private let photoOutput = AVCapturePhotoOutput()
  private var continuation: CheckedContinuation<Data, Error>?

  public init(
    auth: CameraAuthorizationService = CameraAuthorizationService(),
    controller: CameraSessionController = CameraSessionController()
  ) {
    self.auth = auth
    self.controller = controller
    super.init()
  }

  public func captureProcessedJPEG() async throws -> Data {
    try await auth.requestAccessIfNeeded()
    try controller.configureForStillCapture()
    if controller.session.canAddOutput(photoOutput) {
      controller.session.addOutput(photoOutput)
    } else if !controller.session.outputs.contains(where: { $0 === photoOutput }) {
      throw Phase1RuntimeError.cameraConfigurationFailed("cannot add photo output")
    }
    if #available(iOS 16.0, *) {
      photoOutput.maxPhotoQualityPrioritization = .quality
    }
    controller.start()
    try await Task.sleep(nanoseconds: 250_000_000)

    return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Data, Error>) in
      self.continuation = cont
      let settings = AVCapturePhotoSettings()
      if photoOutput.availablePhotoCodecTypes.contains(.jpeg) {
        let s = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
        self.photoOutput.capturePhoto(with: s, delegate: self)
      } else {
        self.photoOutput.capturePhoto(with: settings, delegate: self)
      }
    }
  }
}

extension StillPhotoCaptureService: AVCapturePhotoCaptureDelegate {
  public func photoOutput(
    _ output: AVCapturePhotoOutput,
    didFinishProcessingPhoto photo: AVCapturePhoto,
    error: Error?
  ) {
    if let error {
      continuation?.resume(throwing: Phase1RuntimeError.photoCaptureFailed(error.localizedDescription))
      continuation = nil
      controller.stop()
      return
    }
    if let data = photo.fileDataRepresentation() {
      continuation?.resume(returning: data)
    } else {
      continuation?.resume(throwing: Phase1RuntimeError.fileRepresentationUnavailable)
    }
    continuation = nil
    controller.stop()
  }
}
#endif
