#if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
import AVFoundation
import SwiftUI
import UIKit

/// Full-bleed live preview bound to an `AVCaptureSession`.
/// Public: consumed by the Phase1StillCapture app target across the package boundary.
public struct CameraPreviewView: UIViewRepresentable {
  public let session: AVCaptureSession

  public init(session: AVCaptureSession) {
    self.session = session
  }

  public func makeUIView(context: Context) -> PreviewUIView {
    let view = PreviewUIView()
    view.previewLayer.session = session
    view.previewLayer.videoGravity = .resizeAspectFill
    return view
  }

  public func updateUIView(_ uiView: PreviewUIView, context: Context) {
    if uiView.previewLayer.session !== session {
      uiView.previewLayer.session = session
    }
  }

  public final class PreviewUIView: UIView {
    public override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }

    public var previewLayer: AVCaptureVideoPreviewLayer {
      layer as! AVCaptureVideoPreviewLayer
    }

    public override init(frame: CGRect) {
      super.init(frame: frame)
    }

    @available(*, unavailable)
    public required init?(coder: NSCoder) {
      fatalError("init(coder:) has not been implemented")
    }
  }
}
#endif
