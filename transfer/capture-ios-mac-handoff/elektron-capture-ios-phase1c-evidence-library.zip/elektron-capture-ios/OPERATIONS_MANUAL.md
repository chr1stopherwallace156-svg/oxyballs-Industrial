# OPERATIONS_MANUAL.md — intent-based runbook

Start here when you know **what you want**, not which tool to invoke.

Always:

```bash
cd "<path-to-elektron-capture-ios>"
make help
make doctor
```

---

## I want to open the correct project

```bash
make doctor
make open
```

Open **`Phase1StillCapture.xcworkspace`** at the **repository root**.  
Do **not** open `Phase1StillCapture.xcodeproj` alone as the primary workflow.

If unsure which folder is current: `make repo-locator`

---

## I want to build

Package only:

```bash
make build
```

App (Mac):

```bash
make xcode-build
```

Remember: package build ≠ app build.

---

## I want to test

```bash
make test
```

Simulator (Mac, not physical device):

```bash
make simulator-test
```

---

## I want to run on my iPhone

```bash
make device-preflight
```

If PASS, open Xcode (`make open`), select your iPhone, press **⌘R**.  
`device-preflight` / `device-build` do **not** claim the app ran.

Then record evidence:

```bash
make record-device-validation
```

---

## I want to inspect an .edts-pkg

```bash
make package-check PKG="/path/to/EVD-….edts-pkg"
```

Or see `./Scripts/help.sh package`.

---

## I received a new ZIP

```bash
cd "$HOME/Downloads"
shasum -a 256 DOWNLOAD-….zip
unzip DOWNLOAD-….zip
cd elektron-capture-ios
make doctor
make verify-handoff
```

Compare SHA to Industrial handoff `SHA256SUMS.txt`. Discard superseded ZIPs.

---

## Xcode cannot find a symbol

```bash
./Scripts/diagnose.sh "Cannot find CameraPreviewView in scope"
# or
./Scripts/diagnose.sh "Cannot find Phase1StillCaptureUIState in scope"
make doctor
```

---

## Xcode cannot find the package

```bash
./Scripts/diagnose.sh "Missing package product ElektronCapture"
make open
make repair-package-cache
```

---

## Signing failed

```bash
./Scripts/diagnose.sh "signing requires a development team"
```

Fix Team in Xcode Signing & Capabilities. Do not commit secrets.

---

## The app built but did not launch

```bash
./Scripts/diagnose.sh "-10814"
make device-preflight
```

Use ⌘R with a connected unlocked iPhone; Trust computer; Developer Mode if required.

---

## Export failed / Share or Files failed

```bash
./Scripts/diagnose.sh "share sheet"
./Scripts/diagnose.sh "3328"
make export-help
```

Prefer Share `.edts-pkg` or Save to Files; try diagnostic ZIP copy. Never re-encode the JPEG.

---

## I have several repository copies

```bash
make repo-locator
```

Work only in **CURRENT**. Do not auto-delete others.

---

## I want evidence for handoff

```bash
make verify-handoff
make evidence-status
ls Docs/Evidence/Runs
```

Manual runtime still requires `make record-device-validation`.

---

## Safe cleanup only

```bash
make repair-derived-data
make repair-xcode-cache
make clean
```

Each prints paths and requires confirmation. Never deletes source, git history, or user Documents.
