#!/usr/bin/env bash
# Searchable known-error diagnostic engine (display + suggested checks only).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DICT="$ROOT/Docs/ERROR_DICTIONARY.md"
QUERY="${*:-}"

if [[ -z "$QUERY" ]]; then
  echo "Usage: ./Scripts/diagnose.sh \"<error text or keyword>\"" >&2
  echo "Dictionary: Docs/ERROR_DICTIONARY.md" >&2
  exit 1
fi

# Normalize: lowercase + strip spaces/punctuation noise for robust matching
Q="$(printf '%s' "$QUERY" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')"

emit() {
  local title="$1"
  local class="${2:-}"
  echo "ERROR CLASS: ${class:-SEE_DICTIONARY}"
  echo "ERROR CLASS MATCH: $title"
  echo
  awk -v title="$title" '
    $0 == "## " title {p=1; print; next}
    p && /^## / {exit}
    p {print}
  ' "$DICT"
  echo
  echo "Safe next steps:"
  echo "  make doctor"
  echo "  make repo-locator"
  echo "  make verify"
  echo "See also: OPERATIONS_MANUAL.md"
}

case "$Q" in
  *camerapreviewview*)
    emit "Cannot find CameraPreviewView in scope" "CROSS-MODULE VISIBILITY OR PACKAGE LINKAGE"
    ;;
  *phase1stillcaptureuistate*|*pendingstillcapture*|*approvedstillcapture*|*interactivestillcapturecontroller*)
    emit "Cannot find Phase1StillCaptureUIState / PendingStillCapture / ApprovedStillCapture / InteractiveStillCaptureController in scope" "MISSING_MODULE_IMPORT"
    ;;
  *missingpackageproduct*|*packageproduct*|*missing*elektroncapture*)
    emit "Missing package product 'ElektronCapture'" "PACKAGE_PRODUCT_RESOLUTION"
    ;;
  *alreadyopened*|*anotherworkspace*|*anotherproject*)
    emit "package already opened from another project or workspace / project already open" "DUPLICATE_XCODE_SESSION"
    ;;
  *toolhosted*|*testingunavailable*)
    emit "tool-hosted testing unavailable / cannot run tests on physical device destination" "DEVICE_TEST_DESTINATION_UNSUPPORTED"
    ;;
  *developmentteam*|*signingfor*|*noaccountforteam*|*signing*team*)
    emit "Signing for requires a development team / No Account for Team" "SIGNING_TEAM_MISSING"
    ;;
  *codesign*|*keychain*|*userinteractionisnotallowed*)
    emit "codesign / keychain permission / User interaction is not allowed" "CODESIGN_KEYCHAIN_PERMISSION"
    ;;
  *nosuchfile*|*foldernotfound*)
    emit "No such file or directory / folder not found" "PATH_NOT_FOUND"
    ;;
  *notagitrepository*)
    emit "not a git repository" "NO_GIT_METADATA"
    ;;
  *packagecache*|*resolvedpackage*|*stalepackage*)
    emit "Stale package cache / Resolved package versions out of date" "STALE_PACKAGE_CACHE"
    ;;
  *duplicate*|*severalrepositor*|*multiplecop*)
    emit "Duplicate repository copies / confusion which tree is open" "DUPLICATE_REPO_COPIES"
    ;;
  *10814*|*launchservices*)
    emit "LaunchServices error -10814" "LAUNCH_SERVICES_OPEN_FAILURE"
    ;;
  *3328*|*nscocoaerrordomain*|*fileprovider*)
    emit "NSCocoaErrorDomain Code=3328 / file provider / Files save failure" "FILES_PROVIDER_EXPORT_FAILURE"
    ;;
  *sharesheet*|*airdrop*|*exportpresentation*|*customuti*)
    emit "Share sheet / AirDrop / custom UTI presentation failure" "SHARE_PRESENTATION"
    ;;
  *sha256*|*zipmissing*|*wrongsha*)
    emit "ZIP missing / wrong SHA-256" "HANDOFF_ARTIFACT_MISMATCH"
    ;;
  *elektroncapture*)
    emit "Missing package product 'ElektronCapture'" "PACKAGE_PRODUCT_RESOLUTION"
    ;;
  *notfound*)
    emit "No such file or directory / folder not found" "PATH_NOT_FOUND"
    ;;
  *share*)
    emit "Share sheet / AirDrop / custom UTI presentation failure" "SHARE_PRESENTATION"
    ;;
  *stale*)
    emit "Stale package cache / Resolved package versions out of date" "STALE_PACKAGE_CACHE"
    ;;
  *)
    echo "No exact dictionary match for: $QUERY"
    echo "Try keywords: CameraPreviewView, ElektronCapture, signing, -10814, 3328, duplicate, share"
    echo "Full dictionary: $DICT"
    exit 1
    ;;
esac
