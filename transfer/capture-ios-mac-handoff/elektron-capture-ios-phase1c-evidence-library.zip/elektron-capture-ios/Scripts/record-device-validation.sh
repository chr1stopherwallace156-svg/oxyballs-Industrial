#!/usr/bin/env bash
# record-device-validation.sh — interactive manual evidence. Never auto-marks PHASE_APPROVED.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ops-lib.sh
source "${SCRIPT_DIR}/ops-lib.sh"
ops_require_root

RUN_DIR="$(ops_begin_evidence "device-validation")"
ANSWERS_FILE="${RUN_DIR}/device-validation-answers.txt"
MANIFEST="${RUN_DIR}/manual-checklist.md"

ask_yn() {
  local prompt="$1"
  local key="$2"
  local ans=""
  while true; do
    read -r -p "${prompt} [y/n]: " ans || true
    case "${ans}" in
      y|Y|yes|YES) echo "${key}=yes" >>"${ANSWERS_FILE}"; return 0 ;;
      n|N|no|NO) echo "${key}=no" >>"${ANSWERS_FILE}"; return 1 ;;
      *) echo "Please answer y or n." ;;
    esac
  done
}

ask_note() {
  local prompt="$1"
  local key="$2"
  local note=""
  read -r -p "${prompt}: " note || true
  echo "${key}=${note}" >>"${ANSWERS_FILE}"
}

{
  echo "# Manual device validation"
  echo "Recorded: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "Repository: ${OPS_ROOT}"
  echo ""
  echo "This recorder NEVER sets PHASE_APPROVED automatically."
  echo "Automated scripts must not claim these results."
} | tee "${MANIFEST}"

: >"${ANSWERS_FILE}"
cp "${OPS_ROOT}/.repository-identity.json" "${RUN_DIR}/repository-identity.json"
ops_git_state >"${RUN_DIR}/git-state.txt"
pwd >"${RUN_DIR}/repository-path.txt"

YES_COUNT=0
NO_COUNT=0
bump() { if [[ $1 -eq 0 ]]; then YES_COUNT=$((YES_COUNT + 1)); else NO_COUNT=$((NO_COUNT + 1)); fi; }

echo ""
echo "Answer honestly based on physical iPhone observation."
echo ""

ask_yn "Did the app launch?" "app_launched"; bump $?
ask_yn "Did camera preview appear?" "camera_preview_visible"; bump $?
ask_yn "Was a real photo captured (not placeholder)?" "real_photo_captured"; bump $?
ask_yn "Was the photo visible on the review screen?" "photo_displayed"; bump $?
ask_yn "Did approval complete (Use Photo)?" "approval_completed"; bump $?
ask_yn "Was a frozen artifact hash shown?" "frozen_hash_shown"; bump $?
ask_yn "Was an .edts-pkg created?" "edts_pkg_created"; bump $?
ask_yn "Did the Share sheet open?" "share_sheet_opened"; bump $?
ask_yn "Did Save to Files succeed?" "save_to_files_succeeded"; bump $?
ask_yn "Does the exported file exist and is non-empty?" "exported_file_nonempty"; bump $?
ask_yn "Is the original JPEG recoverable from the package?" "jpeg_recoverable"; bump $?

echo ""
ask_note "Path or note for exported .edts-pkg (required if export claimed)" "evidence_pkg_path"
ask_note "Path or note for screenshot / Files app proof" "evidence_screenshot_note"
ask_note "Any anomalies" "anomalies"

# Copy optional evidence if path exists and is a file under home or repo
PKG_LINE="$(grep '^evidence_pkg_path=' "${ANSWERS_FILE}" | sed 's/^evidence_pkg_path=//' || true)"
if [[ -n "${PKG_LINE}" && -f "${PKG_LINE}" ]]; then
  case "${PKG_LINE}" in
    "${HOME}"/*|"${OPS_ROOT}"/*|/tmp/*)
      cp "${PKG_LINE}" "${RUN_DIR}/exported-package.edts-pkg" || true
      echo "Copied package bytes into evidence run (read-only copy)."
      ;;
    *)
      echo "WARN: package path not under HOME/repo/tmp — not copied (path recorded only)."
      ;;
  esac
fi

{
  echo ""
  echo "## Summary"
  echo "- yes answers: ${YES_COUNT}"
  echo "- no answers: ${NO_COUNT}"
  echo "- PHASE_APPROVED: NOT SET by this script"
  echo "- Recommended next: human review of answers + package-check if .edts-pkg available"
} | tee -a "${MANIFEST}"

# Recommend status transitions — never PHASE_APPROVED
RECS=()
grep -q 'app_launched=yes' "${ANSWERS_FILE}" && RECS+=("DEVICE_APP_LAUNCHED")
grep -q 'camera_preview_visible=yes' "${ANSWERS_FILE}" && RECS+=("CAMERA_CAPTURE_VERIFIED")
grep -q 'approval_completed=yes' "${ANSWERS_FILE}" && RECS+=("PHOTO_APPROVAL_VERIFIED")
grep -q 'edts_pkg_created=yes' "${ANSWERS_FILE}" && RECS+=("PACKAGE_CREATED")
grep -q 'share_sheet_opened=yes' "${ANSWERS_FILE}" && RECS+=("SHARE_SHEET_VERIFIED")
grep -q 'save_to_files_succeeded=yes' "${ANSWERS_FILE}" && RECS+=("FILES_EXPORT_VERIFIED")
grep -q 'jpeg_recoverable=yes' "${ANSWERS_FILE}" && RECS+=("PACKAGE_CONTENTS_VERIFIED")

REC_JOINED="$(IFS=,; echo "${RECS[*]}")"
ops_write_result_json "${RUN_DIR}" "recorded" "device-validation" \
  "Manual recommendations only: ${REC_JOINED}. PHASE_APPROVED requires explicit human gate."

# Update status.json recommendations without setting PHASE_APPROVED
STATUS_FILE="${OPS_ROOT}/Docs/Verification/status.json"
if [[ -f "${STATUS_FILE}" ]] && command -v python3 >/dev/null 2>&1; then
  python3 - "${STATUS_FILE}" "${ANSWERS_FILE}" <<'PY'
import json, sys, datetime
status_path, answers_path = sys.argv[1], sys.argv[2]
with open(status_path) as f:
    data = json.load(f)
answers = {}
with open(answers_path) as f:
    for line in f:
        line=line.strip()
        if "=" in line:
            k,v=line.split("=",1)
            answers[k]=v
mapping = [
    ("app_launched", "DEVICE_APP_LAUNCHED"),
    ("camera_preview_visible", "CAMERA_CAPTURE_VERIFIED"),
    ("approval_completed", "PHOTO_APPROVAL_VERIFIED"),
    ("edts_pkg_created", "PACKAGE_CREATED"),
    ("share_sheet_opened", "SHARE_SHEET_VERIFIED"),
    ("save_to_files_succeeded", "FILES_EXPORT_VERIFIED"),
    ("jpeg_recoverable", "PACKAGE_CONTENTS_VERIFIED"),
]
states = data.setdefault("states", {})
now = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
for key, state in mapping:
    if answers.get(key) == "yes":
        entry = states.setdefault(state, {})
        # Never auto-approve phase; only record manual claim source
        if entry.get("status") != "pass":
            entry["status"] = "manual_pass"
            entry["source"] = "record-device-validation"
            entry["updated"] = now
# Explicitly refuse PHASE_APPROVED
pa = states.setdefault("PHASE_APPROVED", {})
if pa.get("status") == "pass" and pa.get("source") == "record-device-validation":
    pa["status"] = "blocked"
pa.setdefault("status", "blocked")
pa["note"] = "Requires explicit human PHASE_APPROVED gate — not set by recorder"
pa["updated"] = now
data["last_device_validation"] = {"at": now, "answers_file": answers_path}
with open(status_path, "w") as f:
    json.dump(data, f, indent=2)
    f.write("\n")
print("Updated Docs/Verification/status.json (PHASE_APPROVED not granted)")
PY
fi

echo ""
echo "Evidence written: ${RUN_DIR}"
echo "PHASE_APPROVED: NOT SET"
exit 0
