#!/usr/bin/env bash
# evidence-status.sh — summarize verification status + recent evidence runs
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ops-lib.sh
source "${SCRIPT_DIR}/ops-lib.sh"
ops_require_root

STATUS_FILE="${OPS_ROOT}/Docs/Verification/status.json"
EVIDENCE_ROOT="${OPS_ROOT}/Docs/Evidence/Runs"

echo "=== Repository identity ==="
if [[ -f "${OPS_ROOT}/.repository-identity.json" ]]; then
  cat "${OPS_ROOT}/.repository-identity.json"
else
  echo "MISSING .repository-identity.json"
fi
echo ""

echo "=== Verification states ==="
if [[ -f "${STATUS_FILE}" ]]; then
  if command -v python3 >/dev/null 2>&1; then
    python3 - "${STATUS_FILE}" <<'PY'
import json, sys
with open(sys.argv[1]) as f:
    data = json.load(f)
states = data.get("states", data)
order = [
    "SOURCE_PRESENT","PACKAGE_BUILDS","TESTS_PASS","XCODE_APP_BUILDS",
    "DEVICE_SIGNING_READY","DEVICE_APP_LAUNCHED","CAMERA_CAPTURE_VERIFIED",
    "PHOTO_APPROVAL_VERIFIED","PACKAGE_CREATED","SHARE_SHEET_VERIFIED",
    "FILES_EXPORT_VERIFIED","PACKAGE_CONTENTS_VERIFIED","PHASE_APPROVED",
]
if isinstance(states, dict) and any(k in states for k in order):
    for k in order:
        v = states.get(k, {})
        if isinstance(v, dict):
            st = v.get("status", v.get("state", "?"))
            src = v.get("source", "")
            print(f"  {k}: {st}" + (f" ({src})" if src else ""))
        else:
            print(f"  {k}: {v}")
else:
    print(json.dumps(data, indent=2))
PY
  else
    cat "${STATUS_FILE}"
  fi
else
  echo "MISSING ${STATUS_FILE}"
fi
echo ""

echo "=== Recent evidence runs (newest first, max 10) ==="
if [[ -d "${EVIDENCE_ROOT}" ]]; then
  # shellcheck disable=SC2012
  ls -1dt "${EVIDENCE_ROOT}"/*/ 2>/dev/null | head -n 10 | while read -r d; do
    name="$(basename "${d}")"
    res="${d}result.json"
    if [[ -f "${res}" ]]; then
      echo "  ${name}: $(tr '\n' ' ' <"${res}" | head -c 200)"
    else
      echo "  ${name}: (no result.json)"
    fi
  done
else
  echo "  (no evidence runs yet)"
fi
echo ""
echo "Manual physical-device states require make record-device-validation"
echo "PHASE_APPROVED is never set by automation."
