#!/usr/bin/env bash
# open-workspace.sh — open ONLY the root Phase1StillCapture.xcworkspace
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ops-lib.sh
source "${SCRIPT_DIR}/ops-lib.sh"
ops_require_root

WS="${OPS_ROOT}/Phase1StillCapture.xcworkspace"
if [[ ! -d "${WS}" ]]; then
  echo "FAIL: workspace missing: ${WS}"
  exit 1
fi

echo "Opening root workspace (NOT the nested .xcodeproj alone):"
echo "  ${WS}"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "open is macOS-only. On Mac run: open \"${WS}\""
  echo "Or: make open"
  exit 0
fi

open "${WS}"
echo "Opened. Confirm Xcode window title shows Phase1StillCapture.xcworkspace"
echo "Do NOT open Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj by itself."
