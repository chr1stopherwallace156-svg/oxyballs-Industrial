#!/usr/bin/env bash
# Interactive / topic help for elektron-capture-ios.
# Display-only: never deletes files, never builds unless you copy a command yourself.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

topic="${1:-}"

print_menu() {
  cat <<'EOF'
elektron-capture-ios — command help
===================================
Repo root should contain Package.swift and Phase1StillCapture.xcworkspace.

Layered flow:
  HELP → DOCTOR → PREFLIGHT → ACTION → EVIDENCE → STATUS → SAFE RECOVERY

Quick start:
  make help
  make doctor
  make verify-handoff
  make open                 # Mac: root Phase1StillCapture.xcworkspace ONLY

Ops / guardrails:
  make doctor               # read-only environment inspection
  make device-preflight     # ready for ⌘R? (never claims app ran)
  make repo-locator         # find duplicate copies
  make diagnose MSG="..."   # known-error dictionary lookup
  make evidence-status      # verification state + recent runs
  make record-device-validation
  make package-check PKG=/path/to/file.edts-pkg
  make repair-derived-data  # confirmed, path-guarded
  make repair-package-cache
  make ops-system-check

Topics (display only):
  ./Scripts/help.sh build
  ./Scripts/help.sh test
  ./Scripts/help.sh xcode
  ./Scripts/help.sh device
  ./Scripts/help.sh export
  ./Scripts/help.sh package
  ./Scripts/help.sh troubleshoot

Full dictionary: HELP.md
Intent runbook: OPERATIONS_MANUAL.md
Error dictionary: Docs/ERROR_DICTIONARY.md
States: Docs/VERIFICATION_STATES.md

Open the correct app entry point:
  open Phase1StillCapture.xcworkspace
Do NOT open Phase1StillCapture.xcodeproj alone as the primary workflow.
EOF
}

print_build() {
  cat <<'EOF'
[build] Swift package compilation (NOT the Xcode app)

Where: repository root (folder with Package.swift)

  swift build
  make build

Expected:
  Build complete!

Notes:
  - Compiles ElektronCapture only.
  - Does not compile Apps/Phase1StillCapture/*.swift.
  - Green swift build ≠ green Xcode app.

See also: HELP.md §3, ./Scripts/help.sh xcode
EOF
}

print_test() {
  cat <<'EOF'
[test] Swift package tests

Where: repository root

  swift test
  make test
  swift test --filter GoldenEvidencePackageTests

Expected:
  Test Suite 'All tests' passed
  (Linux may report 1 documented skip)

Simulator / Xcode tests (Mac only):
  make simulator-test

Do not use simulator-test against a physical iPhone destination.
EOF
}

print_xcode() {
  cat <<'EOF'
[xcode] App workspace build (Mac)

Where: repository root

Open (preferred):
  open Phase1StillCapture.xcworkspace
  make open

Clean app build:
  xcodebuild -workspace Phase1StillCapture.xcworkspace \
    -scheme Phase1StillCapture \
    -destination 'generic/platform=iOS' \
    clean build
  make xcode-build

Linkage excerpt:
  xcodebuild -workspace Phase1StillCapture.xcworkspace \
    -scheme Phase1StillCapture -showBuildSettings \
    | grep -E 'ElektronCapture|PACKAGE|FRAMEWORK_SEARCH|LIBRARY_SEARCH|SWIFT_INCLUDE'

Handoff verifier (layout + on Mac xcodebuild):
  ./Scripts/verify-xcode-handoff.sh
  make verify

UI:
  ⌘B build only | ⌘R run on device | ⌘U tests (prefer simulator)

Do NOT open the .xcodeproj alone as the primary workflow.
EOF
}

print_device() {
  cat <<'EOF'
[device] Physical iPhone — preflight vs run

Readiness (does NOT claim the app ran):
  make doctor
  make device-preflight

Compile/sign for device (does NOT prove capture runtime):
  make device-build

Install + run on a connected iPhone:
  - make open  (Phase1StillCapture.xcworkspace)
  - Select your iPhone as destination
  - Press ⌘R in Xcode
  - Fix Signing & Capabilities → Team if needed

Then record manual evidence (never auto PHASE_APPROVED):
  make record-device-validation

Acceptance capture is a runtime workflow (preview → Take Photo →
Retake/Use Photo → Export → Share/Save .edts-pkg), not device-build alone.
EOF
}

print_export() {
  cat <<'EOF'
[export] In-app export / share (physical device)

After PACKAGE_EXPORTED in the app:
  1. Share .edts-pkg  (Share Sheet / AirDrop)
  2. Save .edts-pkg to Files
  3. Export as ZIP copy  (diagnostic; same bytes, .zip extension)

On Mac, locate packages:
  find "$HOME/Downloads" -name "*.edts-pkg" -print

Then see: ./Scripts/help.sh package
EOF
}

print_package() {
  cat <<'EOF'
[package] Inspect an .edts-pkg (ZIP transport)

Quote paths (spaces are common):

  unzip -l "<package>.edts-pkg"
  unzip -p "<package>.edts-pkg" manifest.json
  unzip -p "<package>.edts-pkg" package_inventory.json
  unzip -p "<package>.edts-pkg" payload/artifact_original.jpg > artifact_original.jpg
  shasum -a 256 "<package>.edts-pkg"
  shasum -a 256 artifact_original.jpg

Phase 1 minimum usually includes:
  manifest.json, package_inventory.json, payload/artifact_original.jpg

Optional (only if listed by unzip -l):
  package_status.json
  sidecars/camera_calibration.json
  sidecars/avcapture_metadata.json

JPEG identity: artifact SHA must match the frozen post-delegate hash.
Do not re-encode via Preview before hashing.
EOF
}

print_troubleshoot() {
  cat <<'EOF'
[troubleshoot] Common failures

First:
  make doctor
  ./Scripts/diagnose.sh "<paste error text>"
  make repo-locator

Cannot find Phase1StillCaptureUIState / PendingStillCapture / … in scope
  → Add: import ElektronCapture
  → in that Apps/Phase1StillCapture/*.swift file

Cannot find CameraPreviewView in scope
  → Package type must be: public struct CameraPreviewView
  → Re-download tip that includes the public access fix

Missing package product 'ElektronCapture'
  → open Phase1StillCapture.xcworkspace (root)
  → File → Packages → Reset Package Caches → Resolve
  → make repair-package-cache  (confirmed, path-guarded)

swift build OK but Xcode fails
  → Expected class of bug: SPM ≠ app target
  → Run make xcode-build / verify on Mac

xcodebuild not found (Linux)
  → Use a Mac for app/device gates

Signing errors
  → Xcode → Settings → Accounts → Apple ID
  → Target → Signing & Capabilities → Team

Wrong folder / spaces in path / duplicate copies
  → make repo-locator
  → pwd
  → cd "<full path with spaces quoted>"

Full dictionary: HELP.md
Error classes: Docs/ERROR_DICTIONARY.md
Intent runbook: OPERATIONS_MANUAL.md
EOF
}

case "$topic" in
  "") print_menu ;;
  build) print_build ;;
  test) print_test ;;
  xcode) print_xcode ;;
  device) print_device ;;
  export) print_export ;;
  package) print_package ;;
  troubleshoot) print_troubleshoot ;;
  -h|--help|help)
    print_menu
    ;;
  *)
    echo "Unknown topic: $topic" >&2
    echo "Try: ./Scripts/help.sh" >&2
    exit 1
    ;;
esac
