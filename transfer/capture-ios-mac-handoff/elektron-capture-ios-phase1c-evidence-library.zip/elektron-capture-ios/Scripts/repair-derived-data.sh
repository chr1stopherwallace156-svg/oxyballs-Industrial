#!/usr/bin/env bash
# repair-derived-data.sh — remove ONLY repository-specific DerivedData with confirmation.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ops-lib.sh
source "${SCRIPT_DIR}/ops-lib.sh"
ops_require_root

FORCE=0
[[ "${1:-}" == "--yes" ]] && FORCE=1

DD_ROOT="${HOME}/Library/Developer/Xcode/DerivedData"
if [[ ! -d "${DD_ROOT}" ]]; then
  echo "DerivedData root not found: ${DD_ROOT}"
  echo "Nothing to repair (common on Linux CI)."
  exit 0
fi

# Match folders that look related to this project name
mapfile -t CANDIDATES < <(find "${DD_ROOT}" -maxdepth 1 -type d \( -name 'Phase1StillCapture-*' -o -name 'elektron-capture-ios-*' \) 2>/dev/null || true)

if [[ ${#CANDIDATES[@]} -eq 0 ]]; then
  echo "No Phase1StillCapture-* / elektron-capture-ios-* DerivedData folders found."
  exit 0
fi

echo "=== SAFE REPAIR: DerivedData (repository-specific) ==="
echo "Will remove ONLY these folders:"
for c in "${CANDIDATES[@]}"; do
  echo "  ${c}"
done
echo ""
echo "Will NOT touch: source, Git, Docs/Evidence, Downloads, home root, or unrelated DerivedData."
echo ""

if [[ "${FORCE}" -ne 1 ]]; then
  read -r -p "Type DELETE to confirm: " CONFIRM
  if [[ "${CONFIRM}" != "DELETE" ]]; then
    echo "Aborted."
    exit 1
  fi
fi

for c in "${CANDIDATES[@]}"; do
  ops_assert_safe_delete_path "${c}"
  # Extra: must be under DerivedData
  case "${c}" in
    "${DD_ROOT}"/*) ;;
    *) echo "REFUSING: not under DerivedData: ${c}"; exit 2 ;;
  esac
  echo "Removing: ${c}"
  rm -rf "${c}"
done

echo "DerivedData repair complete. Next: make open && Product → Clean Build Folder → Build"
exit 0
