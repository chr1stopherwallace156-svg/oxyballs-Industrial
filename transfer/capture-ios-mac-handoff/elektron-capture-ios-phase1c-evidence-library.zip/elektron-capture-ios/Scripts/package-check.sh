#!/usr/bin/env bash
# package-check.sh — inspect .edts-pkg without modifying package bytes.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ops-lib.sh
source "${SCRIPT_DIR}/ops-lib.sh"
ops_require_root

PKG="${1:-${PKG:-}}"
if [[ -z "${PKG}" ]]; then
  echo "Usage: make package-check PKG=/path/to/file.edts-pkg"
  echo "   or: ./Scripts/package-check.sh /path/to/file.edts-pkg"
  exit 2
fi
if [[ ! -f "${PKG}" ]]; then
  echo "FAIL: package file not found: ${PKG}"
  exit 1
fi

RUN_DIR="$(ops_begin_evidence "package-check")"
cp "${OPS_ROOT}/.repository-identity.json" "${RUN_DIR}/repository-identity.json"
pwd >"${RUN_DIR}/repository-path.txt"
echo "package=${PKG}" >"${RUN_DIR}/package-path.txt"

# Hash package (read-only)
if command -v shasum >/dev/null 2>&1; then
  PKG_HASH="$(shasum -a 256 "${PKG}" | awk '{print $1}')"
elif command -v sha256sum >/dev/null 2>&1; then
  PKG_HASH="$(sha256sum "${PKG}" | awk '{print $1}')"
else
  PKG_HASH="unavailable"
fi
echo "package_sha256=${PKG_HASH}" | tee "${RUN_DIR}/package-hash.txt"
echo "package_bytes=$(wc -c <"${PKG}" | tr -d ' ')" | tee -a "${RUN_DIR}/package-hash.txt"

# ZIP integrity (test only)
set +e
unzip -t "${PKG}" >"${RUN_DIR}/zip-test.log" 2>&1
ZIP_RC=$?
set -e
if [[ "${ZIP_RC}" -eq 0 ]]; then
  echo "ZIP integrity: PASS"
else
  echo "ZIP integrity: FAIL (see zip-test.log)"
fi

# List entries
unzip -l "${PKG}" >"${RUN_DIR}/zip-list.txt" 2>&1 || true
echo "--- Package entries ---"
cat "${RUN_DIR}/zip-list.txt"

# Extract to temp for inspection only — never write back into package
EXTRACT_DIR="${RUN_DIR}/extract"
mkdir -p "${EXTRACT_DIR}"
set +e
unzip -q "${PKG}" -d "${EXTRACT_DIR}"
EXT_RC=$?
set -e

REQUIRED_HINTS=("manifest" "inventory" "status" "original" ".jpg" "jpeg")
echo "" | tee "${RUN_DIR}/package-inspection.txt"
echo "=== Inspection (extracted copy; original package untouched) ===" | tee -a "${RUN_DIR}/package-inspection.txt"

if [[ "${EXT_RC}" -ne 0 ]]; then
  echo "FAIL: could not extract for inspection" | tee -a "${RUN_DIR}/package-inspection.txt"
  ops_write_result_json "${RUN_DIR}" "fail" "package-check" "extract failed"
  exit 1
fi

# Find JSON-ish and JPEG
find "${EXTRACT_DIR}" -type f | sort | tee "${RUN_DIR}/extracted-files.txt"

MANIFEST="$(find "${EXTRACT_DIR}" -iname '*manifest*' -o -iname 'manifest.json' | head -n 1 || true)"
INVENTORY="$(find "${EXTRACT_DIR}" -iname '*inventory*' | head -n 1 || true)"
STATUS="$(find "${EXTRACT_DIR}" -iname '*status*' | head -n 1 || true)"
JPEG="$(find "${EXTRACT_DIR}" \( -iname '*.jpg' -o -iname '*.jpeg' \) | head -n 1 || true)"

for label in MANIFEST INVENTORY STATUS; do
  eval "p=\${${label}}"
  if [[ -n "${p}" && -f "${p}" ]]; then
    echo "${label}: present ($(basename "${p}"))" | tee -a "${RUN_DIR}/package-inspection.txt"
    # Copy small text artifacts into evidence
    cp "${p}" "${RUN_DIR}/artifact-$(basename "${p}")" 2>/dev/null || true
  else
    echo "${label}: NOT FOUND (may be optional or differently named)" | tee -a "${RUN_DIR}/package-inspection.txt"
  fi
done

if [[ -n "${JPEG}" && -f "${JPEG}" ]]; then
  if command -v shasum >/dev/null 2>&1; then
    JHASH="$(shasum -a 256 "${JPEG}" | awk '{print $1}')"
  elif command -v sha256sum >/dev/null 2>&1; then
    JHASH="$(sha256sum "${JPEG}" | awk '{print $1}')"
  else
    JHASH="unavailable"
  fi
  echo "ORIGINAL_JPEG: present" | tee -a "${RUN_DIR}/package-inspection.txt"
  echo "original_jpeg_sha256=${JHASH}" | tee -a "${RUN_DIR}/package-inspection.txt" | tee "${RUN_DIR}/original-jpeg-hash.txt"
  cp "${JPEG}" "${RUN_DIR}/original-extracted.jpg" 2>/dev/null || true
  echo "NOTE: extracted JPEG is an inspection copy; package bytes were not modified."
else
  echo "ORIGINAL_JPEG: NOT FOUND" | tee -a "${RUN_DIR}/package-inspection.txt"
fi

echo ""
echo "Required vs optional: treat missing contract files as FAIL for handoff;"
echo "extra files may be optional. Compare against Docs package contract if present."
echo "Package path unchanged: ${PKG}"
echo "Evidence: ${RUN_DIR}"

STATUS_OUT="pass"
[[ "${ZIP_RC}" -ne 0 ]] && STATUS_OUT="fail"
[[ -z "${JPEG}" ]] && STATUS_OUT="fail"

ops_write_result_json "${RUN_DIR}" "${STATUS_OUT}" "package-check" \
  "Inspection only; package bytes unmodified. sha256=${PKG_HASH}"

[[ "${STATUS_OUT}" == "pass" ]] && exit 0
exit 1
