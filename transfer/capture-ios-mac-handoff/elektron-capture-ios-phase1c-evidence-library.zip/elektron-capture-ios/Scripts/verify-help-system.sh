#!/usr/bin/env bash
# Verify the developer help system is present and consistent.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

echo "=== verify-help-system @ $ROOT ==="

[[ -f HELP.md ]] || fail "HELP.md missing"
pass "HELP.md exists"

[[ -f Makefile ]] || fail "Makefile missing"
pass "Makefile exists"

[[ -f Scripts/help.sh ]] || fail "Scripts/help.sh missing"
[[ -x Scripts/help.sh ]] || fail "Scripts/help.sh not executable"
pass "Scripts/help.sh exists and is executable"

[[ -f Scripts/verify-help-system.sh ]] || fail "Scripts/verify-help-system.sh missing"
[[ -x Scripts/verify-help-system.sh ]] || fail "Scripts/verify-help-system.sh not executable"
pass "Scripts/verify-help-system.sh executable"

[[ -f Scripts/verify-xcode-handoff.sh ]] || fail "Scripts/verify-xcode-handoff.sh missing"
[[ -x Scripts/verify-xcode-handoff.sh ]] || fail "Scripts/verify-xcode-handoff.sh not executable"
pass "Scripts/verify-xcode-handoff.sh present"

# Documented scripts that HELP / Makefile rely on
for s in \
  Scripts/help.sh \
  Scripts/verify-help-system.sh \
  Scripts/verify-xcode-handoff.sh \
  Scripts/validate-contracts \
  Scripts/verify-evidence-package
do
  [[ -e "$s" ]] || fail "documented script missing: $s"
done
pass "documented repository-relative scripts exist"

# help / make help exit 0
./Scripts/help.sh >/tmp/help-menu.out
pass "Scripts/help.sh exits 0"
./Scripts/help.sh build >/dev/null
./Scripts/help.sh test >/dev/null
./Scripts/help.sh xcode >/dev/null
./Scripts/help.sh device >/dev/null
./Scripts/help.sh export >/dev/null
./Scripts/help.sh package >/dev/null
./Scripts/help.sh troubleshoot >/dev/null
pass "Scripts/help.sh topics exit 0"

make -s help >/tmp/make-help.out
pass "make help exits 0"

# Default make target should be help (dry-run first recipe)
DEFAULT="$(make -n 2>/dev/null | head -1 || true)"
# Ensure .DEFAULT_GOAL or first goal is help via makefile content
grep -q '^\.DEFAULT_GOAL[[:space:]]*:=[[:space:]]*help' Makefile \
  || fail "Makefile .DEFAULT_GOAL is not help"
pass "Makefile default goal is help"

# Must recommend root workspace, not instruct opening .xcodeproj as primary
if grep -Eiq 'open[[:space:]]+Apps/Phase1StillCapture/Phase1StillCapture\.xcodeproj' HELP.md Scripts/help.sh Makefile README.md 2>/dev/null; then
  # Allow mentions that say DO NOT open xcodeproj
  if grep -En 'open[[:space:]]+Apps/Phase1StillCapture/Phase1StillCapture\.xcodeproj' HELP.md Scripts/help.sh Makefile README.md \
    | grep -Ev '[Dd]o [Nn][Oo][Tt]|not open|Do not open|DO NOT'; then
    fail "help text tells users to open the app .xcodeproj directly"
  fi
fi
grep -q 'Phase1StillCapture.xcworkspace' HELP.md || fail "HELP.md missing Phase1StillCapture.xcworkspace"
grep -q 'Phase1StillCapture.xcworkspace' Scripts/help.sh || fail "help.sh missing Phase1StillCapture.xcworkspace"
pass "help prefers Phase1StillCapture.xcworkspace"

# No obsolete folder references commonly wrong in this repo
for bad in 'Apps/Phase1StillCapture/Phase1Exports' 'Documents/Phase1Exports'; do
  if grep -R -n --include='HELP.md' --include='help.sh' --include='Makefile' -e "$bad" . 2>/dev/null | grep -q .; then
    # Phase1Exports may appear historically; flag only if presented as current path without CapturePackages
    :
  fi
done

# README quick-start pointers
grep -q 'make help' README.md || fail "README.md missing make help quick-start"
grep -q 'Phase1StillCapture.xcworkspace' README.md || fail "README.md missing workspace name"
pass "README.md quick-start present"

# Ensure workspace exists at repo root
[[ -d Phase1StillCapture.xcworkspace ]] || fail "root Phase1StillCapture.xcworkspace missing"
pass "root Phase1StillCapture.xcworkspace exists"

echo
echo "HELP_SYSTEM_OK"
