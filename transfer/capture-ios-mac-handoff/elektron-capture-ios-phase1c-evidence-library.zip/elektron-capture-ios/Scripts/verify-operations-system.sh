#!/usr/bin/env bash
# verify-operations-system.sh — meta-check that the ops guardrail system is intact.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ops-lib.sh
source "${SCRIPT_DIR}/ops-lib.sh"
ops_require_root

FAILS=0
pass() { echo "PASS: $*"; }
fail() { echo "FAIL: $*"; FAILS=$((FAILS + 1)); }
warn() { echo "WARN: $*"; }

REQUIRED_SCRIPTS=(
  ops-lib.sh
  doctor.sh
  diagnose.sh
  repo-locator.sh
  device-preflight.sh
  repair-derived-data.sh
  repair-package-cache.sh
  open-workspace.sh
  record-device-validation.sh
  package-check.sh
  evidence-status.sh
  verify-handoff.sh
  verify-operations-system.sh
  help.sh
  verify-help-system.sh
)

REQUIRED_DOCS=(
  OPERATIONS_MANUAL.md
  Docs/ERROR_DICTIONARY.md
  Docs/VERIFICATION_STATES.md
  Docs/Verification/status.json
  .repository-identity.json
  Makefile
  HELP.md
)

echo "=== Operations system integrity ==="

for s in "${REQUIRED_SCRIPTS[@]}"; do
  p="${OPS_ROOT}/Scripts/${s}"
  if [[ ! -f "${p}" ]]; then
    fail "missing script ${s}"
    continue
  fi
  if [[ ! -x "${p}" ]]; then
    fail "not executable: Scripts/${s}"
  else
    pass "executable Scripts/${s}"
  fi
done

for d in "${REQUIRED_DOCS[@]}"; do
  if [[ -f "${OPS_ROOT}/${d}" ]]; then
    pass "present ${d}"
  else
    fail "missing ${d}"
  fi
done

# Makefile targets
MAKEFILE="${OPS_ROOT}/Makefile"
for t in help doctor verify verify-handoff open build test xcode-build device-preflight package-check repo-locator troubleshoot evidence-status record-device-validation repair-derived-data repair-package-cache; do
  if grep -qE "^${t}:" "${MAKEFILE}" || grep -qE "^\\.PHONY:.*\\b${t}\\b" "${MAKEFILE}"; then
    # Prefer actual recipe
    if grep -qE "^${t}:" "${MAKEFILE}"; then
      pass "make target ${t}"
    else
      fail "make target ${t} missing recipe"
    fi
  else
    fail "make target ${t} missing"
  fi
done

# Default help
if grep -qE '^\.DEFAULT_GOAL\s*:=\s*help' "${MAKEFILE}" || grep -qE '^help:' "${MAKEFILE}"; then
  pass "help entry point present"
else
  fail "help entry point missing"
fi

# No preference for opening .xcodeproj alone over workspace
if grep -RniE 'open[[:space:]]+.*Phase1StillCapture\.xcodeproj' \
  "${OPS_ROOT}/Scripts" "${OPS_ROOT}/HELP.md" "${OPS_ROOT}/OPERATIONS_MANUAL.md" "${OPS_ROOT}/Makefile" 2>/dev/null \
  | grep -viE 'NOT|do not|Don.t|alone|instead|prefer|warn' >/tmp/ops-bad-open.txt 2>/dev/null; then
  if [[ -s /tmp/ops-bad-open.txt ]]; then
    fail "instruction prefers opening .xcodeproj"
    cat /tmp/ops-bad-open.txt
  else
    pass "no instruction prefers bare .xcodeproj"
  fi
else
  pass "no instruction prefers bare .xcodeproj"
fi
# Explicit: open-workspace must reference xcworkspace
if grep -q 'Phase1StillCapture.xcworkspace' "${OPS_ROOT}/Scripts/open-workspace.sh"; then
  pass "open-workspace prefers xcworkspace"
else
  fail "open-workspace missing xcworkspace"
fi
if grep -qi 'Do NOT open.*xcodeproj\|NOT the nested .xcodeproj' "${OPS_ROOT}/Scripts/open-workspace.sh"; then
  pass "open-workspace warns against bare xcodeproj"
else
  warn "open-workspace should warn against bare xcodeproj"
fi

# No unguarded rm -rf of broad paths in Scripts
while IFS= read -r line; do
  # Allow rm after ops_assert_safe_delete_path in same file — heuristic: flag rm -rf / or $HOME or Downloads without assert nearby
  if echo "${line}" | grep -qE 'rm[[:space:]]+-rf[[:space:]]+("?/\$|"?/Users|"?\$HOME"?[[:space:]]*$|"?\$HOME/Downloads)'; then
    fail "dangerous rm pattern: ${line}"
  fi
done < <(grep -Rn 'rm -rf' "${OPS_ROOT}/Scripts" || true)

# Repair scripts must require confirmation or --yes
for rs in repair-derived-data.sh repair-package-cache.sh; do
  if grep -q 'DELETE' "${OPS_ROOT}/Scripts/${rs}" && grep -q 'ops_assert_safe_delete_path' "${OPS_ROOT}/Scripts/${rs}"; then
    pass "${rs} confirmation + path guard"
  else
    fail "${rs} missing confirmation or path guard"
  fi
done

# No automatic physical-device success claims
CLAIM_HITS="$(grep -RniE 'DEVICE_APP_LAUNCHED.*=.*pass|camera capture verified automatically|app launched successfully' "${OPS_ROOT}/Scripts" 2>/dev/null | grep -vi 'manual' | grep -vi 'NOT' | grep -vi 'never' | grep -vi 'does NOT' || true)"
if [[ -n "${CLAIM_HITS}" ]]; then
  # Allow status.json updates that set manual_pass
  if echo "${CLAIM_HITS}" | grep -v 'manual_pass' | grep -v 'record-device-validation' | grep -q .; then
    fail "possible automatic device success claim"
    echo "${CLAIM_HITS}"
  else
    pass "no automatic device success claims"
  fi
else
  pass "no automatic device success claims"
fi

# record-device-validation must not set PHASE_APPROVED pass
if grep -q 'PHASE_APPROVED' "${OPS_ROOT}/Scripts/record-device-validation.sh"; then
  if grep -qi 'NOT SET\|never\|blocked\|NOT SET by' "${OPS_ROOT}/Scripts/record-device-validation.sh"; then
    pass "recorder refuses PHASE_APPROVED auto-grant"
  else
    fail "recorder mentions PHASE_APPROVED without refusal"
  fi
else
  warn "recorder should mention PHASE_APPROVED refusal explicitly"
fi

# Evidence directory creation works
TEST_RUN="$(ops_begin_evidence "ops-system-selfcheck")"
if [[ -d "${TEST_RUN}" && -f "${TEST_RUN}/started.txt" || -d "${TEST_RUN}" ]]; then
  echo "selfcheck" >"${TEST_RUN}/note.txt"
  ops_write_result_json "${TEST_RUN}" "pass" "ops-system-selfcheck" "meta verify"
  if [[ -f "${TEST_RUN}/result.json" ]]; then
    pass "evidence ledger write works (${TEST_RUN})"
  else
    fail "evidence result.json not written"
  fi
else
  fail "evidence directory not created"
fi

# Paths with spaces: ops_require_root should work when invoked with quoted paths
SPACE_TEST="${OPS_ROOT}/Scripts/ops-lib.sh"
if grep -q 'OPS_ROOT' "${SPACE_TEST}"; then
  pass "ops-lib uses OPS_ROOT (quote-safe pattern expected)"
else
  fail "ops-lib missing OPS_ROOT"
fi

# ERROR dictionary covers required classes
DICT="${OPS_ROOT}/Docs/ERROR_DICTIONARY.md"
for needle in \
  "CameraPreviewView" \
  "ElektronCapture" \
  "already opened" \
  "tool-hosted testing" \
  "development team" \
  "keychain" \
  "not a git repository" \
  "10814" \
  "3328" \
  "duplicate"; do
  if grep -qi "${needle}" "${DICT}"; then
    pass "error dictionary covers: ${needle}"
  else
    fail "error dictionary missing: ${needle}"
  fi
done

# diagnose.sh runnable
DIAG_OUT="$(mktemp)"
"${OPS_ROOT}/Scripts/diagnose.sh" "Cannot find CameraPreviewView in scope" >"${DIAG_OUT}" 2>&1 || true
if grep -qiE 'CROSS-MODULE|VISIBILITY|CameraPreviewView' "${DIAG_OUT}"; then
  pass "diagnose.sh classifies CameraPreviewView error"
else
  fail "diagnose.sh failed CameraPreviewView classification"
  head -n 20 "${DIAG_OUT}" || true
fi
rm -f "${DIAG_OUT}"

# make help exits 0
if make -C "${OPS_ROOT}" help >/dev/null 2>&1; then
  pass "make help exits 0"
else
  fail "make help failed"
fi

# No obsolete folder assumptions as action targets (ignore this verifier's own patterns)
OBSOLETE_HITS="$(grep -RniE 'elektron-capture-ios-OLD|pass2-share' "${OPS_ROOT}/Scripts" "${OPS_ROOT}/Makefile" 2>/dev/null \
  | grep -vi 'verify-operations-system' \
  | grep -Eic '[[:space:]](cd|open)[[:space:]]' || true)"
if [[ "${OBSOLETE_HITS}" -gt 0 ]]; then
  fail "script hard-codes obsolete copy path as action target"
else
  pass "no obsolete copy paths as action targets"
fi

echo ""
if [[ "${FAILS}" -eq 0 ]]; then
  echo "OPERATIONS_SYSTEM_OK"
  exit 0
fi
echo "OPERATIONS_SYSTEM_FAIL (${FAILS})"
exit 1
