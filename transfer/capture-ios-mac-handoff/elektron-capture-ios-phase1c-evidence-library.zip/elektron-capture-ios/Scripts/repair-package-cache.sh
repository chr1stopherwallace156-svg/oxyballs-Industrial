#!/usr/bin/env bash
# repair-package-cache.sh — reset SPM caches with confirmation; never deletes source.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ops-lib.sh
source "${SCRIPT_DIR}/ops-lib.sh"
ops_require_root

FORCE=0
[[ "${1:-}" == "--yes" ]] && FORCE=1

TARGETS=()
SPM_CACHE="${HOME}/Library/Caches/org.swift.swiftpm"
XCODE_SPM="${HOME}/Library/Developer/Xcode/DerivedData/SourcePackages"
WS_RESOLVED="${OPS_ROOT}/Phase1StillCapture.xcworkspace/xcshareddata/swiftpm"
# Only clear workspace checkouts inside THIS repo workspace data if present — not Package.resolved if shared intentionally
# Prefer clearing SourcePackages under DerivedData for this project

if [[ -d "${SPM_CACHE}" ]]; then
  TARGETS+=("${SPM_CACHE}")
fi

# Project-scoped SourcePackages inside matching DerivedData
DD_ROOT="${HOME}/Library/Developer/Xcode/DerivedData"
if [[ -d "${DD_ROOT}" ]]; then
  while IFS= read -r -d '' sp; do
    TARGETS+=("${sp}")
  done < <(find "${DD_ROOT}" -maxdepth 2 -type d \( -path '*/Phase1StillCapture-*/SourcePackages' -o -path '*/elektron-capture-ios-*/SourcePackages' \) -print0 2>/dev/null || true)
fi

# Local .build is regenerable
if [[ -d "${OPS_ROOT}/.build" ]]; then
  TARGETS+=("${OPS_ROOT}/.build")
fi

if [[ ${#TARGETS[@]} -eq 0 ]]; then
  echo "No package cache targets found (common on Linux)."
  echo "On Mac: File → Packages → Reset Package Caches, then Resolve Package Versions."
  exit 0
fi

echo "=== SAFE REPAIR: Swift package caches ==="
echo "Will remove:"
for t in "${TARGETS[@]}"; do
  echo "  ${t}"
done
echo ""
echo "Will NOT delete Package.swift, Sources/, Apps/, Docs/, .git, or evidence."
echo ""

if [[ "${FORCE}" -ne 1 ]]; then
  read -r -p "Type DELETE to confirm: " CONFIRM
  if [[ "${CONFIRM}" != "DELETE" ]]; then
    echo "Aborted."
    exit 1
  fi
fi

for t in "${TARGETS[@]}"; do
  ops_assert_safe_delete_path "${t}"
  # Must be under approved roots
  case "${t}" in
    "${HOME}/Library/Caches/org.swift.swiftpm"|"${HOME}/Library/Caches/org.swift.swiftpm"/*) ;;
    "${HOME}/Library/Developer/Xcode/DerivedData"/*) ;;
    "${OPS_ROOT}/.build"|"${OPS_ROOT}/.build"/*) ;;
    *) echo "REFUSING: path not in approved cache list: ${t}"; exit 2 ;;
  esac
  # Never delete Sources
  case "${t}" in
    */Sources|*/Sources/*|*/Apps|*/Apps/*) echo "REFUSING source path"; exit 2 ;;
  esac
  echo "Removing: ${t}"
  rm -rf "${t}"
done

echo "Package cache repair complete."
echo "Next: make open → File → Packages → Resolve Package Versions → make doctor"
exit 0
