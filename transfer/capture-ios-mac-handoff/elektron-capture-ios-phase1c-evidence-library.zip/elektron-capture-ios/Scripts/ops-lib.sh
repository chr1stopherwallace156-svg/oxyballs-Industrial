#!/usr/bin/env bash
# Shared helpers for operations scripts (sourced, not executed alone).
# shellcheck shell=bash

ops_root() {
  local here
  # When sourced, BASH_SOURCE[0] is ops-lib.sh
  here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
  printf '%s' "$here"
}

# Canonical root for sourced scripts
OPS_ROOT="$(ops_root)"
export OPS_ROOT

ops_require_root() {
  if ! ops_is_repo_root "${OPS_ROOT}"; then
    echo "FAIL: not elektron-capture-ios root: ${OPS_ROOT}" >&2
    echo "Need Package.swift, .repository-identity.json, Phase1StillCapture.xcworkspace" >&2
    return 1
  fi
  cd "${OPS_ROOT}" || return 1
}

ops_pass() { printf 'PASS: %s\n' "$*"; }
ops_warn() { printf 'WARN: %s\n' "$*"; }
ops_fail() { printf 'FAIL: %s\n' "$*"; }
ops_log() { printf '%s\n' "$*"; }

ops_is_repo_root() {
  local root="$1"
  [[ -f "$root/Package.swift" && -f "$root/.repository-identity.json" && -d "$root/Phase1StillCapture.xcworkspace" ]]
}

ops_git_state() {
  if [[ -d "${OPS_ROOT}/.git" ]] && command -v git >/dev/null 2>&1; then
    git -C "${OPS_ROOT}" rev-parse HEAD 2>/dev/null || true
    git -C "${OPS_ROOT}" status -sb 2>/dev/null || true
    git -C "${OPS_ROOT}" log -1 --oneline 2>/dev/null || true
  else
    echo "NO_GIT_METADATA"
  fi
}

ops_new_evidence_run() {
  local root="$1"
  local workflow="$2"
  local ts
  ts="$(date -u +"%Y-%m-%dT%H%M%SZ")"
  local dir="$root/Docs/Evidence/Runs/${ts}-${workflow}"
  mkdir -p "$dir"
  echo "started=$(date -u +%Y-%m-%dT%H:%M:%SZ)" >"$dir/started.txt"
  printf '%s' "$dir"
}

ops_begin_evidence() {
  local workflow="$1"
  ops_new_evidence_run "${OPS_ROOT}" "${workflow}"
}

ops_write_basic_evidence() {
  local root="$1"
  local dir="$2"
  local cmd="$3"
  {
    echo "utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "command=${cmd}"
    echo "host=$(uname -s) $(uname -m)"
    echo "pwd=$(pwd)"
  } >"$dir/environment.txt"
  echo "$root" >"$dir/repository-path.txt"
  if [[ -f "$root/.repository-identity.json" ]]; then
    cp "$root/.repository-identity.json" "$dir/repository-identity.json"
  fi
  if [[ -d "$root/.git" ]] && command -v git >/dev/null 2>&1; then
    {
      git -C "$root" rev-parse HEAD 2>/dev/null || true
      git -C "$root" status -sb 2>/dev/null || true
      git -C "$root" log -1 --oneline 2>/dev/null || true
    } >"$dir/git-state.txt"
  else
    echo "NO_GIT_METADATA" >"$dir/git-state.txt"
  fi
  if command -v swift >/dev/null 2>&1; then
    swift --version >"$dir/swift-version.txt" 2>&1 || true
  fi
  if command -v xcodebuild >/dev/null 2>&1; then
    xcodebuild -version >"$dir/xcode-version.txt" 2>&1 || true
  fi
}

ops_write_result_json() {
  local dir="$1"
  local status="$2"
  local workflow="$3"
  local note="${4:-}"
  local ts
  ts="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$dir/result.json" "$status" "$workflow" "$note" "$ts" <<'PY'
import json, sys
path, status, workflow, note, ts = sys.argv[1:6]
data = {
  "status": status,
  "workflow": workflow,
  "utc": ts,
  "note": note,
  "claims_physical_device_success": False,
  "claims_phase_approved": False,
}
with open(path, "w") as f:
    json.dump(data, f, indent=2)
    f.write("\n")
PY
  else
    cat >"$dir/result.json" <<EOF
{"status":"${status}","workflow":"${workflow}","utc":"${ts}","note":"${note}","claims_physical_device_success":false,"claims_phase_approved":false}
EOF
  fi
}

ops_confirm() {
  local prompt="$1"
  if [[ -t 0 ]]; then
    read -r -p "$prompt [type yes]: " ans
    [[ "$ans" == "yes" ]]
  else
    [[ "${CONFIRM:-}" == "yes" ]]
  fi
}

ops_reject_dangerous_path() {
  local p="$1"
  local abs
  if [[ -d "$p" ]]; then
    abs="$(cd "$p" && pwd)"
  else
    abs="$(cd "$(dirname "$p")" 2>/dev/null && pwd)/$(basename "$p")"
  fi
  case "$abs" in
    / | /Users | /home | "$HOME" | "$HOME/Downloads" | /Downloads | /tmp | /var | /System | /Library)
      echo "REFUSING dangerous path: $abs" >&2
      return 1
      ;;
  esac
  if [[ -z "$p" || "$p" == "/" ]]; then
    echo "REFUSING empty or root path" >&2
    return 1
  fi
  return 0
}

ops_assert_safe_delete_path() {
  local p="$1"
  ops_reject_dangerous_path "$p" || return 1
  local abs
  if [[ -d "$p" ]]; then
    abs="$(cd "$p" && pwd)"
  else
    abs="$(cd "$(dirname "$p")" 2>/dev/null && pwd)/$(basename "$p")"
  fi
  # Never delete source trees, git, evidence packages, or docs content as targets
  case "$abs" in
    */Sources|*/Sources/*|*/Apps|*/Apps/*|*/App|*/App/*|*/.git|*/.git/*)
      echo "REFUSING source/git path: $abs" >&2
      return 1
      ;;
    */Docs/Evidence/Runs|*/Docs/Evidence/Runs/*)
      echo "REFUSING evidence ledger path: $abs" >&2
      return 1
      ;;
  esac
  # Reject if path equals repo root
  if [[ "$abs" == "${OPS_ROOT}" ]]; then
    echo "REFUSING repository root" >&2
    return 1
  fi
  return 0
}
