#!/usr/bin/env bash
# Read-only environment doctor for elektron-capture-ios.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck source=ops-lib.sh
source "$ROOT/Scripts/ops-lib.sh"

cd "$ROOT"
EVIDENCE="$(ops_new_evidence_run "$ROOT" "doctor")"
ops_write_basic_evidence "$ROOT" "$EVIDENCE" "Scripts/doctor.sh"
LOG="$EVIDENCE/doctor.log"
exec > >(tee "$LOG") 2>&1

echo "=== doctor @ $ROOT ==="
FAILS=0
WARNS=0

bump_fail() { FAILS=$((FAILS + 1)); ops_fail "$*"; }
bump_warn() { WARNS=$((WARNS + 1)); ops_warn "$*"; }

if ops_is_repo_root "$ROOT"; then
  ops_pass "Repository root"
else
  bump_fail "Repository root (need Package.swift, .repository-identity.json, Phase1StillCapture.xcworkspace)"
fi

if [[ "$ROOT" == *" "* ]]; then
  bump_warn "Path contains spaces — always quote: cd \"$ROOT\""
else
  ops_pass "Path quoting (no spaces in root)"
fi

if [[ -d "$ROOT/Phase1StillCapture.xcworkspace" ]]; then
  ops_pass "Correct workspace (root Phase1StillCapture.xcworkspace)"
else
  bump_fail "Correct workspace missing"
fi

# Duplicate copies nearby
COPIES=0
while IFS= read -r -d '' p; do
  COPIES=$((COPIES + 1))
done < <(find "$HOME/Downloads" "$HOME/Desktop" "$HOME/Documents" -maxdepth 4 \
  -name 'Package.swift' -path '*/elektron-capture-ios*/Package.swift' -print0 2>/dev/null || true)
if [[ "$COPIES" -gt 1 ]]; then
  bump_warn "Duplicate repositories nearby ($COPIES Package.swift under ~/Downloads|Desktop|Documents) — run make repo-locator"
else
  ops_pass "Duplicate repositories nearby (≤1 match in common folders)"
fi

if command -v xcodebuild >/dev/null 2>&1; then
  ops_pass "Xcode installed (xcodebuild present)"
  xcodebuild -version | head -2 || true
else
  bump_warn "Xcode installed (xcodebuild missing — Linux/cloud OK for SPM only)"
fi

if command -v swift >/dev/null 2>&1; then
  ops_pass "Swift version"
  swift --version | head -1 || true
else
  bump_fail "Swift version (swift not found)"
fi

# Connected iPhone (Mac)
if command -v xcrun >/dev/null 2>&1; then
  DEVICES="$(xcrun xctrace list devices 2>/dev/null | grep -i iphone | grep -v Simulator || true)"
  if [[ -n "$DEVICES" ]]; then
    ops_pass "Connected iPhone"
    echo "$DEVICES" | head -5
  else
    bump_warn "Connected iPhone (none detected)"
  fi
else
  bump_warn "Connected iPhone (xcrun unavailable)"
fi

# Signing readiness (pbxproj empty team is common — warn)
if grep -q 'DEVELOPMENT_TEAM = "";' "$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj" 2>/dev/null; then
  bump_warn "Signing identity (DEVELOPMENT_TEAM empty in pbxproj — set Team in Xcode)"
else
  ops_pass "Signing identity (pbxproj team field non-empty or absent)"
fi

# Package linkage
PBX="$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj"
if grep -q 'ElektronCapture in Frameworks' "$PBX" && grep -q 'productName = ElektronCapture' "$PBX"; then
  ops_pass "Package linkage"
else
  bump_fail "Package linkage"
fi

# CameraPreviewView visibility
CPV="$ROOT/App/Capture/AVFoundation/CameraPreviewView.swift"
if [[ -f "$CPV" ]] && grep -qE 'public[[:space:]]+struct[[:space:]]+CameraPreviewView' "$CPV"; then
  ops_pass "CameraPreviewView visibility"
else
  bump_fail "CameraPreviewView visibility (must be public struct)"
fi

# App imports
for f in Phase1StillCaptureApp.swift Phase1CaptureRootView.swift; do
  if grep -q 'import ElektronCapture' "$ROOT/Apps/Phase1StillCapture/$f"; then
    ops_pass "App import ($f)"
  else
    bump_fail "App import ($f missing import ElektronCapture)"
  fi
done

# Uncommitted changes
if [[ -d "$ROOT/.git" ]] && command -v git >/dev/null 2>&1; then
  if [[ -n "$(git -C "$ROOT" status --porcelain 2>/dev/null)" ]]; then
    bump_warn "Uncommitted changes"
  else
    ops_pass "Uncommitted changes (clean)"
  fi
else
  bump_warn "Uncommitted changes (no .git — ZIP snapshot is OK)"
fi

# Stale DerivedData hint under repo evidence
if [[ -d "$ROOT/Docs/Evidence/XCODE_APP_BUILD/DerivedData" ]]; then
  bump_warn "Stale DerivedData (repo evidence DerivedData present — make repair-derived-data if builds are weird)"
else
  ops_pass "DerivedData (no repo-local evidence DerivedData)"
fi

# Wrong scheme reminder
ops_pass "Scheme expectation (use Phase1StillCapture — not physical-device for package tests)"

{
  echo "{"
  echo "  \"workflow\": \"doctor\","
  echo "  \"fails\": $FAILS,"
  echo "  \"warns\": $WARNS,"
  echo "  \"result\": \"$([[ $FAILS -eq 0 ]] && echo PASS || echo FAIL)\""
  echo "}"
} >"$EVIDENCE/result.json"

echo
echo "Evidence: $EVIDENCE"
if [[ "$FAILS" -gt 0 ]]; then
  echo "DOCTOR_RESULT=FAIL ($FAILS fail, $WARNS warn)"
  exit 1
fi
echo "DOCTOR_RESULT=PASS ($WARNS warn)"
exit 0
