#!/usr/bin/env bash
# device-preflight.sh — prove the machine is ready for Command-R. Never claims the app ran.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ops-lib.sh
source "${SCRIPT_DIR}/ops-lib.sh"
ops_require_root

RUN_DIR="$(ops_begin_evidence "device-preflight")"
RESULT_RC=0
FAILS=0

pass() { ops_log "PASS: $*"; }
fail() { ops_log "FAIL: $*"; FAILS=$((FAILS + 1)); RESULT_RC=1; }
warn() { ops_log "WARN: $*"; }

{
  echo "command: make device-preflight"
  echo "repo: ${OPS_ROOT}"
  echo "started: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
} >"${RUN_DIR}/environment.txt"

cp "${OPS_ROOT}/.repository-identity.json" "${RUN_DIR}/repository-identity.json"
pwd >"${RUN_DIR}/repository-path.txt"
ops_git_state >"${RUN_DIR}/git-state.txt"

# Correct repository / workspace
if [[ -f "${OPS_ROOT}/Phase1StillCapture.xcworkspace/contents.xcworkspacedata" ]]; then
  pass "Correct workspace present (Phase1StillCapture.xcworkspace)"
else
  fail "Root workspace missing"
fi

# Scheme
SCHEME_OK=0
if command -v xcodebuild >/dev/null 2>&1; then
  if xcodebuild -list -workspace "${OPS_ROOT}/Phase1StillCapture.xcworkspace" 2>/dev/null | grep -q "Phase1StillCapture"; then
    pass "Phase1StillCapture scheme exists"
    SCHEME_OK=1
  else
    fail "Phase1StillCapture scheme not listed"
  fi
else
  warn "xcodebuild unavailable — scheme list skipped (Linux CI)"
  if [[ -f "${OPS_ROOT}/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj" ]]; then
    if grep -q "Phase1StillCapture" "${OPS_ROOT}/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj"; then
      pass "Scheme/project name present in pbxproj (static check)"
      SCHEME_OK=1
    fi
  fi
fi

# Package product
if [[ -f "${OPS_ROOT}/Package.swift" ]] && grep -q 'name: "ElektronCapture"' "${OPS_ROOT}/Package.swift"; then
  pass "ElektronCapture product resolves in Package.swift"
else
  fail "ElektronCapture product missing"
fi

# App imports + public API
ROOT_VIEW="${OPS_ROOT}/Apps/Phase1StillCapture/Phase1CaptureRootView.swift"
if grep -q 'import ElektronCapture' "${ROOT_VIEW}" 2>/dev/null; then
  pass "App imports ElektronCapture"
else
  fail "App missing import ElektronCapture"
fi
PREVIEW_SRC="${OPS_ROOT}/App/Capture/AVFoundation/CameraPreviewView.swift"
if grep -qE 'public[[:space:]]+struct[[:space:]]+CameraPreviewView' "${PREVIEW_SRC}" 2>/dev/null; then
  pass "CameraPreviewView is public"
else
  fail "CameraPreviewView not public"
fi

# Device connected
DEVICE_OK=0
if command -v xcrun >/dev/null 2>&1; then
  DEV_OUT="$(xcrun xctrace list devices 2>/dev/null || true)"
  echo "${DEV_OUT}" >"${RUN_DIR}/device-summary.txt"
  if echo "${DEV_OUT}" | grep -qiE "iPhone|iPad"; then
    if echo "${DEV_OUT}" | grep -qi "Simulator"; then
      # Prefer physical if both listed — soft pass if any iPhone line exists outside Simulator section is hard
      pass "iOS device listing present (confirm physical vs simulator in device-summary.txt)"
      DEVICE_OK=1
    else
      pass "Connected iOS device listing present"
      DEVICE_OK=1
    fi
  else
    fail "No connected iPhone/iPad detected"
  fi
else
  warn "xcrun unavailable — device check skipped"
  echo "DEVICE_CHECK_SKIPPED" >"${RUN_DIR}/device-summary.txt"
fi

# Signing
SIGN_SUMMARY="${RUN_DIR}/signing-summary.txt"
{
  echo "# No secrets. Team ID presence only."
  if command -v security >/dev/null 2>&1; then
    security find-identity -v -p codesigning 2>/dev/null | sed 's/[0-9A-F]\{40\}/[IDENTITY_FINGERPRINT_REDACTED]/g' || true
  else
    echo "security tool unavailable"
  fi
  PBX="${OPS_ROOT}/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj"
  if grep -q "DEVELOPMENT_TEAM" "${PBX}" 2>/dev/null; then
    echo "DEVELOPMENT_TEAM key present in pbxproj (value redacted from evidence)"
  else
    echo "DEVELOPMENT_TEAM not found in committed pbxproj — set in Xcode Signing & Capabilities"
  fi
} >"${SIGN_SUMMARY}"

if command -v security >/dev/null 2>&1; then
  if security find-identity -v -p codesigning 2>/dev/null | grep -qi "Apple Development\|iPhone Developer\|Apple Distribution"; then
    pass "Signing identity available"
  else
    fail "No Apple Development signing identity"
  fi
else
  warn "Signing identity check skipped (non-macOS)"
fi

# Optional: try iphoneos build only on Darwin — still does not claim launch
if [[ "$(uname -s)" == "Darwin" ]] && command -v xcodebuild >/dev/null 2>&1 && [[ "${SCHEME_OK}" -eq 1 ]]; then
  ops_log "Attempting iphoneos build (readiness only; does NOT claim app launched)..."
  set +e
  xcodebuild -workspace "${OPS_ROOT}/Phase1StillCapture.xcworkspace" \
    -scheme Phase1StillCapture \
    -destination 'generic/platform=iOS' \
    -configuration Debug \
    build \
    CODE_SIGNING_ALLOWED=YES \
    >"${RUN_DIR}/xcode-build.log" 2>&1
  XB=$?
  set -e
  if [[ "${XB}" -eq 0 ]]; then
    pass "App builds for iphoneos (generic destination)"
  else
    fail "iphoneos build failed — see xcode-build.log"
  fi
else
  warn "iphoneos build skipped (Linux or missing tools) — HANDOFF_XCODE_BUILD_SKIPPED"
  echo "HANDOFF_XCODE_BUILD_SKIPPED" >"${RUN_DIR}/xcode-build.log"
fi

ops_log ""
ops_log "=== DEVICE PREFLIGHT SUMMARY ==="
ops_log "This script does NOT claim the app ran, camera worked, or export succeeded."
ops_log "If PASS: you may press Command-R in Xcode on a physical iPhone."
ops_log "If FAIL: fix failures, then re-run make doctor && make device-preflight"

STATUS="pass"
[[ "${RESULT_RC}" -ne 0 ]] && STATUS="fail"
ops_write_result_json "${RUN_DIR}" "${STATUS}" "device-preflight" \
  "Ready for Command-R only if all critical checks PASS. Manual DEVICE_APP_LAUNCHED still required."

if [[ "${FAILS}" -eq 0 ]]; then
  ops_log "DEVICE_PREFLIGHT: PASS (machine ready — runtime still manual)"
  exit 0
fi
ops_log "DEVICE_PREFLIGHT: FAIL (${FAILS} issue(s))"
exit 1
