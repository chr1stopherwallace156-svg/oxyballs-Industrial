#!/usr/bin/env bash
# Prove Xcode handoff layout + (when available) the Phase1StillCapture app build.
# Usage: ./Scripts/verify-xcode-handoff.sh [repo-root]
#
# Gates:
#   HANDOFF_LAYOUT_OK     — always required (Linux + Mac)
#   HANDOFF_XCODE_BUILD_OK — required on Darwin when xcodebuild is present
#   HANDOFF_XCODE_BUILD_SKIPPED — printed on Linux / no-xcode environments
#
# Note: `swift build` only compiles Package.swift (ElektronCapture). It does NOT
# compile Apps/Phase1StillCapture/*.swift. Do not treat SPM green as app green.
set -euo pipefail

ROOT="$(cd "${1:-$(dirname "$0")/..}" && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }
skip() { echo "SKIP: $*"; }

echo "=== verify-xcode-handoff @ $ROOT ==="
echo "host=$(uname -s) arch=$(uname -m)"

[[ -f Package.swift ]] || fail "Package.swift missing at repo root"
pass "Package.swift exists at repo root"

if command -v swift >/dev/null 2>&1; then
  PROD=$(swift package dump-package | python3 -c "import sys,json; print(',' .join(p['name'] for p in json.load(sys.stdin)['products']))")
  echo "$PROD" | grep -q 'ElektronCapture' || fail "Package does not export product ElektronCapture (got: $PROD)"
  pass "Package exports product ElektronCapture"
else
  grep -q 'library(name: "ElektronCapture"' Package.swift || fail "Package.swift missing ElektronCapture product declaration"
  pass "Package.swift declares product ElektronCapture (swift not installed; dump-package skipped)"
fi

PBX="$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj"
[[ -f "$PBX" ]] || fail "Phase1StillCapture.xcodeproj missing"
pass "Phase1StillCapture.xcodeproj exists"

grep -q 'productName = ElektronCapture' "$PBX" || fail "pbxproj missing productName = ElektronCapture"
pass "pbxproj productName = ElektronCapture"

grep -q 'isa = XCLocalSwiftPackageReference' "$PBX" || fail "pbxproj missing XCLocalSwiftPackageReference"
pass "pbxproj has XCLocalSwiftPackageReference"

# relativePath must resolve to repo root from the directory containing the .xcodeproj
PROJ_DIR="$ROOT/Apps/Phase1StillCapture"
REL=$(grep -E 'relativePath = ' "$PBX" | head -1 | sed 's/.*relativePath = //;s/;//;s/ //g')
[[ -n "$REL" ]] || fail "relativePath not found in pbxproj"
RESOLVED="$(cd "$PROJ_DIR" && realpath "$REL")"
[[ "$RESOLVED" == "$ROOT" ]] || fail "relativePath '$REL' from Apps/Phase1StillCapture resolves to '$RESOLVED', expected '$ROOT'"
[[ -f "$RESOLVED/Package.swift" ]] || fail "resolved package root has no Package.swift"
pass "relativePath '$REL' resolves to repo root with Package.swift"

# Sources that compile in the app target must import the package module when they use it.
# Checking only Phase1StillCaptureApp.swift previously allowed RootView to omit the import.
APP_SWIFT_DIR="$ROOT/Apps/Phase1StillCapture"
[[ -d "$APP_SWIFT_DIR" ]] || fail "Apps/Phase1StillCapture missing"

for base in Phase1StillCaptureApp.swift Phase1CaptureRootView.swift; do
  f="$APP_SWIFT_DIR/$base"
  [[ -f "$f" ]] || fail "missing app source $base"
  grep -q 'import ElektronCapture' "$f" \
    || fail "$base compiles in the app target but lacks 'import ElektronCapture' (swift build will not catch this)"
  pass "$base imports ElektronCapture"
done

# Package-boundary visibility: app-consumed package types must be `public`.
# Internal `struct CameraPreviewView` caused: Cannot find 'CameraPreviewView' in scope
# after import ElektronCapture fixed the prior unresolved-symbol class.
require_public_package_symbol() {
  local symbol="$1"
  local decl_file="$2"
  if ! grep -R -n --include='*.swift' -E "\\b${symbol}\\b" "$APP_SWIFT_DIR" >/dev/null 2>&1; then
    return 0
  fi
  [[ -f "$decl_file" ]] || fail "app uses ${symbol} but declaration file missing: $decl_file"
  grep -qE "public[[:space:]]+(struct|class|enum|actor)[[:space:]]+${symbol}\\b" "$decl_file" \
    || fail "app uses ${symbol} but ${decl_file} does not declare it public (package-boundary visibility)"
  pass "app-consumed symbol ${symbol} is public in package"
}

require_public_package_symbol \
  "CameraPreviewView" \
  "$ROOT/App/Capture/AVFoundation/CameraPreviewView.swift"

# Target membership: RootView must be in Sources build phase
grep -q 'Phase1CaptureRootView.swift in Sources' "$PBX" \
  || fail "Phase1CaptureRootView.swift not in app Sources build phase"
pass "Phase1CaptureRootView.swift is in app Sources"

# Frameworks / package product linkage
grep -q 'ElektronCapture in Frameworks' "$PBX" || fail "pbxproj missing ElektronCapture in Frameworks build file"
pass "pbxproj links ElektronCapture in Frameworks"
grep -q 'packageProductDependencies' "$PBX" || fail "pbxproj missing packageProductDependencies"
grep -q 'ABFD7D8E58674965ABF946C3 /\* ElektronCapture \*/' "$PBX" \
  || grep -q 'productName = ElektronCapture' "$PBX" \
  || fail "pbxproj missing ElektronCapture package product dependency entry"
pass "pbxproj packageProductDependencies includes ElektronCapture"

WS_APP="$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace"
WS_ROOT="$ROOT/Phase1StillCapture.xcworkspace"
if [[ -f "$WS_APP/contents.xcworkspacedata" ]]; then
  pass "App-level xcworkspace present"
  WORKSPACE="$WS_APP"
elif [[ -f "$WS_ROOT/contents.xcworkspacedata" ]]; then
  pass "Root xcworkspace present"
  WORKSPACE="$WS_ROOT"
else
  fail "No Phase1StillCapture.xcworkspace found (app or root)"
fi

echo
echo "HANDOFF_LAYOUT_OK"

# --- Xcode app build gate (Darwin) ---
EVIDENCE_DIR="${VERIFY_XCODE_EVIDENCE_DIR:-$ROOT/Docs/Evidence/XCODE_APP_BUILD}"
if command -v xcodebuild >/dev/null 2>&1; then
  mkdir -p "$EVIDENCE_DIR"
  BUILD_LOG="$EVIDENCE_DIR/xcodebuild-clean-build.log"
  SETTINGS_LOG="$EVIDENCE_DIR/xcodebuild-showBuildSettings.txt"
  LINKAGE_LOG="$EVIDENCE_DIR/xcodebuild-package-linkage-excerpt.txt"

  echo "=== xcodebuild clean build (workspace) ==="
  echo "workspace=$WORKSPACE scheme=Phase1StillCapture"
  xcodebuild \
    -workspace "$WORKSPACE" \
    -scheme Phase1StillCapture \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$EVIDENCE_DIR/DerivedData" \
    clean build \
    2>&1 | tee "$BUILD_LOG"

  # Require BUILD SUCCEEDED in the log
  grep -q 'BUILD SUCCEEDED' "$BUILD_LOG" || fail "xcodebuild did not report BUILD SUCCEEDED (see $BUILD_LOG)"
  pass "xcodebuild clean build succeeded"

  echo "=== xcodebuild -showBuildSettings (package linkage excerpt) ==="
  xcodebuild \
    -workspace "$WORKSPACE" \
    -scheme Phase1StillCapture \
    -showBuildSettings \
    2>&1 | tee "$SETTINGS_LOG" >/dev/null

  # Keep a small reviewable excerpt; full settings retained in SETTINGS_LOG
  grep -E 'ElektronCapture|PACKAGE_FRAMEWORKS|FRAMEWORK_SEARCH_PATHS|SWIFT_INCLUDE_PATHS|PRODUCT_MODULE_NAME' \
    "$SETTINGS_LOG" | tee "$LINKAGE_LOG" || true

  # Soft check: settings dump should mention ElektronCapture somewhere when linked
  if grep -q 'ElektronCapture' "$SETTINGS_LOG"; then
    pass "showBuildSettings mentions ElektronCapture"
  else
    echo "WARN: showBuildSettings did not mention ElektronCapture — inspect $SETTINGS_LOG" >&2
  fi

  echo
  echo "HANDOFF_XCODE_BUILD_OK"
  echo "Evidence: $EVIDENCE_DIR"
else
  skip "xcodebuild not available on this host ($(uname -s))"
  skip "Mac operator must run workspace clean build + -showBuildSettings before claiming app integration"
  echo
  echo "HANDOFF_XCODE_BUILD_SKIPPED"
  echo "Layout gate passed; app-target compile gate NOT executed on this host."
fi

echo
echo "Open the root workspace (preferred):"
echo "  open Phase1StillCapture.xcworkspace"
echo "  make open"
echo "Do NOT open Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj alone as the primary workflow."
echo "If Xcode still shows Missing package product: File → Packages → Reset Package Caches, then resolve."
