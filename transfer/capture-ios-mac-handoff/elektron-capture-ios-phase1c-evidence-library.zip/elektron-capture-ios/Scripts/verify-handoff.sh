#!/usr/bin/env bash
# verify-handoff.sh — golden automated handoff gate. Never claims physical-device success.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ops-lib.sh
source "${SCRIPT_DIR}/ops-lib.sh"
ops_require_root

RUN_DIR="$(ops_begin_evidence "verify-handoff")"
cp "${OPS_ROOT}/.repository-identity.json" "${RUN_DIR}/repository-identity.json"
pwd >"${RUN_DIR}/repository-path.txt"
ops_git_state >"${RUN_DIR}/git-state.txt"
{
  echo "uname: $(uname -a)"
  command -v swift >/dev/null && swift --version 2>&1 | head -n 2 || echo "swift: missing"
  command -v xcodebuild >/dev/null && xcodebuild -version 2>&1 | head -n 2 || echo "xcodebuild: missing"
} >"${RUN_DIR}/environment.txt"

AUTO_RC=0

run_step() {
  local name="$1"
  shift
  echo ""
  echo ">>> ${name}"
  set +e
  "$@" >"${RUN_DIR}/${name}.log" 2>&1
  local rc=$?
  set -e
  if [[ ${rc} -eq 0 ]]; then
    echo "PASS: ${name}"
  else
    echo "FAIL: ${name} (see ${name}.log)"
    AUTO_RC=1
  fi
  return 0
}

run_step "doctor" "${SCRIPT_DIR}/doctor.sh"
run_step "verify-operations-system" "${SCRIPT_DIR}/verify-operations-system.sh"
run_step "verify-help-system" "${SCRIPT_DIR}/verify-help-system.sh"

if [[ -x "${SCRIPT_DIR}/verify-xcode-handoff.sh" ]]; then
  run_step "verify-xcode-handoff" "${SCRIPT_DIR}/verify-xcode-handoff.sh"
fi

if command -v swift >/dev/null 2>&1; then
  run_step "swift-test" bash -c "cd \"${OPS_ROOT}\" && swift test"
else
  echo "WARN: swift missing — tests skipped"
  echo "SWIFT_MISSING" >"${RUN_DIR}/swift-test.log"
fi

# Mac app build if available
if [[ "$(uname -s)" == "Darwin" ]] && command -v xcodebuild >/dev/null 2>&1; then
  run_step "xcode-build" bash -c "cd \"${OPS_ROOT}\" && xcodebuild -workspace Phase1StillCapture.xcworkspace -scheme Phase1StillCapture -destination 'generic/platform=iOS' -configuration Debug build CODE_SIGNING_ALLOWED=YES"
else
  echo "MAC APP BUILD: SKIPPED (HANDOFF_XCODE_BUILD_SKIPPED)"
  echo "HANDOFF_XCODE_BUILD_SKIPPED" >"${RUN_DIR}/xcode-build.log"
fi

echo ""
echo "========================================"
if [[ "${AUTO_RC}" -eq 0 ]]; then
  echo "AUTOMATED CHECKS: PASS"
else
  echo "AUTOMATED CHECKS: FAIL"
fi

if [[ "$(uname -s)" == "Darwin" ]] && command -v xcodebuild >/dev/null 2>&1 && [[ -f "${RUN_DIR}/xcode-build.log" ]] && ! grep -q HANDOFF_XCODE_BUILD_SKIPPED "${RUN_DIR}/xcode-build.log"; then
  if grep -q "PASS: xcode-build" <<<"$(grep -E 'PASS: xcode-build|FAIL: xcode-build' || true)"; then
    :
  fi
  if [[ -f "${RUN_DIR}/xcode-build.log" ]] && tail -n 5 "${RUN_DIR}/xcode-build.log" | grep -qi "BUILD SUCCEEDED\|ARCHIVE SUCCEEDED" 2>/dev/null; then
    echo "MAC APP BUILD: PASS"
  elif [[ "${AUTO_RC}" -eq 0 ]] && [[ "$(uname -s)" == "Darwin" ]]; then
    # check log exit via whether step failed
    if grep -q "FAIL: xcode-build" "${RUN_DIR}/../" 2>/dev/null; then
      echo "MAC APP BUILD: FAIL"
    else
      # Infer from AUTO and presence — re-check by scanning our echoes is hard; use file marker
      if [[ -s "${RUN_DIR}/xcode-build.log" ]] && ! grep -qi "error:" "${RUN_DIR}/xcode-build.log"; then
        echo "MAC APP BUILD: PASS (see xcode-build.log)"
      else
        echo "MAC APP BUILD: REVIEW LOG"
      fi
    fi
  else
    echo "MAC APP BUILD: REVIEW LOG"
  fi
else
  echo "MAC APP BUILD: SKIPPED / PENDING (Linux or no Xcode)"
fi

echo "PHYSICAL DEVICE RUNTIME: MANUAL EVIDENCE REQUIRED"
echo "EXPORT TO FILES: MANUAL EVIDENCE REQUIRED"
echo "FINAL APPROVAL: BLOCKED UNTIL MANUAL CHECKLIST COMPLETED"
echo "========================================"
echo "Next: make device-preflight && (Command-R) && make record-device-validation"
echo "Evidence: ${RUN_DIR}"

STATUS="pass"
[[ "${AUTO_RC}" -ne 0 ]] && STATUS="fail"
ops_write_result_json "${RUN_DIR}" "${STATUS}" "verify-handoff" \
  "Automated only. Physical device + export + PHASE_APPROVED still manual."

exit "${AUTO_RC}"
