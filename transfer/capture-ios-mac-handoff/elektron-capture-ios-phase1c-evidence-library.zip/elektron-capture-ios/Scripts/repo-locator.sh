#!/usr/bin/env bash
# Locate nearby elektron-capture-ios copies. Read-only. Never deletes.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck source=ops-lib.sh
source "$ROOT/Scripts/ops-lib.sh"

echo "=== repo-locator ==="
echo "CURRENT:"
echo "  path=$ROOT"
if [[ -f "$ROOT/.repository-identity.json" ]]; then
  echo "  identity=$(tr -d '\n' <"$ROOT/.repository-identity.json" | head -c 200)…"
fi
if [[ -d "$ROOT/.git" ]] && command -v git >/dev/null 2>&1; then
  echo "  commit=$(git -C "$ROOT" rev-parse HEAD 2>/dev/null || echo unknown)"
else
  echo "  commit=NO_GIT_METADATA"
fi
if [[ -f "$ROOT/App/Capture/AVFoundation/CameraPreviewView.swift" ]] && \
   grep -qE 'public[[:space:]]+struct[[:space:]]+CameraPreviewView' "$ROOT/App/Capture/AVFoundation/CameraPreviewView.swift"; then
  echo "  CameraPreviewView=public"
else
  echo "  CameraPreviewView=NOT_PUBLIC_OR_MISSING"
fi
echo "  workspace=$ROOT/Phase1StillCapture.xcworkspace"
echo "  mtime=$(date -r "$ROOT/Package.swift" '+%Y-%m-%d' 2>/dev/null || stat -c %y "$ROOT/Package.swift" 2>/dev/null | cut -d. -f1 || echo unknown)"

echo
echo "OTHER COPIES (search ~/Downloads, ~/Desktop, ~/Documents; depth≤5):"
FOUND=0
while IFS= read -r -d '' pkg; do
  dir="$(dirname "$pkg")"
  abs="$(cd "$dir" && pwd)"
  [[ "$abs" == "$ROOT" ]] && continue
  FOUND=$((FOUND + 1))
  echo "  - $abs"
  if [[ -f "$abs/App/Capture/AVFoundation/CameraPreviewView.swift" ]]; then
    if grep -qE 'public[[:space:]]+struct[[:space:]]+CameraPreviewView' "$abs/App/Capture/AVFoundation/CameraPreviewView.swift"; then
      echo "      CameraPreviewView=public"
    else
      echo "      CameraPreviewView=internal_or_missing_public"
    fi
  fi
done < <(find "$HOME/Downloads" "$HOME/Desktop" "$HOME/Documents" -maxdepth 5 \
  -name Package.swift -print0 2>/dev/null || true)

if [[ "$FOUND" -eq 0 ]]; then
  echo "  (none found)"
else
  echo
  echo "WARN: $FOUND other candidate(s). Open ONLY the CURRENT root workspace."
  echo "Never auto-delete copies from this script."
fi
