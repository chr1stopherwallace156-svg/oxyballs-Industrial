# CAPTURE SENSOR FRAMEWORK CONTRACT

| Field | Value |
|---|---|
| Status | **DRAFT** |
| Depends on | `ELEKTRON_CAPTURE_V2_SPEC.md`, `CAPTURE_V2_DOMAIN_MODEL.md` |
| Next | `CAPTURE_DEVICE_CAPABILITY_MATRIX.md` |

## 1. Purpose

Guarantee every hardware or software provider — AVFoundation, CoreMotion, ARKit depth, CoreLocation, external thermal — conforms to identical **lifecycle, buffering, timestamp, and failure-handling** conventions.

## 2. Universal Interface

```swift
public protocol EvidenceSensor: AnyObject {
  var sensorID: String { get }
  var sensorType: SensorType { get }
  var currentState: SensorState { get }

  func prepare(configuration: SensorConfiguration) async throws
  func startStreaming(on timeline: CaptureTimeline) async throws
  func capturePayload() async throws -> SensorPayload
  func stopStreaming() async
}
```

No production subsystem talks to vendor SDKs except through an `EvidenceSensor` (or a typed adapter that presents as one).

## 3. Lifecycle State Machine

```text
Discover → Configure → Start → Capture → Verify → Commit → Stop → Recover
```

Illegal transitions must fail closed with typed errors; auxiliary sensors must not tear down the optical pipeline.

## 4. Monotonic Timeline (\(t_0\))

- Session start establishes \(t_0\) via a **monotonic process/device timebase** (`CACurrentMediaTime()` or equivalent)
- Wall-clock / GPS / NTP times are **bound labels**, not the sync backbone
- Every `SensorPayload` carries `tSession` relative to \(t_0\)
- Monotonic \(t_0\) keeps multi-sensor samples ordered **within the session timebase**; it does **not** by itself prove wall-clock integrity or resist clock tampering
- Wall-clock binding, trust provenance, and anti-tamper requirements belong in a **separate contract** (telemetry / evidence authenticity), not this timebase alone

## 5. Buffering & Backpressure

- Sensors may buffer bounded frames; overflow policy is drop-oldest with WARN telemetry
- Primary optical path has priority under thermal/memory pressure
- Coordinator owns flush-on-commit semantics

## 6. Failure Isolation

Decisions are **level-scoped**: capture-point outcomes may differ from session/export outcomes.

| Failure class | Capture-level | Session / export-level |
|---|---|---|
| Optional location / heading timeout | `WARN`; optical commit may proceed | Usually does not block export |
| Optional IMU sample gap | `WARN` or quality `WARN` per policy | Per quality policy |
| Optional depth unavailable | Spatial channel skipped; still path unaffected | Spatial export channel omitted |
| Optional thermal adapter disconnect | External channel stops; optical unaffected | Thermal channel omitted |
| Sensor marked **required** by workflow | `BLOCK_CAPTURE` (point incomplete; not a silent `WARN`) | `BLOCK_EXPORT` until resolved or explicitly waived |
| Optical pipeline failure | `BLOCK_CAPTURE` / abort commit | `BLOCK_EXPORT` for that point |

Do **not** treat every auxiliary failure as `WARN`. Required-sensor policy elevates to `BLOCK_CAPTURE` and/or `BLOCK_EXPORT`. Capture-level feedback and session/export completeness are separate decision scopes.

## 7. Verification Hook

Before Commit, packaging runs deterministic checks (metadata completeness, calibration availability honesty, quality policy stage). Results attach to the artifact as structured telemetry — not free-text AI summaries.

## 8. Relation to Phase 1

Phase 1 still capture remains the optical baseline. This framework **wraps and extends** it; it does not replace Phase 1A package contracts.
