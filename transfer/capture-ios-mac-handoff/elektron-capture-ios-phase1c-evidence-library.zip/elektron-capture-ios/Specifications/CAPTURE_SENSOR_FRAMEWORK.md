# CAPTURE SENSOR FRAMEWORK CONTRACT

| Field | Value |
|---|---|
| Status | **DRAFT** |
| Depends on | `ELEKTRON_CAPTURE_V2_SPEC.md`, `CAPTURE_V2_DOMAIN_MODEL.md` |
| Next | `CAPTURE_DEVICE_CAPABILITY_MATRIX.md` |

## 1. Purpose

Guarantee every hardware or software provider — AVFoundation, CoreMotion, ARKit depth, CoreLocation, external thermal — conforms to identical **lifecycle, buffering, timestamp, and failure-handling** conventions.

## 2. Universal Interface

```swift
public protocol EvidenceSensor: AnyObject {
  var sensorID: String { get }
  var sensorType: SensorType { get }
  var currentState: SensorState { get }

  func prepare(configuration: SensorConfiguration) async throws
  func startStreaming(on timeline: CaptureTimeline) async throws
  func capturePayload() async throws -> SensorPayload
  func stopStreaming() async
}
```

No production subsystem talks to vendor SDKs except through an `EvidenceSensor` (or a typed adapter that presents as one).

## 3. Lifecycle State Machine

```text
Discover → Configure → Start → Capture → Verify → Commit → Stop → Recover
```

Illegal transitions must fail closed with typed errors; auxiliary sensors must not tear down the optical pipeline.

## 4. Monotonic Timeline (\(t_0\))

- Session start establishes \(t_0\) via monotonic clock (`CACurrentMediaTime()` or equivalent)
- Wall-clock / GPS / NTP times are **bound labels**, not the sync backbone
- Every `SensorPayload` carries `tSession` relative to \(t_0\)
- Prevents drift/tampering of wall clock during a session from desynchronizing streams

## 5. Buffering & Backpressure

- Sensors may buffer bounded frames; overflow policy is drop-oldest with WARN telemetry
- Primary optical path has priority under thermal/memory pressure
- Coordinator owns flush-on-commit semantics

## 6. Failure Isolation

| Failure class | Effect on primary still capture |
|---|---|
| Location / heading timeout | WARN; optical commit may proceed |
| IMU sample gap | WARN or quality WARN per policy |
| Depth unavailable | Spatial channel skipped; still path unaffected |
| Thermal adapter disconnect | External channel stops; optical unaffected |
| Optical pipeline failure | BLOCK / abort commit |

## 7. Verification Hook

Before Commit, packaging runs deterministic checks (metadata completeness, calibration availability honesty, quality policy stage). Results attach to the artifact as structured telemetry — not free-text AI summaries.

## 8. Relation to Phase 1

Phase 1 still capture remains the optical baseline. This framework **wraps and extends** it; it does not replace Phase 1A package contracts.
