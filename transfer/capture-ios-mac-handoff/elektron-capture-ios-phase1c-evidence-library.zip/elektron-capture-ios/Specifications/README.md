# Specifications — Elektron Capture v2+

Locked engineering specification suite. **Not** compiled by SPM.

Authoring order after Phase 1 freeze (`v1.0.0-phase1c`):

1. `ELEKTRON_CAPTURE_V2_SPEC.md`
2. `CAPTURE_V2_DOMAIN_MODEL.md`
3. `CAPTURE_SENSOR_FRAMEWORK.md`
4. `CAPTURE_DEVICE_CAPABILITY_MATRIX.md` *(pending)*
5. `CAPTURE_TELEMETRY_CONTRACT.md` *(pending)*
6. `CAPTURE_QUALITY_POLICY.md` *(pending)*
7. `SPATIAL_COORDINATE_SYSTEMS.md` *(pending)*
8. `SPATIAL_EVIDENCE_CONTRACT.md` *(pending)*
9. `EXTERNAL_SENSOR_ADAPTER_CONTRACT.md` *(pending)*
10. `GITHUB_INTEGRATION_REVIEW_TEMPLATE.md` *(pending — see Research IR template)*
