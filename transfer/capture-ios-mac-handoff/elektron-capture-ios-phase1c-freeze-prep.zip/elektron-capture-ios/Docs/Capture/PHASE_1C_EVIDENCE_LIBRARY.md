# Phase 1C — Persistent Local Evidence Library (Revised)

**Status:** `PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE`  
**Freeze protocol:** `PHASE_1C_FREEZE_COMMIT_SEPARATION.md` (Commit A = validation + CHANGE-0001 + Phase 1 changelog; no v2 specs in tag)

## Authority model

| Layer | Role |
|---|---|
| `captures/<id>/artifact_original.jpg` | **Local source of truth** (immutable) |
| Index `index.json` | Rebuildable **catalog only** — never authoritative over files |
| Documents `.edts-pkg` | **Portable** evidence record (Phase 1A/1B contract unchanged) |

## Directory layout

```text
Application Support/EvidenceLibrary/
  index.json
  .staging/<capture-id>-<uuid>/     # incomplete writes only
  .quarantine/                      # unrecognized / failed staging (never auto-deleted)
  captures/<capture-id>/
    artifact_original.jpg
    thumbnail.jpg                   # derived, non-authoritative
    library_status.json
    manifest.json … sidecars/
    exports/
      <capture-id>.edts-pkg
      <capture-id>.edts-pkg.sha256
```

## Staging commit protocol

1. Create `.staging/<capture-id>-<uuid>/`
2. Write `artifact_original.jpg` with exclusive create
3. Write metadata + thumbnail (thumbnail failure does **not** delete original)
4. Read-back: non-empty + SHA-256 == frozen approved hash
5. Atomic rename → `captures/<capture-id>/`
6. Update index with `storageState = STORED_LOCALLY`

UI must **not** assert `STORED_LOCALLY` until steps 4–5 succeed.

## Multi-dimensional state

```text
captureState   · storageState · packageState · exportState · integrityState
```

These dimensions stay orthogonal — integrity failure does not rewrite capture lifecycle.

## Index paths

Only **library-root-relative** paths are stored, e.g.  
`captures/<id>/artifact_original.jpg` — resolved at runtime via Application Support.

## Invariants (summary)

1. Index non-authoritative  
2. Relative paths only  
3. Orthogonal state dimensions  
4. Strict storage gate (read-back SHA)  
5. Write-once original / new id on retake  
6. Package must match canonical JPEG or `packageState=CREATION_FAILED` + integrity mismatch  
7. Non-destructive failures (never delete original on thumbnail/package/index errors)  
8. Thumbnail isolated / retryable  
9. Conservative recovery — quarantine, never auto-delete  
10. Phase 1A `.edts-pkg` schemas preserved  

## Physical-device acceptance (manual)

1. Capture & approve → appears in library (`STORED_LOCALLY`)  
2. Detail view: Capture ID + original SHA-256  
3. Force-quit + reopen → persists  
4. Device restart + reopen → persists  
5. Airplane Mode → fully accessible offline  
6. Second capture → unique IDs + SHA; first untouched  
7. Export `.edts-pkg` → extract `payload/artifact_original.jpg` → SHA == library original  
8. Cancel Share Sheet → library untouched  

## Hard gates for `PHASE_1C_COMPLETE`

```text
[✓] Domain abstraction: PackageRelativePath.swift (Canonical Identity Pattern)
[✓] Error library: Docs/ErrorLibrary/ERR-EDTS-0007.md
[✓] Invariant tests: CanonicalPackageIdentityTests + CanonicalPathInvariantTests
[✓] 1. Local CLI:  swift test → 89 tests, 0 failures (Mac, ZIP-attested)
[✓] 2. Xcode app:  Phase1StillCapture.xcworkspace build (operator-attested)
[ ] 3. Physical matrix with cited evidence paths/IDs in PHASE_1C_FINAL_VALIDATION.md
[ ] 4. Full 64-char digests recorded (manifest / independent JPEG / .edts-pkg)
[ ] 5. Inventory equivalence PASS (ZIP vs authoritative Git checkout)
[ ] 6. Commit A (validation doc only) + annotated tag v1.0.0-phase1c on origin
```

Only after **all** gates above may status become `PHASE_1C_COMPLETE`.  
Do **not** include `Specifications/` or `Research/` in Commit A / freeze tag.

## Tests

```bash
swift test --filter EvidenceLibraryTests
swift test --filter CanonicalPackageIdentityTests
swift test --filter CanonicalPathInvariantTests
swift test
```
