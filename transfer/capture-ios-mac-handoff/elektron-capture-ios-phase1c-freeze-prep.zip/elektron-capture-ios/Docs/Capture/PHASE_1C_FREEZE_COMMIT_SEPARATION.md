# Phase 1C — Commit Separation & Equivalence Protocol

**Current status:**  
`PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE`

Mixing Phase 1 freeze evidence with Capture v2 specification files in a single commit would pollute tag `v1.0.0-phase1c` and invalidate it as a clean Phase 1 baseline.

## Status pipeline

```text
[Current]
PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE
       │
       ├── 1. Inventory integrity & equivalence check (ZIP vs Git checkout)
       ├── 2. Commit A — Phase 1 freeze only (see allowed list)
       ├── 3. Tag v1.0.0-phase1c & push
       │
       ▼
PHASE_1C_COMPLETE_PENDING_REMOTE_TAG_CONFIRMATION
       │
       ├── 4. Verify remote tag on origin / GitHub
       │
       ▼
PHASE_1C_COMPLETE / PHASE_1_FROZEN  (tag: v1.0.0-phase1c)
       │
       ├── 5. Commit B — v2 governance + Specifications/ + Research/ + CHANGE-0002
       └── 6. Later CHANGE-0003 only after architectural review (baseline + IR-0001 auth)
```

## Branch intent (this freeze-prep tree)

| Item | Rule |
|---|---|
| Baseline tip | `88d9a9b` (Canonical Identity / Phase 1C code — **no** `Specifications/` or `Research/`) |
| Commit A contents | Phase 1 freeze artifacts only (see allowed list) — **no** v2 specs |
| Tag `v1.0.0-phase1c` | Must point at Commit A |
| Commit B | Applied **after** remote tag confirmation only |

**Do not** add `Specifications/`, `Research/`, `CHANGE-0002`, or v2 handoff automation until Commit B.

### Commit A — allowed

```text
CHANGELOG.md
Docs/Changes/CHANGE-0001-phase1c-freeze-preparation.md
Docs/Capture/PHASE_1C_FINAL_VALIDATION.md
Phase 1 validation evidence references
Phase 1 status corrections
```

### Commit A — not allowed

```text
Specifications/
Research/
IR-0001/
CHANGE-0002 covering Specs 1–6
v2 baseline promotion records
Docs/Changes/TEMPLATE.md
```

---

## Step 1 — Verification & equivalence (authoritative Mac clone)

### 1A. Host & device metadata

```bash
sw_vers
uname -m
xcrun devicectl list devices
```

Record exact outputs into `PHASE_1C_FINAL_VALIDATION.md`. Do not invent models, OS builds, or IDs.

### 1B. Git identity

```bash
cd /path/to/actual/elektron-capture-ios-git-repository

git status --short
git branch --show-current
git rev-parse HEAD
git remote -v
git remote get-url origin
```

### 1C. SHA-256 inventory equivalence (ZIP vs Git)

Exclude `.git`, `.build`, DerivedData, and the validation doc itself (it is Commit A’s payload):

```bash
# Authoritative Git working tree
find . \
  -type f \
  ! -path './.git/*' \
  ! -path './.build/*' \
  ! -path './Docs/Evidence/*/DerivedData/*' \
  ! -name 'PHASE_1C_FINAL_VALIDATION.md' \
  -print0 |
sort -z |
xargs -0 shasum -a 256 > /tmp/authoritative-repo-inventory.sha256

# Validated unzipped snapshot (89/0 Mac suite)
find /path/to/unzipped/validated-snapshot \
  -type f \
  ! -path '*/.git/*' \
  ! -path '*/.build/*' \
  ! -path '*/Docs/Evidence/*/DerivedData/*' \
  ! -name 'PHASE_1C_FINAL_VALIDATION.md' \
  -print0 |
sort -z |
xargs -0 shasum -a 256 > /tmp/validated-zip-inventory.sha256

diff -u /tmp/validated-zip-inventory.sha256 /tmp/authoritative-repo-inventory.sha256
```

**Gate:** `diff -u` must show **zero** structural/code payload drift before Commit A.  
If the validated ZIP still contains accidental `Specifications/` / `Research/` from a polluted handoff, use a Phase 1–only snapshot (this freeze-prep tip) as the equivalence reference — never tag a tree that mixes v2 scaffolding into Commit A.

---

## Step 2 — Commit A (Phase 1 baseline lock)

Fill `PHASE_1C_FINAL_VALIDATION.md` with **real** terminal/device evidence only (full 64-char digests; no truncated hashes; no placeholder paths marked as `VERIFIED_PASS`).

Ensure Commit A stages only Phase 1 freeze artifacts:

```bash
cd /path/to/actual/elektron-capture-ios-git-repository

git add \
  CHANGELOG.md \
  Docs/Changes/CHANGE-0001-phase1c-freeze-preparation.md \
  PHASE_1C_FINAL_VALIDATION.md \
  Docs/Capture/PHASE_1C_FINAL_VALIDATION.md

# Reject if Specifications/, Research/, or CHANGE-0002 appear in the index
git diff --cached --name-only | grep -E '^(Specifications/|Research/|Docs/Changes/CHANGE-0002)' && exit 1

git commit -m "docs: Phase 1C Commit A — validation, CHANGE-0001, freeze isolation"

git tag -a v1.0.0-phase1c -m "Freeze Phase 1C Still Capture baseline"

git show --stat --decorate v1.0.0-phase1c
git rev-parse 'v1.0.0-phase1c^{commit}'
git status --short

git push origin HEAD
git push origin v1.0.0-phase1c
```

**Checkpoint:** Confirm on GitHub that `v1.0.0-phase1c` exists and points at Commit A.  
Then set status → `PHASE_1C_COMPLETE` / `PHASE_1_FROZEN` and enable branch/tag protection.  
There is **no** `git lock-branch` command.

After Commit A lands locally (before or after push), interim status may be recorded as:

`PHASE_1C_COMPLETE_PENDING_REMOTE_TAG_CONFIRMATION`

---

## Step 3 — Commit B (v2 governance and specifications — after remote tag)

Only after remote tag confirmation. Commit B may include:

```text
Docs/Changes/TEMPLATE.md
Docs/Changes/CHANGE-0002-v2-specification-hardening.md
Specifications/
Research/
IR-0001 scaffolding
architecture index
entity/state registry
handoff automation
PR-template governance
```

`CHANGE-0002` title and status must remain:

```text
Capture v2 Specifications 1–6 hardening and twelve-point correction pass
IMPLEMENTED / FINAL_ARCHITECTURAL_REVIEW_PENDING / NOT_BASELINE_APPROVED
```

Do **not** record baseline approval in `CHANGE-0002`. That is future `CHANGE-0003` after review.

---

## Prepared staging (not in this freeze-prep branch)

Capture v2 Specs 1–6, Research/IR-0001 scaffolding, and handoff governance were prepared on branch `cursor/phase1c-evidence-library-d881` for **post-tag** application.  
**Do not merge those files into Commit A or into tag `v1.0.0-phase1c`.**
