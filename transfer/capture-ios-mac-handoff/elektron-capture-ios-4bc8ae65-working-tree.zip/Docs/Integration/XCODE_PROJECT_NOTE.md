# Xcode project note

## Runnable iPhone app (Phase 1)

Open the thin host (does not duplicate capture logic):

```text
Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj
```

That app target links the **local** Swift package product `ElektronCapture`
(`Package.swift` at the repository root via relative path `../../`).

## Library / tests only

`Package.swift` still exposes the reusable library and unit tests. Opening
`Package.swift` alone does **not** install an app on a physical iPhone.

## Rules

1. Do not copy `App/` or `Contracts/` sources into the Xcode app target.
2. Do not point at a remote package URL for `ElektronCapture`.
3. Do not commit `xcuserdata/` or DerivedData.
4. Full AVFoundation / ARKit features beyond Phase 1 remain deferred per CAP-IOS-ADR-0004.

See `Docs/PHYSICAL_IPHONE_VALIDATION_RUNBOOK.md`.
