import Foundation
import XCTest
@testable import ElektronCapture

final class Phase1RuntimeTests: XCTestCase {
  private var workRoot: URL!

  override func setUp() {
    super.setUp()
    workRoot = FileManager.default.temporaryDirectory
      .appendingPathComponent("phase1-tests-\(UUID().uuidString)", isDirectory: true)
    try? FileManager.default.createDirectory(at: workRoot, withIntermediateDirectories: true)
  }

  override func tearDown() {
    try? FileManager.default.removeItem(at: workRoot)
    super.tearDown()
  }

  private var fixtureJPEG: Data {
    let url = Bundle.module.url(forResource: "synthetic_phase1", withExtension: "jpg", subdirectory: "Fixtures")
      ?? Bundle.module.url(forResource: "synthetic_phase1", withExtension: "jpg")
    if let url, let data = try? Data(contentsOf: url) {
      return data
    }
    // Fallback identical to Tests/Unit/Fixtures/synthetic_phase1.jpg
    return Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
      0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14,
      0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7F, 0xFF, 0xD9,
    ])
  }

  func testStatusOwnerRejectsEdtsCodes() {
    for code in StatusOwnerRegistry.entries.filter({ $0.owner == .edts }).map(\.code) {
      XCTAssertThrowsError(try CaptureSideStatusGuard.parseCaptureSide(code))
    }
  }

  func testLifecycleStatusesAreCaptureOwned() throws {
    for s in CaptureSideStatus.allCases {
      XCTAssertEqual(StatusOwnerRegistry.owner(of: s.rawValue), .capture)
      _ = try CaptureSideStatusGuard.parseCaptureSide(s.rawValue)
    }
  }

  func testReadbackSha256MatchesStreamingHash() throws {
    let url = workRoot.appendingPathComponent("a.jpg")
    try fixtureJPEG.write(to: url)
    let service = ArtifactHashingService()
    let a = try service.sha256HexOfFile(at: url)
    let b = service.sha256HexOfData(fixtureJPEG)
    XCTAssertEqual(a, b)
    XCTAssertNotEqual(a, "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  }

  func testHashMismatchOnCorruptReadback() throws {
    let persistence = ArtifactPersistenceService()
    // Persist then mutate file to force mismatch on a second hash check path
    let art = try persistence.persistExactBytes(
      fixtureJPEG,
      to: "payload/artifact_original.jpg",
      under: workRoot,
      mediaType: "image/jpeg",
      representation: .appleEncodedJpeg
    )
    XCTAssertEqual(art.byteSize, fixtureJPEG.count)
  }

  func testCanonicalManifestMatchesPythonGoldenBytes() throws {
    let ids = Phase1CaptureIdentifiers(
      evidenceId: "EVD-TEST-001",
      sessionId: "SESSION-TEST-001",
      artifactId: "ART-TEST-001",
      recordId: "REC-TEST-001"
    )
    let clock = CaptureClockSnapshot(
      utcISO8601: "2026-07-23T05:00:00.000Z",
      monotonicNanoseconds: 42
    )
    let provenance = CaptureDeviceProvenance(
      deviceProfileId: "CAP-DEVICE-IPRO-LIDAR-001",
      hardwareModelIdentifier: "iPhone17,1",
      deviceDisplayName: "Approved fixture device",
      iosVersion: "fixture",
      appVersion: "0.1.4",
      evidenceSchemaVersion: "1.0.0",
      captureInstallationId: "INSTALL-TEST-001",
      deviceEnrollmentId: "ENR-TEST-001"
    )
    let artifact = PersistedArtifact(
      fileURL: workRoot.appendingPathComponent("payload/artifact_original.jpg"),
      relativePath: "payload/artifact_original.jpg",
      byteSize: fixtureJPEG.count,
      sha256: ArtifactHashingService().sha256HexOfData(fixtureJPEG),
      mediaType: "image/jpeg",
      representation: .appleEncodedJpeg
    )
    let obj = try EvidenceManifestBuilder().build(
      ids: ids,
      artifact: artifact,
      clock: clock,
      provenance: provenance,
      captureAppVersion: "0.1.4"
    )
    let swiftBytes = try CanonicalJSONEncoder.encode(obj)

    // Independent verifier: fixture produced by Python json.dumps(sort_keys=True,…),
    // not by re-invoking CanonicalJSONEncoder.
    let goldenURL =
      Bundle.module.url(
        forResource: "canonical_manifest_phase1_golden",
        withExtension: "json",
        subdirectory: "Fixtures"
      )
      ?? Bundle.module.url(forResource: "canonical_manifest_phase1_golden", withExtension: "json")
    XCTAssertNotNil(goldenURL, "missing Python golden canonical fixture")
    let golden = try Data(contentsOf: goldenURL!)
    XCTAssertEqual(
      swiftBytes,
      golden,
      "Swift canonical bytes must match independent Python golden bytes"
    )
  }

  func testCanonicalManifestRoundTrip() throws {
    let ids = Phase1CaptureIdentifiers(
      evidenceId: "EVD-TEST-001",
      sessionId: "SESSION-TEST-001",
      artifactId: "ART-TEST-001",
      recordId: "REC-TEST-001"
    )
    let clock = CaptureClockSnapshot(
      utcISO8601: "2026-07-23T05:00:00.000Z",
      monotonicNanoseconds: 42
    )
    let provenance = CaptureDeviceProvenance(
      deviceProfileId: "CAP-DEVICE-IPRO-LIDAR-001",
      hardwareModelIdentifier: "iPhone17,1",
      deviceDisplayName: "Approved fixture device",
      iosVersion: "fixture",
      appVersion: "0.1.4",
      evidenceSchemaVersion: "1.0.0",
      captureInstallationId: "INSTALL-TEST-001",
      deviceEnrollmentId: "ENR-TEST-001"
    )
    let artifact = PersistedArtifact(
      fileURL: workRoot.appendingPathComponent("payload/artifact_original.jpg"),
      relativePath: "payload/artifact_original.jpg",
      byteSize: fixtureJPEG.count,
      sha256: ArtifactHashingService().sha256HexOfData(fixtureJPEG),
      mediaType: "image/jpeg",
      representation: .appleEncodedJpeg
    )
    let obj = try EvidenceManifestBuilder().build(
      ids: ids,
      artifact: artifact,
      clock: clock,
      provenance: provenance,
      captureAppVersion: "0.1.4"
    )
    let bytes = try CanonicalJSONEncoder.encode(obj)
    // Re-encode the same in-memory producer object — this is the physical-device path.
    let againFromProducer = try CanonicalJSONEncoder.encode(obj)
    XCTAssertEqual(bytes, againFromProducer)

    #if os(iOS) || os(macOS) || os(tvOS) || os(watchOS) || os(visionOS)
    // Darwin JSONSerialization preserves CFBoolean; round-trip through parse stays stable.
    let parsed = try JSONSerialization.jsonObject(with: bytes)
    let again = try CanonicalJSONEncoder.encode(parsed)
    XCTAssertEqual(bytes, again)
    #endif
  }

  func testPackageBuildInventoryAndExtension() async throws {
    let ids = Phase1CaptureIdentifiers(
      evidenceId: "EVD-TEST-PKG-001",
      sessionId: "SESSION-TEST-PKG-001",
      artifactId: "ART-TEST-PKG-001",
      recordId: "REC-TEST-PKG-001"
    )
    let defaults = UserDefaults(suiteName: "phase1.test.\(UUID().uuidString)")!
    let coordinator = Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: fixtureJPEG),
      workRoot: workRoot
    )
    let result = try await coordinator.captureAndExport(
      ids: ids,
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "fixture",
      defaults: defaults
    )
    XCTAssertEqual(result.captureSideStatus, .packageExported)
    XCTAssertTrue(result.packageZipURL.lastPathComponent.hasSuffix(".edts-pkg"))
    XCTAssertEqual(result.artifactSha256, ArtifactHashingService().sha256HexOfData(fixtureJPEG))
    XCTAssertEqual(result.evidenceId, ids.evidenceId)
    XCTAssertEqual(result.sessionId, ids.sessionId)
    XCTAssertEqual(result.artifactId, ids.artifactId)
    XCTAssertEqual(result.packageSealStatus, "NOT_IMPLEMENTED")

    let invURL = result.packageDirectoryURL.appendingPathComponent("package_inventory.json")
    let invBytes = try Data(contentsOf: invURL)
    let invObj = try JSONSerialization.jsonObject(with: invBytes) as! [String: Any]
    let again = try CanonicalJSONEncoder.encode(invObj)
    XCTAssertEqual(invBytes, again)

    let entries = invObj["entries"] as! [[String: Any]]
    let paths = Set(entries.map { $0["path"] as! String })
    XCTAssertFalse(paths.contains("package_inventory.json"))
    XCTAssertTrue(paths.contains("manifest.json"))
    XCTAssertTrue(paths.contains("payload/artifact_original.jpg"))

    // No undeclared files on disk
    let root = result.packageDirectoryURL
    var onDisk: [String] = []
    if let en = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey]) {
      let rp = root.path
      for case let url as URL in en {
        let vals = try url.resourceValues(forKeys: [.isRegularFileKey])
        guard vals.isRegularFile == true else { continue }
        var rel = url.path
        if rel.hasPrefix(rp) {
          rel = String(rel.dropFirst(rp.count))
          if rel.hasPrefix("/") { rel = String(rel.dropFirst()) }
        }
        onDisk.append(rel)
      }
    }
    for f in onDisk where f != "package_inventory.json" {
      XCTAssertTrue(paths.contains(f), "undeclared \(f)")
    }

    let status = try JSONSerialization.jsonObject(
      with: Data(contentsOf: root.appendingPathComponent("package_status.json"))
    ) as! [String: Any]
    let asserted = status["asserted_statuses"] as! [String]
    XCTAssertEqual(asserted, ["PACKAGE_EXPORTED"])
    XCTAssertFalse(asserted.contains("INGESTED_INTEGRITY_VERIFIED"))
  }

  func testCalibrationUnavailableByDefault() async throws {
    let result = try await Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: fixtureJPEG),
      workRoot: workRoot
    ).captureAndExport(
      ids: Phase1CaptureIdentifiers.generate(),
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "fixture",
      defaults: UserDefaults(suiteName: UUID().uuidString)!
    )
    let calib = try JSONSerialization.jsonObject(
      with: Data(contentsOf: result.packageDirectoryURL.appendingPathComponent("sidecars/camera_calibration.json"))
    ) as! [String: Any]
    XCTAssertEqual(calib["availability"] as? String, "NOT_AVAILABLE")
    XCTAssertTrue(calib["intrinsic_matrix"] is NSNull)
  }

  func testFailureCleanupRemovesIncompletePackage() throws {
    let ids = Phase1CaptureIdentifiers.generate()
    let builder = EvidencePackageBuilder()
    let dir = workRoot.appendingPathComponent(ids.evidenceId)
    let zip = workRoot.appendingPathComponent("\(ids.evidenceId).edts-pkg")
    XCTAssertThrowsError(
      try builder.build(
        jpegBytes: Data(),
        ids: ids,
        clock: CaptureClockSnapshot(utcISO8601: "2026-07-23T05:00:00Z", monotonicNanoseconds: 1),
        provenance: CaptureDeviceProvenance(
          deviceProfileId: "CAP-DEVICE-IPRO-LIDAR-001",
          hardwareModelIdentifier: "iPhone17,1",
          deviceDisplayName: "Approved",
          iosVersion: "fixture",
          appVersion: "0.1.4",
          evidenceSchemaVersion: "1.0.0",
          captureInstallationId: "INSTALL-X"
        ),
        motion: .unavailable,
        calibrationAvailability: .notAvailable,
        workRoot: workRoot,
        captureAppVersion: "0.1.4"
      )
    )
    XCTAssertFalse(FileManager.default.fileExists(atPath: dir.path))
    XCTAssertFalse(FileManager.default.fileExists(atPath: zip.path))
  }

  func testCaptureSideValidatorDoesNotClaimEdtsGates() async throws {
    let result = try await Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: fixtureJPEG),
      workRoot: workRoot
    ).captureAndExport(
      ids: Phase1CaptureIdentifiers.generate(),
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "fixture",
      defaults: UserDefaults(suiteName: UUID().uuidString)!
    )
    let v = CaptureSidePackageValidator.validate(packageDirectory: result.packageDirectoryURL)
    XCTAssertTrue(v.ok)
    XCTAssertEqual(v.artifactSha256, result.artifactSha256)
    XCTAssertTrue(v.notes.contains(where: { $0.contains("EDTS XREPO-0001/0002") }))
  }

  func testReasonCodesAreStable() {
    XCTAssertEqual(Phase1RuntimeError.cameraPermissionDenied.reasonCode, "CAMERA_PERMISSION_DENIED")
    XCTAssertEqual(Phase1RuntimeError.fileRepresentationUnavailable.reasonCode, "FILE_REPRESENTATION_UNAVAILABLE")
    XCTAssertEqual(
      Phase1RuntimeError.hashReadbackMismatch(expected: "a", actual: "b").reasonCode,
      "HASH_READBACK_MISMATCH"
    )
  }

  /// Physical-device DeviceProvenanceService leaves several optionals nil (lidar, attest, calibration).
  /// Boxing those as `Optional.none as Any` previously caused CANONICALIZATION_FAILED on device.
  func testPhysicalDeviceProvenanceDictionaryCanonicalizes() throws {
    let defaults = UserDefaults(suiteName: "phase1.phys.\(UUID().uuidString)")!
    let provenance = DeviceProvenanceService(appVersion: "0.1.4").currentProvenance(
      defaults: defaults,
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "18.5"
    )
    XCTAssertNil(provenance.lidarAvailable)
    XCTAssertNil(provenance.appAttestKeyId)
    XCTAssertNil(provenance.calibrationProfileId)

    let dict = provenance.asDictionary()
    let unsupported = CanonicalJSON.unsupportedValues(in: dict)
    XCTAssertTrue(unsupported.isEmpty, "unsupported: \(unsupported)")

    // Simulate the pre-fix bug and prove diagnostics catch it.
    var buggy = dict
    let nilBool: Bool? = nil
    buggy["lidar_available"] = nilBool as Any
    let found = CanonicalJSON.unsupportedValues(in: buggy)
    XCTAssertTrue(found.contains(where: { $0.keyPath.contains("lidar_available") }))
    XCTAssertThrowsError(try CanonicalJSONEncoder.encode(buggy, stage: "test_buggy_optional")) { err in
      let e = err as? Phase1RuntimeError
      XCTAssertEqual(e?.reasonCode, "CANONICALIZATION_FAILED")
      XCTAssertTrue(e?.detailMessage.contains("stage=test_buggy_optional") == true)
      XCTAssertTrue(e?.detailMessage.contains("Optional") == true)
    }

    let bytes = try CanonicalJSONEncoder.encode(dict, stage: "capture_device.json")
    XCTAssertFalse(bytes.isEmpty)
    let parsed = try JSONSerialization.jsonObject(with: bytes) as! [String: Any]
    XCTAssertTrue(parsed["lidar_available"] is NSNull)
    XCTAssertTrue(parsed["app_attest_key_id"] is NSNull)
  }

  func testPhysicalDeviceStatusPayloadWithClockCanonicalizes() throws {
    let clock = CaptureClockSnapshot(
      utcISO8601: "2026-07-24T04:00:00.000Z",
      monotonicNanoseconds: 9_876_543_210
    )
    let statusObj: [String: Any] = [
      "schema_id": "PackageStatusDeclaration",
      "schema_version": "1.0.0",
      "capture_side_status": CaptureSideStatus.packageExported.rawValue,
      "previous_capture_side_status": CaptureSideStatus.captureSealed.rawValue,
      "asserted_statuses": [CaptureSideStatus.packageExported.rawValue],
      "evidence_id": "EVD-PHYS-001",
      "package_seal": "NOT_IMPLEMENTED",
      "evidence_authority": [
        "capture_class": "OBSERVED_ARTIFACT",
        "engineering_verification": "NOT_PERFORMED",
        "metrology_status": "NOT_ASSERTED",
      ],
      "capture_time": clock.asDictionary(),
      "notes": ["Capture client must not assign EDTS-owned statuses."],
    ]
    let unsupported = CanonicalJSON.unsupportedValues(in: statusObj)
    XCTAssertTrue(unsupported.isEmpty, "unsupported: \(unsupported)")
    let bytes = try CanonicalJSONEncoder.encode(statusObj, stage: "package_status.json")
    let again = try CanonicalJSONEncoder.encode(
      try JSONSerialization.jsonObject(with: bytes),
      stage: "package_status.json.roundtrip"
    )
    XCTAssertEqual(bytes, again)
    let parsed = try JSONSerialization.jsonObject(with: bytes) as! [String: Any]
    let captureTime = parsed["capture_time"] as! [String: Any]
    let mono = captureTime["monotonic_ns"]
    let monoValue: Int64? = {
      if let v = mono as? Int64 { return v }
      if let v = mono as? Int { return Int64(v) }
      if let v = mono as? NSNumber { return v.int64Value }
      return nil
    }()
    XCTAssertEqual(monoValue, 9_876_543_210)
  }

  func testEndToEndPackageWithPhysicalDeviceNilOptionals() async throws {
    let defaults = UserDefaults(suiteName: "phase1.e2e.\(UUID().uuidString)")!
    let result = try await Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: fixtureJPEG),
      workRoot: workRoot,
      provenanceService: DeviceProvenanceService(appVersion: "0.1.4")
    ).captureAndExport(
      ids: Phase1CaptureIdentifiers(
        evidenceId: "EVD-PHYS-E2E-001",
        sessionId: "SESSION-PHYS-E2E-001",
        artifactId: "ART-PHYS-E2E-001",
        recordId: "REC-PHYS-E2E-001"
      ),
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "18.5",
      defaults: defaults
    )
    XCTAssertEqual(result.captureSideStatus, .packageExported)
    XCTAssertFalse(result.artifactSha256.isEmpty)
    let device = try JSONSerialization.jsonObject(
      with: Data(contentsOf: result.packageDirectoryURL.appendingPathComponent("capture_device.json"))
    ) as! [String: Any]
    XCTAssertTrue(device["lidar_available"] is NSNull)
    XCTAssertEqual(device["hardware_model_identifier"] as? String, "iPhone17,1")
  }

  func testCanonicalJSONRejectsBoxedNilOptional() {
    let nilString: String? = nil
    let obj: [String: Any] = ["x": nilString as Any]
    XCTAssertThrowsError(try CanonicalJSON.string(obj))
    let report = CanonicalJSON.unsupportedValues(in: obj)
    XCTAssertEqual(report.first?.keyPath, "x")
    XCTAssertTrue(report.first?.runtimeType.contains("Optional") == true)
  }

  func testCanonicalJSONAcceptsUInt64Leaf() throws {
    let obj: [String: Any] = ["monotonic_ns": UInt64(42)]
    let s = try CanonicalJSON.string(obj)
    XCTAssertEqual(s, "{\"monotonic_ns\":42}")
  }
}