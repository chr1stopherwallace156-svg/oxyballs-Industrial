#if canImport(AVFoundation) && canImport(UIKit)
import AVFoundation
import Foundation
import UIKit

public final class CameraAuthorizationService: @unchecked Sendable {
  public init() {}

  public func authorizationStatus() -> AVAuthorizationStatus {
    AVCaptureDevice.authorizationStatus(for: .video)
  }

  public func requestAccessIfNeeded() async throws {
    switch authorizationStatus() {
    case .authorized:
      return
    case .notDetermined:
      let granted = await AVCaptureDevice.requestAccess(for: .video)
      if !granted { throw Phase1RuntimeError.cameraPermissionDenied }
    case .denied, .restricted:
      throw Phase1RuntimeError.cameraPermissionDenied
    @unknown default:
      throw Phase1RuntimeError.cameraPermissionDenied
    }
  }
}

public final class CameraSessionController: NSObject, @unchecked Sendable {
  public let session = AVCaptureSession()
  private let sessionQueue = DispatchQueue(label: "elektron.capture.session")

  public override init() {
    super.init()
  }

  public func configureForStillCapture() throws {
    session.beginConfiguration()
    defer { session.commitConfiguration() }
    session.sessionPreset = .photo

    session.inputs.forEach { session.removeInput($0) }
    session.outputs.forEach { session.removeOutput($0) }

    guard
      let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
    else {
      throw Phase1RuntimeError.cameraConfigurationFailed("no rear wide camera")
    }
    let input: AVCaptureDeviceInput
    do {
      input = try AVCaptureDeviceInput(device: device)
    } catch {
      throw Phase1RuntimeError.cameraConfigurationFailed(String(describing: error))
    }
    guard session.canAddInput(input) else {
      throw Phase1RuntimeError.cameraConfigurationFailed("cannot add camera input")
    }
    session.addInput(input)
  }

  public func start() {
    sessionQueue.async { [session] in
      if !session.isRunning { session.startRunning() }
    }
  }

  public func stop() {
    sessionQueue.async { [session] in
      if session.isRunning { session.stopRunning() }
    }
  }
}

public final class StillPhotoCaptureService: NSObject, StillPhotoCaptureProviding, @unchecked Sendable {
  private let auth: CameraAuthorizationService
  private let controller: CameraSessionController
  private let photoOutput = AVCapturePhotoOutput()
  private var continuation: CheckedContinuation<Data, Error>?

  public init(
    auth: CameraAuthorizationService = CameraAuthorizationService(),
    controller: CameraSessionController = CameraSessionController()
  ) {
    self.auth = auth
    self.controller = controller
    super.init()
  }

  public func captureProcessedJPEG() async throws -> Data {
    try await auth.requestAccessIfNeeded()
    try controller.configureForStillCapture()
    if controller.session.canAddOutput(photoOutput) {
      controller.session.addOutput(photoOutput)
    } else if !controller.session.outputs.contains(where: { $0 === photoOutput }) {
      throw Phase1RuntimeError.cameraConfigurationFailed("cannot add photo output")
    }
    // Prefer JPEG processed file representation — never claim RAW.
    if #available(iOS 16.0, *) {
      photoOutput.maxPhotoQualityPrioritization = .quality
    }
    controller.start()
    // Brief settle for session
    try await Task.sleep(nanoseconds: 250_000_000)

    return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Data, Error>) in
      self.continuation = cont
      let settings = AVCapturePhotoSettings()
      // Request JPEG by setting available codec when possible.
      if photoOutput.availablePhotoCodecTypes.contains(.jpeg) {
        let s = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
        self.photoOutput.capturePhoto(with: s, delegate: self)
      } else {
        self.photoOutput.capturePhoto(with: settings, delegate: self)
      }
    }
  }
}

extension StillPhotoCaptureService: AVCapturePhotoCaptureDelegate {
  public func photoOutput(
    _ output: AVCapturePhotoOutput,
    didFinishProcessingPhoto photo: AVCapturePhoto,
    error: Error?
  ) {
    if let error {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "capture_failure",
        detail: [
          "swiftErrorType=\(String(describing: type(of: error)))",
          "describing=\(String(describing: error))",
          "reflecting=\(String(reflecting: error))",
          "localizedDescription=\(error.localizedDescription)",
        ].joined(separator: " | ")
      )
      continuation?.resume(throwing: Phase1RuntimeError.photoCaptureFailed(error.localizedDescription))
      continuation = nil
      controller.stop()
      return
    }
    // Exact file representation bytes — do not UIImage round-trip.
    // Log counts/types only — never full image bytes or sensitive EXIF payloads.
    let meta = photo.metadata
    let metaKeyCount = meta.count
    let metaKeySample = Array(meta.keys.prefix(12)).map { String(describing: $0) }
    let hasEmbeddedThumbnail = photo.embeddedThumbnailPhotoFormat != nil
    if let data = photo.fileDataRepresentation() {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "fileDataRepresentation_ok",
        detail: [
          "byteCount=\(data.count)",
          "metadataKeyCount=\(metaKeyCount)",
          "metadataKeySample=\(metaKeySample)",
          "embeddedThumbnailPresent=\(hasEmbeddedThumbnail)",
          "note=JPEG bytes not logged",
        ].joined(separator: " | ")
      )
      continuation?.resume(returning: data)
    } else {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "file_representation_unavailable",
        detail: [
          "metadataKeyCount=\(metaKeyCount)",
          "metadataKeySample=\(metaKeySample)",
          "embeddedThumbnailPresent=\(hasEmbeddedThumbnail)",
        ].joined(separator: " | ")
      )
      continuation?.resume(throwing: Phase1RuntimeError.fileRepresentationUnavailable)
    }
    continuation = nil
    controller.stop()
  }
}
#endif
