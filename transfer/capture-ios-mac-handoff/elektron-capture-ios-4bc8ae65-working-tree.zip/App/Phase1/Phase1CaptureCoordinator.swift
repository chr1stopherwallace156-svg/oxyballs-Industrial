import Foundation

/// Injectable still-photo source (real AVFoundation on device; fixture in tests).
public protocol StillPhotoCaptureProviding: Sendable {
  func captureProcessedJPEG() async throws -> Data
}

/// Fixture provider for unit/integration tests — exact bytes, no re-encode path.
public struct FixtureStillPhotoCaptureService: StillPhotoCaptureProviding {
  public var jpegBytes: Data
  public init(jpegBytes: Data) {
    self.jpegBytes = jpegBytes
  }
  public func captureProcessedJPEG() async throws -> Data {
    jpegBytes
  }
}

public struct Phase1CaptureCoordinator: Sendable {
  public var appVersion: String
  public var photoCapture: any StillPhotoCaptureProviding
  public var clock: CaptureClockService
  public var provenanceService: DeviceProvenanceService
  public var motionService: MotionSampleService
  public var packageBuilder: EvidencePackageBuilder
  public var workRoot: URL

  public init(
    appVersion: String,
    photoCapture: any StillPhotoCaptureProviding,
    workRoot: URL,
    clock: CaptureClockService = CaptureClockService(),
    provenanceService: DeviceProvenanceService? = nil,
    motionService: MotionSampleService = MotionSampleService(),
    packageBuilder: EvidencePackageBuilder = EvidencePackageBuilder()
  ) {
    self.appVersion = appVersion
    self.photoCapture = photoCapture
    self.workRoot = workRoot
    self.clock = clock
    self.provenanceService = provenanceService ?? DeviceProvenanceService(appVersion: appVersion)
    self.motionService = motionService
    self.packageBuilder = packageBuilder
  }

  /// Full Phase 1 pipeline to PACKAGE_EXPORTED. Does not assign EDTS statuses.
  public func captureAndExport(
    ids: Phase1CaptureIdentifiers = .generate(),
    motionInjected: MotionSampleRecord? = nil,
    hardwareModelOverride: String? = nil,
    iosVersionOverride: String? = nil,
    defaults: UserDefaults = .standard
  ) async throws -> Phase1PackageResult {
    // Lifecycle: CREATED
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureCreated.rawValue)

    let jpeg: Data
    do {
      jpeg = try await photoCapture.captureProcessedJPEG()
      Phase1CaptureDiagnostics.log(
        stage: "photo_bytes",
        event: "received",
        detail: "byteCount=\(jpeg.count) empty=\(jpeg.isEmpty)"
      )
    } catch let e as Phase1RuntimeError {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture",
        event: "failed",
        detail: "reason=\(e.reasonCode) detail=\(e.detailMessage)"
      )
      throw e
    } catch {
      throw Phase1RuntimeError.photoCaptureFailed(String(describing: error))
    }
    guard !jpeg.isEmpty else {
      throw Phase1RuntimeError.fileRepresentationUnavailable
    }

    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.capturePersisted.rawValue)
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureHashed.rawValue)
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureSealed.rawValue)

    let clockSnap = clock.snapshot()
    let provenance = provenanceService.currentProvenance(
      defaults: defaults,
      hardwareModelOverride: hardwareModelOverride,
      iosVersionOverride: iosVersionOverride
    )
    let motion = motionService.sample(injected: motionInjected)

    let result = try packageBuilder.build(
      jpegBytes: jpeg,
      ids: ids,
      clock: clockSnap,
      provenance: provenance,
      motion: motion,
      calibrationAvailability: .notAvailable,
      workRoot: workRoot,
      captureAppVersion: appVersion,
      previousStatus: .captureSealed
    )
    return result
  }
}
