import Foundation

public struct Phase1PackageResult: Equatable, Sendable {
  public var packageDirectoryURL: URL
  public var packageZipURL: URL
  public var packageId: String
  public var evidenceId: String
  public var sessionId: String
  public var artifactId: String
  public var artifactSha256: String
  public var artifactByteSize: Int
  public var captureSideStatus: CaptureSideStatus
  public var packageSealStatus: String

  public init(
    packageDirectoryURL: URL,
    packageZipURL: URL,
    packageId: String,
    evidenceId: String,
    sessionId: String,
    artifactId: String,
    artifactSha256: String,
    artifactByteSize: Int,
    captureSideStatus: CaptureSideStatus,
    packageSealStatus: String = "NOT_IMPLEMENTED"
  ) {
    self.packageDirectoryURL = packageDirectoryURL
    self.packageZipURL = packageZipURL
    self.packageId = packageId
    self.evidenceId = evidenceId
    self.sessionId = sessionId
    self.artifactId = artifactId
    self.artifactSha256 = artifactSha256
    self.artifactByteSize = artifactByteSize
    self.captureSideStatus = captureSideStatus
    self.packageSealStatus = packageSealStatus
  }
}

public struct EvidencePackageBuilder: Sendable {
  public var manifestBuilder: EvidenceManifestBuilder
  public var inventoryBuilder: PackageInventoryBuilder
  public var persistence: ArtifactPersistenceService

  public init(
    manifestBuilder: EvidenceManifestBuilder = EvidenceManifestBuilder(),
    inventoryBuilder: PackageInventoryBuilder = PackageInventoryBuilder(),
    persistence: ArtifactPersistenceService = ArtifactPersistenceService()
  ) {
    self.manifestBuilder = manifestBuilder
    self.inventoryBuilder = inventoryBuilder
    self.persistence = persistence
  }

  /// Assembles a Phase 1 `.edts-pkg` directory + zip from exact JPEG bytes already captured.
  public func build(
    jpegBytes: Data,
    ids: Phase1CaptureIdentifiers,
    clock: CaptureClockSnapshot,
    provenance: CaptureDeviceProvenance,
    motion: MotionSampleRecord,
    calibrationAvailability: CameraCalibrationAvailability,
    workRoot: URL,
    captureAppVersion: String,
    previousStatus: CaptureSideStatus = .captureSealed
  ) throws -> Phase1PackageResult {
    let fm = FileManager.default
    let dir = workRoot.appendingPathComponent(ids.evidenceId, isDirectory: true)
    let finalZip = workRoot.appendingPathComponent("\(ids.evidenceId).edts-pkg")
    // Clean incomplete leftovers
    try? fm.removeItem(at: dir)
    try? fm.removeItem(at: finalZip)
    try fm.createDirectory(at: dir, withIntermediateDirectories: true)

    do {
      _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureCreated.rawValue)

      let artifact = try persistence.persistExactBytes(
        jpegBytes,
        to: "payload/artifact_original.jpg",
        under: dir,
        mediaType: "image/jpeg",
        representation: .appleEncodedJpeg
      )

      let manifestObj = try manifestBuilder.build(
        ids: ids,
        artifact: artifact,
        clock: clock,
        provenance: provenance,
        captureAppVersion: captureAppVersion
      )
      let manifestBytes = try CanonicalJSONEncoder.encode(manifestObj, stage: "manifest.json")
      try writeOnce(manifestBytes, to: dir.appendingPathComponent("manifest.json"))

      let deviceBytes = try CanonicalJSONEncoder.encode(
        provenance.asDictionary(),
        stage: "capture_device.json"
      )
      try writeOnce(deviceBytes, to: dir.appendingPathComponent("capture_device.json"))

      let statusObj: [String: Any] = [
        "schema_id": "PackageStatusDeclaration",
        "schema_version": "1.0.0",
        "capture_side_status": CaptureSideStatus.packageExported.rawValue,
        "previous_capture_side_status": previousStatus.rawValue,
        "asserted_statuses": [CaptureSideStatus.packageExported.rawValue],
        "evidence_id": ids.evidenceId,
        "package_seal": "NOT_IMPLEMENTED",
        "evidence_authority": [
          "capture_class": "OBSERVED_ARTIFACT",
          "engineering_verification": "NOT_PERFORMED",
          "metrology_status": "NOT_ASSERTED",
        ],
        "capture_time": clock.asDictionary(),
        "notes": [
          "Capture client must not assign EDTS-owned statuses.",
        ],
      ]
      // Ensure status is capture-owned
      _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.packageExported.rawValue)
      let statusBytes = try CanonicalJSONEncoder.encode(statusObj, stage: "package_status.json")
      try writeOnce(statusBytes, to: dir.appendingPathComponent("package_status.json"))

      let calibObj: [String: Any] = [
        "schema_id": "CameraCalibrationRecord",
        "schema_version": "1.0.0",
        "availability": calibrationAvailability.rawValue,
        "authority": NSNull(),
        "intrinsic_matrix": NSNull(),
        "intrinsic_matrix_reference_dimensions_px": NSNull(),
      ]
      let calibBytes = try CanonicalJSONEncoder.encode(calibObj, stage: "sidecars/camera_calibration.json")
      try writeOnce(calibBytes, to: dir.appendingPathComponent("sidecars/camera_calibration.json"))

      let motionObj = motion.asDictionary().merging([
        "schema_id": "MotionOrientationSample",
        "schema_version": "1.0.0",
      ]) { _, new in new }
      let motionBytes = try CanonicalJSONEncoder.encode(motionObj, stage: "sidecars/motion_orientation.json")
      try writeOnce(motionBytes, to: dir.appendingPathComponent("sidecars/motion_orientation.json"))

      let metaObj: [String: Any] = [
        "schema_id": "AVCaptureMetadata",
        "schema_version": "1.0.0",
        "representation": ArtifactRepresentation.appleEncodedJpeg.rawValue,
        "role": ArtifactRole.originalCaptureOutput.rawValue,
        "pixel_processing_claim": PixelProcessingClaim.notAsserted.rawValue,
        "notes": ["Only values actually returned at capture time should be added."],
      ]
      let metaBytes = try CanonicalJSONEncoder.encode(metaObj, stage: "sidecars/avcapture_metadata.json")
      try writeOnce(metaBytes, to: dir.appendingPathComponent("sidecars/avcapture_metadata.json"))

      // Inventory over all files except itself
      var listed: [(path: String, url: URL)] = []
      if let en = fm.enumerator(at: dir, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles]) {
        let root = dir.standardizedFileURL.path
        for case let url as URL in en {
          let vals = try url.resourceValues(forKeys: [.isRegularFileKey])
          guard vals.isRegularFile == true else { continue }
          var rel = url.standardizedFileURL.path
          if rel.hasPrefix(root) {
            rel = String(rel.dropFirst(root.count))
            if rel.hasPrefix("/") { rel = String(rel.dropFirst()) }
          }
          if rel == "package_inventory.json" { continue }
          listed.append((rel, url))
        }
      }
      let inventoryObj = try inventoryBuilder.build(packageId: ids.evidenceId, files: listed)
      let inventoryBytes = try CanonicalJSONEncoder.encode(inventoryObj, stage: "package_inventory.json")
      try writeOnce(inventoryBytes, to: dir.appendingPathComponent("package_inventory.json"))

      // Zip transport (.edts-pkg file; directory remains for inspection)
      try ZipPackageWriter.writeZip(ofDirectory: dir, to: finalZip)

      return Phase1PackageResult(
        packageDirectoryURL: dir,
        packageZipURL: finalZip,
        packageId: ids.evidenceId,
        evidenceId: ids.evidenceId,
        sessionId: ids.sessionId,
        artifactId: ids.artifactId,
        artifactSha256: artifact.sha256,
        artifactByteSize: artifact.byteSize,
        captureSideStatus: .packageExported,
        packageSealStatus: "NOT_IMPLEMENTED"
      )
    } catch {
      try? fm.removeItem(at: dir)
      try? fm.removeItem(at: finalZip)
      if let e = error as? Phase1RuntimeError { throw e }
      if let e = error as? CaptureError {
        throw Phase1RuntimeError.statusAuthorityViolation(String(describing: e))
      }
      throw Phase1RuntimeError.packageBuildFailed(String(describing: error))
    }
  }

  private func writeOnce(_ data: Data, to url: URL) throws {
    try FileManager.default.createDirectory(
      at: url.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if FileManager.default.fileExists(atPath: url.path) {
      throw Phase1RuntimeError.packageBuildFailed("refusing overwrite \(url.lastPathComponent)")
    }
    try data.write(to: url, options: .withoutOverwriting)
  }
}
