#!/usr/bin/env bash
# Interactive / topic help for elektron-capture-ios.
# Display-only: never deletes files, never builds unless you copy a command yourself.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

topic="${1:-}"

print_menu() {
  cat <<'EOF'
elektron-capture-ios — command help
===================================
Repo root should contain Package.swift and Phase1StillCapture.xcworkspace.

Quick start:
  make help
  make verify
  make open          # Mac: opens Phase1StillCapture.xcworkspace

Topics (display only):
  ./Scripts/help.sh build
  ./Scripts/help.sh test
  ./Scripts/help.sh xcode
  ./Scripts/help.sh device
  ./Scripts/help.sh export
  ./Scripts/help.sh package
  ./Scripts/help.sh troubleshoot

Full dictionary:
  less HELP.md
  # or open HELP.md in any editor

Categories
----------
  Navigation     pwd | cd "<repo>" | find workspaces
  Package        make build | make test
  Handoff        make verify | ./Scripts/verify-xcode-handoff.sh
  Xcode app      make xcode-build | make open
  Device build   make device-build   (compile/sign only — not runtime)
  Simulator      make simulator-test (not physical device)
  Export/pkg     make export-help | make package-help
  Clean          make clean
  Help system    ./Scripts/verify-help-system.sh

Open the correct app entry point:
  open Phase1StillCapture.xcworkspace
Do NOT open Phase1StillCapture.xcodeproj alone as the primary workflow.
EOF
}

print_build() {
  cat <<'EOF'
[build] Swift package compilation (NOT the Xcode app)

Where: repository root (folder with Package.swift)

  swift build
  make build

Expected:
  Build complete!

Notes:
  - Compiles ElektronCapture only.
  - Does not compile Apps/Phase1StillCapture/*.swift.
  - Green swift build ≠ green Xcode app.

See also: HELP.md §3, ./Scripts/help.sh xcode
EOF
}

print_test() {
  cat <<'EOF'
[test] Swift package tests

Where: repository root

  swift test
  make test
  swift test --filter GoldenEvidencePackageTests

Expected:
  Test Suite 'All tests' passed
  (Linux may report 1 documented skip)

Simulator / Xcode tests (Mac only):
  make simulator-test

Do not use simulator-test against a physical iPhone destination.
EOF
}

print_xcode() {
  cat <<'EOF'
[xcode] App workspace build (Mac)

Where: repository root

Open (preferred):
  open Phase1StillCapture.xcworkspace
  make open

Clean app build:
  xcodebuild -workspace Phase1StillCapture.xcworkspace \
    -scheme Phase1StillCapture \
    -destination 'generic/platform=iOS' \
    clean build
  make xcode-build

Linkage excerpt:
  xcodebuild -workspace Phase1StillCapture.xcworkspace \
    -scheme Phase1StillCapture -showBuildSettings \
    | grep -E 'ElektronCapture|PACKAGE|FRAMEWORK_SEARCH|LIBRARY_SEARCH|SWIFT_INCLUDE'

Handoff verifier (layout + on Mac xcodebuild):
  ./Scripts/verify-xcode-handoff.sh
  make verify

UI:
  ⌘B build only | ⌘R run on device | ⌘U tests (prefer simulator)

Do NOT open the .xcodeproj alone as the primary workflow.
EOF
}

print_device() {
  cat <<'EOF'
[device] Physical iPhone — build vs run

Compile/sign for device (does NOT prove capture runtime):
  xcodebuild -workspace Phase1StillCapture.xcworkspace \
    -scheme Phase1StillCapture -sdk iphoneos \
    -destination 'generic/platform=iOS' build
  make device-build

Install + run on a connected iPhone:
  - Open Phase1StillCapture.xcworkspace
  - Select your iPhone as destination
  - Press ⌘R in Xcode
  - Fix Signing & Capabilities → Team if needed

Acceptance capture is a runtime workflow (preview → Take Photo →
Retake/Use Photo → Export → Share/Save .edts-pkg), not device-build alone.
EOF
}

print_export() {
  cat <<'EOF'
[export] In-app export / share (physical device)

After PACKAGE_EXPORTED in the app:
  1. Share .edts-pkg  (Share Sheet / AirDrop)
  2. Save .edts-pkg to Files
  3. Export as ZIP copy  (diagnostic; same bytes, .zip extension)

On Mac, locate packages:
  find "$HOME/Downloads" -name "*.edts-pkg" -print

Then see: ./Scripts/help.sh package
EOF
}

print_package() {
  cat <<'EOF'
[package] Inspect an .edts-pkg (ZIP transport)

Quote paths (spaces are common):

  unzip -l "<package>.edts-pkg"
  unzip -p "<package>.edts-pkg" manifest.json
  unzip -p "<package>.edts-pkg" package_inventory.json
  unzip -p "<package>.edts-pkg" payload/artifact_original.jpg > artifact_original.jpg
  shasum -a 256 "<package>.edts-pkg"
  shasum -a 256 artifact_original.jpg

Phase 1 minimum usually includes:
  manifest.json, package_inventory.json, payload/artifact_original.jpg

Optional (only if listed by unzip -l):
  package_status.json
  sidecars/camera_calibration.json
  sidecars/avcapture_metadata.json

JPEG identity: artifact SHA must match the frozen post-delegate hash.
Do not re-encode via Preview before hashing.
EOF
}

print_troubleshoot() {
  cat <<'EOF'
[troubleshoot] Common failures

Cannot find Phase1StillCaptureUIState / PendingStillCapture / … in scope
  → Add: import ElektronCapture
  → in that Apps/Phase1StillCapture/*.swift file

Cannot find CameraPreviewView in scope
  → Package type must be: public struct CameraPreviewView
  → Re-download tip that includes the public access fix

Missing package product 'ElektronCapture'
  → open Phase1StillCapture.xcworkspace (root)
  → File → Packages → Reset Package Caches → Resolve

swift build OK but Xcode fails
  → Expected class of bug: SPM ≠ app target
  → Run make xcode-build / verify on Mac

xcodebuild not found (Linux)
  → Use a Mac for app/device gates

Signing errors
  → Xcode → Settings → Accounts → Apple ID
  → Target → Signing & Capabilities → Team

Wrong folder / spaces in path
  → pwd
  → cd "<full path with spaces quoted>"
  → find "$HOME/Downloads" -name "Phase1StillCapture.xcworkspace" -print

Full dictionary: HELP.md
EOF
}

case "$topic" in
  "") print_menu ;;
  build) print_build ;;
  test) print_test ;;
  xcode) print_xcode ;;
  device) print_device ;;
  export) print_export ;;
  package) print_package ;;
  troubleshoot) print_troubleshoot ;;
  -h|--help|help)
    print_menu
    ;;
  *)
    echo "Unknown topic: $topic" >&2
    echo "Try: ./Scripts/help.sh" >&2
    exit 1
    ;;
esac
