# Phase1StillCapture (thin Xcode host)

Minimal SwiftUI host for the Phase 1 single-still runtime.

## Open on Mac (do this)

Prefer the workspace (most reliable package resolution):

```bash
open Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace
# or from repo root:
open Phase1StillCapture.xcworkspace
```

Or open the project alone:

```bash
open Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj
```

Do **not** create a new Xcode project. Do **not** open only `Package.swift` if you intend to Run on an iPhone.

Scheme: `Phase1StillCapture`  
Destination: your **physical iPhone** (not Simulator for acceptance)

### If Xcode says “Missing package product 'ElektronCapture'”

1. Confirm you cloned/opened the **repo root** (must contain `Package.swift` next to `Apps/`).
2. File → Packages → **Reset Package Caches**, then Resolve Package Versions.
3. Or open `Phase1StillCapture.xcworkspace` instead of the `.xcodeproj`.
4. Run `./Scripts/verify-xcode-handoff.sh` — must print `HANDOFF_LAYOUT_OK`.

## Wiring

```text
Phase1StillCapture.xcodeproj / .xcworkspace
        ↓
Apps/Phase1StillCapture/*.swift  (this folder only)
        ↓
local package product ElektronCapture  (relativePath ../.. → Package.swift)
        ↓
existing capture / hash / manifest / EvidencePackageBuilder
```

No duplication of `App/` or `Contracts/` sources into the app target.

## Behavior

- Requests camera permission (`NSCameraUsageDescription`).
- Captures one processed JPEG via AVFoundation (`fileDataRepresentation`).
- Persists exact bytes → SHA-256 read-back → canonical `.edts-pkg`.
- Writes under Documents/`Phase1Exports/`.
- **Share .edts-pkg** (Share Sheet / AirDrop) after export — package bytes unchanged.
- Documents also visible via Files when file sharing is enabled.
- Does **not** write to the Photo Library.
- Does **not** display EDTS verification status (EDTS assigns that).

## First physical session labels

- `DEVICE_VALIDATION_REHEARSAL`
- `NON_AUTHORITATIVE`
- `CONTENT_UNVERIFIED`

See `Docs/PHYSICAL_IPHONE_VALIDATION_RUNBOOK.md`.
