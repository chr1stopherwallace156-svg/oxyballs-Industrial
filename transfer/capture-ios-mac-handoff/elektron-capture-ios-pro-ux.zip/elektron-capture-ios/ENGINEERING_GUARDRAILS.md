# ENGINEERING_GUARDRAILS

Canonical document: [`Docs/Architecture/ENGINEERING_GUARDRAILS.md`](Docs/Architecture/ENGINEERING_GUARDRAILS.md)

This root file exists so repository checklists and Cursor rules can reference a stable top-level name. Edit the Docs/ path above; keep this pointer in sync if the canonical path moves.
