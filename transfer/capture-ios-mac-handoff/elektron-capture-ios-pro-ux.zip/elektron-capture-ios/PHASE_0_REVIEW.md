# PHASE_0_REVIEW.md

| Field | Value |
|---|---|
| Status | **UNDER_REVIEW** (not automatically approved) |
| Version | 0.1.1 |
| Owner | elektron-capture-ios |
| Last Updated | 2026-07-23 |
| Applies To | Phase 0 exit |
| Supersedes | REPOSITORY_FOUNDATION_REVIEW.md (superseded as Phase 0 report; retained historically) |

## What was created

- Foundational Implementation Contract embodied in `CURSOR_OPERATING_RULES.md` + `.cursor/rules/edts-capture.mdc` (+ existing `elektron-capture-ios.mdc`).
- Apple-native roadmap (Phases 0–7) — not Android line-by-line.
- Documentation set with Status/Version/Owner headers: architecture, boundaries, evidence, calibration, security, integration contract, state machine, coordinate/timestamp standards, etc.
- Domain models: authority classes, uncertain values, session state machine, calibration profile shape, spatial pose, motion window, device profile, richer session.
- Framework-isolation protocols + labeled mocks.
- Path A package layout (`originals/`, `derivatives/`, `checksums.sha256`, …).
- Contracts updated (EvidenceManifest authority/original flags; Apple-native CalibrationProfile).
- Golden package `GOLDEN_CAPTURE_001` rebuilt to Path A layout.
- Unit tests for state machine, authority, mocks; scripts for contracts/package/security.

## What remains unknown

| Item | Marker |
|---|---|
| Exact commercial iPhone Pro SKU for profile `IPHONE-PRO-LIDAR-PROFILE-001` | `DECISION_REQUIRED` |
| Approved iOS version range | `DECISION_REQUIRED` |
| Protective case geometry specification | `RESEARCH_REQUIRED` |
| App Attest environment / server verifier ownership | `DECISION_REQUIRED` |
| EDTS importer field mapping for revised manifest | `VALIDATION_REQUIRED` |
| GitHub remote URL for this independent repo | `DECISION_REQUIRED` |

## Architecture decisions made

CAP-IOS-ADR-0001 … 0008 (independent repo; Path A first; no submodules; defer hardware; Apple-native; guidance-grade ARKit; single device profile; Apple calibration + OpenCV derivative).

## Assumptions used

- Phase 0 may ship Swift Package domain code without a full `.xcodeproj` on Linux CI.
- Synthetic golden bytes are acceptable until Phase 1 hardware capture.
- `PACKAGE_EXPORT_READY` does not imply EDTS importer acceptance.
- Android repos will not be vendored here.

## Risks discovered

| Risk | Severity |
|---|---|
| Premature camera work before Phase 0 acceptance | High — gated by ADR-0004 |
| Authority inflation in UI copy | High — guardrails + AuthorityGuard |
| Schema drift vs EDTS importer | High — XREPO process |
| Mock/production confusion | Medium — labels + INTEGRATION_STATUS |
| Cannot create GitHub sibling repo from this agent token | Medium — manual remote |

## Schemas introduced / updated

EvidenceManifest 1.0.0 (authority, is_original, parent ids, capture_identity, spatial_context) · CapturePlan / CaptureRequirement · CalibrationProfile (Apple-native) · CoordinateTransform · ArtifactMetadata · Compatibility record · Integration contract draft.

## Tests added

State machine legal/illegal transitions · uncertain value default · adapter mock labels · existing hash/authority/store tests · golden package path via scripts · Swift golden tests (Mac toolchain).

Script results (this environment): `validate-contracts` PASS · `verify-evidence-package` PASS · `run-security-checks` PASS.

## Integration contract status

`INTEGRATION_CONTRACT.md` = **DRAFT**. Runtime status = **PACKAGE_EXPORT_READY**. Not `EDTS_COMPATIBLE`. Path B API stub only.

## Recommended next action

1. Human review/accept Phase 0 (`PHASE_0_REVIEW.md` → APPROVED).  
2. Create empty GitHub `elektron-capture-ios` and push.  
3. On Mac: iOS app shell depending on `ElektronCapture` package.  
4. Begin **Phase 1** only: AVFoundation still capture + immutable originals + export — still no ARKit/LiDAR production path until Phase 2–3.

**Phase 0 is not automatically approved.**
