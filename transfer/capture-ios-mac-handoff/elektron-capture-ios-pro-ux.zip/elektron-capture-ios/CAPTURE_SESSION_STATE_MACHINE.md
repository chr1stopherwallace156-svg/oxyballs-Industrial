# CAPTURE_SESSION_STATE_MACHINE

Canonical document: [`Docs/Architecture/CAPTURE_SESSION_STATE_MACHINE.md`](Docs/Architecture/CAPTURE_SESSION_STATE_MACHINE.md)

This root file exists so repository checklists and Cursor rules can reference a stable top-level name. Edit the Docs/ path above; keep this pointer in sync if the canonical path moves.
