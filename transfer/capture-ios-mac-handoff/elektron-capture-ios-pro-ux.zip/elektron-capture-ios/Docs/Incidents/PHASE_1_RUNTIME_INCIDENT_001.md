# PHASE_1_RUNTIME_INCIDENT_001.md

## Incident Metadata

```text
Incident Status:
OPEN

Discovery Date:
2026-07-24

Opened By:
Physical-device operator + cloud agent investigation

Repository:
elektron-capture-ios

Branch:
cursor/canonicalization-failed-repair-d881

Baseline Commit (pre-repair):
c3581d04c0eacb0790e80b52a794eb5a3251b2cc

Candidate Repair Commit (UNAPPROVED for baseline until physical proof):
1b132f4183d66d791ef94773201e3387cd2da747

Incident + diagnostics documentation commit:
21d24e8131426511d79dcda812721ac1e3104a7c

Final Verified Commit:
(not set — PENDING_PHYSICAL_DEVICE_RETEST)

Physical Validation:
PENDING

Status locks:
CANONICALIZATION_DEFECT_UNDER_INVESTIGATION
PENDING_PHYSICAL_DEVICE_RETEST

Evidence posture:
CODE-LEVEL ROOT CAUSE: HIGH-CONFIDENCE, REPRODUCED
ORIGINAL DEVICE FAILURE MATCH: NOT YET DIRECTLY OBSERVED (no on-device type/key log from failing session)
AUTOMATED TESTS: PASS
PHYSICAL EXPORT RETEST: PENDING
INCIDENT STATUS: OPEN

Phase 0 / Phase 1 baseline tags (unchanged):
capture-ios-phase0-approved-v0.1.3 @ d867137877817de0369d749a64201cad01886227
capture-ios-phase1-directive-v0.1.4 @ 61502eb3ccc0336c52e6dfbbb58f38a66eeaad7c

Device / iOS / Xcode / macOS:
NOT_OBSERVED in cloud — record on physical retest
```

---

## Executive Summary

During first physical iPhone validation of Phase1StillCapture, the app launched, obtained camera permission, and started Capture & Export, then displayed **`FAIL CANONICALIZATION_FAILED`** with empty Package ID, Evidence ID, Artifact SHA-256, and package path.

Investigation traced the displayed string to `Phase1RuntimeError.canonicalizationFailed` → reason code `CANONICALIZATION_FAILED`, thrown from `CanonicalJSONEncoder.encode` when encoding **`capture_device.json`**. Pre-repair `CaptureDeviceProvenance.asDictionary()` boxed nil Swift `Optional`s as `Any` (`Optional.none`). `CanonicalJSON` rejects that type.

**Severity:** High for Phase 1 physical gate (blocks first verified capture artifact on device).  
**Impact:** No `.edts-pkg` export on device; no evidence package for EDTS ingest.  
**Current status:** Code repair + regression tests on `1b132f4`; **not** closed until physical retest produces non-empty IDs/hash/path. Simulator/`swift test` green alone is insufficient.

---

## Timeline

```text
Simulator / Linux fixture validation (package path with overrides)
↓
Physical device deployed (Phase1StillCapture signed + installed)
↓
Camera permission granted
↓
Capture button pressed → UI Working
↓
FAIL CANONICALIZATION_FAILED (package fields empty)
↓
Investigation (status registry + encoder + provenance asDictionary)
↓
Root cause isolated: nil Optional boxed as Any in capture_device.json
↓
Repair: NSNull() for absent optional provenance fields + diagnostics + UI defer
↓
Regression tests (pre-fix pattern FAIL / post-fix PASS)
↓
Physical retest  ← PENDING (acceptance gate)
```

---

## Symptoms

```text
App launched successfully.
Camera permission requested and granted.
Capture & Export initiated.
Working indicator shown.
FAIL CANONICALIZATION_FAILED displayed.
Package ID empty.
Evidence ID empty.
Artifact SHA-256 empty.
Package path empty.
Button appeared stuck on Working (pre-repair UI hid detail; Working reset not audibly confirmed on device).
Xcode console dominated by Fig / FigCaptureSourceRemote / FBSSceneSnapshot noise.
Literal search for CANONICALIZATION_FAILED did not land on a single call site (value is enum reasonCode).
```

---

## Environment

```text
iPhone model:        (record on retest — hw.machine via DeviceProvenanceService)
iOS version:         (record on retest)
Xcode version:       (record on retest)
Swift version:       5.9+ (Package.swift); cloud verification used Swift 5.10.1 Linux
Branch:              cursor/canonicalization-failed-repair-d881
Commit before repair: c3581d04c0eacb0790e80b52a794eb5a3251b2cc
Commit after repair:  1b132f4183d66d791ef94773201e3387cd2da747
Cloud agent:         Linux (no Xcode / no physical camera)
```

---

## Console Logs

### Non-root-cause framework diagnostics

```text
Fig / FigCaptureSourceRemote …
FBSSceneSnapshot …
```

These are system camera/scene messages. They did **not** encode the application failure reason.

### Actual application diagnostics (after instrumentation)

Encoder / UI path logs (stderr / console), pattern:

```text
[Phase1Capture] stage=capture_device.json event=canonicalization_failed
  stage=capture_device.json
  | swiftErrorType=CaptureError
  | describing=packageInvalid("Unsupported JSON type Optional<…> …")
  | unsupportedValues=<keyPath> type=Optional<…> describing=nil
```

UI after repair shows:

```text
FAIL CANONICALIZATION_FAILED
Error detail: stage=… | describing=… | unsupportedValues=…
```

Photo-path instrumentation (byteCount / metadataKeyCount only; **no** full JPEG or sensitive EXIF dump) added for device retest distinguishability — see Code Changes.

---

## Stage Analysis

Evidence mix: **OBS** = physical observation; **INF** = inferred from distinct reason codes / builder order; **EXE** = reproduced in tests/harness.

| Stage | Result | Basis |
| ----- | ------ | ----- |
| Launch | PASS | OBS |
| Camera Authorization | PASS | OBS |
| AVCapture Session | PASS | OBS (capture starts) |
| Photo Delegate | PASS | INF — failure was not `PHOTO_CAPTURE_FAILED` |
| JPEG Extraction (`fileDataRepresentation`) | PASS | INF — not `FILE_REPRESENTATION_UNAVAILABLE`; builder reaches provenance encode |
| Persist / hash artifact | PASS | INF — encode order places artifact persist before device JSON |
| Manifest canonical encode | PASS | INF — enrollment is non-nil String; next stage is device JSON |
| **Canonical JSON (`capture_device.json`)** | **FAIL** | EXE — first failing encode; Optional nil key paths |
| Remaining package JSON / ZIP | NOT REACHED | EXE — builder catch cleans partial package |
| Export / Share | NOT REACHED | OBS — empty path |
| UI field population | FAIL | OBS |
| UI Working reset | Ambiguous OBS; fixed in code via `defer` | code review |

**Failure class:** canonicalization failure (not capture, metadata adaptation, manifest schema validation, or filesystem export).

---

## Root Cause

```text
Exact file:
  App/Domain/Models/CaptureDeviceProvenance.swift

Exact function:
  CaptureDeviceProvenance.asDictionary()

Exact pre-repair pattern:
  d["lidar_available"] = lidarAvailable as Any   // and siblings
  when lidarAvailable == nil → value type Optional<Bool>.none boxed in Any

Exact key paths proven (physical DeviceProvenanceService nils):
  app_attest_key_id     → Optional<String> (nil)
  calibration_profile_id → Optional<String> (nil)
  lidar_available       → Optional<Bool> (nil)
  (dictionary walk order may surface any of these first)

Exact throw site:
  CanonicalJSON.normalize(_:) default → CaptureError.packageInvalid("Unsupported JSON type …")
  wrapped by CanonicalJSONEncoder.encode → Phase1RuntimeError.canonicalizationFailed(…)

Exact displayed status:
  Phase1RuntimeError.reasonCode == "CANONICALIZATION_FAILED"
  (Apps/Phase1StillCapture/Phase1CaptureRootView.swift: "FAIL \(e.reasonCode)")

Producer of nils:
  App/Phase1/DeviceProvenanceService.currentProvenance(…)
  sets lidarAvailable: nil (and leaves attest/calibration nil by default)
```

**Contract note:** These provenance fields are **optional** in the capture-device contract sense (may be absent/unknown at Phase 1). Encoding them as JSON `null` preserves key presence and determinism. This is **not** a license to serialize arbitrary undocumented AVCapture metadata dictionaries into the package.

---

## Why Simulator / Fixture Tests Didn't Catch It

```text
Simulator / Linux fixture path:
  Phase1RuntimeTests often used CaptureDeviceProvenance(...) with enrollment set,
  OR full coordinator with hardwareModelOverride / iosVersionOverride.
  Golden manifest tests encode EvidenceManifestBuilder output only — not
  provenance.asDictionary() with the full nil-optional matrix from DeviceProvenanceService.

Physical device path:
  Always uses DeviceProvenanceService.currentProvenance() which intentionally
  leaves lidarAvailable (and related optionals) nil until asserted.

Difference:
  Physical path systematically produces Optional.none entries in asDictionary().
  Fixture/golden paths often omitted those keys' nil matrix or never encoded
  capture_device.json through the failing asDictionary implementation in isolation.

Why coverage missed it:
  No regression that built DeviceProvenanceService().currentProvenance()-shaped
  dictionaries (nil lidar/attest/calibration) and required CanonicalJSONEncoder
  success before physical deployment.
  UI mapped errors to reasonCode only, hiding Unsupported JSON type Optional<…>.
```

Fields **simulated in regression (not observed from a captured on-device package dump):** exact iPhone `hw.machine` string, exact iOS marketing version, live AVCapture metadata key set, real JPEG byte count from the failing session.  
Fields **evidence-backed:** nil optional matrix from `DeviceProvenanceService` source; encoder rejection of `Optional.none as Any`; builder encode order; reason-code mapping.

---

## Code Changes

| File | Reason | Change | Risk |
| ---- | ------ | ------ | ---- |
| `App/Domain/Models/CaptureDeviceProvenance.swift` | Root cause | `?? NSNull()` for optional fields in `asDictionary()` | Low — JSON null for unknowns |
| `App/Phase1/EvidenceManifestBuilder.swift` | Same Optional boxing | `device_enrollment_id: … ?? NSNull()` | Low |
| `App/Phase1/CaptureClockService.swift` | Harden leaf types | `monotonic_ns` as Int64/NSNumber | Low |
| `App/Application/CanonicalJSON.swift` | Diagnostics + leaf types + Bool/NSNumber order + solidus normalize | Clearer Optional errors; UInt64; Darwin-safe Bool | Medium — review Bool/NSNumber carefully |
| `App/Phase1/CanonicalJSONEncoder.swift` | Preserve root cause | Stage name + describing/reflecting + unsupported key paths | Low |
| `App/Phase1/EvidencePackageBuilder.swift` | Stage isolation | Per-file `stage:` on encode | Low |
| `App/Phase1/Phase1RuntimeError.swift` | UI/diagnostics | `detailMessage` | Low |
| `Apps/Phase1StillCapture/Phase1CaptureRootView.swift` | UI safety | `defer { busy = false }`, show detail | Low |
| `App/Export/FileEvidenceExporter.swift` | Same Optional pattern | `?? NSNull()` | Low |
| `App/Provenance/ContentHasher.swift` / `ArtifactHashingService.swift` | Linux CI only | CryptoKit fallback for `swift test` on Linux | Low on Apple (CryptoKit unchanged) |
| `Tests/Unit/Phase1RuntimeTests.swift` | Prevention | Physical nil-optional + buggy Optional regression | Low |
| `App/Capture/AVFoundation/Phase1CameraServices.swift` | Retest diagnostics | Log byteCount / metadataKeyCount only | Low |
| `App/Phase1/Phase1CaptureCoordinator.swift` | Retest diagnostics | Log received JPEG byteCount | Low |

ADR: [ADR-001-optional-provenance-json-null.md](./ADR-001-optional-provenance-json-null.md)

---

## Diff Summary

```text
Added:
  Docs/Incidents/* (this record, README, ADR-001)
  Phase1 physical-nil regression tests
  CanonicalJSON.unsupportedValues diagnostics
  Stage-labeled encode + UI error detail

Modified:
  CaptureDeviceProvenance.asDictionary (NSNull)
  CanonicalJSON / CanonicalJSONEncoder
  EvidencePackageBuilder, EvidenceManifestBuilder, CaptureClockService
  Phase1CaptureRootView, Phase1RuntimeError
  FileEvidenceExporter
  Photo capture diagnostics (byte/key counts)
  CHANGELOG [Unreleased] Fixed section
  ContentHasher Linux fallback (CI)

Removed:
  (none intentional — no deletion of evidence fields; nils become JSON null)
```

---

## Tests

### Before (pre-repair `asDictionary` pattern / parent semantics)

```text
FAILED — CanonicalJSON / CanonicalJSONEncoder on DeviceProvenanceService-shaped
         dictionary with nil lidar_available / app_attest_key_id /
         calibration_profile_id
         → Unsupported JSON type Optional<…>
         → Phase1RuntimeError.canonicalizationFailed → CANONICALIZATION_FAILED
```

### After (`1b132f4` + tip tests)

```text
PASS — testPhysicalDeviceProvenanceDictionaryCanonicalizes
PASS — testCanonicalJSONRejectsBoxedNilOptional (still rejects buggy Optional boxing)
PASS — testEndToEndPackageWithPhysicalDeviceNilOptionals
PASS — testPhysicalDeviceStatusPayloadWithClockCanonicalizes
PASS — testCanonicalManifestMatchesPythonGoldenBytes
PASS — package / inventory / capture-side validator suite
```

| Class | Name / notes |
| ----- | ------------ |
| Regression | Physical DeviceProvenanceService nil matrix + intentional buggy Optional re-injection |
| Golden | Canonical manifest Python golden bytes |
| Runtime | Phase1CaptureCoordinator fixture JPEG e2e |
| Package | Inventory self-hash policy, calibration NOT_AVAILABLE |

`swift test` (Linux cloud): 47 tests, 0 failures (1 skipped: cross-language corpus on Linux Foundation bool collapse).  
`xcodebuild`: not run in cloud — **Mac required**.

---

## Evidence

### Physical successful export (acceptance)

```text
Package ID:     (PENDING_PHYSICAL_DEVICE_RETEST)
Evidence ID:    (PENDING_PHYSICAL_DEVICE_RETEST)
SHA-256:        (PENDING_PHYSICAL_DEVICE_RETEST)
Package path:   (PENDING_PHYSICAL_DEVICE_RETEST)
```

Do **not** treat Linux fixture package IDs as physical acceptance evidence.

### Code / harness evidence (investigation)

```text
Pre-fix unsupported keyPaths: app_attest_key_id, calibration_profile_id, lidar_available
Post-fix: unsupported_count=0; capture_device.json encodes with JSON nulls
Repair commit: 1b132f4183d66d791ef94773201e3387cd2da747
```

---

## Lessons Learned

```text
Never map pipeline errors to generic reason codes without preserving the underlying Swift error.
Always reset UI busy/Working via defer (or equivalent).
Physical-device payloads (DeviceProvenanceService nil matrix) need dedicated regression fixtures.
Optional.none boxed as Any is not JSON — prefer NSNull() or omit per contract.
Simulator/fixture success ≠ physical acceptance for Phase 1.
Literal string search can miss enum-backed status codes.
```

---

## Preventive Actions

* Every `Phase1RuntimeError` associated value / UI path must preserve underlying error text.
* Every canonical encode site must pass a **stage** name into diagnostics.
* Every physical-only producer path must have a regression fixture labeled `OBS` vs `SIMULATED_NOT_OBSERVED`.
* No bare `CANONICALIZATION_FAILED` in UI without detail/stage/unsupported key path when available.
* Physical-device validation required before Phase 1 implementation complete.
* Incident records live under `Docs/Incidents/` and are not overwritten; open incidents get dated addenda.

---

## ADR

See [ADR-001-optional-provenance-json-null.md](./ADR-001-optional-provenance-json-null.md).

---

## Acceptance Evidence

Checklist for physical retest (fill on device; do not check off from cloud):

* [ ] App launched
* [ ] Camera authorized
* [ ] Photo captured (`fileDataRepresentation` byteCount > 0 in logs)
* [ ] Package created (non-empty Package ID / Evidence ID)
* [ ] SHA generated (non-empty Artifact SHA-256)
* [ ] Package exported (non-empty path / Share available)
* [ ] Physical-device retest passed

**Until then:** `PENDING_PHYSICAL_DEVICE_RETEST`.

---

## Addendum 2026-07-24B — Review gate response (do not treat as closure)

This addendum answers the review challenges. It does **not** close the incident.

### Evidence classification legend

| Label | Meaning |
| ----- | ------- |
| OBSERVED | Seen on physical iPhone / console by operator |
| VERIFIED | Demonstrated by automated test or harness |
| CODE-DERIVED | Established by reading committed source |
| HYPOTHESIS | Engineering inference; not yet observed |

### Repair Candidate vs Verification (separated)

```text
Repair Candidate
-------------
Commit: 1b132f4183d66d791ef94773201e3387cd2da747
Status: UNAPPROVED for permanent baseline — awaiting physical validation + review of diff boundary
Process note: committed before review-gate existed; treat as candidate, not automatic invalidation

Documentation / diagnostics follow-up
-------------
Commit: 21d24e8131426511d79dcda812721ac1e3104a7c
Contains: P1R-001 docs, ADR-001, photo byteCount/metadataKeyCount logs

Verification
-------------
Simulator / Linux swift test: PASS (VERIFIED)
Unit / regression tests: PASS (VERIFIED)
Physical Device export: PENDING (NOT_OBSERVED)
```

### 1. Clean baseline and diff boundary

```text
Working tree at documentation tip: clean after this commit (when applied)
Baseline (pre-repair): c3581d04c0eacb0790e80b52a794eb5a3251b2cc
Repair-only range:     c3581d0..1b132f4
Docs+diagnostics:      1b132f4..21d24e8
```

**Repair-only files (c3581d0..1b132f4):** provenance NSNull, CanonicalJSON/Encoder, builders, UI defer/detail, tests, CHANGELOG, plus Linux CI hashing shims (`ContentHasher` / `ArtifactHashingService`) and a golden meta version assertion fix.

**Diff-boundary review note (HYPOTHESIS → flag for human):**  
`ContentHasher.swift` Linux SHA-256 fallback and `GoldenEvidencePackageTests` `0.1.0`→`0.1.1` are **not** required for the Optional→NSNull root-cause repair. Flag as **out-of-boundary candidates** for possible split/revert if the reviewer wants a minimal Apple-only repair commit. They do not change Apple CryptoKit behavior.

**Diagnostics-only files (1b132f4..21d24e8):**  
`Phase1CameraServices.swift`, `Phase1CaptureCoordinator.swift`, `Docs/Incidents/*`, status pointer, CHANGELOG line.

### 2. Contract citation for JSON null

| Source | Evidence grade | Citation |
| ------ | -------------- | -------- |
| Schema | CODE-DERIVED | `Contracts/CaptureDeviceProvenance/CaptureDeviceProvenance.v1.0.0.schema.json` — `"lidar_available": { "type": ["boolean", "null"] }` (and peers for string\|null optionals) |
| Canonical rules | CODE-DERIVED | `Docs/Validation/CANONICAL_JSON.md` — rule **Null → `null`** |
| ADR | CODE-DERIVED | `Docs/Incidents/ADR-001-optional-provenance-json-null.md` |

Required provenance fields remain non-null strings per schema `"required"` array. This repair does not null required identity fields.

### 3. First failing key — precise wording

```text
ORIGINAL_DEVICE_FIRST_KEY = NOT_OBSERVED
  (no console capture from the failing iPhone session recorded unsupportedValues=…)

HARNESS_SORTED_WALK_FIRST_KEY = app_attest_key_id (Optional<String>)
  (VERIFIED) — CanonicalJSON.unsupportedValues sorts keys; first unsupported among
  DeviceProvenanceService-shaped nils is app_attest_key_id, then calibration_profile_id,
  then lidar_available.

Any of the three nil Optionals is independently sufficient to throw CANONICALIZATION_FAILED.
Do not claim the original device threw on a specific key without an OBSERVED log.
```

### 4. Critical repair diff

Before (`c3581d0`):

```swift
d["lidar_available"] = lidarAvailable as Any
d["calibration_profile_id"] = calibrationProfileId as Any
d["app_attest_key_id"] = appAttestKeyId as Any
// … same pattern for other Optionals
```

After (`1b132f4`):

```swift
"lidar_available": lidarAvailable ?? NSNull(),
"calibration_profile_id": calibrationProfileId ?? NSNull(),
"app_attest_key_id": appAttestKeyId ?? NSNull(),
// … same for other schema-optional fields
```

### 5. Regression test (code + outcomes)

Test: `Phase1RuntimeTests.testPhysicalDeviceProvenanceDictionaryCanonicalizes`  
Also: `testCanonicalJSONRejectsBoxedNilOptional`, `testEndToEndPackageWithPhysicalDeviceNilOptionals`

Pre-fix pattern (VERIFIED harness): DeviceProvenanceService-shaped `as Any` nils → FAIL `Unsupported JSON type Optional<…>` / `CANONICALIZATION_FAILED`.  
Post-fix (VERIFIED `swift test`): same physical-nil matrix encodes; buggy Optional re-injection still fails with stage detail.

Process gap (documented): regression was not landed as a red commit before the repair commit.

### 6. Diagnostics diff (separated from repair)

See `git diff 1b132f4..21d24e8 -- App/Capture/AVFoundation/Phase1CameraServices.swift App/Phase1/Phase1CaptureCoordinator.swift`  
Bounded logs only: `byteCount`, `metadataKeyCount`, `metadataKeySample` (≤12 keys), `embeddedThumbnailPresent`. **No** image bytes, full EXIF, GPS, or private identifiers.

### 7. Physical stage template (replace inferred rows on retest)

Use only: `OBSERVED_PASS` | `OBSERVED_FAIL` | `NOT_OBSERVED`

| Fact | Status (until retest) |
| ---- | --------------------- |
| photoDelegateCompleted | NOT_OBSERVED |
| fileDataByteCount | NOT_OBSERVED |
| metadataKeyCount | NOT_OBSERVED |
| manifestEncodeStarted | NOT_OBSERVED |
| manifestEncodeCompleted | NOT_OBSERVED |
| captureDeviceEncodeStarted | NOT_OBSERVED |
| captureDeviceEncodeCompleted | NOT_OBSERVED |
| packageBuildCompleted | NOT_OBSERVED |
| packageID | NOT_OBSERVED |
| evidenceID | NOT_OBSERVED |
| artifactSHA256 | NOT_OBSERVED |
| packagePath | NOT_OBSERVED |
| busyStateReset | NOT_OBSERVED |

### 8. L. Incident Prevention (permanent guardrails)

| Guardrail | Status |
| --------- | ------ |
| Regression tests for DeviceProvenanceService nil matrix + Optional boxing | Present (`1b132f4`) |
| Stage-labeled CanonicalJSONEncoder diagnostics + unsupported key paths | Present |
| UI reasonCode + detailMessage + `defer` Working reset | Present |
| Runtime Rule R-001 | Present — `Docs/Capture/RUNTIME_RULES.md` |
| Incident + ADR records | Present — this file + ADR-001 |
| Schema-backed nullability for optional provenance | Cited |
| CI / physical export gate before Phase 1 complete | Process — still PENDING physical |
| Review checklist: no generic status without underlying error | Documented in R-001 |

### Original failure (preserved)

```text
FAIL CANONICALIZATION_FAILED
Package ID / Evidence ID / SHA / path empty
```

### Resolution Verification (empty until physical success)

```text
Package ID:
Evidence ID:
SHA-256:
Package path:
Final Verified Commit:
```

### What would falsify this diagnosis?

Good engineering states in advance what evidence would prove the current root-cause story wrong.
If any of the following occur, **do not close P1R-001** and treat the `Optional.none as Any` / `capture_device.json` hypothesis as **incomplete or wrong**.

```text
F1. Physical retest still shows FAIL CANONICALIZATION_FAILED
    AND diagnostics show capture_device.json encode completed successfully
    (stage=capture_device.json event=canonicalization_failed is absent;
     a later stage fails instead).
    → First failing stage was mis-identified; reopen stage isolation.

F2. Physical retest fails with CANONICALIZATION_FAILED
    AND unsupportedValues / detailMessage name a key path that is NOT an
    Optional-boxed provenance field (e.g. Date, URL, Data, non-string key,
    non-finite number, AVCapture metadata object).
    → Different unsupported type; Optional.none hypothesis insufficient.

F3. Physical retest fails with a different reasonCode
    (PHOTO_CAPTURE_FAILED, FILE_REPRESENTATION_UNAVAILABLE, PACKAGE_BUILD_FAILED,
     EXPORT_FAILED, etc.) while Working resets correctly.
    → Original symptom cluster may have been multi-causal or environment-shifted;
      keep P1R-001 open or open a linked incident for the new code.

F4. Pre-repair DeviceProvenanceService-shaped dictionary (nil lidar/attest/
    calibration) encodes successfully under CanonicalJSON without NSNull mapping
    on the same toolchain that failed on device.
    → Reproduction does not match device; investigate platform bridging differences.

F5. Successful encode of capture_device.json on device, but package fields remain
    empty / UI still shows CANONICALIZATION_FAILED.
    → UI/status mapping bug distinct from encoder; R-001 / UI path incomplete.
```

**Closure rule:** Only when physical Capture & Export succeeds with non-empty Package ID, Evidence ID, SHA-256, and package path **and** no falsifier above applies may status move to `PHYSICAL_DEVICE_VALIDATED` / `CLOSED`.

### Addendum log

| Date (UTC) | Note |
| ---------- | ---- |
| 2026-07-24 | Incident opened; repair candidate `1b132f4`; awaiting physical retest |
| 2026-07-24B | Review-gate addendum: contract citations, evidence grades, first-key honesty, diff boundary flags, R-001; status remains OPEN / PENDING_PHYSICAL_DEVICE_RETEST |
| 2026-07-24C | Added falsification criteria (F1–F5) for Optional.none / capture_device.json diagnosis |
