# ADR-001 — Optional provenance fields as JSON null

| Field | Value |
| ----- | ----- |
| Status | Accepted as **candidate** (pending physical retest confirmation) |
| Date | 2026-07-24 |
| Incident | P1R-001 |
| Deciders | Capture runtime maintainers |

## Context

`CaptureDeviceProvenance.asDictionary()` must feed `CanonicalJSON` for `capture_device.json`. Phase 1 `DeviceProvenanceService` leaves several fields nil (`lidar_available`, attestation, calibration identifiers) until asserted. Boxing `Optional.none as Any` is not a JSON value and caused `CANONICALIZATION_FAILED` on physical device (P1R-001).

## Contract citations (why JSON null is valid)

### 1. CaptureDeviceProvenance schema v1.0.0

File: `Contracts/CaptureDeviceProvenance/CaptureDeviceProvenance.v1.0.0.schema.json`

Optional fields are typed as union including null, for example:

```json
"lidar_available": { "type": ["boolean", "null"] },
"calibration_profile_id": { "type": ["string", "null"] },
"app_attest_key_id": { "type": ["string", "null"] }
```

Required fields (must remain non-null strings) are listed under `"required"` and do **not** include those optionals.

### 2. Canonical JSON binding rules

File: `Docs/Validation/CANONICAL_JSON.md`

| Rule | Requirement |
| ---- | ----------- |
| Null | `null` |

Canonical JSON explicitly admits JSON `null` as a scalar. This repair does not introduce a new scalar kind; it maps Swift `Optional.none` → JSON `null` for schema-optional fields.

### 3. Compatibility

Pre-repair physical path never successfully wrote `capture_device.json` when those Optionals were nil, so there is no stable on-device byte baseline that prohibited nulls. Fixture/golden paths that already emitted `null` (e.g. calibration sidecars, `capture_plan_id`) remain consistent.

## Decision

Encode absent **schema-optional** provenance fields as JSON `null` via `NSNull()` in `asDictionary()` (and equivalent sites). Do **not** silently drop required identity fields. Do **not** dump arbitrary AVCapture metadata dictionaries into the package unless a contract field explicitly requires them.

## Alternatives considered

1. **Omit nil keys** — also JSON-valid; not chosen for Phase 1 because the producer already emitted a stable key set and schema documents nullability per property.
2. **Force placeholder strings** (`"UNKNOWN"`) — rejected; invents evidence semantics.
3. **Teach CanonicalJSON to coerce all Optionals** — rejected as a silent footgun; producers should emit JSON-safe values; encoder may diagnose Optionals but must not hide producer bugs without tests.
4. **Ordinary JSONEncoder** — rejected; breaks canonical determinism contract.

## Determinism

Sorted-key compact UTF-8 canonicalization unchanged. Null is a stable scalar. Required string fields remain strings. Optional→null is explicit and tested.

## Implications

* Future optional fields added to provenance must use `?? NSNull()` (or contract-documented omission) — never `as Any` on Optional.
* Non-contract camera metadata stays out of canonical payloads unless a schema field is added with tests.
* Physical retest still required before closing P1R-001.
