# SECURITY_MODEL.md

| Field | Value |
|---|---|
| Status | **DRAFT** |
| Version | 1.0.0 |
| Owner | elektron-capture-ios |
| Last Updated | 2026-07-23 |
| Applies To | Provenance and secrets |
| Supersedes | (none) |

## Mechanisms

| Mechanism | Proves (approx.) | Does not prove |
|---|---|---|
| SHA-256 artifact hash | Byte integrity after sealing | Subject correctness |
| Signed manifest | Binding of listed fields at sign time | Physical location / operator truth if device compromised pre-hash |
| App Attest | Request likely from legitimate app instance | Metrology accuracy |
| Secure Enclave key | Key material isolation from main CPU | Capture subject identity |
| Server challenge | Freshness vs replay (when verified) | Vehicle physical state |

## Manifest binding (minimum)

artifact hashes · session · vehicle identity · operator · installation · requirement · timestamps · app version · device profile · calibration profile · previous manifest hash · server challenge

## Secrets

Never commit API keys, private keys, passwords, production URLs, or long-lived tokens. Use Keychain / Secure Enclave / short-lived server tokens / externalized env config.
