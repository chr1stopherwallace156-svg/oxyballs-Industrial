# THREAT_MODEL.md

| Field | Value |
|---|---|
| Status | **DRAFT** |
| Version | 1.0.0 |
| Owner | elektron-capture-ios |
| Last Updated | 2026-07-23 |
| Applies To | Capture app threats |
| Supersedes | (none) |

## Assets

Original evidence bytes · manifests · signing keys · enrollment records · capture plans · technician credentials · offline queues

## Threats (initial)

| Threat | Mitigation direction |
|---|---|
| Tampered originals | Immutable write + hash + seal |
| Mock mistaken for production | Labeled mocks + integration status honesty |
| Replay uploads | Server challenge + nonce |
| Unauthorized device | Approved-device registry + attestation |
| Secret leakage in repo | No secrets in source; scanning |
| Authority inflation | Authority classes; no Build Engine claims |
| Offline loss | Durable writes, recovery states |

## Out of scope (Phase 0)

Full STRIDE workbook; production App Attest server — deferred Phase 1–2 with dedicated security review.
