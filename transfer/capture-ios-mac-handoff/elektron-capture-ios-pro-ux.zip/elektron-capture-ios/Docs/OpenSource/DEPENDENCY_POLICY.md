# DEPENDENCY_POLICY.md

- Prefer Apple frameworks for capture.
- Third-party deps require decision log entry + license review.
- No unreviewed GitHub clones in production tree.
- Generate SBOM via `Scripts/generate-sbom` before release.
- Pin versions; record in OPEN_SOURCE_REGISTRY.
