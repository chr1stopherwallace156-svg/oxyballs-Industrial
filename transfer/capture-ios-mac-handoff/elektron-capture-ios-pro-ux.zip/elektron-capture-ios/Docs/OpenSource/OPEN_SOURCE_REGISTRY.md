# OPEN_SOURCE_REGISTRY.md

| Dependency | Version | License | Use | Status |
|---|---|---|---|---|
| *(none yet)* | — | — | — | — |

Research-only clones belong in `ResearchReferences/` (gitignored).
