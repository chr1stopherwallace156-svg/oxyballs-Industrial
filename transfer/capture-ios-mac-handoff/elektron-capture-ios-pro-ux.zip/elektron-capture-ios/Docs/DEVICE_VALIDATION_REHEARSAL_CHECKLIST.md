# DEVICE_VALIDATION_REHEARSAL_CHECKLIST.md

| Field | Value |
|---|---|
| Session | `DEVICE_VALIDATION_REHEARSAL` |
| Authority | `NON_AUTHORITATIVE` |
| Content | `CONTENT_UNVERIFIED` |
| Branch | `feature/phase1-single-still-runtime` |
| Commit SHA | _(fill)_ |
| Device / iOS | _(fill)_ |
| Date (UTC) | _(fill)_ |
| Operator | _(fill)_ |

Use only: **PASS** · **FAIL** · **BLOCKED** · **UNVERIFIED**

| Check | Result | Notes |
|---|---|---|
| Xcode project opens (`Phase1StillCapture.xcodeproj`) | UNVERIFIED | |
| Local `ElektronCapture` package resolves | UNVERIFIED | |
| Xcode build result | UNVERIFIED | |
| Signing result (Automatic + Team) | UNVERIFIED | |
| Physical installation result | UNVERIFIED | |
| Launch result | UNVERIFIED | |
| Camera permission result | UNVERIFIED | |
| Still-photo capture result | UNVERIFIED | |
| Original-byte acquisition (`fileDataRepresentation`) | UNVERIFIED | |
| SHA-256 result (shown in UI) | UNVERIFIED | hex: |
| Manifest result (capture-side) | UNVERIFIED | |
| Package inventory result | UNVERIFIED | |
| `.edts-pkg` export result | UNVERIFIED | path: |
| Transfer-to-Mac result (Share/AirDrop/Files) | UNVERIFIED | |
| Importer result (`xrepo_cap_edts`) | UNVERIFIED | |
| Payload hash verification result | UNVERIFIED | |
| Final status result | UNVERIFIED | expect integrity verified + content unverified |

## Final status (EDTS, after ingest)

Record exactly what the importer returned:

```text
canonical_compatibility:
secure_ingestion:
committed:
edts_status:
```

Allowed successful rehearsal outcome:

```text
INGESTED_INTEGRITY_VERIFIED
CONTENT_UNVERIFIED
```

## Explicit non-claims

- [ ] I did **not** claim XREPO PASS inside the iPhone UI  
- [ ] I did **not** treat this as authoritative F-450 evidence  
- [ ] I did **not** run the full guided VIN/door/exterior campaign  

## Blockers

_(list anything BLOCKED and why)_
