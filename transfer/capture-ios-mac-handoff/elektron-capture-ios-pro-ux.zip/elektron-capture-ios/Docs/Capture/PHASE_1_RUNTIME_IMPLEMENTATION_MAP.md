# Phase 1 Runtime — Implementation Map

Branch: `feature/phase1-single-still-runtime`  
Baseline: `capture-ios-phase1-directive-v0.1.4` @ `338d436` (tags not moved)

## 1. Swift package / Xcode structure

| Item | Status |
|---|---|
| `Package.swift` → library `ElektronCapture` | Present |
| Thin iOS host `.xcodeproj` | **Present** — `Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj` (links local package; no logic duplication) |
| Compiled: Application, Domain, Export, EDTSClient, Provenance (partial), Storage | Present |
| Excluded scaffolding: UI, Capture, Motion, Calibration, Quality | Was README-only |

## 2. Contracts

Schemas under `Contracts/` including EvidenceManifest, PackageInventory, CaptureDeviceProvenance, status-owner-registry. Phase 1 `.edts-pkg` format in `Docs/Evidence/EDTS_PKG_FORMAT.md`.

## 3. Canonical JSON

`App/Application/CanonicalJSON.swift` — sorted-key compact UTF-8. Spec: `Docs/Validation/CANONICAL_JSON.md`.

## 4. Status-owner registry

`Contracts/Compatibility/status-owner-registry.json` + `StatusOwnerRegistry` / `CaptureSideStatusGuard` in `CaptureSideStatus.swift`. Sync: `Scripts/test-status-owner-registry`.

## 5. Package export (pre-runtime)

`FileEvidenceExporter` = Path A session tree only. No `.edts-pkg` / `package_inventory.json` builder yet.

## 6. Missing → implementing on this branch

CameraAuthorizationService, CameraSessionController, StillPhotoCaptureService, ArtifactPersistenceService, ArtifactHashingService, CaptureClockService, MotionSampleService, DeviceProvenanceService, EvidenceManifestBuilder, CanonicalJSONEncoder, PackageInventoryBuilder, EvidencePackageBuilder, Phase1CaptureCoordinator. CaptureSideStatusGuard already exists.

## 7. Doc ↔ code mismatches (handled in implementation)

| Topic | Resolution |
|---|---|
| Path A golden vs Phase 1 `.edts-pkg` | New builder emits `.edts-pkg` layout; Path A exporter retained |
| `phase1_still.manifest.example.json` extra fields vs schema `additionalProperties: false` | Schema-valid `manifest.json`; Phase 1 authority/calibration/motion in `package_status.json` + `sidecars/` so EDTS XREPO-0001 still validates |
| No `package_status.json` in prior code | Added for capture-side status declaration |
| No physical Xcode app | `Apps/Phase1StillCapture/` SwiftUI shell (wire in Xcode on Mac) |

## Explicit non-goals

ARKit, LiDAR, photogrammetry, Photo Library writes, UIImage re-encode, Build Engine.
