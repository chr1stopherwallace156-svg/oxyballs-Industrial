# Phase 1 still-capture UI state machine

Status: CANDIDATE  
Scope: Phase 1 single-still only — no video / ARKit / LiDAR / EDTS claims.

## Exact progression

```text
[ App Launch ]
      │
      ▼
┌──────────────┐    (User adjusts Flash / Torch / Lens / Focus / Zoom / Grid)
│  PREVIEWING  │ ◄──────────────────────────────────────────────┐
└──────┬───────┘                                                │
       │ (User taps Take Photo / Shutter)                       │
       ▼                                                        │
┌──────────────┐                                                │
│  CAPTURING   │ ──► (photo.fileDataRepresentation() returned)   │
└──────┬───────┘                                                │
       ▼                                                        │
┌──────────────┐     Selects "Retake"                           │
│  REVIEWING   │ ───────────────────────────────────────────────┤
└──────┬───────┘                                                │
       │ Selects "Use Photo" (quality guard may block → stay)   │
       ▼                                                        │
┌──────────────┐                                                │
│   APPROVED   │ ──► (bytes + SHA sealed for export; no write)  │
└──────┬───────┘                                                │
       │ (User taps Export Package)                             │
       ▼                                                        │
┌──────────────┐                                                │
│   EXPORTED   │ ──► (.edts-pkg written & shared)               │
└──────────────┘                                                │
       │ New Capture
       └──────────► PREVIEWING
```

## Illegal transitions (must throw / no-op)

| From | To | Why illegal |
|---|---|---|
| `previewing` | `approved` / `exported` | Must capture + review first |
| `capturing` | `approved` / `exported` | Must review |
| `reviewing` | `exported` | Must approve (“Use Photo”) first |
| `*` | `capturing` | Only from `previewing` with shutter enabled |
| any auto-capture on view load | — | Forbidden |

## Integrity invariants

1. Authoritative bytes = exact `AVCapturePhoto.fileDataRepresentation()`.
2. Preview / thumbnail / quality decode are throwaway — never rewrite artifact bytes.
3. Post-delegate SHA-256 == `payload/artifact_original.jpg` SHA-256 after export.
4. Package assembly begins only in `approved` → `exported`.

## Readiness overlay (while `previewing`)

`Starting Camera` → `Adjusting` → `Ready` | `Error`  
Shutter enablement: session running + preview attached + warm-up elapsed + no fatal error.  
**Not** hard-blocked on continuous `isAdjustingExposure` / `isAdjustingFocus`.
