# Runtime Engineering Rules

Permanent rules derived from runtime incidents. Append new rules; do not rewrite closed ones.

| ID | Title | Source Incident | Status |
|----|-------|-----------------|--------|
| R-001 | Preserve underlying runtime errors | P1R-001 | Active |

---

## R-001 — Preserve underlying runtime errors

```text
Runtime Rule R-001

Every runtime failure must preserve:

• stage
• underlying Swift error type
• String(describing:)
• String(reflecting:)
• localizedDescription
• coding/key path when applicable

No generic runtime status (e.g. CANONICALIZATION_FAILED) may replace the
underlying error without recording it alongside the status code.

UI must surface both reasonCode and detailMessage (or equivalent).
Busy/Working state must reset via defer or equivalent on all exits.
```

**Rationale:** P1R-001 hid `Unsupported JSON type Optional<…>` behind `FAIL CANONICALIZATION_FAILED`, delaying root-cause isolation.
