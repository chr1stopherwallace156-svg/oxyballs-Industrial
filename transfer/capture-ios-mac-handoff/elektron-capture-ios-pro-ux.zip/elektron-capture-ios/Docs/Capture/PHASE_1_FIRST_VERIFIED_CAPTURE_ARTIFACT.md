# PHASE_1_FIRST_VERIFIED_CAPTURE_ARTIFACT.md

| Field | Value |
|---|---|
| Status | **APPROVED** (implementation directive) |
| Version | 1.0.0 |
| Owner | elektron-capture-ios |
| Last Updated | 2026-07-23 |
| Applies To | Phase 1 only |
| Supersedes | Informal “controlled still capture” sketch in ROADMAP 0.1.1 |

## Title

**PHASE 1 — FIRST VERIFIED CAPTURE ARTIFACT**

Framing: *First Verified Evidence* means the pipeline guarantees provenance, immutability, and integrity of a **single** AVFoundation-produced still. It does **not** mean the physical scene depicted has been proven true.

## Mindset

The iOS app is a **provenance-preserving cryptographic witness**.

```
The phone verifies integrity and origin context of an artifact.
It does not verify the engineering truth depicted by that artifact.
```

If the pipeline cannot guarantee provenance, immutability, and validation of one encoded still today, it will fail for 100-image sets or large point clouds later.

## Boundary diagram

```
┌─────────────────────────────────────────────────────────────┐
│                     iOS CAPTURE CLIENT                      │
│  AVFoundation still (configured capture)                    │
│       │                                                     │
│       ├──► Exact AVFoundation-produced encoded bytes        │
│       │         → persist once → read back → SHA-256        │
│       ├──► Apple metadata sidecar (immutable)               │
│       ├──► Optional AVCameraCalibrationData (or NOT_AVAILABLE)│
│       └──► Optional motion sample (GUIDANCE_ESTIMATE)       │
│                           ▼                                 │
│                 EvidenceManifest + package_inventory        │
└───────────────────────────┬─────────────────────────────────┘
                            │  .edts-pkg (transport)
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    EDTS INGESTION SERVER                    │
│  Receive → quarantine → safe inspect → stage → validate     │
│  → recompute hashes → commit or reject                      │
│  Status: INGESTED_INTEGRITY_VERIFIED + CONTENT_UNVERIFIED   │
│  No Build Engine / policy / metrology calls                 │
└─────────────────────────────────────────────────────────────┘
```

## What Phase 1 verifies

| Verified | Not verified |
|---|---|
| Source application workflow | Physical dimensions |
| Artifact byte integrity after capture | Object identity |
| Package structure + inventory | Camera metrology accuracy |
| Provenance completeness | Spatial accuracy |
| Schema compliance | Technician interpretation |
| Successful EDTS transport/storage | Engineering suitability |

EDTS commit status (normative — **EDTS assigns only**):

- `INGESTED_INTEGRITY_VERIFIED`
- `CONTENT_UNVERIFIED`

Capture-side may assert only: `CAPTURE_*` … `PACKAGE_EXPORTED` / `CAPTURE_SEALED`.  
See `Docs/Architecture/STATUS_TAXONOMY.md`.

Do **not** use language that implies the photograph’s subject was validated.

## Hard prohibitions (Phase 1)

1. Do **not** call JPEG/HEIF a RAW stream. Use `APPLE_ENCODED_JPEG` / `APPLE_ENCODED_HEIF` / etc.
2. Do **not** write to the public Photos library (`UIImageWriteToSavedPhotosAlbum` forbidden).
3. Do **not** `UIImage` round-trip, resize, or recompress before hashing.
4. Do **not** fabricate intrinsics from image size or nominal phone specs.
5. Do **not** use technician-renamed device names as identity.
6. Do **not** claim permanent hardware serial/UDID disclosure.
7. Do **not** call Build Engine or emit approval tokens.
8. Do **not** start ARKit / LiDAR / multi-image photogrammetry in Phase 1.
9. Do **not** treat ZIP container bytes as the ultimate evidence identity.

## Artifact originality language

```json
{
  "role": "ORIGINAL_CAPTURE_OUTPUT",
  "representation": "APPLE_ENCODED_JPEG",
  "originality": "ORIGINAL_CAPTURE_OUTPUT",
  "pixel_processing_claim": "NOT_ASSERTED"
}
```

**Original** means: the exact encoded bytes returned by the configured AVFoundation capture pipeline were preserved unchanged after receipt — **not** an optically untouched sensor dump.

RAW (`APPLE_RAW` / DNG) is out of Phase 1 unless a separate decision explicitly scopes it.

## Camera calibration

`AVCameraCalibrationData` is **optional**. Valid Phase 1 result:

```json
"camera_calibration": {
  "availability": "NOT_AVAILABLE",
  "authority": null,
  "intrinsic_matrix": null,
  "intrinsic_matrix_reference_dimensions_px": null
}
```

Availability enum:

- `APPLE_REPORTED`
- `NOT_AVAILABLE`
- `UNSUPPORTED_CAPTURE_CONFIGURATION`
- `EXTRACTION_FAILED`

When present, always record reference image dimensions with the intrinsic matrix.

## Device identity

Use controlled identifiers only (see CaptureDeviceProvenance):

- `device_profile_id`
- `hardware_model_identifier`
- `installation_enrollment_id` / `capture_installation_id`
- `app_attest_key_id` (server-managed reference)
- `os_version` / `os_build` recorded at runtime
- `device_display_name` — UI only, never authoritative

## Motion / orientation (optional in Phase 1)

If recorded, must include reference frame + synchronization:

- `authority`: `GUIDANCE_ESTIMATE`
- `reference_frame` (e.g. `X_ARBITRARY_CORRECTED_Z_VERTICAL`)
- photo vs sample timestamps + `synchronization_delta_ms`
- quaternion authoritative; Euler convenience derivative
- `true_north_claimed`: false unless proven
- magnetometer accuracy when relevant

Ambiguous lone `yaw_deg` without frame is **rejected**.

## Package transport vs evidence identity

| Layer | Role |
|---|---|
| Exact artifact bytes | Evidence |
| Canonical manifest bytes | Evidence binding |
| `package_inventory.json` | Declared paths + sizes + hashes |
| `.edts-pkg` ZIP | **Transport only** — may vary by compressor |

See `EDTS_PKG_FORMAT.md`.

## EDTS ingestion states

```
RECEIVED
QUARANTINED
VALIDATING
REJECTED
VERIFIED_TRANSPORT_INTEGRITY
COMMITTED_UNVERIFIED_EVIDENCE   (= integrity verified, content unverified)
```

HTTP:

- `201` — committed synchronously (include `ingestion_id` + status)
- `202` — quarantined / verification pending (include `ingestion_id` + status)
- Success is defined by **ingestion state**, not status code alone

## Hostile archive defenses (EDTS — XREPO)

Importer must reject: path traversal, absolute paths, symlinks, duplicate/case-collision names, bombs, excessive count/size, undeclared/missing files, nested archives, MIME mismatches.

Never extract client archives directly into permanent storage.

## Cross-language canonical proof

Required before `EDTS_COMPATIBLE`: Swift and EDTS canonicalizers produce identical canonical manifest bytes + SHA-256 on shared fixtures.

## Implementation order for Phase 1 code (after this directive)

1. Mac/Xcode app shell  
2. Minimal shutter → isolate `Data` buffer  
3. Persist encoded bytes once; read back; hash  
4. Metadata sidecar + honest calibration availability  
5. Optional motion sample with frame/sync  
6. Build `.edts-pkg` with inventory  
7. EDTS quarantine ingest (XREPO)  
8. Pass 16-point acceptance gate in `ACCEPTANCE_CRITERIA.md`

Do not open Phase 2 until that gate passes.
