# PHASE_1_IMPLEMENTATION_STATUS.md

| Field | Value |
|---|---|
| Branch | `feature/phase1-single-still-runtime` |
| Directive baseline | `capture-ios-phase1-directive-v0.1.4` @ `338d436` |
| Runtime classification | **`PHASE_1_RUNTIME_IMPLEMENTED_PENDING_DEVICE_VALIDATION`** |
| Runtime code | **Present** (fixture pipeline + AVFoundation `fileDataRepresentation` path) |
| Simulator validation | **`BLOCKED_BY_ENVIRONMENT`** (Linux / no Xcode) |
| Physical-device validation | **Physical export path DEMONSTRATED** on device; black-frame cause **UNDER INSTRUMENTATION**; Phase 1 still **INCOMPLETE** until automated tests + non-black capture acceptance |
| Synthetic fixture → EDTS | Exercised against EDTS importer (see procedure doc) |
| Phase 1 implementation complete | **No** |

Runtime incident log: [`Docs/Incidents/`](../Incidents/) — P1R-001 path exercised; black-frame investigation is separate from canonicalization repair.

```
PHASE_1_DIRECTIVE_APPROVED ≠ PHASE_1_IMPLEMENTATION_COMPLETE
Physical export DEMONSTRATED ≠ Phase 1 complete (tests + quality still gate)
```

## Validation scopes (do not conflate)

| Scope | Who | Meaning |
|---|---|---|
| Capture-side | This app / `CaptureSidePackageValidator` | Schema layout, canonical bytes, inventory hashes, capture-only lifecycle |
| EDTS XREPO-0001 / 0002 | EDTS importer only | Canonical compatibility + secure ingest + commit |

The iPhone UI must **never** display XREPO PASS from local checks.

## Components

| Component | Location |
|---|---|
| CameraAuthorizationService | `App/Capture/AVFoundation/Phase1CameraServices.swift` |
| CameraSessionController | same |
| InteractiveStillCaptureController | same (preview + warm-up shutter; no AE deadlock) |
| StillPhotoCaptureService | same (`photo.fileDataRepresentation()` one-shot) |
| CaptureLifecycleInstrumenter | `App/Phase1/` |
| CaptureImageQualityGuard | `App/Phase1/` (`CAPTURE_QUALITY_IMAGE_EFFECTIVELY_BLACK`) |
| ArtifactPersistenceService | `App/Phase1/` |
| ArtifactHashingService | `App/Phase1/` |
| CaptureClockService | `App/Phase1/` |
| MotionSampleService | `App/Phase1/` (optional / `NOT_AVAILABLE`) |
| DeviceProvenanceService | `App/Phase1/` |
| EvidenceManifestBuilder | `App/Phase1/` |
| CanonicalJSONEncoder | `App/Phase1/` |
| PackageInventoryBuilder | `App/Phase1/` |
| EvidencePackageBuilder | `App/Phase1/` |
| CaptureSidePackageValidator | `App/Phase1/` |
| CaptureSideStatusGuard | `App/Domain/Models/CaptureSideStatus.swift` |
| Phase1CaptureCoordinator | `App/Phase1/` |
| App shell | `Apps/Phase1StillCapture/` |

## Honest limits

- Current cloud agent environment: **Linux**, no `swift` / Xcode / physical device.
- Do not fabricate simulator or device results.
- Final Phase 1 completion requires `Docs/Capture/PHASE_1_PHYSICAL_DEVICE_PROCEDURE.md`.
