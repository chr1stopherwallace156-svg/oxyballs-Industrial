# Capture image quality guard (non-authoritative)

| Field | Value |
|---|---|
| Status | CANDIDATE |
| Reason code | `CAPTURE_QUALITY_IMAGE_EFFECTIVELY_BLACK` |
| Authority | Capture-side only — does **not** claim engineering/metrology truth |

## Purpose

Reject packaging of stills that are effectively black on a **throwaway inspection decode**, while leaving `AVCapturePhoto.fileDataRepresentation()` bytes untouched.

Physical export success with a black frame is a demonstrated runtime milestone, not Phase 1 completion. Automated tests must also pass.

## Dual criteria (both required)

Default thresholds (`CaptureImageQualityThresholds.phase1Default`):

| Threshold | Default | Meaning |
|---|---|---|
| `maxMeanLuminance` | `8.0` | Mean luma (0…255) must be ≤ this |
| `minNearBlackFraction` | `0.98` | ≥ this fraction of samples must be ≤ `nearBlackMax` |
| `nearBlackMax` | `8` | Per-pixel near-black ceiling |
| `maxSamples` | `10000` | Stride-sampled inspection budget |

Reject only when **mean ≤ maxMeanLuminance AND nearBlackFraction ≥ minNearBlackFraction**.

## Non-goals

- Do not treat AE/AF settling as proven black-frame root cause without lifecycle logs.
- Do not resize/recompress/replace original JPEG bytes for the guard.
- Synthetic luminance fixtures prove the guard logic — never physical-camera success.

## Lifecycle instrumentation (required before behavior conclusions)

Log with high-resolution timestamps:

`session_start_requested`, `session_running_changed`, `preview_attached`, `device_adjusting_exposure`, `device_adjusting_focus`, `shutter_enabled`, `shutter_pressed`, `photo_delegate_received`, `image_quality_result`

Also record:

- ms from session-running → shutter-enabled
- ms from shutter-pressed → photo-delegate

Shutter enablement uses session running + preview attached + warm-up interval. Do **not** hard-block on `isAdjustingExposure` / `isAdjustingFocus`.
