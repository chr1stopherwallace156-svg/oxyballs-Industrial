# CALIBRATION_STANDARD.md

| Field | Value |
|---|---|
| Status | **DRAFT** |
| Version | 1.0.0 |
| Owner | elektron-capture-ios |
| Last Updated | 2026-07-23 |
| Applies To | Camera calibration profiles |
| Supersedes | (none) |

## Sources / provenance

`APPLE_REPORTED` · `ARKit_REPORTED` · `TARGET_CALIBRATED` · `FIELD_REVALIDATED` · `THIRD_PARTY_ESTIMATED` · `UNKNOWN` · `EXPIRED` · `REJECTED`

## Apple-native first

Prefer `AVCameraCalibrationData` fields (intrinsics, reference dimensions, lens distortion center, radial lookup tables) over forcing only OpenCV `k1,k2,p1,p2`.

OpenCV-compatible coefficients are **derivatives** with parent calibration hash + conversion algorithm version.

## Required record fields

device profile · camera · resolution · focus state (if relevant) · temperature (if relevant) · method · target · sample count · residuals · validation · date · expiration · software version · operator · reviewer

Invalidate when applicable conditions change.
