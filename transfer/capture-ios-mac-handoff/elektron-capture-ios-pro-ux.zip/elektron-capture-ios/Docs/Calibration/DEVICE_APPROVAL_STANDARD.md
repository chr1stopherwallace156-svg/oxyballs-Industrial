# DEVICE_APPROVAL_STANDARD.md

| Field | Value |
|---|---|
| Status | **DRAFT** |
| Version | 1.0.0 |
| Owner | elektron-capture-ios |
| Last Updated | 2026-07-23 |
| Applies To | Approved capture devices |
| Supersedes | (none) |

## v1 policy

Standardize on **one LiDAR-equipped iPhone Pro** profile before broad device support.

## Registry fields

device profile ID · commercial model · hardware identifier (enrollment-facing, not permanent consumer UID abuse) · supported iOS versions · approved rear camera · LiDAR availability · approved capture resolution · approved application version · calibration profile · calibration date/expiration · protective case configuration · lens inspection status · validation test version · approval status

## Unsupported devices

Either refuse engineering capture **or** enter clearly labeled non-authoritative demonstration mode.

## Identity

Use Elektron installation ID + attested app key ID + approved-device enrollment — not permanent hardware UDIDs.
