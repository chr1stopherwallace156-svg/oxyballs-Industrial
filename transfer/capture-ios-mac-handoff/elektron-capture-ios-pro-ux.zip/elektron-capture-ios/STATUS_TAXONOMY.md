# STATUS_TAXONOMY

Canonical: [`Docs/Architecture/STATUS_TAXONOMY.md`](Docs/Architecture/STATUS_TAXONOMY.md)
