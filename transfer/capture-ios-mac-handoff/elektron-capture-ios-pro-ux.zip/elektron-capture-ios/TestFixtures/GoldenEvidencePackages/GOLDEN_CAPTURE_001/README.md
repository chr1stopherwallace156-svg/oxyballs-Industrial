# GOLDEN_CAPTURE_001

Non-sensitive golden portable evidence package (Path A layout).

Synthetic artifact bytes only. Used by `Scripts/verify-evidence-package` and Swift golden tests.
