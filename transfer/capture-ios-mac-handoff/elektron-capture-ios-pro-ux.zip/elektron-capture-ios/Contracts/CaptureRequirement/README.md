# CaptureRequirement

v1 embeds requirements inside `CapturePlan`. Standalone schema reserved for a future split when plans and requirements version independently.
