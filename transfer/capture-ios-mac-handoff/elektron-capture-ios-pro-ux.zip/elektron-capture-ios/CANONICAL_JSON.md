# CANONICAL_JSON

Canonical: [`Docs/Validation/CANONICAL_JSON.md`](Docs/Validation/CANONICAL_JSON.md)
