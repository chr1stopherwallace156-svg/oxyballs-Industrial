# DEPENDENCY_POLICY

Canonical document: [`Docs/OpenSource/DEPENDENCY_POLICY.md`](Docs/OpenSource/DEPENDENCY_POLICY.md)

This root file exists so repository checklists and Cursor rules can reference a stable top-level name. Edit the Docs/ path above; keep this pointer in sync if the canonical path moves.
