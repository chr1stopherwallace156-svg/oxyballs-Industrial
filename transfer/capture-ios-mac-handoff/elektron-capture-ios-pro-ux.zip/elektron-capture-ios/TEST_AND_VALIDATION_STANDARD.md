# TEST_AND_VALIDATION_STANDARD

Canonical document: [`Docs/Validation/TEST_AND_VALIDATION_STANDARD.md`](Docs/Validation/TEST_AND_VALIDATION_STANDARD.md)

This root file exists so repository checklists and Cursor rules can reference a stable top-level name. Edit the Docs/ path above; keep this pointer in sync if the canonical path moves.
