# OPEN_SOURCE_REGISTRY

Canonical document: [`Docs/OpenSource/OPEN_SOURCE_REGISTRY.md`](Docs/OpenSource/OPEN_SOURCE_REGISTRY.md)

This root file exists so repository checklists and Cursor rules can reference a stable top-level name. Edit the Docs/ path above; keep this pointer in sync if the canonical path moves.
