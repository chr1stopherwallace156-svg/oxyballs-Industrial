# CONTRACT_OWNERSHIP

Canonical: [`Docs/Integration/CONTRACT_OWNERSHIP.md`](Docs/Integration/CONTRACT_OWNERSHIP.md)

