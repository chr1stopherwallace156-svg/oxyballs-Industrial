# EVIDENCE_PACKAGE_STANDARD

Canonical document: [`Docs/Evidence/EVIDENCE_PACKAGE_STANDARD.md`](Docs/Evidence/EVIDENCE_PACKAGE_STANDARD.md)

This root file exists so repository checklists and Cursor rules can reference a stable top-level name. Edit the Docs/ path above; keep this pointer in sync if the canonical path moves.
