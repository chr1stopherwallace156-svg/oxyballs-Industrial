# elektron-capture-ios

**Independent** iPhone engineering-evidence capture application for EDTS.

| This repository **is** | This repository **is not** |
|---|---|
| A standalone capture **instrument** | Inside `edts-core` or `build-engine` |
| Apple-native (AVFoundation / ARKit / Core Motion) | An Android Camera2/ARCore port |
| Versioned and released on its own | An EDTS truth / Build Engine engine |

```
Physical vehicle → Calibrated capture → Spatial evidence package → EDTS → Build Engine
```

## Version

**0.1.4** — Phase 0 approved; Phase 1 **`PHASE_1_DIRECTIVE_APPROVED ≠ PHASE_1_IMPLEMENTATION_COMPLETE`**. Runtime code for single-still → `.edts-pkg` is on `feature/phase1-single-still-runtime`; physical-device EDTS pass **not yet recorded**. Still `PACKAGE_EXPORT_READY`.


```json
{
  "capture_app_version": "0.1.4",
  "evidence_schema_version": "1.0.0",
  "capture_plan_schema_version": "1.0.0",
  "edts_api_version": "v1",
  "platform": "iphone_apple_native",
  "integration_status": "PACKAGE_EXPORT_READY"
}
```

## Quick start

```bash
cd elektron-capture-ios
./Scripts/validate-contracts
./Scripts/test-contract-negatives
./Scripts/test-determinism
./Scripts/test-schema-migration
./Scripts/test-status-owner-registry
./Scripts/build-phase1-fixture-package
./Scripts/verify-evidence-package TestFixtures/GoldenEvidencePackages/GOLDEN_CAPTURE_001
./Scripts/run-security-checks
swift test   # on macOS / Swift toolchain — includes Phase1RuntimeTests
```

Phase 1 directive: `Docs/Capture/PHASE_1_FIRST_VERIFIED_CAPTURE_ARTIFACT.md`.  
Phase 1 runtime status: `Docs/Capture/PHASE_1_IMPLEMENTATION_STATUS.md`.  
Physical device + EDTS procedure: `Docs/Capture/PHASE_1_PHYSICAL_DEVICE_PROCEDURE.md`.  
**Open in Xcode (iPhone Run):** `Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj` — see `Docs/PHYSICAL_IPHONE_VALIDATION_RUNBOOK.md`.  
App shell sources: `Apps/Phase1StillCapture/`.

Read first: `CURSOR_OPERATING_RULES.md`, `FOUNDATION_VERIFICATION_REPORT.md`, `ACCEPTANCE_CRITERIA.md`, `PHASE_0_REVIEW.md`, `Docs/Integration/XREPO/XREPO-CAP-EDTS-0001.md`.

## Boundaries (summary)

**Owns:** guided capture, Apple capture/spatial/motion adapters, local evidence, manifests, hashing, attestation hooks, export.  
**Does not own:** engineering approval, Build Engine authorization, certified metrology claims from ARKit alone.  
**Must never emit:** `BUILD_AUTHORIZED` / `STRUCTURALLY_APPROVED` / `DESIGN_SAFE` / `VEHICLE_COMPLIANT`.  
**Must never self-assign:** any status with `owner: EDTS` in `status-owner-registry.json`.

## Current phase

**Phase 0 foundation:** Approved.  
**Phase 1 directive:** Approved (`PHASE_1_DIRECTIVE_APPROVED`).  
**Phase 1 runtime:** `PHASE_1_RUNTIME_IMPLEMENTED_PENDING_DEVICE_VALIDATION`.  
**Simulator / physical validation here:** `BLOCKED_BY_ENVIRONMENT`.  
**Phase 1 implementation complete:** **No**.
