import XCTest
@testable import ElektronCapture

final class AuthorityGuardTests: XCTestCase {
  func testRejectsForbiddenClaims() {
    for claim in ForbiddenAuthorityClaim.allCases {
      XCTAssertThrowsError(try AuthorityGuard.rejectForbiddenClaims(in: "status=\(claim.rawValue)"))
    }
  }

  func testAllowsNeutralText() throws {
    try AuthorityGuard.rejectForbiddenClaims(in: "EVIDENCE_ACCEPTED pending review")
  }
}

final class EvidenceManifestValidatorTests: XCTestCase {
  func testRejectsDerivativeWithoutParent() {
    let art = LocalArtifactRef(
      artifactId: "ART-D",
      relativePath: "derivatives/x.bin",
      sha256: String(repeating: "ab", count: 32),
      mediaType: "application/octet-stream",
      capturedAt: Date(timeIntervalSince1970: 0),
      clockDomain: "wall",
      authority: .algorithmEstimate,
      isOriginal: false,
      parentArtifactIds: []
    )
    XCTAssertThrowsError(try EvidenceManifestValidator.validateArtifact(art, sessionSealed: true))
  }

  func testRejectsEmptyHash() {
    let art = LocalArtifactRef(
      artifactId: "ART-1",
      relativePath: "originals/images/a.bin",
      sha256: "",
      mediaType: "application/octet-stream",
      capturedAt: Date(timeIntervalSince1970: 0),
      clockDomain: "wall"
    )
    XCTAssertThrowsError(try EvidenceManifestValidator.validateArtifact(art, sessionSealed: true))
  }

  func testRejectsEngineeringVerifiedFromCapture() {
    let art = LocalArtifactRef(
      artifactId: "ART-1",
      relativePath: "originals/images/a.bin",
      sha256: String(repeating: "ab", count: 32),
      mediaType: "application/octet-stream",
      capturedAt: Date(timeIntervalSince1970: 0),
      clockDomain: "wall",
      authority: .engineeringVerified
    )
    XCTAssertThrowsError(try EvidenceManifestValidator.validateArtifact(art, sessionSealed: false))
  }

  func testRejectsMeasurementWithoutUnit() {
    let v = UncertainValue(value: 860, unit: "  ", authority: .guidanceEstimate)
    // trim check — empty after trim
    var bad = v
    bad = UncertainValue(value: 860, unit: "", authority: .guidanceEstimate)
    XCTAssertThrowsError(try EvidenceManifestValidator.validateMeasurement(bad))
  }

  func testRejectsAnonymousPoseFrames() {
    let pose = SpatialPose(
      transformId: "TRN-1",
      sourceFrame: "",
      targetFrame: "",
      values: Array(repeating: 0, count: 16),
      timestamp: TimestampValue(value: 1, clockDomain: .arkitFrame)
    )
    XCTAssertThrowsError(try EvidenceManifestValidator.validatePose(pose))
  }

  func testRejectsForbiddenClaimEmbeddedInExportValidation() {
    let session = LocalCaptureSession(sessionId: "SESSION-BUILD_AUTHORIZED-X")
    let art = LocalArtifactRef(
      artifactId: "ART-1",
      relativePath: "originals/images/a.bin",
      sha256: String(repeating: "ab", count: 32),
      mediaType: "application/octet-stream",
      capturedAt: Date(timeIntervalSince1970: 0),
      clockDomain: "wall"
    )
    XCTAssertThrowsError(
      try EvidenceManifestValidator.validateSessionForExport(session, artifacts: [art])
    )
  }

  func testCanonicalJSONStable() throws {
    let obj: [String: Any] = ["b": 1, "a": ["z": true, "y": 2]]
    let s1 = try CanonicalJSON.string(obj)
    let s2 = try CanonicalJSON.string(obj)
    XCTAssertEqual(s1, s2)
    XCTAssertTrue(s1.hasPrefix("{\"a\":"))
  }

  func testCanonicalJSONIndependentOfInsertionOrder() throws {
    let a: [String: Any] = ["z": 1, "a": ["y": 2, "b": true]]
    let b: [String: Any] = ["a": ["b": true, "y": 2], "z": 1]
    XCTAssertEqual(try CanonicalJSON.string(a), try CanonicalJSON.string(b))
  }

  func testCanonicalJSONRejectsNonFinite() {
    XCTAssertThrowsError(try CanonicalJSON.string(["x": Double.nan]))
  }
}

final class ProductionConfigurationGuardTests: XCTestCase {
  func testProductionRejectsMocks() {
    XCTAssertThrowsError(
      try ProductionConfigurationGuard.validate(
        environment: .production,
        providers: [MockEDTSClient(), MockAttestationVerifier(), LocalCapturePlanProvider()]
      )
    )
  }

  func testDevelopmentAllowsMocks() throws {
    try ProductionConfigurationGuard.validate(
      environment: .developmentMock,
      providers: [MockEDTSClient(), MockAttestationVerifier()]
    )
  }

  func testTestAllowsMocks() throws {
    try ProductionConfigurationGuard.validate(
      environment: .test,
      providers: [MockEDTSClient()]
    )
  }
}

final class ContentHasherTests: XCTestCase {
  func testSha256KnownVector() {
    let data = Data("abc".utf8)
    let hex = ContentHasher.sha256Hex(data)
    XCTAssertEqual(
      hex,
      "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
    )
  }
}

final class CaptureSessionStateMachineTests: XCTestCase {
  func testLegalTransition() throws {
    let ts = TimestampValue(value: 1, clockDomain: .wall)
    let t = try CaptureSessionStateMachine.transition(
      from: .created,
      to: .deviceCheck,
      actorId: "OPERATOR-001",
      reason: "start",
      at: ts,
      softwareVersion: "0.1.1"
    )
    XCTAssertEqual(t.to, .deviceCheck)
  }

  func testIllegalTransitionThrows() {
    let ts = TimestampValue(value: 1, clockDomain: .wall)
    XCTAssertThrowsError(
      try CaptureSessionStateMachine.transition(
        from: .created,
        to: .sealed,
        actorId: "OPERATOR-001",
        reason: "skip",
        at: ts,
        softwareVersion: "0.1.1"
      )
    )
  }

  func testGuidanceAuthorityDefaultForPose() {
    let pose = SpatialPose(
      transformId: "TRN-1",
      sourceFrame: "camera",
      targetFrame: "arkit_world",
      values: Array(repeating: 0, count: 16),
      timestamp: TimestampValue(value: 1, clockDomain: .arkitFrame)
    )
    XCTAssertEqual(pose.authority, .guidanceEstimate)
  }
}

final class MockEDTSClientTests: XCTestCase {
  func testMockIsLabeled() {
    let client = MockEDTSClient()
    XCTAssertTrue(client.isMock)
  }

  func testSubmitRejectsMissingManifest() async throws {
    let client = MockEDTSClient()
    let dir = FileManager.default.temporaryDirectory
      .appendingPathComponent("cap-empty-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: dir) }
    let status = try await client.submitEvidencePackage(directoryURL: dir)
    XCTAssertEqual(status, .evidenceRejected)
  }

  func testSubmitAcceptsEvidenceManifestPresence() async throws {
    let client = MockEDTSClient()
    let dir = FileManager.default.temporaryDirectory
      .appendingPathComponent("cap-pkg-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: dir) }
    try Data("{}".utf8).write(to: dir.appendingPathComponent("evidence_manifest.json"))
    let status = try await client.submitEvidencePackage(directoryURL: dir)
    XCTAssertEqual(status, .engineeringReviewRequired)
  }

  func testBuiltinPlanLoads() async throws {
    let provider = LocalCapturePlanProvider()
    let plan = try await provider.loadPlan(planId: "PLAN-MOCK")
    XCTAssertEqual(plan.schemaId, "CapturePlan")
    XCTAssertFalse(plan.requirements.isEmpty)
  }

  func testAdapterMocksLabeled() {
    XCTAssertTrue(MockCameraCaptureProvider().isMock)
    XCTAssertTrue(MockSpatialTrackingProvider().isMock)
    XCTAssertTrue(MockMotionSampleProvider().isMock)
    XCTAssertTrue(MockDepthProvider().isMock)
    XCTAssertTrue(MockAttestationProvider().isMock)
    XCTAssertTrue(LocalCapturePlanProvider().isMock)
  }
}

final class ImmutableFileStoreTests: XCTestCase {
  func testWriteImmutablePreventsOverwrite() throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("cap-store-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: root) }
    let store = ImmutableFileStore()
    let hash1 = try store.writeImmutable(data: Data("one".utf8), to: "a.bin", under: root)
    XCTAssertFalse(hash1.isEmpty)
    XCTAssertThrowsError(try store.writeImmutable(data: Data("two".utf8), to: "a.bin", under: root))
  }
}

final class UncertainValueTests: XCTestCase {
  func testUnknownUncertaintyWhenNil() {
    let v = UncertainValue(value: 860, unit: "mm", authority: .guidanceEstimate)
    XCTAssertEqual(v.uncertaintyStatus, .unknown)
  }
}

final class CaptureSideStatusTests: XCTestCase {
  func testAcceptsCaptureSideStatuses() throws {
    XCTAssertEqual(
      try CaptureSideStatusGuard.parseCaptureSide("CAPTURE_SEALED"),
      .captureSealed
    )
    XCTAssertEqual(
      try CaptureSideStatusGuard.parseCaptureSide("PACKAGE_EXPORTED"),
      .packageExported
    )
  }

  func testRejectsAllRegistryEdtsOwnedStatuses() {
    let edtsCodes = StatusOwnerRegistry.entries
      .filter { $0.owner == .edts }
      .map(\.code)
    XCTAssertFalse(edtsCodes.isEmpty)
    for code in edtsCodes {
      XCTAssertThrowsError(
        try CaptureSideStatusGuard.parseCaptureSide(code),
        "expected reject of EDTS-owned \(code)"
      )
    }
  }

  func testDirectiveApprovedIsNotImplementationComplete() {
    XCTAssertNotEqual(
      "PHASE_1_DIRECTIVE_APPROVED",
      "PHASE_1_IMPLEMENTATION_COMPLETE"
    )
    XCTAssertEqual(
      StatusOwnerRegistry.owner(of: "PHASE_1_DIRECTIVE_APPROVED"),
      .capture
    )
    XCTAssertEqual(
      StatusOwnerRegistry.owner(of: "PHASE_1_IMPLEMENTATION_COMPLETE"),
      .capture
    )
  }
}
