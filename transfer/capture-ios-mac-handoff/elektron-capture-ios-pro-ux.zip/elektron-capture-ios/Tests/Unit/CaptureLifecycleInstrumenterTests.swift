import XCTest
@testable import ElektronCapture

final class CaptureLifecycleInstrumenterTests: XCTestCase {
  func testRecordsElapsedMillisecondsBetweenGates() throws {
    let log = CaptureLifecycleInstrumenter()
    log.record(.sessionStartRequested)
    log.record(.sessionRunningChanged, detail: "true")
    Thread.sleep(forTimeInterval: 0.02)
    log.record(.previewAttached)
    log.record(.shutterEnabled)
    log.record(.shutterPressed)
    Thread.sleep(forTimeInterval: 0.01)
    log.record(.photoDelegateReceived, detail: "byteCount=1")
    log.record(.imageQualityResult, detail: "mean=12.0")

    let events = log.snapshot().map(\.event)
    XCTAssertEqual(events.first, .sessionStartRequested)
    XCTAssertTrue(events.contains(.sessionRunningChanged))
    XCTAssertTrue(events.contains(.shutterEnabled))
    XCTAssertTrue(events.contains(.shutterPressed))
    XCTAssertTrue(events.contains(.photoDelegateReceived))

    let toEnabled = try XCTUnwrap(log.msSessionRunningToShutterEnabled)
    XCTAssertGreaterThanOrEqual(toEnabled, 15)
    let toDelegate = try XCTUnwrap(log.msShutterPressToPhotoDelegate)
    XCTAssertGreaterThanOrEqual(toDelegate, 5)

    let summary = log.summaryLine()
    XCTAssertTrue(summary.contains("ms_session_running_to_shutter_enabled="))
    XCTAssertTrue(summary.contains("ms_shutter_press_to_photo_delegate="))
  }

  func testDoesNotRequireAdjustingExposureFalseForElapsedGates() {
    let log = CaptureLifecycleInstrumenter()
    log.record(.sessionRunningChanged, detail: "true")
    log.record(.deviceAdjustingExposure, detail: "true")
    log.record(.shutterEnabled, detail: "warm_up_only")
    XCTAssertNotNil(log.msSessionRunningToShutterEnabled)
  }
}
