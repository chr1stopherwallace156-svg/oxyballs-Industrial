import XCTest
@testable import ElektronCapture

final class Phase1StillCaptureUIStateMachineTests: XCTestCase {
  func testHappyPathTransitions() throws {
    var s = Phase1StillCaptureUIState.previewing
    s = try Phase1StillCaptureUIStateMachine.transition(from: s, to: .capturing)
    s = try Phase1StillCaptureUIStateMachine.transition(from: s, to: .reviewing)
    s = try Phase1StillCaptureUIStateMachine.transition(from: s, to: .approved)
    s = try Phase1StillCaptureUIStateMachine.transition(from: s, to: .exported)
    XCTAssertEqual(s, .exported)
  }

  func testRetakeFromReviewing() throws {
    let s = try Phase1StillCaptureUIStateMachine.transition(from: .reviewing, to: .previewing)
    XCTAssertEqual(s, .previewing)
  }

  func testCannotExportBeforeApprove() {
    XCTAssertFalse(Phase1StillCaptureUIStateMachine.canTransition(from: .reviewing, to: .exported))
    XCTAssertThrowsError(
      try Phase1StillCaptureUIStateMachine.transition(from: .previewing, to: .exported)
    )
  }

  func testCannotSkipReview() {
    XCTAssertFalse(Phase1StillCaptureUIStateMachine.canTransition(from: .capturing, to: .approved))
    XCTAssertFalse(Phase1StillCaptureUIStateMachine.canTransition(from: .capturing, to: .exported))
  }

  func testNewCaptureFromExported() throws {
    let s = try Phase1StillCaptureUIStateMachine.transition(from: .exported, to: .previewing)
    XCTAssertEqual(s, .previewing)
  }
}

final class StillCaptureShotMetadataTests: XCTestCase {
  func testMetadataDictionaryUsesNullForAbsentFields() throws {
    let meta = StillCaptureShotMetadata(
      flashModeRequested: "off",
      torchModeDuringFraming: "on",
      physicalCameraType: "AVCaptureDeviceTypeBuiltInWideAngleCamera",
      videoZoomFactor: 1.0
    )
    let dict = meta.asDictionary()
    XCTAssertEqual(dict["schema_version"] as? String, "1.1.0")
    XCTAssertEqual(dict["flash_mode_requested"] as? String, "off")
    XCTAssertEqual(dict["torch_mode_during_framing"] as? String, "on")
    XCTAssertTrue(dict["flash_fired"] is NSNull)
    XCTAssertTrue(dict["iso"] is NSNull)
    let bytes = try CanonicalJSONEncoder.encode(dict, stage: "test_avcapture_metadata")
    XCTAssertFalse(bytes.isEmpty)
  }

  func testSanitizeDropsOpaqueLeaves() {
    let tree: [String: Any] = [
      "ok": "x",
      "blob": Data([1, 2, 3]),
      "nested": ["a": 1, "b": Data([9])],
    ]
    let cleaned = StillCaptureShotMetadata.sanitizeJSONTree(tree) as! [String: Any]
    XCTAssertEqual(cleaned["ok"] as? String, "x")
    XCTAssertTrue(cleaned["blob"] is NSNull)
    let nested = cleaned["nested"] as! [String: Any]
    XCTAssertEqual((nested["a"] as? NSNumber)?.intValue ?? nested["a"] as? Int, 1)
    XCTAssertTrue(nested["b"] is NSNull)
  }

  func testPackageIncludesExpandedMetadata() throws {
    let work = FileManager.default.temporaryDirectory
      .appendingPathComponent("meta-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: work) }

    let jpeg = Data([
      0xFF, 0xD8, 0xFF, 0xD9,
    ])
    // Use a slightly larger fixture-like jpeg from tests if available — empty-ish may fail persist.
    // Minimal valid-enough for persistExactBytes (non-empty).
    let bytes = Data(repeating: 0xAB, count: 64)
    let meta = StillCaptureShotMetadata(
      flashModeRequested: "auto",
      flashFired: false,
      torchModeDuringFraming: "on",
      physicalCameraUniqueID: "cam-1",
      physicalCameraType: "wide",
      lensPosition: 0.5,
      videoZoomFactor: 1.25,
      exposureDurationSeconds: 0.01,
      iso: 100,
      exposureBiasEV: -0.5,
      focusMode: "1",
      exposureMode: "2",
      whiteBalanceMode: "3",
      imageOrientation: "1",
      pixelWidth: 4032,
      pixelHeight: 3024
    )
    let result = try Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: bytes),
      workRoot: work,
      enforceImageQualityGuard: false
    ).exportCapturedJPEG(
      bytes,
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "fixture",
      defaults: UserDefaults(suiteName: UUID().uuidString)!,
      shotMetadata: meta
    )
    let side = try Data(
      contentsOf: result.packageDirectoryURL.appendingPathComponent("sidecars/avcapture_metadata.json")
    )
    let obj = try JSONSerialization.jsonObject(with: side) as! [String: Any]
    XCTAssertEqual(obj["torch_mode_during_framing"] as? String, "on")
    XCTAssertEqual(obj["flash_mode_requested"] as? String, "auto")
    XCTAssertEqual(obj["pixel_width"] as? Int ?? (obj["pixel_width"] as? NSNumber)?.intValue, 4032)
    XCTAssertEqual(result.artifactSha256, ArtifactHashingService().sha256HexOfData(bytes))
    _ = jpeg
  }
}
