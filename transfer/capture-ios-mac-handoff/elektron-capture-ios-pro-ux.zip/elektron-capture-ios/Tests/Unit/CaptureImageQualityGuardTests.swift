import XCTest
@testable import ElektronCapture

final class CaptureImageQualityGuardTests: XCTestCase {
  func testRejectsNearBlackSamplesMeetingBothCriteria() {
    let samples = [UInt8](repeating: 2, count: 1000)
    let verdict = CaptureImageQualityGuard.evaluate(luminanceSamples: samples)
    XCTAssertTrue(verdict.isEffectivelyBlack)
    XCTAssertLessThanOrEqual(verdict.metrics.meanLuminance, 8.0)
    XCTAssertGreaterThanOrEqual(verdict.metrics.nearBlackFraction, 0.98)
  }

  func testAcceptsBrightSamples() {
    let samples = [UInt8](repeating: 180, count: 1000)
    let verdict = CaptureImageQualityGuard.evaluate(luminanceSamples: samples)
    XCTAssertFalse(verdict.isEffectivelyBlack)
  }

  func testDoesNotRejectOnMeanAloneWithoutNearBlackFraction() {
    // Mean near zero but only half the pixels near-black → do not reject.
    var samples = [UInt8](repeating: 0, count: 500)
    samples += [UInt8](repeating: 40, count: 500)
    let thresholds = CaptureImageQualityThresholds(
      maxMeanLuminance: 25,
      minNearBlackFraction: 0.98,
      nearBlackMax: 8
    )
    let verdict = CaptureImageQualityGuard.evaluate(luminanceSamples: samples, thresholds: thresholds)
    XCTAssertFalse(
      verdict.isEffectivelyBlack,
      "guard requires BOTH mean and near-black fraction"
    )
  }

  func testDoesNotRejectOnNearBlackFractionAloneWithoutLowMean() {
    // All near-black relative to a high threshold, but mean stays above maxMean.
    let samples = [UInt8](repeating: 20, count: 1000)
    let thresholds = CaptureImageQualityThresholds(
      maxMeanLuminance: 8,
      minNearBlackFraction: 0.98,
      nearBlackMax: 30
    )
    let verdict = CaptureImageQualityGuard.evaluate(luminanceSamples: samples, thresholds: thresholds)
    XCTAssertFalse(verdict.isEffectivelyBlack)
  }

  func testDocumentedPhase1ThresholdDefaults() {
    let t = CaptureImageQualityThresholds.phase1Default
    XCTAssertEqual(t.maxMeanLuminance, 8.0)
    XCTAssertEqual(t.minNearBlackFraction, 0.98)
    XCTAssertEqual(t.nearBlackMax, 8)
  }

  func testReasonCodeStable() {
    XCTAssertEqual(
      Phase1RuntimeError.captureQualityImageEffectivelyBlack("x").reasonCode,
      "CAPTURE_QUALITY_IMAGE_EFFECTIVELY_BLACK"
    )
  }
}
