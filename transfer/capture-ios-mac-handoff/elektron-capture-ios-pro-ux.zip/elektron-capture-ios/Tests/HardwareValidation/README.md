# Hardware validation

Reserved for approved iPhone profiles (LiDAR / ARKit / camera). Not executed in foundation 0.1.0.
