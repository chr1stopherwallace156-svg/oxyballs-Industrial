# Integration tests

Reserved for Path A package import dry-runs against a future EDTS development importer.

Do not mark `EDTS_COMPATIBLE` from tests in this folder while `INTEGRATION_STATUS.md` remains `MOCK_ONLY`.
