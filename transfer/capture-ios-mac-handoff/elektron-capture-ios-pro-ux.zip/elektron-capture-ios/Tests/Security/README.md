# Security tests

Reserved for App Attest binding, keychain isolation, and anti-tamper checks beyond foundation scripts.
