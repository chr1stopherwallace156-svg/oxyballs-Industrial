# SCHEMA_MIGRATION

Canonical: [`Docs/Integration/SCHEMA_MIGRATION.md`](Docs/Integration/SCHEMA_MIGRATION.md)
