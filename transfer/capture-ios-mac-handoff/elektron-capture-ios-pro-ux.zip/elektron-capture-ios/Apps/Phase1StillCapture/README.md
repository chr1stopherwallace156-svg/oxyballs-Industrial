# Phase1StillCapture (thin Xcode host)

```bash
open Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace
```

Scheme: `Phase1StillCapture`

## Operator workflow

```text
PREVIEWING → CAPTURING → REVIEWING → APPROVED → EXPORTED
                ↑___________| Retake
```

1. **Live viewfinder** (full-bleed) with readiness: Starting Camera / Adjusting / Ready / Error  
2. Adjust **Flash** (strobe) vs **Torch** (continuous), lens, EV, zoom, AE/AF lock, tap-to-focus, grid  
3. **Take Photo** (manual shutter only — never auto on load)  
4. **Retake** or **Use Photo** (quality guard may block effectively-black)  
5. **Export Package** → `.edts-pkg` (exact `fileDataRepresentation()` bytes)

State machine: `Docs/Capture/PHASE_1_STILL_CAPTURE_UI_STATE.md`

Physical export demonstrated ≠ Phase 1 complete while Darwin CrossLanguage / inventory gates remain.

## Integrity

- Preview / UIImage / quality decode are non-authoritative.
- Post-delegate SHA-256 must equal `payload/artifact_original.jpg` after export.
