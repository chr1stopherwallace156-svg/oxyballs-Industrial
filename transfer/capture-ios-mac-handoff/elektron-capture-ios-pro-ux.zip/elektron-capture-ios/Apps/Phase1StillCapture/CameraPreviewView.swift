import AVFoundation
import SwiftUI
import UIKit

/// Full-bleed `AVCaptureVideoPreviewLayer`. Preview pixels are non-authoritative.
struct CameraPreviewView: UIViewRepresentable {
  let session: AVCaptureSession
  var showGrid: Bool
  var focusIndicator: CGPoint?
  var onAttached: (() -> Void)?
  var onTap: ((_ devicePoint: CGPoint, _ viewNormalized: CGPoint) -> Void)?

  func makeUIView(context: Context) -> PreviewUIView {
    let view = PreviewUIView()
    view.previewLayer.session = session
    view.previewLayer.videoGravity = .resizeAspectFill
    view.showGrid = showGrid
    let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleTap(_:)))
    view.addGestureRecognizer(tap)
    context.coordinator.view = view
    return view
  }

  func updateUIView(_ uiView: PreviewUIView, context: Context) {
    if uiView.previewLayer.session !== session {
      uiView.previewLayer.session = session
    }
    uiView.showGrid = showGrid
    uiView.focusIndicatorNormalized = focusIndicator
    context.coordinator.onTap = onTap
    uiView.setNeedsDisplay()
    DispatchQueue.main.async {
      onAttached?()
    }
  }

  func makeCoordinator() -> Coordinator {
    Coordinator(onTap: onTap)
  }

  final class Coordinator: NSObject {
    var onTap: ((_ devicePoint: CGPoint, _ viewNormalized: CGPoint) -> Void)?
    weak var view: PreviewUIView?

    init(onTap: ((_ devicePoint: CGPoint, _ viewNormalized: CGPoint) -> Void)?) {
      self.onTap = onTap
    }

    @objc func handleTap(_ gesture: UITapGestureRecognizer) {
      guard let view else { return }
      let p = gesture.location(in: view)
      guard view.bounds.width > 0, view.bounds.height > 0 else { return }
      let viewNormalized = CGPoint(x: p.x / view.bounds.width, y: p.y / view.bounds.height)
      let devicePoint = view.previewLayer.captureDevicePointConverted(fromLayerPoint: p)
      onTap?(devicePoint, viewNormalized)
    }
  }

  final class PreviewUIView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
    var showGrid = false
    var focusIndicatorNormalized: CGPoint?

    override func layoutSubviews() {
      super.layoutSubviews()
      setNeedsDisplay()
    }

    override func draw(_ rect: CGRect) {
      guard let ctx = UIGraphicsGetCurrentContext() else { return }
      if showGrid {
        ctx.setStrokeColor(UIColor.white.withAlphaComponent(0.35).cgColor)
        ctx.setLineWidth(1)
        let w = bounds.width
        let h = bounds.height
        for i in 1...2 {
          let x = w * CGFloat(i) / 3
          ctx.move(to: CGPoint(x: x, y: 0))
          ctx.addLine(to: CGPoint(x: x, y: h))
          let y = h * CGFloat(i) / 3
          ctx.move(to: CGPoint(x: 0, y: y))
          ctx.addLine(to: CGPoint(x: w, y: y))
        }
        ctx.strokePath()
      }
      if let focus = focusIndicatorNormalized {
        let c = CGPoint(x: focus.x * bounds.width, y: focus.y * bounds.height)
        let size: CGFloat = 56
        let r = CGRect(x: c.x - size / 2, y: c.y - size / 2, width: size, height: size)
        ctx.setStrokeColor(UIColor.systemYellow.cgColor)
        ctx.setLineWidth(2)
        ctx.stroke(r)
      }
    }
  }
}
