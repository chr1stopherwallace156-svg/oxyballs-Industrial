import ElektronCapture
import SwiftUI

#if canImport(AVFoundation) && canImport(UIKit)
import AVFoundation
import UIKit
#endif

/// Professional Phase 1 still capture: PREVIEWING → CAPTURING → REVIEWING → APPROVED → EXPORTED.
/// Preview/UI decode never replaces `fileDataRepresentation()` bytes.
public struct Phase1CaptureRootView: View {
  #if canImport(AVFoundation) && canImport(UIKit)
  @StateObject private var capture = InteractiveStillCaptureController()
  #endif

  @State private var uiState: Phase1StillCaptureUIState = .previewing
  @State private var statusText = "Starting Camera"
  @State private var packagePath = ""
  @State private var packageURL: URL?
  @State private var artifactHash = ""
  @State private var packageId = ""
  @State private var evidenceId = ""
  @State private var busy = false
  @State private var lastErrorDetail = ""
  @State private var capturedJPEG: Data?
  @State private var postDelegateHash = ""
  @State private var shotMetadata: StillCaptureShotMetadata?
  @State private var reviewImage: UIImage?
  @State private var lifecycleSummary = ""
  @State private var qualityWarning = ""

  private let appVersion = "0.1.4"

  public init() {}

  public var body: some View {
    NavigationStack {
      ZStack {
        Color.black.ignoresSafeArea()

        #if canImport(AVFoundation) && canImport(UIKit)
        switch uiState {
        case .previewing, .capturing, .error:
          liveCameraLayer
        case .reviewing, .approved:
          reviewLayer
        case .exported:
          exportedLayer
        }
        #else
        Text("AVFoundation unavailable")
          .foregroundStyle(.white)
        #endif
      }
      .safeAreaInset(edge: .bottom) {
        controlDock
      }
      .navigationTitle("Elektron Capture")
      .navigationBarTitleDisplayMode(.inline)
      .toolbar {
        ToolbarItem(placement: .principal) {
          VStack(spacing: 0) {
            Text("Phase 1 Still").font(.headline)
            Text(uiState.rawValue).font(.caption2).foregroundStyle(.secondary)
          }
        }
      }
      .task {
        #if canImport(AVFoundation) && canImport(UIKit)
        await startCamera()
        #endif
      }
      .onDisappear {
        #if canImport(AVFoundation) && canImport(UIKit)
        capture.stopSession()
        #endif
      }
    }
  }

  #if canImport(AVFoundation) && canImport(UIKit)
  private var liveCameraLayer: some View {
    ZStack {
      CameraPreviewView(
        session: capture.session,
        showGrid: capture.showGrid,
        focusIndicator: capture.focusIndicatorNormalized,
        onAttached: {
          if !capture.previewAttached {
            capture.markPreviewAttached(true)
          }
        },
        onTap: { devicePoint, viewNormalized in
          capture.setFocusExposure(atDevicePoint: devicePoint, viewNormalized: viewNormalized)
        }
      )
      .ignoresSafeArea()

      VStack {
        HStack {
          readinessBadge
          Spacer()
          Text("NON_AUTHORITATIVE")
            .font(.caption2.monospaced())
            .foregroundStyle(.white.opacity(0.7))
        }
        .padding(.horizontal)
        .padding(.top, 8)

        Spacer()
      }
    }
  }

  private var readinessBadge: some View {
    Text(capture.readinessText)
      .font(.caption.weight(.semibold))
      .padding(.horizontal, 10)
      .padding(.vertical, 6)
      .background(.ultraThinMaterial, in: Capsule())
      .foregroundStyle(capture.shutterEnabled ? Color.primary : Color.secondary)
  }

  private var reviewLayer: some View {
    VStack(spacing: 12) {
      if let reviewImage {
        Image(uiImage: reviewImage)
          .resizable()
          .scaledToFit()
          .frame(maxWidth: .infinity, maxHeight: .infinity)
      } else {
        Text("Captured (preview decode unavailable)")
          .foregroundStyle(.white)
          .frame(maxWidth: .infinity, maxHeight: .infinity)
      }
      Text("Decoded preview is non-authoritative. Export uses original JPEG bytes.")
        .font(.caption)
        .foregroundStyle(.white.opacity(0.7))
        .multilineTextAlignment(.center)
        .padding(.horizontal)
      if !qualityWarning.isEmpty {
        Text(qualityWarning)
          .font(.caption.monospaced())
          .foregroundStyle(.orange)
          .padding(.horizontal)
      }
      labeledRow("Post-delegate SHA-256", postDelegateHash)
    }
    .padding(.bottom, 8)
  }

  private var exportedLayer: some View {
    VStack(alignment: .leading, spacing: 12) {
      Text("PACKAGE_EXPORTED")
        .font(.title2.weight(.bold))
        .foregroundStyle(.white)
      labeledRow("Package ID", packageId)
      labeledRow("Evidence ID", evidenceId)
      labeledRow("Artifact SHA-256", artifactHash)
      labeledRow("Package path", packagePath)
      if let packageURL {
        ShareLink(item: packageURL) {
          Label("Share .edts-pkg", systemImage: "square.and.arrow.up")
        }
        .buttonStyle(.borderedProminent)
      }
      Text("Capture-side OK ≠ EDTS XREPO PASS")
        .font(.caption)
        .foregroundStyle(.white.opacity(0.6))
    }
    .padding()
  }

  private var controlDock: some View {
    VStack(alignment: .leading, spacing: 10) {
      if !lastErrorDetail.isEmpty {
        Text(lastErrorDetail)
          .font(.caption2.monospaced())
          .foregroundStyle(.red)
          .lineLimit(4)
      }
      if !lifecycleSummary.isEmpty {
        Text(lifecycleSummary)
          .font(.caption2.monospaced())
          .foregroundStyle(.secondary)
          .lineLimit(2)
      }

      switch uiState {
      case .previewing, .capturing, .error:
        previewControls
      case .reviewing:
        reviewControls
      case .approved:
        approvedControls
      case .exported:
        Button("New Capture") { Task { await newCapture() } }
          .buttonStyle(.borderedProminent)
      }
    }
    .padding()
    .background(.ultraThinMaterial)
  }

  private var previewControls: some View {
    VStack(spacing: 10) {
      // Flash vs Torch (independent)
      HStack {
        Picker("Flash", selection: $capture.flashMode) {
          ForEach(CaptureFlashModeOption.allCases, id: \.self) { mode in
            Text("Flash \(mode.rawValue)").tag(mode)
          }
        }
        .pickerStyle(.menu)
        .disabled(!capture.flashSupported)

        Picker("Torch", selection: $capture.torchMode) {
          ForEach(CaptureTorchModeOption.allCases, id: \.self) { mode in
            Text("Torch \(mode.rawValue)").tag(mode)
          }
        }
        .pickerStyle(.menu)
        .disabled(!capture.torchSupported)

        Toggle("Grid", isOn: $capture.showGrid)
          .labelsHidden()
        Text("Grid").font(.caption)
      }

      // Lens discovery — only physical devices present
      if capture.availableLenses.count > 1 {
        ScrollView(.horizontal, showsIndicators: false) {
          HStack {
            ForEach(capture.availableLenses) { lens in
              Button(lens.shortLabel) {
                capture.selectLens(uniqueID: lens.uniqueID)
              }
              .buttonStyle(.bordered)
              .tint(capture.selectedLensID == lens.uniqueID ? .yellow : .primary)
            }
          }
        }
      }

      HStack {
        Text("EV").font(.caption)
        Slider(
          value: Binding(
            get: { Double(capture.exposureBias) },
            set: { capture.exposureBias = Float($0) }
          ),
          in: Double(capture.minExposureBias)...Double(capture.maxExposureBias)
        )
        Button(capture.aeAfLocked ? "AE/AF Locked" : "Lock AE/AF") {
          capture.toggleAeAfLock()
        }
        .font(.caption)
      }

      if capture.maxZoom > capture.minZoom + 0.01 {
        HStack {
          Text("Zoom").font(.caption)
          Slider(
            value: $capture.zoomFactor,
            in: capture.minZoom...min(capture.maxZoom, capture.minZoom + 8)
          )
        }
      }

      Button {
        Task { await takePhoto() }
      } label: {
        Text(busy || uiState == .capturing ? "Capturing…" : "Take Photo")
          .frame(maxWidth: .infinity)
      }
      .buttonStyle(.borderedProminent)
      .disabled(busy || !capture.shutterEnabled || uiState == .capturing)
    }
  }

  private var reviewControls: some View {
    HStack(spacing: 12) {
      Button("Retake") { Task { await retake() } }
        .buttonStyle(.bordered)
        .disabled(busy)
      Button("Use Photo") { Task { await usePhoto() } }
        .buttonStyle(.borderedProminent)
        .disabled(busy || capturedJPEG == nil)
    }
  }

  private var approvedControls: some View {
    HStack(spacing: 12) {
      Button("Retake") { Task { await retake() } }
        .buttonStyle(.bordered)
        .disabled(busy)
      Button(busy ? "Exporting…" : "Export Package") {
        Task { await exportPackage() }
      }
      .buttonStyle(.borderedProminent)
      .disabled(busy || capturedJPEG == nil)
    }
  }

  @MainActor
  private func startCamera() async {
    do {
      try await capture.prepareSession()
      uiState = .previewing
      statusText = capture.readinessText
    } catch let e as Phase1RuntimeError {
      uiState = .error
      statusText = "FAIL \(e.reasonCode)"
      lastErrorDetail = e.detailMessage
    } catch {
      uiState = .error
      statusText = "FAIL UNKNOWN"
      lastErrorDetail = String(describing: error)
    }
  }

  @MainActor
  private func takePhoto() async {
    busy = true
    defer { busy = false }
    lastErrorDetail = ""
    qualityWarning = ""
    do {
      uiState = try Phase1StillCaptureUIStateMachine.transition(from: .previewing, to: .capturing)
      let shot = try await capture.captureStill()
      capturedJPEG = shot.jpegBytes
      postDelegateHash = shot.postDelegateSha256
      shotMetadata = shot.metadata
      reviewImage = UIImage(data: shot.jpegBytes) // throwaway decode
      artifactHash = shot.postDelegateSha256
      lifecycleSummary = capture.lifecycle.summaryLine()
      uiState = try Phase1StillCaptureUIStateMachine.transition(from: .capturing, to: .reviewing)
      statusText = "REVIEWING — Retake or Use Photo"
    } catch let e as Phase1RuntimeError {
      uiState = (try? Phase1StillCaptureUIStateMachine.transition(from: .capturing, to: .previewing)) ?? .previewing
      statusText = "FAIL \(e.reasonCode)"
      lastErrorDetail = e.detailMessage
      lifecycleSummary = capture.lifecycle.summaryLine()
    } catch {
      uiState = .previewing
      statusText = "FAIL UNKNOWN"
      lastErrorDetail = String(describing: error)
    }
  }

  @MainActor
  private func retake() async {
    capturedJPEG = nil
    reviewImage = nil
    shotMetadata = nil
    packageURL = nil
    packagePath = ""
    packageId = ""
    evidenceId = ""
    artifactHash = ""
    postDelegateHash = ""
    qualityWarning = ""
    lastErrorDetail = ""
    uiState = (try? Phase1StillCaptureUIStateMachine.transition(from: uiState, to: .previewing)) ?? .previewing
    statusText = "PREVIEWING"
    if !capture.sessionRunning {
      await startCamera()
    }
  }

  @MainActor
  private func usePhoto() async {
    guard let jpeg = capturedJPEG else { return }
    busy = true
    defer { busy = false }
    qualityWarning = ""
    lastErrorDetail = ""
    // Quality guard before approval — reject effectively-black; allow Retake.
    #if canImport(ImageIO)
    do {
      let verdict = try CaptureImageQualityGuard.evaluateJPEGInspection(jpeg)
      let m = verdict.metrics
      capture.lifecycle.record(
        .imageQualityResult,
        detail: "mean=\(m.meanLuminance) nearBlack=\(m.nearBlackFraction) black=\(verdict.isEffectivelyBlack)"
      )
      if verdict.isEffectivelyBlack {
        qualityWarning =
          "CAPTURE_QUALITY_IMAGE_EFFECTIVELY_BLACK — Retake recommended (mean=\(String(format: "%.2f", m.meanLuminance)), nearBlack=\(String(format: "%.3f", m.nearBlackFraction)))"
        statusText = "FAIL CAPTURE_QUALITY_IMAGE_EFFECTIVELY_BLACK"
        lastErrorDetail = qualityWarning
        // Stay in REVIEWING — do not approve.
        return
      }
    } catch {
      // If inspection decode fails, do not block approval; log only.
      Phase1CaptureDiagnostics.log(stage: "image_quality", event: "inspection_failed", detail: String(describing: error))
    }
    #endif
    do {
      uiState = try Phase1StillCaptureUIStateMachine.transition(from: .reviewing, to: .approved)
      statusText = "APPROVED — tap Export Package"
    } catch {
      lastErrorDetail = String(describing: error)
    }
  }

  @MainActor
  private func exportPackage() async {
    guard let jpeg = capturedJPEG else { return }
    busy = true
    defer { busy = false }
    lastErrorDetail = ""
    statusText = "Exporting…"
    do {
      let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
      let work = docs.appendingPathComponent("Phase1Exports", isDirectory: true)
      try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)

      let coordinator = Phase1CaptureCoordinator(
        appVersion: appVersion,
        photoCapture: FixtureStillPhotoCaptureService(jpegBytes: jpeg),
        workRoot: work,
        enforceImageQualityGuard: false, // already gated at Use Photo
        lifecycle: capture.lifecycle
      )
      let result = try coordinator.exportCapturedJPEG(
        jpeg,
        shotMetadata: shotMetadata
      )
      if result.artifactSha256 != postDelegateHash {
        throw Phase1RuntimeError.hashReadbackMismatch(
          expected: postDelegateHash,
          actual: result.artifactSha256
        )
      }
      let captureSide = CaptureSidePackageValidator.validate(packageDirectory: result.packageDirectoryURL)
      packageId = result.packageId
      evidenceId = result.evidenceId
      artifactHash = result.artifactSha256
      packageURL = result.packageZipURL
      packagePath = result.packageZipURL.path
      lifecycleSummary = capture.lifecycle.summaryLine()
      uiState = try Phase1StillCaptureUIStateMachine.transition(from: .approved, to: .exported)
      if captureSide.ok {
        statusText = "CAPTURE_SIDE_OK → PACKAGE_EXPORTED"
      } else {
        statusText = "CAPTURE_SIDE_FAIL \(captureSide.reasonCodes.joined(separator: ","))"
        lastErrorDetail = captureSide.notes.joined(separator: " | ")
      }
    } catch let e as Phase1RuntimeError {
      statusText = "FAIL \(e.reasonCode)"
      lastErrorDetail = e.detailMessage
      packageURL = nil
    } catch {
      statusText = "FAIL UNKNOWN"
      lastErrorDetail = String(describing: error)
      packageURL = nil
    }
  }

  @MainActor
  private func newCapture() async {
    await retake()
  }
  #endif

  private func labeledRow(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(.caption2).foregroundStyle(.secondary)
      Text(value.isEmpty ? "—" : value)
        .font(.footnote.monospaced())
        .foregroundStyle(.white)
        .textSelection(.enabled)
    }
  }
}
