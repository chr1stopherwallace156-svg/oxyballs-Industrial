import SwiftUI
import ElektronCapture

@main
struct Phase1StillCaptureApp: App {
  var body: some Scene {
    WindowGroup {
      Phase1CaptureRootView()
    }
  }
}
