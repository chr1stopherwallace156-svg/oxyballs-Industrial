#!/usr/bin/env bash
# Prove Xcode handoff layout from a clean tree (no Xcode required).
# Usage: ./Scripts/verify-xcode-handoff.sh [repo-root]
set -euo pipefail

ROOT="$(cd "${1:-$(dirname "$0")/..}" && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

echo "=== verify-xcode-handoff @ $ROOT ==="

[[ -f Package.swift ]] || fail "Package.swift missing at repo root"
pass "Package.swift exists at repo root"

if command -v swift >/dev/null 2>&1; then
  PROD=$(swift package dump-package | python3 -c "import sys,json; print(',' .join(p['name'] for p in json.load(sys.stdin)['products']))")
  echo "$PROD" | grep -q 'ElektronCapture' || fail "Package does not export product ElektronCapture (got: $PROD)"
  pass "Package exports product ElektronCapture"
else
  grep -q 'library(name: "ElektronCapture"' Package.swift || fail "Package.swift missing ElektronCapture product declaration"
  pass "Package.swift declares product ElektronCapture (swift not installed; dump-package skipped)"
fi

PBX="$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj"
[[ -f "$PBX" ]] || fail "Phase1StillCapture.xcodeproj missing"
pass "Phase1StillCapture.xcodeproj exists"

grep -q 'productName = ElektronCapture' "$PBX" || fail "pbxproj missing productName = ElektronCapture"
pass "pbxproj productName = ElektronCapture"

grep -q 'isa = XCLocalSwiftPackageReference' "$PBX" || fail "pbxproj missing XCLocalSwiftPackageReference"
pass "pbxproj has XCLocalSwiftPackageReference"

# relativePath must resolve to repo root from the directory containing the .xcodeproj
PROJ_DIR="$ROOT/Apps/Phase1StillCapture"
REL=$(grep -E 'relativePath = ' "$PBX" | head -1 | sed 's/.*relativePath = //;s/;//;s/ //g')
[[ -n "$REL" ]] || fail "relativePath not found in pbxproj"
RESOLVED="$(cd "$PROJ_DIR" && realpath "$REL")"
[[ "$RESOLVED" == "$ROOT" ]] || fail "relativePath '$REL' from Apps/Phase1StillCapture resolves to '$RESOLVED', expected '$ROOT'"
[[ -f "$RESOLVED/Package.swift" ]] || fail "resolved package root has no Package.swift"
pass "relativePath '$REL' resolves to repo root with Package.swift"

# Sources import the module
grep -q 'import ElektronCapture' "$ROOT/Apps/Phase1StillCapture/Phase1StillCaptureApp.swift" \
  || fail "App does not import ElektronCapture"
pass "App sources import ElektronCapture"

# Workspace helpers (optional but recommended)
if [[ -f "$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace/contents.xcworkspacedata" ]]; then
  pass "App-level xcworkspace present"
fi
if [[ -f "$ROOT/Phase1StillCapture.xcworkspace/contents.xcworkspacedata" ]]; then
  pass "Root xcworkspace present"
fi

echo
echo "HANDOFF_LAYOUT_OK"
echo "Open either:"
echo "  open Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj"
echo "  open Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace"
echo "  open Phase1StillCapture.xcworkspace"
echo "If Xcode still shows Missing package product: File → Packages → Reset Package Caches, then resolve."
