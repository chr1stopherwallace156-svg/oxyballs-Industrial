# DECISION_LOG.md

Architectural decisions for **elektron-capture-ios** only.  
Identifiers: `CAP-IOS-ADR-####`. Cross-system: `XREPO-CAP-EDTS-####`.

---

## CAP-IOS-ADR-0001 — Independent repository boundary

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Capture must evolve without contaminating edts-core / build-engine history |
| Decision | Standalone Git repository with own SemVer, changelog, CI, security model |
| Alternatives | Monorepo package; submodule inside edts-core; nest under build-engine |
| Consequences | Integration only via versioned contracts / packages / API |
| Affected contracts | All under `Contracts/` |
| Migration impact | None (greenfield) |
| Integration impact | EDTS consumes packages/API; no shared source tree |

---

## CAP-IOS-ADR-0002 — Path A portable package before live API

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Need independent perfection before backend coupling |
| Decision | First integration milestone = export + verify portable evidence package; API is Path B |
| Alternatives | API-first; direct database write (rejected) |
| Consequences | MockEDTSClient + FileEvidenceExporter required early |
| Affected contracts | EvidenceManifest, ArtifactMetadata |
| Migration impact | Package remains diagnostic after API exists |
| Integration impact | EDTS importer must accept package schema |

---

## CAP-IOS-ADR-0003 — No Git submodules in phase 1

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Submodules add sync/CI risk during prototype |
| Decision | Versioned schema copies with hash tracking; optional `elektron-contracts` later |
| Alternatives | Submodule now; package-only distribution |
| Consequences | Explicit schema ownership until multi-repo consumption |
| Affected contracts | Contracts/* |
| Migration impact | May later extract to elektron-contracts |
| Integration impact | Hash-pin shared schemas in INTEGRATION_STATUS |

---

## CAP-IOS-ADR-0004 — Defer AVFoundation / ARKit / LiDAR until Phase 0 review

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Foundational Implementation Contract §51 |
| Decision | Phase 0 = contracts/domain/mocks/golden only; no production camera pipelines |
| Alternatives | Start hardware capture immediately |
| Consequences | Integration readiness = PACKAGE_EXPORT_READY until Phase 1 |
| Affected contracts | None yet for live media codecs |
| Migration impact | Capture modules land in Phase 1+ |
| Integration impact | Golden package uses synthetic artifacts |

---

## CAP-IOS-ADR-0005 — Apple-native primary platform (not Android translation)

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | iPhone is the controlled technician capture platform |
| Decision | Production architecture uses AVFoundation, ARKit, Core Motion, CryptoKit/Security/App Attest; Android is reference-only |
| Alternatives | Android-first; dual-platform simultaneous |
| Consequences | Roadmap and adapters are Apple-shaped; no Camera2/ARCore line-by-line port |
| Affected contracts | Calibration (Apple-native), spatial manifests |
| Migration impact | None |
| Integration impact | EDTS contracts remain device-agnostic at package boundary |

---

## CAP-IOS-ADR-0006 — ARKit/LiDAR default GUIDANCE_ESTIMATE

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Metrology inflation risk |
| Decision | ARKit pose/depth and LiDAR-derived distances are GUIDANCE_ESTIMATE until validated |
| Alternatives | Treat LiDAR as metrology-grade by default (rejected) |
| Consequences | UI and manifests must not claim certified dimensions from ARKit alone |
| Affected contracts | EvidenceManifest spatial_context, SpatialPose |
| Migration impact | Authority promotion requires documented validation |
| Integration impact | EDTS must not auto-promote guidance estimates |

---

## CAP-IOS-ADR-0007 — Single approved iPhone Pro LiDAR profile for v1

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Calibration/quality consistency |
| Decision | v1 engineering capture targets one controlled LiDAR iPhone Pro profile registry entry |
| Alternatives | Support all employee phones |
| Consequences | Unsupported devices refuse engineering capture or enter labeled demo mode |
| Affected contracts | Device approval standard |
| Migration impact | Later approved-device registry expansion |
| Integration impact | Capture identity includes approved_device_profile |

---

## CAP-IOS-ADR-0008 — Apple-native calibration storage; OpenCV as derivative

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | AVCameraCalibrationData differs from simple k1–p2 models |
| Decision | Store Apple-native calibration; generate OpenCV-compatible coefficients only as derived artifacts |
| Alternatives | Force all calibration into OpenCV coefficients immediately |
| Consequences | CalibrationProfile schema includes lookup tables / intrinsics matrices |
| Affected contracts | CalibrationProfile |
| Migration impact | Derivative conversion algorithm must be versioned |
| Integration impact | Importers must accept Apple-native fields |

---

## CAP-IOS-ADR-0009 — Foundation verification: enforce AuthorityGuard + mock fail-closed

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Verification pass found AuthorityGuard unused on export path; mocks unlabeled at composition root |
| Decision | Route export/seal validation through `EvidenceManifestValidator` (calls AuthorityGuard); introduce `RuntimeEnvironment` with PRODUCTION fail-closed on mocks; strict schemas + negative tests; raise XREPO-CAP-EDTS-0001 |
| Alternatives | Leave guard as documentation-only helper |
| Consequences | Capture cannot emit ENGINEERING_VERIFIED or Build Engine tokens via validated path |
| Affected contracts | EvidenceManifest, MeasurementObservation, ownership metadata |
| Migration impact | Schemas tightened (`additionalProperties: false`); examples updated |
| Integration impact | EDTS_COMPATIBLE still blocked pending importer handshake |

---

## CAP-IOS-ADR-0010 — Explicit contract ownership metadata

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Risk of Cursor editing shared schemas from whichever repo is open |
| Decision | Every schema carries `contract_ownership`; EDTS-owned and joint changes require XREPO |
| Alternatives | Informal ownership in prose only |
| Consequences | `validate-contracts` fails without ownership field |
| Affected contracts | All |
| Migration impact | None for payload bytes beyond stricter validation |
| Integration impact | Clear change-control boundary |

---

## CAP-IOS-ADR-0011 — Schema compatibility registry before multi-version growth

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Need explicit read/write/migrate/reject policy before 1.1 / 2.0 |
| Decision | Maintain SCHEMA_COMPATIBILITY + SCHEMA_MIGRATION + registry JSON + gate script; unknown versions reject |
| Alternatives | Ad-hoc version checks in importers only |
| Consequences | Second schema version cannot ship without registry + tests |
| Affected contracts | All |
| Migration impact | Migrators list empty until first bump |
| Integration impact | Joint bumps still need XREPO |

---

## CAP-IOS-ADR-0012 — Canonical JSON independent of Dictionary order

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Swift Dictionary order is not a serialization contract |
| Decision | Document and implement Canonical JSON (UTF-8, sorted keys, compact, normalized scalars); sign canonical bytes not pretty files |
| Alternatives | Pretty-print signing; rely on insertion order |
| Consequences | Cross-language hash binding becomes feasible |
| Affected contracts | Signed manifests / package_meta |
| Migration impact | None for artifact file hashes |
| Integration impact | EDTS must use equivalent canonicalization when verifying structured bindings |

---

## CAP-IOS-ADR-0013 — Capture device provenance required for Phase 1+ packages

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Long-term forensic questions across iPhone generations |
| Decision | Emit `capture_device.json` (CaptureDeviceProvenance) with profile, model, iOS, camera/lens, calibration version, app + schema versions, installation/enrollment IDs — no permanent hardware UDID |
| Alternatives | Rely only on ad-hoc notes / EXIF |
| Consequences | Golden fixture includes placeholder `DECISION_REQUIRED` model fields |
| Affected contracts | CaptureDeviceProvenance |
| Migration impact | Additive file in Path A layout |
| Integration impact | Importer should preserve provenance block |

---

## CAP-IOS-ADR-0014 — Phase acceptance criteria are objective checklists

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Prevent feature creep and vague “done” |
| Decision | ACCEPTANCE_CRITERIA.md defines pass/fail per phase; UI alone never completes a phase |
| Alternatives | Informal roadmap-only completion |
| Consequences | Phase 1 requires still capture + hash + package + provenance (+ EDTS import or documented deferral) |
| Affected contracts | None directly |
| Migration impact | None |
| Integration impact | EDTS_COMPATIBLE remains a Phase 6 / XREPO outcome |

---

## CAP-IOS-ADR-0015 — Compatibility uses four operation axes (not vague SUPPORTED)

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Reading old versions ≠ writing old versions; unknown futures must fail closed |
| Decision | Every version row declares READ_SUPPORT, WRITE_SUPPORT, MIGRATION_SUPPORT, REJECTION_POLICY |
| Alternatives | Single SUPPORTED enum |
| Consequences | Registry + docs updated; tests assert axes |
| Affected contracts | Compatibility registry |
| Migration impact | None for 1.0.0 payloads |
| Integration impact | Importers must honor reject policies |

---

## CAP-IOS-ADR-0016 — Phase 0 approved for Phase 1 preparation only

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Foundation mature; next proof is EDTS importer, not more local docs |
| Decision | Classify Phase 0 as APPROVED_FOR_PHASE_1_PREPARATION; keep PACKAGE_EXPORT_READY; tag baseline; no production/EDTS/metrology/security deployment claims |
| Alternatives | Claim EDTS_COMPATIBLE locally; continue Phase 0 polishing indefinitely |
| Consequences | Next work is GitHub publish + XREPO-0001 + still capture |
| Affected contracts | None |
| Migration impact | None |
| Integration impact | EDTS_COMPATIBLE still gated on importer + canonical cross-proof |

---

## CAP-IOS-ADR-0017 — Phase 1 is First Verified Capture Artifact (not RAW, not metrology)

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Phase 1 proposal risked calling JPEG “RAW” and assuming intrinsics |
| Decision | Lock Phase 1 as integrity pipeline for exact AVFoundation-encoded stills; optional calibration; motion with reference frames; `.edts-pkg` inventory; EDTS commit INGESTED_INTEGRITY_VERIFIED + CONTENT_UNVERIFIED; no Photos write; no Build Engine |
| Alternatives | UI-first camera demo; assume RAW+intrinsics always; ZIP-as-identity |
| Consequences | 16-point acceptance gate; XREPO-0002 for archive hardening |
| Affected contracts | PackageInventory, IngestionStatus, CameraCalibrationRecord, MotionOrientationSample |
| Migration impact | None for 0.1.3 golden Path A package |
| Integration impact | EDTS must quarantine and re-hash; HTTP 201/202 both allowed |


---

## CAP-IOS-ADR-0018 — Status planes and capture vs EDTS authority

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Risk of conflating directive approval, PACKAGE_EXPORT_READY, and ingest verification |
| Decision | Maintain STATUS_TAXONOMY; phone may assert only CAPTURE_* / PACKAGE_EXPORTED; EDTS alone assigns INGESTED_INTEGRITY_VERIFIED / CONTENT_UNVERIFIED; XREPO-0001 = canonical compatibility; XREPO-0002 = secure ingestion |
| Alternatives | Single “verified” flag |
| Consequences | CaptureSideStatusGuard rejects EDTS-only statuses from capture |
| Affected contracts | IngestionStatus display only |
| Migration impact | None |
| Integration impact | Clear dual-gate importer work |

---

## CAP-IOS-ADR-0019 — Registry-driven EDTS status rejection

| Field | Value |
|---|---|
| Date | 2026-07-23 |
| Status | ACCEPTED |
| Context | Hard-coded deny lists drift when new EDTS ingest states are added |
| Decision | `status-owner-registry.json` is source of truth; `CaptureSideStatusGuard` rejects any code with `owner: EDTS`; sync script fails CI if Swift drifts |
| Alternatives | Maintain a fixed deny list of two codes |
| Consequences | Future EDTS statuses are blocked on the phone without code churn beyond registry update |
| Affected contracts | StatusOwnerRegistry (JOINT_CAPTURE_EDTS) |
| Migration impact | None |
| Integration impact | Dual-gate result tuple preferred over opaque `INVALID_PACKAGE` |
