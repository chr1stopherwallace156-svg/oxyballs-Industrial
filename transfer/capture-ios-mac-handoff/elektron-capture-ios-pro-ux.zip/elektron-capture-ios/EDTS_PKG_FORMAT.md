# EDTS_PKG_FORMAT

Canonical: [`Docs/Evidence/EDTS_PKG_FORMAT.md`](Docs/Evidence/EDTS_PKG_FORMAT.md)
