# AVFoundation

Deferred to Phase 1 (still capture / depth as applicable). No production implementation in Phase 0.
