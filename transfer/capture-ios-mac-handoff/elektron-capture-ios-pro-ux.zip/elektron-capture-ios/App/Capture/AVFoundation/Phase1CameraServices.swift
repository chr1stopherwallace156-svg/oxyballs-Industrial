#if canImport(AVFoundation) && canImport(UIKit)
import AVFoundation
import Combine
import CoreGraphics
import Foundation
import ImageIO
import UIKit

public final class CameraAuthorizationService: @unchecked Sendable {
  public init() {}

  public func authorizationStatus() -> AVAuthorizationStatus {
    AVCaptureDevice.authorizationStatus(for: .video)
  }

  public func requestAccessIfNeeded() async throws {
    switch authorizationStatus() {
    case .authorized:
      return
    case .notDetermined:
      let granted = await AVCaptureDevice.requestAccess(for: .video)
      if !granted { throw Phase1RuntimeError.cameraPermissionDenied }
    case .denied, .restricted:
      throw Phase1RuntimeError.cameraPermissionDenied
    @unknown default:
      throw Phase1RuntimeError.cameraPermissionDenied
    }
  }
}

/// Physical rear camera lens discovered on-device (never simulated).
public struct DiscoveredCaptureLens: Equatable, Identifiable, Sendable {
  public var id: String { uniqueID }
  public var uniqueID: String
  public var deviceTypeRaw: String
  public var localizedName: String
  public var shortLabel: String
  public var minZoom: Double
  public var maxZoom: Double

  public init(
    uniqueID: String,
    deviceTypeRaw: String,
    localizedName: String,
    shortLabel: String,
    minZoom: Double,
    maxZoom: Double
  ) {
    self.uniqueID = uniqueID
    self.deviceTypeRaw = deviceTypeRaw
    self.localizedName = localizedName
    self.shortLabel = shortLabel
    self.minZoom = minZoom
    self.maxZoom = maxZoom
  }
}

public enum CaptureFlashModeOption: String, CaseIterable, Sendable {
  case off = "off"
  case auto = "auto"
  case on = "on"
}

public enum CaptureTorchModeOption: String, CaseIterable, Sendable {
  case off = "off"
  case on = "on"
}

public final class CameraSessionController: NSObject, @unchecked Sendable {
  public let session = AVCaptureSession()
  private let sessionQueue = DispatchQueue(label: "elektron.capture.session")
  public private(set) var captureDevice: AVCaptureDevice?
  public private(set) var currentInput: AVCaptureDeviceInput?

  public override init() {
    super.init()
  }

  public func configureForStillCapture(device: AVCaptureDevice? = nil) throws {
    session.beginConfiguration()
    defer { session.commitConfiguration() }
    session.sessionPreset = .photo

    session.inputs.forEach { session.removeInput($0) }

    let resolved: AVCaptureDevice
    if let device {
      resolved = device
    } else if let wide = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) {
      resolved = wide
    } else {
      throw Phase1RuntimeError.cameraConfigurationFailed("no rear wide camera")
    }

    let input: AVCaptureDeviceInput
    do {
      input = try AVCaptureDeviceInput(device: resolved)
    } catch {
      throw Phase1RuntimeError.cameraConfigurationFailed(String(describing: error))
    }
    guard session.canAddInput(input) else {
      throw Phase1RuntimeError.cameraConfigurationFailed("cannot add camera input")
    }
    session.addInput(input)
    currentInput = input
    captureDevice = resolved
  }

  public func start(lifecycle: CaptureLifecycleInstrumenter? = nil) {
    lifecycle?.record(.sessionStartRequested, detail: "queue=elektron.capture.session")
    sessionQueue.async { [session] in
      if !session.isRunning {
        session.startRunning()
      }
      let running = session.isRunning
      DispatchQueue.main.async {
        lifecycle?.record(.sessionRunningChanged, detail: "\(running)")
      }
    }
  }

  public func stop() {
    sessionQueue.async { [session] in
      if session.isRunning { session.stopRunning() }
    }
  }
}

/// Interactive still capture: professional framing controls + warm-up shutter (no AE deadlock).
@MainActor
public final class InteractiveStillCaptureController: NSObject, ObservableObject {
  public let sessionController: CameraSessionController
  public let lifecycle: CaptureLifecycleInstrumenter
  public let warmUpNanoseconds: UInt64

  private let auth: CameraAuthorizationService
  private let photoOutput = AVCapturePhotoOutput()
  private var continuation: CheckedContinuation<StillCaptureResult, Error>?
  private var exposureObs: NSKeyValueObservation?
  private var focusObs: NSKeyValueObservation?
  private var runningObs: NSObjectProtocol?
  private var stoppedObs: NSObjectProtocol?
  private var warmUpTask: Task<Void, Never>?
  private var lastTorchMode: CaptureTorchModeOption = .off
  private var lastFlashMode: CaptureFlashModeOption = .off

  @Published public private(set) var sessionRunning = false
  @Published public private(set) var previewAttached = false
  @Published public private(set) var warmUpElapsed = false
  @Published public private(set) var isAdjustingExposure = false
  @Published public private(set) var isAdjustingFocus = false
  @Published public private(set) var shutterEnabled = false
  @Published public private(set) var readinessText = "Starting Camera"
  @Published public private(set) var fatalConfigError: String?
  @Published public private(set) var availableLenses: [DiscoveredCaptureLens] = []
  @Published public private(set) var selectedLensID: String?
  @Published public var flashMode: CaptureFlashModeOption = .off {
    didSet { lastFlashMode = flashMode }
  }
  @Published public var torchMode: CaptureTorchModeOption = .off {
    didSet { applyTorch(torchMode) }
  }
  @Published public var showGrid = false
  @Published public var exposureBias: Float = 0 {
    didSet { applyExposureBias(exposureBias) }
  }
  @Published public private(set) var minExposureBias: Float = -2
  @Published public private(set) var maxExposureBias: Float = 2
  @Published public var zoomFactor: Double = 1 {
    didSet { applyZoom(zoomFactor) }
  }
  @Published public private(set) var minZoom: Double = 1
  @Published public private(set) var maxZoom: Double = 1
  @Published public private(set) var aeAfLocked = false
  @Published public private(set) var focusIndicatorNormalized: CGPoint?
  @Published public private(set) var flashSupported = false
  @Published public private(set) var torchSupported = false

  public var session: AVCaptureSession { sessionController.session }

  public init(
    auth: CameraAuthorizationService = CameraAuthorizationService(),
    sessionController: CameraSessionController = CameraSessionController(),
    lifecycle: CaptureLifecycleInstrumenter = CaptureLifecycleInstrumenter(),
    warmUpNanoseconds: UInt64 = 1_500_000_000
  ) {
    self.auth = auth
    self.sessionController = sessionController
    self.lifecycle = lifecycle
    self.warmUpNanoseconds = warmUpNanoseconds
    super.init()
  }

  public func prepareSession() async throws {
    fatalConfigError = nil
    lifecycle.reset()
    readinessText = "Starting Camera"
    try await auth.requestAccessIfNeeded()
    discoverLenses()
    let initial = preferredInitialDevice()
    do {
      try configurePipeline(with: initial)
    } catch {
      let msg = (error as? Phase1RuntimeError)?.detailMessage ?? String(describing: error)
      fatalConfigError = msg
      readinessText = "Error"
      refreshShutterGate()
      throw error
    }
    observeDeviceAdjustments()
    observeSessionRunning()
    sessionController.start(lifecycle: lifecycle)
    scheduleWarmUp()
    refreshShutterGate()
  }

  public func markPreviewAttached(_ attached: Bool = true) {
    previewAttached = attached
    if attached {
      lifecycle.record(.previewAttached, detail: "AVCaptureVideoPreviewLayer")
    }
    refreshShutterGate()
  }

  public func selectLens(uniqueID: String) {
    guard selectedLensID != uniqueID,
          let device = AVCaptureDevice(uniqueID: uniqueID)
    else { return }
    do {
      let wasTorch = torchMode
      try configurePipeline(with: device)
      observeDeviceAdjustments()
      applyTorch(wasTorch)
      scheduleWarmUp()
      refreshShutterGate()
    } catch {
      fatalConfigError = (error as? Phase1RuntimeError)?.detailMessage ?? String(describing: error)
      readinessText = "Error"
      refreshShutterGate()
    }
  }

  public func setFocusExposure(atDevicePoint devicePoint: CGPoint, viewNormalized: CGPoint) {
    focusIndicatorNormalized = viewNormalized
    guard let device = sessionController.captureDevice else { return }
    let poi = CGPoint(
      x: min(max(devicePoint.x, 0), 1),
      y: min(max(devicePoint.y, 0), 1)
    )
    do {
      try device.lockForConfiguration()
      defer { device.unlockForConfiguration() }
      if device.isFocusPointOfInterestSupported {
        device.focusPointOfInterest = poi
        if device.isFocusModeSupported(.autoFocus) {
          device.focusMode = .autoFocus
        } else if device.isFocusModeSupported(.continuousAutoFocus) {
          device.focusMode = .continuousAutoFocus
        }
      }
      if device.isExposurePointOfInterestSupported {
        device.exposurePointOfInterest = poi
        if device.isExposureModeSupported(.autoExpose) {
          device.exposureMode = .autoExpose
        } else if device.isExposureModeSupported(.continuousAutoExposure) {
          device.exposureMode = .continuousAutoExposure
        }
      }
      aeAfLocked = false
    } catch {
      Phase1CaptureDiagnostics.log(
        stage: "camera_control",
        event: "tap_focus_failed",
        detail: String(describing: error)
      )
    }
  }

  public func toggleAeAfLock() {
    guard let device = sessionController.captureDevice else { return }
    do {
      try device.lockForConfiguration()
      defer { device.unlockForConfiguration() }
      if aeAfLocked {
        if device.isFocusModeSupported(.continuousAutoFocus) {
          device.focusMode = .continuousAutoFocus
        }
        if device.isExposureModeSupported(.continuousAutoExposure) {
          device.exposureMode = .continuousAutoExposure
        }
        aeAfLocked = false
      } else {
        if device.isFocusModeSupported(.locked) {
          device.focusMode = .locked
        }
        if device.isExposureModeSupported(.locked) {
          device.exposureMode = .locked
        }
        aeAfLocked = true
      }
    } catch {
      Phase1CaptureDiagnostics.log(
        stage: "camera_control",
        event: "ae_af_lock_failed",
        detail: String(describing: error)
      )
    }
  }

  public func captureStill() async throws -> StillCaptureResult {
    guard shutterEnabled else {
      throw Phase1RuntimeError.cameraConfigurationFailed(
        "shutter not enabled (sessionRunning=\(sessionRunning) previewAttached=\(previewAttached) warmUpElapsed=\(warmUpElapsed) fatal=\(fatalConfigError ?? "nil"))"
      )
    }
    lifecycle.record(.shutterPressed, detail: "interactive")
    lastFlashMode = flashMode
    lastTorchMode = torchMode
    return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<StillCaptureResult, Error>) in
      self.continuation = cont
      let settings = makePhotoSettings()
      self.photoOutput.capturePhoto(with: settings, delegate: self)
    }
  }

  public func stopSession() {
    warmUpTask?.cancel()
    warmUpTask = nil
    exposureObs?.invalidate()
    focusObs?.invalidate()
    if let runningObs { NotificationCenter.default.removeObserver(runningObs) }
    if let stoppedObs { NotificationCenter.default.removeObserver(stoppedObs) }
    runningObs = nil
    stoppedObs = nil
    applyTorch(.off)
    sessionController.stop()
    sessionRunning = false
    shutterEnabled = false
    refreshShutterGate()
  }

  // MARK: - Private

  private func discoverLenses() {
    let types: [AVCaptureDevice.DeviceType] = [
      .builtInUltraWideCamera,
      .builtInWideAngleCamera,
      .builtInTelephotoCamera,
    ]
    let discovery = AVCaptureDevice.DiscoverySession(
      deviceTypes: types,
      mediaType: .video,
      position: .back
    )
    availableLenses = discovery.devices.map { device in
      DiscoveredCaptureLens(
        uniqueID: device.uniqueID,
        deviceTypeRaw: device.deviceType.rawValue,
        localizedName: device.localizedName,
        shortLabel: Self.shortLabel(for: device.deviceType),
        minZoom: Double(device.minAvailableVideoZoomFactor),
        maxZoom: Double(device.maxAvailableVideoZoomFactor)
      )
    }
  }

  private static func shortLabel(for type: AVCaptureDevice.DeviceType) -> String {
    switch type {
    case .builtInUltraWideCamera: return "0.5×"
    case .builtInWideAngleCamera: return "1×"
    case .builtInTelephotoCamera: return "Tele"
    default: return type.rawValue
    }
  }

  private func preferredInitialDevice() -> AVCaptureDevice? {
    if let wide = availableLenses.first(where: { $0.deviceTypeRaw.contains("WideAngle") }),
       let d = AVCaptureDevice(uniqueID: wide.uniqueID)
    {
      return d
    }
    if let first = availableLenses.first {
      return AVCaptureDevice(uniqueID: first.uniqueID)
    }
    return AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
  }

  private func configurePipeline(with device: AVCaptureDevice?) throws {
    try sessionController.configureForStillCapture(device: device)

    sessionController.session.beginConfiguration()
    defer { sessionController.session.commitConfiguration() }

    if !sessionController.session.outputs.contains(where: { $0 === photoOutput }) {
      if sessionController.session.canAddOutput(photoOutput) {
        sessionController.session.addOutput(photoOutput)
      } else {
        throw Phase1RuntimeError.cameraConfigurationFailed("cannot add photo output")
      }
    }
    if #available(iOS 16.0, *) {
      photoOutput.maxPhotoQualityPrioritization = .quality
    }

    guard let active = sessionController.captureDevice else {
      throw Phase1RuntimeError.cameraConfigurationFailed("no active capture device")
    }
    selectedLensID = active.uniqueID
    flashSupported = active.hasFlash
    torchSupported = active.hasTorch
    minExposureBias = active.minExposureTargetBias
    maxExposureBias = active.maxExposureTargetBias
    minZoom = Double(active.minAvailableVideoZoomFactor)
    maxZoom = Double(active.maxAvailableVideoZoomFactor)
    zoomFactor = min(max(1, minZoom), maxZoom)
    exposureBias = 0
    aeAfLocked = false
    focusIndicatorNormalized = nil

    // Default continuous AF/AE when supported.
    do {
      try active.lockForConfiguration()
      defer { active.unlockForConfiguration() }
      if active.isFocusModeSupported(.continuousAutoFocus) {
        active.focusMode = .continuousAutoFocus
      }
      if active.isExposureModeSupported(.continuousAutoExposure) {
        active.exposureMode = .continuousAutoExposure
      }
      if active.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) {
        active.whiteBalanceMode = .continuousAutoWhiteBalance
      }
    } catch {
      throw Phase1RuntimeError.cameraConfigurationFailed(String(describing: error))
    }
  }

  private func scheduleWarmUp() {
    warmUpTask?.cancel()
    warmUpElapsed = false
    let ns = warmUpNanoseconds
    warmUpTask = Task { [weak self] in
      try? await Task.sleep(nanoseconds: ns)
      guard let self, !Task.isCancelled else { return }
      await MainActor.run {
        self.warmUpElapsed = true
        self.refreshShutterGate()
      }
    }
  }

  private func observeSessionRunning() {
    if let runningObs { NotificationCenter.default.removeObserver(runningObs) }
    if let stoppedObs { NotificationCenter.default.removeObserver(stoppedObs) }
    runningObs = NotificationCenter.default.addObserver(
      forName: .AVCaptureSessionDidStartRunning,
      object: sessionController.session,
      queue: .main
    ) { [weak self] _ in
      Task { @MainActor in
        self?.sessionRunning = true
        self?.lifecycle.record(.sessionRunningChanged, detail: "true")
        self?.refreshShutterGate()
      }
    }
    stoppedObs = NotificationCenter.default.addObserver(
      forName: .AVCaptureSessionDidStopRunning,
      object: sessionController.session,
      queue: .main
    ) { [weak self] _ in
      Task { @MainActor in
        self?.sessionRunning = false
        self?.lifecycle.record(.sessionRunningChanged, detail: "false")
        self?.refreshShutterGate()
      }
    }
  }

  private func observeDeviceAdjustments() {
    exposureObs?.invalidate()
    focusObs?.invalidate()
    guard let device = sessionController.captureDevice else { return }
    isAdjustingExposure = device.isAdjustingExposure
    isAdjustingFocus = device.isAdjustingFocus
    exposureObs = device.observe(\.isAdjustingExposure, options: [.new]) { [weak self] _, change in
      let value = change.newValue ?? false
      Task { @MainActor in
        self?.isAdjustingExposure = value
        self?.lifecycle.record(.deviceAdjustingExposure, detail: "\(value)")
        self?.refreshShutterGate()
      }
    }
    focusObs = device.observe(\.isAdjustingFocus, options: [.new]) { [weak self] _, change in
      let value = change.newValue ?? false
      Task { @MainActor in
        self?.isAdjustingFocus = value
        self?.lifecycle.record(.deviceAdjustingFocus, detail: "\(value)")
        self?.refreshShutterGate()
      }
    }
  }

  private func applyTorch(_ mode: CaptureTorchModeOption) {
    lastTorchMode = mode
    guard let device = sessionController.captureDevice, device.hasTorch else {
      torchSupported = false
      return
    }
    do {
      try device.lockForConfiguration()
      defer { device.unlockForConfiguration() }
      switch mode {
      case .off:
        if device.isTorchModeSupported(.off) { device.torchMode = .off }
      case .on:
        if device.isTorchModeSupported(.on) {
          try device.setTorchModeOn(level: 1.0)
        }
      }
    } catch {
      Phase1CaptureDiagnostics.log(
        stage: "camera_control",
        event: "torch_failed",
        detail: String(describing: error)
      )
    }
  }

  private func applyExposureBias(_ bias: Float) {
    guard let device = sessionController.captureDevice else { return }
    let clamped = min(max(bias, device.minExposureTargetBias), device.maxExposureTargetBias)
    do {
      try device.lockForConfiguration()
      defer { device.unlockForConfiguration() }
      device.setExposureTargetBias(clamped, completionHandler: nil)
    } catch {
      Phase1CaptureDiagnostics.log(
        stage: "camera_control",
        event: "exposure_bias_failed",
        detail: String(describing: error)
      )
    }
  }

  private func applyZoom(_ factor: Double) {
    guard let device = sessionController.captureDevice else { return }
    let clamped = min(max(factor, Double(device.minAvailableVideoZoomFactor)), Double(device.maxAvailableVideoZoomFactor))
    do {
      try device.lockForConfiguration()
      defer { device.unlockForConfiguration() }
      device.videoZoomFactor = CGFloat(clamped)
    } catch {
      Phase1CaptureDiagnostics.log(
        stage: "camera_control",
        event: "zoom_failed",
        detail: String(describing: error)
      )
    }
  }

  private func makePhotoSettings() -> AVCapturePhotoSettings {
    let settings: AVCapturePhotoSettings
    if photoOutput.availablePhotoCodecTypes.contains(.jpeg) {
      settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
    } else {
      settings = AVCapturePhotoSettings()
    }
    if let device = sessionController.captureDevice, device.hasFlash {
      switch flashMode {
      case .off: settings.flashMode = .off
      case .auto: settings.flashMode = .auto
      case .on: settings.flashMode = .on
      }
    } else {
      settings.flashMode = .off
    }
    return settings
  }

  /// Shutter enablement uses session + preview + warm-up — **not** a hard AE/AF lock.
  private func refreshShutterGate() {
    if let fatalConfigError {
      shutterEnabled = false
      readinessText = "Error"
      return
    }
    let readyCore = sessionRunning && previewAttached && warmUpElapsed
    if readyCore {
      if !shutterEnabled {
        shutterEnabled = true
        lifecycle.record(
          .shutterEnabled,
          detail: "ms_session_running_to_shutter_enabled=\(lifecycle.msSessionRunningToShutterEnabled.map { String(format: "%.3f", $0) } ?? "nil")"
        )
      }
      if isAdjustingExposure || isAdjustingFocus {
        readinessText = "Adjusting"
      } else {
        readinessText = "Ready"
      }
    } else {
      shutterEnabled = false
      if !sessionRunning {
        readinessText = "Starting Camera"
      } else if !previewAttached {
        readinessText = "Starting Camera"
      } else if !warmUpElapsed {
        readinessText = "Adjusting"
      } else {
        readinessText = "Adjusting"
      }
    }
  }

  private func buildShotMetadata(photo: AVCapturePhoto, jpegByteCount: Int) -> StillCaptureShotMetadata {
    let device = sessionController.captureDevice
    let flashFired: Bool? = {
      if let dict = photo.metadata[kCGImagePropertyExifDictionary as String] as? [String: Any],
         let flash = dict[kCGImagePropertyExifFlash as String] as? NSNumber
      {
        // EXIF Flash bit 0 = fired
        return (flash.intValue & 1) == 1
      }
      return nil
    }()
    let dims = photo.resolvedSettings.photoDimensions
    return StillCaptureShotMetadata(
      flashModeRequested: lastFlashMode.rawValue,
      flashFired: flashFired,
      torchModeDuringFraming: lastTorchMode.rawValue,
      physicalCameraUniqueID: device?.uniqueID,
      physicalCameraType: device?.deviceType.rawValue,
      lensPosition: device.map { Double($0.lensPosition) },
      videoZoomFactor: device.map { Double($0.videoZoomFactor) },
      exposureDurationSeconds: device.map { CMTimeGetSeconds($0.exposureDuration) },
      iso: device.map { Double($0.iso) },
      exposureBiasEV: device.map { Double($0.exposureTargetBias) },
      focusMode: device.map { String(describing: $0.focusMode.rawValue) },
      exposureMode: device.map { String(describing: $0.exposureMode.rawValue) },
      whiteBalanceMode: device.map { String(describing: $0.whiteBalanceMode.rawValue) },
      imageOrientation: String(describing: photo.metadata[kCGImagePropertyOrientation as String] ?? NSNull()),
      pixelWidth: Int(dims.width),
      pixelHeight: Int(dims.height),
      rawPhotoMetadata: StillCaptureShotMetadata.sanitizeJSONTree(photo.metadata) as? [String: Any]
    )
  }
}

extension InteractiveStillCaptureController: AVCapturePhotoCaptureDelegate {
  public nonisolated func photoOutput(
    _ output: AVCapturePhotoOutput,
    didFinishProcessingPhoto photo: AVCapturePhoto,
    error: Error?
  ) {
    Task { @MainActor in
      self.handlePhoto(photo, error: error)
    }
  }

  private func handlePhoto(_ photo: AVCapturePhoto, error: Error?) {
    if let error {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "capture_failure",
        detail: String(describing: error)
      )
      lifecycle.record(.photoDelegateReceived, detail: "error=true")
      continuation?.resume(throwing: Phase1RuntimeError.photoCaptureFailed(error.localizedDescription))
      continuation = nil
      return
    }
    if let data = photo.fileDataRepresentation() {
      let hash = ArtifactHashingService().sha256HexOfData(data)
      let meta = buildShotMetadata(photo: photo, jpegByteCount: data.count)
      lifecycle.record(
        .photoDelegateReceived,
        detail: "byteCount=\(data.count) sha256=\(hash) ms_shutter_to_delegate=\(lifecycle.msShutterPressToPhotoDelegate.map { String(format: "%.3f", $0) } ?? "nil")"
      )
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "fileDataRepresentation_ok",
        detail: "byteCount=\(data.count) sha256=\(hash) note=JPEG bytes not logged | \(lifecycle.summaryLine())"
      )
      continuation?.resume(
        returning: StillCaptureResult(jpegBytes: data, postDelegateSha256: hash, metadata: meta)
      )
    } else {
      lifecycle.record(.photoDelegateReceived, detail: "file_representation_unavailable")
      continuation?.resume(throwing: Phase1RuntimeError.fileRepresentationUnavailable)
    }
    continuation = nil
  }
}

/// One-shot still capture (tests / legacy). Prefer `InteractiveStillCaptureController` for UI.
public final class StillPhotoCaptureService: NSObject, StillPhotoCaptureProviding, @unchecked Sendable {
  private let auth: CameraAuthorizationService
  private let controller: CameraSessionController
  private let photoOutput = AVCapturePhotoOutput()
  private var continuation: CheckedContinuation<Data, Error>?
  public let lifecycle: CaptureLifecycleInstrumenter

  public init(
    auth: CameraAuthorizationService = CameraAuthorizationService(),
    controller: CameraSessionController = CameraSessionController(),
    lifecycle: CaptureLifecycleInstrumenter = CaptureLifecycleInstrumenter()
  ) {
    self.auth = auth
    self.controller = controller
    self.lifecycle = lifecycle
    super.init()
  }

  public func captureProcessedJPEG() async throws -> Data {
    try await auth.requestAccessIfNeeded()
    try controller.configureForStillCapture()
    if controller.session.canAddOutput(photoOutput) {
      controller.session.addOutput(photoOutput)
    } else if !controller.session.outputs.contains(where: { $0 === photoOutput }) {
      throw Phase1RuntimeError.cameraConfigurationFailed("cannot add photo output")
    }
    if #available(iOS 16.0, *) {
      photoOutput.maxPhotoQualityPrioritization = .quality
    }
    controller.start(lifecycle: lifecycle)
    try await Task.sleep(nanoseconds: 250_000_000)
    lifecycle.record(.shutterEnabled, detail: "one_shot_settle")
    lifecycle.record(.shutterPressed, detail: "one_shot")

    return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Data, Error>) in
      self.continuation = cont
      let settings = AVCapturePhotoSettings()
      if photoOutput.availablePhotoCodecTypes.contains(.jpeg) {
        let s = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
        self.photoOutput.capturePhoto(with: s, delegate: self)
      } else {
        self.photoOutput.capturePhoto(with: settings, delegate: self)
      }
    }
  }
}

extension StillPhotoCaptureService: AVCapturePhotoCaptureDelegate {
  public func photoOutput(
    _ output: AVCapturePhotoOutput,
    didFinishProcessingPhoto photo: AVCapturePhoto,
    error: Error?
  ) {
    if let error {
      lifecycle.record(.photoDelegateReceived, detail: "error=true")
      continuation?.resume(throwing: Phase1RuntimeError.photoCaptureFailed(error.localizedDescription))
      continuation = nil
      controller.stop()
      return
    }
    if let data = photo.fileDataRepresentation() {
      lifecycle.record(.photoDelegateReceived, detail: "byteCount=\(data.count)")
      continuation?.resume(returning: data)
    } else {
      lifecycle.record(.photoDelegateReceived, detail: "file_representation_unavailable")
      continuation?.resume(throwing: Phase1RuntimeError.fileRepresentationUnavailable)
    }
    continuation = nil
    controller.stop()
  }
}
#endif
