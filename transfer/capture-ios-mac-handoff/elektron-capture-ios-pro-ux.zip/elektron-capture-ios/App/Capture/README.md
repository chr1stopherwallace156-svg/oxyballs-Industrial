# Capture

Apple-native AVFoundation path (Phase 1+).

Submodules: `AVFoundation/`, `PhotoCaptureCoordinator/`, `DepthCapture/`, `OriginalArtifactWriter/`.

Preserve ORIGINAL (HEIC/DNG + metadata + depth + calibration + hash) and DERIVED artifacts with parent hashes.
