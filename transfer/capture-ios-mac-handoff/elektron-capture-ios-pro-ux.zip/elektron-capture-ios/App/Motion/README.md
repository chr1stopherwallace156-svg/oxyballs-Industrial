# Motion

Core Motion supporting evidence (Phase 2). ARKit pose remains primary guidance pose for v1.
