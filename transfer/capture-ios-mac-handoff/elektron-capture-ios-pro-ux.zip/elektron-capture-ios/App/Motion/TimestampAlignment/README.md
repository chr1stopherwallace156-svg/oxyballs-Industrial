# TimestampAlignment

Deferred to Phase 2.
