# CoreMotionRecorder

Deferred to Phase 2.
