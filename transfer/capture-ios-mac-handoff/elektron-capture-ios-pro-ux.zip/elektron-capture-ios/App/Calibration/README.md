# Calibration

AVCameraCalibrationData-first (Phase 3). OpenCV coefficients are derivatives only.
