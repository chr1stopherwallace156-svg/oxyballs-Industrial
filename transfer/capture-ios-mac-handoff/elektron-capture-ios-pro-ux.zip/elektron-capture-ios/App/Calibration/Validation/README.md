# Validation

Deferred to Phase 3.
