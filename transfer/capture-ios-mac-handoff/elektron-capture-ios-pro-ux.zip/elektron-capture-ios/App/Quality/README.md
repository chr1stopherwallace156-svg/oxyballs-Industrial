# Quality

Modular, explainable quality gates. No single unexplained score. Blur thresholds are profile-versioned.
