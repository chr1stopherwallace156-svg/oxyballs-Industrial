import Foundation

/// MOCK EDTS client — must never be selected in production builds without an explicit environment gate.
public struct MockEDTSClient: EDTSClient {
  public var planProvider: CapturePlanProviding
  public var isMock: Bool { true }

  public init(planProvider: CapturePlanProviding = LocalCapturePlanProvider()) {
    self.planProvider = planProvider
  }

  public func fetchCapturePlan(planId: String) async throws -> CapturePlanDTO {
    try await planProvider.loadPlan(planId: planId)
  }

  public func submitEvidencePackage(directoryURL: URL) async throws -> EDTSIntakeStatus {
    let candidates = ["evidence_manifest.json", "manifest.json"]
    let hasManifest = candidates.contains {
      FileManager.default.fileExists(atPath: directoryURL.appendingPathComponent($0).path)
    }
    guard hasManifest else {
      return .evidenceRejected
    }
    // Mock accepts structurally present packages only — not engineering verification.
    return .engineeringReviewRequired
  }
}
