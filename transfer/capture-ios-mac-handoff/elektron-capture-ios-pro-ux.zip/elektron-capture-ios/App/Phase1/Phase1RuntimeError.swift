import Foundation

/// Machine-readable Phase 1 runtime failures.
public enum Phase1RuntimeError: Error, Equatable, Sendable {
  case cameraPermissionDenied
  case cameraConfigurationFailed(String)
  case photoCaptureFailed(String)
  case fileRepresentationUnavailable
  case artifactPersistenceFailed(String)
  case readbackFailed(String)
  case artifactHashFailed(String)
  case hashReadbackMismatch(expected: String, actual: String)
  case manifestBuildFailed(String)
  case canonicalizationFailed(String)
  case inventoryBuildFailed(String)
  case packageBuildFailed(String)
  case exportFailed(String)
  case statusAuthorityViolation(String)
  case incompleteCleanup(String)
  /// Non-authoritative quality guard: image is effectively black on inspection decode.
  case captureQualityImageEffectivelyBlack(String)

  public var reasonCode: String {
    switch self {
    case .cameraPermissionDenied: return "CAMERA_PERMISSION_DENIED"
    case .cameraConfigurationFailed: return "CAMERA_CONFIGURATION_FAILED"
    case .photoCaptureFailed: return "PHOTO_CAPTURE_FAILED"
    case .fileRepresentationUnavailable: return "FILE_REPRESENTATION_UNAVAILABLE"
    case .artifactPersistenceFailed: return "ARTIFACT_PERSISTENCE_FAILED"
    case .readbackFailed: return "READBACK_FAILED"
    case .artifactHashFailed: return "ARTIFACT_HASH_FAILED"
    case .hashReadbackMismatch: return "HASH_READBACK_MISMATCH"
    case .manifestBuildFailed: return "MANIFEST_BUILD_FAILED"
    case .canonicalizationFailed: return "CANONICALIZATION_FAILED"
    case .inventoryBuildFailed: return "INVENTORY_BUILD_FAILED"
    case .packageBuildFailed: return "PACKAGE_BUILD_FAILED"
    case .exportFailed: return "EXPORT_FAILED"
    case .statusAuthorityViolation: return "STATUS_AUTHORITY_VIOLATION"
    case .incompleteCleanup: return "INCOMPLETE_CLEANUP"
    case .captureQualityImageEffectivelyBlack: return "CAPTURE_QUALITY_IMAGE_EFFECTIVELY_BLACK"
    }
  }

  /// Underlying detail for UI / console — never empty for associated-value cases.
  public var detailMessage: String {
    switch self {
    case .cameraPermissionDenied:
      return "Camera permission denied"
    case .fileRepresentationUnavailable:
      return "AVCapturePhoto.fileDataRepresentation() returned nil"
    case .cameraConfigurationFailed(let s),
      .photoCaptureFailed(let s),
      .artifactPersistenceFailed(let s),
      .readbackFailed(let s),
      .artifactHashFailed(let s),
      .manifestBuildFailed(let s),
      .canonicalizationFailed(let s),
      .inventoryBuildFailed(let s),
      .packageBuildFailed(let s),
      .exportFailed(let s),
      .statusAuthorityViolation(let s),
      .incompleteCleanup(let s),
      .captureQualityImageEffectivelyBlack(let s):
      return s
    case .hashReadbackMismatch(let expected, let actual):
      return "expected=\(expected) actual=\(actual)"
    }
  }
}
