import Foundation

/// Phase 1 still-camera UI / pipeline states (operator workflow).
/// Distinct from repository `CaptureSessionState` (plan/session lifecycle).
public enum Phase1StillCaptureUIState: String, Sendable, Equatable, CaseIterable {
  case previewing = "PREVIEWING"
  case capturing = "CAPTURING"
  case reviewing = "REVIEWING"
  case approved = "APPROVED"
  case exported = "EXPORTED"
  case error = "ERROR"
}

public enum Phase1StillCaptureUITransitionError: Error, Equatable, Sendable {
  case illegal(from: Phase1StillCaptureUIState, to: Phase1StillCaptureUIState, reason: String)
}

/// Enforces Take → Approve → Export. No package write before `.approved`.
public enum Phase1StillCaptureUIStateMachine {
  public static func canTransition(from: Phase1StillCaptureUIState, to: Phase1StillCaptureUIState) -> Bool {
    switch (from, to) {
    case (.previewing, .capturing),
      (.previewing, .error),
      (.capturing, .reviewing),
      (.capturing, .previewing), // capture failed → back to live
      (.capturing, .error),
      (.reviewing, .previewing), // Retake
      (.reviewing, .approved), // Use Photo
      (.reviewing, .error),
      (.approved, .exported), // Export Package
      (.approved, .previewing), // abandon approval / new framing
      (.approved, .error),
      (.exported, .previewing), // New Capture
      (.error, .previewing):
      return true
    default:
      return false
    }
  }

  @discardableResult
  public static func transition(
    from: Phase1StillCaptureUIState,
    to: Phase1StillCaptureUIState
  ) throws -> Phase1StillCaptureUIState {
    guard canTransition(from: from, to: to) else {
      throw Phase1StillCaptureUITransitionError.illegal(
        from: from,
        to: to,
        reason: "illegal Phase 1 still UI transition \(from.rawValue) → \(to.rawValue)"
      )
    }
    return to
  }
}

/// Snapshot of camera settings + photo metadata recorded at capture time.
/// Unavailable values serialize as JSON null via `asDictionary()`.
public struct StillCaptureShotMetadata: Equatable, Sendable {
  public var flashModeRequested: String?
  public var flashFired: Bool?
  public var torchModeDuringFraming: String?
  public var physicalCameraUniqueID: String?
  public var physicalCameraType: String?
  public var lensPosition: Double?
  public var videoZoomFactor: Double?
  public var exposureDurationSeconds: Double?
  public var iso: Double?
  public var exposureBiasEV: Double?
  public var focusMode: String?
  public var exposureMode: String?
  public var whiteBalanceMode: String?
  public var imageOrientation: String?
  public var pixelWidth: Int?
  public var pixelHeight: Int?
  /// Sanitized AVCapturePhoto.metadata — scalars/arrays/dicts only; never raw binary blobs.
  public var rawPhotoMetadata: [String: Any]?

  public init(
    flashModeRequested: String? = nil,
    flashFired: Bool? = nil,
    torchModeDuringFraming: String? = nil,
    physicalCameraUniqueID: String? = nil,
    physicalCameraType: String? = nil,
    lensPosition: Double? = nil,
    videoZoomFactor: Double? = nil,
    exposureDurationSeconds: Double? = nil,
    iso: Double? = nil,
    exposureBiasEV: Double? = nil,
    focusMode: String? = nil,
    exposureMode: String? = nil,
    whiteBalanceMode: String? = nil,
    imageOrientation: String? = nil,
    pixelWidth: Int? = nil,
    pixelHeight: Int? = nil,
    rawPhotoMetadata: [String: Any]? = nil
  ) {
    self.flashModeRequested = flashModeRequested
    self.flashFired = flashFired
    self.torchModeDuringFraming = torchModeDuringFraming
    self.physicalCameraUniqueID = physicalCameraUniqueID
    self.physicalCameraType = physicalCameraType
    self.lensPosition = lensPosition
    self.videoZoomFactor = videoZoomFactor
    self.exposureDurationSeconds = exposureDurationSeconds
    self.iso = iso
    self.exposureBiasEV = exposureBiasEV
    self.focusMode = focusMode
    self.exposureMode = exposureMode
    self.whiteBalanceMode = whiteBalanceMode
    self.imageOrientation = imageOrientation
    self.pixelWidth = pixelWidth
    self.pixelHeight = pixelHeight
    self.rawPhotoMetadata = rawPhotoMetadata
  }

  public static func == (lhs: StillCaptureShotMetadata, rhs: StillCaptureShotMetadata) -> Bool {
    lhs.flashModeRequested == rhs.flashModeRequested
      && lhs.flashFired == rhs.flashFired
      && lhs.torchModeDuringFraming == rhs.torchModeDuringFraming
      && lhs.physicalCameraUniqueID == rhs.physicalCameraUniqueID
      && lhs.physicalCameraType == rhs.physicalCameraType
      && lhs.lensPosition == rhs.lensPosition
      && lhs.videoZoomFactor == rhs.videoZoomFactor
      && lhs.exposureDurationSeconds == rhs.exposureDurationSeconds
      && lhs.iso == rhs.iso
      && lhs.exposureBiasEV == rhs.exposureBiasEV
      && lhs.focusMode == rhs.focusMode
      && lhs.exposureMode == rhs.exposureMode
      && lhs.whiteBalanceMode == rhs.whiteBalanceMode
      && lhs.imageOrientation == rhs.imageOrientation
      && lhs.pixelWidth == rhs.pixelWidth
      && lhs.pixelHeight == rhs.pixelHeight
    // rawPhotoMetadata excluded from Equatable deep compare (Any)
  }

  public func asDictionary() -> [String: Any] {
    var out: [String: Any] = [
      "schema_id": "AVCaptureMetadata",
      "schema_version": "1.1.0",
      "representation": ArtifactRepresentation.appleEncodedJpeg.rawValue,
      "role": ArtifactRole.originalCaptureOutput.rawValue,
      "pixel_processing_claim": PixelProcessingClaim.notAsserted.rawValue,
      "notes": [
        "Only values observed at capture time are recorded.",
        "Preview/UI decode must not replace fileDataRepresentation bytes.",
      ],
      "flash_mode_requested": flashModeRequested ?? NSNull(),
      "flash_fired": flashFired.map { $0 as Any } ?? NSNull(),
      "torch_mode_during_framing": torchModeDuringFraming ?? NSNull(),
      "physical_camera_unique_id": physicalCameraUniqueID ?? NSNull(),
      "physical_camera_type": physicalCameraType ?? NSNull(),
      "lens_position": lensPosition.map { $0 as Any } ?? NSNull(),
      "video_zoom_factor": videoZoomFactor.map { $0 as Any } ?? NSNull(),
      "exposure_duration_seconds": exposureDurationSeconds.map { $0 as Any } ?? NSNull(),
      "iso": iso.map { $0 as Any } ?? NSNull(),
      "exposure_bias_ev": exposureBiasEV.map { $0 as Any } ?? NSNull(),
      "focus_mode": focusMode ?? NSNull(),
      "exposure_mode": exposureMode ?? NSNull(),
      "white_balance_mode": whiteBalanceMode ?? NSNull(),
      "image_orientation": imageOrientation ?? NSNull(),
      "pixel_width": pixelWidth.map { $0 as Any } ?? NSNull(),
      "pixel_height": pixelHeight.map { $0 as Any } ?? NSNull(),
    ]
    if let raw = rawPhotoMetadata {
      out["raw_avcapture_photo_metadata"] = Self.sanitizeJSONTree(raw)
    } else {
      out["raw_avcapture_photo_metadata"] = NSNull()
    }
    return out
  }

  /// Drop non-JSON-safe leaves (Data, unknown objects) so CanonicalJSON can encode.
  public static func sanitizeJSONTree(_ value: Any) -> Any {
    if value is NSNull { return NSNull() }
    if let s = value as? String { return s }
    if let b = value as? Bool { return b }
    if type(of: value) == Bool.self, let b = value as? Bool { return b }
    if let n = value as? NSNumber { return n }
    if let i = value as? Int { return i }
    if let d = value as? Double { return d }
    if let f = value as? Float { return Double(f) }
    if let dict = value as? [String: Any] {
      var out: [String: Any] = [:]
      for (k, v) in dict {
        out[k] = sanitizeJSONTree(v)
      }
      return out
    }
    if let arr = value as? [Any] {
      return arr.map { sanitizeJSONTree($0) }
    }
    // Skip Data / undocumented types — record as null rather than fail packaging.
    return NSNull()
  }
}

public struct StillCaptureResult: Equatable, Sendable {
  public var jpegBytes: Data
  public var postDelegateSha256: String
  public var metadata: StillCaptureShotMetadata

  public init(jpegBytes: Data, postDelegateSha256: String, metadata: StillCaptureShotMetadata) {
    self.jpegBytes = jpegBytes
    self.postDelegateSha256 = postDelegateSha256
    self.metadata = metadata
  }
}
