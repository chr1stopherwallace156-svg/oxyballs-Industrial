import Foundation

/// Thin alias matching the Phase 1 component name; delegates to `CanonicalJSON`.
public enum CanonicalJSONEncoder {
  /// Encodes with optional stage label for diagnostics. Never drops the underlying error.
  public static func encode(_ object: Any, stage: String = "canonical") throws -> Data {
    #if DEBUG
    let unsupported = CanonicalJSON.unsupportedValues(in: object)
    if !unsupported.isEmpty {
      let report = unsupported.map {
        "\($0.keyPath) type=\($0.runtimeType) describing=\($0.describing) reflecting=\($0.reflecting)"
      }.joined(separator: "; ")
      Phase1CaptureDiagnostics.log(
        stage: stage,
        event: "preflight_unsupported_values",
        detail: report
      )
    }
    #endif

    do {
      return try CanonicalJSON.data(object)
    } catch {
      let unsupported = CanonicalJSON.unsupportedValues(in: object)
      let unsupportedReport =
        unsupported.isEmpty
        ? "none"
        : unsupported.map {
          "\($0.keyPath) type=\($0.runtimeType) describing=\($0.describing)"
        }.joined(separator: "; ")

      let detail = [
        "stage=\(stage)",
        "swiftErrorType=\(String(describing: type(of: error)))",
        "describing=\(String(describing: error))",
        "reflecting=\(String(reflecting: error))",
        "localizedDescription=\(error.localizedDescription)",
        "unsupportedValues=\(unsupportedReport)",
      ].joined(separator: " | ")

      Phase1CaptureDiagnostics.log(stage: stage, event: "canonicalization_failed", detail: detail)
      // Preserve original cause inside the reason payload — never map silently.
      throw Phase1RuntimeError.canonicalizationFailed(detail)
    }
  }
}

/// Lightweight stderr diagnostics for physical-device capture failures.
public enum Phase1CaptureDiagnostics {
  public static func log(stage: String, event: String, detail: String) {
    let line = "[Phase1Capture] stage=\(stage) event=\(event) \(detail)"
    print(line)
    fputs(line + "\n", stderr)
  }
}
