import Foundation

public struct PersistedArtifact: Equatable, Sendable {
  public var fileURL: URL
  public var relativePath: String
  public var byteSize: Int
  public var sha256: String
  public var mediaType: String
  public var representation: ArtifactRepresentation

  public init(
    fileURL: URL,
    relativePath: String,
    byteSize: Int,
    sha256: String,
    mediaType: String,
    representation: ArtifactRepresentation
  ) {
    self.fileURL = fileURL
    self.relativePath = relativePath
    self.byteSize = byteSize
    self.sha256 = sha256
    self.mediaType = mediaType
    self.representation = representation
  }
}

/// Write-once persistence of exact capture file bytes (no re-encode).
public struct ArtifactPersistenceService: Sendable {
  public var hasher: ArtifactHashingService

  public init(hasher: ArtifactHashingService = ArtifactHashingService()) {
    self.hasher = hasher
  }

  /// Writes `data` exactly once, then hashes via read-back from disk.
  public func persistExactBytes(
    _ data: Data,
    to relativePath: String,
    under root: URL,
    mediaType: String,
    representation: ArtifactRepresentation
  ) throws -> PersistedArtifact {
    guard !data.isEmpty else {
      throw Phase1RuntimeError.fileRepresentationUnavailable
    }
    let url = root.appendingPathComponent(relativePath)
    do {
      try FileManager.default.createDirectory(
        at: url.deletingLastPathComponent(),
        withIntermediateDirectories: true
      )
      if FileManager.default.fileExists(atPath: url.path) {
        throw Phase1RuntimeError.artifactPersistenceFailed("refusing overwrite: \(relativePath)")
      }
      try data.write(to: url, options: .withoutOverwriting)
    } catch let e as Phase1RuntimeError {
      throw e
    } catch {
      throw Phase1RuntimeError.artifactPersistenceFailed(String(describing: error))
    }

    // Read-back before seal
    let readback: Data
    do {
      readback = try Data(contentsOf: url)
    } catch {
      throw Phase1RuntimeError.readbackFailed(String(describing: error))
    }
    if readback.count != data.count {
      throw Phase1RuntimeError.hashReadbackMismatch(
        expected: "size=\(data.count)",
        actual: "size=\(readback.count)"
      )
    }
    let inMemory = hasher.sha256HexOfData(data)
    let onDisk: String
    do {
      onDisk = try hasher.sha256HexOfFile(at: url)
    } catch let e as Phase1RuntimeError {
      throw e
    } catch {
      throw Phase1RuntimeError.artifactHashFailed(String(describing: error))
    }
    if inMemory != onDisk {
      throw Phase1RuntimeError.hashReadbackMismatch(expected: inMemory, actual: onDisk)
    }
    return PersistedArtifact(
      fileURL: url,
      relativePath: relativePath,
      byteSize: readback.count,
      sha256: onDisk,
      mediaType: mediaType,
      representation: representation
    )
  }
}
