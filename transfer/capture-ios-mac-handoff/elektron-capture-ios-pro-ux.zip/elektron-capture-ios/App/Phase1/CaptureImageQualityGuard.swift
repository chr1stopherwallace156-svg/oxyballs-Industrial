import Foundation

#if canImport(ImageIO)
import CoreGraphics
import ImageIO
#endif

/// Thresholds for the non-authoritative black-frame quality guard.
/// Evaluated on a throwaway decoded inspection representation — never mutates artifact bytes.
public struct CaptureImageQualityThresholds: Equatable, Sendable {
  /// Mean luminance (0…255) at or below this value is "near zero".
  public var maxMeanLuminance: Double
  /// Fraction of sampled pixels with luminance ≤ `nearBlackMax` that must also hold.
  public var minNearBlackFraction: Double
  /// Per-pixel luminance at or below this counts as near-black.
  public var nearBlackMax: UInt8
  /// Cap on samples drawn from a decoded raster (stride sampling).
  public var maxSamples: Int

  public init(
    maxMeanLuminance: Double = 8.0,
    minNearBlackFraction: Double = 0.98,
    nearBlackMax: UInt8 = 8,
    maxSamples: Int = 10_000
  ) {
    self.maxMeanLuminance = maxMeanLuminance
    self.minNearBlackFraction = minNearBlackFraction
    self.nearBlackMax = nearBlackMax
    self.maxSamples = maxSamples
  }

  /// Documented Phase 1 defaults used by production capture path.
  public static let phase1Default = CaptureImageQualityThresholds()
}

public struct CaptureImageQualityMetrics: Equatable, Sendable {
  public var meanLuminance: Double
  public var nearBlackFraction: Double
  public var sampleCount: Int

  public init(meanLuminance: Double, nearBlackFraction: Double, sampleCount: Int) {
    self.meanLuminance = meanLuminance
    self.nearBlackFraction = nearBlackFraction
    self.sampleCount = sampleCount
  }
}

public enum CaptureImageQualityVerdict: Equatable, Sendable {
  case acceptable(CaptureImageQualityMetrics)
  case effectivelyBlack(CaptureImageQualityMetrics)

  public var metrics: CaptureImageQualityMetrics {
    switch self {
    case .acceptable(let m), .effectivelyBlack(let m):
      return m
    }
  }

  public var isEffectivelyBlack: Bool {
    if case .effectivelyBlack = self { return true }
    return false
  }
}

/// Conservative capture-side guard. Reject only when **both** mean luminance is near zero
/// **and** an overwhelming share of sampled pixels are near black.
public enum CaptureImageQualityGuard {
  public static func evaluate(
    luminanceSamples: [UInt8],
    thresholds: CaptureImageQualityThresholds = .phase1Default
  ) -> CaptureImageQualityVerdict {
    guard !luminanceSamples.isEmpty else {
      let empty = CaptureImageQualityMetrics(meanLuminance: 0, nearBlackFraction: 1, sampleCount: 0)
      return .effectivelyBlack(empty)
    }
    let limited: ArraySlice<UInt8>
    if luminanceSamples.count <= thresholds.maxSamples {
      limited = luminanceSamples[...]
    } else {
      let stride = max(1, luminanceSamples.count / thresholds.maxSamples)
      var picked: [UInt8] = []
      picked.reserveCapacity(thresholds.maxSamples)
      var i = 0
      while i < luminanceSamples.count, picked.count < thresholds.maxSamples {
        picked.append(luminanceSamples[i])
        i += stride
      }
      return evaluate(luminanceSamples: picked, thresholds: thresholds)
    }

    var sum = 0
    var nearBlack = 0
    for y in limited {
      sum += Int(y)
      if y <= thresholds.nearBlackMax { nearBlack += 1 }
    }
    let n = limited.count
    let mean = Double(sum) / Double(n)
    let frac = Double(nearBlack) / Double(n)
    let metrics = CaptureImageQualityMetrics(
      meanLuminance: mean,
      nearBlackFraction: frac,
      sampleCount: n
    )
    if mean <= thresholds.maxMeanLuminance, frac >= thresholds.minNearBlackFraction {
      return .effectivelyBlack(metrics)
    }
    return .acceptable(metrics)
  }

  /// Decodes JPEG into a temporary RGB buffer for inspection only.
  /// Original `fileDataRepresentation()` bytes must remain untouched by callers.
  public static func evaluateJPEGInspection(
    _ jpegBytes: Data,
    thresholds: CaptureImageQualityThresholds = .phase1Default
  ) throws -> CaptureImageQualityVerdict {
    #if canImport(ImageIO)
    guard let source = CGImageSourceCreateWithData(jpegBytes as CFData, nil),
          let image = CGImageSourceCreateImageAtIndex(source, 0, [
            kCGImageSourceShouldCache: false,
          ] as CFDictionary)
    else {
      throw Phase1RuntimeError.packageBuildFailed("quality guard could not decode JPEG inspection image")
    }
    let samples = try luminanceSamples(from: image, maxSamples: thresholds.maxSamples)
    return evaluate(luminanceSamples: samples, thresholds: thresholds)
    #else
    // Linux CI: JPEG decode unavailable — callers must use luminanceSamples fixtures.
    throw Phase1RuntimeError.packageBuildFailed(
      "quality guard JPEG inspection requires ImageIO (use luminance fixture tests on Linux)"
    )
    #endif
  }

  #if canImport(ImageIO)
  private static func luminanceSamples(from image: CGImage, maxSamples: Int) throws -> [UInt8] {
    let width = image.width
    let height = image.height
    guard width > 0, height > 0 else {
      throw Phase1RuntimeError.packageBuildFailed("quality guard image has zero dimensions")
    }
    // Downsample target ~sqrt(maxSamples) on each axis.
    let target = max(1, Int(Double(maxSamples).squareRoot()))
    let outW = min(width, target)
    let outH = min(height, target)
    let bytesPerPixel = 4
    let bytesPerRow = outW * bytesPerPixel
    var buffer = [UInt8](repeating: 0, count: outH * bytesPerRow)
    guard let ctx = CGContext(
      data: &buffer,
      width: outW,
      height: outH,
      bitsPerComponent: 8,
      bytesPerRow: bytesPerRow,
      space: CGColorSpaceCreateDeviceRGB(),
      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
    ) else {
      throw Phase1RuntimeError.packageBuildFailed("quality guard bitmap context failed")
    }
    ctx.interpolationQuality = .low
    ctx.draw(image, in: CGRect(x: 0, y: 0, width: outW, height: outH))

    var samples: [UInt8] = []
    samples.reserveCapacity(outW * outH)
    for y in 0..<outH {
      let row = y * bytesPerRow
      for x in 0..<outW {
        let i = row + x * bytesPerPixel
        let r = Double(buffer[i])
        let g = Double(buffer[i + 1])
        let b = Double(buffer[i + 2])
        // Rec. 601 luma; inspection only.
        let y601 = 0.299 * r + 0.587 * g + 0.114 * b
        samples.append(UInt8(clamping: Int(y601.rounded())))
      }
    }
    return samples
  }
  #endif
}
