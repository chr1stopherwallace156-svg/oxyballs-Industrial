import Foundation

public struct MotionSampleRecord: Equatable, Sendable {
  public var availability: String
  public var authority: String
  public var referenceFrame: String
  public var trueNorthClaimed: Bool
  public var quaternion: [Double]?
  public var nearestSampleDeltaSeconds: Double?
  public var sourceClockDomain: String?
  public var mappingMethod: String?

  public init(
    availability: String,
    authority: String,
    referenceFrame: String,
    trueNorthClaimed: Bool,
    quaternion: [Double]? = nil,
    nearestSampleDeltaSeconds: Double? = nil,
    sourceClockDomain: String? = nil,
    mappingMethod: String? = nil
  ) {
    self.availability = availability
    self.authority = authority
    self.referenceFrame = referenceFrame
    self.trueNorthClaimed = trueNorthClaimed
    self.quaternion = quaternion
    self.nearestSampleDeltaSeconds = nearestSampleDeltaSeconds
    self.sourceClockDomain = sourceClockDomain
    self.mappingMethod = mappingMethod
  }

  public func asDictionary() -> [String: Any] {
    var d: [String: Any] = [
      "availability": availability,
      "authority": authority,
      "reference_frame": referenceFrame,
      "true_north_claimed": trueNorthClaimed,
    ]
    if let q = quaternion { d["quaternion_xyzw"] = q }
    if let delta = nearestSampleDeltaSeconds { d["nearest_sample_delta_s"] = delta }
    if let c = sourceClockDomain { d["source_clock_domain"] = c }
    if let m = mappingMethod { d["mapping_method"] = m }
    return d
  }

  public static let unavailable = MotionSampleRecord(
    availability: "NOT_AVAILABLE",
    authority: "UNKNOWN",
    referenceFrame: "NONE",
    trueNorthClaimed: false
  )
}

/// Guidance-grade motion only — never metrology.
public struct MotionSampleService: Sendable {
  public init() {}

  /// Phase 1 default: record unavailable unless a Core Motion sample is injected.
  public func sample(injected: MotionSampleRecord? = nil) -> MotionSampleRecord {
    injected ?? .unavailable
  }
}
