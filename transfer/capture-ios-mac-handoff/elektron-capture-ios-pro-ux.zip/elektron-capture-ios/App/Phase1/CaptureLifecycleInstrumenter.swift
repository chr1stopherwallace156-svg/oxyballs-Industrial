import Dispatch
import Foundation

/// Named lifecycle transitions for physical-device capture diagnosis.
/// Log first; do not treat AE/AF settling as proven root cause without these timestamps.
public enum CaptureLifecycleEvent: String, Sendable, Equatable, CaseIterable {
  case sessionStartRequested = "session_start_requested"
  case sessionRunningChanged = "session_running_changed"
  case previewAttached = "preview_attached"
  case deviceAdjustingExposure = "device_adjusting_exposure"
  case deviceAdjustingFocus = "device_adjusting_focus"
  case shutterEnabled = "shutter_enabled"
  case shutterPressed = "shutter_pressed"
  case photoDelegateReceived = "photo_delegate_received"
  case imageQualityResult = "image_quality_result"
}

public struct CaptureLifecycleRecord: Equatable, Sendable {
  public var event: CaptureLifecycleEvent
  public var timestamp: Date
  public var monotonicNanos: UInt64
  public var detail: String

  public init(event: CaptureLifecycleEvent, timestamp: Date, monotonicNanos: UInt64, detail: String) {
    self.event = event
    self.timestamp = timestamp
    self.monotonicNanos = monotonicNanos
    self.detail = detail
  }
}

/// High-resolution lifecycle log for black-frame investigation.
public final class CaptureLifecycleInstrumenter: @unchecked Sendable {
  private let lock = NSLock()
  private var records: [CaptureLifecycleRecord] = []
  private var sessionRunningNanos: UInt64?
  private var shutterEnabledNanos: UInt64?
  private var shutterPressedNanos: UInt64?

  public init() {}

  public func reset() {
    lock.lock()
    defer { lock.unlock() }
    records.removeAll(keepingCapacity: true)
    sessionRunningNanos = nil
    shutterEnabledNanos = nil
    shutterPressedNanos = nil
  }

  @discardableResult
  public func record(_ event: CaptureLifecycleEvent, detail: String = "") -> CaptureLifecycleRecord {
    let now = Date()
    let nanos = DispatchTime.now().uptimeNanoseconds
    let rec = CaptureLifecycleRecord(
      event: event,
      timestamp: now,
      monotonicNanos: nanos,
      detail: detail
    )
    lock.lock()
    records.append(rec)
    switch event {
    case .sessionRunningChanged:
      if detail.contains("true") {
        sessionRunningNanos = nanos
      }
    case .shutterEnabled:
      shutterEnabledNanos = nanos
    case .shutterPressed:
      shutterPressedNanos = nanos
    default:
      break
    }
    lock.unlock()

    let elapsedBits = elapsedSummary(at: nanos)
    Phase1CaptureDiagnostics.log(
      stage: "lifecycle",
      event: event.rawValue,
      detail: [
        "t_wall=\(ISO8601DateFormatter().string(from: now))",
        "t_mono_ns=\(nanos)",
        elapsedBits,
        detail.isEmpty ? nil : "detail=\(detail)",
      ].compactMap { $0 }.joined(separator: " ")
    )
    return rec
  }

  /// Milliseconds from session-running to shutter-enabled (nil if either missing).
  public var msSessionRunningToShutterEnabled: Double? {
    lock.lock()
    defer { lock.unlock() }
    guard let a = sessionRunningNanos, let b = shutterEnabledNanos, b >= a else { return nil }
    return Double(b - a) / 1_000_000
  }

  /// Milliseconds from shutter press to photo delegate (nil if either missing).
  public var msShutterPressToPhotoDelegate: Double? {
    lock.lock()
    defer { lock.unlock() }
    guard
      let a = shutterPressedNanos,
      let b = records.last(where: { $0.event == .photoDelegateReceived })?.monotonicNanos,
      b >= a
    else { return nil }
    return Double(b - a) / 1_000_000
  }

  public func snapshot() -> [CaptureLifecycleRecord] {
    lock.lock()
    defer { lock.unlock() }
    return records
  }

  public func summaryLine() -> String {
    let parts = [
      "ms_session_running_to_shutter_enabled=\(msSessionRunningToShutterEnabled.map { String(format: "%.3f", $0) } ?? "nil")",
      "ms_shutter_press_to_photo_delegate=\(msShutterPressToPhotoDelegate.map { String(format: "%.3f", $0) } ?? "nil")",
      "events=\(snapshot().map(\.event.rawValue).joined(separator: ","))",
    ]
    return parts.joined(separator: " ")
  }

  private func elapsedSummary(at nanos: UInt64) -> String {
    lock.lock()
    let run = sessionRunningNanos
    let enabled = shutterEnabledNanos
    let pressed = shutterPressedNanos
    lock.unlock()
    var bits: [String] = []
    if let run {
      bits.append(String(format: "ms_since_session_running=%.3f", Double(nanos &- run) / 1_000_000))
    }
    if let enabled {
      bits.append(String(format: "ms_since_shutter_enabled=%.3f", Double(nanos &- enabled) / 1_000_000))
    }
    if let pressed {
      bits.append(String(format: "ms_since_shutter_pressed=%.3f", Double(nanos &- pressed) / 1_000_000))
    }
    return bits.joined(separator: " ")
  }
}
