import Foundation

/// Minimal ZIP writer (stored entries) for `.edts-pkg` transport.
/// ZIP bytes are not the evidence identity authority.
public enum ZipPackageWriter {
  public static func writeZip(ofDirectory directory: URL, to zipURL: URL) throws {
    let fm = FileManager.default
    if fm.fileExists(atPath: zipURL.path) {
      try fm.removeItem(at: zipURL)
    }
    var files: [(name: String, data: Data)] = []
    guard let enumerator = fm.enumerator(
      at: directory,
      includingPropertiesForKeys: [.isRegularFileKey],
      options: [.skipsHiddenFiles]
    ) else {
      throw Phase1RuntimeError.packageBuildFailed("cannot enumerate package directory")
    }
    let rootPath = directory.standardizedFileURL.path
    for case let url as URL in enumerator {
      let values = try url.resourceValues(forKeys: [.isRegularFileKey])
      guard values.isRegularFile == true else { continue }
      var name = url.standardizedFileURL.path
      if name.hasPrefix(rootPath) {
        name = String(name.dropFirst(rootPath.count))
        if name.hasPrefix("/") { name = String(name.dropFirst()) }
      }
      if name.isEmpty || name.contains("..") || name.hasPrefix("/") {
        throw Phase1RuntimeError.packageBuildFailed("unsafe path: \(name)")
      }
      if name.contains("__MACOSX") || name.contains(".DS_Store") {
        continue
      }
      files.append((name: name, data: try Data(contentsOf: url)))
    }
    files.sort { $0.name < $1.name }
    try write(entries: files, to: zipURL)
  }

  public static func write(entries: [(name: String, data: Data)], to zipURL: URL) throws {
    var localParts: [Data] = []
    var centralParts: [Data] = []
    var offset: UInt32 = 0

    for entry in entries {
      let nameData = Data(entry.name.utf8)
      let crc = crc32(entry.data)
      let method: UInt16 = 0 // stored

      var local = Data()
      local.appendUInt32(0x04034b50)
      local.appendUInt16(20)
      local.appendUInt16(0)
      local.appendUInt16(method)
      local.appendUInt16(0)
      local.appendUInt16(0)
      local.appendUInt32(crc)
      local.appendUInt32(UInt32(entry.data.count))
      local.appendUInt32(UInt32(entry.data.count))
      local.appendUInt16(UInt16(nameData.count))
      local.appendUInt16(0)
      local.append(nameData)
      local.append(entry.data)
      localParts.append(local)

      var central = Data()
      central.appendUInt32(0x02014b50)
      central.appendUInt16(20)
      central.appendUInt16(20)
      central.appendUInt16(0)
      central.appendUInt16(method)
      central.appendUInt16(0)
      central.appendUInt16(0)
      central.appendUInt32(crc)
      central.appendUInt32(UInt32(entry.data.count))
      central.appendUInt32(UInt32(entry.data.count))
      central.appendUInt16(UInt16(nameData.count))
      central.appendUInt16(0)
      central.appendUInt16(0)
      central.appendUInt16(0)
      central.appendUInt16(0)
      central.appendUInt32(0)
      central.appendUInt32(offset)
      central.append(nameData)
      centralParts.append(central)

      offset += UInt32(local.count)
    }

    var out = Data()
    for p in localParts { out.append(p) }
    let centralStart = UInt32(out.count)
    for p in centralParts { out.append(p) }
    let centralSize = UInt32(out.count) - centralStart

    out.appendUInt32(0x06054b50)
    out.appendUInt16(0)
    out.appendUInt16(0)
    out.appendUInt16(UInt16(entries.count))
    out.appendUInt16(UInt16(entries.count))
    out.appendUInt32(centralSize)
    out.appendUInt32(centralStart)
    out.appendUInt16(0)

    try out.write(to: zipURL, options: .atomic)
  }

  /// IEEE CRC-32 (ZIP).
  private static func crc32(_ data: Data) -> UInt32 {
    var crc: UInt32 = 0xFFFF_FFFF
    for byte in data {
      let idx = Int((crc ^ UInt32(byte)) & 0xFF)
      crc = (crc >> 8) ^ crcTable[idx]
    }
    return crc ^ 0xFFFF_FFFF
  }

  private static let crcTable: [UInt32] = {
    (0..<256).map { i -> UInt32 in
      var c = UInt32(i)
      for _ in 0..<8 {
        c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1)
      }
      return c
    }
  }()
}

private extension Data {
  mutating func appendUInt16(_ v: UInt16) {
    var le = v.littleEndian
    Swift.withUnsafeBytes(of: &le) { append(contentsOf: $0) }
  }

  mutating func appendUInt32(_ v: UInt32) {
    var le = v.littleEndian
    Swift.withUnsafeBytes(of: &le) { append(contentsOf: $0) }
  }
}
