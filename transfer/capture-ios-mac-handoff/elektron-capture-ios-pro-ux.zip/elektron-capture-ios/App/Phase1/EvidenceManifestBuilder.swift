import Foundation

public struct Phase1CaptureIdentifiers: Equatable, Sendable {
  public var evidenceId: String
  public var sessionId: String
  public var artifactId: String
  public var recordId: String

  public init(
    evidenceId: String,
    sessionId: String,
    artifactId: String,
    recordId: String
  ) {
    self.evidenceId = evidenceId
    self.sessionId = sessionId
    self.artifactId = artifactId
    self.recordId = recordId
  }

  public static func generate() -> Phase1CaptureIdentifiers {
    let suffix = UUID().uuidString
    return Phase1CaptureIdentifiers(
      evidenceId: "EVD-\(suffix)",
      sessionId: "SESSION-\(suffix)",
      artifactId: "ART-\(suffix)",
      recordId: "REC-\(suffix)"
    )
  }
}

public struct EvidenceManifestBuilder: Sendable {
  public init() {}

  /// Builds a schema-valid EvidenceManifest 1.0.0 dictionary (no undeclared properties).
  public func build(
    ids: Phase1CaptureIdentifiers,
    artifact: PersistedArtifact,
    clock: CaptureClockSnapshot,
    provenance: CaptureDeviceProvenance,
    captureAppVersion: String
  ) throws -> [String: Any] {
    [
      "manifest_version": "1.0.0",
      "schema_id": "EvidenceManifest",
      "schema_version": "1.0.0",
      "record_id": ids.recordId,
      "session_id": ids.sessionId,
      "capture_app_version": captureAppVersion,
      "created_at_utc": clock.utcISO8601,
      "clock_domain": "wall",
      "device_profile_id": provenance.deviceProfileId,
      "capture_plan_id": NSNull(),
      "capture_identity": [
        "operator_id": "OPERATOR-DEVICE",
        "capture_installation_id": provenance.captureInstallationId,
        "device_enrollment_id": provenance.deviceEnrollmentId ?? NSNull(),
        "app_version": captureAppVersion,
        "ios_version": provenance.iosVersion,
        "approved_device_profile": provenance.deviceProfileId,
      ] as [String: Any],
      "spatial_context": [
        "tracking_state": "unavailable_phase1",
        "scene_depth_available": false,
      ] as [String: Any],
      "engineering_link": [
        "measurement_authority": "NOT_YET_VERIFIED",
      ] as [String: Any],
      "artifacts": [
        [
          "artifact_id": ids.artifactId,
          "relative_path": artifact.relativePath,
          "sha256": artifact.sha256,
          "media_type": artifact.mediaType,
          "captured_at_utc": clock.utcISO8601,
          "clock_domain": "wall",
          "coordinate_frame": "camera",
          "authority": "RAW_OBSERVATION",
          "is_original": true,
          "parent_artifact_ids": [] as [String],
        ] as [String: Any]
      ],
      "notes": [
        "Phase 1 still: APPLE_ENCODED_JPEG exact AVFoundation bytes.",
        "evidence_id=\(ids.evidenceId) (also package_id).",
        "Engineering verification NOT_PERFORMED; metrology NOT_ASSERTED.",
        "Extended Phase 1 context in package_status.json and sidecars/.",
      ],
    ]
  }
}
