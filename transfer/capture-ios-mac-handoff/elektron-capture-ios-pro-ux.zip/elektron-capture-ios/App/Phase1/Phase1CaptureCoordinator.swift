import Foundation

/// Injectable still-photo source (real AVFoundation on device; fixture in tests).
public protocol StillPhotoCaptureProviding: Sendable {
  func captureProcessedJPEG() async throws -> Data
}

/// Fixture provider for unit/integration tests — exact bytes, no re-encode path.
public struct FixtureStillPhotoCaptureService: StillPhotoCaptureProviding {
  public var jpegBytes: Data
  public init(jpegBytes: Data) {
    self.jpegBytes = jpegBytes
  }
  public func captureProcessedJPEG() async throws -> Data {
    jpegBytes
  }
}

public struct Phase1CaptureCoordinator: Sendable {
  public var appVersion: String
  public var photoCapture: any StillPhotoCaptureProviding
  public var clock: CaptureClockService
  public var provenanceService: DeviceProvenanceService
  public var motionService: MotionSampleService
  public var packageBuilder: EvidencePackageBuilder
  public var workRoot: URL
  public var qualityThresholds: CaptureImageQualityThresholds
  /// When true, run non-authoritative black-frame guard before packaging.
  /// Fixture/unit paths may disable when JPEG ImageIO decode is unavailable.
  public var enforceImageQualityGuard: Bool
  public var lifecycle: CaptureLifecycleInstrumenter?

  public init(
    appVersion: String,
    photoCapture: any StillPhotoCaptureProviding,
    workRoot: URL,
    clock: CaptureClockService = CaptureClockService(),
    provenanceService: DeviceProvenanceService? = nil,
    motionService: MotionSampleService = MotionSampleService(),
    packageBuilder: EvidencePackageBuilder = EvidencePackageBuilder(),
    qualityThresholds: CaptureImageQualityThresholds = .phase1Default,
    enforceImageQualityGuard: Bool = false,
    lifecycle: CaptureLifecycleInstrumenter? = nil
  ) {
    self.appVersion = appVersion
    self.photoCapture = photoCapture
    self.workRoot = workRoot
    self.clock = clock
    self.provenanceService = provenanceService ?? DeviceProvenanceService(appVersion: appVersion)
    self.motionService = motionService
    self.packageBuilder = packageBuilder
    self.qualityThresholds = qualityThresholds
    self.enforceImageQualityGuard = enforceImageQualityGuard
    self.lifecycle = lifecycle
  }

  /// Full Phase 1 pipeline to PACKAGE_EXPORTED. Does not assign EDTS statuses.
  public func captureAndExport(
    ids: Phase1CaptureIdentifiers = .generate(),
    motionInjected: MotionSampleRecord? = nil,
    hardwareModelOverride: String? = nil,
    iosVersionOverride: String? = nil,
    defaults: UserDefaults = .standard
  ) async throws -> Phase1PackageResult {
    let jpeg: Data
    do {
      jpeg = try await photoCapture.captureProcessedJPEG()
      Phase1CaptureDiagnostics.log(
        stage: "photo_bytes",
        event: "received",
        detail: "byteCount=\(jpeg.count) empty=\(jpeg.isEmpty)"
      )
    } catch let e as Phase1RuntimeError {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture",
        event: "failed",
        detail: "reason=\(e.reasonCode) detail=\(e.detailMessage)"
      )
      throw e
    } catch {
      throw Phase1RuntimeError.photoCaptureFailed(String(describing: error))
    }
    return try exportCapturedJPEG(
      jpeg,
      ids: ids,
      motionInjected: motionInjected,
      hardwareModelOverride: hardwareModelOverride,
      iosVersionOverride: iosVersionOverride,
      defaults: defaults
    )
  }

  /// Export path for interactive shutter: exact post-delegate JPEG bytes in, package out.
  /// Asserts artifact hash invariance vs SHA-256 computed immediately after capture.
  public func exportCapturedJPEG(
    _ jpeg: Data,
    ids: Phase1CaptureIdentifiers = .generate(),
    motionInjected: MotionSampleRecord? = nil,
    hardwareModelOverride: String? = nil,
    iosVersionOverride: String? = nil,
    defaults: UserDefaults = .standard,
    skipQualityGuard: Bool? = nil,
    shotMetadata: StillCaptureShotMetadata? = nil
  ) throws -> Phase1PackageResult {
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureCreated.rawValue)

    guard !jpeg.isEmpty else {
      throw Phase1RuntimeError.fileRepresentationUnavailable
    }

    let postDelegateHash = ArtifactHashingService().sha256HexOfData(jpeg)
    Phase1CaptureDiagnostics.log(
      stage: "artifact_hash",
      event: "post_delegate",
      detail: "sha256=\(postDelegateHash) byteCount=\(jpeg.count)"
    )

    let runGuard = skipQualityGuard.map { !$0 } ?? enforceImageQualityGuard
    if runGuard {
      try applyQualityGuard(to: jpeg)
    }

    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.capturePersisted.rawValue)
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureHashed.rawValue)
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureSealed.rawValue)

    let clockSnap = clock.snapshot()
    var provenance = provenanceService.currentProvenance(
      defaults: defaults,
      hardwareModelOverride: hardwareModelOverride,
      iosVersionOverride: iosVersionOverride
    )
    if let shotMetadata {
      if let cam = shotMetadata.physicalCameraUniqueID {
        provenance.cameraProfileId = cam
      }
      provenance.cameraPosition = "back"
      if let lens = shotMetadata.physicalCameraType {
        provenance.lensProfileId = lens
        provenance.lensDisplayName = lens
      }
      var notes = provenance.notes
      if let z = shotMetadata.videoZoomFactor {
        notes.append("video_zoom_factor=\(z)")
      }
      provenance.notes = notes
    }
    let motion = motionService.sample(injected: motionInjected)

    let result = try packageBuilder.build(
      jpegBytes: jpeg,
      ids: ids,
      clock: clockSnap,
      provenance: provenance,
      motion: motion,
      calibrationAvailability: .notAvailable,
      workRoot: workRoot,
      captureAppVersion: appVersion,
      previousStatus: .captureSealed,
      shotMetadata: shotMetadata
    )

    // Strict artifact hash invariance: exported artifact SHA-256 == post-delegate hash.
    if result.artifactSha256 != postDelegateHash {
      throw Phase1RuntimeError.hashReadbackMismatch(
        expected: postDelegateHash,
        actual: result.artifactSha256
      )
    }
    Phase1CaptureDiagnostics.log(
      stage: "artifact_hash",
      event: "invariance_ok",
      detail: "sha256=\(result.artifactSha256)"
    )
    return result
  }

  private func applyQualityGuard(to jpeg: Data) throws {
    #if canImport(ImageIO)
    let verdict = try CaptureImageQualityGuard.evaluateJPEGInspection(
      jpeg,
      thresholds: qualityThresholds
    )
    let m = verdict.metrics
    let detail =
      "mean=\(String(format: "%.3f", m.meanLuminance)) nearBlackFraction=\(String(format: "%.4f", m.nearBlackFraction)) samples=\(m.sampleCount) black=\(verdict.isEffectivelyBlack)"
    lifecycle?.record(.imageQualityResult, detail: detail)
    Phase1CaptureDiagnostics.log(stage: "image_quality", event: "result", detail: detail)
    if case .effectivelyBlack(let metrics) = verdict {
      throw Phase1RuntimeError.captureQualityImageEffectivelyBlack(
        "mean_luminance=\(String(format: "%.3f", metrics.meanLuminance)) near_black_fraction=\(String(format: "%.4f", metrics.nearBlackFraction)) thresholds=mean<=\(qualityThresholds.maxMeanLuminance)&&nearBlack>=\(qualityThresholds.minNearBlackFraction)"
      )
    }
    #else
    Phase1CaptureDiagnostics.log(
      stage: "image_quality",
      event: "skipped_no_imageio",
      detail: "JPEG inspection unavailable on this platform"
    )
    #endif
  }
}
