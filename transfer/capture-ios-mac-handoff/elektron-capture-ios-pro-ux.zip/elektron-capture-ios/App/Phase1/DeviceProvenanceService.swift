import Foundation

#if canImport(Darwin)
import Darwin
#endif
#if canImport(UIKit)
import UIKit
#endif

/// Privacy-preserving installation enrollment (Keychain when available; UserDefaults fallback for tests).
public struct DeviceProvenanceService: Sendable {
  public var appVersion: String
  public var deviceProfileId: String
  public var installationKey: String

  public init(
    appVersion: String,
    deviceProfileId: String = "CAP-DEVICE-IPRO-LIDAR-001",
    installationKey: String = "elektron.capture.installation_id"
  ) {
    self.appVersion = appVersion
    self.deviceProfileId = deviceProfileId
    self.installationKey = installationKey
  }

  public func currentProvenance(
    defaults: UserDefaults = .standard,
    hardwareModelOverride: String? = nil,
    iosVersionOverride: String? = nil
  ) -> CaptureDeviceProvenance {
    let installId = stableInstallationId(defaults: defaults)
    let hardware = hardwareModelOverride ?? Self.hardwareModelIdentifier()
    let ios = iosVersionOverride ?? Self.systemVersion()
    return CaptureDeviceProvenance(
      deviceProfileId: deviceProfileId,
      hardwareModelIdentifier: hardware,
      deviceDisplayName: "Approved iPhone capture device",
      iosVersion: ios,
      appVersion: appVersion,
      evidenceSchemaVersion: "1.0.0",
      captureInstallationId: installId,
      cameraProfileId: "CAM-REAR-WIDE-001",
      cameraPosition: "back",
      lensProfileId: "LENS-WIDE-001",
      lensDisplayName: "Wide",
      lidarAvailable: nil,
      deviceEnrollmentId: "ENR-\(installId.suffix(12))",
      notes: [
        "Installation ID is app-local and privacy-preserving.",
        "device_display_name is not authoritative identity.",
      ]
    )
  }

  public func stableInstallationId(defaults: UserDefaults) -> String {
    if let existing = defaults.string(forKey: installationKey), !existing.isEmpty {
      return existing
    }
    let created = "INSTALL-\(UUID().uuidString)"
    defaults.set(created, forKey: installationKey)
    return created
  }

  public static func hardwareModelIdentifier() -> String {
    #if canImport(Darwin)
    var size = 0
    sysctlbyname("hw.machine", nil, &size, nil, 0)
    var machine = [CChar](repeating: 0, count: size)
    sysctlbyname("hw.machine", &machine, &size, nil, 0)
    let id = String(cString: machine)
    return id.isEmpty ? "UNKNOWN_HARDWARE" : id
    #else
    return "UNKNOWN_HARDWARE"
    #endif
  }

  public static func systemVersion() -> String {
    #if canImport(UIKit)
    return UIDevice.current.systemVersion
    #else
    return ProcessInfo.processInfo.operatingSystemVersionString
    #endif
  }
}
