import Foundation

public struct PackageInventoryBuilder: Sendable {
  public var hasher: ArtifactHashingService

  public init(hasher: ArtifactHashingService = ArtifactHashingService()) {
    self.hasher = hasher
  }

  /// Phase 1 self-hash policy: omit `package_inventory.json` from entries.
  public func build(
    packageId: String,
    files: [(path: String, url: URL)]
  ) throws -> [String: Any] {
    var entries: [[String: Any]] = []
    for file in files.sorted(by: { $0.path < $1.path }) {
      if file.path == "package_inventory.json" {
        throw Phase1RuntimeError.inventoryBuildFailed("inventory must not list itself")
      }
      let attrs: [FileAttributeKey: Any]
      do {
        attrs = try FileManager.default.attributesOfItem(atPath: file.url.path)
      } catch {
        throw Phase1RuntimeError.inventoryBuildFailed(String(describing: error))
      }
      let size = (attrs[.size] as? NSNumber)?.intValue ?? -1
      let digest: String
      do {
        digest = try hasher.sha256HexOfFile(at: file.url)
      } catch let e as Phase1RuntimeError {
        throw e
      } catch {
        throw Phase1RuntimeError.inventoryBuildFailed(String(describing: error))
      }
      entries.append([
        "path": file.path,
        "byte_size": size,
        "sha256": digest,
      ])
    }
    guard !entries.isEmpty else {
      throw Phase1RuntimeError.inventoryBuildFailed("empty inventory")
    }
    return [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_format_version": "1.0.0",
      "package_id": packageId,
      "entries": entries,
      "notes": [
        "Phase 1: package_inventory.json omitted from entries (self-hash policy).",
        "ZIP is transport only; integrity = entry hashes.",
        "package_seal: NOT_IMPLEMENTED",
      ],
    ]
  }
}
