import Foundation

/// Capture-side validation only. Never claims XREPO-0001/0002 PASS.
public struct CaptureSideValidationResult: Equatable, Sendable {
  public var ok: Bool
  public var reasonCodes: [String]
  public var packagePath: String?
  public var artifactSha256: String?
  public var notes: [String]

  public init(
    ok: Bool,
    reasonCodes: [String] = [],
    packagePath: String? = nil,
    artifactSha256: String? = nil,
    notes: [String] = []
  ) {
    self.ok = ok
    self.reasonCodes = reasonCodes
    self.packagePath = packagePath
    self.artifactSha256 = artifactSha256
    self.notes = notes
  }
}

public enum CaptureSidePackageValidator {
  /// Validates local package directory: required files, inventory hashes, capture-only status.
  public static func validate(packageDirectory: URL) -> CaptureSideValidationResult {
    var codes: [String] = []
    let required = [
      "manifest.json",
      "package_inventory.json",
      "payload/artifact_original.jpg",
      "package_status.json",
      "capture_device.json",
    ]
    for rel in required {
      if !FileManager.default.fileExists(atPath: packageDirectory.appendingPathComponent(rel).path) {
        codes.append("MISSING_\(rel.uppercased().replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: ".", with: "_"))")
      }
    }
    guard codes.isEmpty else {
      return CaptureSideValidationResult(ok: false, reasonCodes: codes, packagePath: packageDirectory.path)
    }

    do {
      let invData = try Data(contentsOf: packageDirectory.appendingPathComponent("package_inventory.json"))
      let invObj = try JSONSerialization.jsonObject(with: invData) as? [String: Any]
      let entries = invObj?["entries"] as? [[String: Any]] ?? []
      let hasher = ArtifactHashingService()
      var declared = Set<String>()
      for entry in entries {
        guard let path = entry["path"] as? String,
              let expected = entry["sha256"] as? String
        else {
          codes.append("INVENTORY_ENTRY_INVALID")
          continue
        }
        // Darwin JSONSerialization yields NSNumber; Linux may yield Int — accept both.
        let size: Int?
        if let i = entry["byte_size"] as? Int {
          size = i
        } else if let n = entry["byte_size"] as? NSNumber {
          size = n.intValue
        } else {
          size = nil
        }
        guard let size else {
          codes.append("INVENTORY_ENTRY_INVALID")
          continue
        }
        declared.insert(path)
        let url = packageDirectory.appendingPathComponent(path)
        guard FileManager.default.fileExists(atPath: url.path) else {
          codes.append("INVENTORY_DECLARED_PATH_MISSING")
          continue
        }
        let actual = try hasher.sha256HexOfFile(at: url)
        let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
        let actualSize = (attrs[.size] as? NSNumber)?.intValue ?? -1
        if actual != expected || actualSize != size {
          codes.append("HASH_READBACK_MISMATCH")
        }
      }
      if declared.contains("package_inventory.json") {
        codes.append("INVENTORY_SELF_HASH_POLICY_VIOLATION")
      }

      // Every on-disk regular file (except inventory itself) must be declared.
      if let en = FileManager.default.enumerator(
        at: packageDirectory,
        includingPropertiesForKeys: [.isRegularFileKey],
        options: [.skipsHiddenFiles]
      ) {
        let root = packageDirectory.standardizedFileURL.path
        for case let url as URL in en {
          let vals = try url.resourceValues(forKeys: [.isRegularFileKey])
          guard vals.isRegularFile == true else { continue }
          var rel = url.standardizedFileURL.path
          if rel.hasPrefix(root) {
            rel = String(rel.dropFirst(root.count))
            if rel.hasPrefix("/") { rel = String(rel.dropFirst()) }
          }
          if rel == "package_inventory.json" { continue }
          if !declared.contains(rel) {
            codes.append("INVENTORY_UNDECLARED_PATH")
          }
        }
      }

      let statusData = try Data(contentsOf: packageDirectory.appendingPathComponent("package_status.json"))
      let statusObj = try JSONSerialization.jsonObject(with: statusData) as? [String: Any]
      var asserted = statusObj?["asserted_statuses"] as? [String] ?? []
      if let single = statusObj?["capture_side_status"] as? String {
        asserted.append(single)
      }
      for code in Set(asserted) {
        _ = try CaptureSideStatusGuard.parseCaptureSide(code)
      }

      let artHash = try hasher.sha256HexOfFile(
        at: packageDirectory.appendingPathComponent("payload/artifact_original.jpg")
      )
      return CaptureSideValidationResult(
        ok: codes.isEmpty,
        reasonCodes: codes,
        packagePath: packageDirectory.path,
        artifactSha256: artHash,
        notes: [
          "Capture-side validation only.",
          "EDTS XREPO-0001/0002 must be assigned by the EDTS importer — never by this app.",
        ]
      )
    } catch let e as CaptureError {
      return CaptureSideValidationResult(
        ok: false,
        reasonCodes: ["STATUS_AUTHORITY_VIOLATION"],
        packagePath: packageDirectory.path,
        notes: [String(describing: e)]
      )
    } catch {
      return CaptureSideValidationResult(
        ok: false,
        reasonCodes: ["CAPTURE_SIDE_VALIDATION_FAILED"],
        packagePath: packageDirectory.path,
        notes: [String(describing: error)]
      )
    }
  }
}
