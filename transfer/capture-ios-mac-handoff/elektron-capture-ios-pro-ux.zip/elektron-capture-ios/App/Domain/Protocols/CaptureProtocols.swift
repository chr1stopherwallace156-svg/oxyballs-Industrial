import Foundation

public protocol EDTSClient: Sendable {
  func fetchCapturePlan(planId: String) async throws -> CapturePlanDTO
  func submitEvidencePackage(directoryURL: URL) async throws -> EDTSIntakeStatus
}

public protocol CapturePlanProviding: Sendable {
  func loadPlan(planId: String) async throws -> CapturePlanDTO
}

public protocol EvidenceExporting: Sendable {
  func exportPackage(
    session: LocalCaptureSession,
    artifacts: [LocalArtifactRef],
    to directory: URL,
    captureAppVersion: String
  ) async throws -> URL
}

public protocol AttestationVerifying: Sendable {
  func verifySession(sessionId: String) async throws -> Bool
}

public protocol ArtifactStoring: Sendable {
  func writeImmutable(data: Data, to relativePath: String, under root: URL) throws -> String
}

/// Framework isolation — Phase 1+ adapters implement these without leaking Apple types.
public protocol CameraCaptureProvider: Sendable {
  var isMock: Bool { get }
}

public protocol SpatialTrackingProvider: Sendable {
  var isMock: Bool { get }
}

public protocol MotionSampleProvider: Sendable {
  var isMock: Bool { get }
}

public protocol DepthProvider: Sendable {
  var isMock: Bool { get }
}

public protocol CryptographicSigningProvider: Sendable {
  func sha256Hex(_ data: Data) -> String
}

public protocol AttestationProvider: Sendable {
  var isMock: Bool { get }
}

public protocol EvidenceStore: Sendable {
  func rootURL(forSessionId sessionId: String) throws -> URL
}

public protocol EvidenceUploadClient: Sendable {
  func enqueue(packageDirectory: URL) async throws
}

public struct MockCameraCaptureProvider: CameraCaptureProvider {
  public var isMock: Bool { true }
  public init() {}
}

public struct MockSpatialTrackingProvider: SpatialTrackingProvider {
  public var isMock: Bool { true }
  public init() {}
}

public struct MockMotionSampleProvider: MotionSampleProvider {
  public var isMock: Bool { true }
  public init() {}
}

public struct MockDepthProvider: DepthProvider {
  public var isMock: Bool { true }
  public init() {}
}

public struct CryptoKitHashingProvider: CryptographicSigningProvider {
  public init() {}
  public func sha256Hex(_ data: Data) -> String {
    ContentHasher.sha256Hex(data)
  }
}

public struct MockAttestationProvider: AttestationProvider {
  public var isMock: Bool { true }
  public init() {}
}
