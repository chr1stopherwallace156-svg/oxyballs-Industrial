import Foundation

public struct CapturePlanDTO: Equatable, Sendable, Codable {
  public var schemaId: String
  public var schemaVersion: String
  public var planId: String
  public var title: String
  public var targetConfigurationId: String?
  public var requirements: [CaptureRequirementDTO]

  enum CodingKeys: String, CodingKey {
    case schemaId = "schema_id"
    case schemaVersion = "schema_version"
    case planId = "plan_id"
    case title
    case targetConfigurationId = "target_configuration_id"
    case requirements
  }
}

public struct CaptureRequirementDTO: Equatable, Sendable, Codable {
  public var requirementId: String
  public var description: String
  public var artifactKind: String
  public var mandatory: Bool?
  public var targetComponent: String?
  public var requiredViewpoint: String?
  public var minImageCount: Int?
  public var depthRequired: Bool?
  public var scaleAnchorRequired: Bool?
  public var blocking: Bool?

  enum CodingKeys: String, CodingKey {
    case requirementId = "requirement_id"
    case description
    case artifactKind = "artifact_kind"
    case mandatory
    case targetComponent = "target_component"
    case requiredViewpoint = "required_viewpoint"
    case minImageCount = "min_image_count"
    case depthRequired = "depth_required"
    case scaleAnchorRequired = "scale_anchor_required"
    case blocking
  }
}

/// Versioned contract shape for export (maps from LocalCaptureSession).
public struct CaptureSessionContractV1: Equatable, Sendable, Codable {
  public var schemaId: String = "CaptureSessionContract"
  public var schemaVersion: String = "1.0.0"
  public var sessionId: String
  public var state: String
  public var planId: String?
  public var vehicleId: String?
  public var vehicleIdentityStatus: String
  public var captureAppVersion: String
  public var createdAtUtc: String
  public var clockDomain: String

  enum CodingKeys: String, CodingKey {
    case schemaId = "schema_id"
    case schemaVersion = "schema_version"
    case sessionId = "session_id"
    case state
    case planId = "plan_id"
    case vehicleId = "vehicle_id"
    case vehicleIdentityStatus = "vehicle_identity_status"
    case captureAppVersion = "capture_app_version"
    case createdAtUtc = "created_at_utc"
    case clockDomain = "clock_domain"
  }
}
