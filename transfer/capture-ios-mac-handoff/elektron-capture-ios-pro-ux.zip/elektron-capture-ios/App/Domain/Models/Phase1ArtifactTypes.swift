import Foundation

/// Phase 1 artifact representation — never conflate JPEG/HEIF with RAW.
public enum ArtifactRepresentation: String, Codable, Sendable, CaseIterable {
  case appleEncodedJpeg = "APPLE_ENCODED_JPEG"
  case appleEncodedHeif = "APPLE_ENCODED_HEIF"
  case appleRaw = "APPLE_RAW" // Out of Phase 1 unless explicitly scoped
}

public enum ArtifactRole: String, Codable, Sendable {
  case originalCaptureOutput = "ORIGINAL_CAPTURE_OUTPUT"
}

public enum PixelProcessingClaim: String, Codable, Sendable {
  case notAsserted = "NOT_ASSERTED"
}

public enum CameraCalibrationAvailability: String, Codable, Sendable, CaseIterable {
  case appleReported = "APPLE_REPORTED"
  case notAvailable = "NOT_AVAILABLE"
  case unsupportedCaptureConfiguration = "UNSUPPORTED_CAPTURE_CONFIGURATION"
  case extractionFailed = "EXTRACTION_FAILED"
}

public enum EdtsIngestionStatus: String, Codable, Sendable, CaseIterable {
  case received = "RECEIVED"
  case quarantined = "QUARANTINED"
  case validating = "VALIDATING"
  case rejected = "REJECTED"
  case verifiedTransportIntegrity = "VERIFIED_TRANSPORT_INTEGRITY"
  case committedUnverifiedEvidence = "COMMITTED_UNVERIFIED_EVIDENCE"
  case ingestedIntegrityVerified = "INGESTED_INTEGRITY_VERIFIED"
}

public enum ContentVerificationStatus: String, Codable, Sendable {
  case contentUnverified = "CONTENT_UNVERIFIED"
  case notApplicable = "NOT_APPLICABLE"
}
