import Foundation

/// Local capture session — app domain model (not an EDTS persistence row).
public struct LocalCaptureSession: Equatable, Sendable {
  public var sessionId: String
  public var state: CaptureSessionState
  public var planId: String?
  public var vehicleId: String?
  public var vehicleIdentityStatus: VehicleIdentityStatus
  public var createdAt: Date
  public var clockDomain: String
  public var deviceProfileId: String?
  public var installationId: String?
  public var operatorId: String?
  public var artifactIds: [String]
  public var transitions: [SessionTransition]

  public init(
    sessionId: String,
    state: CaptureSessionState = .created,
    planId: String? = nil,
    vehicleId: String? = nil,
    vehicleIdentityStatus: VehicleIdentityStatus = .unresolved,
    createdAt: Date = Date(),
    clockDomain: String = "wall",
    deviceProfileId: String? = nil,
    installationId: String? = nil,
    operatorId: String? = nil,
    artifactIds: [String] = [],
    transitions: [SessionTransition] = []
  ) {
    self.sessionId = sessionId
    self.state = state
    self.planId = planId
    self.vehicleId = vehicleId
    self.vehicleIdentityStatus = vehicleIdentityStatus
    self.createdAt = createdAt
    self.clockDomain = clockDomain
    self.deviceProfileId = deviceProfileId
    self.installationId = installationId
    self.operatorId = operatorId
    self.artifactIds = artifactIds
    self.transitions = transitions
  }
}

public struct LocalArtifactRef: Equatable, Sendable {
  public var artifactId: String
  public var relativePath: String
  public var sha256: String
  public var mediaType: String
  public var capturedAt: Date
  public var clockDomain: String
  public var coordinateFrame: String?
  public var authority: EvidenceAuthority
  public var isOriginal: Bool
  public var parentArtifactIds: [String]

  public init(
    artifactId: String,
    relativePath: String,
    sha256: String,
    mediaType: String,
    capturedAt: Date,
    clockDomain: String,
    coordinateFrame: String? = nil,
    authority: EvidenceAuthority = .rawObservation,
    isOriginal: Bool = true,
    parentArtifactIds: [String] = []
  ) {
    self.artifactId = artifactId
    self.relativePath = relativePath
    self.sha256 = sha256
    self.mediaType = mediaType
    self.capturedAt = capturedAt
    self.clockDomain = clockDomain
    self.coordinateFrame = coordinateFrame
    self.authority = authority
    self.isOriginal = isOriginal
    self.parentArtifactIds = parentArtifactIds
  }
}

public struct ApprovedDeviceProfile: Equatable, Sendable, Codable {
  public var profileId: String
  public var commercialModel: String
  public var supportedIOSVersions: String
  public var approvedRearCamera: String
  public var lidarAvailable: Bool
  public var approvedAppVersion: String
  public var calibrationProfileId: String?
  public var approvalStatus: String

  public init(
    profileId: String,
    commercialModel: String,
    supportedIOSVersions: String,
    approvedRearCamera: String,
    lidarAvailable: Bool,
    approvedAppVersion: String,
    calibrationProfileId: String? = nil,
    approvalStatus: String
  ) {
    self.profileId = profileId
    self.commercialModel = commercialModel
    self.supportedIOSVersions = supportedIOSVersions
    self.approvedRearCamera = approvedRearCamera
    self.lidarAvailable = lidarAvailable
    self.approvedAppVersion = approvedAppVersion
    self.calibrationProfileId = calibrationProfileId
    self.approvalStatus = approvalStatus
  }
}

public struct CameraCalibrationProfile: Equatable, Sendable, Codable {
  public var profileID: String
  public var deviceModel: String
  public var cameraUniqueID: String
  public var imageWidth: Int
  public var imageHeight: Int
  public var intrinsicMatrix: [Float]
  public var intrinsicReferenceWidth: Int
  public var intrinsicReferenceHeight: Int
  public var lensDistortionCenter: [Float]
  public var radialDistortionLookupTable: [Float]?
  public var inverseRadialDistortionLookupTable: [Float]?
  public var source: CalibrationSource
  public var validatedAt: Date?
  public var validationResidualMM: Double?
  public var authority: EvidenceAuthority

  public init(
    profileID: String,
    deviceModel: String,
    cameraUniqueID: String,
    imageWidth: Int,
    imageHeight: Int,
    intrinsicMatrix: [Float],
    intrinsicReferenceWidth: Int,
    intrinsicReferenceHeight: Int,
    lensDistortionCenter: [Float],
    radialDistortionLookupTable: [Float]? = nil,
    inverseRadialDistortionLookupTable: [Float]? = nil,
    source: CalibrationSource,
    validatedAt: Date? = nil,
    validationResidualMM: Double? = nil,
    authority: EvidenceAuthority = .deviceReported
  ) {
    self.profileID = profileID
    self.deviceModel = deviceModel
    self.cameraUniqueID = cameraUniqueID
    self.imageWidth = imageWidth
    self.imageHeight = imageHeight
    self.intrinsicMatrix = intrinsicMatrix
    self.intrinsicReferenceWidth = intrinsicReferenceWidth
    self.intrinsicReferenceHeight = intrinsicReferenceHeight
    self.lensDistortionCenter = lensDistortionCenter
    self.radialDistortionLookupTable = radialDistortionLookupTable
    self.inverseRadialDistortionLookupTable = inverseRadialDistortionLookupTable
    self.source = source
    self.validatedAt = validatedAt
    self.validationResidualMM = validationResidualMM
    self.authority = authority
  }
}

public struct MotionSampleWindow: Equatable, Sendable, Codable {
  public var captureTimestamp: TimestampValue
  public var start: TimestampValue
  public var end: TimestampValue
  public var sampleCount: Int
  public var authority: EvidenceAuthority

  public init(
    captureTimestamp: TimestampValue,
    start: TimestampValue,
    end: TimestampValue,
    sampleCount: Int,
    authority: EvidenceAuthority = .rawObservation
  ) {
    self.captureTimestamp = captureTimestamp
    self.start = start
    self.end = end
    self.sampleCount = sampleCount
    self.authority = authority
  }
}

public struct SpatialPose: Equatable, Sendable, Codable {
  public var transformId: String
  public var sourceFrame: String
  public var targetFrame: String
  public var matrixLayout: String
  public var handedness: String
  public var translationUnit: String
  public var values: [Double]
  public var timestamp: TimestampValue
  public var authority: EvidenceAuthority
  public var trackingState: String?

  public init(
    transformId: String,
    sourceFrame: String,
    targetFrame: String,
    matrixLayout: String = "column_major",
    handedness: String = "right_handed",
    translationUnit: String = "meter",
    values: [Double],
    timestamp: TimestampValue,
    authority: EvidenceAuthority = .guidanceEstimate,
    trackingState: String? = nil
  ) {
    self.transformId = transformId
    self.sourceFrame = sourceFrame
    self.targetFrame = targetFrame
    self.matrixLayout = matrixLayout
    self.handedness = handedness
    self.translationUnit = translationUnit
    self.values = values
    self.timestamp = timestamp
    self.authority = authority
    self.trackingState = trackingState
  }
}
