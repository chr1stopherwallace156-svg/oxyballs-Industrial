import Foundation

/// Long-lived capture-device provenance for evidence packages.
/// Authoritative identity = stable machine-readable IDs (profile, hardware model, lens, enrollment).
/// `device_display_name` is UI-only — never use technician-renamed phone names as identity.
/// Do not store raw serial numbers or unrelated personal device identifiers unless reviewed.
public struct CaptureDeviceProvenance: Equatable, Sendable, Codable {
  public var schemaId: String = "CaptureDeviceProvenance"
  public var schemaVersion: String = "1.0.0"
  public var deviceProfileId: String
  public var hardwareModelIdentifier: String
  public var deviceDisplayName: String
  public var iosVersion: String
  public var cameraProfileId: String?
  public var cameraPosition: String?
  public var lensProfileId: String?
  public var lensDisplayName: String?
  public var lidarAvailable: Bool?
  public var calibrationProfileId: String?
  public var calibrationVersion: String?
  public var appVersion: String
  public var evidenceSchemaVersion: String
  public var capturePlanSchemaVersion: String?
  public var portablePackageVersion: String?
  public var captureInstallationId: String
  public var deviceEnrollmentId: String?
  public var appAttestKeyId: String?
  public var notes: [String]

  enum CodingKeys: String, CodingKey {
    case schemaId = "schema_id"
    case schemaVersion = "schema_version"
    case deviceProfileId = "device_profile_id"
    case hardwareModelIdentifier = "hardware_model_identifier"
    case deviceDisplayName = "device_display_name"
    case iosVersion = "ios_version"
    case cameraProfileId = "camera_profile_id"
    case cameraPosition = "camera_position"
    case lensProfileId = "lens_profile_id"
    case lensDisplayName = "lens_display_name"
    case lidarAvailable = "lidar_available"
    case calibrationProfileId = "calibration_profile_id"
    case calibrationVersion = "calibration_version"
    case appVersion = "app_version"
    case evidenceSchemaVersion = "evidence_schema_version"
    case capturePlanSchemaVersion = "capture_plan_schema_version"
    case portablePackageVersion = "portable_package_version"
    case captureInstallationId = "capture_installation_id"
    case deviceEnrollmentId = "device_enrollment_id"
    case appAttestKeyId = "app_attest_key_id"
    case notes
  }

  public init(
    deviceProfileId: String,
    hardwareModelIdentifier: String,
    deviceDisplayName: String,
    iosVersion: String,
    appVersion: String,
    evidenceSchemaVersion: String,
    captureInstallationId: String,
    cameraProfileId: String? = nil,
    cameraPosition: String? = nil,
    lensProfileId: String? = nil,
    lensDisplayName: String? = nil,
    lidarAvailable: Bool? = nil,
    calibrationProfileId: String? = nil,
    calibrationVersion: String? = nil,
    capturePlanSchemaVersion: String? = "1.0.0",
    portablePackageVersion: String? = "1.0.0",
    deviceEnrollmentId: String? = nil,
    appAttestKeyId: String? = nil,
    notes: [String] = []
  ) {
    self.deviceProfileId = deviceProfileId
    self.hardwareModelIdentifier = hardwareModelIdentifier
    self.deviceDisplayName = deviceDisplayName
    self.iosVersion = iosVersion
    self.cameraProfileId = cameraProfileId
    self.cameraPosition = cameraPosition
    self.lensProfileId = lensProfileId
    self.lensDisplayName = lensDisplayName
    self.lidarAvailable = lidarAvailable
    self.calibrationProfileId = calibrationProfileId
    self.calibrationVersion = calibrationVersion
    self.appVersion = appVersion
    self.evidenceSchemaVersion = evidenceSchemaVersion
    self.capturePlanSchemaVersion = capturePlanSchemaVersion
    self.portablePackageVersion = portablePackageVersion
    self.captureInstallationId = captureInstallationId
    self.deviceEnrollmentId = deviceEnrollmentId
    self.appAttestKeyId = appAttestKeyId
    self.notes = notes
  }

  public func asDictionary() -> [String: Any] {
    // Never box Optional.none as Any — CanonicalJSON / JSONSerialization reject it.
    // Use NSNull() for absent optional fields so physical-device payloads stay JSON-safe.
    [
      "schema_id": schemaId,
      "schema_version": schemaVersion,
      "device_profile_id": deviceProfileId,
      "hardware_model_identifier": hardwareModelIdentifier,
      "device_display_name": deviceDisplayName,
      "ios_version": iosVersion,
      "app_version": appVersion,
      "evidence_schema_version": evidenceSchemaVersion,
      "capture_installation_id": captureInstallationId,
      "notes": notes,
      "camera_profile_id": cameraProfileId ?? NSNull(),
      "camera_position": cameraPosition ?? NSNull(),
      "lens_profile_id": lensProfileId ?? NSNull(),
      "lens_display_name": lensDisplayName ?? NSNull(),
      "lidar_available": lidarAvailable ?? NSNull(),
      "calibration_profile_id": calibrationProfileId ?? NSNull(),
      "calibration_version": calibrationVersion ?? NSNull(),
      "capture_plan_schema_version": capturePlanSchemaVersion ?? NSNull(),
      "portable_package_version": portablePackageVersion ?? NSNull(),
      "device_enrollment_id": deviceEnrollmentId ?? NSNull(),
      "app_attest_key_id": appAttestKeyId ?? NSNull(),
    ]
  }
}
