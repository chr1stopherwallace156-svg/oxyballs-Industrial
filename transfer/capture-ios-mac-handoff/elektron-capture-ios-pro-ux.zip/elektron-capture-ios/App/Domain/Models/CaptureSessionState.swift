import Foundation

/// Deterministic capture-session lifecycle. UI must not invent parallel Boolean state.
public enum CaptureSessionState: String, Codable, Sendable, CaseIterable {
  case created = "CREATED"
  case deviceCheck = "DEVICE_CHECK"
  case vehicleIdentityPending = "VEHICLE_IDENTITY_PENDING"
  case vehicleIdentityConfirmed = "VEHICLE_IDENTITY_CONFIRMED"
  case calibrationCheck = "CALIBRATION_CHECK"
  case capturePlanReady = "CAPTURE_PLAN_READY"
  case capturing = "CAPTURING"
  case paused = "PAUSED"
  case qualityReview = "QUALITY_REVIEW"
  case technicianReview = "TECHNICIAN_REVIEW"
  case readyForSealing = "READY_FOR_SEALING"
  case sealed = "SEALED"
  case uploadPending = "UPLOAD_PENDING"
  case uploading = "UPLOADING"
  case uploaded = "UPLOADED"
  case serverVerified = "SERVER_VERIFIED"
  case rejected = "REJECTED"
  case recoveryRequired = "RECOVERY_REQUIRED"
  case cancelled = "CANCELLED"
}

public struct SessionTransition: Equatable, Sendable, Codable {
  public var from: CaptureSessionState
  public var to: CaptureSessionState
  public var actorId: String
  public var reason: String
  public var at: TimestampValue
  public var softwareVersion: String

  public init(
    from: CaptureSessionState,
    to: CaptureSessionState,
    actorId: String,
    reason: String,
    at: TimestampValue,
    softwareVersion: String
  ) {
    self.from = from
    self.to = to
    self.actorId = actorId
    self.reason = reason
    self.at = at
    self.softwareVersion = softwareVersion
  }
}

public enum CaptureSessionStateMachine {
  /// Allowed edges for Phase 0 documentation/enforcement scaffold.
  public static let allowedTransitions: [(CaptureSessionState, CaptureSessionState)] = [
    (.created, .deviceCheck),
    (.deviceCheck, .vehicleIdentityPending),
    (.deviceCheck, .rejected),
    (.deviceCheck, .cancelled),
    (.vehicleIdentityPending, .vehicleIdentityConfirmed),
    (.vehicleIdentityPending, .cancelled),
    (.vehicleIdentityConfirmed, .calibrationCheck),
    (.calibrationCheck, .capturePlanReady),
    (.calibrationCheck, .rejected),
    (.capturePlanReady, .capturing),
    (.capturing, .paused),
    (.paused, .capturing),
    (.capturing, .qualityReview),
    (.qualityReview, .technicianReview),
    (.qualityReview, .capturing),
    (.technicianReview, .readyForSealing),
    (.technicianReview, .capturing),
    (.readyForSealing, .sealed),
    (.sealed, .uploadPending),
    (.uploadPending, .uploading),
    (.uploading, .uploaded),
    (.uploading, .recoveryRequired),
    (.uploaded, .serverVerified),
    (.uploaded, .rejected),
    (.recoveryRequired, .uploadPending),
    (.capturing, .cancelled),
    (.paused, .cancelled),
  ]

  public static func canTransition(from: CaptureSessionState, to: CaptureSessionState) -> Bool {
    allowedTransitions.contains { $0.0 == from && $0.1 == to }
  }

  public static func transition(
    from: CaptureSessionState,
    to: CaptureSessionState,
    actorId: String,
    reason: String,
    at: TimestampValue,
    softwareVersion: String
  ) throws -> SessionTransition {
    guard canTransition(from: from, to: to) else {
      throw CaptureError.contractViolation("Illegal session transition \(from.rawValue) → \(to.rawValue)")
    }
    if from == .sealed && to != .uploadPending {
      throw CaptureError.contractViolation("Sealed session cannot transition to \(to.rawValue)")
    }
    return SessionTransition(
      from: from,
      to: to,
      actorId: actorId,
      reason: reason,
      at: at,
      softwareVersion: softwareVersion
    )
  }
}
