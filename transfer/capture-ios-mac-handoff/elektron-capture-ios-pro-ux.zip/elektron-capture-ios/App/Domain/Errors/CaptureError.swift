import Foundation

public enum CaptureError: Error, Equatable, Sendable {
  case mockOnly(String)
  case packageInvalid(String)
  case contractViolation(String)
  case forbiddenAuthorityClaim(String)
}

public enum EDTSIntakeStatus: String, Equatable, Sendable {
  case evidenceAccepted = "EVIDENCE_ACCEPTED"
  case evidenceRejected = "EVIDENCE_REJECTED"
  case moreCaptureRequired = "MORE_CAPTURE_REQUIRED"
  case engineeringReviewRequired = "ENGINEERING_REVIEW_REQUIRED"
}

/// Forbidden local claims — never emit from this app.
public enum ForbiddenAuthorityClaim: String, CaseIterable, Sendable {
  case buildAuthorized = "BUILD_AUTHORIZED"
  case structurallyApproved = "STRUCTURALLY_APPROVED"
  case designSafe = "DESIGN_SAFE"
  case vehicleCompliant = "VEHICLE_COMPLIANT"
}
