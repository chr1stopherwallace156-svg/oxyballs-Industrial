import Foundation

public struct EvidenceExportOptions: Sendable {
  /// Injected for deterministic tests. Production may pass wall-clock ISO strings.
  public var createdAtUTC: String?
  /// When true, write pretty JSON (human inspection). Determinism tests use false.
  public var prettyPrint: Bool
  /// When true, also write evidence_manifest.json alias.
  public var writeLegacyManifestAlias: Bool
  /// Required for Phase 1+ packages; optional in Phase 0 fixtures.
  public var deviceProvenance: CaptureDeviceProvenance?

  public init(
    createdAtUTC: String? = nil,
    prettyPrint: Bool = true,
    writeLegacyManifestAlias: Bool = true,
    deviceProvenance: CaptureDeviceProvenance? = nil
  ) {
    self.createdAtUTC = createdAtUTC
    self.prettyPrint = prettyPrint
    self.writeLegacyManifestAlias = writeLegacyManifestAlias
    self.deviceProvenance = deviceProvenance
  }
}

public struct FileEvidenceExporter: EvidenceExporting {
  public var store: ArtifactStoring
  public var isoFormatter: ISO8601DateFormatter
  public var options: EvidenceExportOptions

  public init(
    store: ArtifactStoring = ImmutableFileStore(),
    options: EvidenceExportOptions = EvidenceExportOptions()
  ) {
    self.store = store
    self.options = options
    self.isoFormatter = ISO8601DateFormatter()
    self.isoFormatter.formatOptions = [.withInternetDateTime]
  }

  public func exportPackage(
    session: LocalCaptureSession,
    artifacts: [LocalArtifactRef],
    to directory: URL,
    captureAppVersion: String
  ) async throws -> URL {
    try EvidenceManifestValidator.validateSessionForExport(session, artifacts: artifacts)

    let fm = FileManager.default
    if fm.fileExists(atPath: directory.path) {
      throw CaptureError.packageInvalid("Export directory already exists: \(directory.path)")
    }

    let dirs = [
      "originals/images",
      "originals/depth",
      "originals/motion",
      "originals/metadata",
      "derivatives",
      "calibration",
      "quality",
      "signatures",
      "amendments",
    ]
    for d in dirs {
      try fm.createDirectory(at: directory.appendingPathComponent(d), withIntermediateDirectories: true)
    }

    let createdAt = options.createdAtUTC ?? isoFormatter.string(from: session.createdAt)

    var manifestArtifacts: [[String: Any]] = []
    var checksumLines: [String] = []

    // Stable artifact order by artifact_id
    let ordered = artifacts.sorted { $0.artifactId < $1.artifactId }

    for art in ordered {
      let dest = directory.appendingPathComponent(art.relativePath)
      if !fm.fileExists(atPath: dest.path) {
        throw CaptureError.packageInvalid("Missing artifact file: \(art.relativePath)")
      }
      let hash = try ContentHasher.sha256Hex(fileAt: dest)
      guard hash == art.sha256 else {
        throw CaptureError.packageInvalid("Hash mismatch for \(art.artifactId)")
      }
      checksumLines.append("\(hash)  \(art.relativePath)")
      var entry: [String: Any] = [
        "artifact_id": art.artifactId,
        "relative_path": art.relativePath,
        "sha256": hash,
        "media_type": art.mediaType,
        "captured_at_utc": isoFormatter.string(from: art.capturedAt),
        "clock_domain": art.clockDomain,
        "authority": art.authority.rawValue,
        "is_original": art.isOriginal,
        "parent_artifact_ids": art.parentArtifactIds.sorted(),
      ]
      if let frame = art.coordinateFrame {
        entry["coordinate_frame"] = frame
      }
      manifestArtifacts.append(entry)
    }

    let sessionJSON: [String: Any] = [
      "schema_id": "CaptureSessionContract",
      "schema_version": "1.0.0",
      "session_id": session.sessionId,
      "state": session.state.rawValue,
      "plan_id": session.planId ?? NSNull(),
      "vehicle_id": session.vehicleId ?? NSNull(),
      "vehicle_identity_status": session.vehicleIdentityStatus.rawValue,
      "capture_app_version": captureAppVersion,
      "created_at_utc": createdAt,
      "clock_domain": session.clockDomain,
      "device_profile_id": session.deviceProfileId ?? NSNull(),
      "installation_id": session.installationId ?? NSNull(),
      "operator_id": session.operatorId ?? NSNull(),
    ]

    let manifest: [String: Any] = [
      "manifest_version": "1.0.0",
      "schema_id": "EvidenceManifest",
      "schema_version": "1.0.0",
      "session_id": session.sessionId,
      "capture_app_version": captureAppVersion,
      "created_at_utc": createdAt,
      "clock_domain": session.clockDomain,
      "device_profile_id": session.deviceProfileId ?? NSNull(),
      "capture_plan_id": session.planId ?? NSNull(),
      "artifacts": manifestArtifacts,
      "notes": ["Exported by FileEvidenceExporter", "Apple-native Path A package"],
    ]

    try AuthorityGuard.rejectForbiddenClaims(in: try CanonicalJSON.string(manifest))
    try AuthorityGuard.rejectForbiddenClaims(in: try CanonicalJSON.string(sessionJSON))

    let packageMeta: [String: Any] = [
      "capture_app_version": captureAppVersion,
      "evidence_schema_version": "1.0.0",
      "capture_plan_schema_version": "1.0.0",
      "edts_api_version": "v1",
      "portable_package_version": "1.0.0",
      "integration_label": "MOCK_OR_OFFLINE_EXPORT",
      "platform": "iphone_apple_native",
    ]

    try writeJSON(manifest, to: directory.appendingPathComponent("manifest.json"))
    if options.writeLegacyManifestAlias {
      try writeJSON(manifest, to: directory.appendingPathComponent("evidence_manifest.json"))
    }
    try writeJSON(sessionJSON, to: directory.appendingPathComponent("session.json"))
    try writeJSON(packageMeta, to: directory.appendingPathComponent("package_meta.json"))
    if let prov = options.deviceProvenance {
      try writeJSON(prov.asDictionary(), to: directory.appendingPathComponent("capture_device.json"))
    }
    try writeJSON(
      ["mock": true, "verifier": "MockAttestationVerifier", "session_id": session.sessionId],
      to: directory.appendingPathComponent("signatures/attestation.json")
    )
    let checksumBody = checksumLines.sorted().joined(separator: "\n") + "\n"
    try checksumBody.data(using: .utf8)!.write(
      to: directory.appendingPathComponent("checksums.sha256"),
      options: .withoutOverwriting
    )

    return directory
  }

  private func writeJSON(_ object: Any, to url: URL) throws {
    var opts: JSONSerialization.WritingOptions = [.sortedKeys]
    if options.prettyPrint {
      opts.insert(.prettyPrinted)
    }
    let data = try JSONSerialization.data(withJSONObject: object, options: opts)
    try data.write(to: url, options: .withoutOverwriting)
  }
}

// NOTE: CanonicalJSON lives in Application/CanonicalJSON.swift (signing / binding).
// Pretty on-disk manifests may differ in whitespace; signatures must use CanonicalJSON.
