# AppAttest

Deferred / mock until Phase 1–2 security path.
