import Foundation

#if canImport(CryptoKit)
import CryptoKit
#endif

public enum ContentHasher {
  public static func sha256Hex(_ data: Data) -> String {
    #if canImport(CryptoKit)
    let digest = SHA256.hash(data: data)
    return digest.map { String(format: "%02x", $0) }.joined()
    #else
    return LinuxSHA256.hex(data)
    #endif
  }

  public static func sha256Hex(fileAt url: URL) throws -> String {
    let data = try Data(contentsOf: url)
    return sha256Hex(data)
  }
}

#if !canImport(CryptoKit)
/// Minimal SHA-256 for Linux CI (Apple builds use CryptoKit).
enum LinuxSHA256 {
  static func hex(_ data: Data) -> String {
    var hasher = Hasher()
    hasher.update(data)
    return hasher.finalize().map { String(format: "%02x", $0) }.joined()
  }

  struct Hasher {
    private var h: [UInt32] = [
      0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
    ]
    private var chunk = [UInt8]()
    private var totalLen: UInt64 = 0

    mutating func update(_ data: Data) {
      totalLen += UInt64(data.count)
      var idx = 0
      let bytes = [UInt8](data)
      while idx < bytes.count {
        let take = min(64 - chunk.count, bytes.count - idx)
        chunk.append(contentsOf: bytes[idx..<(idx + take)])
        idx += take
        if chunk.count == 64 {
          process(chunk)
          chunk.removeAll(keepingCapacity: true)
        }
      }
    }

    mutating func finalize() -> [UInt8] {
      var tail = chunk
      tail.append(0x80)
      while (tail.count % 64) != 56 {
        tail.append(0)
      }
      var bitLen = totalLen &* 8
      var lenBytes = [UInt8](repeating: 0, count: 8)
      for i in (0..<8).reversed() {
        lenBytes[i] = UInt8(bitLen & 0xff)
        bitLen >>= 8
      }
      tail.append(contentsOf: lenBytes)
      for i in stride(from: 0, to: tail.count, by: 64) {
        process(Array(tail[i..<(i + 64)]))
      }
      var out = [UInt8]()
      for v in h {
        out.append(UInt8((v >> 24) & 0xff))
        out.append(UInt8((v >> 16) & 0xff))
        out.append(UInt8((v >> 8) & 0xff))
        out.append(UInt8(v & 0xff))
      }
      return out
    }

    private mutating func process(_ block: [UInt8]) {
      let k: [UInt32] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
      ]
      var w = [UInt32](repeating: 0, count: 64)
      for i in 0..<16 {
        let j = i * 4
        w[i] =
          (UInt32(block[j]) << 24) | (UInt32(block[j + 1]) << 16) | (UInt32(block[j + 2]) << 8)
          | UInt32(block[j + 3])
      }
      for i in 16..<64 {
        let s0 = rotateRight(w[i - 15], 7) ^ rotateRight(w[i - 15], 18) ^ (w[i - 15] >> 3)
        let s1 = rotateRight(w[i - 2], 17) ^ rotateRight(w[i - 2], 19) ^ (w[i - 2] >> 10)
        w[i] = w[i - 16] &+ s0 &+ w[i - 7] &+ s1
      }
      var a = h[0], b = h[1], c = h[2], d = h[3]
      var e = h[4], f = h[5], g = h[6], hh = h[7]
      for i in 0..<64 {
        let S1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25)
        let ch = (e & f) ^ (~e & g)
        let t1 = hh &+ S1 &+ ch &+ k[i] &+ w[i]
        let S0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22)
        let maj = (a & b) ^ (a & c) ^ (b & c)
        let t2 = S0 &+ maj
        hh = g; g = f; f = e; e = d &+ t1
        d = c; c = b; b = a; a = t1 &+ t2
      }
      h[0] &+= a; h[1] &+= b; h[2] &+= c; h[3] &+= d
      h[4] &+= e; h[5] &+= f; h[6] &+= g; h[7] &+= hh
    }

    private func rotateRight(_ x: UInt32, _ n: UInt32) -> UInt32 {
      (x >> n) | (x << (32 - n))
    }
  }
}
#endif
