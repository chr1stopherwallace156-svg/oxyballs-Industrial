import Foundation

/// MOCK — labels all verifications as non-production.
public struct MockAttestationVerifier: AttestationVerifying {
  public init() {}

  public func verifySession(sessionId: String) async throws -> Bool {
    _ = sessionId
    // Always "passes" in mock mode; callers must check environment.
    return true
  }

  public var isMock: Bool { true }
}
