import Foundation

/// Runtime mode — production must fail closed on mocks.
public enum RuntimeEnvironment: String, Codable, Sendable, CaseIterable {
  case test = "TEST"
  case developmentMock = "DEVELOPMENT_MOCK"
  case production = "PRODUCTION"
}

public protocol MockDetectable: Sendable {
  var isMock: Bool { get }
}

extension MockEDTSClient: MockDetectable {}
extension MockAttestationVerifier: MockDetectable {}
extension LocalCapturePlanProvider: MockDetectable {
  public var isMock: Bool { true }
}

/// Composition root checks — call at app startup / release validation.
public enum ProductionConfigurationGuard {
  public static func validate(
    environment: RuntimeEnvironment,
    providers: [MockDetectable]
  ) throws {
    guard environment == .production else { return }
    let mocks = providers.filter(\.isMock)
    if !mocks.isEmpty {
      let names = mocks.map { String(describing: type(of: $0)) }.joined(separator: ", ")
      throw CaptureError.contractViolation(
        "PRODUCTION forbids mock providers: \(names)"
      )
    }
  }
}
