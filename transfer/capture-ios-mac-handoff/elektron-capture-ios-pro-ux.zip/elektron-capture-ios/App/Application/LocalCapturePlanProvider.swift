import Foundation

public struct LocalCapturePlanProvider: CapturePlanProviding {
  public var fixtureDirectory: URL?

  public init(fixtureDirectory: URL? = nil) {
    self.fixtureDirectory = fixtureDirectory
  }

  public func loadPlan(planId: String) async throws -> CapturePlanDTO {
    if let dir = fixtureDirectory {
      let url = dir.appendingPathComponent("\(planId).json")
      let data = try Data(contentsOf: url)
      return try JSONDecoder().decode(CapturePlanDTO.self, from: data)
    }
    // Built-in mock plan
    return CapturePlanDTO(
      schemaId: "CapturePlan",
      schemaVersion: "1.0.0",
      planId: planId,
      title: "Mock plan \(planId)",
      targetConfigurationId: "CFG-2019-F450-REG-CAB-4X2-60CA-DRW",
      requirements: [
        CaptureRequirementDTO(
          requirementId: "req-rail-lh-overview",
          description: "Left frame rail overview still (synthetic)",
          artifactKind: "still_image",
          mandatory: true
        ),
      ]
    )
  }
}
