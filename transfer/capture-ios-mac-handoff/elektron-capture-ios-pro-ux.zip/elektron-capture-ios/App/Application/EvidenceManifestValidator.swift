import Foundation

/// Validates manifests/artifacts before seal or export. AuthorityGuard is enforced here.
public enum EvidenceManifestValidator {
  /// Authorities the capture app may emit. ENGINEERING_VERIFIED is EDTS-side only.
  public static let captureEmittableAuthorities: Set<EvidenceAuthority> = [
    .rawObservation,
    .deviceReported,
    .guidanceEstimate,
    .algorithmEstimate,
    .physicalReference,
    .fieldValidated,
    .rejected,
    .unknown,
  ]

  public static func validateArtifact(_ art: LocalArtifactRef, sessionSealed: Bool) throws {
    if art.sha256.isEmpty {
      throw CaptureError.contractViolation("Artifact \(art.artifactId) missing hash")
    }
    if art.sha256.count != 64 || art.sha256.contains(where: { !$0.isHexDigit }) {
      throw CaptureError.contractViolation("Artifact \(art.artifactId) hash must be 64 hex chars")
    }
    if sessionSealed && art.sha256.isEmpty {
      throw CaptureError.contractViolation("Sealed artifact missing hash")
    }
    if !art.isOriginal && art.parentArtifactIds.isEmpty {
      throw CaptureError.contractViolation("Derivative \(art.artifactId) missing parentArtifactIds")
    }
    if !captureEmittableAuthorities.contains(art.authority) {
      throw CaptureError.forbiddenAuthorityClaim(art.authority.rawValue)
    }
    try AuthorityGuard.rejectForbiddenClaims(in: art.artifactId)
    try AuthorityGuard.rejectForbiddenClaims(in: art.relativePath)
    try AuthorityGuard.rejectForbiddenClaims(in: art.mediaType)
    try AuthorityGuard.rejectForbiddenClaims(in: art.authority.rawValue)
    if let frame = art.coordinateFrame {
      try AuthorityGuard.rejectForbiddenClaims(in: frame)
    }
  }

  public static func validateMeasurement(_ value: UncertainValue) throws {
    if value.unit.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
      throw CaptureError.contractViolation("Measurement missing unit")
    }
    if !captureEmittableAuthorities.contains(value.authority) {
      throw CaptureError.forbiddenAuthorityClaim(value.authority.rawValue)
    }
    try AuthorityGuard.rejectForbiddenClaims(in: value.unit)
    try AuthorityGuard.rejectForbiddenClaims(in: value.authority.rawValue)
    if let method = value.method {
      try AuthorityGuard.rejectForbiddenClaims(in: method)
    }
  }

  public static func validatePose(_ pose: SpatialPose) throws {
    if pose.sourceFrame.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
      || pose.targetFrame.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    {
      throw CaptureError.contractViolation("Transform missing source/target frame")
    }
    if pose.values.count != 16 {
      throw CaptureError.contractViolation("Transform must be 4x4 (16 values)")
    }
    if !captureEmittableAuthorities.contains(pose.authority) {
      throw CaptureError.forbiddenAuthorityClaim(pose.authority.rawValue)
    }
    try AuthorityGuard.rejectForbiddenClaims(in: pose.sourceFrame)
    try AuthorityGuard.rejectForbiddenClaims(in: pose.targetFrame)
    try AuthorityGuard.rejectForbiddenClaims(in: pose.authority.rawValue)
  }

  public static func validateSessionForExport(
    _ session: LocalCaptureSession,
    artifacts: [LocalArtifactRef]
  ) throws {
    try AuthorityGuard.rejectForbiddenClaims(in: session.sessionId)
    if let plan = session.planId { try AuthorityGuard.rejectForbiddenClaims(in: plan) }
    if let veh = session.vehicleId { try AuthorityGuard.rejectForbiddenClaims(in: veh) }
    let sealed = session.state == .sealed || session.state == .uploadPending
      || session.state == .uploading || session.state == .uploaded
      || session.state == .serverVerified
    for art in artifacts {
      try validateArtifact(art, sessionSealed: sealed)
    }
    // Scan canonical JSON of session+artifacts for forbidden claim tokens
    let blob = try CanonicalJSON.string([
      "session_id": session.sessionId,
      "state": session.state.rawValue,
      "artifacts": artifacts.map {
        [
          "artifact_id": $0.artifactId,
          "authority": $0.authority.rawValue,
          "sha256": $0.sha256,
        ] as [String: Any]
      },
    ] as [String: Any])
    try AuthorityGuard.rejectForbiddenClaims(in: blob)
  }
}
