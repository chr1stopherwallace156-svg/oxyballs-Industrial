import Foundation

public enum AuthorityGuard {
  /// Throws if a string matches a forbidden Build Engine / compliance claim.
  public static func rejectForbiddenClaims(in text: String) throws {
    for claim in ForbiddenAuthorityClaim.allCases {
      if text.contains(claim.rawValue) {
        throw CaptureError.forbiddenAuthorityClaim(claim.rawValue)
      }
    }
  }
}
