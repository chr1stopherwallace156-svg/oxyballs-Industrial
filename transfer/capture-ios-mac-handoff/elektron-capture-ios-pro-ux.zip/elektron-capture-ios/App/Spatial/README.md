# Spatial

ARKit-based guidance (Phase 2+). Default authority: GUIDANCE_ESTIMATE.
