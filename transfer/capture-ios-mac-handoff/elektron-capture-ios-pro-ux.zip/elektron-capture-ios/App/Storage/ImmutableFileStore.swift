import Foundation

public struct ImmutableFileStore: ArtifactStoring {
  public init() {}

  public func writeImmutable(data: Data, to relativePath: String, under root: URL) throws -> String {
    let url = root.appendingPathComponent(relativePath)
    try FileManager.default.createDirectory(
      at: url.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if FileManager.default.fileExists(atPath: url.path) {
      throw CaptureError.packageInvalid("Refusing overwrite of \(relativePath)")
    }
    try data.write(to: url, options: .withoutOverwriting)
    return ContentHasher.sha256Hex(data)
  }
}
