# LocalEvidenceStore

Offline-first storage scaffolding (Phase 1+).
