# ROADMAP

Canonical document: [`Docs/Integration/ROADMAP.md`](Docs/Integration/ROADMAP.md)

This root file exists so repository checklists and Cursor rules can reference a stable top-level name. Edit the Docs/ path above; keep this pointer in sync if the canonical path moves.
