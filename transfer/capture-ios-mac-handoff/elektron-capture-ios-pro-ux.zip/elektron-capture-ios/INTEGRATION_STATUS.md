# INTEGRATION_STATUS.md

| Field | Value |
|---|---|
| Capture application version | **0.1.4** |
| Evidence schema version | **1.0.0** (DRAFT) |
| Capture-plan schema version | **1.0.0** (DRAFT) |
| API version (target) | **v1** |
| Portable-package version | **1.0.0** |
| Platform | **iPhone Apple-native** |
| Phase 0 implementation | **Approved** (`APPROVED_FOR_PHASE_1_PREPARATION`) |
| Phase 1 specification | **`PHASE_1_DIRECTIVE_APPROVED`** |
| Phase 1 runtime implementation | **`PHASE_1_RUNTIME_IMPLEMENTED_PENDING_DEVICE_VALIDATION`** |
| Simulator / physical validation | **`BLOCKED_BY_ENVIRONMENT`** (this agent host) |
| Phase 1 implementation complete | **No** |
| Repository ↔ EDTS status | **`PACKAGE_EXPORT_READY`** |
| EDTS compatibility | **Not established for a real still** (synthetic fixture can pass importer) |
| Last integration test date | Synthetic fixture → EDTS importer (agent host); physical still *pending* |
| Golden package version | **GOLDEN_CAPTURE_001 / 1.0.0** (Path A layout) |
| Known incompatibilities | No live EDTS importer exercised yet |
| Required EDTS changes | XREPO-0001 (canonical compatibility) + XREPO-0002 (secure ingest) |
| Required capture-app changes | Phase 1 still capture after GitHub publish + importer progress |

## Status planes (do not conflate)

See `Docs/Architecture/STATUS_TAXONOMY.md`.

| Plane | Current |
|---|---|
| Repository implementation | `PACKAGE_EXPORT_READY` |
| Phase governance | `PHASE_1_DIRECTIVE_APPROVED` (spec only) |
| Runtime evidence (EDTS) | *none yet* |

```
PHASE_1_DIRECTIVE_APPROVED ≠ PHASE_1_IMPLEMENTATION_COMPLETE
```

Phase 1 directive approved.  
Phase 1 runtime code present (`PHASE_1_RUNTIME_IMPLEMENTED_PENDING_DEVICE_VALIDATION`).  
Simulator / physical-device validation: **`BLOCKED_BY_ENVIRONMENT`** on this host.  
Phase 1 implementation **not** complete until a physical package passes XREPO-0001 and XREPO-0002.

## Status legend

`NOT_CONNECTED` · `MOCK_ONLY` · `PACKAGE_EXPORT_READY` · `API_CLIENT_READY` · `INTEGRATION_TESTING` · `EDTS_COMPATIBLE` · `INCOMPATIBLE` · `MIGRATION_REQUIRED`

## Contract ownership (summary)

See `Docs/Integration/CONTRACT_OWNERSHIP.md`.

| Contract | Ownership |
|---|---|
| CapturePlan / CaptureRequirement | EDTS_OWNED_REQUEST |
| EvidenceManifest / CoordinateTransform / API | JOINT_CAPTURE_EDTS |
| ArtifactMetadata / MeasurementObservation | CAPTURE_OWNED_OUTPUT |
| CalibrationProfile | CAPTURE_OWNED_OBSERVATION |
| Build authorization | BUILD_ENGINE_OWNED (prohibited in capture output) |

## Phase 1 directive

Locked: `Docs/Capture/PHASE_1_FIRST_VERIFIED_CAPTURE_ARTIFACT.md` (First Verified Capture Artifact — integrity, not engineering truth).

## Pre–Phase 1 controls

- `Docs/Integration/SCHEMA_COMPATIBILITY.md` / `SCHEMA_MIGRATION.md`
- `Docs/Validation/CANONICAL_JSON.md`
- `Docs/Validation/ACCEPTANCE_CRITERIA.md`
- Golden includes `capture_device.json`

## Cross-repository requests

| ID | Status | Purpose |
|---|---|---|
| XREPO-CAP-EDTS-0001 | OPEN | **Canonical compatibility** (schema, canonical JSON, hashes, IDs, authority, provenance) |
| XREPO-CAP-EDTS-0002 | OPEN | **Secure package ingestion** (quarantine, archive limits, path safety, inventory, atomic commit) |

A package may pass 0001 and still fail 0002.

## Honesty

Status **PACKAGE_EXPORT_READY** means local portable packages verify. It does **not** mean live EDTS API integration. Do **not** claim `EDTS_COMPATIBLE` until XREPO-0001 (and for Phase 1 stills, 0002) succeed on the EDTS side. The capture app must not self-assign `INGESTED_INTEGRITY_VERIFIED`.
