import CryptoKit
import Foundation

/// Streaming SHA-256 over on-disk bytes (read-back path).
public struct ArtifactHashingService: Sendable {
  public init() {}

  public func sha256HexOfFile(at url: URL) throws -> String {
    do {
      let handle = try FileHandle(forReadingFrom: url)
      defer { try? handle.close() }
      var hasher = SHA256()
      while true {
        let chunk = try handle.read(upToCount: 1024 * 1024) ?? Data()
        if chunk.isEmpty { break }
        hasher.update(data: chunk)
      }
      return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    } catch {
      throw Phase1RuntimeError.artifactHashFailed(String(describing: error))
    }
  }

  public func sha256HexOfData(_ data: Data) -> String {
    ContentHasher.sha256Hex(data)
  }
}
