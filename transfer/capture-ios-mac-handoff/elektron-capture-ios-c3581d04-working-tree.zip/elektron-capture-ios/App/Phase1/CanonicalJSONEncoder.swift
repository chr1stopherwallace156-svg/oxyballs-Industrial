import Foundation

/// Thin alias matching the Phase 1 component name; delegates to `CanonicalJSON`.
public enum CanonicalJSONEncoder {
  public static func encode(_ object: Any) throws -> Data {
    do {
      return try CanonicalJSON.data(object)
    } catch {
      throw Phase1RuntimeError.canonicalizationFailed(String(describing: error))
    }
  }
}
