import Foundation

/// Machine-readable Phase 1 runtime failures.
public enum Phase1RuntimeError: Error, Equatable, Sendable {
  case cameraPermissionDenied
  case cameraConfigurationFailed(String)
  case photoCaptureFailed(String)
  case fileRepresentationUnavailable
  case artifactPersistenceFailed(String)
  case readbackFailed(String)
  case artifactHashFailed(String)
  case hashReadbackMismatch(expected: String, actual: String)
  case manifestBuildFailed(String)
  case canonicalizationFailed(String)
  case inventoryBuildFailed(String)
  case packageBuildFailed(String)
  case exportFailed(String)
  case statusAuthorityViolation(String)
  case incompleteCleanup(String)

  public var reasonCode: String {
    switch self {
    case .cameraPermissionDenied: return "CAMERA_PERMISSION_DENIED"
    case .cameraConfigurationFailed: return "CAMERA_CONFIGURATION_FAILED"
    case .photoCaptureFailed: return "PHOTO_CAPTURE_FAILED"
    case .fileRepresentationUnavailable: return "FILE_REPRESENTATION_UNAVAILABLE"
    case .artifactPersistenceFailed: return "ARTIFACT_PERSISTENCE_FAILED"
    case .readbackFailed: return "READBACK_FAILED"
    case .artifactHashFailed: return "ARTIFACT_HASH_FAILED"
    case .hashReadbackMismatch: return "HASH_READBACK_MISMATCH"
    case .manifestBuildFailed: return "MANIFEST_BUILD_FAILED"
    case .canonicalizationFailed: return "CANONICALIZATION_FAILED"
    case .inventoryBuildFailed: return "INVENTORY_BUILD_FAILED"
    case .packageBuildFailed: return "PACKAGE_BUILD_FAILED"
    case .exportFailed: return "EXPORT_FAILED"
    case .statusAuthorityViolation: return "STATUS_AUTHORITY_VIOLATION"
    case .incompleteCleanup: return "INCOMPLETE_CLEANUP"
    }
  }
}
