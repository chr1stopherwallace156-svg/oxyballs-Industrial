import Foundation

/// Canonical JSON for signed/bound structured metadata.
/// See Docs/Validation/CANONICAL_JSON.md — do **not** rely on Dictionary iteration order.
public enum CanonicalJSON {
  /// Deterministic JSON: UTF-8, sorted keys, compact separators, normalized scalars.
  public static func data(_ object: Any) throws -> Data {
    let normalized = try normalize(object)
    // .sortedKeys is the sole key-order authority — never enumerate Dictionary for output order.
    return try JSONSerialization.data(withJSONObject: normalized, options: [.sortedKeys])
  }

  public static func string(_ object: Any) throws -> String {
    let d = try data(object)
    guard let s = String(data: d, encoding: .utf8) else {
      throw CaptureError.packageInvalid("Canonical JSON not UTF-8")
    }
    return s
  }

  private static func normalize(_ value: Any) throws -> Any {
    switch value {
    case let dict as [String: Any]:
      var out: [String: Any] = [:]
      for (k, v) in dict {
        out[k] = try normalize(v)
      }
      return out
    case let arr as [Any]:
      return try arr.map { try normalize($0) }
    case let s as String:
      return s
    case let b as Bool:
      return b
    case is NSNull:
      return NSNull()
    case let n as NSNumber:
      // Bool bridges to NSNumber on Apple platforms — keep JSON true/false.
      if CFGetTypeID(n as CFTypeRef) == CFBooleanGetTypeID() {
        return n.boolValue
      }
      let d = n.doubleValue
      if d.isNaN || d.isInfinite {
        throw CaptureError.packageInvalid("Canonical JSON rejects non-finite numbers")
      }
      // Prefer integers when exactly representable as Int64.
      if floor(d) == d, let i = Int64(exactly: n.int64Value), Double(i) == d {
        return NSNumber(value: i)
      }
      return n
    case let i as Int:
      return i
    case let i as Int64:
      return i
    case let d as Double:
      if d.isNaN || d.isInfinite {
        throw CaptureError.packageInvalid("Canonical JSON rejects non-finite numbers")
      }
      if floor(d) == d, let i = Int64(exactly: d) {
        return i
      }
      return d
    case let f as Float:
      return try normalize(Double(f))
    default:
      throw CaptureError.packageInvalid("Unsupported JSON type \(type(of: value))")
    }
  }
}
