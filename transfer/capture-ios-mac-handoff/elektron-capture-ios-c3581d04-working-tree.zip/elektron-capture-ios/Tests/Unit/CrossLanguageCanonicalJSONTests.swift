import CryptoKit
import Foundation
import XCTest
@testable import ElektronCapture

/// Cross-language byte identity gate against the Python `dumps_canonical` golden.
/// Do NOT parse both sides and compare objects — compare raw UTF-8 bytes.
final class CrossLanguageCanonicalJSONTests: XCTestCase {
  func testSwiftCanonicalBytesMatchPythonGolden() throws {
    let semanticURL = try fixtureURL(name: "corpus.semantic", ext: "json", subdir: "canonical_corpus")
    let goldenURL = try fixtureURL(name: "corpus.python.canonical", ext: "json", subdir: "canonical_corpus")
    let shaURL = try fixtureURL(name: "corpus.python.canonical", ext: "sha256", subdir: "canonical_corpus")

    let semanticData = try Data(contentsOf: semanticURL)
    let object = try JSONSerialization.jsonObject(with: semanticData, options: [])
    let swiftBytes = try CanonicalJSON.data(object)
    let golden = try Data(contentsOf: goldenURL)

    if swiftBytes != golden {
      let msg = firstDiffMessage(actual: swiftBytes, expected: golden)
      XCTFail(
        """
        CROSS_LANGUAGE_CANONICAL_JSON_BYTE_IDENTITY FAILED
        \(msg)
        Swift(UTF-8): \(String(data: swiftBytes, encoding: .utf8) ?? "<binary>")
        Python(UTF-8): \(String(data: golden, encoding: .utf8) ?? "<binary>")
        Likely cause: Unicode escaping (Python ensure_ascii=True vs Swift UTF-8 raw).
        Resolve via reviewed canonical policy change — do not parse-and-compare objects.
        """
      )
      return
    }

    let digest = SHA256.hash(data: swiftBytes).map { String(format: "%02x", $0) }.joined()
    let expectedDigest = try String(contentsOf: shaURL, encoding: .utf8)
      .trimmingCharacters(in: .whitespacesAndNewlines)
    XCTAssertEqual(digest, expectedDigest)
  }

  private func fixtureURL(name: String, ext: String, subdir: String) throws -> URL {
    if let url = Bundle.module.url(forResource: name, withExtension: ext, subdirectory: "Fixtures/\(subdir)") {
      return url
    }
    if let url = Bundle.module.url(forResource: name, withExtension: ext, subdirectory: subdir) {
      return url
    }
    if let url = Bundle.module.url(forResource: name, withExtension: ext) {
      return url
    }
    struct Missing: Error {}
    throw Missing()
  }

  private func firstDiffMessage(actual: Data, expected: Data) -> String {
    let a = [UInt8](actual)
    let e = [UInt8](expected)
    let n = min(a.count, e.count)
    for i in 0..<n where a[i] != e[i] {
      return String(
        format: "first differing byte at offset %d: actual=0x%02x expected=0x%02x; actual_len=%d expected_len=%d",
        i, a[i], e[i], a.count, e.count
      )
    }
    return "length mismatch actual=\(a.count) expected=\(e.count)"
  }
}
