import XCTest
@testable import ElektronCapture

/// Golden-file tests. Prefer locating fixtures via SWIFT_PACKAGE environment / relative crawl.
final class GoldenEvidencePackageTests: XCTestCase {
  func testGoldenPackageHashesMatchManifest() throws {
    let package = try Self.locateGoldenPackage()
    let manifestURL = package.appendingPathComponent("evidence_manifest.json")
    let data = try Data(contentsOf: manifestURL)
    let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
    XCTAssertEqual(json?["schema_id"] as? String, "EvidenceManifest")
    XCTAssertEqual(json?["schema_version"] as? String, "1.0.0")
    guard let artifacts = json?["artifacts"] as? [[String: Any]], !artifacts.isEmpty else {
      return XCTFail("missing artifacts")
    }
    for art in artifacts {
      guard let rel = art["relative_path"] as? String,
            let expected = art["sha256"] as? String else {
        return XCTFail("artifact missing path/hash")
      }
      let fileURL = package.appendingPathComponent(rel)
      let actual = try ContentHasher.sha256Hex(fileAt: fileURL)
      XCTAssertEqual(actual, expected.lowercased(), "hash mismatch for \(rel)")
    }
  }

  func testPackageMetaDeclaresCompatibility() throws {
    let package = try Self.locateGoldenPackage()
    let metaURL = package.appendingPathComponent("package_meta.json")
    let data = try Data(contentsOf: metaURL)
    let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
    XCTAssertEqual(json?["evidence_schema_version"] as? String, "1.0.0")
    XCTAssertEqual(json?["portable_package_version"] as? String, "1.0.0")
    XCTAssertEqual(json?["capture_app_version"] as? String, "0.1.0")
  }

  private static func locateGoldenPackage() throws -> URL {
    let fm = FileManager.default
    var url = URL(fileURLWithPath: #filePath).deletingLastPathComponent()
    for _ in 0..<6 {
      let candidate = url
        .appendingPathComponent("TestFixtures/GoldenEvidencePackages/GOLDEN_CAPTURE_001")
      if fm.fileExists(atPath: candidate.appendingPathComponent("evidence_manifest.json").path) {
        return candidate
      }
      url.deleteLastPathComponent()
    }
    throw CaptureError.packageInvalid("GOLDEN_CAPTURE_001 not found relative to tests")
  }
}
