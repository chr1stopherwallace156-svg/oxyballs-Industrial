import ElektronCapture
import SwiftUI

#if canImport(AVFoundation) && canImport(UIKit)
import AVFoundation
#endif

/// Minimal Phase 1 UI: one capture → package → share path/hash.
/// Preview must not mutate evidence. Does not display EDTS XREPO results.
public struct Phase1CaptureRootView: View {
  @State private var statusText = "Ready"
  @State private var packagePath = ""
  @State private var packageURL: URL?
  @State private var artifactHash = ""
  @State private var packageId = ""
  @State private var evidenceId = ""
  @State private var busy = false

  private let appVersion = "0.1.4"

  public init() {}

  public var body: some View {
    NavigationStack {
      VStack(alignment: .leading, spacing: 16) {
        Text("Elektron Capture")
          .font(.largeTitle.weight(.bold))
        Text("Phase 1 — single still → .edts-pkg")
          .foregroundStyle(.secondary)
        Text("DEVICE_VALIDATION_REHEARSAL · NON_AUTHORITATIVE · CONTENT_UNVERIFIED")
          .font(.caption2)
          .foregroundStyle(.secondary)

        Button(busy ? "Working…" : "Capture & Export") {
          Task { await runCapture() }
        }
        .buttonStyle(.borderedProminent)
        .disabled(busy)

        if let packageURL {
          ShareLink(item: packageURL) {
            Label("Share .edts-pkg", systemImage: "square.and.arrow.up")
          }
          .buttonStyle(.bordered)
        }

        Group {
          labeled("Capture-side status", statusText)
          labeled("Package ID", packageId)
          labeled("Evidence ID", evidenceId)
          labeled("Artifact SHA-256", artifactHash)
          labeled("Package path", packagePath)
          labeled("EDTS XREPO-0001", "NOT_RUN (EDTS importer only)")
          labeled("EDTS XREPO-0002", "NOT_RUN (EDTS importer only)")
        }
        .font(.footnote.monospaced())

        Text("Capture-side validation ≠ EDTS gates. This app never displays XREPO PASS.")
          .font(.caption)
          .foregroundStyle(.secondary)
        Text("After Share/AirDrop to Mac, ingest with eae/importers/xrepo_cap_edts/.")
          .font(.caption)
          .foregroundStyle(.secondary)

        Spacer()
      }
      .padding()
      .navigationTitle("Phase 1 Still")
    }
  }

  private func labeled(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(.caption).foregroundStyle(.secondary)
      Text(value.isEmpty ? "—" : value).textSelection(.enabled)
    }
  }

  @MainActor
  private func runCapture() async {
    busy = true
    defer { busy = false }
    do {
      let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
      let work = docs.appendingPathComponent("Phase1Exports", isDirectory: true)
      try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)

      #if canImport(AVFoundation) && canImport(UIKit)
      let capture: any StillPhotoCaptureProviding = StillPhotoCaptureService()
      #else
      throw Phase1RuntimeError.cameraConfigurationFailed("AVFoundation unavailable on this platform")
      #endif

      let coordinator = Phase1CaptureCoordinator(
        appVersion: appVersion,
        photoCapture: capture,
        workRoot: work
      )
      let result = try await coordinator.captureAndExport()
      let captureSide = CaptureSidePackageValidator.validate(packageDirectory: result.packageDirectoryURL)
      packageId = result.packageId
      evidenceId = result.evidenceId
      artifactHash = result.artifactSha256
      packageURL = result.packageZipURL
      packagePath = result.packageZipURL.path
      if captureSide.ok {
        statusText = "CAPTURE_SIDE_OK → PACKAGE_EXPORTED. Use Share to send .edts-pkg to Mac, then EDTS XREPO."
      } else {
        statusText = "CAPTURE_SIDE_FAIL \(captureSide.reasonCodes.joined(separator: ","))"
      }
    } catch let e as Phase1RuntimeError {
      statusText = "FAIL \(e.reasonCode)"
      packageURL = nil
    } catch {
      statusText = "FAIL \(error.localizedDescription)"
      packageURL = nil
    }
  }
}
