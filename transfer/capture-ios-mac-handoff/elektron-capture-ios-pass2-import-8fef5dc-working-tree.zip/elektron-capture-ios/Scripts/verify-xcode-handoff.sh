#!/usr/bin/env bash
# Prove Xcode handoff layout from a clean tree (no Xcode required).
# Usage: ./Scripts/verify-xcode-handoff.sh [repo-root]
set -euo pipefail

ROOT="$(cd "${1:-$(dirname "$0")/..}" && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

echo "=== verify-xcode-handoff @ $ROOT ==="

[[ -f Package.swift ]] || fail "Package.swift missing at repo root"
pass "Package.swift exists at repo root"

if command -v swift >/dev/null 2>&1; then
  PROD=$(swift package dump-package | python3 -c "import sys,json; print(',' .join(p['name'] for p in json.load(sys.stdin)['products']))")
  echo "$PROD" | grep -q 'ElektronCapture' || fail "Package does not export product ElektronCapture (got: $PROD)"
  pass "Package exports product ElektronCapture"
else
  grep -q 'library(name: "ElektronCapture"' Package.swift || fail "Package.swift missing ElektronCapture product declaration"
  pass "Package.swift declares product ElektronCapture (swift not installed; dump-package skipped)"
fi

PBX="$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj"
[[ -f "$PBX" ]] || fail "Phase1StillCapture.xcodeproj missing"
pass "Phase1StillCapture.xcodeproj exists"

grep -q 'productName = ElektronCapture' "$PBX" || fail "pbxproj missing productName = ElektronCapture"
pass "pbxproj productName = ElektronCapture"

grep -q 'isa = XCLocalSwiftPackageReference' "$PBX" || fail "pbxproj missing XCLocalSwiftPackageReference"
pass "pbxproj has XCLocalSwiftPackageReference"

# relativePath must resolve to repo root from the directory containing the .xcodeproj
PROJ_DIR="$ROOT/Apps/Phase1StillCapture"
REL=$(grep -E 'relativePath = ' "$PBX" | head -1 | sed 's/.*relativePath = //;s/;//;s/ //g')
[[ -n "$REL" ]] || fail "relativePath not found in pbxproj"
RESOLVED="$(cd "$PROJ_DIR" && realpath "$REL")"
[[ "$RESOLVED" == "$ROOT" ]] || fail "relativePath '$REL' from Apps/Phase1StillCapture resolves to '$RESOLVED', expected '$ROOT'"
[[ -f "$RESOLVED/Package.swift" ]] || fail "resolved package root has no Package.swift"
pass "relativePath '$REL' resolves to repo root with Package.swift"

# Sources that compile in the app target must import the package module when present.
# `swift build` only builds Package.swift (ElektronCapture) — it does NOT compile the Xcode app.
# Checking only Phase1StillCaptureApp.swift previously allowed RootView to omit the import.
APP_SWIFT_DIR="$ROOT/Apps/Phase1StillCapture"
[[ -d "$APP_SWIFT_DIR" ]] || fail "Apps/Phase1StillCapture missing"
APP_SWIFT_FILES=()
while IFS= read -r -d '' f; do
  APP_SWIFT_FILES+=("$f")
done < <(find "$APP_SWIFT_DIR" -maxdepth 1 -name '*.swift' -print0 | sort -z)

[[ ${#APP_SWIFT_FILES[@]} -gt 0 ]] || fail "No app Swift sources under Apps/Phase1StillCapture"

for f in "${APP_SWIFT_FILES[@]}"; do
  base="$(basename "$f")"
  # Info-only / empty files shouldn't exist; every app .swift that is a compile unit must import.
  if [[ "$base" == "Phase1StillCaptureApp.swift" || "$base" == "Phase1CaptureRootView.swift" ]]; then
    grep -q 'import ElektronCapture' "$f" \
      || fail "$base compiles in the app target but lacks 'import ElektronCapture' (swift build will not catch this)"
    pass "$base imports ElektronCapture"
  fi
done

# Frameworks / package product linkage (pbxproj surrogate for xcodebuild -showBuildSettings on Linux)
grep -q 'ElektronCapture in Frameworks' "$PBX" || fail "pbxproj missing ElektronCapture in Frameworks build file"
pass "pbxproj links ElektronCapture in Frameworks"
grep -q 'productName = ElektronCapture' "$PBX" || fail "pbxproj missing productName = ElektronCapture"
pass "pbxproj productName = ElektronCapture (package product dependency)"

# Workspace helpers (optional but recommended)
if [[ -f "$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace/contents.xcworkspacedata" ]]; then
  pass "App-level xcworkspace present"
fi
if [[ -f "$ROOT/Phase1StillCapture.xcworkspace/contents.xcworkspacedata" ]]; then
  pass "Root xcworkspace present"
fi

echo
echo "HANDOFF_LAYOUT_OK"
echo "Open either:"
echo "  open Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj"
echo "  open Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace"
echo "  open Phase1StillCapture.xcworkspace"
echo "If Xcode still shows Missing package product: File → Packages → Reset Package Caches, then resolve."
