# Phase1StillCapture (thin Xcode host)

Open the **workspace** (not Package.swift alone):

```bash
open Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace
# or
open Phase1StillCapture.xcworkspace
```

Scheme: `Phase1StillCapture`

## Capture UX (current)

1. Live `AVCaptureVideoPreviewLayer` (non-authoritative).
2. Readiness indicator (`Warming up…` / `Adjusting exposure… (shutter available)` / `Ready`).
3. Deliberate **Shutter** after warm-up (not deadlocked on continuous AE/AF).
4. Review with **Retake** / **Export Package**.
5. Export runs quality guard + hash invariance; packages exact `fileDataRepresentation()` bytes.

Physical export demonstrated ≠ Phase 1 complete while automated tests fail.

## Layout

```
Phase1StillCapture.xcodeproj / .xcworkspace
Apps/Phase1StillCapture/*.swift  (this folder only)
  → local package product ElektronCapture (repo root Package.swift)
```

- Captures one processed JPEG via AVFoundation (`fileDataRepresentation`).
- Preview / UIImage confirmation must never replace artifact bytes.
