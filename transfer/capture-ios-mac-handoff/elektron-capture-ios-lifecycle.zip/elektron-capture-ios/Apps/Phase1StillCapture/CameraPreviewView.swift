import AVFoundation
import SwiftUI
import UIKit

/// Displays `AVCaptureVideoPreviewLayer`. Preview pixels are non-authoritative.
struct CameraPreviewView: UIViewRepresentable {
  let session: AVCaptureSession
  var onAttached: (() -> Void)?

  func makeUIView(context: Context) -> PreviewUIView {
    let view = PreviewUIView()
    view.previewLayer.session = session
    view.previewLayer.videoGravity = .resizeAspectFill
    return view
  }

  func updateUIView(_ uiView: PreviewUIView, context: Context) {
    if uiView.previewLayer.session !== session {
      uiView.previewLayer.session = session
    }
    DispatchQueue.main.async {
      onAttached?()
    }
  }

  final class PreviewUIView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
  }
}
