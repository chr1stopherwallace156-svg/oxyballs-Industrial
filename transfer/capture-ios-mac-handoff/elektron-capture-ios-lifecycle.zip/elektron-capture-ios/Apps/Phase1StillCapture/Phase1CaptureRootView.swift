import ElektronCapture
import SwiftUI

#if canImport(AVFoundation) && canImport(UIKit)
import AVFoundation
import UIKit
#endif

/// Phase 1 UI: live preview → deliberate shutter → Retake / Export Package.
/// Preview and confirmation images are non-authoritative; package uses exact JPEG bytes.
public struct Phase1CaptureRootView: View {
  private enum Step {
    case live
    case review
    case exported
  }

  @State private var step: Step = .live
  @State private var statusText = "Ready"
  @State private var packagePath = ""
  @State private var packageURL: URL?
  @State private var artifactHash = ""
  @State private var packageId = ""
  @State private var evidenceId = ""
  @State private var busy = false
  @State private var lastErrorDetail = ""
  @State private var capturedJPEG: Data?
  @State private var postDelegateHash = ""
  @State private var reviewImage: UIImage?
  @State private var lifecycleSummary = ""

  #if canImport(AVFoundation) && canImport(UIKit)
  @StateObject private var capture = InteractiveStillCaptureController()
  #endif

  private let appVersion = "0.1.4"

  public init() {}

  public var body: some View {
    NavigationStack {
      VStack(alignment: .leading, spacing: 12) {
        Text("Elektron Capture")
          .font(.largeTitle.weight(.bold))
        Text("Phase 1 — single still → .edts-pkg")
          .foregroundStyle(.secondary)
        Text("DEVICE_VALIDATION_REHEARSAL · NON_AUTHORITATIVE · CONTENT_UNVERIFIED")
          .font(.caption2)
          .foregroundStyle(.secondary)

        #if canImport(AVFoundation) && canImport(UIKit)
        switch step {
        case .live:
          liveCapturePane
        case .review:
          reviewPane
        case .exported:
          exportedPane
        }
        #else
        Text("AVFoundation unavailable on this platform")
          .foregroundStyle(.red)
        #endif

        Group {
          labeled("Capture-side status", statusText)
          labeled("Package ID", packageId)
          labeled("Evidence ID", evidenceId)
          labeled("Artifact SHA-256", artifactHash)
          labeled("Package path", packagePath)
          if !lifecycleSummary.isEmpty {
            labeled("Lifecycle", lifecycleSummary)
          }
          if !lastErrorDetail.isEmpty {
            labeled("Error detail", lastErrorDetail)
          }
          labeled("EDTS XREPO-0001", "NOT_RUN (EDTS importer only)")
          labeled("EDTS XREPO-0002", "NOT_RUN (EDTS importer only)")
        }
        .font(.footnote.monospaced())

        Text("Capture-side validation ≠ EDTS gates. This app never displays XREPO PASS.")
          .font(.caption)
          .foregroundStyle(.secondary)
        Text("Physical export demonstrated ≠ Phase 1 complete while unit tests fail.")
          .font(.caption)
          .foregroundStyle(.secondary)

        Spacer(minLength: 0)
      }
      .padding()
      .navigationTitle("Phase 1 Still")
      .task {
        #if canImport(AVFoundation) && canImport(UIKit)
        await startCamera()
        #endif
      }
      .onDisappear {
        #if canImport(AVFoundation) && canImport(UIKit)
        capture.stopSession()
        #endif
      }
    }
  }

  #if canImport(AVFoundation) && canImport(UIKit)
  private var liveCapturePane: some View {
    VStack(alignment: .leading, spacing: 10) {
      CameraPreviewView(session: capture.session) {
        if !capture.previewAttached {
          capture.markPreviewAttached(true)
        }
      }
      .frame(maxWidth: .infinity)
      .frame(height: 320)
      .clipped()
      .background(Color.black)

      Text(capture.readinessText)
        .font(.subheadline.weight(.semibold))
        .foregroundStyle(capture.shutterEnabled ? .primary : .secondary)

      Button(busy ? "Capturing…" : "Shutter") {
        Task { await pressShutter() }
      }
      .buttonStyle(.borderedProminent)
      .disabled(busy || !capture.shutterEnabled)
    }
  }

  private var reviewPane: some View {
    VStack(alignment: .leading, spacing: 10) {
      if let reviewImage {
        Image(uiImage: reviewImage)
          .resizable()
          .scaledToFit()
          .frame(maxWidth: .infinity)
          .frame(height: 280)
          .background(Color.black)
      } else {
        Text("Captured (preview decode unavailable)")
          .frame(maxWidth: .infinity, minHeight: 120)
          .background(Color.black.opacity(0.8))
          .foregroundStyle(.white)
      }
      Text("Confirmation preview is non-authoritative. Export uses original JPEG bytes.")
        .font(.caption)
        .foregroundStyle(.secondary)

      HStack(spacing: 12) {
        Button("Retake") {
          retake()
        }
        .buttonStyle(.bordered)

        Button(busy ? "Exporting…" : "Export Package") {
          Task { await exportPackage() }
        }
        .buttonStyle(.borderedProminent)
        .disabled(busy || capturedJPEG == nil)
      }
    }
  }

  private var exportedPane: some View {
    VStack(alignment: .leading, spacing: 10) {
      if let packageURL {
        ShareLink(item: packageURL) {
          Label("Share .edts-pkg", systemImage: "square.and.arrow.up")
        }
        .buttonStyle(.bordered)
      }
      Button("New Capture") {
        retake()
      }
      .buttonStyle(.borderedProminent)
    }
  }

  @MainActor
  private func startCamera() async {
    do {
      try await capture.prepareSession()
      statusText = "Camera live — wait for Ready, then press Shutter"
    } catch let e as Phase1RuntimeError {
      statusText = "FAIL \(e.reasonCode)"
      lastErrorDetail = e.detailMessage
    } catch {
      statusText = "FAIL UNKNOWN"
      lastErrorDetail = String(describing: error)
    }
  }

  @MainActor
  private func pressShutter() async {
    busy = true
    defer { busy = false }
    lastErrorDetail = ""
    statusText = "Capturing…"
    do {
      let jpeg = try await capture.captureProcessedJPEG()
      capturedJPEG = jpeg
      postDelegateHash = ArtifactHashingService().sha256HexOfData(jpeg)
      // Throwaway UI decode only — never replaces artifact bytes.
      reviewImage = UIImage(data: jpeg)
      lifecycleSummary = capture.lifecycle.summaryLine()
      step = .review
      statusText = "Review — Retake or Export Package"
      artifactHash = postDelegateHash
    } catch let e as Phase1RuntimeError {
      statusText = "FAIL \(e.reasonCode)"
      lastErrorDetail = e.detailMessage
      lifecycleSummary = capture.lifecycle.summaryLine()
      Phase1CaptureDiagnostics.log(
        stage: "ui",
        event: "capture_failed",
        detail: "reason=\(e.reasonCode) detail=\(e.detailMessage)"
      )
    } catch {
      statusText = "FAIL UNKNOWN"
      lastErrorDetail = String(describing: error)
    }
  }

  @MainActor
  private func retake() {
    capturedJPEG = nil
    reviewImage = nil
    packageURL = nil
    packagePath = ""
    packageId = ""
    evidenceId = ""
    artifactHash = ""
    postDelegateHash = ""
    lastErrorDetail = ""
    step = .live
    statusText = "Camera live — wait for Ready, then press Shutter"
    Task { await startCamera() }
  }

  @MainActor
  private func exportPackage() async {
    guard let jpeg = capturedJPEG else { return }
    busy = true
    defer { busy = false }
    lastErrorDetail = ""
    statusText = "Exporting…"

    do {
      let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
      let work = docs.appendingPathComponent("Phase1Exports", isDirectory: true)
      try FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)

      let coordinator = Phase1CaptureCoordinator(
        appVersion: appVersion,
        photoCapture: FixtureStillPhotoCaptureService(jpegBytes: jpeg),
        workRoot: work,
        enforceImageQualityGuard: true,
        lifecycle: capture.lifecycle
      )
      let result = try coordinator.exportCapturedJPEG(jpeg)
      if result.artifactSha256 != postDelegateHash {
        throw Phase1RuntimeError.hashReadbackMismatch(
          expected: postDelegateHash,
          actual: result.artifactSha256
        )
      }
      let captureSide = CaptureSidePackageValidator.validate(packageDirectory: result.packageDirectoryURL)
      packageId = result.packageId
      evidenceId = result.evidenceId
      artifactHash = result.artifactSha256
      packageURL = result.packageZipURL
      packagePath = result.packageZipURL.path
      lifecycleSummary = capture.lifecycle.summaryLine()
      step = .exported
      if captureSide.ok {
        statusText = "CAPTURE_SIDE_OK → PACKAGE_EXPORTED. Use Share to send .edts-pkg to Mac, then EDTS XREPO."
      } else {
        statusText = "CAPTURE_SIDE_FAIL \(captureSide.reasonCodes.joined(separator: ","))"
        lastErrorDetail = captureSide.notes.joined(separator: " | ")
      }
    } catch let e as Phase1RuntimeError {
      statusText = "FAIL \(e.reasonCode)"
      lastErrorDetail = e.detailMessage
      packageURL = nil
      lifecycleSummary = capture.lifecycle.summaryLine()
      Phase1CaptureDiagnostics.log(
        stage: "ui",
        event: "export_failed",
        detail: "reason=\(e.reasonCode) detail=\(e.detailMessage) reflecting=\(String(reflecting: e))"
      )
    } catch {
      statusText = "FAIL UNKNOWN"
      lastErrorDetail = [
        "type=\(String(describing: type(of: error)))",
        "describing=\(String(describing: error))",
        "reflecting=\(String(reflecting: error))",
        "localizedDescription=\(error.localizedDescription)",
      ].joined(separator: " | ")
      packageURL = nil
      Phase1CaptureDiagnostics.log(stage: "ui", event: "export_failed", detail: lastErrorDetail)
    }
  }
  #endif

  private func labeled(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(.caption).foregroundStyle(.secondary)
      Text(value.isEmpty ? "—" : value).textSelection(.enabled)
    }
  }
}
