#if canImport(AVFoundation) && canImport(UIKit)
import AVFoundation
import Combine
import Foundation
import UIKit

public final class CameraAuthorizationService: @unchecked Sendable {
  public init() {}

  public func authorizationStatus() -> AVAuthorizationStatus {
    AVCaptureDevice.authorizationStatus(for: .video)
  }

  public func requestAccessIfNeeded() async throws {
    switch authorizationStatus() {
    case .authorized:
      return
    case .notDetermined:
      let granted = await AVCaptureDevice.requestAccess(for: .video)
      if !granted { throw Phase1RuntimeError.cameraPermissionDenied }
    case .denied, .restricted:
      throw Phase1RuntimeError.cameraPermissionDenied
    @unknown default:
      throw Phase1RuntimeError.cameraPermissionDenied
    }
  }
}

public final class CameraSessionController: NSObject, @unchecked Sendable {
  public let session = AVCaptureSession()
  private let sessionQueue = DispatchQueue(label: "elektron.capture.session")
  public private(set) var captureDevice: AVCaptureDevice?

  public override init() {
    super.init()
  }

  public func configureForStillCapture() throws {
    session.beginConfiguration()
    defer { session.commitConfiguration() }
    session.sessionPreset = .photo

    session.inputs.forEach { session.removeInput($0) }
    session.outputs.forEach { session.removeOutput($0) }

    guard
      let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
    else {
      throw Phase1RuntimeError.cameraConfigurationFailed("no rear wide camera")
    }
    let input: AVCaptureDeviceInput
    do {
      input = try AVCaptureDeviceInput(device: device)
    } catch {
      throw Phase1RuntimeError.cameraConfigurationFailed(String(describing: error))
    }
    guard session.canAddInput(input) else {
      throw Phase1RuntimeError.cameraConfigurationFailed("cannot add camera input")
    }
    session.addInput(input)
    captureDevice = device
  }

  public func start(lifecycle: CaptureLifecycleInstrumenter? = nil) {
    lifecycle?.record(.sessionStartRequested, detail: "queue=elektron.capture.session")
    sessionQueue.async { [session] in
      if !session.isRunning {
        session.startRunning()
      }
      let running = session.isRunning
      DispatchQueue.main.async {
        lifecycle?.record(.sessionRunningChanged, detail: "\(running)")
      }
    }
  }

  public func stop() {
    sessionQueue.async { [session] in
      if session.isRunning { session.stopRunning() }
    }
  }
}

/// Interactive still capture: preview + warm-up shutter enablement (no AE/AF deadlock).
@MainActor
public final class InteractiveStillCaptureController: NSObject, ObservableObject {
  public let sessionController: CameraSessionController
  public let lifecycle: CaptureLifecycleInstrumenter
  public let warmUpNanoseconds: UInt64

  private let auth: CameraAuthorizationService
  private let photoOutput = AVCapturePhotoOutput()
  private var continuation: CheckedContinuation<Data, Error>?
  private var exposureObs: NSKeyValueObservation?
  private var focusObs: NSKeyValueObservation?
  private var runningObs: NSObjectProtocol?
  private var stoppedObs: NSObjectProtocol?
  private var warmUpTask: Task<Void, Never>?

  @Published public private(set) var sessionRunning = false
  @Published public private(set) var previewAttached = false
  @Published public private(set) var warmUpElapsed = false
  @Published public private(set) var isAdjustingExposure = false
  @Published public private(set) var isAdjustingFocus = false
  @Published public private(set) var shutterEnabled = false
  @Published public private(set) var readinessText = "Starting camera…"
  @Published public private(set) var fatalConfigError: String?

  public var session: AVCaptureSession { sessionController.session }

  public init(
    auth: CameraAuthorizationService = CameraAuthorizationService(),
    sessionController: CameraSessionController = CameraSessionController(),
    lifecycle: CaptureLifecycleInstrumenter = CaptureLifecycleInstrumenter(),
    warmUpNanoseconds: UInt64 = 1_500_000_000
  ) {
    self.auth = auth
    self.sessionController = sessionController
    self.lifecycle = lifecycle
    self.warmUpNanoseconds = warmUpNanoseconds
    super.init()
  }

  deinit {
    // Cannot touch MainActor state from deinit reliably; stop session on queue.
    sessionController.stop()
  }

  public func prepareSession() async throws {
    fatalConfigError = nil
    lifecycle.reset()
    try await auth.requestAccessIfNeeded()
    do {
      try sessionController.configureForStillCapture()
      sessionController.session.beginConfiguration()
      if sessionController.session.canAddOutput(photoOutput) {
        sessionController.session.addOutput(photoOutput)
      } else if !sessionController.session.outputs.contains(where: { $0 === photoOutput }) {
        throw Phase1RuntimeError.cameraConfigurationFailed("cannot add photo output")
      }
      if #available(iOS 16.0, *) {
        photoOutput.maxPhotoQualityPrioritization = .quality
      }
      sessionController.session.commitConfiguration()
    } catch {
      let msg = (error as? Phase1RuntimeError)?.detailMessage ?? String(describing: error)
      fatalConfigError = msg
      refreshShutterGate()
      throw error
    }

    observeDeviceAdjustments()
    observeSessionRunning()
    sessionController.start(lifecycle: lifecycle)
    scheduleWarmUp()
    refreshShutterGate()
  }

  public func markPreviewAttached(_ attached: Bool = true) {
    previewAttached = attached
    if attached {
      lifecycle.record(.previewAttached, detail: "AVCaptureVideoPreviewLayer")
    }
    refreshShutterGate()
  }

  public func captureProcessedJPEG() async throws -> Data {
    guard shutterEnabled else {
      throw Phase1RuntimeError.cameraConfigurationFailed(
        "shutter not enabled (sessionRunning=\(sessionRunning) previewAttached=\(previewAttached) warmUpElapsed=\(warmUpElapsed) fatal=\(fatalConfigError ?? "nil"))"
      )
    }
    lifecycle.record(.shutterPressed, detail: "interactive")
    return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Data, Error>) in
      self.continuation = cont
      let settings: AVCapturePhotoSettings
      if photoOutput.availablePhotoCodecTypes.contains(.jpeg) {
        settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
      } else {
        settings = AVCapturePhotoSettings()
      }
      self.photoOutput.capturePhoto(with: settings, delegate: self)
    }
  }

  public func stopSession() {
    warmUpTask?.cancel()
    warmUpTask = nil
    exposureObs?.invalidate()
    focusObs?.invalidate()
    if let runningObs { NotificationCenter.default.removeObserver(runningObs) }
    if let stoppedObs { NotificationCenter.default.removeObserver(stoppedObs) }
    runningObs = nil
    stoppedObs = nil
    sessionController.stop()
    sessionRunning = false
    shutterEnabled = false
    refreshShutterGate()
  }

  private func scheduleWarmUp() {
    warmUpTask?.cancel()
    warmUpElapsed = false
    let ns = warmUpNanoseconds
    warmUpTask = Task { [weak self] in
      try? await Task.sleep(nanoseconds: ns)
      guard let self, !Task.isCancelled else { return }
      await MainActor.run {
        self.warmUpElapsed = true
        self.refreshShutterGate()
      }
    }
  }

  private func observeSessionRunning() {
    if let runningObs { NotificationCenter.default.removeObserver(runningObs) }
    if let stoppedObs { NotificationCenter.default.removeObserver(stoppedObs) }
    runningObs = NotificationCenter.default.addObserver(
      forName: .AVCaptureSessionDidStartRunning,
      object: sessionController.session,
      queue: .main
    ) { [weak self] _ in
      Task { @MainActor in
        self?.sessionRunning = true
        self?.lifecycle.record(.sessionRunningChanged, detail: "true")
        self?.refreshShutterGate()
      }
    }
    stoppedObs = NotificationCenter.default.addObserver(
      forName: .AVCaptureSessionDidStopRunning,
      object: sessionController.session,
      queue: .main
    ) { [weak self] _ in
      Task { @MainActor in
        self?.sessionRunning = false
        self?.lifecycle.record(.sessionRunningChanged, detail: "false")
        self?.refreshShutterGate()
      }
    }
  }

  private func observeDeviceAdjustments() {
    exposureObs?.invalidate()
    focusObs?.invalidate()
    guard let device = sessionController.captureDevice else { return }
    isAdjustingExposure = device.isAdjustingExposure
    isAdjustingFocus = device.isAdjustingFocus
    exposureObs = device.observe(\.isAdjustingExposure, options: [.new]) { [weak self] _, change in
      let value = change.newValue ?? false
      Task { @MainActor in
        self?.isAdjustingExposure = value
        self?.lifecycle.record(.deviceAdjustingExposure, detail: "\(value)")
        self?.refreshShutterGate()
      }
    }
    focusObs = device.observe(\.isAdjustingFocus, options: [.new]) { [weak self] _, change in
      let value = change.newValue ?? false
      Task { @MainActor in
        self?.isAdjustingFocus = value
        self?.lifecycle.record(.deviceAdjustingFocus, detail: "\(value)")
        self?.refreshShutterGate()
      }
    }
  }

  /// Shutter enablement uses session + preview + warm-up — **not** a hard AE/AF lock.
  private func refreshShutterGate() {
    if let fatalConfigError {
      shutterEnabled = false
      readinessText = "Camera error: \(fatalConfigError)"
      return
    }
    let readyCore = sessionRunning && previewAttached && warmUpElapsed
    if readyCore {
      if !shutterEnabled {
        shutterEnabled = true
        lifecycle.record(
          .shutterEnabled,
          detail: "ms_session_running_to_shutter_enabled=\(lifecycle.msSessionRunningToShutterEnabled.map { String(format: "%.3f", $0) } ?? "nil")"
        )
      }
      if isAdjustingExposure || isAdjustingFocus {
        readinessText = "Adjusting exposure… (shutter available)"
      } else {
        readinessText = "Ready"
      }
    } else {
      shutterEnabled = false
      if !sessionRunning {
        readinessText = "Starting camera…"
      } else if !previewAttached {
        readinessText = "Attaching preview…"
      } else if !warmUpElapsed {
        readinessText = "Warming up…"
      } else {
        readinessText = "Not ready"
      }
    }
  }
}

extension InteractiveStillCaptureController: AVCapturePhotoCaptureDelegate {
  public nonisolated func photoOutput(
    _ output: AVCapturePhotoOutput,
    didFinishProcessingPhoto photo: AVCapturePhoto,
    error: Error?
  ) {
    Task { @MainActor in
      self.handlePhoto(photo, error: error)
    }
  }

  private func handlePhoto(_ photo: AVCapturePhoto, error: Error?) {
    if let error {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "capture_failure",
        detail: [
          "swiftErrorType=\(String(describing: type(of: error)))",
          "describing=\(String(describing: error))",
          "reflecting=\(String(reflecting: error))",
          "localizedDescription=\(error.localizedDescription)",
        ].joined(separator: " | ")
      )
      lifecycle.record(.photoDelegateReceived, detail: "error=true")
      continuation?.resume(throwing: Phase1RuntimeError.photoCaptureFailed(error.localizedDescription))
      continuation = nil
      return
    }
    let meta = photo.metadata
    let metaKeyCount = meta.count
    let metaKeySample = Array(meta.keys.prefix(12)).map { String(describing: $0) }
    let hasEmbeddedThumbnail = photo.embeddedThumbnailPhotoFormat != nil
    if let data = photo.fileDataRepresentation() {
      lifecycle.record(
        .photoDelegateReceived,
        detail: "byteCount=\(data.count) ms_shutter_to_delegate=\(lifecycle.msShutterPressToPhotoDelegate.map { String(format: "%.3f", $0) } ?? "nil")"
      )
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "fileDataRepresentation_ok",
        detail: [
          "byteCount=\(data.count)",
          "metadataKeyCount=\(metaKeyCount)",
          "metadataKeySample=\(metaKeySample)",
          "embeddedThumbnailPresent=\(hasEmbeddedThumbnail)",
          "note=JPEG bytes not logged",
          lifecycle.summaryLine(),
        ].joined(separator: " | ")
      )
      continuation?.resume(returning: data)
    } else {
      lifecycle.record(.photoDelegateReceived, detail: "file_representation_unavailable")
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "file_representation_unavailable",
        detail: [
          "metadataKeyCount=\(metaKeyCount)",
          "metadataKeySample=\(metaKeySample)",
          "embeddedThumbnailPresent=\(hasEmbeddedThumbnail)",
        ].joined(separator: " | ")
      )
      continuation?.resume(throwing: Phase1RuntimeError.fileRepresentationUnavailable)
    }
    continuation = nil
  }
}

/// One-shot still capture (tests / legacy). Prefer `InteractiveStillCaptureController` for UI.
public final class StillPhotoCaptureService: NSObject, StillPhotoCaptureProviding, @unchecked Sendable {
  private let auth: CameraAuthorizationService
  private let controller: CameraSessionController
  private let photoOutput = AVCapturePhotoOutput()
  private var continuation: CheckedContinuation<Data, Error>?
  public let lifecycle: CaptureLifecycleInstrumenter

  public init(
    auth: CameraAuthorizationService = CameraAuthorizationService(),
    controller: CameraSessionController = CameraSessionController(),
    lifecycle: CaptureLifecycleInstrumenter = CaptureLifecycleInstrumenter()
  ) {
    self.auth = auth
    self.controller = controller
    self.lifecycle = lifecycle
    super.init()
  }

  public func captureProcessedJPEG() async throws -> Data {
    try await auth.requestAccessIfNeeded()
    try controller.configureForStillCapture()
    if controller.session.canAddOutput(photoOutput) {
      controller.session.addOutput(photoOutput)
    } else if !controller.session.outputs.contains(where: { $0 === photoOutput }) {
      throw Phase1RuntimeError.cameraConfigurationFailed("cannot add photo output")
    }
    if #available(iOS 16.0, *) {
      photoOutput.maxPhotoQualityPrioritization = .quality
    }
    controller.start(lifecycle: lifecycle)
    // Brief settle for session — one-shot path only; interactive UI uses warm-up + preview.
    try await Task.sleep(nanoseconds: 250_000_000)
    lifecycle.record(.shutterEnabled, detail: "one_shot_settle")
    lifecycle.record(.shutterPressed, detail: "one_shot")

    return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Data, Error>) in
      self.continuation = cont
      let settings = AVCapturePhotoSettings()
      if photoOutput.availablePhotoCodecTypes.contains(.jpeg) {
        let s = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
        self.photoOutput.capturePhoto(with: s, delegate: self)
      } else {
        self.photoOutput.capturePhoto(with: settings, delegate: self)
      }
    }
  }
}

extension StillPhotoCaptureService: AVCapturePhotoCaptureDelegate {
  public func photoOutput(
    _ output: AVCapturePhotoOutput,
    didFinishProcessingPhoto photo: AVCapturePhoto,
    error: Error?
  ) {
    if let error {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "capture_failure",
        detail: [
          "swiftErrorType=\(String(describing: type(of: error)))",
          "describing=\(String(describing: error))",
          "reflecting=\(String(reflecting: error))",
          "localizedDescription=\(error.localizedDescription)",
        ].joined(separator: " | ")
      )
      lifecycle.record(.photoDelegateReceived, detail: "error=true")
      continuation?.resume(throwing: Phase1RuntimeError.photoCaptureFailed(error.localizedDescription))
      continuation = nil
      controller.stop()
      return
    }
    let meta = photo.metadata
    let metaKeyCount = meta.count
    let metaKeySample = Array(meta.keys.prefix(12)).map { String(describing: $0) }
    let hasEmbeddedThumbnail = photo.embeddedThumbnailPhotoFormat != nil
    if let data = photo.fileDataRepresentation() {
      lifecycle.record(
        .photoDelegateReceived,
        detail: "byteCount=\(data.count) ms_shutter_to_delegate=\(lifecycle.msShutterPressToPhotoDelegate.map { String(format: "%.3f", $0) } ?? "nil")"
      )
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "fileDataRepresentation_ok",
        detail: [
          "byteCount=\(data.count)",
          "metadataKeyCount=\(metaKeyCount)",
          "metadataKeySample=\(metaKeySample)",
          "embeddedThumbnailPresent=\(hasEmbeddedThumbnail)",
          "note=JPEG bytes not logged",
        ].joined(separator: " | ")
      )
      continuation?.resume(returning: data)
    } else {
      lifecycle.record(.photoDelegateReceived, detail: "file_representation_unavailable")
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture_delegate",
        event: "file_representation_unavailable",
        detail: [
          "metadataKeyCount=\(metaKeyCount)",
          "metadataKeySample=\(metaKeySample)",
          "embeddedThumbnailPresent=\(hasEmbeddedThumbnail)",
        ].joined(separator: " | ")
      )
      continuation?.resume(throwing: Phase1RuntimeError.fileRepresentationUnavailable)
    }
    continuation = nil
    controller.stop()
  }
}
#endif
