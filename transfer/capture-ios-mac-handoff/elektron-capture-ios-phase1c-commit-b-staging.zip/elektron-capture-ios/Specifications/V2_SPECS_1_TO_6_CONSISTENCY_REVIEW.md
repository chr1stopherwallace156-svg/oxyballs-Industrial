# Capture v2 — Specs 1–6 Cross-Contract Consistency Review

| Field | Value |
|---|---|
| Review date | 2026-07-25 |
| Specs in scope | EC-V2-SPEC-001 … 006 |
| Prior gate | `V2_CORE_SPECS_1_TO_3_HARDENED` + Specs 4–6 `DRAFT_FOR_BASELINE_REVIEW` |
| Result gate | **`V2_SPECIFICATIONS_1_TO_6_BASELINE_APPROVED`** |
| Spike gate | **`AUTHORIZED_FOR_IR_0001_EXECUTION`** (isolated spike only) |

## Authoritative owners

| Concern | Owner | Notes |
|---|---|---|
| Constitution / Phase 1 compatibility / RAW vs DERIVED / ML ban | Spec 1 | |
| Session hierarchy, retakes, supersession, package identity | Spec 2 | |
| EvidenceSensor lifecycle, actors, failure escalation | Spec 3 | Time taxonomy summary; defers normative clock IDs to Spec 5 |
| `DeviceCapabilitySnapshot` / support states / snapshot reasons | Spec 4 | Alias `CapabilitySnapshot` allowed in Spec 2 |
| Telemetry records, clock domains, sync windows, packaging hashes | Spec 5 | |
| Quality layers, metrics, thresholds, overrides, rollout | Spec 6 | |

## Checklist

| # | Item | Result | Evidence |
|---|---|---|---|
| 1 | Every entity has one authoritative owner | **PASS** | Owner table above; Spec 2 points capability/quality/telemetry detail to Specs 4–6 |
| 2 | Every state name has one meaning | **PASS** | Session lifecycle (`draft`…`exported`) ≠ point/session completeness ≠ export policy (`BLOCK_EXPORT` not a lifecycle state) |
| 3 | Capture decisions distinct from export decisions | **PASS** | Spec 1 §8 + Spec 6 §3.1 vs §3.4 |
| 4 | RAW and DERIVED distinguishable everywhere | **PASS** | Spec 1 §7; Spec 5 fused=`DERIVED`/`FRAMEWORK_FUSED`; transforms declare lineage |
| 5 | Every derived record preserves lineage | **PASS** | Spec 1 DERIVED rules; Spec 5 §7/§9; Spec 6 metric input IDs |
| 6 | Every timestamp declares a clock domain | **PASS** | Spec 5 §3 mandatory domains; Spec 3 defers to Spec 5 identifiers |
| 7 | Capability `UNKNOWN` ≠ `UNSUPPORTED` | **PASS** | Spec 4 §3; Spec 2 §10 restates |
| 8 | Required/optional from workflow policy | **PASS** | Spec 3 escalation + Spec 6 §8 missing-metric behaviors by workflow |
| 9 | Retakes never overwrite artifacts | **PASS** | Spec 2 retake invariant; Spec 6 §10 |
| 10 | Phase 1 fields remain backward-compatible | **PASS** | Spec 1 §3 compatibility clause |
| 11 | No ML in production boundary | **PASS** | Spec 1 §2; Spec 6 §2.8 |
| 12 | IR-0001 isolated from production targets | **PASS** | `Research/Spikes/IR-0001/`; IR status `APPROVED_FOR_ISOLATED_SPIKE` |

## Residual notes (non-blocking)

1. **`SensorRecord` (Spec 2/3) vs `TelemetryRecord` (Spec 5):** packaged telemetry normative shape is Spec 5 `TelemetryRecord`. Spec 3 `SensorPayload`/`SensorRecord` are framework-facing; implementations must map into Spec 5 records before packaging.
2. **`FRAMEWORK_FUSED`:** treated as a DERIVED subclass under Spec 1; may be added to Spec 1 glossary in a later editorial pass.
3. **Phase 1 freeze** remains a separate gate (`PHASE_1C_…EQUIVALENCE_AND_FREEZE` / Commit A). Spec baseline approval does **not** freeze Phase 1.

## Decision

```text
V2_SPECIFICATIONS_1_TO_6_BASELINE_APPROVED
AUTHORIZED_FOR_IR_0001_EXECUTION
```

Specs 4–6 remain labeled `DRAFT_FOR_BASELINE_REVIEW` in-header until editorial freeze of wording; the **gate** above authorizes proceeding to the isolated IR-0001 spike and measured v2.0A directive drafting — **not** production actor/camera landing.

Production v2 modules still require: Phase 1 freeze tag (separate), IR-0001 measured results, and an explicit implementation directive.
