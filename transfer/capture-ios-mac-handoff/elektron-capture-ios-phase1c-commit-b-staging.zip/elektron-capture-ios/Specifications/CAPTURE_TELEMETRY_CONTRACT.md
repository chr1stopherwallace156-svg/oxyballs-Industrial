# CAPTURE TELEMETRY CONTRACT

**Document ID:** EC-V2-SPEC-005  
**Status:** DRAFT_FOR_BASELINE_REVIEW  
**Applies To:** Capture v2.0A and later  
**Gate:** `V2_BASELINE_APPROVAL_PENDING_SPECS_4_TO_6`  
**Depends on:** EC-V2-SPEC-001, EC-V2-SPEC-002, EC-V2-SPEC-003  
**Production code:** None

## 1. Purpose

This specification defines the timestamp, synchronization, provenance,
calibration, storage, and integrity requirements for telemetry recorded by
Elektron Capture.

Telemetry provides evidence about capture conditions. It does not diagnose
vehicle state or infer component identity.

## 2. Telemetry Principles

1. Every sample must identify its source.
2. Every sample must carry a timestamp and timestamp-domain identifier.
3. Missing telemetry must be represented explicitly.
4. Samples must not be silently interpolated into RAW evidence.
5. Derived telemetry must preserve input lineage and processor version.
6. Original sensor-native timestamps must be retained when available.
7. Clock uncertainty must never be represented as zero unless proven.

## 3. Timestamp Taxonomy

### `monotonicTimestamp`

Local monotonic time used for ordering and duration measurement.

Required fields:

- `value`
- `timescale`
- `clockDomain`
- `bootSessionID`

### `wallClockTimestamp`

UTC-oriented civil timestamp.

Required fields:

- `value`
- `source`
- `uncertainty`
- `timezoneOffsetAtCapture`

UTC values must not erase the locally observed timezone metadata.

### `sensorNativeTimestamp`

Timestamp emitted by the sensor or framework.

Required fields:

- `value`
- `timescale`
- `sensorClockDomain`
- `wraparoundMetadata`
- `conversionStatus`

### `ClockAnchor`

Maps two clock domains at an observed instant.

Required fields:

- `anchorID`
- `monotonicTimestamp`
- `wallClockTimestamp`
- `wallClockSource`
- `uncertainty`
- `captureMethod`
- `createdAt`
- `bootSessionID`

A clock anchor is evidence of an observed mapping, not proof of trusted global
time.

## 4. Clock Sources

Permitted wall-clock source identifiers include:

- `SYSTEM_CLOCK`
- `NETWORK_TIME_OBSERVED`
- `GNSS_TIME_OBSERVED`
- `EXTERNAL_SENSOR_CLOCK`
- `UNKNOWN`

The presence of network connectivity does not by itself prove NTP
synchronization.

## 5. Core Telemetry Record

### `TelemetryRecord`

Required fields:

- `recordID`
- `sessionID`
- `attemptID`
- `sensorID`
- `sensorType`
- `sampleType`
- `monotonicTimestamp`
- `wallClockTimestamp`
- `sensorNativeTimestamp`
- `clockAnchorID`
- `clockUncertainty`
- `measurementValue`
- `measurementUnit`
- `coordinateFrame`
- `calibrationReferenceID`
- `qualityFlags`
- `sourceAPI`
- `schemaVersion`

Fields that are unavailable must use an explicit availability state rather
than fabricated defaults.

## 6. Availability States

Every optional measurement uses:

- `AVAILABLE`
- `NOT_SUPPORTED`
- `NOT_AUTHORIZED`
- `TEMPORARILY_UNAVAILABLE`
- `SENSOR_ERROR`
- `NOT_REQUESTED`
- `UNKNOWN`

A missing numeric measurement must never be encoded as zero.

## 7. Coordinate Frames

Every vector or pose must declare its coordinate frame.

Minimum supported identifiers:

- `DEVICE_BODY`
- `CAMERA_OPTICAL`
- `IMAGE_PIXEL`
- `WORLD_SESSION`
- `GRAVITY_ALIGNED`
- `SENSOR_NATIVE`
- `UNKNOWN`

Transformations between frames are DERIVED evidence and must record:

- source frame
- destination frame
- transformation matrix
- processor version
- calibration reference
- input record IDs

## 8. Sensor Sampling Contracts

### 8.1 Camera

Record, when available:

- presentation timestamp
- exposure duration
- ISO
- lens position
- white-balance gains
- device orientation
- active format
- focus/exposure adjustment state
- intrinsic matrix
- calibration reference

### 8.2 Motion

Record separately:

- raw accelerometer
- raw gyroscope
- raw magnetometer
- device-motion attitude
- gravity
- user acceleration
- rotation rate

Framework-fused values must be classified as DERIVED or FRAMEWORK_FUSED rather
than raw hardware measurements.

### 8.3 Location and Heading

Record:

- coordinate
- altitude
- horizontal accuracy
- vertical accuracy
- course
- speed
- true heading
- magnetic heading
- heading accuracy
- authorization state
- source timestamp

Location failure may not fabricate coordinates.

### 8.4 Depth and Pose

Record:

- depth/disparity representation
- dimensions
- pixel format
- calibration reference
- camera transform
- tracking state
- timestamp association
- confidence representation when available

## 9. Synchronization

Telemetry association with a committed artifact must define:

- target artifact timestamp;
- permitted pre-capture window;
- permitted post-capture window;
- nearest-sample rule;
- interpolation policy;
- missing-data policy;
- maximum tolerated uncertainty.

Interpolation is DERIVED evidence and must not replace retained RAW samples.

## 10. Data Segmentation

Telemetry must be segmented by:

- application launch
- device boot session
- inspection session
- capture attempt
- sensor lifecycle instance

Records from different boot sessions must not be joined on monotonic time
without a documented clock anchor.

## 11. Integrity and Packaging

RAW telemetry streams must include:

- byte count
- SHA-256
- encoding
- schema version
- record count
- start timestamp
- end timestamp

The manifest must declare all telemetry files and their relationships to
artifacts and attempts.

## 12. Privacy and Minimization

Location, heading, and external identifiers must be collected only when:

- enabled by the workflow;
- authorized by the user;
- required by the declared evidence contract.

Disabled or unauthorized collection must be explicitly represented.

## 13. Acceptance Criteria

This specification passes review when:

- every timestamp declares a clock domain;
- wall-clock and monotonic time remain distinct;
- boot-session boundaries are represented;
- missing values cannot masquerade as zero;
- fused and derived data are distinguishable from RAW samples;
- artifact association rules are deterministic;
- interpolation remains regenerable and lineage-preserving.
