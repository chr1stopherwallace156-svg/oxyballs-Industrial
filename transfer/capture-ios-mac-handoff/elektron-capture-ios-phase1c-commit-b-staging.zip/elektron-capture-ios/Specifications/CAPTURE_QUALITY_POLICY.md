# CAPTURE QUALITY POLICY

**Document ID:** EC-V2-SPEC-006  
**Status:** DRAFT_FOR_BASELINE_REVIEW  
**Applies To:** Capture v2.0C and policy consumers introduced earlier  
**Gate:** `V2_BASELINE_APPROVAL_PENDING_SPECS_4_TO_6`  
**Depends on:** EC-V2-SPEC-001, EC-V2-SPEC-002, EC-V2-SPEC-005  
**Production code:** None

## 1. Purpose

This specification defines deterministic evidence-quality evaluation,
policy rollout, threshold versioning, user feedback, and capture/export
enforcement.

The quality system evaluates measurable capture conditions. It does not infer
component identity, damage, correctness of repair, or vehicle condition.

## 2. Governing Principles

1. Every quality decision must be reproducible from declared inputs.
2. Every metric must have a versioned algorithm identifier.
3. Every threshold must have a versioned policy identifier.
4. Metrics and enforcement decisions must remain separate.
5. RAW evidence must not be modified to improve a quality score.
6. A blocked candidate frame must not become a committed artifact unless an
   authorized override contract explicitly permits it.
7. Quality policy must preserve uncertainty and unavailable measurements.
8. Learned models are prohibited from producing enforcement decisions.

## 3. Evaluation Layers

### 3.1 Capture-Level Evaluation

Permitted outcomes:

- `PASS`
- `WARN`
- `BLOCK_CAPTURE`

Evaluates a single candidate capture attempt before commitment.

### 3.2 Capture-Point Completeness

Permitted outcomes:

- `POINT_COMPLETE`
- `POINT_COMPLETE_WITH_WARNINGS`
- `POINT_INCOMPLETE`

Evaluates whether a required inspection step has acceptable committed evidence.

### 3.3 Session-Level Evaluation

Permitted outcomes:

- `COMPLETE`
- `COMPLETE_WITH_WARNINGS`
- `INCOMPLETE`

Evaluates required sequence completion and evidence availability.

### 3.4 Export-Level Evaluation

Permitted outcomes:

- `EXPORT_ALLOWED`
- `EXPORT_ALLOWED_WITH_WARNINGS`
- `BLOCK_EXPORT`

Evaluates package integrity, mandatory artifacts, required telemetry, and
contract completeness.

Do not use `BLOCK_EXPORT` as a session lifecycle state. It is an export-policy
decision.

## 4. Policy Rollout Modes

- `OBSERVE_ONLY`
- `WARN_ONLY`
- `BLOCK_ELIGIBLE`
- `BLOCK_ACTIVE`

### `OBSERVE_ONLY`

Metrics are recorded but not displayed as enforcement feedback.

### `WARN_ONLY`

Metrics may produce visible warnings but cannot block commitment or export.

### `BLOCK_ELIGIBLE`

The policy engine calculates what would be blocked and records shadow decisions,
but enforcement remains disabled.

### `BLOCK_ACTIVE`

Authorized metrics may enforce `BLOCK_CAPTURE` or `BLOCK_EXPORT`.

A policy must not enter `BLOCK_ACTIVE` without an approved validation record.

## 5. Metric Contract

Each `QualityMetricResult` contains:

- `metricID`
- `metricVersion`
- `inputArtifactIDs`
- `inputTelemetryRecordIDs`
- `computedValue`
- `normalizedValue`
- `unit`
- `availabilityState`
- `thresholdPolicyID`
- `thresholdVersion`
- `evaluationTimestamp`
- `processorBuildID`
- `determinismProfile`
- `resultFlags`

## 6. Initial Deterministic Metrics

### 6.1 Sharpness

Use a:

> versioned, normalized deterministic sharpness score

The specification must not require one permanent algorithm.

Required metadata:

- algorithm ID
- algorithm version
- source-image dimensions
- preprocessing declaration
- region-of-interest declaration
- normalized range
- threshold version

### 6.2 Luminance

Measure declared image-luminance statistics.

Possible outputs include:

- mean luminance
- median luminance
- percentile distribution
- clipped-dark ratio
- clipped-highlight ratio

### 6.3 Histogram Completeness

Record histogram binning and channel-selection rules.

### 6.4 Motion Stability

May use deterministic motion telemetry such as:

- angular velocity
- acceleration magnitude
- exposure-window motion integral
- timestamp uncertainty

Motion stability is unavailable when required telemetry is missing; it must not
default to a passing score.

### 6.5 Metadata Completeness

Evaluate declared required fields without interpreting their physical meaning.

## 7. Policy Definitions

### `QualityThresholdPolicy`

Required fields:

- `policyID`
- `policyVersion`
- `scope`
- `workflowType`
- `capturePointType`
- `requiredMetrics`
- `warningThresholds`
- `blockingThresholds`
- `missingMetricBehavior`
- `overridePolicy`
- `effectiveDate`
- `validationEvidenceReference`

Thresholds must not be hard-coded solely in user-interface logic.

## 8. Missing Metric Behavior

Each required metric declares one of:

- `WARN_IF_UNAVAILABLE`
- `BLOCK_CAPTURE_IF_UNAVAILABLE`
- `MARK_POINT_INCOMPLETE`
- `BLOCK_EXPORT_IF_UNAVAILABLE`
- `NOT_APPLICABLE`

The behavior is determined by workflow policy, not globally by sensor type.

## 9. Overrides

Any permitted override must record:

- actor or user initiating override
- timestamp
- original decision
- override reason code
- free-text explanation when required
- policy authorizing the override
- resulting artifact status

An override does not convert a failed metric into a pass. It records that
commitment or export was authorized despite the recorded result.

## 10. Supersession and Retakes

Quality failure may lead to a new `CaptureAttempt`.

Previous committed evidence remains immutable.

The selected artifact for a capture point must be identified through a
versioned selection or supersession record, never through deletion.

## 11. Determinism Requirements

A metric is eligible for enforcement only when:

- identical canonical input bytes yield identical output;
- algorithm and policy versions are recorded;
- platform-dependent behavior is characterized;
- numerical tolerance is specified;
- test vectors exist;
- unsupported input conditions fail explicitly;
- replay verification is available.

## 12. Validation Ladder

Before enabling `BLOCK_ACTIVE`, each metric must pass:

1. unit test validation;
2. golden-corpus replay;
3. cross-device characterization;
4. OS-version characterization;
5. false-block review;
6. field observation under `OBSERVE_ONLY`;
7. shadow enforcement under `BLOCK_ELIGIBLE`;
8. formal activation approval.

## 13. Acceptance Criteria

This specification passes review when:

- metric calculation and policy enforcement are separate;
- capture, point, session, and export outcomes are distinct;
- thresholds are versioned;
- unavailable values are explicit;
- overrides preserve the original failure result;
- enforcement requires validation evidence;
- no learned inference can create quality decisions.
