# CAPTURE DEVICE CAPABILITY MATRIX

**Document ID:** EC-V2-SPEC-004  
**Status:** DRAFT_FOR_BASELINE_REVIEW  
**Applies To:** Capture v2.0A and later  
**Gate:** `V2_BASELINE_APPROVAL_PENDING_SPECS_4_TO_6`  
**Depends on:** EC-V2-SPEC-001, EC-V2-SPEC-003  
**Production code:** None

## 1. Purpose

This specification defines how Elektron Capture discovers, records, compares,
and exposes hardware capabilities without assuming that every supported device,
lens, operating-system version, or sensor configuration provides identical
features.

The capability system reports observable device support. It does not infer
hardware behavior from model names alone.

## 2. Governing Rules

1. Every configurable feature must be capability-queried before use.
2. Unsupported controls must not be presented as available.
3. Capability discovery must not modify active capture configuration.
4. Capability records are immutable after creation.
5. Hardware changes create a new capability snapshot.
6. No capability may be inferred solely from an iPhone product model.
7. Runtime capability results override static compatibility tables.

## 3. Core Entities

### `DeviceCapabilitySnapshot`

Required fields:

- `snapshotID`
- `sessionID`
- `deviceID`
- `deviceType`
- `devicePosition`
- `capturedAtMonotonicTimestamp`
- `capturedAtWallClockTimestamp`
- `operatingSystemVersion`
- `applicationVersion`
- `captureFrameworkVersion`
- `activeFormatID`
- `capabilities`
- `snapshotReason`
- `snapshotSchemaVersion`

### `CapabilityValue<T>`

Each capability entry contains:

- `capabilityID`
- `supportState`
- `reportedValue`
- `sourceAPI`
- `queriedAt`
- `failureReason`
- `confidence`

Supported states:

- `SUPPORTED`
- `UNSUPPORTED`
- `UNAVAILABLE_DURING_CURRENT_STATE`
- `QUERY_FAILED`
- `UNKNOWN`

`UNKNOWN` must never be converted to `UNSUPPORTED`.

## 4. Snapshot Reasons

A new immutable snapshot is required when:

- a session begins;
- the active camera changes;
- the active lens changes;
- the active format changes;
- frame-rate configuration changes;
- depth delivery configuration changes;
- an interruption is recovered;
- media services reset;
- an external sensor reconnects;
- the operating system reports a material capability change;
- thermal restriction materially changes available capture modes.

Snapshot history must remain preserved.

## 5. Camera Capability Categories

### 5.1 Device Discovery

Record:

- unique device identifier
- localized device name
- device type
- physical position
- virtual-device membership
- constituent devices
- connected state
- suspended state

### 5.2 Focus

Record support for:

- continuous autofocus
- single autofocus
- locked focus
- lens-position control
- autofocus range restriction
- smooth autofocus
- subject-area monitoring
- minimum focus distance when available

Ranges must include:

- minimum supported value
- maximum supported value
- step or precision information when exposed
- active value at snapshot time

### 5.3 Exposure

Record support for:

- continuous auto exposure
- single auto exposure
- locked exposure
- custom exposure
- exposure target bias
- active ISO
- minimum ISO
- maximum ISO
- active exposure duration
- minimum exposure duration
- maximum exposure duration

### 5.4 White Balance

Record support for:

- continuous automatic white balance
- locked white balance
- temperature/tint conversion
- device-gain control
- supported gain ranges

### 5.5 Format and Frame Rate

For every discoverable format, record:

- media subtype
- dimensions
- supported frame-rate ranges
- field of view
- stabilization modes
- HDR support
- color-space support
- depth support
- highest supported photo dimensions
- video binned state where reported

### 5.6 Photo Output

Record support for:

- RAW capture
- processed capture
- supported codecs
- flash modes
- semantic segmentation mattes
- calibration data delivery
- depth data delivery
- bracketed capture
- quality prioritization modes

Support must only be recorded when exposed by the runtime API.

### 5.7 Spatial and Depth Capabilities

Record:

- depth-capable formats
- depth data types
- calibration-data availability
- intrinsic-matrix availability
- disparity versus depth representation
- filtering support
- LiDAR availability as directly reported by the device

No spatial capability may be inferred from marketing model names.

## 6. External Sensor Capability Records

External sensors use the same capability-value semantics.

Required categories include:

- transport type
- vendor identifier
- product identifier
- firmware version
- measurement channels
- resolution
- unit
- nominal sample rate
- timestamp support
- calibration support
- connection state
- required permissions

## 7. Capability Matrix Presentation

The application may derive a user-facing matrix from snapshots, but the matrix
must preserve the distinction between:

- unsupported;
- temporarily unavailable;
- query failure;
- unknown;
- supported.

The user interface must not collapse these into one generic disabled state
without an accessible reason.

## 8. Required Compatibility Behavior

When a requested feature is unsupported:

1. preserve the requested workflow intent;
2. select only an explicitly authorized fallback;
3. record the fallback;
4. record the unsupported capability;
5. never silently substitute a different capture mode.

## 9. Acceptance Criteria

This specification passes review when:

- all v2.0A controls map to explicit capability entries;
- snapshot creation triggers are defined;
- static model-name assumptions are prohibited;
- fallback decisions are auditable;
- unsupported and unknown remain distinct;
- capability changes cannot overwrite previous snapshots.
