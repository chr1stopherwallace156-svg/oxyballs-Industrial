# Specifications — Elektron Capture v2+

Locked engineering specification suite. **Not** compiled by SPM.  
**No production v2 actor/camera code** until Phase 1 freeze (separate) + IR-0001 measured results + implementation directive.

## Gate status

| Gate | State |
|---|---|
| `V2_CORE_SPECS_1_TO_3_HARDENED` | **Done** |
| Specs 4–6 `DRAFT_FOR_BASELINE_REVIEW` | **Done** (this tip) |
| Cross-spec consistency review | **Done** → `Specifications/V2_SPECS_1_TO_6_CONSISTENCY_REVIEW.md` |
| `V2_SPECIFICATIONS_1_TO_6_BASELINE_APPROVED` | **Declared** (see review) |
| `AUTHORIZED_FOR_IR_0001_EXECUTION` | **Declared** — isolated spike only |
| Phase 1 freeze `v1.0.0-phase1c` | **Pending** (Commit A on freeze-prep branch) |
| Production v2 modules | **Blocked** |

## Authoring order

1. `ELEKTRON_CAPTURE_V2_SPEC.md` — EC-V2-SPEC-001 — `V2_CORE_SPECS_1_TO_3_HARDENED`
2. `CAPTURE_V2_DOMAIN_MODEL.md` — EC-V2-SPEC-002 — `V2_CORE_SPECS_1_TO_3_HARDENED`
3. `CAPTURE_SENSOR_FRAMEWORK.md` — EC-V2-SPEC-003 — `V2_CORE_SPECS_1_TO_3_HARDENED`
4. `CAPTURE_DEVICE_CAPABILITY_MATRIX.md` — EC-V2-SPEC-004 — `DRAFT_FOR_BASELINE_REVIEW`
5. `CAPTURE_TELEMETRY_CONTRACT.md` — EC-V2-SPEC-005 — `DRAFT_FOR_BASELINE_REVIEW`
6. `CAPTURE_QUALITY_POLICY.md` — EC-V2-SPEC-006 — `DRAFT_FOR_BASELINE_REVIEW`
7. `SPATIAL_COORDINATE_SYSTEMS.md` *(pending)*
8. `SPATIAL_EVIDENCE_CONTRACT.md` *(pending)*
9. `EXTERNAL_SENSOR_ADAPTER_CONTRACT.md` *(pending)*
10. `GITHUB_INTEGRATION_REVIEW_TEMPLATE.md` *(template present)*

## Path forward

```text
V2_CORE_SPECS_1_TO_3_HARDENED
V2_BASELINE_APPROVAL_PENDING_SPECS_4_TO_6   ← satisfied by Specs 4–6 + review
        │
        ▼
V2_SPECIFICATIONS_1_TO_6_BASELINE_APPROVED
AUTHORIZED_FOR_IR_0001_EXECUTION
        │
        └── Research/Spikes/IR-0001/  → measured RESULTS.md → v2.0A directive
```

## Branch role

This tip (`cursor/phase1c-evidence-library-d881`) is **Commit B+ staging**.  
Freeze tag `v1.0.0-phase1c` must come from `cursor/phase1c-freeze-commit-a-d881` (Phase 1 only).
