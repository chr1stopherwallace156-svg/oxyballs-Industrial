# Phase 1C — Commit Separation (pointer)

**Authoritative freeze-prep branch (Phase 1 only, no Specs/Research):**  
`cursor/phase1c-freeze-commit-a-d881` @ `c3dea9f8164704c8323d2c539133283bad4d6a18`

This branch (`cursor/phase1c-evidence-library-d881`) holds **Commit B+ staging** only:

- Specs 1–3: `V2_CORE_SPECS_1_TO_3_HARDENED`
- Specs 4–6: `DRAFT_FOR_BASELINE_REVIEW` + consistency review
- Gate: `V2_SPECIFICATIONS_1_TO_6_BASELINE_APPROVED` / `AUTHORIZED_FOR_IR_0001_EXECUTION`
- `Research/Spikes/IR-0001/` (non-production)

**Do not** tag `v1.0.0-phase1c` from this tip. Apply after remote freeze tag confirmation.

Freeze-prep branch (Phase 1 only): `cursor/phase1c-freeze-commit-a-d881`  
Consistency review: `Specifications/V2_SPECS_1_TO_6_CONSISTENCY_REVIEW.md`
