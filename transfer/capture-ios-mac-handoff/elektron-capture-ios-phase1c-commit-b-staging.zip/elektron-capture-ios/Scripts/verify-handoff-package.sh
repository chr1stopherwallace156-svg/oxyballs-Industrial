#!/usr/bin/env bash
# verify-handoff-package.sh — independently verify Handoff/ digests and unpack artifacts.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
OUT="${ROOT}/Handoff"
fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

[[ -d "${OUT}" ]] || fail "Handoff/ missing — run make handoff first"
[[ -f "${OUT}/SHA256SUMS.txt" ]] || fail "SHA256SUMS.txt missing"
[[ -f "${OUT}/HANDOFF.md" ]] || fail "HANDOFF.md missing"
[[ -f "${OUT}/PACKAGE_INVENTORY.json" ]] || fail "PACKAGE_INVENTORY.json missing"
[[ -f "${OUT}/CHANGELOG.md" ]] || fail "CHANGELOG.md missing from handoff"

# No false COMPLETE without pending language in packaged validation
if [[ -f "${OUT}/Docs/Capture/PHASE_1C_FINAL_VALIDATION.md" ]]; then
  if rg -q 'PHASE_1C_COMPLETE[^_]' "${OUT}/Docs/Capture/PHASE_1C_FINAL_VALIDATION.md"; then
    rg -q 'PENDING|Not a completed freeze|PENDING_AUTHORITATIVE' \
      "${OUT}/Docs/Capture/PHASE_1C_FINAL_VALIDATION.md" \
      || fail "packaged validation claims COMPLETE without pending caveats"
  fi
fi

while read -r digest path; do
  [[ -z "${digest:-}" ]] && continue
  f="${OUT}/${path}"
  [[ -f "${f}" ]] || fail "missing ${path}"
  got="$(sha256sum "${f}" | awk '{print $1}')"
  [[ "${got}" == "${digest}" ]] || fail "SHA-256 mismatch for ${path} (got ${got})"
  pass "sha256 ${path}"
done < "${OUT}/SHA256SUMS.txt"

# Unpack latest zip to temp and spot-check identity
ZIP="$(ls -1 "${OUT}/artifacts"/elektron-capture-ios-handoff-*.zip 2>/dev/null | rg -v latest | sort | tail -1 || true)"
[[ -n "${ZIP}" ]] || ZIP="${OUT}/artifacts/elektron-capture-ios-handoff-latest.zip"
[[ -f "${ZIP}" ]] || fail "handoff zip missing"

TMP="$(mktemp -d)"
trap 'rm -rf "${TMP}"' EXIT
unzip -q "${ZIP}" -d "${TMP}"
[[ -f "${TMP}/elektron-capture-ios/HANDOFF_IDENTITY.txt" ]] || fail "HANDOFF_IDENTITY.txt missing in ZIP"
[[ -f "${TMP}/elektron-capture-ios/Package.swift" ]] || fail "Package.swift missing in ZIP"
# ZIP must not claim to be a git repo
if [[ -d "${TMP}/elektron-capture-ios/.git" ]]; then
  fail "ZIP unexpectedly contains .git — freeze/equivalence semantics broken"
fi
pass "ZIP unpack structure"

BUNDLE="$(ls -1 "${OUT}/artifacts"/elektron-capture-ios-handoff-*.bundle 2>/dev/null | rg -v latest | sort | tail -1 || true)"
[[ -n "${BUNDLE}" ]] || BUNDLE="${OUT}/artifacts/elektron-capture-ios-handoff-latest.bundle"
[[ -f "${BUNDLE}" ]] || fail "handoff bundle missing"
git bundle verify "${BUNDLE}" >/dev/null
pass "git bundle verify"

# Mark verified
if [[ -f "${OUT}/STATUS.txt" ]]; then
  if rg -q '^HANDOFF_VERIFIED=' "${OUT}/STATUS.txt"; then
    sed -i 's/^HANDOFF_VERIFIED=.*/HANDOFF_VERIFIED=1/' "${OUT}/STATUS.txt"
  else
    echo "HANDOFF_VERIFIED=1" >> "${OUT}/STATUS.txt"
  fi
fi

echo ""
echo "HANDOFF_VERIFIED"
echo "NOTE: Phase 1C freeze status is unchanged by handoff verification."
