#!/usr/bin/env bash
# generate-handoff.sh — regenerate Handoff/ package + ZIP + Git bundle + digests.
# Completion rule:
# CODE_OR_SPEC + TESTS + EVIDENCE + CHANGELOG + CHANGE_RECORD + HANDOFF_REFRESHED + HASHES_VERIFIED
# = IMPLEMENTATION_COMPLETE
# Else: IMPLEMENTED_PENDING_CHANGE_DOCUMENTATION_AND_HANDOFF
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
info() { echo "==> $*"; }

HANDOFF_ID="${HANDOFF_ID:-}"
OUT="${ROOT}/Handoff"
ART="${OUT}/artifacts"
STAGING="$(mktemp -d)"
trap 'rm -rf "${STAGING}"' EXIT

[[ -f CHANGELOG.md ]] || fail "CHANGELOG.md missing"
[[ -f Docs/Governance/CHANGELOG_AND_HANDOFF_GOVERNANCE.md ]] || fail "governance doc missing"
[[ -f Docs/Handoffs/HANDOFF_HISTORY.md ]] || fail "HANDOFF_HISTORY.md missing"

# Reject stale COMPLETE claims without authoritative freeze language in validation pointer
if rg -q 'PHASE_1C_COMPLETE[^_]' PHASE_1C_FINAL_VALIDATION.md Docs/Capture/PHASE_1C_FINAL_VALIDATION.md 2>/dev/null; then
  if ! rg -q 'PENDING|Not a completed freeze|PENDING_AUTHORITATIVE' Docs/Capture/PHASE_1C_FINAL_VALIDATION.md; then
    fail "PHASE_1C_COMPLETE claimed without pending/freeze caveats — refuse handoff"
  fi
fi

# Placeholder scan in committed validation templates (allow [INSERT] only in template sections)
if rg -n '`VERIFIED_PASS`' Docs/Capture/PHASE_1C_FINAL_VALIDATION.md 2>/dev/null | rg -v 'pre-mark|Do not|without cited|INSERT'; then
  fail "suspicious VERIFIED_PASS presentation in validation record"
fi

BRANCH="$(git branch --show-current 2>/dev/null || echo UNKNOWN)"
COMMIT="$(git rev-parse HEAD)"
COMMIT_SHORT="$(git rev-parse --short HEAD)"
TREE_STATE="clean"
if [[ -n "$(git status --porcelain)" ]]; then
  TREE_STATE="dirty"
  echo "WARN: working tree is dirty — handoff records dirty state; prefer clean commit before release packaging"
fi
REMOTE_URL="$(git remote get-url origin 2>/dev/null || echo NONE)"
UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
if [[ -z "${HANDOFF_ID}" ]]; then
  # Next id from history or default
  LAST="$(rg -o 'HANDOFF-[0-9]+' Docs/Handoffs/HANDOFF_HISTORY.md | head -1 || true)"
  if [[ "${LAST}" =~ HANDOFF-([0-9]+) ]]; then
    NEXT=$((10#${BASH_REMATCH[1]} + 1))
    HANDOFF_ID=$(printf 'HANDOFF-%04d' "${NEXT}")
  else
    HANDOFF_ID="HANDOFF-0028"
  fi
fi

info "Generating ${HANDOFF_ID} @ ${COMMIT_SHORT} (${BRANCH})"

rm -rf "${OUT}"
mkdir -p "${OUT}" "${ART}" \
  "${OUT}/Specifications" \
  "${OUT}/Research" \
  "${OUT}/Docs/Capture" \
  "${OUT}/Docs/Governance" \
  "${OUT}/Docs/Handoffs" \
  "${OUT}/Docs/Changes" \
  "${OUT}/Docs/Evidence"

# --- REPOSITORY_STATE.md ---
cat > "${OUT}/REPOSITORY_STATE.md" <<EOF
# Repository State

| Field | Value |
|------|---------|
| Handoff ID | ${HANDOFF_ID} |
| Generated (UTC) | ${UTC} |
| Branch | \`${BRANCH}\` |
| Commit | \`${COMMIT}\` |
| Working tree | ${TREE_STATE} |
| Remote | \`${REMOTE_URL}\` |
| Host | \`$(uname -s) $(uname -m)\` |

\`\`\`text
$(git status --short || true)
\`\`\`
EOF

# --- VALIDATION_SUMMARY.md ---
TEST_LINE="NOT_RUN_IN_GENERATE"
if command -v swift >/dev/null 2>&1; then
  info "Running swift test for validation summary"
  set +e
  swift test 2>&1 | tee "${STAGING}/swift-test.log" | tail -5
  TEST_RC=${PIPESTATUS[0]}
  set -e
  if [[ ${TEST_RC} -eq 0 ]]; then
    TEST_LINE="$(rg -N 'Executed [0-9]+ tests' "${STAGING}/swift-test.log" | tail -1 || echo 'swift test PASS')"
  else
    TEST_LINE="swift test FAILED (rc=${TEST_RC})"
  fi
else
  TEST_LINE="swift missing — tests not executed in generate-handoff"
fi

PHASE1C_STATUS="$(rg -o 'PHASE_1C_[A-Z0-9_]+' App/Phase1/EvidenceLibrary/EvidenceLibraryModels.swift | rg 'VALIDATION_PASSED|COMPLETE' | head -1 || echo UNKNOWN)"
V2_GATE="BASELINE_APPROVAL_PENDING_FINAL_ARCHITECTURAL_REVIEW"
if rg -q 'BASELINE_APPROVAL_PENDING_FINAL_ARCHITECTURAL_REVIEW' Specifications/README.md 2>/dev/null; then
  V2_GATE="BASELINE_APPROVAL_PENDING_FINAL_ARCHITECTURAL_REVIEW"
fi
PREV_HANDOFF="$(rg -o 'HANDOFF-[0-9]+' Docs/Handoffs/HANDOFF_HISTORY.md | head -1 || echo NONE)"
INCLUDED_CHANGES="$(ls Docs/Changes/CHANGE-*.md 2>/dev/null | xargs -n1 basename 2>/dev/null | sed 's/\.md$//' | paste -sd, -)"
INCLUDED_CHANGES="${INCLUDED_CHANGES:-NONE}"
INCLUDED_PRS="PR#23,PR#24"

cat > "${OUT}/VALIDATION_SUMMARY.md" <<EOF
# Validation Summary

| Gate | Result |
|------|---------|
| \`swift test\` | ${TEST_LINE} |
| Phase 1C status | \`${PHASE1C_STATUS}\` |
| Capture v2 gate | \`${V2_GATE}\` |
| Handoff generation | \`HANDOFF_GENERATED\` (pending \`make handoff-verify\`) |

Phase 1 freeze remains **pending authoritative repository equivalence and tag** —
do not treat this handoff as \`PHASE_1C_COMPLETE\` / \`PHASE_1_FROZEN\`.
EOF

# --- OPEN_ITEMS.md ---
cat > "${OUT}/OPEN_ITEMS.md" <<EOF
# Open Items

1. Authoritative Git clone equivalence vs validated ZIP; fill \`PHASE_1C_FINAL_VALIDATION.md\` digests/evidence.
2. Commit A (Phase 1 only: CHANGELOG + CHANGE-0001 + validation) + annotated tag \`v1.0.0-phase1c\` + remote confirm + GitHub protection → \`PHASE_1_FROZEN\`.
3. After remote tag: merge/apply Commit B (Specs, CHANGE-0002, handoff governance) — never into the freeze tag.
4. Specs final architectural review → future \`CHANGE-0003\` → then \`AUTHORIZED_FOR_IR_0001_EXECUTION\`.
5. Execute isolated IR-0001 on device; fill \`Research/Spikes/IR-0001/RESULTS.md\`.
EOF

# --- Copy docs ---
cp -f CHANGELOG.md "${OUT}/CHANGELOG.md"
cp -f Docs/Governance/CHANGELOG_AND_HANDOFF_GOVERNANCE.md "${OUT}/Docs/Governance/"
cp -f Docs/Handoffs/HANDOFF_HISTORY.md "${OUT}/Docs/Handoffs/"
cp -f Docs/Changes/*.md "${OUT}/Docs/Changes/" 2>/dev/null || true
cp -f Docs/Capture/PHASE_1C_FINAL_VALIDATION.md "${OUT}/Docs/Capture/" 2>/dev/null || true
cp -f Docs/Capture/PHASE_1C_FREEZE_COMMIT_SEPARATION.md "${OUT}/Docs/Capture/" 2>/dev/null || true
cp -f Docs/Capture/PHASE_1_FREEZE.md "${OUT}/Docs/Capture/" 2>/dev/null || true
cp -f PHASE_1C_FINAL_VALIDATION.md "${OUT}/" 2>/dev/null || true
cp -f CURSOR_OPERATING_RULES.md "${OUT}/" 2>/dev/null || true

if [[ -d Specifications ]]; then
  cp -f Specifications/*.md "${OUT}/Specifications/" 2>/dev/null || true
fi
if [[ -d Research ]]; then
  mkdir -p "${OUT}/Research/Spikes/IR-0001" "${OUT}/Research/IntegrationReports" "${OUT}/Research/Deferred/SemanticMattes"
  cp -f Research/README.md "${OUT}/Research/" 2>/dev/null || true
  cp -f Research/IntegrationReports/*.md "${OUT}/Research/IntegrationReports/" 2>/dev/null || true
  cp -f Research/Spikes/IR-0001/*.md "${OUT}/Research/Spikes/IR-0001/" 2>/dev/null || true
  cp -f Research/Deferred/SemanticMattes/README.md "${OUT}/Research/Deferred/SemanticMattes/" 2>/dev/null || true
fi

# --- PACKAGE_INVENTORY.json (handoff package files before zip/bundle) ---
python3 - <<'PY' "${OUT}"
import json, os, sys, hashlib
from pathlib import Path
out = Path(sys.argv[1])
entries = []
for p in sorted(out.rglob("*")):
    if p.is_file() and "artifacts" not in p.parts:
        rel = str(p.relative_to(out)).replace("\\", "/")
        data = p.read_bytes()
        entries.append({
            "path": rel,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        })
inv = {
    "schemaVersion": "1.0.0",
    "packageKind": "elektron-capture-ios-handoff",
    "fileCount": len(entries),
    "files": entries,
}
(out / "PACKAGE_INVENTORY.json").write_text(json.dumps(inv, indent=2) + "\n")
print(f"inventory files={len(entries)}")
PY

# --- Source ZIP (working tree snapshot, no .git/.build) ---
info "Creating source ZIP"
ZIP_NAME="elektron-capture-ios-handoff-${COMMIT_SHORT}.zip"
BUNDLE_NAME="elektron-capture-ios-handoff-${COMMIT_SHORT}.bundle"
SRC_STAGE="${STAGING}/elektron-capture-ios"
mkdir -p "${SRC_STAGE}"
git archive --format=tar --prefix=elektron-capture-ios/ HEAD | tar -x -C "${STAGING}"
# Include dirty CHANGELOG/governance if dirty? Prefer HEAD-only for reproducibility.
# Stamp identity into snapshot
cat > "${SRC_STAGE}/HANDOFF_IDENTITY.txt" <<EOF
HANDOFF_ID=${HANDOFF_ID}
CAPTURE_TIP=${COMMIT}
CAPTURE_BRANCH=${BRANCH}
TREE_STATE=${TREE_STATE}
GENERATED_UTC=${UTC}
NOTE=ZIP has no .git. Use companion .bundle for authoritative clone. Phase 1 freeze still pending.
EOF
# Also copy freshly generated Handoff docs into snapshot under Handoff/
mkdir -p "${SRC_STAGE}/Handoff"
rsync -a --exclude artifacts "${OUT}/" "${SRC_STAGE}/Handoff/" 2>/dev/null || \
  (cd "${OUT}" && tar cf - --exclude=artifacts . | tar xf - -C "${SRC_STAGE}/Handoff")

(cd "${STAGING}" && zip -rq "${ART}/${ZIP_NAME}" elektron-capture-ios)
cp -f "${ART}/${ZIP_NAME}" "${ART}/elektron-capture-ios-handoff-latest.zip"

# --- Git bundle ---
info "Creating Git bundle"
git bundle create "${ART}/${BUNDLE_NAME}" HEAD "${BRANCH}" 2>/dev/null || \
  git bundle create "${ART}/${BUNDLE_NAME}" HEAD
cp -f "${ART}/${BUNDLE_NAME}" "${ART}/elektron-capture-ios-handoff-latest.bundle"

ZIP_SHA="$(sha256sum "${ART}/${ZIP_NAME}" | awk '{print $1}')"
BUNDLE_SHA="$(sha256sum "${ART}/${BUNDLE_NAME}" | awk '{print $1}')"
INV_SHA="$(sha256sum "${OUT}/PACKAGE_INVENTORY.json" | awk '{print $1}')"

# --- SHA256SUMS.txt ---
{
  echo "${ZIP_SHA}  artifacts/${ZIP_NAME}"
  echo "${ZIP_SHA}  artifacts/elektron-capture-ios-handoff-latest.zip"
  echo "${BUNDLE_SHA}  artifacts/${BUNDLE_NAME}"
  echo "${BUNDLE_SHA}  artifacts/elektron-capture-ios-handoff-latest.bundle"
  echo "${INV_SHA}  PACKAGE_INVENTORY.json"
} > "${OUT}/SHA256SUMS.txt"

# Independent verify digests just written
while read -r digest path; do
  [[ -z "${digest:-}" ]] && continue
  f="${OUT}/${path}"
  [[ -f "${f}" ]] || fail "missing ${path}"
  got="$(sha256sum "${f}" | awk '{print $1}')"
  [[ "${got}" == "${digest}" ]] || fail "digest mismatch ${path}"
done < "${OUT}/SHA256SUMS.txt"
info "All SHA256SUMS digests independently verified"

# --- HANDOFF.md ---
cat > "${OUT}/HANDOFF.md" <<EOF
# ${HANDOFF_ID} — Elektron Capture iOS Handoff

| Field | Value |
|------|---------|
| handoffID | \`${HANDOFF_ID}\` |
| generatedAt | ${UTC} |
| sourceCommit | \`${COMMIT}\` |
| sourceBranch | \`${BRANCH}\` |
| workingTreeState | ${TREE_STATE} |
| previousHandoffID | \`${PREV_HANDOFF}\` |
| changeRange | tip \`${COMMIT_SHORT}\` (see git log / CHANGELOG [Unreleased]) |
| includedChangeIDs | \`${INCLUDED_CHANGES}\` |
| includedPRs | \`${INCLUDED_PRS}\` |
| projectStatus | Phase1C=\`${PHASE1C_STATUS}\`; v2=\`${V2_GATE}\` |
| validationStatus | ${TEST_LINE} |
| Status | \`HANDOFF_GENERATED\` (run \`make handoff-verify\` → \`HANDOFF_VERIFIED\`) |

## What changed?

See \`CHANGELOG.md\` [Unreleased] and \`Docs/Handoffs/HANDOFF_HISTORY.md\` (${HANDOFF_ID}).

## Why did it change?

Phase 1C Evidence Library hardening, Canonical Identity path keys, Commit A/B freeze
isolation, Capture v2 Specs 1–6 correction pass (\`CHANGE-0002\`, not baseline-approved),
and permanent changelog/handoff completion rules.

## When did it change?

${UTC} (handoff generation). Underlying commits through \`${COMMIT_SHORT}\`.

## Which files changed?

See git history ending at \`${COMMIT}\` and \`PACKAGE_INVENTORY.json\` for packaged paths.

## Which contracts or behaviors changed?

- Package-relative path Canonical Identity (\`PackageRelativePath\`)
- Phase 1C Evidence Library Hashable / persistence model
- Freeze Commit A/B separation (no v2 specs / no CHANGE-0002 in \`v1.0.0-phase1c\`)
- Specs EC-V2-SPEC-001…006 (draft; \`NOT_BASELINE_APPROVED\`)
- Changelog + handoff governance (this package)

## Which commit and PR contain it?

- Capture commit: \`${COMMIT}\`
- Industrial delivery: PR #23 (merged), PR #24 (changelog/governance); refresh this handoff into \`transfer/capture-ios-mac-handoff/\`

## What was tested?

${TEST_LINE}

## What evidence was produced?

- This \`Handoff/\` tree
- Source ZIP SHA-256: \`${ZIP_SHA}\`
- Git bundle SHA-256: \`${BUNDLE_SHA}\`
- Inventory SHA-256: \`${INV_SHA}\`

## artifactHashes

| Artifact | SHA-256 |
|----------|---------|
| \`${ZIP_NAME}\` | \`${ZIP_SHA}\` |
| \`${BUNDLE_NAME}\` | \`${BUNDLE_SHA}\` |
| \`PACKAGE_INVENTORY.json\` | \`${INV_SHA}\` |

Full list: \`SHA256SUMS.txt\`.

## remainingGates

See \`OPEN_ITEMS.md\`. Phase 1C is **not** frozen. Specs are **not** baseline-approved.

## What must the next person do?

1. \`make handoff-verify\` (or consume Industrial transfer copy)
2. Clone the **bundle** for authoritative git work (ZIP has no \`.git\`)
3. Equivalence check → fill validation → Commit A (CHANGE-0001) → tag \`v1.0.0-phase1c\` → push → protect
4. After remote tag: Commit B (CHANGE-0002 + Specs); IR-0001 only after future \`CHANGE-0003\`

## Governance

\`Docs/Governance/CHANGELOG_AND_HANDOFF_GOVERNANCE.md\`

\`\`\`text
NO CHANGE WITHOUT CHANGELOG
NO COMPLETION WITHOUT HANDOFF
NO HANDOFF WITHOUT VERIFIED HASHES
NO RELEASE WITHOUT AUTHORITATIVE TAG
\`\`\`
EOF

# --- STATUS.txt ---
cat > "${OUT}/STATUS.txt" <<EOF
HANDOFF_ID=${HANDOFF_ID}
HANDOFF_GENERATED=1
HANDOFF_VERIFIED=0
PHASE_1C_STATUS=${PHASE1C_STATUS}
V2_GATE=${V2_GATE}
COMMIT=${COMMIT}
BRANCH=${BRANCH}
TREE_STATE=${TREE_STATE}
ZIP_SHA256=${ZIP_SHA}
BUNDLE_SHA256=${BUNDLE_SHA}
EOF

# Append history if this ID not already present
if ! rg -q "^## ${HANDOFF_ID} " Docs/Handoffs/HANDOFF_HISTORY.md; then
  PREV="$(rg -o 'HANDOFF-[0-9]+' Docs/Handoffs/HANDOFF_HISTORY.md | head -1 || echo NONE)"
  DATE_UTC="${UTC%%T*}"
  HANDOFF_ID="${HANDOFF_ID}" PREV="${PREV}" COMMIT="${COMMIT}" BRANCH="${BRANCH}" \
  ZIP_SHA="${ZIP_SHA}" BUNDLE_SHA="${BUNDLE_SHA}" TEST_LINE="${TEST_LINE}" DATE_UTC="${DATE_UTC}" \
  python3 - <<'PY'
import os
from pathlib import Path
path = Path("Docs/Handoffs/HANDOFF_HISTORY.md")
text = path.read_text()
hid = os.environ["HANDOFF_ID"]
entry = f"""## {hid} — {os.environ['DATE_UTC']}

- Previous handoff: {os.environ['PREV']}
- Capture tip: `{os.environ['COMMIT']}` (`{os.environ['BRANCH']}`)
- Summary: Regenerated handoff package via `make handoff` / `Scripts/generate-handoff.sh`.
- ZIP SHA-256: `{os.environ['ZIP_SHA']}`
- Bundle SHA-256: `{os.environ['BUNDLE_SHA']}`
- Validation: {os.environ['TEST_LINE']}
- Remaining gate: Phase 1C Commit A + remote tag; Specs final architectural review (CHANGE-0003 later).

---

"""
marker = "---\n"
idx = text.find(marker)
if idx >= 0:
    idx_end = idx + len(marker)
    text = text[:idx_end] + "\n" + entry + text[idx_end:].lstrip("\n")
else:
    text = text.rstrip() + "\n\n" + entry
path.write_text(text)
print("history appended", hid)
PY
  cp -f Docs/Handoffs/HANDOFF_HISTORY.md "${OUT}/Docs/Handoffs/HANDOFF_HISTORY.md"
fi

echo ""
echo "HANDOFF_GENERATED ${HANDOFF_ID}"
echo "ZIP_SHA256=${ZIP_SHA}"
echo "BUNDLE_SHA256=${BUNDLE_SHA}"
echo "Artifacts: ${ART}/${ZIP_NAME}"
echo "Next: make handoff-verify"
