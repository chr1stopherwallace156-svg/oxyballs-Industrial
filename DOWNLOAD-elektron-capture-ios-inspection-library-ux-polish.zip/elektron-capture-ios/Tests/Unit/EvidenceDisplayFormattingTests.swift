import XCTest
@testable import ElektronCapture

final class EvidenceDisplayFormattingTests: XCTestCase {
  func testLocalDateTimeFromDateIsStableLocale() {
    let date = Date(timeIntervalSince1970: 1_753_449_600) // 2025-07-25T16:00:00Z approx window
    let text = EvidenceDisplayFormatting.localDateTime(from: date)
    XCTAssertFalse(text.isEmpty)
    XCTAssertFalse(text.contains("T"))
  }

  func testLocalDateTimeFromISO8601() {
    let text = EvidenceDisplayFormatting.localDateTime(fromISO8601: "2026-07-25T18:20:00Z")
    XCTAssertFalse(text.contains("T"))
    XCTAssertNotEqual(text, "2026-07-25T18:20:00Z")
  }

  func testInspectionStatusLabels() {
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel("IN_PROGRESS"), "In Progress")
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel("COMPLETED"), "Completed")
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel("CANCELED"), "Canceled")
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel("PAUSED"), "Paused")
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel(nil), "Unknown")
  }

  func testVINClassifyKind() {
    XCTAssertEqual(VehicleIdentifier.classifyKind(from: "1HGCM82633A004352"), .vin)
    XCTAssertEqual(VehicleIdentifier.classifyKind(from: " 1hgcm82633a004352 "), .vin)
    XCTAssertEqual(VehicleIdentifier.classifyKind(from: "1HGCM82633A00435O"), .unknown)
    XCTAssertEqual(VehicleIdentifier.classifyKind(from: "SHORT"), .unknown)
  }
}
