import Foundation

/// UI-facing display helpers. Does not alter canonical evidence JSON or hashes.
public enum EvidenceDisplayFormatting {
  /// Formats a `Date` for Evidence Library UI (local medium date + short time).
  public static func localDateTime(from date: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "en_US_POSIX")
    f.dateStyle = .medium
    f.timeStyle = .short
    return f.string(from: date)
  }

  /// Parses ISO-8601 evidence timestamps for display; falls back to the raw string.
  public static func localDateTime(fromISO8601 string: String) -> String {
    let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { return "—" }
    let fractional = ISO8601DateFormatter()
    fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    let plain = ISO8601DateFormatter()
    plain.formatOptions = [.withInternetDateTime]
    if let date = fractional.date(from: trimmed) ?? plain.date(from: trimmed) {
      return localDateTime(from: date)
    }
    return trimmed
  }

  /// Human-readable inspection / session status for UI labels.
  public static func inspectionStatusLabel(_ raw: String?) -> String {
    guard let raw, !raw.isEmpty else { return "Unknown" }
    if let status = SessionStatus(rawValue: raw) {
      return status.displayName
    }
    return raw
      .replacingOccurrences(of: "_", with: " ")
      .capitalized
  }
}

extension SessionStatus {
  public var displayName: String {
    switch self {
    case .inProgress: return "In Progress"
    case .paused: return "Paused"
    case .completed: return "Completed"
    case .canceled: return "Canceled"
    }
  }
}
