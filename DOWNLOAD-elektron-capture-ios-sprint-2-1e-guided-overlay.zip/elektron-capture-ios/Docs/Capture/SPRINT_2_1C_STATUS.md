# Sprint 2.1C — Formal Workflow Engine & State Machine

| Field | Value |
|---|---|
| **Status** | `SPRINT_2_1C_COMPLETE` (Linux `swift test`; Mac `xcodebuild` NOT RUN on this host) |
| **Branch** | `cursor/sprint-2-1c-progression-state-machine-d881` |
| **Baseline** | Sprint 2.1B session envelope (`schemaVersion` = `v1`) |
| **Next** | Sprint 2.1D — evidence-to-point binding (only when prompted) |

## Architecture

```text
Presentation (not this sprint)
        │ observes / triggers
        ▼
InspectionProgressionEngine   ◄── sole mutation path (stateless; no .shared)
        │ returns updated session
        ▼
InspectionSession.progress: InspectionProgressState?
        │ identities/order from frozen snapshot only
        ▼
InspectionSessionEnvelope (2.1B, still v1 — Option A)
```

## New domain types

| Type | Persisted facts |
|---|---|
| `InspectionPointStatus` | `notStarted` / `inProgress` / `completed` / `skipped(reason)` / `blocked(reason)` |
| `InspectionPointProgress` | `pointID` + `status` only |
| `InspectionProgressState` | `orderedPoints` + `activePointID` |
| `InspectionCompletionDisposition` | **Derived only** — `.incomplete` / `.complete` / `.blocked` |
| `InspectionProgressionEngine` | Stateless value type; session-in → session-out |
| `InspectionProgressionError` | Strongly typed guardrails |

**Not persisted (derived or reserved for 2.1D):** `isComplete`, `isSatisfied`, array indexes as public identity, `completedCaptures` / evidence counts.

## Engine operations

- `initializeProgress(for:)`
- `activate(pointID:in:)`
- `advanceToNextEligiblePoint(in:)`
- `returnToPreviousEligiblePoint(in:)`
- `completeActivePoint(in:)`
- `skipActivePoint(reason:in:)`
- `blockActivePoint(reason:in:)`
- `evaluateCompletion(of:)` → `InspectionCompletionDisposition`

Rules:

- Point identities and order come only from the session’s frozen `InspectionPlanSnapshot` (never `InspectionPlanRegistry`).
- Duplicate / unknown / snapshot-mismatched progress throws.
- Skip/block reasons must be non-empty after trim.
- `advanceToNextEligiblePoint` does **not** implicitly complete, skip, or block.
- Required `blocked` → disposition `.blocked` (prevents successful normal completion).
- `InspectionSession.assigning` leaves `progress == nil`; initialization is explicit and idempotent.
- Legacy-unassigned sessions cannot initialize progression (no fabricated points).

## Persistence Version Policy — **Option A**

**Choice:** Treat `InspectionSession.progress` as a **backward-compatible additive `v1` field**.

**Justification:** Existing `v1` decoding already uses `decodeIfPresent` for `progress`. Older envelopes without the key decode as `progress == nil`. The wire format remains materially compatible with Sprint 2.1B `v1` — introducing `v2` solely because progression exists would violate the “meaningful migrations only” rule. Decode also tolerates earlier 2.1C tip field names (`pointsProgress` / `pointProgress` / `currentPointIndex`) by mapping them into `orderedPoints` + `activePointID`.

`InspectionSessionSchemaVersion.current` remains **`v1`**.

## Reactivation Policy — **Strictly terminal**

**Choice:** `completed`, `skipped`, and `blocked` are **strictly terminal**. There is **no** `reactivatePoint` API.

**Justification:** Forcing a reopen surface would dictate product behavior that is not yet required. Terminal transitions stay authoritative; reopening (if ever needed) can be introduced as an explicit product decision with its own errors/tests. Navigation that would activate a terminal point throws `pointIsTerminal`.

## Modified files

| Path | Change |
|---|---|
| `App/Domain/Models/InspectionProgression.swift` | Slim progress types; Option A Codable |
| `App/Domain/Services/InspectionProgressionEngine.swift` | Stateless ID-based engine |
| `App/Domain/Models/InspectionSession.swift` | Optional `progress`; assigning leaves `nil` |
| `Tests/Unit/Sprint2_1CTests.swift` | Dedicated 2.1C suite |
| `Docs/Capture/SPRINT_2_1C_STATUS.md` | This status report |

## Test suite summary

| Suite | Result |
|---|---|
| `Sprint2_1CTests` | **19** executed, **0** failures |
| Full package (`swift test`) | **214** executed, **1** skipped, **0** failures |
| Mac `xcodebuild` | **NOT RUN** (Linux host) |

Coverage includes: ID-targeted progression; unknown/duplicate/mismatch rejection; whitespace skip/block rejection; advance without implicit terminal transitions; blocked required → `.blocked`; derived completion; `activePointID` persistence (not index); Option A older `v1` decode; legacy-unassigned no fabrication; idempotent init; strictly terminal policy; no `.shared`.

## Boundary confirmations

| Check | Result |
|---|---|
| UI / SwiftUI files modified | **0** |
| Camera / AVFoundation / ARKit / LiDAR | **0** |
| Evidence frame / file binding (2.1D) | **not started** |
| Evidence Library (2.1F) | **not started** |
| Bootstrap / workspace scripts | **0** |

## Execution

```text
Host: Linux (Swift 5.10.1)
Command: swift test
Result: 214 executed, 1 skipped, 0 failures
Sprint2_1CTests: 19 / 19 passed
xcodebuild: NOT RUN
```
