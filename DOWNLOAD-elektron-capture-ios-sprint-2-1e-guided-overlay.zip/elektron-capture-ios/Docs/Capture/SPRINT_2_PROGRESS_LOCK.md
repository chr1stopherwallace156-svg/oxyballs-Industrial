# Sprint 2 — Inspection Progress Lock (Frozen)

| Field | Value |
|---|---|
| **Status** | `FROZEN` — record only; not implemented |
| **Frozen at** | `2026-07-25T21:59:00Z` |
| **Depends on** | Sprint 1.1.1 Mac + physical validation + tag `v1.1.1-schema-compatibility-validated` |
| **Implement in** | **Sprint 2.2** (not 2.0 / 2.1 / 2.3) |
| **Roadmap** | `Docs/Capture/SPRINT_2_ROADMAP.md` |

## Primary rule

Primary inspection progress is based on **accepted required inspection points only**.

Captured-but-unaccepted points may appear in a **secondary** capture-progress metric, but they do **not** count toward completion.

```swift
state.status == .accepted
```

```swift
public var isComplete: Bool {
  status == .accepted
}

public var hasCapture: Bool {
  status == .captured || status == .accepted
}
```

## Two separate metrics

```text
Captured:  N / R required points have at least one capture   (secondary)
Accepted:  M / R required points are complete               (primary)
```

Primary completion / progress bar copy:

```text
M / R Required Points Complete
```

Do **not** label primary progress “Required Photos”. Future points may require multi-photo, video, document, LiDAR, or non-photo evidence.

## Status semantics

| Status | Required-point completion | Notes |
|---|---|---|
| `.accepted` | **Complete** | Only status that advances primary progress |
| `.captured` | Incomplete | Attempt exists; not approved / packaged as point completion |
| `.awaitingCapture` / `.notStarted` | Incomplete | |
| `.rejected` | Incomplete | Remains incomplete even with several attempts |
| `.skipped` | Does **not** satisfy a required point | |
| `.notApplicable` | Satisfies only after an **explicit** applicability decision on a conditional point | |
| Optional points (`isRequired == false`) | Excluded from required completion percentage | |

## Alignment with Sprint 1.1

Sprint 1.1 locked `captureCount` to increment only after successful approve-and-persist. Counting `.captured` toward required progress would diverge from persisted evidence count and integrity boundaries.

A `.captured` photo is a local attempt/preview path until the inspector approves; only then does cryptographic hashing, packaging, and persistence complete for that accepted evidence.

## Sprint sequencing (gate)

| Sprint | Scope | Gate |
|---|---|---|
| **1.1.1** | UX polish, VIN heuristic, schema fixtures | `IMPLEMENTED_AND_LINUX_VERIFIED` · formal Mac + physical tag still required |
| **2.0** | Plans, points, registry, immutable snapshot + hash, minimal plan UI | **BLOCKED** until 1.1.1 validated tag |
| **2.1** | Session ↔ snapshot wiring; additive evidence plan metadata | After 2.0 validate; **no** checklist UI |
| **2.2** | `InspectionPointState`, dual metrics, guided checklist UI | Implements **this** lock |
| **2.3** | Guided camera context UI (no AR) | After 2.2 |

## Architecture reminder (definitions vs execution)

```text
[ InspectionPlan ] (immutable template)          ← 2.0
        │
        ▼
[ InspectionPoint ] (definition only)            ← 2.0
        │
        ▼
[ InspectionPlanSnapshot + hash ]                ← 2.0
        │
        ▼
[ InspectionSession ] (frozen snapshot ref)      ← 2.1
        │
        ▼
[ InspectionPointState ]                         ← 2.2
        │
        ▼
[ CaptureAttempt ] → [ Approved Evidence ]
```

Do not retag or move `v1.1.0-inspection-grouping-validated`. Do not claim Sprint 2 progress implementation until Sprint 2.2.
