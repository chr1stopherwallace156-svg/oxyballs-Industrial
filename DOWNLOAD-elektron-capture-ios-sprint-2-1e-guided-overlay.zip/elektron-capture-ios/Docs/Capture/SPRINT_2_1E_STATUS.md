# Sprint 2.1E — Guided Capture Overlay Controls & Guidance UI

| Field | Value |
|---|---|
| **Status** | `SPRINT_2_1E_COMPLETE` (Linux `swift test`; Mac/device walkthrough NOT RUN on this host) |
| **Branch** | `cursor/sprint-2-1e-guided-overlay-d881` |
| **Baseline** | Sprint 2.1D evidence binding |
| **Next** | Sprint 2.1F — hierarchical Evidence Library (only when prompted) |
| **Device protocol** | `Docs/Capture/SPRINT_2_1E_TECHNICIAN_WALKTHROUGH.md` |

## Architecture (Intent → Coordinator + ephemeral UI)

```text
AVCaptureVideoPreviewLayer          ← foundational camera surface (untouched)
   └─ GuidedInspectionOverlayView   ← semi-transparent HUD
            │ UI actions
            ▼
GuidedInspectionViewModel
   ├─ presentation: GuidedInspectionPresentationState  (derived from domain)
   └─ ui: GuidedInspectionUIState                      (ephemeral — never persisted)
            │ GuidedInspectionIntent
            ▼
GuidedInspectionCoordinator
   ├── InspectionProgressionEngine
   └── EvidenceBindingService  → constructs EvidenceMetadata + storage keys
            │
            ▼
InspectionSessionService.applyUpdatedSession → persisted InspectionSession
```

## Key refinements

### 1. `GuidedInspectionUIState` isolation

Ephemeral only: `showingSkipDialog`, `showingBlockDialog`, `captureInProgress`, `alert`, `draftSkipReason`, `draftBlockReason`.

Never encoded on `InspectionSession` / `InspectionProgressState`.

### 2. Camera-as-surface HUD

Overlay is a HUD over the existing preview `ZStack`. No `AVCaptureSession` / warm-up / permission changes.

### 3. Domain-driven enablement

- **Complete** requires evidence satisfaction on the active open point
- **Next** stays disabled until satisfied **or** terminal, and a non-terminal successor exists
- Capture in-flight sets `ui.captureInProgress` and locks HUD controls

## Modified / new files

| Path | Role |
|---|---|
| `App/Domain/Services/GuidedInspectionPresentation.swift` | Intents, UIState, presentation |
| `App/Domain/Services/GuidedInspectionPresenter.swift` | Satisfaction-gated enablement + HUD labels |
| `App/Domain/Services/GuidedInspectionCoordinator.swift` | Intent orchestration |
| `Apps/Phase1StillCapture/GuidedInspection*.swift` | Thin VM + HUD |
| `Apps/Phase1StillCapture/Phase1CaptureRootView.swift` | HUD layering + bind-on-approve |
| `Tests/Unit/Sprint2_1ETests.swift` | Linux coordinator/presenter suite |
| `Docs/Capture/SPRINT_2_1E_TECHNICIAN_WALKTHROUGH.md` | Device verification protocol |

## Boundary confirmations

| Check | Result |
|---|---|
| AVCaptureSession / permission / warm-up modified | **0** |
| `GuidedInspectionUIState` persisted on session | **0** |
| View constructs `EvidenceMetadata` | **0** |
| Sprint 2.1F started | **no** |

## Backlog (post-2.1)

Explicit `EvidenceRequirement` on plan snapshot (replace inferred multiPhoto→2).

## Test suite summary

| Suite | Result |
|---|---|
| `Sprint2_1ETests` | **11** executed, **0** failures |
| Full package (`swift test`) | **236** executed, **1** skipped, **0** failures |
| Mac / device walkthrough | **NOT RUN** (operator protocol documented) |

## Execution

```text
Host: Linux (Swift 5.10.1)
Command: swift test
Result: 236 executed, 1 skipped, 0 failures
Sprint2_1ETests: 11 / 11 passed
xcodebuild / technician walkthrough: NOT RUN
```
