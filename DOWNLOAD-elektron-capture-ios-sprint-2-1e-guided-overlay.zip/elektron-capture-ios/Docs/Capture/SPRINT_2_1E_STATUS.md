# Sprint 2.1E — Guided Capture Overlay Controls & Guidance UI

| Field | Value |
|---|---|
| **Status** | `SPRINT_2_1E_COMPLETE` (Linux `swift test`; Mac `xcodebuild` NOT RUN on this host) |
| **Branch** | `cursor/sprint-2-1e-guided-overlay-d881` |
| **Baseline** | Sprint 2.1D evidence binding |
| **Next** | Sprint 2.1F — hierarchical Evidence Library (only when prompted) |

## Architecture (Intent → Coordinator)

```text
GuidedInspectionOverlayView
        │ emits UI actions
        ▼
GuidedInspectionViewModel (@MainActor)
        │ GuidedInspectionIntent
        ▼
GuidedInspectionCoordinator
        ├── InspectionProgressionEngine
        └── EvidenceBindingService  → constructs EvidenceMetadata + storage keys
                │
                ▼
        InspectionSessionService.applyUpdatedSession
                │
                ▼
        InspectionSession (persisted)
```

**Strict boundary:** SwiftUI / ViewModel never construct `EvidenceMetadata` or storage keys.

## New / modified types

| Type | Layer | Role |
|---|---|---|
| `GuidedInspectionIntent` | Package | Discrete intents |
| `GuidedInspectionPresentationError` | Package | Typed UI-mappable errors |
| `GuidedInspectionPresentationState` | Package | Derived enablement + point chrome |
| `GuidedInspectionPresenter` | Package | Pure derivation from session/snapshot |
| `GuidedInspectionCoordinator` | Package | Intent orchestration |
| `GuidedInspectionViewModel` | App | Thin presentation & delegation |
| `GuidedInspectionOverlayView` | App | Overlay on live preview |
| `AppSessionContainer` | App | Owns inspection + guided VMs |

## Camera / AVFoundation

- Overlay layers onto existing `previewStage` `ZStack`.
- Still capture continues via `Phase1CaptureViewModel.takePhoto()` → `InteractiveStillCaptureController.capturePendingStill()`.
- **Not modified:** `Phase1CameraServices.swift`, `CameraPreviewView.swift`, Info.plist camera permission, warm-up / shutter gating.

## Session plan assignment fix

`InspectionSessionViewModel.start` now passes `selectedPlanSnapshot` into `startInspection`, so new sessions are plan-assigned (required for guided progression).

## Modified files

| Path | Change |
|---|---|
| `App/Domain/Services/GuidedInspectionPresentation.swift` | Intents / errors / presentation state |
| `App/Domain/Services/GuidedInspectionPresenter.swift` | Derived enablement |
| `App/Domain/Services/GuidedInspectionCoordinator.swift` | Intent handler |
| `App/Phase1/Inspection/InspectionSessionService.swift` | `applyUpdatedSession` |
| `Apps/Phase1StillCapture/*` | Overlay + VM + wiring + pbxproj |
| `Tests/Unit/Sprint2_1ETests.swift` | Coordinator/presenter suite |
| `Docs/Capture/SPRINT_2_1E_STATUS.md` | This report |
| `Docs/Capture/SPRINT_2_ROADMAP.md` | 2.1E marked |

## Backlog note (not in 2.1E)

Explicit `EvidenceRequirement` on plan snapshot (replace inferred `multiPhoto→2` / default→1) remains a **post-2.1** backlog item.

## Test suite summary

| Suite | Result |
|---|---|
| `Sprint2_1ETests` | **9** executed, **0** failures |
| Full package (`swift test`) | **234** executed, **1** skipped, **0** failures |
| Mac `xcodebuild` / device | **NOT RUN** |

## Boundary confirmations

| Check | Result |
|---|---|
| AVCaptureSession / permission / warm-up modified | **0** |
| Evidence Library hierarchy UI (2.1F) | **not started** |
| Binary re-encode of JPEG/HEIC | **0** |
| View constructs `EvidenceMetadata` | **0** (coordinator only) |

## Execution

```text
Host: Linux (Swift 5.10.1)
Command: swift test
Result: 234 executed, 1 skipped, 0 failures
Sprint2_1ETests: 9 / 9 passed
xcodebuild: NOT RUN
```
