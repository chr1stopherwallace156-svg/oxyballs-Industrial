# Sprint 2 Roadmap — Inspection Plans (Record Only)

| Field | Value |
|---|---|
| **Status** | `2.1E IMPLEMENTED` — see `Docs/Capture/SPRINT_2_1E_STATUS.md` |
| **Gate** | Sprint 1.1.1 validated tag on Industrial `origin` |
| **2.0 status** | `Docs/Capture/SPRINT_2_0_STATUS.md` |
| **2.1A status** | `Docs/Capture/SPRINT_2_1A_STATUS.md` (immutable plan assignment on session) |
| **2.1B status** | `Docs/Capture/SPRINT_2_1B_STATUS.md` (versioned session envelope + store) |
| **2.1C status** | `Docs/Capture/SPRINT_2_1C_STATUS.md` (guided progression state machine) |
| **2.1D status** | `Docs/Capture/SPRINT_2_1D_STATUS.md` (evidence-to-point binding metadata) |
| **2.1E status** | `Docs/Capture/SPRINT_2_1E_STATUS.md` (guided overlay Intent–Coordinator UI) |
| **Progress lock** | `Docs/Capture/SPRINT_2_PROGRESS_LOCK.md` (S2-001) |
| **Snapshot hash lock** | `Docs/Capture/SPRINT_2_SNAPSHOT_HASH_LOCK.md` (S2-002) |

Do **not** begin Sprint 2 coding because the app launches. Finish formal 1.1.1 Mac validation and the validated tag first.

---

## Milestone map

```text
2.0 Foundation (plans + immutable snapshots)
        │
        ▼
2.1 Session assignment + additive evidence metadata
        │
        ▼  STOP · validate
2.2 Guided workflow (PointState + S2-001 progress)
        │
        ▼
2.3 Guided camera (context-aware capture UI; no AR yet)
        │
        ▼
Sprint 3+  AR / LiDAR / quality / Plan Builder (JSON-loaded plans)
```

---

## Sprint 2.0 — Inspection Plans (Foundation)

**Question answered:** *What inspection is this inspector supposed to perform?*

Implement (narrow scope):

- `InspectionPlan`, `InspectionPoint`
- `InspectionPlanRegistry` (seed templates; e.g. commercial intake, quick 4-point)
- immutable `InspectionPlanSnapshot` + `InspectionPlanSnapshotPayload`
- typed IDs, versioning
- definition-only `snapshotSHA256` per **S2-002** (`sha256-canonical-json-v1`); validate-before-hash; verify digest on load; `snapshotCreatedAt` metadata only
- explicit plan selection / assignment at session creation
- minimal UI only: plan selection + display of frozen plan identity

**Done when:** *This inspection uses Commercial Intake v1.2.0, and that definition will never change for this session.*

**Out of scope:** checklist UI, `InspectionPointState`, progress bars, guided camera, AR.

---

## Sprint 2.1 — Inspection Session Assignment

Wire the frozen snapshot into the session and evidence path.

```text
InspectionSession.planState: SessionPlanState
        │
        ├─ .assigned(AssignedInspectionPlan { snapshot, assignedAt })
        └─ .legacyUnassigned
```

- **2.1A (complete):** session owns immutable snapshot via `SessionPlanState` + `AssignedInspectionPlan`; registry only pre-assignment; legacy decodes as `.legacyUnassigned`. See `SPRINT_2_1A_STATUS.md`.
- **2.1B (complete):** `InspectionSessionEnvelope` (schema v1) + integrity digest + `FileInspectionSessionStore` + migration framework; legacy load without fabricate/overwrite. See `SPRINT_2_1B_STATUS.md`.
- **2.1C (complete):** singular stateless `InspectionProgressionEngine` + authoritative `InspectionProgressState` (`orderedPoints` + `activePointID`); Option A additive `v1` persistence; strictly terminal statuses; no UI/camera/evidence binding. See `SPRINT_2_1C_STATUS.md`.
- **2.1D (complete):** `EvidenceBindingService` + `EvidenceMetadata` / `EvidenceBindingCollection` on session; satisfaction derived from frozen `expectedEvidenceType`; Option A `v1`; no UI/camera/binary IO. See `SPRINT_2_1D_STATUS.md`.
- **2.1E (complete):** Intent–Coordinator guided overlay over live preview; ViewModel thin; camera warm-up untouched; typed `GuidedInspectionPresentationError`. See `SPRINT_2_1E_STATUS.md`.
- Later 2.1 slices: library hierarchy (2.1F).

Additive optional evidence / sidecar fields (deferred; legacy decode must remain clean):

- `planID`
- `planVersion`
- `snapshotHash`
- optional `activePointID`

**Still no checklist UI.** Stop, test, validate before 2.2.

---

## Sprint 2.2 — Guided Workflow

Introduce execution state and progress (implements S2-001):

- `InspectionPointState` + transitions
- primary: `M / R Required Points Complete` (`.accepted` only)
- secondary: capture coverage metric
- next recommended point
- checklist-style session UI

---

## Sprint 2.3 — Guided Camera

Context-aware capture UI for the active point (title, stand-off, include list).  
Overlays / guidance text allowed; **no ARKit** in 2.3.

---

## Later (Sprint 3 / 4 — not Sprint 2)

- ARKit overlays, vehicle-aware guidance, LiDAR, quality engine, CV, EV conversion integration
- **Plan Builder**: load plans from versioned JSON so new inspection types do not require Swift changes (immutable snapshot model already anticipates this)

---

## Kickoff rule for Sprint 2.0

After the 1.1.1 validated tag exists, start **2.0 only**: domain + registry + immutable snapshots + hashing + minimal plan UI. Validate again before 2.1 evidence wiring and before 2.2 execution/progress.
