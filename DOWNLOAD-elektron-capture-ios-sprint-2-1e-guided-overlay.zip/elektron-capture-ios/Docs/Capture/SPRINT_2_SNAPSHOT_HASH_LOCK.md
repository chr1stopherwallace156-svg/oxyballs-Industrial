# Sprint 2 — Inspection Plan Snapshot Integrity (Frozen)

| Field | Value |
|---|---|
| **Decision** | **S2-002** |
| **Status** | `FROZEN` — record only; implement in Sprint **2.0** |
| **Gate** | Blocked until `v1.1.1-schema-compatibility-validated` |
| **Related** | `Docs/Capture/SPRINT_2_ROADMAP.md`, `CanonicalJSONEncoder`, CryptoKit `SHA256` |
| **Supersedes** | Drafts that put `snapshotCreatedAt` in the digest, or overloaded one hash with assignment identity |

## Semantic split (locked)

```text
snapshotSHA256
= identity of the exact plan definition

snapshotCreatedAt
= immutable metadata describing when that definition was frozen for a session
```

Properties:

- identical plan content → same digest across sessions and devices
- changed point, title, requirement, order, version, or other hashed field → different digest
- session-specific metadata cannot alter the plan’s content identity
- stored snapshot remains self-contained and independently verifiable

## Algorithm

```text
snapshotSHA256 = SHA-256( CanonicalJSONEncoder.encode(InspectionPlanSnapshotPayload) )
             → 64 lowercase hexadecimal characters (no prefix, no separators)

snapshotHashAlgorithm = "sha256-canonical-json-v1"
```

The algorithm string identifies **both** the cryptographic digest and the canonicalization contract. A future encoding change must use a new identifier (e.g. `sha256-canonical-json-v2`), not pretend compatibility.

**Prohibited** for persisted identity: Swift `hashValue`, `Hasher`, non-canonical `JSONEncoder`.

## Canonical payload

**Includes:**

- snapshot schema version
- exact plan ID
- exact plan version
- title
- optional description
- inspection points in validated deterministic order

**Excludes:**

- `snapshotSHA256`
- `snapshotCreatedAt`
- session and vehicle metadata
- inspector metadata
- execution state / progress / capture attempts
- device / locale / runtime-only values

## Validate before hashing

Plans **must** pass `InspectionPlanValidator.validate(plan)` before hashing:

- unique point IDs
- unique `displayOrder`
- valid semantic version
- non-empty required fields
- deterministic point ordering already present

Do **not** use sorting during serialization to silently repair an invalid plan.

## Verify on load (Sprint 2.0 implementation lock)

Never blind-trust a stored digest. On decode / load:

```swift
let computed = try hasher.hash(snapshot.payload)
guard computed == snapshot.snapshotSHA256 else {
  throw InspectionPlanSnapshotError.hashMismatch(
    expected: snapshot.snapshotSHA256,
    actual: computed
  )
}
```

Also reject unknown / unsupported `snapshotHashAlgorithm` values.

## Storage shape

```swift
public struct InspectionPlanSnapshotPayload: Codable, Equatable, Sendable {
  public let snapshotSchemaVersion: String
  public let planID: InspectionPlanID
  public let planVersion: String
  public let title: String
  public let descriptionText: String?
  public let points: [InspectionPoint]
}

public struct InspectionPlanSnapshot: Codable, Equatable, Sendable {
  public let payload: InspectionPlanSnapshotPayload
  public let snapshotCreatedAt: Date
  public let snapshotSHA256: String
  public let snapshotHashAlgorithm: String  // "sha256-canonical-json-v1"
}
```

## Optional later: assignment digest

If a unique per-session assignment identity is needed, add a **separate** digest later. Do not overload `snapshotSHA256`.

## Integrity vs authenticity

SHA-256 = integrity fingerprint. HMAC/signature = authenticity — out of scope for Sprint 2.0 unless evidence signing authority already exists.

Must **not** change existing evidence artifact hashes or signature semantics.

## Final freeze text

```text
S2-002

Plan-definition identity uses SHA-256 over canonical JSON
(UTF-8, CanonicalJSONEncoder, UTC dates, stable keys, no whitespace,
raw enum values).

snapshotSHA256 identifies the exact immutable inspection-plan definition.
snapshotCreatedAt is stored as immutable metadata and is excluded from the digest.

Plans must validate before hashing (unique point IDs, unique displayOrder,
valid semver, non-empty required fields, deterministic ordering).
Do not sort-to-repair during encoding.

On load, recompute and verify snapshotSHA256; use algorithm id
"sha256-canonical-json-v1".

Swift Hasher and hashValue are prohibited for persisted identity.
```
