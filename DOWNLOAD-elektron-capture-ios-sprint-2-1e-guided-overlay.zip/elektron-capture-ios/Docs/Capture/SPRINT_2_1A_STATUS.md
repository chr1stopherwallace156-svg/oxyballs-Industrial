# Sprint 2.1A — Immutable Inspection Plan Assignment

| Field | Value |
|---|---|
| **Status** | `SPRINT_2_1A_COMPLETE` (Linux `swift test` green; Mac `xcodebuild` NOT RUN on this host) |
| **Branch** | `cursor/sprint-2-1a-immutable-plan-assignment-d881` |
| **Depends on** | Sprint 2.0 (`InspectionPlanSnapshot` + S2-002) |
| **Next** | Sprint 2.1B — session persistence schema / legacy envelope migration (only when prompted) |

## Domain contract

`InspectionSession` owns the immutable assigned plan via:

```swift
struct AssignedInspectionPlan: Codable, Equatable, Sendable {
  let snapshot: InspectionPlanSnapshot  // definition only (S2-002)
  let assignedAt: Date                  // assignment context
}

enum SessionPlanState: Codable, Equatable, Sendable {
  case assigned(AssignedInspectionPlan)
  case legacyUnassigned
}
```

| Field | Role |
|---|---|
| `planState` | Explicit assigned vs legacy-unassigned (sole stored assignment field) |
| `assignedPlan` / `assignedAt` / `planID` / `planVersion` / `definitionDigest` / `inspectionPlanSnapshot` | Convenience accessors derived from `AssignedInspectionPlan` — **not** duplicated stored fields |

Rules:

- `InspectionPlanSnapshot` stays definition-focused; assignment metadata lives on `AssignedInspectionPlan`.
- Registry is used **only before** assignment (validate → snapshot → verify digest → wrap).
- Assigned sessions remain historically stable when registry templates change.
- Decode is self-contained: no registry I/O; missing assignment → `.legacyUnassigned`.
- Never fabricate a snapshot from the current registry during decode.
- Full storage migration / upgrade workflows deferred to **Sprint 2.1B**.

## Authoritative creation path

```swift
InspectionSessionService.createSession(
  vehicleIdentifierRaw:...,
  inspectionPlan: InspectionPlan,
  assignedAt: Date?,
  inspector: Inspector?
)
```

Steps: validate plan → `InspectionPlanSnapshotFactory.makeSnapshot` → verify digest →
`AssignedInspectionPlan(snapshot:assignedAt:)` → `planState = .assigned(...)` → persist.

`startInspection` without a plan remains `.legacyUnassigned` for pre-wiring callers (UI deferred).

## Boundaries (honored)

- No UI / ViewModel changes
- No evidence-frame / sidecar plan fields
- No 2.1B envelope schema bump or migration helpers
- No PointState / progress / guided capture (2.1C+)
- No bootstrap / workspace / Xcode handoff changes
- S2-002 hash algorithm unchanged (`sha256-canonical-json-v1`)

## File layout (repo paths)

| Blueprint | Actual path |
|---|---|
| Domain types | `App/Domain/Models/AssignedInspectionPlan.swift` |
| | `App/Domain/Models/SessionPlanState.swift` |
| Session model | `App/Domain/Models/InspectionSession.swift` |
| Creation service | `App/Phase1/Inspection/InspectionSessionService.swift` |
| Tests | `Tests/Unit/Sprint2_1ATests.swift` |

(`Package.swift` target path is `App/`, not `Sources/`.)

## Tests

`Tests/Unit/Sprint2_1ATests.swift`

Coverage: immutable assignment, registry independence (Session A/B), digest integrity,
plan version + point-order + optional metadata retention, deterministic Codable round-trip,
legacy `.legacyUnassigned` decode, invalid-plan rejection, digest-mismatch rejection.

Blueprint-named cases: `testRegistryMutationDoesNotAffectSessionA`,
`testSessionBGetsUpdatedSnapshotWhileSessionARetainsOriginal`,
`testCodableRoundTripPreservesSnapshotAndIdentity`,
`testLegacySessionDecodesToLegacyUnassigned`,
`testInvalidPlanRejection`,
`testDigestMismatchRejection`.

## Success criteria

| Criterion | Result |
|---|---|
| `SessionPlanState` + `AssignedInspectionPlan` own assignment | Yes |
| Registry changes cannot mutate existing sessions | Yes |
| Serialization round-trip | Yes |
| Legacy → `.legacyUnassigned` without fabrication | Yes |
| Full suite passes | Yes |
| Later sprints started | No |
