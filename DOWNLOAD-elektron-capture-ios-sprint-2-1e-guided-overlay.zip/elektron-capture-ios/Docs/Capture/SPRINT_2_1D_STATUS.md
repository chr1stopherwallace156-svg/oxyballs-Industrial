# Sprint 2.1D — Evidence-to-Point Binding Metadata

| Field | Value |
|---|---|
| **Status** | `SPRINT_2_1D_COMPLETE` (Linux `swift test`; Mac `xcodebuild` NOT RUN on this host) |
| **Branch** | `cursor/sprint-2-1d-evidence-binding-d881` |
| **Baseline** | Sprint 2.1C progression engine |
| **Next** | Sprint 2.1E — guided capture overlay UI (only when prompted) |

## Architecture

```text
Presentation / camera / binary IO (not this sprint)
        │
        ▼
EvidenceBindingService   ◄── sole binding mutation path (stateless)
        │ returns updated session
        ▼
InspectionSession.evidenceBindings: EvidenceBindingCollection?
        │ point IDs validated against frozen snapshot
        ▼
InspectionSessionEnvelope (2.1B, still v1 — Option A)
```

## New domain types

| Type | Role |
|---|---|
| `EvidenceID` | UUID-backed binding identity |
| `EvidenceType` | `photo` / `video` / `textNote` / `spatialScan` / `thermalImage` / `document` |
| `EvidenceMetadata` | `id`, `pointID`, `sessionID`, `type`, `createdAt`, `storageKey`, `payloadAttributes` |
| `EvidenceBindingCollection` | `bindings: [EvidenceMetadata]` |
| `EvidenceBindingService` | Stateless bind / unbind / query / satisfaction |
| `EvidenceBindingError` | Strongly typed guardrails |
| `InspectionEvidenceRequirement` | Derives required binding count from frozen `expectedEvidenceType` |

**Not persisted:** `isSatisfied`, binary payloads, camera settings blobs beyond optional string attributes, file handles.

## Binding operations

- `bind(evidence:to:)`
- `unbind(evidenceID:from:)`
- `evidence(for:in:)` / `evidenceCount(for:in:)`
- `isPointSatisfied(pointID:in:)` — **derived**
- `requiredBindingCount(for:in:)`

Guardrails:

- Unknown `pointID` (not in frozen snapshot) → `unknownPointID`
- Duplicate `EvidenceID` → `duplicateEvidenceID`
- `sessionID` mismatch → `sessionIDMismatch`
- Empty/whitespace `storageKey` → `emptyStorageKey`
- Legacy-unassigned session → `noAssignedPlan`

## Satisfaction policy

Frozen plan points expose ``ExpectedEvidenceType``, not a numeric `requiredCaptures` field.
Sprint 2.1D derives the threshold without mutating the S2-002 plan schema:

| `expectedEvidenceType` | Required binding count |
|---|---|
| `.multiPhoto` | 2 |
| `.photo`, `.video`, `.lidarScan`, `.thermalImage`, `.document` | 1 |

`isPointSatisfied` compares `evidenceCount` to that derived requirement. No boolean is stored on progress or metadata.

## Persistence Version Policy — **Option A**

`InspectionSession.evidenceBindings` is an additive optional `v1` field (`decodeIfPresent` / `encodeIfPresent`).
`InspectionSessionSchemaVersion.current` remains **`v1`**. Pre-2.1D sessions decode with `evidenceBindings == nil`.

## Modified files

| Path | Change |
|---|---|
| `App/Domain/Models/EvidenceBinding.swift` | New domain types |
| `App/Domain/Services/EvidenceBindingService.swift` | New binding service |
| `App/Domain/Models/InspectionSession.swift` | Optional `evidenceBindings` + Codable |
| `Tests/Unit/Sprint2_1DTests.swift` | Dedicated 2.1D suite |
| `Docs/Capture/SPRINT_2_1D_STATUS.md` | This status report |
| `Docs/Capture/SPRINT_2_ROADMAP.md` | 2.1D marked complete |

## Test suite summary

| Suite | Result |
|---|---|
| `Sprint2_1DTests` | **11** executed, **0** failures |
| Full package (`swift test`) | **225** executed, **1** skipped, **0** failures |
| Mac `xcodebuild` | **NOT RUN** (Linux host) |

## Boundary confirmations

| Check | Result |
|---|---|
| UI / SwiftUI files modified | **0** |
| Camera / AVFoundation / ARKit / LiDAR | **0** |
| Binary image encode/decode / JPEG-HEIC disk IO | **0** |
| Evidence Library UI (2.1F) | **not started** |
| Guided overlay UI (2.1E) | **not started** |

## Execution

```text
Host: Linux (Swift 5.10.1)
Command: swift test
Result: 225 executed, 1 skipped, 0 failures
Sprint2_1DTests: 11 / 11 passed
xcodebuild: NOT RUN
```
