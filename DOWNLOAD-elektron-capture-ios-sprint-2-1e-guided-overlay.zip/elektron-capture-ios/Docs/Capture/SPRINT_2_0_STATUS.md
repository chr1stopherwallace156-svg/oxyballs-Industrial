# Sprint 2.0 Status

| Field | Value |
|---|---|
| **Phase** | Sprint 2.0 — InspectionPlan foundation |
| **Status** | `IMPLEMENTED_AND_MAC_BUILD_SUCCEEDED` |
| **Capture tip** | `dd04ecac7a0fbf241a42f9c8a561b5d66dc0f1ef` |
| **Branch** | `cursor/sprint-2-0-inspection-plan-d881` |
| **Linux `swift test`** | 161 executed, 1 skipped, 0 failures |
| **Mac `xcodebuild`** | **BUILD SUCCEEDED** (operator host) |
| **Physical-device smoke (2.0)** | Pending operator confirmation (plan picker / digest display) |

## Delivered

- Domain: `InspectionPlan`, `InspectionPoint`, typed IDs, `ExpectedEvidenceType`
- `InspectionPlanRegistry`, `InspectionPlanValidator`
- S2-002 snapshot payload / snapshot / hasher / factory (`sha256-canonical-json-v1`)
- Minimal plan selection + definition-digest display
- Unit tests: `Tests/Unit/InspectionPlanTests.swift`

## Explicitly deferred

- Sprint **2.1** — session ↔ snapshot persistence / evidence sidecar fields
- Sprint **2.2** — `InspectionPointState`, S2-001 progress UI
- Sprint **2.3** — guided camera

## Next

Confirm plan picker shows title / version / digest on device, then begin Sprint 2.1 when ready.
