# Sprint 2.1B — Session Persistence and Migration Foundation

| Field | Value |
|---|---|
| **Status** | `SPRINT_2_1B_COMPLETE` (Linux `swift test`; Mac `xcodebuild` NOT RUN on this host) |
| **Branch** | `cursor/sprint-2-1b-session-persistence-d881` |
| **Baseline** | Sprint 2.1A (`SessionPlanState` + `AssignedInspectionPlan`) |
| **Next** | Sprint 2.1C — point progression state machine (only when prompted) |

## Authoritative envelope

```swift
struct InspectionSessionEnvelope {
  let schemaVersion: InspectionSessionSchemaVersion  // Int, current = 1
  let session: InspectionSession                     // domain state
  let savedAt: Date                                  // save metadata
  let integrity: InspectionSessionEnvelopeIntegrity  // algorithm + sessionDigest
}
```

**First persistent schema version (2.1B): `1` (`InspectionSessionSchemaVersion.v1`).**

## Digests (two independent purposes)

| Digest | Scope |
|---|---|
| Envelope `integrity.sessionDigest` | Canonical JSON of the full `InspectionSession` value |
| S2-002 `snapshotSHA256` / `definitionDigest` | Plan-definition payload only |

Algorithm stack (both): `sha256-canonical-json-v1` via `CanonicalJSONEncoder` + `ContentHasher`.

## Storage policy

| Store | Path policy |
|---|---|
| `FileInspectionSessionStore` | `<Application Support/Documents>/InspectionSessions/sessions/<SessionID>.json` |
| `FileCurrentSessionRepository` | `…/InspectionSessions/current_session.json` (now writes v1 envelope) |

- Deterministic filenames from `SessionID.rawValue`
- Directory created when absent
- Domain model does not know filesystem paths

## Atomic save (application-level)

1. Build + verify envelope in memory  
2. Encode  
3. Write complete temporary file (same directory)  
4. Read-back temp equality check  
5. Backup destination → move temp into place → remove backup  
6. On replace failure, restore backup  

**Guarantee:** a failed/abandoned temp write does not destroy the last valid destination.  
**Limitation:** not a claim of power-fail durability beyond OS rename semantics.

## Migration rules

- `InspectionSessionMigration` / `InspectionSessionMigrationRegistry` / `InspectionSessionMigrator`
- Current v1 bypasses migration (empty step registry in 2.1B)
- Unsupported future versions throw `unsupportedSchemaVersion`
- Missing step throws `missingMigrationPath`
- **No** registry lookup; **no** fabricated plan snapshots
- Legacy inputs (in-memory wrap only; **no** automatic upgrade-on-read overwrite):
  - Pre-2.1B `CurrentSessionPersistenceEnvelope` (`schemaVersion: "1.0.0"`)
  - Raw `InspectionSession` JSON → preserve `.legacyUnassigned` when unassigned

## Recovery

- Integrity mismatch → reject (no silent repair)
- Malformed file → `malformedEnvelope`
- Missing file → `fileNotFound`
- Terminal current-session still cleared on load (existing behavior)

## Deferred

- Automatic upgrade-on-read rewrite of legacy files  
- Speculative v2+ migrations  
- Strong-ID refactor beyond existing `SessionID`  
- UI / Evidence Library hierarchy / progression (2.1C+)

## Tests

`Tests/Unit/Sprint2_1BTests.swift` — envelope, store, atomic abandon-temp, migration/legacy.
