#!/usr/bin/env bash
# Double-click entrypoint (macOS): validate extracted repo, then open Xcode.
# Portable — resolves this file's directory; no hard-coded paths.
set -euo pipefail

FAILED_STEP="startup"

on_error() {
  local rc=$?
  echo "" >&2
  echo "FAIL: START-HERE bootstrap stopped." >&2
  echo "  failed_step=${FAILED_STEP}" >&2
  echo "  exit_code=${rc}" >&2
  echo "" >&2
  echo "Run manually from the repository root:" >&2
  echo "  make xcode-ready" >&2
  echo "  # or:" >&2
  echo "  ./Scripts/xcode-ready.sh" >&2
  echo "" >&2
  echo "If macOS Gatekeeper blocked this .command (quarantine from a downloaded ZIP):" >&2
  echo "  Preferred: Right-click START-HERE.command → Open → Open" >&2
  echo "  Terminal:  xattr -d com.apple.quarantine START-HERE.command" >&2
  echo "  (Scripts do NOT clear quarantine automatically.)" >&2
  echo "" >&2
  echo "Repository: ${HERE:-unknown}" >&2
  if [[ -t 0 ]] || [[ "$(uname -s)" == "Darwin" ]]; then
    echo ""
    read -r -p "Press Return to close this window…" _
  fi
  exit "${rc}"
}
trap on_error ERR

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FAILED_STEP="resolve-repository-root"
if command -v realpath >/dev/null 2>&1; then
  HERE="$(realpath "${HERE}")"
else
  HERE="$(cd "${HERE}" && pwd -P)"
fi
cd "${HERE}"

FAILED_STEP="ensure-xcode-ready-executable"
chmod +x "${HERE}/Scripts/xcode-ready.sh" 2>/dev/null || true

FAILED_STEP="Scripts/xcode-ready.sh --open"
# Disable ERR trap around the child so we can print a richer failure path ourselves.
trap - ERR
set +e
"${HERE}/Scripts/xcode-ready.sh" --open
RC=$?
set -e

if [[ "${RC}" -ne 0 ]]; then
  FAILED_STEP="Scripts/xcode-ready.sh --open"
  # Re-enter failure UX without re-triggering trap recursion.
  echo "" >&2
  echo "FAIL: START-HERE bootstrap stopped." >&2
  echo "  failed_step=${FAILED_STEP}" >&2
  echo "  exit_code=${RC}" >&2
  echo "" >&2
  echo "Scroll up for the exact doctor / verify / build gate that failed." >&2
  echo "" >&2
  echo "Run manually from the repository root:" >&2
  echo "  make xcode-ready" >&2
  echo "  # or:" >&2
  echo "  ./Scripts/xcode-ready.sh" >&2
  echo "" >&2
  echo "If macOS Gatekeeper blocked this .command (quarantine from a downloaded ZIP):" >&2
  echo "  Preferred: Right-click START-HERE.command → Open → Open" >&2
  echo "  Terminal:  xattr -d com.apple.quarantine START-HERE.command" >&2
  echo "  (Scripts do NOT clear quarantine automatically.)" >&2
  echo "" >&2
  echo "Repository: ${HERE}" >&2
  if [[ -t 0 ]] || [[ "$(uname -s)" == "Darwin" ]]; then
    echo ""
    read -r -p "Press Return to close this window…" _
  fi
  exit "${RC}"
fi

echo ""
echo "SUCCESS: Bootstrap completed. Xcode should be open (on macOS)."
echo "Workspace: ${HERE}/Phase1StillCapture.xcworkspace"
exit 0
