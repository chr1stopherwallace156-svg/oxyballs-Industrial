#!/usr/bin/env bash
# ekp-package.sh — Stage 2: assemble Elektron Knowledge Package from clean HEAD → dist/
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
info() { echo "==> $*"; }
pass() { echo "PASS: $*"; }

[[ -f PROJECT_STATE.md ]] || fail "PROJECT_STATE.md missing — run make ekp-prepare"
[[ -f CAPTURE_IMPLEMENTATION_HANDOFF.md ]] || fail "CAPTURE_IMPLEMENTATION_HANDOFF.md missing"
[[ -f Docs/Governance/ELEKTRON_KNOWLEDGE_PACKAGE.md ]] || fail "EKP contract missing"
[[ -f KNOWLEDGE_PACKAGE/Overview.md ]] || fail "KNOWLEDGE_PACKAGE/Overview.md missing"

if [[ -n "$(git status --porcelain=v1)" ]]; then
  echo "ERROR: working tree is not clean. Commit before ekp-package:" >&2
  git status --porcelain=v1 >&2
  exit 1
fi
pass "working tree clean"

BRANCH="$(git branch --show-current 2>/dev/null || echo UNKNOWN)"
COMMIT_SHA="$(git rev-parse HEAD)"
COMMIT_SHORT="$(git rev-parse --short HEAD)"
UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

EKP_ID="${EKP_ID:-}"
if [[ -z "${EKP_ID}" ]]; then
  # Prefer history; never use multi-file rg (it prefixes path:)
  EKP_ID="$(rg -o 'EKP-CAPTURE-[0-9]+' Docs/Handoffs/EKP_HISTORY.md 2>/dev/null | head -1 || true)"
fi
if [[ -z "${EKP_ID}" && -f KNOWLEDGE_PACKAGE/CurrentStatus/PREPARE_STAMP.md ]]; then
  EKP_ID="$(rg -o 'EKP-CAPTURE-[0-9]+' KNOWLEDGE_PACKAGE/CurrentStatus/PREPARE_STAMP.md | head -1 || true)"
fi
[[ -n "${EKP_ID}" ]] || EKP_ID="EKP-CAPTURE-0001"
# Guard against accidental path:id pollution
[[ "${EKP_ID}" =~ ^EKP-CAPTURE-[0-9]+$ ]] || fail "Invalid EKP_ID='${EKP_ID}'"

DIST="${ROOT}/dist/${EKP_ID}"
CAP="${DIST}/Capture"
rm -rf "${DIST}"
mkdir -p "${CAP}"

info "Assembling ${EKP_ID} from clean HEAD ${COMMIT_SHORT} → ${DIST}"

copy_tree() {
  local src="$1" dst="$2"
  [[ -e "${src}" ]] || return 0
  mkdir -p "${dst}"
  if [[ -d "${src}" ]]; then
    (cd "${src}" && tar cf - .) | (cd "${dst}" && tar xf -)
  else
    cp -f "${src}" "${dst}/"
  fi
}

cp -f KNOWLEDGE_PACKAGE/Overview.md "${CAP}/Overview.md"
cp -f PROJECT_STATE.md "${CAP}/Current Status.md"
cp -f PROJECT_STATE.md "${CAP}/Open Gates.md"
cp -f Docs/Validation/KNOWN_LIMITATIONS.md "${CAP}/Known Issues.md" 2>/dev/null || \
  printf '%s\n' '# Known Issues' '' 'See Docs/Validation/KNOWN_LIMITATIONS.md and OPEN_ITEMS in handoffs.' > "${CAP}/Known Issues.md"

# Architecture
mkdir -p "${CAP}/Architecture"
copy_tree Docs/Architecture "${CAP}/Architecture"
cp -f Docs/Architecture/ARCHITECTURE.md "${CAP}/Architecture.md" 2>/dev/null || true

# Specs / Research
copy_tree Specifications "${CAP}/Specifications"
copy_tree Research "${CAP}/Research"

# Changelog + change records
mkdir -p "${CAP}/Changelog"
cp -f CHANGELOG.md "${CAP}/Changelog/CHANGELOG.md"
copy_tree Docs/Changes "${CAP}/Changelog/Change Records"

# Decisions
copy_tree Docs/Decisions "${CAP}/Decisions"
mkdir -p "${CAP}/Decision History"
copy_tree Docs/Decisions "${CAP}/Decision History"

# Evidence / Validation / Instructions
copy_tree Docs/Evidence "${CAP}/Evidence"
copy_tree Docs/Validation "${CAP}/Validation"
mkdir -p "${CAP}/Instructions"
cp -f Docs/Capture/PHASE_1C_FREEZE_COMMIT_SEPARATION.md "${CAP}/Instructions/" 2>/dev/null || true
cp -f Docs/Capture/PHASE_1C_FINAL_VALIDATION.md "${CAP}/Instructions/" 2>/dev/null || true
cp -f Docs/Capture/PHASE_1_PHYSICAL_DEVICE_PROCEDURE.md "${CAP}/Instructions/" 2>/dev/null || true
cp -f Docs/PHYSICAL_IPHONE_VALIDATION_RUNBOOK.md "${CAP}/Instructions/" 2>/dev/null || true
copy_tree KNOWLEDGE_PACKAGE/Instructions "${CAP}/Instructions/KNOWLEDGE_PACKAGE"

# Build
mkdir -p "${CAP}/Build"
cp -f Package.swift "${CAP}/Build/" 2>/dev/null || true
cp -f Makefile "${CAP}/Build/" 2>/dev/null || true
printf '%s\n' '# Build' '' 'See Build/Makefile and Package.swift. Mac: xcodebuild via Phase1StillCapture.xcworkspace.' > "${CAP}/Build/README.md"

# Git / repository state
mkdir -p "${CAP}/Git" "${CAP}/Repository State"
{
  echo "# Repository State"
  echo
  echo "| Field | Value |"
  echo "|------|---------|"
  echo "| ekpID | \`${EKP_ID}\` |"
  echo "| generatedAt | ${UTC} |"
  echo "| sourceCommit | \`${COMMIT_SHA}\` |"
  echo "| sourceBranch | \`${BRANCH}\` |"
  echo "| workingTreeState | clean |"
  echo
  echo '```'
  git log -5 --oneline
  echo '```'
} > "${CAP}/Repository State/REPOSITORY_STATE.md"
cp -f "${CAP}/Repository State/REPOSITORY_STATE.md" "${CAP}/Git/REPOSITORY_STATE.md"

# Recent commits / PRs
{
  echo "# Recent Commits"
  echo
  echo '```'
  git log -20 --format='%h %s'
  echo '```'
} > "${CAP}/Recent Commits.md"

{
  echo "# Recent PRs"
  echo
  echo "| PR | Topic |"
  echo "|---|---|"
  echo "| Industrial #25 | Two-stage handoff packaging |"
  echo "| Industrial #24 | Changelog / governance handoff |"
  echo "| Industrial #23 | Phase 1C freeze-prep / completion retraction |"
  echo
  echo "Capture PRs may be delivered via Industrial transfer bundles when Capture has no origin remote."
} > "${CAP}/Recent PRs.md"

# Handoffs + memory
mkdir -p "${CAP}/Handoffs" "${CAP}/Memory"
cp -f CAPTURE_IMPLEMENTATION_HANDOFF.md "${CAP}/Handoffs/"
copy_tree Docs/Handoffs "${CAP}/Handoffs/History"
cp -f REPOSITORY_MEMORY.md "${CAP}/Memory/"

# API / Schemas (best-effort)
copy_tree Docs/Integration "${CAP}/API"
mkdir -p "${CAP}/Schemas"
printf '%s\n' '# Schemas' '' 'See package inventory docs and EDTS_PKG_FORMAT references under Docs/Capture and Specs.' > "${CAP}/Schemas/README.md"

# Package inventory pointer
mkdir -p "${CAP}/Package Inventory"
if [[ -f Handoff/PACKAGE_INVENTORY.json ]]; then
  cp -f Handoff/PACKAGE_INVENTORY.json "${CAP}/Package Inventory/"
fi
printf '%s\n' '# Package Inventory' '' 'Full digests for this EKP are in the envelope root SHA256SUMS.txt.' > "${CAP}/Package Inventory/README.md"

# Roadmap pointer
printf '%s\n' '# Roadmap' '' '- Phase 1C freeze (`v1.0.0-phase1c`)' '' '- Specs baseline → CHANGE-0003' '' '- IR-0001 after authorization' > "${CAP}/Roadmap.md"

# Governance copies
mkdir -p "${CAP}/Governance"
cp -f Docs/Governance/*.md "${CAP}/Governance/" 2>/dev/null || true

# Identity
cat > "${CAP}/EKP_IDENTITY.md" <<EOF
# ${EKP_ID}

| Field | Value |
|------|---------|
| subsystem | Capture |
| generatedAt | ${UTC} |
| sourceCommit | \`${COMMIT_SHA}\` |
| sourceBranch | \`${BRANCH}\` |
| Track A | \`PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE\` |
| Track B | \`BASELINE_APPROVAL_PENDING_FINAL_ARCHITECTURAL_REVIEW\` |
| IR | \`IR_0001_EXECUTION_NOT_YET_AUTHORIZED\` |
EOF

VERIFY_DIR="$(mktemp -d)"
STAGING="$(mktemp -d)"
trap 'rm -rf "${VERIFY_DIR}" "${STAGING}"' EXIT

ZIP_NAME="ekp-capture-${COMMIT_SHA}.zip"
BUNDLE_NAME="ekp-capture-${COMMIT_SHA}.bundle"

info "Creating EKP ZIP"
mkdir -p "${STAGING}/elektron-capture-ekp"
cp -a "${CAP}" "${STAGING}/elektron-capture-ekp/Capture"
cp -f Docs/Governance/ELEKTRON_KNOWLEDGE_PACKAGE.md "${STAGING}/elektron-capture-ekp/"
(cd "${STAGING}" && zip -rq "${DIST}/${ZIP_NAME}" elektron-capture-ekp)
pass "SOURCE_ARCHIVE_GENERATED ${ZIP_NAME}"

info "Creating Git bundle (full Capture repo HEAD)"
git bundle create "${DIST}/${BUNDLE_NAME}" HEAD "${BRANCH}" 2>/dev/null \
  || git bundle create "${DIST}/${BUNDLE_NAME}" HEAD
pass "REPOSITORY_BUNDLE_GENERATED ${BUNDLE_NAME}"

info "Restoration test"
git clone "${DIST}/${BUNDLE_NAME}" "${VERIFY_DIR}/restored-repo" >/dev/null
git -C "${VERIFY_DIR}/restored-repo" fsck --full >/dev/null
TEST_SHA="$(git -C "${VERIFY_DIR}/restored-repo" rev-parse HEAD)"
[[ "${TEST_SHA}" == "${COMMIT_SHA}" ]] || fail "Restored HEAD ${TEST_SHA} != ${COMMIT_SHA}"
unzip -q "${DIST}/${ZIP_NAME}" -d "${VERIFY_DIR}/zip"
[[ -f "${VERIFY_DIR}/zip/elektron-capture-ekp/Capture/Overview.md" ]] || fail "EKP ZIP missing Overview.md"
pass "RESTORATION_TEST_PASSED"

info "Generating SHA256SUMS.txt"
(
  cd "${DIST}"
  find ./Capture ./${ZIP_NAME} ./${BUNDLE_NAME} -type f -print0 |
  LC_ALL=C sort -z |
  xargs -0 sha256sum
) > "${DIST}/SHA256SUMS.txt"

while read -r digest path; do
  [[ -z "${digest:-}" ]] && continue
  f="${DIST}/${path#./}"
  [[ -f "${f}" ]] || fail "missing ${path}"
  got="$(sha256sum "${f}" | awk '{print $1}')"
  [[ "${got}" == "${digest}" ]] || fail "digest mismatch ${path}"
done < "${DIST}/SHA256SUMS.txt"
pass "DIGESTS_VERIFIED"

ZIP_SHA="$(sha256sum "${DIST}/${ZIP_NAME}" | awk '{print $1}')"
BUNDLE_SHA="$(sha256sum "${DIST}/${BUNDLE_NAME}" | awk '{print $1}')"

cat > "${DIST}/VERIFICATION_REPORT.md" <<EOF
# Verification Report — ${EKP_ID}

| Field | Value |
|------|---------|
| ekpID | \`${EKP_ID}\` |
| generatedAt | ${UTC} |
| sourceCommit | \`${COMMIT_SHA}\` |
| sourceBranch | \`${BRANCH}\` |
| DIGESTS_VERIFIED | yes |
| RESTORATION_TEST_PASSED | yes |

| Artifact | SHA-256 |
|----------|---------|
| \`${ZIP_NAME}\` | \`${ZIP_SHA}\` |
| \`${BUNDLE_NAME}\` | \`${BUNDLE_SHA}\` |

This EKP does **not** claim Phase 1 frozen or Specs baseline-approved.
EOF

cat > "${DIST}/STATUS.txt" <<EOF
EKP_ID=${EKP_ID}
EKP_METADATA_COMMITTED=1
SOURCE_ARCHIVE_GENERATED=1
REPOSITORY_BUNDLE_GENERATED=1
DIGESTS_VERIFIED=1
RESTORATION_TEST_PASSED=1
COMMIT=${COMMIT_SHA}
ZIP_SHA256=${ZIP_SHA}
BUNDLE_SHA256=${BUNDLE_SHA}
EOF

echo ""
echo "EKP_PACKAGE_COMPLETE ${EKP_ID}"
echo "DIST=${DIST}"
echo "ZIP_SHA256=${ZIP_SHA}"
echo "BUNDLE_SHA256=${BUNDLE_SHA}"
echo "External envelope is untracked (dist/). Do not commit dist/."
