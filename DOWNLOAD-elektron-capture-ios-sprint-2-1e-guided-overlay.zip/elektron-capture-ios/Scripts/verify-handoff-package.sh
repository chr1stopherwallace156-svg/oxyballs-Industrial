#!/usr/bin/env bash
echo "ERROR: Scripts/verify-handoff-package.sh (in-tree) is retired." >&2
echo "Stage 2 make handoff-package verifies dist/handoff-<id>/ digests + restoration." >&2
exit 1
