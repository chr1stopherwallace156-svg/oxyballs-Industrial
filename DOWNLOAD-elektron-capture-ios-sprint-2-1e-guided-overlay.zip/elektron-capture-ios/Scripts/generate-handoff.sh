#!/usr/bin/env bash
echo "ERROR: Scripts/generate-handoff.sh is retired (circular-hash / dirty-tree paradox)." >&2
echo "Use: make handoff-prepare && git commit && make handoff-package" >&2
exit 1
