#!/usr/bin/env bash
# ekp-prepare.sh — Stage 1: refresh living memory docs + KNOWLEDGE_PACKAGE index (tracked).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
info() { echo "==> $*"; }

[[ -f PROJECT_STATE.md ]] || fail "PROJECT_STATE.md missing"
[[ -f CAPTURE_IMPLEMENTATION_HANDOFF.md ]] || fail "CAPTURE_IMPLEMENTATION_HANDOFF.md missing"
[[ -f REPOSITORY_MEMORY.md ]] || fail "REPOSITORY_MEMORY.md missing"
[[ -f Docs/Governance/ELEKTRON_KNOWLEDGE_PACKAGE.md ]] || fail "EKP contract missing"
[[ -f KNOWLEDGE_PACKAGE/Overview.md ]] || fail "KNOWLEDGE_PACKAGE/Overview.md missing"

BRANCH="$(git branch --show-current 2>/dev/null || echo UNKNOWN)"
COMMIT="$(git rev-parse HEAD)"
COMMIT_SHORT="$(git rev-parse --short HEAD)"
UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
TREE_STATE="clean"
[[ -z "$(git status --porcelain=v1)" ]] || TREE_STATE="dirty"

EKP_ID="${EKP_ID:-}"
if [[ -z "${EKP_ID}" ]]; then
  if [[ -f Docs/Handoffs/EKP_HISTORY.md ]]; then
    LAST="$(rg -o 'EKP-CAPTURE-[0-9]+' Docs/Handoffs/EKP_HISTORY.md | head -1 || true)"
    if [[ "${LAST}" =~ EKP-CAPTURE-([0-9]+) ]]; then
      NEXT=$((10#${BASH_REMATCH[1]} + 1))
      EKP_ID=$(printf 'EKP-CAPTURE-%04d' "${NEXT}")
    else
      EKP_ID="EKP-CAPTURE-0001"
    fi
  else
    EKP_ID="EKP-CAPTURE-0001"
  fi
fi

info "Preparing ${EKP_ID} living docs @ ${COMMIT_SHORT} (${BRANCH}) tree=${TREE_STATE}"

STAGING="$(mktemp -d)"
trap 'rm -rf "${STAGING}"' EXIT
TEST_LINE="NOT_RUN"
if command -v swift >/dev/null 2>&1; then
  info "Running swift test"
  set +e
  swift test 2>&1 | tee "${STAGING}/swift-test.log" | tail -3
  TEST_RC=${PIPESTATUS[0]}
  set -e
  [[ ${TEST_RC} -eq 0 ]] || fail "swift test failed"
  TEST_LINE="$(rg -N 'Executed [0-9]+ tests' "${STAGING}/swift-test.log" | tail -1 || echo PASS)"
else
  TEST_LINE="swift missing"
fi

mkdir -p KNOWLEDGE_PACKAGE/CurrentStatus KNOWLEDGE_PACKAGE/Inventory Docs/Handoffs
cat > KNOWLEDGE_PACKAGE/CurrentStatus/PREPARE_STAMP.md <<EOF
# EKP prepare stamp

| Field | Value |
|------|---------|
| ekpID | \`${EKP_ID}\` |
| generatedAt | ${UTC} |
| sourceCommit | \`${COMMIT}\` |
| sourceBranch | \`${BRANCH}\` |
| workingTreeState | ${TREE_STATE} |
| validationStatus | ${TEST_LINE} |
| stage | \`EKP_METADATA_PREPARED\` |

Next: commit living docs, then \`make ekp-package\` on clean HEAD → \`dist/${EKP_ID}/\`.
EOF

cp -f PROJECT_STATE.md KNOWLEDGE_PACKAGE/CurrentStatus/PROJECT_STATE.md
cp -f CAPTURE_IMPLEMENTATION_HANDOFF.md KNOWLEDGE_PACKAGE/CurrentStatus/CAPTURE_IMPLEMENTATION_HANDOFF.md

if [[ ! -f Docs/Handoffs/EKP_HISTORY.md ]]; then
  cat > Docs/Handoffs/EKP_HISTORY.md <<'EOF'
# EKP History — Capture

Append-only. Newest at top. Digests live only under `dist/EKP-CAPTURE-*/` after Stage 2.

---
EOF
fi

if ! rg -q "^## ${EKP_ID} " Docs/Handoffs/EKP_HISTORY.md; then
  DATE_UTC="${UTC%%T*}"
  EKP_ID="${EKP_ID}" COMMIT="${COMMIT}" BRANCH="${BRANCH}" TEST_LINE="${TEST_LINE}" DATE_UTC="${DATE_UTC}" \
  python3 - <<'PY'
import os
from pathlib import Path
path = Path("Docs/Handoffs/EKP_HISTORY.md")
text = path.read_text()
hid = os.environ["EKP_ID"]
entry = f"""## {hid} — {os.environ['DATE_UTC']}

- Capture tip (at prepare): `{os.environ['COMMIT']}` (`{os.environ['BRANCH']}`)
- Stage: `EKP_METADATA_PREPARED` — package pending (`make ekp-package` → `dist/{hid}/`)
- Validation: {os.environ['TEST_LINE']}
- Living docs: `PROJECT_STATE.md`, `CAPTURE_IMPLEMENTATION_HANDOFF.md`, `REPOSITORY_MEMORY.md`

---

"""
marker = "---\n"
idx = text.find(marker)
if idx >= 0:
    idx_end = idx + len(marker)
    text = text[:idx_end] + "\n" + entry + text[idx_end:].lstrip("\n")
else:
    text = text.rstrip() + "\n\n" + entry
path.write_text(text)
print("EKP history appended", hid)
PY
fi

if rg -q '^\*\*Generated\*\*' PROJECT_STATE.md; then
  sed -i "s|^\*\*Generated\*\*.*|**Generated (prepare):** ${UTC} @ \`${COMMIT_SHORT}\` (\`${BRANCH}\`) / ${EKP_ID}|" PROJECT_STATE.md || true
fi

echo ""
echo "EKP_METADATA_PREPARED ${EKP_ID}"
echo "Commit living docs, then: make ekp-package"
