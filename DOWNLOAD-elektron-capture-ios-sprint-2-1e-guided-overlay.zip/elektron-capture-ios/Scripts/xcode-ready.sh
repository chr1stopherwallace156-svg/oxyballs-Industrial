#!/usr/bin/env bash
# xcode-ready.sh — universal post-ZIP / post-extract bootstrap for Elektron Capture.
# Orchestrates existing doctor + verify-xcode-handoff; does not replace them.
#
# Usage:
#   ./Scripts/xcode-ready.sh
#   ./Scripts/xcode-ready.sh --check-only
#   ./Scripts/xcode-ready.sh --deep-clean
#   ./Scripts/xcode-ready.sh --open
#
# Safe: never deletes source, Git, Docs/Evidence, signing, or unrelated DerivedData.
# Portable: no hard-coded /Users or Downloads paths.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if command -v realpath >/dev/null 2>&1; then
  ROOT="$(realpath "${SCRIPT_DIR}/..")"
else
  ROOT="$(cd "${SCRIPT_DIR}/.." && pwd -P)"
fi
cd "${ROOT}"

CHECK_ONLY=0
DEEP_CLEAN=0
DO_OPEN=0

usage() {
  cat <<'EOF'
Usage: ./Scripts/xcode-ready.sh [--check-only] [--deep-clean] [--open]

  (no flags)     Safe cleanup, doctor/verify, SPM tests, Simulator build.
  --check-only   Diagnostics only — no deletions, resolve, or builds; no open.
  --deep-clean   Normal workflow + narrowly scoped project package caches.
  --open         Full workflow; open root Phase1StillCapture.xcworkspace only if all gates pass.
EOF
}

for arg in "$@"; do
  case "${arg}" in
    --check-only) CHECK_ONLY=1 ;;
    --deep-clean) DEEP_CLEAN=1 ;;
    --open) DO_OPEN=1 ;;
    -h|--help) usage; exit 0 ;;
    *)
      echo "FAIL: unknown argument: ${arg}" >&2
      usage >&2
      exit 2
      ;;
  esac
done

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }
skip() { echo "SKIP: $*"; }
warn() { echo "WARN: $*" >&2; }
step() { echo ""; echo "=== $* ==="; }

RESULT_DOCTOR="NOT_RUN"
RESULT_HANDOFF="NOT_RUN"
RESULT_RESOLVE="NOT_RUN"
RESULT_SWIFT_BUILD="NOT_RUN"
RESULT_SWIFT_TEST="NOT_RUN"
RESULT_SIM_BUILD="NOT_RUN"
SWIFT_TEST_SUMMARY=""
PKG_REL=""
PKG_ABS=""

PROJECT_PATH="${ROOT}/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj"
WORKSPACE_PATH="${ROOT}/Phase1StillCapture.xcworkspace"
PBX="${PROJECT_PATH}/project.pbxproj"
SCHEME="Phase1StillCapture"
SCHEME_FILE="${PROJECT_PATH}/xcshareddata/xcschemes/${SCHEME}.xcscheme"
DD_ROOT="${HOME}/Library/Developer/Xcode/DerivedData"
DERIVED_DATA_PATH="${ROOT}/Docs/Evidence/XCODE_READY/DerivedData"

echo "=== xcode-ready @ ${ROOT} ==="
echo "host=$(uname -s) arch=$(uname -m)"
echo "check_only=${CHECK_ONLY} deep_clean=${DEEP_CLEAN} open=${DO_OPEN}"
echo "workspace_path=${WORKSPACE_PATH}"
echo "project_path=${PROJECT_PATH} (linkage only — builds use workspace)"

# ---------------------------------------------------------------------------
# A. Repository identity
# ---------------------------------------------------------------------------
step "A. Repository identity"
[[ -f "${ROOT}/Package.swift" ]] || fail "Package.swift missing at repo root: ${ROOT}/Package.swift"
[[ -d "${PROJECT_PATH}" ]] || fail "Phase1StillCapture.xcodeproj missing: ${PROJECT_PATH}"
[[ -d "${WORKSPACE_PATH}" ]] || fail "Authoritative workspace missing: ${WORKSPACE_PATH}"
[[ -f "${PBX}" ]] || fail "project.pbxproj missing: ${PBX}"

if command -v swift >/dev/null 2>&1; then
  DUMP="$(swift package dump-package)"
  echo "${DUMP}" | python3 -c '
import sys, json
pkg = json.load(sys.stdin)
products = [p["name"] for p in pkg.get("products", [])]
targets = [t["name"] for t in pkg.get("targets", [])]
if "ElektronCapture" not in products:
    raise SystemExit("products=" + ",".join(products))
if "ElektronCapture" not in targets:
    raise SystemExit("targets=" + ",".join(targets))
print("product_and_target_ok")
' || fail "Package.swift must export library product + target ElektronCapture"
  pass "Package.swift exports product + target ElektronCapture"
else
  grep -q 'library(name: "ElektronCapture"' "${ROOT}/Package.swift" \
    || fail "Package.swift missing library product ElektronCapture"
  grep -Eq 'name:[[:space:]]*"ElektronCapture"' "${ROOT}/Package.swift" \
    || fail "Package.swift missing target ElektronCapture"
  pass "Package.swift declares product + target ElektronCapture (swift dump-package skipped)"
fi

[[ -f "${SCHEME_FILE}" ]] \
  || fail "Missing shared scheme ${SCHEME}: ${SCHEME_FILE}"
pass "Shared scheme Phase1StillCapture present"

# ---------------------------------------------------------------------------
# B. Existing diagnostics (propagate failures; do not suppress output)
# ---------------------------------------------------------------------------
step "B. Existing diagnostics — Scripts/doctor.sh"
set +e
"${ROOT}/Scripts/doctor.sh"
DOCTOR_RC=$?
set -e
if [[ "${DOCTOR_RC}" -ne 0 ]]; then
  RESULT_DOCTOR="FAIL(rc=${DOCTOR_RC})"
  fail "doctor.sh exited ${DOCTOR_RC}"
fi
RESULT_DOCTOR="PASS"
pass "doctor.sh completed"

step "B. Existing diagnostics — Scripts/verify-xcode-handoff.sh"
set +e
"${ROOT}/Scripts/verify-xcode-handoff.sh" "${ROOT}"
HANDOFF_RC=$?
set -e
if [[ "${HANDOFF_RC}" -ne 0 ]]; then
  RESULT_HANDOFF="FAIL(rc=${HANDOFF_RC})"
  fail "verify-xcode-handoff.sh exited ${HANDOFF_RC}"
fi
RESULT_HANDOFF="PASS"
pass "verify-xcode-handoff.sh completed"

# ---------------------------------------------------------------------------
# C. Xcode project linkage (exact checks + evidence on failure)
# ---------------------------------------------------------------------------
step "C. Xcode project linkage"
python3 - "${PBX}" "${ROOT}" <<'PY' || fail "Xcode project linkage checks failed (see evidence above)"
import re, sys, os
pbx_path, root = sys.argv[1], sys.argv[2]
text = open(pbx_path, encoding="utf-8").read()
errors = []

def need(label, pattern):
    if not re.search(pattern, text):
        errors.append(f"missing: {label} (pattern={pattern})")

need("productName = ElektronCapture", r"productName\s*=\s*ElektronCapture\s*;")
need("ElektronCapture in Frameworks", r"ElektronCapture in Frameworks")
need(
    "packageProductDependencies includes ElektronCapture",
    r"packageProductDependencies\s*=\s*\([\s\S]*?ElektronCapture[\s\S]*?\)",
)
need("XCLocalSwiftPackageReference", r"XCLocalSwiftPackageReference")
need("relativePath", r"relativePath\s*=")

m = re.search(r"relativePath\s*=\s*([^;]+);", text)
if not m:
    errors.append("could not parse relativePath")
    rel = None
else:
    rel = m.group(1).strip().strip('"')
    base = os.path.join(root, "Apps", "Phase1StillCapture")
    resolved = os.path.realpath(os.path.join(base, rel))
    root_real = os.path.realpath(root)
    if resolved != root_real:
        errors.append(
            f"relativePath {rel!r} resolves to {resolved!r}, expected repo root {root_real!r}"
        )
    else:
        print(f"PASS: relativePath {rel!r} → {resolved}")
    # stash for shell via stdout marker
    print(f"PKG_REL={rel}")
    print(f"PKG_ABS={resolved}")

if re.search(r"(/Users/|/home/|file:///Users/|file:///home/)", text):
    errors.append("absolute filesystem path committed in project.pbxproj")

if errors:
    print("LINKAGE_EVIDENCE_BEGIN", file=sys.stderr)
    for e in errors:
        print(f"  {e}", file=sys.stderr)
    for pat in [
        r".*productName\s*=\s*ElektronCapture.*",
        r".*ElektronCapture in Frameworks.*",
        r".*packageProductDependencies.*",
        r".*XCLocalSwiftPackageReference.*",
        r".*relativePath\s*=.*",
    ]:
        for line in text.splitlines():
            if re.search(pat, line):
                print(f"  evidence: {line.strip()}", file=sys.stderr)
                break
    print("LINKAGE_EVIDENCE_END", file=sys.stderr)
    raise SystemExit(1)
PY

# Capture PKG_REL / PKG_ABS from python stdout (re-run lightweight parse for shell vars)
PKG_REL="$(python3 -c '
import re, sys
text = open(sys.argv[1], encoding="utf-8").read()
m = re.search(r"relativePath\s*=\s*([^;]+);", text)
print(m.group(1).strip().strip("\"") if m else "")
' "${PBX}")"
if command -v realpath >/dev/null 2>&1; then
  PKG_ABS="$(realpath "${ROOT}/Apps/Phase1StillCapture/${PKG_REL}")"
else
  PKG_ABS="$(cd "${ROOT}/Apps/Phase1StillCapture/${PKG_REL}" && pwd -P)"
fi
pass "Linkage: productName, Frameworks, packageProductDependencies, local package → ${PKG_ABS}"

# ---------------------------------------------------------------------------
# D. App imports — covered by verify-xcode-handoff; confirm at least one import
# ---------------------------------------------------------------------------
step "D. App imports (ElektronCapture)"
IMPORT_HITS=0
while IFS= read -r -d '' f; do
  if grep -q '^import ElektronCapture' "${f}" || grep -q 'import ElektronCapture' "${f}"; then
    IMPORT_HITS=$((IMPORT_HITS + 1))
  fi
done < <(find "${ROOT}/Apps/Phase1StillCapture" -maxdepth 1 -name '*.swift' -print0)
[[ "${IMPORT_HITS}" -ge 1 ]] \
  || fail "No Apps/Phase1StillCapture/*.swift files import ElektronCapture (handoff verify should have caught this)"
pass "Found ${IMPORT_HITS} app Swift file(s) importing ElektronCapture (detailed checks via verify-xcode-handoff)"

if [[ "${CHECK_ONLY}" -eq 1 ]]; then
  step "I. Final report (--check-only)"
  echo "XCODE_READY_CHECK_ONLY"
  echo "repository_root=${ROOT}"
  echo "workspace_path=${WORKSPACE_PATH}"
  echo "project_path=${PROJECT_PATH}"
  echo "resolved_local_package_path=${PKG_ABS}"
  echo "doctor_result=${RESULT_DOCTOR}"
  echo "handoff_verification_result=${RESULT_HANDOFF}"
  echo "package_resolution_result=SKIPPED(check-only)"
  echo "swift_build_result=SKIPPED(check-only)"
  echo "swift_test_result=SKIPPED(check-only)"
  echo "simulator_build_result=SKIPPED(check-only)"
  echo "NOTE: Physical-device validation remains a separate gate."
  echo "Open command (after full make xcode-ready on Mac):"
  echo "  open \"${WORKSPACE_PATH}\""
  exit 0
fi

# ---------------------------------------------------------------------------
# E. Safe generated-state cleanup
# ---------------------------------------------------------------------------
step "E. Safe generated-state cleanup"
if [[ -d "${ROOT}/.build" ]]; then
  echo "Will remove regenerable path: ${ROOT}/.build"
  rm -rf "${ROOT}/.build"
  pass "Removed repo-local .build"
else
  pass "No repo-local .build present"
fi

# Never delete Package.resolved (preserved by policy).
if [[ -f "${ROOT}/Package.resolved" ]]; then
  pass "Preserving Package.resolved (not deleted)"
fi

remove_project_derived_data() {
  local mode="$1"
  if [[ ! -d "${DD_ROOT}" ]]; then
    skip "DerivedData root absent (common on Linux): ${DD_ROOT}"
    return 0
  fi
  local found=0
  local dd
  while IFS= read -r -d '' dd; do
    found=1
    case "${dd}" in
      "${DD_ROOT}"/Phase1StillCapture-*) ;;
      *)
        warn "Skipping DerivedData with unclear ownership: ${dd}"
        continue
        ;;
    esac
    echo "${mode}: will remove project DerivedData: ${dd}"
    rm -rf "${dd}"
  done < <(find "${DD_ROOT}" -maxdepth 1 -type d -name 'Phase1StillCapture-*' -print0 2>/dev/null || true)
  if [[ "${found}" -eq 0 ]]; then
    pass "No Phase1StillCapture-* DerivedData folders found"
  else
    pass "${mode}: finished Phase1StillCapture DerivedData scan"
  fi
}

remove_project_derived_data "CLEAN"

if [[ "${DEEP_CLEAN}" -eq 1 ]]; then
  step "E+. Deep-clean (project-associated package caches only)"
  # Do NOT delete entire ~/Library/Caches/org.swift.swiftpm
  if [[ -d "${DD_ROOT}" ]]; then
    local_sp_found=0
    while IFS= read -r -d '' sp; do
      local_sp_found=1
      echo "DEEP-CLEAN: will remove project SourcePackages: ${sp}"
      rm -rf "${sp}"
    done < <(
      find "${DD_ROOT}" -maxdepth 2 -type d \
        -path '*/Phase1StillCapture-*/SourcePackages' -print0 2>/dev/null || true
    )
    if [[ "${local_sp_found}" -eq 0 ]]; then
      warn "No Phase1StillCapture-*/SourcePackages found — skipping SPM cache deletion (ownership not established)"
    else
      pass "Removed Phase1StillCapture SourcePackages under DerivedData"
    fi
  else
    warn "DerivedData absent — cannot establish project SourcePackages ownership; skipping deep package-cache deletion"
  fi
  # Optionally clear only workspace-local swiftpm checkouts inside THIS repo if present.
  WS_SPM="${ROOT}/Phase1StillCapture.xcworkspace/xcshareddata/swiftpm"
  if [[ -d "${WS_SPM}/checkouts" ]]; then
    echo "DEEP-CLEAN: will remove workspace-local checkouts: ${WS_SPM}/checkouts"
    rm -rf "${WS_SPM}/checkouts"
    pass "Removed workspace-local swiftpm checkouts"
  fi
  if [[ -d "${ROOT}/.swiftpm" ]]; then
    echo "DEEP-CLEAN: will remove repo-local .swiftpm: ${ROOT}/.swiftpm"
    rm -rf "${ROOT}/.swiftpm"
    pass "Removed repo-local .swiftpm"
  fi
fi

# ---------------------------------------------------------------------------
# F. Package resolution
# ---------------------------------------------------------------------------
step "F. Package resolution (workspace -resolvePackageDependencies)"
if command -v xcodebuild >/dev/null 2>&1; then
  RESOLVE_LOG="$(mktemp)"
  set +e
  xcodebuild \
    -workspace "${WORKSPACE_PATH}" \
    -resolvePackageDependencies \
    2>&1 | tee "${RESOLVE_LOG}"
  RESOLVE_RC=${PIPESTATUS[0]}
  set -e
  if [[ "${RESOLVE_RC}" -ne 0 ]]; then
    RESULT_RESOLVE="FAIL(rc=${RESOLVE_RC})"
    rm -f "${RESOLVE_LOG}"
    fail "xcodebuild -resolvePackageDependencies exited ${RESOLVE_RC}"
  fi
  if ! grep -Eqi 'ElektronCapture' "${RESOLVE_LOG}"; then
    warn "Resolve log did not clearly mention ElektronCapture; linkage already verified in pbxproj → ${PKG_ABS}"
  fi
  # Confirm local package path still resolves to this root after resolve.
  [[ "${PKG_ABS}" == "${ROOT}" ]] \
    || fail "Resolved package path ${PKG_ABS} is not repository root ${ROOT}"
  RESULT_RESOLVE="PASS(local=${PKG_ABS})"
  rm -f "${RESOLVE_LOG}"
  pass "Resolved package dependencies via workspace; ElektronCapture → ${PKG_ABS}"
else
  RESULT_RESOLVE="SKIPPED(no-xcodebuild)"
  skip "xcodebuild unavailable — package resolve deferred to Mac/Xcode"
fi

# ---------------------------------------------------------------------------
# G. Swift Package Manager verification
# ---------------------------------------------------------------------------
step "G. SPM verification (swift build / swift test)"
if ! command -v swift >/dev/null 2>&1; then
  fail "swift toolchain required for SPM verification"
fi

set +e
swift build
BUILD_RC=$?
set -e
if [[ "${BUILD_RC}" -ne 0 ]]; then
  RESULT_SWIFT_BUILD="FAIL(rc=${BUILD_RC})"
  fail "swift build exited ${BUILD_RC}"
fi
RESULT_SWIFT_BUILD="PASS"
pass "swift build"

TEST_LOG="$(mktemp)"
set +e
swift test 2>&1 | tee "${TEST_LOG}"
TEST_RC=${PIPESTATUS[0]}
set -e
SWIFT_TEST_SUMMARY="$(grep -E 'Executed [0-9]+ tests' "${TEST_LOG}" | tail -1 || true)"
if [[ -z "${SWIFT_TEST_SUMMARY}" ]]; then
  SWIFT_TEST_SUMMARY="$(tail -5 "${TEST_LOG}" | tr '\n' ' ')"
fi
rm -f "${TEST_LOG}"
if [[ "${TEST_RC}" -ne 0 ]]; then
  RESULT_SWIFT_TEST="FAIL(rc=${TEST_RC})"
  fail "swift test exited ${TEST_RC}"
fi
RESULT_SWIFT_TEST="PASS"
pass "swift test — ${SWIFT_TEST_SUMMARY}"

# ---------------------------------------------------------------------------
# H. Xcode Simulator build
# ---------------------------------------------------------------------------
step "H. Xcode Simulator build (authoritative workspace, unsigned)"
if command -v xcodebuild >/dev/null 2>&1; then
  echo "workspace=${WORKSPACE_PATH}"
  echo "destination=generic/platform=iOS Simulator"
  echo "configuration=Debug"
  echo "derivedDataPath=${DERIVED_DATA_PATH}"
  echo "CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO"
  echo "NOTE: DEVELOPMENT_TEAM is not required for make xcode-ready."
  echo "      Physical-device signing remains in Scripts/device-preflight.sh."
  echo "      Builds use the root workspace — not Phase1StillCapture.xcodeproj alone."
  mkdir -p "${DERIVED_DATA_PATH}"
  set +e
  xcodebuild \
    -workspace "${WORKSPACE_PATH}" \
    -scheme "${SCHEME}" \
    -destination 'generic/platform=iOS Simulator' \
    -configuration Debug \
    -derivedDataPath "${DERIVED_DATA_PATH}" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    clean build
  SIM_RC=$?
  set -e
  if [[ "${SIM_RC}" -ne 0 ]]; then
    RESULT_SIM_BUILD="FAIL(rc=${SIM_RC})"
    fail "xcodebuild workspace Simulator build exited ${SIM_RC}"
  fi
  RESULT_SIM_BUILD="PASS"
  pass "xcodebuild workspace + generic iOS Simulator Debug clean build (unsigned)"
else
  RESULT_SIM_BUILD="SKIPPED(no-xcodebuild)"
  skip "xcodebuild unavailable — Simulator build deferred to Mac/Xcode (HANDOFF_XCODE_BUILD_SKIPPED)"
fi

# ---------------------------------------------------------------------------
# I. Final report (only after all gates pass)
# ---------------------------------------------------------------------------
step "I. Final report"
echo "XCODE_READY"
echo "repository_root=${ROOT}"
echo "workspace_path=${WORKSPACE_PATH}"
echo "project_path=${PROJECT_PATH}"
echo "resolved_local_package_path=${PKG_ABS}"
echo "doctor_result=${RESULT_DOCTOR}"
echo "handoff_verification_result=${RESULT_HANDOFF}"
echo "package_resolution_result=${RESULT_RESOLVE}"
echo "swift_build_result=${RESULT_SWIFT_BUILD}"
echo "swift_test_result=${RESULT_SWIFT_TEST}"
echo "swift_test_summary=${SWIFT_TEST_SUMMARY}"
echo "simulator_build_result=${RESULT_SIM_BUILD}"
echo "NOTE: Physical-device / iPhone validation remains a separate gate."
echo "Open command:"
echo "  open \"${WORKSPACE_PATH}\""

if [[ "${DO_OPEN}" -eq 1 ]]; then
  if [[ "$(uname -s)" == "Darwin" ]]; then
    echo "Opening authoritative workspace after successful gates: ${WORKSPACE_PATH}"
    open "${WORKSPACE_PATH}"
    echo "Xcode open requested for Phase1StillCapture.xcworkspace"
  else
    skip "--open requested but host is not Darwin; open skipped"
  fi
fi

exit 0
