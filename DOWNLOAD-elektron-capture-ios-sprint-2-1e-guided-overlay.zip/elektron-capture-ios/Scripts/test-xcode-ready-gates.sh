#!/usr/bin/env bash
# Isolated failure-propagation checks for xcode-ready.sh.
# Does not modify the authoritative repository working tree.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "${SCRIPT_DIR}/.." && pwd -P)"
READY="${ROOT}/Scripts/xcode-ready.sh"
TMP="$(mktemp -d)"
trap 'rm -rf "${TMP}"' EXIT

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

write_minimal_package() {
  local dest="$1"
  mkdir -p "${dest}/Sources/ElektronCapture"
  cat > "${dest}/Package.swift" <<'EOF'
// swift-tools-version: 5.9
import PackageDescription
let package = Package(
  name: "ElektronCapture",
  products: [.library(name: "ElektronCapture", targets: ["ElektronCapture"])],
  targets: [.target(name: "ElektronCapture", path: "Sources/ElektronCapture")]
)
EOF
  echo "public enum FixtureMarker {}" > "${dest}/Sources/ElektronCapture/FixtureMarker.swift"
}

echo "=== test-xcode-ready-gates (isolated fixtures under ${TMP}) ==="

# Unknown flags
set +e
"${READY}" --definitely-not-a-flag >/dev/null 2>&1
RC=$?
set -e
[[ "${RC}" -ne 0 ]] || fail "unknown flag should fail"
pass "unknown flag → nonzero (${RC})"

# Missing Package.swift
EMPTY="${TMP}/empty-root"
mkdir -p "${EMPTY}/Scripts"
cp "${READY}" "${EMPTY}/Scripts/xcode-ready.sh"
chmod +x "${EMPTY}/Scripts/xcode-ready.sh"
set +e
"${EMPTY}/Scripts/xcode-ready.sh" --check-only >/dev/null 2>&1
RC=$?
set -e
[[ "${RC}" -ne 0 ]] || fail "missing Package.swift should fail"
pass "missing Package.swift → nonzero (${RC})"

# Missing xcodeproj
NO_PROJ="${TMP}/no-proj"
mkdir -p "${NO_PROJ}/Scripts" "${NO_PROJ}/Apps"
write_minimal_package "${NO_PROJ}"
cp "${READY}" "${NO_PROJ}/Scripts/xcode-ready.sh"
chmod +x "${NO_PROJ}/Scripts/xcode-ready.sh"
set +e
"${NO_PROJ}/Scripts/xcode-ready.sh" --check-only >/dev/null 2>&1
RC=$?
set -e
[[ "${RC}" -ne 0 ]] || fail "missing xcodeproj should fail"
pass "missing xcodeproj → nonzero (${RC})"

# Broken project linkage (scheme present, pbx missing ElektronCapture product refs)
BROKEN="${TMP}/broken-link"
mkdir -p "${BROKEN}/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/xcshareddata/xcschemes"
mkdir -p "${BROKEN}/Scripts"
write_minimal_package "${BROKEN}"
printf '%s\n' '// !$*UTF8*$!' '{' '  archiveVersion = 1;' '  classes = {' '  };' '  objectVersion = 56;' '  objects = {' '  };' '  rootObject = 0;' '}' \
  > "${BROKEN}/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj"
touch "${BROKEN}/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/xcshareddata/xcschemes/Phase1StillCapture.xcscheme"
cat > "${BROKEN}/Scripts/doctor.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
echo "STUB doctor PASS"
exit 0
EOF
cat > "${BROKEN}/Scripts/verify-xcode-handoff.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
echo "STUB verify-xcode-handoff PASS"
exit 0
EOF
chmod +x "${BROKEN}/Scripts/"*.sh
cp "${READY}" "${BROKEN}/Scripts/xcode-ready.sh"
set +e
OUT="$("${BROKEN}/Scripts/xcode-ready.sh" --check-only 2>&1)"
RC=$?
set -e
[[ "${RC}" -ne 0 ]] || fail "broken project linkage should fail; output=${OUT}"
pass "broken project linkage → nonzero (${RC})"

# Failed xcodebuild returns nonzero: when xcodebuild exists, a nonsense project fails.
# On Linux without xcodebuild, simulate with a wrapper on PATH.
if command -v xcodebuild >/dev/null 2>&1; then
  set +e
  xcodebuild -project "${TMP}/does-not-exist.xcodeproj" -scheme Nope build >/dev/null 2>&1
  RC=$?
  set -e
  [[ "${RC}" -ne 0 ]] || fail "xcodebuild should fail for missing project"
  pass "xcodebuild missing-project → nonzero (${RC})"
else
  BIN="${TMP}/bin"
  mkdir -p "${BIN}"
  cat > "${BIN}/xcodebuild" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
echo "simulated xcodebuild failure" >&2
exit 66
EOF
  chmod +x "${BIN}/xcodebuild"
  set +e
  PATH="${BIN}:${PATH}" xcodebuild -project ignored -scheme ignored build >/dev/null 2>&1
  RC=$?
  set -e
  [[ "${RC}" -eq 66 ]] || fail "simulated xcodebuild should exit 66"
  pass "simulated xcodebuild failure → nonzero (${RC})"
fi

echo "ALL_XCODE_READY_GATE_TESTS_PASSED"
