#!/usr/bin/env bash
# handoff-package.sh — Stage 2: package committed HEAD into external dist/ envelope.
# REQUIRES clean working tree (git status --porcelain=v1 empty).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
info() { echo "==> $*"; }
pass() { echo "PASS: $*"; }

[[ -f Handoff/HANDOFF.md ]] || fail "Handoff/HANDOFF.md missing — run make handoff-prepare and commit first"
[[ -f Handoff/PACKAGE_INVENTORY.json ]] || fail "Handoff/PACKAGE_INVENTORY.json missing"
[[ -f CHANGELOG.md ]] || fail "CHANGELOG.md missing"

# Clean-tree hard gate
if [[ -n "$(git status --porcelain=v1)" ]]; then
  echo "ERROR: working tree is not clean. Commit or stash before handoff-package:" >&2
  git status --porcelain=v1 >&2
  exit 1
fi
pass "working tree clean"

resolve_base_ref() {
  if [[ -n "${BASE_REF:-}" ]]; then
    git rev-parse --verify "${BASE_REF}" >/dev/null 2>&1 || fail "BASE_REF=${BASE_REF} not resolvable"
    echo "${BASE_REF}"
    return
  fi
  if git rev-parse --verify origin/main >/dev/null 2>&1; then
    echo "origin/main"
    return
  fi
  if git rev-parse --verify main >/dev/null 2>&1; then
    echo "main"
    return
  fi
  fail "Set BASE_REF=<ref> (neither origin/main nor main available)"
}

BASE_REF_RESOLVED="$(resolve_base_ref)"
info "BASE_REF=${BASE_REF_RESOLVED}"

# Diff-based changelog gate against committed HEAD
if git diff --quiet "${BASE_REF_RESOLVED}"...HEAD -- CHANGELOG.md; then
  echo "ERROR: CHANGELOG.md was not updated relative to ${BASE_REF_RESOLVED}" >&2
  exit 1
fi
pass "CHANGELOG.md updated vs ${BASE_REF_RESOLVED}"

if ! git diff --name-only "${BASE_REF_RESOLVED}"...HEAD | grep -Eq '^Docs/Changes/CHANGE-[0-9]{4}.*\.md$'; then
  if ! grep -q "CHANGE_RECORD_NOT_REQUIRED_REASON" Handoff/HANDOFF.md; then
    echo "ERROR: No detailed Docs/Changes/CHANGE-XXXX.md record found and no explicit exception declared." >&2
    exit 1
  fi
  pass "CHANGE_RECORD_NOT_REQUIRED_REASON declared"
else
  pass "CHANGE-XXXX record present in ${BASE_REF_RESOLVED}...HEAD"
fi

BRANCH="$(git branch --show-current 2>/dev/null || echo UNKNOWN)"
COMMIT_SHA="$(git rev-parse HEAD)"
COMMIT_SHORT="$(git rev-parse --short HEAD)"
UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

HANDOFF_ID="${HANDOFF_ID:-}"
if [[ -z "${HANDOFF_ID}" ]]; then
  HANDOFF_ID="$(rg -o 'HANDOFF-[0-9]+' Handoff/HANDOFF.md | head -1 || true)"
fi
[[ -n "${HANDOFF_ID}" ]] || fail "Could not determine HANDOFF_ID (set HANDOFF_ID= or ensure Handoff/HANDOFF.md has one)"

DIST="${ROOT}/dist/${HANDOFF_ID}"
rm -rf "${DIST}"
mkdir -p "${DIST}/payload"

info "Packaging ${HANDOFF_ID} from clean HEAD ${COMMIT_SHORT} → ${DIST}"

# Exact exported copy of tracked handoff docs
if command -v rsync >/dev/null 2>&1; then
  rsync -a --exclude artifacts --exclude SHA256SUMS.txt Handoff/ "${DIST}/payload/"
else
  (cd Handoff && tar cf - --exclude=artifacts --exclude=SHA256SUMS.txt .) | (cd "${DIST}/payload" && tar xf -)
fi

# Ensure key payload files exist
[[ -f "${DIST}/payload/HANDOFF.md" ]] || fail "payload/HANDOFF.md missing"
[[ -f "${DIST}/payload/PACKAGE_INVENTORY.json" ]] || fail "payload/PACKAGE_INVENTORY.json missing"
[[ -f "${DIST}/payload/CHANGELOG.md" ]] || fail "payload/CHANGELOG.md missing"

# Source archive from committed HEAD (no .git)
ZIP_NAME="elektron-capture-${COMMIT_SHA}.zip"
BUNDLE_NAME="elektron-capture-${COMMIT_SHA}.bundle"
STAGING="$(mktemp -d)"
VERIFY_DIR="$(mktemp -d)"
trap 'rm -rf "${STAGING}" "${VERIFY_DIR}"' EXIT

info "Creating source ZIP from HEAD"
git archive --format=tar --prefix=elektron-capture-ios/ HEAD | tar -x -C "${STAGING}"
cat > "${STAGING}/elektron-capture-ios/HANDOFF_IDENTITY.txt" <<EOF
HANDOFF_ID=${HANDOFF_ID}
CAPTURE_TIP=${COMMIT_SHA}
CAPTURE_BRANCH=${BRANCH}
TREE_STATE=clean
GENERATED_UTC=${UTC}
STAGE=HANDOFF_PACKAGE
NOTE=ZIP has no .git. Use companion .bundle for authoritative clone. Phase 1 freeze still pending.
EOF
# Embed packaged payload snapshot under Handoff/ inside ZIP for convenience
mkdir -p "${STAGING}/elektron-capture-ios/Handoff"
(cd "${DIST}/payload" && tar cf - .) | (cd "${STAGING}/elektron-capture-ios/Handoff" && tar xf -)

(cd "${STAGING}" && zip -rq "${DIST}/${ZIP_NAME}" elektron-capture-ios)
pass "SOURCE_ARCHIVE_GENERATED ${ZIP_NAME}"

info "Creating Git bundle from HEAD"
git bundle create "${DIST}/${BUNDLE_NAME}" HEAD "${BRANCH}" 2>/dev/null \
  || git bundle create "${DIST}/${BUNDLE_NAME}" HEAD
pass "REPOSITORY_BUNDLE_GENERATED ${BUNDLE_NAME}"

# Isolated restoration verification
info "Restoration test (isolated mktemp)"
git clone "${DIST}/${BUNDLE_NAME}" "${VERIFY_DIR}/restored-repo" >/dev/null
git -C "${VERIFY_DIR}/restored-repo" fsck --full >/dev/null
TEST_SHA="$(git -C "${VERIFY_DIR}/restored-repo" rev-parse HEAD)"
if [[ "${TEST_SHA}" != "${COMMIT_SHA}" ]]; then
  echo "ERROR: Restored HEAD (${TEST_SHA}) does not match expected commit (${COMMIT_SHA})" >&2
  exit 1
fi
# Spot-check ZIP unpack
unzip -q "${DIST}/${ZIP_NAME}" -d "${VERIFY_DIR}/zip"
[[ -f "${VERIFY_DIR}/zip/elektron-capture-ios/Package.swift" ]] || fail "ZIP missing Package.swift"
[[ -f "${VERIFY_DIR}/zip/elektron-capture-ios/HANDOFF_IDENTITY.txt" ]] || fail "ZIP missing HANDOFF_IDENTITY.txt"
if [[ -d "${VERIFY_DIR}/zip/elektron-capture-ios/.git" ]]; then
  fail "ZIP unexpectedly contains .git"
fi
pass "RESTORATION_TEST_PASSED"

# Deterministic digests (exclude SHA256SUMS.txt itself)
info "Generating SHA256SUMS.txt"
(
  cd "${DIST}"
  find . \
    -type f \
    ! -name 'SHA256SUMS.txt' \
    ! -name 'SHA256SUMS.txt.tmp' \
    ! -name 'VERIFICATION_REPORT.md' \
    -print0 |
  LC_ALL=C sort -z |
  xargs -0 sha256sum
) > "${DIST}/SHA256SUMS.txt.tmp"

# Include VERIFICATION_REPORT after it is written — first write report without digests section finalization
# Actually: user said SHA256SUMS hashes payload/ and zip/bundle, excludes itself.
# VERIFICATION_REPORT can be written after digests and optionally not included, or included via second pass.
# Spec: "Hashes of all payload/ and zip/bundle files (excludes itself)"
# So only payload + zip + bundle — not VERIFICATION_REPORT.
(
  cd "${DIST}"
  find ./payload ./${ZIP_NAME} ./${BUNDLE_NAME} \
    -type f \
    -print0 2>/dev/null |
  LC_ALL=C sort -z |
  xargs -0 sha256sum
) > "${DIST}/SHA256SUMS.txt"

# Independent digest verification
while read -r digest path; do
  [[ -z "${digest:-}" ]] && continue
  # paths from sha256sum may be ./prefixed
  f="${DIST}/${path#./}"
  [[ -f "${f}" ]] || fail "missing ${path}"
  got="$(sha256sum "${f}" | awk '{print $1}')"
  [[ "${got}" == "${digest}" ]] || fail "digest mismatch ${path}"
done < "${DIST}/SHA256SUMS.txt"
pass "DIGESTS_VERIFIED"
rm -f "${DIST}/SHA256SUMS.txt.tmp"

ZIP_SHA="$(sha256sum "${DIST}/${ZIP_NAME}" | awk '{print $1}')"
BUNDLE_SHA="$(sha256sum "${DIST}/${BUNDLE_NAME}" | awk '{print $1}')"

cat > "${DIST}/VERIFICATION_REPORT.md" <<EOF
# Verification Report — ${HANDOFF_ID}

| Field | Value |
|------|---------|
| handoffID | \`${HANDOFF_ID}\` |
| generatedAt | ${UTC} |
| sourceCommit | \`${COMMIT_SHA}\` |
| sourceBranch | \`${BRANCH}\` |
| workingTreeState | clean |
| baseRef | \`${BASE_REF_RESOLVED}\` |
| SOURCE_ARCHIVE_GENERATED | yes (\`${ZIP_NAME}\`) |
| REPOSITORY_BUNDLE_GENERATED | yes (\`${BUNDLE_NAME}\`) |
| DIGESTS_GENERATED | yes |
| DIGESTS_VERIFIED | yes |
| RESTORATION_TEST_PASSED | yes (bundle HEAD == \`${COMMIT_SHA}\`; ZIP unpack OK) |

## Artifact hashes

| Artifact | SHA-256 |
|----------|---------|
| \`${ZIP_NAME}\` | \`${ZIP_SHA}\` |
| \`${BUNDLE_NAME}\` | \`${BUNDLE_SHA}\` |

Full list: \`SHA256SUMS.txt\` (excludes itself and this report).

## Status note

Packaging does **not** advance Phase 1 freeze or Specs baseline approval.

\`\`\`text
NO CHANGE WITHOUT CHANGELOG
NO COMPLETION WITHOUT HANDOFF
NO HANDOFF WITHOUT VERIFIED HASHES
NO RELEASE WITHOUT AUTHORITATIVE TAG
\`\`\`
EOF

# Stamp package status into a non-tracked sidecar next to dist (optional machine-readable)
cat > "${DIST}/STATUS.txt" <<EOF
HANDOFF_ID=${HANDOFF_ID}
HANDOFF_METADATA_COMMITTED=1
SOURCE_ARCHIVE_GENERATED=1
REPOSITORY_BUNDLE_GENERATED=1
PACKAGE_INVENTORY_COMPLETE=1
DIGESTS_GENERATED=1
DIGESTS_VERIFIED=1
RESTORATION_TEST_PASSED=1
COMMIT=${COMMIT_SHA}
BRANCH=${BRANCH}
ZIP_SHA256=${ZIP_SHA}
BUNDLE_SHA256=${BUNDLE_SHA}
EOF

echo ""
echo "HANDOFF_PACKAGE_COMPLETE ${HANDOFF_ID}"
echo "DIST=${DIST}"
echo "ZIP_SHA256=${ZIP_SHA}"
echo "BUNDLE_SHA256=${BUNDLE_SHA}"
echo "External envelope is untracked (dist/). Do not commit dist/ into the source tree."
