#!/usr/bin/env bash
# handoff-prepare.sh — Stage 1: generate tracked handoff metadata only.
# Does NOT create zip/bundle/SHA256SUMS (those are Stage 2 → dist/).
#
# Flow:
#   make handoff-prepare
#   git add … && git commit
#   make handoff-package   # requires clean HEAD
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
info() { echo "==> $*"; }

[[ -f CHANGELOG.md ]] || fail "CHANGELOG.md missing"
[[ -f Docs/Governance/CHANGELOG_AND_HANDOFF_GOVERNANCE.md ]] || fail "governance doc missing"
[[ -f Docs/Handoffs/HANDOFF_HISTORY.md ]] || fail "HANDOFF_HISTORY.md missing"

resolve_base_ref() {
  if [[ -n "${BASE_REF:-}" ]]; then
    git rev-parse --verify "${BASE_REF}" >/dev/null 2>&1 || fail "BASE_REF=${BASE_REF} not resolvable"
    echo "${BASE_REF}"
    return
  fi
  if git rev-parse --verify origin/main >/dev/null 2>&1; then
    echo "origin/main"
    return
  fi
  if git rev-parse --verify main >/dev/null 2>&1; then
    echo "main"
    return
  fi
  fail "Set BASE_REF=<ref> (neither origin/main nor main available)"
}

BASE_REF_RESOLVED="$(resolve_base_ref)"
info "BASE_REF=${BASE_REF_RESOLVED}"

# Diff-based changelog gate (working tree vs BASE_REF — includes uncommitted edits)
if git diff --quiet "${BASE_REF_RESOLVED}" -- CHANGELOG.md; then
  fail "CHANGELOG.md was not updated relative to ${BASE_REF_RESOLVED} (set BASE_REF or update CHANGELOG.md)"
fi
info "CHANGELOG.md differs from ${BASE_REF_RESOLVED}"

# Change-record gate: new/changed CHANGE-XXXX vs BASE_REF, or explicit exception
CHANGE_HIT=0
if git diff --name-only "${BASE_REF_RESOLVED}" | grep -Eq '^Docs/Changes/CHANGE-[0-9]{4}.*\.md$'; then
  CHANGE_HIT=1
fi
if [[ "${CHANGE_HIT}" -eq 0 ]]; then
  for f in Docs/Changes/CHANGE-[0-9][0-9][0-9][0-9]*.md; do
    [[ -f "${f}" ]] || continue
    if ! git cat-file -e "${BASE_REF_RESOLVED}:${f}" 2>/dev/null; then
      CHANGE_HIT=1
      break
    fi
  done
fi
if [[ "${CHANGE_HIT}" -eq 0 ]]; then
  if [[ -f Handoff/HANDOFF.md ]] && grep -q 'CHANGE_RECORD_NOT_REQUIRED_REASON' Handoff/HANDOFF.md; then
    info "CHANGE_RECORD_NOT_REQUIRED_REASON declared"
  else
    fail "No detailed Docs/Changes/CHANGE-XXXX.md record found vs ${BASE_REF_RESOLVED} and no explicit exception declared"
  fi
else
  info "CHANGE-XXXX record present/changed vs ${BASE_REF_RESOLVED}"
fi

# Reject stale COMPLETE claims without pending language
if rg -q 'PHASE_1C_COMPLETE[^_]' PHASE_1C_FINAL_VALIDATION.md Docs/Capture/PHASE_1C_FINAL_VALIDATION.md 2>/dev/null; then
  if ! rg -q 'PENDING|Not a completed freeze|PENDING_AUTHORITATIVE' Docs/Capture/PHASE_1C_FINAL_VALIDATION.md; then
    fail "PHASE_1C_COMPLETE claimed without pending/freeze caveats — refuse handoff-prepare"
  fi
fi

if rg -n '`VERIFIED_PASS`' Docs/Capture/PHASE_1C_FINAL_VALIDATION.md 2>/dev/null | rg -v 'pre-mark|Do not|without cited|INSERT'; then
  fail "suspicious VERIFIED_PASS presentation in validation record"
fi

BRANCH="$(git branch --show-current 2>/dev/null || echo UNKNOWN)"
COMMIT="$(git rev-parse HEAD)"
COMMIT_SHORT="$(git rev-parse --short HEAD)"
TREE_STATE="clean"
if [[ -n "$(git status --porcelain=v1)" ]]; then
  TREE_STATE="dirty"
fi
REMOTE_URL="$(git remote get-url origin 2>/dev/null || echo NONE)"
UTC="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

HANDOFF_ID="${HANDOFF_ID:-}"
if [[ -z "${HANDOFF_ID}" ]]; then
  LAST="$(rg -o 'HANDOFF-[0-9]+' Docs/Handoffs/HANDOFF_HISTORY.md | head -1 || true)"
  if [[ "${LAST}" =~ HANDOFF-([0-9]+) ]]; then
    NEXT=$((10#${BASH_REMATCH[1]} + 1))
    HANDOFF_ID=$(printf 'HANDOFF-%04d' "${NEXT}")
  else
    HANDOFF_ID="HANDOFF-0001"
  fi
fi

PREV_HANDOFF="$(rg -o 'HANDOFF-[0-9]+' Docs/Handoffs/HANDOFF_HISTORY.md | head -1 || echo NONE)"
INCLUDED_CHANGES="$(ls Docs/Changes/CHANGE-*.md 2>/dev/null | xargs -n1 basename 2>/dev/null | sed 's/\.md$//' | paste -sd, -)"
INCLUDED_CHANGES="${INCLUDED_CHANGES:-NONE}"

PHASE1C_STATUS="PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE"
if [[ -f App/Phase1/EvidenceLibrary/EvidenceLibraryModels.swift ]]; then
  PHASE1C_STATUS="$(rg -o 'PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE' App/Phase1/EvidenceLibrary/EvidenceLibraryModels.swift | head -1 || echo "${PHASE1C_STATUS}")"
fi
V2_GATE="BASELINE_APPROVAL_PENDING_FINAL_ARCHITECTURAL_REVIEW"
IR_GATE="IR_0001_EXECUTION_NOT_YET_AUTHORIZED"

info "Preparing tracked metadata ${HANDOFF_ID} @ ${COMMIT_SHORT} (${BRANCH}) tree=${TREE_STATE}"

STAGING="$(mktemp -d)"
trap 'rm -rf "${STAGING}"' EXIT

TEST_LINE="NOT_RUN_IN_PREPARE"
if command -v swift >/dev/null 2>&1; then
  info "Running swift test for validation summary"
  set +e
  swift test 2>&1 | tee "${STAGING}/swift-test.log" | tail -5
  TEST_RC=${PIPESTATUS[0]}
  set -e
  if [[ ${TEST_RC} -eq 0 ]]; then
    TEST_LINE="$(rg -N 'Executed [0-9]+ tests' "${STAGING}/swift-test.log" | tail -1 || echo 'swift test PASS')"
  else
    TEST_LINE="swift test FAILED (rc=${TEST_RC})"
    fail "swift test failed — fix tests before handoff-prepare"
  fi
else
  TEST_LINE="swift missing — tests not executed in handoff-prepare"
fi

OUT="${ROOT}/Handoff"
# Preserve nothing from prior packaging under Handoff/ — Stage 2 owns dist/
rm -rf "${OUT}/artifacts" "${OUT}/SHA256SUMS.txt" "${OUT}/STATUS.txt"
mkdir -p "${OUT}" \
  "${OUT}/Specifications" \
  "${OUT}/Research" \
  "${OUT}/Docs/Capture" \
  "${OUT}/Docs/Governance" \
  "${OUT}/Docs/Handoffs" \
  "${OUT}/Docs/Changes"

cat > "${OUT}/REPOSITORY_STATE.md" <<EOF
# Repository State

| Field | Value |
|------|---------|
| handoffID | \`${HANDOFF_ID}\` |
| generatedAt | ${UTC} |
| sourceCommit | \`${COMMIT}\` |
| sourceBranch | \`${BRANCH}\` |
| workingTreeState | ${TREE_STATE} |
| previousHandoffID | \`${PREV_HANDOFF}\` |
| baseRef | \`${BASE_REF_RESOLVED}\` |
| remote | \`${REMOTE_URL}\` |
| host | \`$(uname -s) $(uname -m)\` |
| stage | \`HANDOFF_METADATA_PREPARED\` (Stage 1 — commit before \`make handoff-package\`) |

\`\`\`text
$(git status --porcelain=v1 || true)
\`\`\`
EOF

cat > "${OUT}/VALIDATION_SUMMARY.md" <<EOF
# Validation Summary

| Gate | Result |
|------|---------|
| \`swift test\` | ${TEST_LINE} |
| Phase 1C (Track A) | \`${PHASE1C_STATUS}\` |
| Capture v2 (Track B) | \`${V2_GATE}\` |
| IR-0001 | \`${IR_GATE}\` |
| Handoff stage | \`HANDOFF_METADATA_PREPARED\` (package pending on clean HEAD) |

Phase 1 freeze remains **pending authoritative repository equivalence and tag**.
Specs baseline remains **pending final architectural review**.
EOF

cat > "${OUT}/OPEN_ITEMS.md" <<EOF
# Open Items / Remaining Gates

## Track A — Phase 1 freeze

1. Mac device evidence substitution into \`PHASE_1C_FINAL_VALIDATION.md\`
2. Commit A (Phase 1 only) → annotated tag \`v1.0.0-phase1c\` → push
3. \`REMOTE_TAG_VERIFIED\` → \`TAG_TARGET_VERIFIED\` → protection recorded → \`PHASE_1_FROZEN\`

## Track B — Specs / spike

1. Phase 1 remote tag freeze complete
2. Final architectural review → future \`CHANGE-0003\`
3. Formal IR-0001 execution authorization (\`${IR_GATE}\` until then)

## Handoff packaging

1. Commit Stage 1 metadata (\`make handoff-prepare\` outputs)
2. \`make handoff-package\` on clean HEAD → \`dist/${HANDOFF_ID}/\`
3. Confirm \`DIGESTS_VERIFIED\` + \`RESTORATION_TEST_PASSED\`
EOF

cp -f CHANGELOG.md "${OUT}/CHANGELOG.md"
cp -f Docs/Governance/CHANGELOG_AND_HANDOFF_GOVERNANCE.md "${OUT}/Docs/Governance/"
cp -f Docs/Handoffs/HANDOFF_HISTORY.md "${OUT}/Docs/Handoffs/"
cp -f Docs/Changes/*.md "${OUT}/Docs/Changes/" 2>/dev/null || true
cp -f Docs/Capture/PHASE_1C_FINAL_VALIDATION.md "${OUT}/Docs/Capture/" 2>/dev/null || true
cp -f Docs/Capture/PHASE_1C_FREEZE_COMMIT_SEPARATION.md "${OUT}/Docs/Capture/" 2>/dev/null || true
cp -f Docs/Capture/PHASE_1_FREEZE.md "${OUT}/Docs/Capture/" 2>/dev/null || true
cp -f PHASE_1C_FINAL_VALIDATION.md "${OUT}/" 2>/dev/null || true
cp -f CURSOR_OPERATING_RULES.md "${OUT}/" 2>/dev/null || true

if [[ -d Specifications ]]; then
  cp -f Specifications/*.md "${OUT}/Specifications/" 2>/dev/null || true
fi
if [[ -d Research ]]; then
  mkdir -p "${OUT}/Research/Spikes/IR-0001" "${OUT}/Research/IntegrationReports" "${OUT}/Research/Deferred/SemanticMattes"
  cp -f Research/README.md "${OUT}/Research/" 2>/dev/null || true
  cp -f Research/IntegrationReports/*.md "${OUT}/Research/IntegrationReports/" 2>/dev/null || true
  cp -f Research/Spikes/IR-0001/*.md "${OUT}/Research/Spikes/IR-0001/" 2>/dev/null || true
  cp -f Research/Deferred/SemanticMattes/README.md "${OUT}/Research/Deferred/SemanticMattes/" 2>/dev/null || true
fi

# Inventory of tracked handoff payload (docs only — no zip/bundle)
python3 - <<'PY' "${OUT}"
import json, sys, hashlib
from pathlib import Path
out = Path(sys.argv[1])
entries = []
for p in sorted(out.rglob("*")):
    if p.is_file() and "artifacts" not in p.parts and p.name != "SHA256SUMS.txt":
        rel = str(p.relative_to(out)).replace("\\", "/")
        data = p.read_bytes()
        entries.append({
            "path": rel,
            "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        })
inv = {
    "schemaVersion": "2.0.0",
    "packageKind": "elektron-capture-ios-handoff-metadata",
    "stage": "HANDOFF_METADATA_PREPARED",
    "fileCount": len(entries),
    "files": entries,
}
(out / "PACKAGE_INVENTORY.json").write_text(json.dumps(inv, indent=2) + "\n")
print(f"inventory files={len(entries)}")
PY

cat > "${OUT}/HANDOFF.md" <<EOF
# ${HANDOFF_ID} — Elektron Capture iOS Handoff (Stage 1 metadata)

| Field | Value |
|------|---------|
| handoffID | \`${HANDOFF_ID}\` |
| generatedAt | ${UTC} |
| sourceCommit | \`${COMMIT}\` |
| sourceBranch | \`${BRANCH}\` |
| workingTreeState | ${TREE_STATE} |
| previousHandoffID | \`${PREV_HANDOFF}\` |
| changeRange | \`${BASE_REF_RESOLVED}...${COMMIT_SHORT}\` |
| includedChangeIDs | \`${INCLUDED_CHANGES}\` |
| includedPRs | \`PR#23,PR#24\` |
| projectStatus | TrackA=\`${PHASE1C_STATUS}\`; TrackB=\`${V2_GATE}\`; IR=\`${IR_GATE}\` |
| validationStatus | ${TEST_LINE} |
| stage | \`HANDOFF_METADATA_PREPARED\` |
| packagingStatus | \`PENDING_CLEAN_HEAD_PACKAGE\` |

## Status invariants

### Track A — Phase 1 freeze

\`\`\`text
${PHASE1C_STATUS}
\`\`\`

Lineage: \`cursor/phase1c-freeze-commit-a-d881\`

### Track B — Specs & spike

\`\`\`text
${V2_GATE}
${IR_GATE}
\`\`\`

Lineage: \`cursor/phase1c-evidence-library-handoff-d881\`

## Completion sub-gates (not yet all green)

Until Stage 2 packaging + digest verification + restoration pass, work remains:

\`IMPLEMENTED_PENDING_COMPLETION_ARTIFACTS\`

\`\`\`text
1. IMPLEMENTATION_COMPLETE (code/spec)
2. TESTS_COMPLETE
3. EVIDENCE_COMPLETE
4. CHANGELOG_COMPLETE
5. CHANGE_RECORD_COMPLETE_OR_JUSTIFIED
6. HANDOFF_METADATA_COMMITTED   ← commit this Stage 1 output next
7. SOURCE_ARCHIVE_GENERATED     ← make handoff-package
8. REPOSITORY_BUNDLE_GENERATED
9. PACKAGE_INVENTORY_COMPLETE
10. DIGESTS_GENERATED
11. DIGESTS_VERIFIED
12. RESTORATION_TEST_PASSED
= IMPLEMENTATION_COMPLETE (full)
\`\`\`

## Next actions

1. Review \`Handoff/\` metadata + \`CHANGELOG.md\` + \`Docs/Changes/\`
2. \`git add\` Stage 1 outputs and commit (\`HANDOFF_METADATA_COMMITTED\`)
3. Ensure \`git status --porcelain=v1\` is empty
4. \`make handoff-package\` → external envelope \`dist/${HANDOFF_ID}/\`

## Permanent invariants

\`\`\`text
NO CHANGE WITHOUT CHANGELOG
NO COMPLETION WITHOUT HANDOFF
NO HANDOFF WITHOUT VERIFIED HASHES
NO RELEASE WITHOUT AUTHORITATIVE TAG
\`\`\`

## Governance

\`Docs/Governance/CHANGELOG_AND_HANDOFF_GOVERNANCE.md\`
EOF

# Append history if this ID not already present
if ! rg -q "^## ${HANDOFF_ID} " Docs/Handoffs/HANDOFF_HISTORY.md; then
  DATE_UTC="${UTC%%T*}"
  HANDOFF_ID="${HANDOFF_ID}" PREV_HANDOFF="${PREV_HANDOFF}" COMMIT="${COMMIT}" BRANCH="${BRANCH}" \
  TEST_LINE="${TEST_LINE}" DATE_UTC="${DATE_UTC}" BASE_REF_RESOLVED="${BASE_REF_RESOLVED}" \
  python3 - <<'PY'
import os
from pathlib import Path
path = Path("Docs/Handoffs/HANDOFF_HISTORY.md")
text = path.read_text()
hid = os.environ["HANDOFF_ID"]
entry = f"""## {hid} — {os.environ['DATE_UTC']}

- Previous handoff: {os.environ['PREV_HANDOFF']}
- Capture tip (at prepare): `{os.environ['COMMIT']}` (`{os.environ['BRANCH']}`)
- Base ref: `{os.environ['BASE_REF_RESOLVED']}`
- Stage: `HANDOFF_METADATA_PREPARED` (Stage 1). Digests / zip / bundle: **PENDING Stage 2** (`make handoff-package` on clean HEAD → `dist/{hid}/`).
- Validation: {os.environ['TEST_LINE']}
- Remaining gate: Commit metadata → package → digests verified → restoration test; Phase 1 freeze; Specs architectural review.

---

"""
marker = "---\n"
idx = text.find(marker)
if idx >= 0:
    idx_end = idx + len(marker)
    text = text[:idx_end] + "\n" + entry + text[idx_end:].lstrip("\n")
else:
    text = text.rstrip() + "\n\n" + entry
path.write_text(text)
print("history appended", hid)
PY
  cp -f Docs/Handoffs/HANDOFF_HISTORY.md "${OUT}/Docs/Handoffs/HANDOFF_HISTORY.md"
fi

echo ""
echo "HANDOFF_METADATA_PREPARED ${HANDOFF_ID}"
echo "Stage 1 complete. Review, commit tracked metadata, then:"
echo "  make handoff-package"
echo "Package output will be external: dist/${HANDOFF_ID}/"
