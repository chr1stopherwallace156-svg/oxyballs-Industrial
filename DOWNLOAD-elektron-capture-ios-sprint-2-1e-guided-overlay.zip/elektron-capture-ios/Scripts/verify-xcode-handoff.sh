#!/usr/bin/env bash
# Prove Xcode handoff layout + (when available) the Phase1StillCapture app build.
# Usage: ./Scripts/verify-xcode-handoff.sh [repo-root]
#
# Gates:
#   HANDOFF_LAYOUT_OK     — always required (Linux + Mac)
#   HANDOFF_XCODE_BUILD_OK — required on Darwin when xcodebuild is present
#   HANDOFF_XCODE_BUILD_SKIPPED — printed on Linux / no-xcode environments
#
# Note: `swift build` only compiles Package.swift (ElektronCapture). It does NOT
# compile Apps/Phase1StillCapture/*.swift. Do not treat SPM green as app green.
#
# Authoritative workspace (portable ZIP / any extract folder name):
#   Phase1StillCapture.xcworkspace   ← repo root (open this)
# Nested Apps/.../Phase1StillCapture.xcworkspace is secondary only.
set -euo pipefail

ROOT="$(cd "${1:-$(dirname "$0")/..}" && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }
skip() { echo "SKIP: $*"; }
warn() { echo "WARN: $*" >&2; }

echo "=== verify-xcode-handoff @ $ROOT ==="
echo "host=$(uname -s) arch=$(uname -m)"

[[ -f Package.swift ]] || fail "Package.swift missing at repo root"
pass "Package.swift exists at repo root"

if command -v swift >/dev/null 2>&1; then
  PROD=$(swift package dump-package | python3 -c "import sys,json; print(',' .join(p['name'] for p in json.load(sys.stdin)['products']))")
  echo "$PROD" | grep -q 'ElektronCapture' || fail "Package does not export product ElektronCapture (got: $PROD)"
  pass "Package exports product ElektronCapture"
else
  grep -q 'library(name: "ElektronCapture"' Package.swift || fail "Package.swift missing ElektronCapture product declaration"
  pass "Package.swift declares product ElektronCapture (swift not installed; dump-package skipped)"
fi

# InspectionSession production sources must live in the package target (App/), not the app shell.
for req in \
  "App/Domain/Models/InspectionSession.swift" \
  "App/Phase1/Inspection/InspectionSessionService.swift" \
  "App/Phase1/Inspection/CurrentSessionRepository.swift"
do
  [[ -f "$ROOT/$req" ]] || fail "missing package source required for InspectionSession: $req"
done
grep -q 'struct InspectionSessionEvidenceContext' "$ROOT/App/Domain/Models/InspectionSession.swift" \
  || fail "InspectionSessionEvidenceContext missing from package InspectionSession.swift"
pass "Package target includes InspectionSession domain + service sources"

PBX="$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj/project.pbxproj"
[[ -f "$PBX" ]] || fail "Phase1StillCapture.xcodeproj missing"
pass "Phase1StillCapture.xcodeproj exists"

# --- Stale / absolute package path gate (committed Xcode metadata only) ---
XCODE_META_PATHS=(
  "$PBX"
  "$ROOT/Phase1StillCapture.xcworkspace/contents.xcworkspacedata"
  "$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace/contents.xcworkspacedata"
)
# Optional SPM / workspace sidecars if ever committed
while IFS= read -r -d '' f; do
  XCODE_META_PATHS+=("$f")
done < <(find "$ROOT/Apps/Phase1StillCapture" "$ROOT/Phase1StillCapture.xcworkspace" \
  \( -name 'Package.resolved' -o -name 'workspace-state.json' -o -name '*.xcscmblueprint' \) \
  -print0 2>/dev/null || true)

for meta in "${XCODE_META_PATHS[@]}"; do
  [[ -f "$meta" ]] || continue
  if grep -nE 'elektron-capture-ios-OLD' "$meta" >/dev/null 2>&1; then
    fail "stale elektron-capture-ios-OLD reference in ${meta#"$ROOT"/}"
  fi
  # Absolute developer filesystem paths (portable ZIP must not embed these).
  if grep -nE '(/Users/|/home/|file:///Users/|file:///home/)' "$meta" >/dev/null 2>&1; then
    fail "absolute filesystem path committed in ${meta#"$ROOT"/} — use relative local package refs only"
  fi
  if grep -nE 'Downloads/.+elektron-capture' "$meta" >/dev/null 2>&1; then
    fail "Downloads checkout path committed in ${meta#"$ROOT"/}"
  fi
done
pass "no absolute / stale OLD package path in committed Xcode metadata"

# Exactly one local package reference in the app project
LOCAL_PKG_COUNT=$(grep -c 'isa = XCLocalSwiftPackageReference' "$PBX" || true)
[[ "$LOCAL_PKG_COUNT" -eq 1 ]] || fail "expected exactly 1 XCLocalSwiftPackageReference in pbxproj, found $LOCAL_PKG_COUNT"
pass "pbxproj has exactly one XCLocalSwiftPackageReference"

grep -q 'productName = ElektronCapture' "$PBX" || fail "pbxproj missing productName = ElektronCapture"
pass "pbxproj productName = ElektronCapture"

# relativePath must resolve to repo root from the directory containing the .xcodeproj
PROJ_DIR="$ROOT/Apps/Phase1StillCapture"
REL=$(grep -E 'relativePath = ' "$PBX" | head -1 | sed 's/.*relativePath = //;s/;//;s/ //g')
[[ -n "$REL" ]] || fail "relativePath not found in pbxproj"
RESOLVED="$(cd "$PROJ_DIR" && realpath "$REL")"
[[ "$RESOLVED" == "$ROOT" ]] || fail "relativePath '$REL' from Apps/Phase1StillCapture resolves to '$RESOLVED', expected '$ROOT'"
[[ -f "$RESOLVED/Package.swift" ]] || fail "resolved package root has no Package.swift"
pass "relativePath '$REL' resolves to repo root with Package.swift (portable)"

# --- Authoritative workspace ---
WS_ROOT="$ROOT/Phase1StillCapture.xcworkspace"
WS_APP="$ROOT/Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace"
WS_ROOT_DATA="$WS_ROOT/contents.xcworkspacedata"
[[ -f "$WS_ROOT_DATA" ]] || fail "authoritative workspace missing: Phase1StillCapture.xcworkspace/contents.xcworkspacedata"

grep -q 'Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj' "$WS_ROOT_DATA" \
  || fail "root workspace must reference Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj"
# self: attaches the workspace container (repo root) so SPM sees Package.swift portably
grep -q 'location = "self:"' "$WS_ROOT_DATA" \
  || fail "root workspace must include location = \"self:\" (repo-local Package.swift)"
pass "authoritative workspace Phase1StillCapture.xcworkspace points at xcodeproj + repo-local package (self:)"

if [[ -f "$WS_APP/contents.xcworkspacedata" ]]; then
  grep -q 'location = "group:../.."' "$WS_APP/contents.xcworkspacedata" \
    || fail "nested app workspace must use relative group:../.. for package (no absolute paths)"
  pass "nested app workspace uses relative package ref group:../.. (secondary entry point)"
fi

WORKSPACE="$WS_ROOT"
pass "using authoritative workspace for build gate: Phase1StillCapture.xcworkspace"

# --- App module imports ---
# Any app compile unit that references ElektronCapture public types must import the module.
# `swift build` will not catch a missing app-target import.
APP_SWIFT_DIR="$ROOT/Apps/Phase1StillCapture"
[[ -d "$APP_SWIFT_DIR" ]] || fail "Apps/Phase1StillCapture missing"

# Package type names observed in the app shell (extend when new package APIs are consumed).
# Word-bounded package symbols only (do not treat app-local InspectionSessionViewModel as a package type).
PACKAGE_TYPE_RE='\bInspectionSession\b|\bInspectionSessionService\b|\bInspectionSessionEvidenceContext\b|\bFileCurrentSessionRepository\b|\bPhase1CaptureCoordinator\b|\bPhase1CaptureIdentifiers\b|\bPhase1CaptureDiagnostics\b|\bEvidenceLibraryStore\b|\bEvidenceLibraryPaths\b|\bEvidenceLibraryIndexRecord\b|\bCameraPreviewView\b|\bDeviceCapabilitySnapshot\b|\bDeviceCapabilitySnapshotProviding\b|\bAppleDeviceCapabilitySnapshotService\b|\bCaptureClockService\b|\bMotionSampleRecord\b|\bArtifactHashingService\b'

IMPORT_FAIL=0
while IFS= read -r -d '' f; do
  base="$(basename "$f")"
  # Skip files with no package-type references
  if ! grep -E "$PACKAGE_TYPE_RE" "$f" >/dev/null 2>&1; then
    continue
  fi
  if grep -q 'import ElektronCapture' "$f"; then
    pass "$base imports ElektronCapture"
  else
    echo "FAIL: $base references ElektronCapture types but lacks 'import ElektronCapture'" >&2
    IMPORT_FAIL=1
  fi
done < <(find "$APP_SWIFT_DIR" -maxdepth 1 -name '*.swift' -print0)

[[ "$IMPORT_FAIL" -eq 0 ]] || fail "one or more app sources missing import ElektronCapture (see FAIL lines above)"

# Explicit named gate for the Sprint 1 ViewModel (this was the reported breakage).
VM="$APP_SWIFT_DIR/InspectionSessionViewModel.swift"
[[ -f "$VM" ]] || fail "missing InspectionSessionViewModel.swift"
grep -q 'import ElektronCapture' "$VM" \
  || fail "InspectionSessionViewModel.swift references InspectionSession types without importing ElektronCapture"
pass "InspectionSessionViewModel.swift imports ElektronCapture"

# Package-boundary visibility: app-consumed package types must be `public`.
require_public_package_symbol() {
  local symbol="$1"
  local decl_file="$2"
  if ! grep -R -n --include='*.swift' -E "\\b${symbol}\\b" "$APP_SWIFT_DIR" >/dev/null 2>&1; then
    return 0
  fi
  [[ -f "$decl_file" ]] || fail "app uses ${symbol} but declaration file missing: $decl_file"
  grep -qE "public[[:space:]]+(final[[:space:]]+)?(struct|class|enum|actor)[[:space:]]+${symbol}\\b" "$decl_file" \
    || fail "app uses ${symbol} but ${decl_file} does not declare it public (package-boundary visibility)"
  pass "app-consumed symbol ${symbol} is public in package"
}

require_public_package_symbol \
  "CameraPreviewView" \
  "$ROOT/App/Capture/AVFoundation/CameraPreviewView.swift"
require_public_package_symbol \
  "InspectionSession" \
  "$ROOT/App/Domain/Models/InspectionSession.swift"
require_public_package_symbol \
  "InspectionSessionService" \
  "$ROOT/App/Phase1/Inspection/InspectionSessionService.swift"

# Target membership
grep -q 'InspectionSessionViewModel.swift in Sources' "$PBX" \
  || fail "InspectionSessionViewModel.swift not in app Sources build phase"
pass "InspectionSessionViewModel.swift is in app Sources"
grep -q 'Phase1CaptureRootView.swift in Sources' "$PBX" \
  || fail "Phase1CaptureRootView.swift not in app Sources build phase"
pass "Phase1CaptureRootView.swift is in app Sources"

# Frameworks / package product linkage
grep -q 'ElektronCapture in Frameworks' "$PBX" || fail "pbxproj missing ElektronCapture in Frameworks build file"
pass "pbxproj links ElektronCapture in Frameworks"
grep -q 'packageProductDependencies' "$PBX" || fail "pbxproj missing packageProductDependencies"
grep -q 'productName = ElektronCapture' "$PBX" \
  || fail "pbxproj missing ElektronCapture package product dependency entry"
pass "pbxproj packageProductDependencies includes ElektronCapture"

# Guard: package sources must not be duplicated into the app target Sources list
if grep -E 'InspectionSession\.swift in Sources|InspectionSessionService\.swift in Sources' "$PBX" >/dev/null 2>&1; then
  fail "pbxproj must not compile package InspectionSession sources into the app target (import ElektronCapture instead)"
fi
pass "app target does not duplicate InspectionSession package sources"

echo
echo "HANDOFF_LAYOUT_OK"
echo "AUTHORITATIVE_WORKSPACE=Phase1StillCapture.xcworkspace"

# --- Xcode app build gate (Darwin) ---
EVIDENCE_DIR="${VERIFY_XCODE_EVIDENCE_DIR:-$ROOT/Docs/Evidence/XCODE_APP_BUILD}"
if command -v xcodebuild >/dev/null 2>&1; then
  mkdir -p "$EVIDENCE_DIR"
  BUILD_LOG="$EVIDENCE_DIR/xcodebuild-clean-build.log"
  SETTINGS_LOG="$EVIDENCE_DIR/xcodebuild-showBuildSettings.txt"
  LINKAGE_LOG="$EVIDENCE_DIR/xcodebuild-package-linkage-excerpt.txt"

  echo "=== xcodebuild clean build (authoritative workspace, unsigned Simulator) ==="
  echo "workspace=$WORKSPACE scheme=Phase1StillCapture"
  echo "destination=generic/platform=iOS Simulator"
  echo "CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO"
  echo "NOTE: Physical-device signing / DEVELOPMENT_TEAM is NOT required for this bootstrap gate."
  echo "      Use Scripts/device-preflight.sh for real iPhone builds."
  xcodebuild \
    -workspace "$WORKSPACE" \
    -scheme Phase1StillCapture \
    -destination 'generic/platform=iOS Simulator' \
    -configuration Debug \
    -derivedDataPath "$EVIDENCE_DIR/DerivedData" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    clean build \
    2>&1 | tee "$BUILD_LOG"

  grep -q 'BUILD SUCCEEDED' "$BUILD_LOG" || fail "xcodebuild did not report BUILD SUCCEEDED (see $BUILD_LOG)"
  pass "xcodebuild clean build succeeded (generic iOS Simulator, unsigned)"

  echo "=== xcodebuild -showBuildSettings (package linkage excerpt) ==="
  xcodebuild \
    -workspace "$WORKSPACE" \
    -scheme Phase1StillCapture \
    -destination 'generic/platform=iOS Simulator' \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    -showBuildSettings \
    2>&1 | tee "$SETTINGS_LOG" >/dev/null

  grep -E 'ElektronCapture|PACKAGE_FRAMEWORKS|FRAMEWORK_SEARCH_PATHS|SWIFT_INCLUDE_PATHS|PRODUCT_MODULE_NAME' \
    "$SETTINGS_LOG" | tee "$LINKAGE_LOG" || true

  if grep -q 'ElektronCapture' "$SETTINGS_LOG"; then
    pass "showBuildSettings mentions ElektronCapture"
  else
    warn "showBuildSettings did not mention ElektronCapture — inspect $SETTINGS_LOG"
  fi

  echo
  echo "HANDOFF_XCODE_BUILD_OK"
  echo "Evidence: $EVIDENCE_DIR"
else
  skip "xcodebuild not available on this host ($(uname -s))"
  skip "Mac operator must run workspace clean build + -showBuildSettings before claiming app integration"
  echo
  echo "HANDOFF_XCODE_BUILD_SKIPPED"
  echo "Layout gate passed; app-target compile gate NOT executed on this host."
fi

echo
echo "Open the authoritative workspace:"
echo "  open Phase1StillCapture.xcworkspace"
echo "  make open"
echo "Do NOT open Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj alone as the primary workflow."
echo "Nested Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace is secondary only."
echo "If Xcode still shows Missing package product: File → Packages → Reset Package Caches, then resolve."
echo "If an old absolute checkout appears, reset package caches and confirm relativePath ../.. in the pbxproj."
