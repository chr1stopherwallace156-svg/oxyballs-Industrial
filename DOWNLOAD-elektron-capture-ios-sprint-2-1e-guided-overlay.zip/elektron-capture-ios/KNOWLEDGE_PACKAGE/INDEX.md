# KNOWLEDGE_PACKAGE — Stage 1 index (tracked)

This directory holds **pointers and overview stubs** committed with the source tree.
The full EKP tree is assembled only into `dist/EKP-CAPTURE-*/Capture/` by `make ekp-package`.

| Stub | Maps into EKP as |
|---|---|
| `Overview.md` | `Capture/Overview.md` |
| `INDEX.md` | packaging manifest notes |
| `CurrentStatus/` | filled from `PROJECT_STATE.md` at package time |
| `Instructions/` | freeze / validation pointers |

Source-of-truth trees copied at package time: `Specifications/`, `Research/`, `Docs/`,
`CHANGELOG.md`, `CAPTURE_IMPLEMENTATION_HANDOFF.md`, `REPOSITORY_MEMORY.md`, `Docs/Decisions/`.
