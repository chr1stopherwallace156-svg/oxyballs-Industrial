# Current Status (EKP stub)

Authoritative executive snapshot lives at repository root: `PROJECT_STATE.md`.
`make ekp-package` copies it to `Capture/Current Status.md` inside the envelope.
