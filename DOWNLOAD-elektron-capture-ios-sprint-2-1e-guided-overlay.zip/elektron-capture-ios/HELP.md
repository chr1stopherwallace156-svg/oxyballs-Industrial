# elektron-capture-ios — Developer command dictionary

**Post-extraction terminal workflow (fresh ZIP / new folder):**

```bash
cd "/path/to/elektron-capture-ios"
make xcode-ready
```

Validate and open Xcode in one operation:

```bash
make xcode-open
```

Read-only diagnostics:

```bash
make xcode-ready-check
```

Deeper narrowly scoped cache reset:

```bash
make xcode-ready-deep
```

**Double-click workflow (macOS):** double-click `START-HERE.command`. It validates the extracted repository and opens the root `Phase1StillCapture.xcworkspace` only after all gates pass.

A newly extracted ZIP may have a new absolute path. Xcode can retain stale package and DerivedData state from an older extraction. `make xcode-ready` distinguishes local-environment failures from source-code failures. Physical-iPhone validation remains a separate gate (`make device-preflight` / `Scripts/device-preflight.sh`). Bootstrap / handoff verification builds use **unsigned** `-destination "generic/platform=iOS Simulator"` and do **not** require `DEVELOPMENT_TEAM`.

### macOS Gatekeeper / quarantine (downloaded ZIPs)

Downloaded `.command` files are often quarantined. Scripts **do not** clear quarantine automatically.

**Preferred:**

1. Right-click `START-HERE.command`
2. Choose **Open**
3. Confirm **Open** in the dialog

**Terminal fallback** (from the repository root):

```bash
xattr -d com.apple.quarantine START-HERE.command
```

Then double-click again, or run `make xcode-open`.

**Important:** Quarantine may block `START-HERE.command` **before** the script launches, so its own failure handler cannot run. Use Right-click → Open (or `xattr`) first if macOS refuses to start the command. After the script has launched, failures inside bootstrap print `make xcode-ready` and the same `xattr` recovery note.

**Help menu:**

```bash
cd "<path-to-elektron-capture-ios>"
make help
# or:
./Scripts/help.sh
```

This file is the full dictionary. `Scripts/help.sh` and `make help` print categorized short menus that point here.

**Intent runbook:** `OPERATIONS_MANUAL.md`  
**Error classes:** `Docs/ERROR_DICTIONARY.md`  
**Verification states:** `Docs/VERIFICATION_STATES.md`

### Ops guardrail commands (layered system)

```bash
make help
make doctor
make verify-handoff
make device-preflight
make repo-locator
make diagnose MSG="Cannot find CameraPreviewView in scope"
make evidence-status
make record-device-validation
make package-check PKG="/path/to/file.edts-pkg"
make repair-derived-data
make repair-package-cache
make ops-system-check
```

Flow: **HELP → DOCTOR → PREFLIGHT → ACTION → EVIDENCE → STATUS → SAFE RECOVERY**

Automated scripts never claim physical-device runtime success or `PHASE_APPROVED`.

---

## 0. Safety rules

- Quote every path that might contain spaces: `"$HOME/Downloads/elektron-capture-ios"`.
- Prefer the **root workspace**: `Phase1StillCapture.xcworkspace` for daily Xcode work.
- `make xcode-ready` / `START-HERE.command` open the **root** `Phase1StillCapture.xcworkspace` after bootstrap verification (same as `make open`).
- `make clean` only removes repo-local Swift `.build` and an optional DerivedData folder under this repo — never your whole Disk DerivedData unless you explicitly choose that command after reading the warning.
- Help scripts **display** commands only; they do not delete files or install apps.
- Bootstrap never deletes source, Git history, Docs/Evidence, or user documents. Paths are resolved from the script location (no hard-coded `/Users/...`).

---

## 0a. Post-extraction Xcode bootstrap

Use this after downloading or unzipping into a **new folder**.

### cmd: xcode-ready
| | |
|---|---|
| **Exact command** | `make xcode-ready` |
| **Where** | Repo root (or `make -f "/path/to/Makefile" xcode-ready` from a nested folder) |
| **What it does** | Runs `Scripts/xcode-ready.sh`: identity + linkage + import checks, orchestrates `doctor.sh` + `verify-xcode-handoff.sh`, safe `.build`/DerivedData cleanup, `swift build`/`swift test`, and (on Mac) unsigned `-destination "generic/platform=iOS Simulator"` `xcodebuild` |
| **Expected success** | Prints `XCODE_READY` with zero FAIL lines |
| **Common failure** | Incomplete unzip / wrong folder / missing Xcode on Mac / Gatekeeper quarantine on `START-HERE.command` |
| **Fix** | Confirm `Package.swift` at root; install Xcode; Gatekeeper: Right-click → Open (or `xattr -d com.apple.quarantine START-HERE.command`); re-run `make xcode-ready-deep` if package caches are stale. `DEVELOPMENT_TEAM` is **not** required for this command. |

### cmd: xcode-open
| | |
|---|---|
| **Exact command** | `make xcode-open` |
| **Where** | Repo root (Mac) |
| **What it does** | Full `xcode-ready` bootstrap, then opens root `Phase1StillCapture.xcworkspace` |
| **Expected success** | `XCODE_READY` then Xcode launches |
| **Alias** | Double-click `START-HERE.command` |

### cmd: xcode-ready-deep
| | |
|---|---|
| **Exact command** | `make xcode-ready-deep` |
| **Where** | Repo root |
| **What it does** | Same as `xcode-ready` plus narrowly scoped project SourcePackages / repo-local `.swiftpm` cleanup (never wipes all global DerivedData or all of `org.swift.swiftpm`) |
| **Expected success** | `XCODE_READY` |

### cmd: xcode-ready-check
| | |
|---|---|
| **Exact command** | `make xcode-ready-check` |
| **Where** | Repo root |
| **What it does** | Read-only diagnostics (`--check-only`); no deletions or builds |
| **Expected success** | `XCODE_READY_CHECK_ONLY` |

---

## 1. Repository navigation

### cmd: where-am-i
| | |
|---|---|
| **Exact command** | `pwd` |
| **Where** | Any shell, ideally inside the repo |
| **What it does** | Prints the current working directory |
| **Expected success** | A path ending in `elektron-capture-ios` (or your clone folder name) |
| **Common failure** | Path is `Downloads` or home — you are not in the repo yet |
| **Fix** | `cd "<full-path-to-repo>"` then `pwd` again |

### cmd: enter-repo
| | |
|---|---|
| **Exact command** | `cd "<path-to-elektron-capture-ios>"` |
| **Where** | Terminal |
| **What it does** | Enters the repository root |
| **Expected success** | Next `pwd` shows the repo; `ls Package.swift` succeeds |
| **Common failure** | `No such file or directory` (wrong path / spaces unquoted) |
| **Fix** | Use quotes; locate with `find` (section 2) |

### cmd: confirm-root-files
| | |
|---|---|
| **Exact command** | `test -f Package.swift && test -d Phase1StillCapture.xcworkspace && test -f Apps/Phase1StillCapture/Phase1CaptureRootView.swift && echo ROOT_OK` |
| **Where** | Repo root |
| **What it does** | Confirms package + root workspace + app source exist |
| **Expected success** | `ROOT_OK` |
| **Common failure** | No output / exit 1 — wrong folder or incomplete unzip |
| **Fix** | Re-download ZIP; unzip again; `cd` into `elektron-capture-ios` |

---

## 2. Locating workspaces (paths with spaces)

### cmd: find-workspace-downloads
| | |
|---|---|
| **Exact command** | `find "$HOME/Downloads" -name "Phase1StillCapture.xcworkspace" -print` |
| **Where** | Any directory |
| **What it does** | Finds workspaces under Downloads |
| **Expected success** | One or more paths; prefer the one next to `Package.swift` (repo root) |
| **Common failure** | Empty — not downloaded / different folder |
| **Fix** | Search Desktop/Documents; check unzip created a nested folder |

### cmd: find-preview-source
| | |
|---|---|
| **Exact command** | `find "$HOME/Downloads" -path "*/App/Capture/AVFoundation/CameraPreviewView.swift" -print` |
| **Where** | Any directory |
| **What it does** | Finds the package preview source (proves you have the full tree) |
| **Expected success** | Path under `…/elektron-capture-ios/App/Capture/AVFoundation/` |
| **Common failure** | Empty — incomplete archive |
| **Fix** | Use the regenerated import/preview ZIP from Industrial handoff |

### cmd: open-correct-workspace
| | |
|---|---|
| **Exact command** | `open Phase1StillCapture.xcworkspace` |
| **Where** | **Repo root** (Mac) |
| **What it does** | Opens the root Xcode workspace (app + local package) |
| **Expected success** | Xcode opens; scheme `Phase1StillCapture` available |
| **Common failure** | `open: command not found` (Linux) or opens wrong folder |
| **Fix** | Run on Mac; ensure `pwd` is repo root; use `make open` |

**Alias:** `make open`

**Do not** use `open Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj` as the primary entry — use the **workspace**.

---

## 3. Swift package build & tests

### cmd: swift-build
| | |
|---|---|
| **Exact command** | `swift build` |
| **Where** | Repo root |
| **What it does** | Compiles the `ElektronCapture` Swift package only |
| **Expected success** | `Build complete!` |
| **Common failure** | Missing toolchain; compile errors in `App/` |
| **Fix** | Install Swift; read error file/line; do **not** treat this as an Xcode app build |

**Alias:** `make build`

### cmd: swift-test
| | |
|---|---|
| **Exact command** | `swift test` |
| **Where** | Repo root |
| **What it does** | Runs unit + golden package tests |
| **Expected success** | `Test Suite 'All tests' passed` (Linux may show 1 documented skip) |
| **Common failure** | Test failures; missing fixtures |
| **Fix** | Re-run with full log; do not delete tests |

**Alias:** `make test`

### cmd: golden-tests-only
| | |
|---|---|
| **Exact command** | `swift test --filter GoldenEvidencePackageTests` |
| **Where** | Repo root |
| **What it does** | Runs golden evidence package tests only |
| **Expected success** | Golden suite passed |
| **Common failure** | Filter matches nothing |
| **Fix** | Check test target name; run full `swift test` |

---

## 4. Handoff & package verification

### cmd: verify-xcode-handoff
| | |
|---|---|
| **Exact command** | `./Scripts/verify-xcode-handoff.sh` |
| **Where** | Repo root |
| **What it does** | Checks package product, workspace, app imports, public `CameraPreviewView`, pbxproj linkage; on Mac also runs `xcodebuild` |
| **Expected success** | `HANDOFF_LAYOUT_OK`; on Mac also `HANDOFF_XCODE_BUILD_OK` |
| **Common failure** | Missing import / internal package type / wrong relativePath |
| **Fix** | Read FAIL line; restore `import ElektronCapture`; ensure `public struct CameraPreviewView` |

**Alias:** `make verify`

### cmd: validate-contracts
| | |
|---|---|
| **Exact command** | `./Scripts/validate-contracts` |
| **Where** | Repo root |
| **What it does** | Validates contract schemas / ownership rules |
| **Expected success** | Exit 0; script success messages |
| **Common failure** | Permission denied / schema errors |
| **Fix** | `chmod +x ./Scripts/validate-contracts`; fix reported schema path |

### cmd: verify-evidence-package
| | |
|---|---|
| **Exact command** | `./Scripts/verify-evidence-package "<path-to-package-dir-or-zip>"` |
| **Where** | Repo root |
| **What it does** | Runs capture-side package verification helpers (see script `--help` / usage) |
| **Expected success** | Exit 0 |
| **Common failure** | Wrong argument path |
| **Fix** | Pass a real package directory or supported archive path |

### cmd: verify-help-system
| | |
|---|---|
| **Exact command** | `./Scripts/verify-help-system.sh` |
| **Where** | Repo root |
| **What it does** | Confirms HELP.md / help.sh / Makefile / documented scripts exist and help exits 0 |
| **Expected success** | `HELP_SYSTEM_OK` |
| **Common failure** | Missing file / non-executable help.sh |
| **Fix** | Restore files from tip; `chmod +x Scripts/help.sh Scripts/verify-help-system.sh` |

---

## 5. Xcode app build (Mac)

### cmd: xcode-build
| | |
|---|---|
| **Exact command** | `xcodebuild -workspace Phase1StillCapture.xcworkspace -scheme Phase1StillCapture -destination 'generic/platform=iOS' clean build` |
| **Where** | Repo root (Mac with Xcode) |
| **What it does** | Clean-compiles the **app** target + linked package |
| **Expected success** | `BUILD SUCCEEDED` |
| **Common failure** | `Cannot find '…' in scope`; signing; missing package product |
| **Fix** | `import ElektronCapture`; `public` package types; File → Packages → Reset Package Caches; open **workspace** not project |

**Alias:** `make xcode-build`  
**Linux:** Not available — do not claim success from Linux.

### cmd: show-build-settings-linkage
| | |
|---|---|
| **Exact command** | `xcodebuild -workspace Phase1StillCapture.xcworkspace -scheme Phase1StillCapture -showBuildSettings \| grep -E 'ElektronCapture\|PACKAGE\|FRAMEWORK_SEARCH\|LIBRARY_SEARCH\|SWIFT_INCLUDE'` |
| **Where** | Repo root (Mac) |
| **What it does** | Filters settings relevant to package linkage |
| **Expected success** | Lines mentioning `ElektronCapture` / framework search paths |
| **Common failure** | Empty grep — product not linked / wrong scheme |
| **Fix** | Confirm scheme `Phase1StillCapture`; check pbxproj Frameworks |

### cmd: device-build
| | |
|---|---|
| **Exact command** | `xcodebuild -workspace Phase1StillCapture.xcworkspace -scheme Phase1StillCapture -sdk iphoneos -destination 'generic/platform=iOS' build` |
| **Where** | Repo root (Mac) |
| **What it does** | Produces a signed **device** build artifact when signing is configured |
| **Expected success** | `BUILD SUCCEEDED` (compile/sign only) |
| **Common failure** | Code signing / provisioning / no team |
| **Fix** | Xcode → Signing & Capabilities → Team; do **not** treat build success as “app ran on phone” |

**Alias:** `make device-build`  
**Note:** This does **not** claim runtime capture success. Use Xcode **Run** (⌘R) on a connected iPhone for install+launch.

### cmd: simulator-test
| | |
|---|---|
| **Exact command** | `xcodebuild test -workspace Phase1StillCapture.xcworkspace -scheme Phase1StillCapture -destination 'platform=iOS Simulator,name=iPhone 16' ` |
| **Where** | Repo root (Mac) |
| **What it does** | Runs tests on an **iOS Simulator** destination |
| **Expected success** | `TEST SUCCEEDED` (if the scheme defines tests) |
| **Common failure** | Destination name missing; scheme has no test action |
| **Fix** | `xcrun simctl list devices available`; prefer `swift test` for package unit tests; **do not** point this at a physical device |

**Alias:** `make simulator-test`

---

## 6. Xcode UI cheat sheet (Mac)

| Action | Shortcut | Meaning |
|---|---|---|
| Install & run on selected device | ⌘R | Runtime on iPhone/Simulator |
| Build only | ⌘B | Compile; does not prove capture flow |
| Test | ⌘U | Prefer Simulator / package `swift test` |

Scheme: **Phase1StillCapture**  
Destination for acceptance capture: **physical iPhone**

---

## 7. Cleaning caches (safe)

### cmd: clean-swift-build
| | |
|---|---|
| **Exact command** | `rm -rf .build` |
| **Where** | Repo root |
| **What it does** | Deletes local SPM build products only |
| **Expected success** | `.build` gone; next `swift build` recompiles |
| **Common failure** | Permission denied |
| **Fix** | Ensure you own the repo folder |

**Alias:** `make clean` (prompts / explains before deleting `.build` and `build/`)

### cmd: clean-repo-derived-data
| | |
|---|---|
| **Exact command** | `rm -rf "./Docs/Evidence/XCODE_APP_BUILD/DerivedData"` |
| **Where** | Repo root |
| **What it does** | Removes DerivedData created by `verify-xcode-handoff.sh` under this repo |
| **Expected success** | Folder removed if present |
| **Common failure** | Path did not exist (OK) |
| **Fix** | None required |

### cmd: reset-package-caches-xcode
| | |
|---|---|
| **Exact command** | *(Xcode menu)* File → Packages → Reset Package Caches; then Resolve Package Versions |
| **Where** | Xcode with workspace open |
| **What it does** | Clears SPM resolution glitches for the local package |
| **Expected success** | `ElektronCapture` resolves; Missing package product disappears |
| **Common failure** | Still missing product |
| **Fix** | Close Xcode; reopen `Phase1StillCapture.xcworkspace` from repo root |

---

## 8. Signing configuration (Mac)

### cmd: check-signing-ui
| | |
|---|---|
| **Exact command** | Open workspace → select target **Phase1StillCapture** → Signing & Capabilities |
| **Where** | Xcode |
| **What it does** | Shows Team / Bundle ID / provisioning |
| **Expected success** | Team selected; no red signing errors |
| **Common failure** | “Failed to register bundle identifier” / no Team |
| **Fix** | Add Apple ID in Xcode Settings → Accounts; enable Automatic signing |

---

## 9. Exported `.edts-pkg` — locate & inspect

On device, packages are typically under the app Documents tree (Files app → On My iPhone → Elektron Capture…), often mirrored via Share / AirDrop to Mac as `EVD-….edts-pkg`.

### cmd: find-edts-pkg
| | |
|---|---|
| **Exact command** | `find "$HOME/Downloads" -name "*.edts-pkg" -print` |
| **Where** | Mac |
| **What it does** | Locates AirDropped / saved packages |
| **Expected success** | One or more `.edts-pkg` paths |
| **Common failure** | Empty — not shared yet |
| **Fix** | In app: Share .edts-pkg or Save to Files; AirDrop to Mac |

### cmd: list-edts-pkg
| | |
|---|---|
| **Exact command** | `unzip -l "<package>.edts-pkg"` |
| **Where** | Directory containing the file |
| **What it does** | Lists ZIP transport contents (`.edts-pkg` is ZIP transport) |
| **Expected success** | Entries including `manifest.json`, `package_inventory.json`, `payload/artifact_original.jpg` (Phase 1 minimum) |
| **Common failure** | `cannot find zipfile` — path wrong / spaces unquoted |
| **Fix** | Quote the path; confirm file exists with `ls -la "<package>.edts-pkg"` |

### cmd: show-manifest
| | |
|---|---|
| **Exact command** | `unzip -p "<package>.edts-pkg" manifest.json` |
| **Where** | Same |
| **What it does** | Prints canonical manifest JSON |
| **Expected success** | JSON on stdout |
| **Common failure** | `caution: filename not matched` — layout differs |
| **Fix** | Re-list with `unzip -l`; use the exact entry path shown |

### cmd: show-inventory
| | |
|---|---|
| **Exact command** | `unzip -p "<package>.edts-pkg" package_inventory.json` |
| **Where** | Same |
| **What it does** | Prints package inventory JSON |
| **Expected success** | JSON with `entries` (inventory itself is omitted from entries by Phase 1 policy) |
| **Common failure** | Missing entry |
| **Fix** | Confirm export completed; re-export from app |

### cmd: extract-artifact-jpeg
| | |
|---|---|
| **Exact command** | `unzip -p "<package>.edts-pkg" payload/artifact_original.jpg > artifact_original.jpg` |
| **Where** | Working directory for output |
| **What it does** | Extracts the authoritative JPEG bytes |
| **Expected success** | Non-empty `artifact_original.jpg`; `file artifact_original.jpg` reports JPEG |
| **Common failure** | Zero-byte file / path mismatch |
| **Fix** | Check `unzip -l` for exact payload path |

### cmd: sha256-package
| | |
|---|---|
| **Exact command** | `shasum -a 256 "<package>.edts-pkg"` |
| **Where** | Same |
| **What it does** | Hashes the transport ZIP file (not the evidence identity of the JPEG) |
| **Expected success** | Hex digest + filename |
| **Common failure** | File not found |
| **Fix** | Quote path |

### cmd: sha256-artifact
| | |
|---|---|
| **Exact command** | `shasum -a 256 artifact_original.jpg` |
| **Where** | After extract |
| **What it does** | Hashes the JPEG; must match the frozen post-delegate SHA from capture/review |
| **Expected success** | Digest equals in-app frozen SHA |
| **Common failure** | Mismatch — wrong file or re-encoded image |
| **Fix** | Re-export without Photos round-trip; do not open/re-save in Preview before hashing |

**Optional** (not guaranteed in every Phase 1 package; only if listed by `unzip -l`):

```bash
unzip -p "<package>.edts-pkg" package_status.json
unzip -p "<package>.edts-pkg" sidecars/camera_calibration.json   # optional
unzip -p "<package>.edts-pkg" sidecars/avcapture_metadata.json  # optional
```

---

## 10. Viewing build evidence

### cmd: list-xcode-evidence
| | |
|---|---|
| **Exact command** | `ls -la Docs/Evidence/XCODE_APP_BUILD 2>/dev/null \|\| echo "No Xcode evidence dir yet (run verify on Mac)"` |
| **Where** | Repo root |
| **What it does** | Shows logs written by `verify-xcode-handoff.sh` on Darwin |
| **Expected success** | `xcodebuild-clean-build.log`, `xcodebuild-showBuildSettings.txt` |
| **Common failure** | Missing on Linux clones |
| **Fix** | Run `./Scripts/verify-xcode-handoff.sh` on Mac |

---

## 11. Common errors → exact fixes

| Error | Meaning | Fix |
|---|---|---|
| `Cannot find 'Phase1StillCaptureUIState' in scope` (etc.) | App file missing `import ElektronCapture` | Add `import ElektronCapture` to that app `.swift` |
| `Cannot find 'CameraPreviewView' in scope` | Type not `public` across package boundary | Ensure `public struct CameraPreviewView` in package; rebuild |
| `Missing package product 'ElektronCapture'` | Workspace/package resolution | Open **root** `Phase1StillCapture.xcworkspace`; Reset Package Caches |
| `swift build` green but Xcode red | SPM ≠ app target | Always run `make xcode-build` / verifier on Mac |
| `xcodebuild: error: …` on Linux | No Xcode | Use Mac; Linux only does SPM + layout gates |
| Signing / provisioning errors | No Team | Xcode Accounts + Automatic signing |
| `Permission denied: ./Scripts/…` | Not executable | `chmod +x ./Scripts/<name>` |
| `unzip: cannot find zipfile` | Bad path / spaces | Quote: `unzip -l "$HOME/Downloads/My File.edts-pkg"` |

---

## 12. Make targets (summary)

| Target | Purpose |
|---|---|
| `make help` | Default — short menu |
| `make open` | Open root workspace (Mac) |
| `make build` | `swift build` |
| `make test` | `swift test` |
| `make verify` | `./Scripts/verify-xcode-handoff.sh` |
| `make xcode-build` | App clean build (Mac) |
| `make simulator-test` | Simulator tests (Mac) |
| `make device-build` | iphoneos build only (Mac; not runtime) |
| `make clean` | Remove repo `.build` / local build dirs (explained first) |
| `make package-help` | `.edts-pkg` inspection cheat sheet |
| `make export-help` | Export / share workflow reminders |
| `make troubleshoot` | Common errors |

---

## 13. Help script topics

```bash
./Scripts/help.sh              # menu
./Scripts/help.sh build
./Scripts/help.sh test
./Scripts/help.sh xcode
./Scripts/help.sh device
./Scripts/help.sh export
./Scripts/help.sh package
./Scripts/help.sh troubleshoot
```

Help **only prints** commands. It never deletes data or runs destructive cleans.
