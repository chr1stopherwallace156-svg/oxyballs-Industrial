import Foundation

/// In-process registry of immutable plan templates (Sprint 2.0).
/// JSON Plan Builder loading is intentionally deferred.
public struct InspectionPlanRegistry: Sendable {
  private let plansByKey: [String: InspectionPlan]

  public init(plans: [InspectionPlan] = InspectionPlanRegistry.defaultTemplates) {
    var map: [String: InspectionPlan] = [:]
    for plan in plans {
      map[Self.key(id: plan.id, version: plan.version)] = plan
    }
    self.plansByKey = map
  }

  public var allPlans: [InspectionPlan] {
    plansByKey.values.sorted {
      if $0.title != $1.title { return $0.title < $1.title }
      return $0.version < $1.version
    }
  }

  public func plan(id: InspectionPlanID, version: String) throws -> InspectionPlan {
    let key = Self.key(id: id, version: version)
    guard let plan = plansByKey[key] else {
      throw InspectionPlanError.planNotFound("\(id.rawValue)@\(version)")
    }
    try InspectionPlanValidator.validate(plan)
    return plan
  }

  public func plan(id: String, version: String) throws -> InspectionPlan {
    try plan(id: InspectionPlanID(rawValue: id), version: version)
  }

  private static func key(id: InspectionPlanID, version: String) -> String {
    "\(id.rawValue)@\(version)"
  }

  // MARK: - Seed templates

  public static let defaultTemplates: [InspectionPlan] = {
    do {
      return [
        try makeStandardCommercialIntake(),
        try makeQuick4Point(),
      ]
    } catch {
      preconditionFailure("Default inspection plans failed validation: \(error)")
    }
  }()

  public static var defaultPlanID: InspectionPlanID {
    InspectionPlanID.unchecked("standard_commercial_intake")
  }

  public static var defaultPlanVersion: String { "1.0.0" }

  private static func makeStandardCommercialIntake() throws -> InspectionPlan {
    let points: [InspectionPoint] = [
      try InspectionPoint(
        id: "vin",
        title: "VIN",
        displayOrder: 1,
        guidanceInstruction: "Capture the VIN plate clearly."
      ),
      try InspectionPoint(
        id: "front_left",
        title: "Front Left Quarter",
        displayOrder: 2,
        guidanceInstruction: "Include wheel, bumper, and headlight."
      ),
      try InspectionPoint(
        id: "front_right",
        title: "Front Right Quarter",
        displayOrder: 3,
        guidanceInstruction: "Include wheel, bumper, and headlight."
      ),
      try InspectionPoint(
        id: "rear_left",
        title: "Rear Left Quarter",
        displayOrder: 4
      ),
      try InspectionPoint(
        id: "rear_right",
        title: "Rear Right Quarter",
        displayOrder: 5
      ),
      try InspectionPoint(
        id: "interior",
        title: "Interior Overview",
        displayOrder: 6,
        isRequired: false,
        expectedEvidenceType: .photo
      ),
    ]
    let plan = try InspectionPlan(
      id: "standard_commercial_intake",
      version: "1.0.0",
      title: "Standard Commercial Intake",
      descriptionText: "Baseline commercial vehicle intake checklist.",
      points: points
    )
    try InspectionPlanValidator.validate(plan)
    return plan
  }

  private static func makeQuick4Point() throws -> InspectionPlan {
    let points: [InspectionPoint] = [
      try InspectionPoint(id: "front", title: "Front", displayOrder: 1),
      try InspectionPoint(id: "driver_side", title: "Driver Side", displayOrder: 2),
      try InspectionPoint(id: "rear", title: "Rear", displayOrder: 3),
      try InspectionPoint(id: "passenger_side", title: "Passenger Side", displayOrder: 4),
    ]
    let plan = try InspectionPlan(
      id: "quick_4_point",
      version: "1.0.0",
      title: "Quick 4-Point",
      descriptionText: "Minimal four-corner exterior set.",
      points: points
    )
    try InspectionPlanValidator.validate(plan)
    return plan
  }
}
