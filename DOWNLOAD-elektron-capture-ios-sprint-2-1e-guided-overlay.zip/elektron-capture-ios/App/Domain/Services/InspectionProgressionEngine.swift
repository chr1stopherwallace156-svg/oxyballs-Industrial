import Foundation

/// Singular, **stateless** pure-domain engine for guided point progression (Sprint 2.1C).
///
/// - No `.shared` / global mutable state.
/// - All mutations return a new ``InspectionSession``.
/// - Ordering and identities come only from the session's frozen ``InspectionPlanSnapshot``.
/// - Never queries ``InspectionPlanRegistry``.
///
/// **Reactivation policy:** terminal statuses (`completed` / `skipped` / `blocked`) are
/// strictly terminal — there is no reopen API.
public struct InspectionProgressionEngine: Sendable {
  public init() {}

  // MARK: - Initialize

  /// Idempotent: builds or validates progress against the frozen snapshot.
  public func initializeProgress(for session: InspectionSession) throws -> InspectionSession {
    guard let snapshot = session.inspectionPlanSnapshot else {
      throw InspectionProgressionError.noAssignedPlan
    }
    var next = session
    if let existing = next.progress {
      try validate(progress: existing, against: snapshot)
      return next
    }
    next.progress = InspectionProgressState.uninitialized(from: snapshot)
    return next
  }

  // MARK: - Activate / navigate

  public func activate(
    pointID: InspectionPointID,
    in session: InspectionSession
  ) throws -> InspectionSession {
    let snapshot = try requireSnapshot(session)
    var state = try requireProgress(session)
    try validate(progress: state, against: snapshot)
    guard let index = state.index(of: pointID) else {
      throw InspectionProgressionError.unknownPointID(pointID.rawValue)
    }
    try activate(at: index, state: &state)
    return withProgress(session, state)
  }

  /// Moves the active identity to the next point in frozen order.
  /// Does **not** implicitly complete, skip, or block the current point.
  public func advanceToNextEligiblePoint(in session: InspectionSession) throws -> InspectionSession {
    let snapshot = try requireSnapshot(session)
    var state = try requireProgress(session)
    try validate(progress: state, against: snapshot)
    let start = try activeIndex(in: state) + 1
    guard start < state.orderedPoints.count else {
      throw InspectionProgressionError.noEligiblePoint
    }
    try activate(at: start, state: &state)
    return withProgress(session, state)
  }

  public func returnToPreviousEligiblePoint(in session: InspectionSession) throws -> InspectionSession {
    let snapshot = try requireSnapshot(session)
    var state = try requireProgress(session)
    try validate(progress: state, against: snapshot)
    let current = try activeIndex(in: state)
    let prev = current - 1
    guard prev >= 0 else {
      throw InspectionProgressionError.noEligiblePoint
    }
    try activate(at: prev, state: &state)
    return withProgress(session, state)
  }

  // MARK: - Terminal transitions

  public func completeActivePoint(in session: InspectionSession) throws -> InspectionSession {
    let snapshot = try requireSnapshot(session)
    var state = try requireProgress(session)
    try validate(progress: state, against: snapshot)
    let index = try activeIndex(in: state)
    try ensureNotTerminal(state.orderedPoints[index])
    switch state.orderedPoints[index].status {
    case .inProgress:
      state.orderedPoints[index].status = .completed
    case .notStarted:
      throw InspectionProgressionError.invalidTransition(
        "cannot complete from notStarted; activate the point first"
      )
    case .completed, .skipped, .blocked:
      throw InspectionProgressionError.pointIsTerminal(state.orderedPoints[index].pointID.rawValue)
    }
    return withProgress(session, state)
  }

  public func skipActivePoint(reason: String, in session: InspectionSession) throws -> InspectionSession {
    let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { throw InspectionProgressionError.emptySkipReason }
    let snapshot = try requireSnapshot(session)
    var state = try requireProgress(session)
    try validate(progress: state, against: snapshot)
    let index = try activeIndex(in: state)
    try ensureNotTerminal(state.orderedPoints[index])
    state.orderedPoints[index].status = .skipped(reason: trimmed)
    return withProgress(session, state)
  }

  public func blockActivePoint(reason: String, in session: InspectionSession) throws -> InspectionSession {
    let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { throw InspectionProgressionError.emptyBlockReason }
    let snapshot = try requireSnapshot(session)
    var state = try requireProgress(session)
    try validate(progress: state, against: snapshot)
    let index = try activeIndex(in: state)
    try ensureNotTerminal(state.orderedPoints[index])
    state.orderedPoints[index].status = .blocked(reason: trimmed)
    return withProgress(session, state)
  }

  // MARK: - Derived evaluation

  public func evaluateCompletion(of session: InspectionSession) -> InspectionCompletionDisposition {
    guard let snapshot = session.inspectionPlanSnapshot,
      let state = session.progress,
      (try? validate(progress: state, against: snapshot)) != nil
    else {
      return .incomplete
    }
    let requiredIDs = Set(snapshot.points.filter(\.isRequired).map(\.id))
    if requiredIDs.isEmpty {
      return .complete
    }
    var sawBlocked = false
    var sawOpen = false
    for row in state.orderedPoints where requiredIDs.contains(row.pointID) {
      switch row.status {
      case .blocked:
        sawBlocked = true
      case .completed, .skipped:
        break
      case .notStarted, .inProgress:
        sawOpen = true
      }
    }
    if sawBlocked { return .blocked }
    if sawOpen { return .incomplete }
    return .complete
  }

  // MARK: - Internals

  private func requireSnapshot(_ session: InspectionSession) throws -> InspectionPlanSnapshot {
    guard let snapshot = session.inspectionPlanSnapshot else {
      throw InspectionProgressionError.noAssignedPlan
    }
    return snapshot
  }

  private func requireProgress(_ session: InspectionSession) throws -> InspectionProgressState {
    guard let progress = session.progress else {
      throw InspectionProgressionError.progressNotInitialized
    }
    return progress
  }

  private func withProgress(_ session: InspectionSession, _ state: InspectionProgressState)
    -> InspectionSession
  {
    var next = session
    next.progress = state
    return next
  }

  private func activeIndex(in state: InspectionProgressState) throws -> Int {
    guard let id = state.activePointID, let index = state.index(of: id) else {
      throw InspectionProgressionError.noActivePoint
    }
    return index
  }

  private func ensureNotTerminal(_ point: InspectionPointProgress) throws {
    if point.status.isTerminal {
      throw InspectionProgressionError.pointIsTerminal(point.pointID.rawValue)
    }
  }

  /// Activate by frozen order index. Demotes prior `inProgress` → `notStarted` when leaving.
  /// Refuses activation of terminal points (strictly terminal policy).
  private func activate(at index: Int, state: inout InspectionProgressState) throws {
    guard state.orderedPoints.indices.contains(index) else {
      throw InspectionProgressionError.noEligiblePoint
    }
    let target = state.orderedPoints[index]
    if target.status.isTerminal {
      throw InspectionProgressionError.pointIsTerminal(target.pointID.rawValue)
    }
    if let activeID = state.activePointID,
      let prior = state.index(of: activeID),
      prior != index
    {
      if case .inProgress = state.orderedPoints[prior].status {
        state.orderedPoints[prior].status = .notStarted
      }
    }
    state.orderedPoints[index].status = .inProgress
    state.activePointID = state.orderedPoints[index].pointID
  }

  private func validate(
    progress: InspectionProgressState,
    against snapshot: InspectionPlanSnapshot
  ) throws {
    let expected = snapshot.points.map(\.id)
    let actual = progress.orderedPoints.map(\.pointID)
    if actual.count != Set(actual).count {
      if let dup = actual.first(where: { id in actual.filter { $0 == id }.count > 1 }) {
        throw InspectionProgressionError.duplicatePointID(dup.rawValue)
      }
    }
    guard actual == expected else {
      throw InspectionProgressionError.progressSnapshotMismatch(
        "progress point set/order does not match frozen snapshot"
      )
    }
    if let active = progress.activePointID, !expected.contains(active) {
      throw InspectionProgressionError.unknownPointID(active.rawValue)
    }
  }
}
