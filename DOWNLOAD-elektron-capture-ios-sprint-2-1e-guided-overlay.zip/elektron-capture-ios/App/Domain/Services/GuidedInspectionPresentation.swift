import Foundation

// MARK: - Intents (presentation → coordinator)

/// Discrete guided-inspection intents. Views emit these; they never build domain bindings.
public enum GuidedInspectionIntent: Equatable, Sendable {
  /// Initialize progress (idempotent) and activate the first eligible non-terminal point.
  case prepareGuidedSession
  case activatePoint(InspectionPointID)
  case advanceRequested
  case returnRequested
  case completePointRequested
  case skipRequested(reason: String)
  case blockRequested(reason: String)
  /// UI signal that the operator wants a capture. Coordinator validates readiness only;
  /// camera shutter remains outside this domain path.
  case captureRequested
  /// Bind an already-approved capture's opaque storage key to the active point.
  case bindApprovedCapture(
    storageKey: String,
    type: EvidenceType,
    attributes: [String: String]
  )
}

// MARK: - Presentation errors

/// Structured errors for UI mapping — not flattened free-text from domain internals.
public enum GuidedInspectionPresentationError: Error, Equatable, Sendable {
  case noActiveSession
  case planNotAssigned
  case progressUnavailable
  case noActivePoint
  case captureNotReady(String)
  case emptySkipReason
  case emptyBlockReason
  case progression(InspectionProgressionError)
  case evidenceBinding(EvidenceBindingError)
  case persistence(String)
}

// MARK: - Handle result

public struct GuidedInspectionHandleResult: Equatable, Sendable {
  public var session: InspectionSession
  /// When true, the presentation layer should invoke the existing camera shutter API.
  public var shouldTriggerShutter: Bool
  public var presentation: GuidedInspectionPresentationState

  public init(
    session: InspectionSession,
    shouldTriggerShutter: Bool = false,
    presentation: GuidedInspectionPresentationState
  ) {
    self.session = session
    self.shouldTriggerShutter = shouldTriggerShutter
    self.presentation = presentation
  }
}

// MARK: - Presentation state (derived)

public struct GuidedInspectionPointSummary: Equatable, Sendable, Identifiable {
  public var id: InspectionPointID { pointID }
  public let pointID: InspectionPointID
  public let title: String
  public let isRequired: Bool
  public let status: InspectionPointStatus?
  public let evidenceCount: Int
  public let requiredCount: Int
  public let isSatisfied: Bool
  public let isActive: Bool
}

/// Pure derived UI model from session + frozen snapshot. Never persists.
public struct GuidedInspectionPresentationState: Equatable, Sendable {
  public var isGuidedAvailable: Bool
  public var activePointID: InspectionPointID?
  public var activePointTitle: String?
  public var guidanceText: String?
  public var activeStatus: InspectionPointStatus?
  public var evidenceCount: Int
  public var requiredCount: Int
  public var isPointSatisfied: Bool
  public var canAdvance: Bool
  public var canReturn: Bool
  public var canComplete: Bool
  public var canSkip: Bool
  public var canBlock: Bool
  public var canCapture: Bool
  public var canPrepare: Bool
  public var completionDisposition: InspectionCompletionDisposition
  public var points: [GuidedInspectionPointSummary]

  public static let unavailable = GuidedInspectionPresentationState(
    isGuidedAvailable: false,
    activePointID: nil,
    activePointTitle: nil,
    guidanceText: nil,
    activeStatus: nil,
    evidenceCount: 0,
    requiredCount: 0,
    isPointSatisfied: false,
    canAdvance: false,
    canReturn: false,
    canComplete: false,
    canSkip: false,
    canBlock: false,
    canCapture: false,
    canPrepare: false,
    completionDisposition: .incomplete,
    points: []
  )
}
