import Foundation

/// Stateless pure-domain service for evidence→point binding metadata (Sprint 2.1D).
///
/// - No `.shared` / global mutable state.
/// - Mutations return a new ``InspectionSession``.
/// - Point identities come only from the session's frozen ``InspectionPlanSnapshot``.
/// - Satisfaction is **derived** — never persisted on progress or metadata.
public struct EvidenceBindingService: Sendable {
  public init() {}

  // MARK: - Bind / unbind

  public func bind(
    evidence: EvidenceMetadata,
    to session: InspectionSession
  ) throws -> InspectionSession {
    let snapshot = try requireSnapshot(session)
    try validateStorageKey(evidence.storageKey)
    guard evidence.sessionID == session.id else {
      throw EvidenceBindingError.sessionIDMismatch(
        expected: session.id.rawValue,
        actual: evidence.sessionID.rawValue
      )
    }
    guard snapshot.points.contains(where: { $0.id == evidence.pointID }) else {
      throw EvidenceBindingError.unknownPointID(evidence.pointID.rawValue)
    }
    var collection = session.evidenceBindings ?? EvidenceBindingCollection()
    if collection.contains(evidenceID: evidence.id) {
      throw EvidenceBindingError.duplicateEvidenceID(evidence.id.rawValue.uuidString)
    }
    collection.bindings.append(evidence)
    return withBindings(session, collection)
  }

  public func unbind(
    evidenceID: EvidenceID,
    from session: InspectionSession
  ) throws -> InspectionSession {
    guard var collection = session.evidenceBindings else {
      throw EvidenceBindingError.unknownEvidenceID(evidenceID.rawValue.uuidString)
    }
    guard let index = collection.bindings.firstIndex(where: { $0.id == evidenceID }) else {
      throw EvidenceBindingError.unknownEvidenceID(evidenceID.rawValue.uuidString)
    }
    collection.bindings.remove(at: index)
    return withBindings(session, collection.isEmpty ? nil : collection)
  }

  // MARK: - Queries

  public func evidence(
    for pointID: InspectionPointID,
    in session: InspectionSession
  ) -> [EvidenceMetadata] {
    session.evidenceBindings?.evidence(for: pointID) ?? []
  }

  public func evidenceCount(
    for pointID: InspectionPointID,
    in session: InspectionSession
  ) -> Int {
    session.evidenceBindings?.evidenceCount(for: pointID) ?? 0
  }

  /// Derived satisfaction: binding count ≥ required count from frozen snapshot point.
  public func isPointSatisfied(
    pointID: InspectionPointID,
    in session: InspectionSession
  ) -> Bool {
    guard let snapshot = session.inspectionPlanSnapshot,
      let point = snapshot.points.first(where: { $0.id == pointID })
    else {
      return false
    }
    let required = InspectionEvidenceRequirement.requiredBindingCount(for: point)
    return evidenceCount(for: pointID, in: session) >= required
  }

  public func requiredBindingCount(
    for pointID: InspectionPointID,
    in session: InspectionSession
  ) throws -> Int {
    let snapshot = try requireSnapshot(session)
    guard let point = snapshot.points.first(where: { $0.id == pointID }) else {
      throw EvidenceBindingError.unknownPointID(pointID.rawValue)
    }
    return InspectionEvidenceRequirement.requiredBindingCount(for: point)
  }

  // MARK: - Internals

  private func requireSnapshot(_ session: InspectionSession) throws -> InspectionPlanSnapshot {
    guard let snapshot = session.inspectionPlanSnapshot else {
      throw EvidenceBindingError.noAssignedPlan
    }
    return snapshot
  }

  private func validateStorageKey(_ key: String) throws {
    let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { throw EvidenceBindingError.emptyStorageKey }
  }

  private func withBindings(
    _ session: InspectionSession,
    _ collection: EvidenceBindingCollection?
  ) -> InspectionSession {
    var next = session
    next.evidenceBindings = collection
    return next
  }
}
