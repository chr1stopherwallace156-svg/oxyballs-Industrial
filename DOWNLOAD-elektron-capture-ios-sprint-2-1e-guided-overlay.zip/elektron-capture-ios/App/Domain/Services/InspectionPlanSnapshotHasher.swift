import Foundation

/// S2-002: SHA-256 over CanonicalJSON of `InspectionPlanSnapshotPayload`.
public enum InspectionPlanSnapshotHasher {
  public static let algorithmID = InspectionPlanSnapshot.hashAlgorithmID

  public static func sha256Hex(of payload: InspectionPlanSnapshotPayload) throws -> String {
    let data = try CanonicalJSONEncoder.encode(
      payload.asDictionary(),
      stage: "inspection_plan_snapshot_payload"
    )
    return ContentHasher.sha256Hex(data)
  }

  /// Recomputes digest and rejects mismatches / unknown algorithms.
  public static func verify(_ snapshot: InspectionPlanSnapshot) throws {
    guard snapshot.snapshotHashAlgorithm == algorithmID else {
      throw InspectionPlanError.unsupportedHashAlgorithm(snapshot.snapshotHashAlgorithm)
    }
    let computed = try sha256Hex(of: snapshot.payload)
    guard computed == snapshot.snapshotSHA256 else {
      throw InspectionPlanError.hashMismatch(
        expected: snapshot.snapshotSHA256,
        actual: computed
      )
    }
  }
}
