import Foundation

/// Validates an inspection plan before hashing. Does not repair invalid plans.
public enum InspectionPlanValidator {
  /// Semantic version: MAJOR.MINOR.PATCH with non-negative integers (no pre-release/build).
  private static let semverPattern = #"^[0-9]+\.[0-9]+\.[0-9]+$"#

  public static func validate(_ plan: InspectionPlan) throws {
    let title = plan.title.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !title.isEmpty else {
      throw InspectionPlanError.emptyTitle
    }
    guard plan.version.range(of: semverPattern, options: .regularExpression) != nil else {
      throw InspectionPlanError.invalidSemanticVersion(plan.version)
    }

    var seenIDs = Set<String>()
    var seenOrders = Set<Int>()
    for point in plan.points {
      let pointTitle = point.title.trimmingCharacters(in: .whitespacesAndNewlines)
      guard !pointTitle.isEmpty else {
        throw InspectionPlanError.validationFailed("empty point title for \(point.id.rawValue)")
      }
      if seenIDs.contains(point.id.rawValue) {
        throw InspectionPlanError.duplicatePointID(point.id.rawValue)
      }
      seenIDs.insert(point.id.rawValue)
      if seenOrders.contains(point.displayOrder) {
        throw InspectionPlanError.duplicateDisplayOrder(point.displayOrder)
      }
      seenOrders.insert(point.displayOrder)
    }

    // Deterministic ordering must already be present: strictly increasing displayOrder
    // in the stored array (validators do not sort-to-repair).
    if plan.points.count > 1 {
      for i in 1..<plan.points.count {
        if plan.points[i - 1].displayOrder >= plan.points[i].displayOrder {
          throw InspectionPlanError.nonDeterministicPointOrdering
        }
      }
    }
  }
}
