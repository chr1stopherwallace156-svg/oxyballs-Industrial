import Foundation

/// Builds immutable snapshots from validated plans (Sprint 2.0).
public struct InspectionPlanSnapshotFactory: Sendable {
  public var instantProvider: any InstantProviding

  public init(instantProvider: any InstantProviding = SystemInstantProvider()) {
    self.instantProvider = instantProvider
  }

  public func makeSnapshot(from plan: InspectionPlan) throws -> InspectionPlanSnapshot {
    try InspectionPlanValidator.validate(plan)
    let payload = InspectionPlanSnapshotPayload(
      planID: plan.id,
      planVersion: plan.version,
      title: plan.title,
      descriptionText: plan.descriptionText,
      points: plan.points
    )
    let digest = try InspectionPlanSnapshotHasher.sha256Hex(of: payload)
    let snapshot = InspectionPlanSnapshot(
      payload: payload,
      snapshotCreatedAt: instantProvider.now(),
      snapshotSHA256: digest,
      snapshotHashAlgorithm: InspectionPlanSnapshotHasher.algorithmID
    )
    try InspectionPlanSnapshotHasher.verify(snapshot)
    return snapshot
  }
}
