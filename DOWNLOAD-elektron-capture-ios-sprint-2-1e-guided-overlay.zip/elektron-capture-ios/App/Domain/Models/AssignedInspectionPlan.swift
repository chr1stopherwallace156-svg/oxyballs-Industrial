import Foundation

/// Assignment context wrapping a frozen plan definition (Sprint 2.1A).
///
/// Keeps ``InspectionPlanSnapshot`` focused on definition-only identity (S2-002).
/// Future operator/audit tags belong here — not on the snapshot payload.
public struct AssignedInspectionPlan: Codable, Equatable, Sendable {
  public let snapshot: InspectionPlanSnapshot
  public let assignedAt: Date

  public init(snapshot: InspectionPlanSnapshot, assignedAt: Date) {
    self.snapshot = snapshot
    self.assignedAt = assignedAt
  }

  public var planID: InspectionPlanID { snapshot.planID }
  public var planVersion: String { snapshot.planVersion }
  /// S2-002 definition digest (`snapshotSHA256`) of the frozen snapshot.
  public var definitionDigest: String { snapshot.snapshotSHA256 }
}
