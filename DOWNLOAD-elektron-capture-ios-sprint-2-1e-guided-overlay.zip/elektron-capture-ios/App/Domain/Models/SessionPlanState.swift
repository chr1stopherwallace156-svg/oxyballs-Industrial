import Foundation

/// Domain state distinguishing assigned sessions from legacy pre-2.1 sessions.
///
/// Decoding never consults ``InspectionPlanRegistry``.
public enum SessionPlanState: Codable, Equatable, Sendable {
  /// Session created with a verified snapshot + assignment metadata.
  case assigned(AssignedInspectionPlan)
  /// Pre-2.1 persisted sessions (or starts that did not supply a plan).
  case legacyUnassigned

  public var assignedPlan: AssignedInspectionPlan? {
    if case .assigned(let assignment) = self { return assignment }
    return nil
  }

  public var snapshot: InspectionPlanSnapshot? { assignedPlan?.snapshot }

  public var isAssigned: Bool {
    if case .assigned = self { return true }
    return false
  }

  private enum CodingKeys: String, CodingKey {
    case type
    case assignment
    /// Intermediate 2.1A tip encoded snapshot without `AssignedInspectionPlan`.
    case snapshot
    case assignedAt
  }

  private enum Kind: String, Codable {
    case assigned
    case legacyUnassigned
  }

  public init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    let kind = try c.decode(Kind.self, forKey: .type)
    switch kind {
    case .assigned:
      let assignment: AssignedInspectionPlan
      if let wrapped = try c.decodeIfPresent(AssignedInspectionPlan.self, forKey: .assignment) {
        assignment = wrapped
      } else {
        // Backward-compatible wire: `{ type, snapshot, assignedAt? }`
        let snapshot = try c.decode(InspectionPlanSnapshot.self, forKey: .snapshot)
        let assignedAt = try c.decodeIfPresent(Date.self, forKey: .assignedAt)
          ?? snapshot.snapshotCreatedAt
        assignment = AssignedInspectionPlan(snapshot: snapshot, assignedAt: assignedAt)
      }
      do {
        try InspectionPlanSnapshotHasher.verify(assignment.snapshot)
      } catch {
        throw DecodingError.dataCorrupted(
          DecodingError.Context(
            codingPath: c.codingPath + [CodingKeys.assignment],
            debugDescription: "assigned snapshot failed definition-digest verification: \(error)"
          )
        )
      }
      self = .assigned(assignment)
    case .legacyUnassigned:
      self = .legacyUnassigned
    }
  }

  public func encode(to encoder: Encoder) throws {
    var c = encoder.container(keyedBy: CodingKeys.self)
    switch self {
    case .assigned(let assignment):
      try c.encode(Kind.assigned, forKey: .type)
      try c.encode(assignment, forKey: .assignment)
    case .legacyUnassigned:
      try c.encode(Kind.legacyUnassigned, forKey: .type)
    }
  }
}
