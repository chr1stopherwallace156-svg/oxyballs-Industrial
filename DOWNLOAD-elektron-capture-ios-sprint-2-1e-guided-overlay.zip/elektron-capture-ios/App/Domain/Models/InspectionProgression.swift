import Foundation

// MARK: - Errors

public enum InspectionProgressionError: Error, Equatable, Sendable {
  case noAssignedPlan
  case progressNotInitialized
  case unknownPointID(String)
  case duplicatePointID(String)
  case progressSnapshotMismatch(String)
  case noActivePoint
  case noEligiblePoint
  case emptySkipReason
  case emptyBlockReason
  case invalidTransition(String)
  case pointIsTerminal(String)
}

// MARK: - Completion disposition (derived — never persisted)

/// Result of evaluating required-point completion against authoritative statuses.
public enum InspectionCompletionDisposition: Equatable, Sendable {
  /// At least one required point is still `notStarted` or `inProgress`.
  case incomplete
  /// Every required point is `completed` or validly `skipped`.
  case complete
  /// At least one required point is `blocked` (prevents normal successful completion).
  case blocked
}

// MARK: - Point status

/// Explicit point-state machine values (Sprint 2.1C).
///
/// **Reactivation policy (strictly terminal):** `completed`, `skipped`, and `blocked`
/// cannot be reopened. There is no `reactivatePoint` API.
public enum InspectionPointStatus: Codable, Equatable, Sendable {
  case notStarted
  case inProgress
  case completed
  case skipped(reason: String)
  case blocked(reason: String)

  public var isTerminal: Bool {
    switch self {
    case .completed, .skipped, .blocked: return true
    case .notStarted, .inProgress: return false
    }
  }

  private enum CodingKeys: String, CodingKey {
    case type
    case reason
  }

  private enum Kind: String, Codable {
    case notStarted
    case inProgress
    case completed
    case skipped
    case blocked
  }

  public init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    switch try c.decode(Kind.self, forKey: .type) {
    case .notStarted: self = .notStarted
    case .inProgress: self = .inProgress
    case .completed: self = .completed
    case .skipped:
      self = .skipped(reason: try c.decode(String.self, forKey: .reason))
    case .blocked:
      let reason = try c.decodeIfPresent(String.self, forKey: .reason) ?? "blocked"
      self = .blocked(reason: reason)
    }
  }

  public func encode(to encoder: Encoder) throws {
    var c = encoder.container(keyedBy: CodingKeys.self)
    switch self {
    case .notStarted:
      try c.encode(Kind.notStarted, forKey: .type)
    case .inProgress:
      try c.encode(Kind.inProgress, forKey: .type)
    case .completed:
      try c.encode(Kind.completed, forKey: .type)
    case .skipped(let reason):
      try c.encode(Kind.skipped, forKey: .type)
      try c.encode(reason, forKey: .reason)
    case .blocked(let reason):
      try c.encode(Kind.blocked, forKey: .type)
      try c.encode(reason, forKey: .reason)
    }
  }
}

// MARK: - Point progress (authoritative facts only)

/// Persisted per-point workflow fact: identity + status.
/// Capture counts / satisfaction are derived later (2.1D) or via ``InspectionProgressionEngine``.
public struct InspectionPointProgress: Codable, Equatable, Sendable {
  public let pointID: InspectionPointID
  public var status: InspectionPointStatus

  public init(pointID: InspectionPointID, status: InspectionPointStatus = .notStarted) {
    self.pointID = pointID
    self.status = status
  }
}

// MARK: - Session progress state (authoritative facts only)

/// Persisted guided progression: ordered point statuses + active point identity.
///
/// Does **not** persist `isComplete`, `isSatisfied`, array indexes, or evidence counts.
public struct InspectionProgressState: Codable, Equatable, Sendable {
  public var orderedPoints: [InspectionPointProgress]
  public var activePointID: InspectionPointID?

  public init(orderedPoints: [InspectionPointProgress], activePointID: InspectionPointID?) {
    self.orderedPoints = orderedPoints
    self.activePointID = activePointID
  }

  /// Initial authoritative state from a frozen snapshot (all `notStarted`, no active point).
  public static func uninitialized(from snapshot: InspectionPlanSnapshot) -> InspectionProgressState {
    let rows = snapshot.points.map {
      InspectionPointProgress(pointID: $0.id, status: .notStarted)
    }
    return InspectionProgressState(orderedPoints: rows, activePointID: nil)
  }

  public func progress(for pointID: InspectionPointID) -> InspectionPointProgress? {
    orderedPoints.first { $0.pointID == pointID }
  }

  public func index(of pointID: InspectionPointID) -> Int? {
    orderedPoints.firstIndex { $0.pointID == pointID }
  }

  // MARK: Codable — Option A additive v1 (+ tolerate earlier 2.1C tip shapes)

  enum CodingKeys: String, CodingKey {
    case orderedPoints
    case activePointID
    case pointsProgress
    case pointProgress
    case currentPointIndex
    case activePointIndex
  }

  public init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    if let rows = try c.decodeIfPresent([InspectionPointProgress].self, forKey: .orderedPoints) {
      orderedPoints = rows
    } else if let rows = try c.decodeIfPresent([InspectionPointProgress].self, forKey: .pointsProgress)
    {
      orderedPoints = rows.map { InspectionPointProgress(pointID: $0.pointID, status: $0.status) }
    } else if let rows = try c.decodeIfPresent([InspectionPointProgress].self, forKey: .pointProgress)
    {
      orderedPoints = rows.map { InspectionPointProgress(pointID: $0.pointID, status: $0.status) }
    } else {
      orderedPoints = []
    }

    if let id = try c.decodeIfPresent(InspectionPointID.self, forKey: .activePointID) {
      activePointID = id
    } else if let idx = try c.decodeIfPresent(Int.self, forKey: .currentPointIndex)
      ?? c.decodeIfPresent(Int.self, forKey: .activePointIndex),
      orderedPoints.indices.contains(idx)
    {
      activePointID = orderedPoints[idx].pointID
    } else {
      activePointID = nil
    }
  }

  public func encode(to encoder: Encoder) throws {
    var c = encoder.container(keyedBy: CodingKeys.self)
    try c.encode(orderedPoints, forKey: .orderedPoints)
    try c.encodeIfPresent(activePointID, forKey: .activePointID)
  }
}

/// Compatibility alias.
public typealias InspectionProgress = InspectionProgressState
