import Foundation

/// Explicit support / availability state for a queried device capability.
public enum CapabilityState: String, Codable, Sendable, Equatable {
  case supported = "SUPPORTED"
  case unsupported = "UNSUPPORTED"
  case unknown = "UNKNOWN"
  case unavailable = "UNAVAILABLE"
  case permissionDenied = "PERMISSION_DENIED"
}

/// One discovered camera node as observed at snapshot time.
public struct CameraCapability: Codable, Sendable, Equatable {
  public let cameraID: String
  public let position: String
  public let deviceType: String
  public let supportsFocusLock: Bool
  public let supportsExposureLock: Bool
  public let supportsDepthData: Bool

  public init(
    cameraID: String,
    position: String,
    deviceType: String,
    supportsFocusLock: Bool,
    supportsExposureLock: Bool,
    supportsDepthData: Bool
  ) {
    self.cameraID = cameraID
    self.position = position
    self.deviceType = deviceType
    self.supportsFocusLock = supportsFocusLock
    self.supportsExposureLock = supportsExposureLock
    self.supportsDepthData = supportsDepthData
  }

  public func asDictionary() -> [String: Any] {
    [
      "camera_id": cameraID,
      "position": position,
      "device_type": deviceType,
      "supports_focus_lock": supportsFocusLock,
      "supports_exposure_lock": supportsExposureLock,
      "supports_depth_data": supportsDepthData,
    ]
  }
}

/// Immutable device capability observation retained for one capture session.
public struct DeviceCapabilitySnapshot: Codable, Sendable, Equatable {
  public let snapshotID: String
  public let capturedAtUTC: String
  public let deviceModel: String
  public let operatingSystemVersion: String
  public let availableCameras: [CameraCapability]
  public let motion: CapabilityState
  public let depth: CapabilityState
  public let lidar: CapabilityState

  public init(
    snapshotID: String,
    capturedAtUTC: String,
    deviceModel: String,
    operatingSystemVersion: String,
    availableCameras: [CameraCapability],
    motion: CapabilityState,
    depth: CapabilityState,
    lidar: CapabilityState
  ) {
    self.snapshotID = snapshotID
    self.capturedAtUTC = capturedAtUTC
    self.deviceModel = deviceModel
    self.operatingSystemVersion = operatingSystemVersion
    self.availableCameras = availableCameras
    self.motion = motion
    self.depth = depth
    self.lidar = lidar
  }

  /// Package / canonical-JSON dictionary (snake_case keys).
  public func asDictionary() -> [String: Any] {
    [
      "schema_id": "DeviceCapabilitySnapshot",
      "schema_version": "1.0.0",
      "snapshot_id": snapshotID,
      "captured_at_utc": capturedAtUTC,
      "device_model": deviceModel,
      "operating_system_version": operatingSystemVersion,
      "available_cameras": availableCameras.map { $0.asDictionary() },
      "motion": motion.rawValue,
      "depth": depth.rawValue,
      "lidar": lidar.rawValue,
    ]
  }
}
