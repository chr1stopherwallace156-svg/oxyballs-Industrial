import Foundation

// MARK: - Errors

public enum InspectionPlanError: Error, Equatable, Sendable {
  case emptyPlanID
  case emptyPointID
  case emptyTitle
  case invalidSemanticVersion(String)
  case duplicatePointID(String)
  case duplicateDisplayOrder(Int)
  case nonDeterministicPointOrdering
  case planNotFound(String)
  case unsupportedHashAlgorithm(String)
  case hashMismatch(expected: String, actual: String)
  case validationFailed(String)
}

// MARK: - Typed IDs

public struct InspectionPlanID: Hashable, Codable, Sendable, CustomStringConvertible {
  public let rawValue: String

  public init(rawValue: String) throws {
    let trimmed = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { throw InspectionPlanError.emptyPlanID }
    self.rawValue = trimmed
  }

  public static func unchecked(_ rawValue: String) -> InspectionPlanID {
    (try? InspectionPlanID(rawValue: rawValue)) ?? InspectionPlanID(unsafe: rawValue)
  }

  private init(unsafe rawValue: String) { self.rawValue = rawValue }

  public var description: String { rawValue }

  public init(from decoder: Decoder) throws {
    let c = try decoder.singleValueContainer()
    try self.init(rawValue: try c.decode(String.self))
  }

  public func encode(to encoder: Encoder) throws {
    var c = encoder.singleValueContainer()
    try c.encode(rawValue)
  }
}

public struct InspectionPointID: Hashable, Codable, Sendable, CustomStringConvertible {
  public let rawValue: String

  public init(rawValue: String) throws {
    let trimmed = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { throw InspectionPlanError.emptyPointID }
    self.rawValue = trimmed
  }

  public static func unchecked(_ rawValue: String) -> InspectionPointID {
    (try? InspectionPointID(rawValue: rawValue)) ?? InspectionPointID(unsafe: rawValue)
  }

  private init(unsafe rawValue: String) { self.rawValue = rawValue }

  public var description: String { rawValue }

  public init(from decoder: Decoder) throws {
    let c = try decoder.singleValueContainer()
    try self.init(rawValue: try c.decode(String.self))
  }

  public func encode(to encoder: Encoder) throws {
    var c = encoder.singleValueContainer()
    try c.encode(rawValue)
  }
}

// MARK: - Expected evidence

public enum ExpectedEvidenceType: String, Codable, Sendable, Equatable {
  case photo
  case multiPhoto
  case video
  case lidarScan
  case thermalImage
  case document
}

// MARK: - Point / Plan definitions (immutable templates)

public struct InspectionPoint: Identifiable, Codable, Equatable, Sendable {
  public var id: InspectionPointID
  public let title: String
  public let displayOrder: Int
  public let isRequired: Bool
  public let guidanceInstruction: String?
  public let expectedEvidenceType: ExpectedEvidenceType

  public init(
    id: InspectionPointID,
    title: String,
    displayOrder: Int,
    isRequired: Bool = true,
    guidanceInstruction: String? = nil,
    expectedEvidenceType: ExpectedEvidenceType = .photo
  ) {
    self.id = id
    self.title = title
    self.displayOrder = displayOrder
    self.isRequired = isRequired
    self.guidanceInstruction = guidanceInstruction
    self.expectedEvidenceType = expectedEvidenceType
  }

  public init(
    id: String,
    title: String,
    displayOrder: Int,
    isRequired: Bool = true,
    guidanceInstruction: String? = nil,
    expectedEvidenceType: ExpectedEvidenceType = .photo
  ) throws {
    try self.init(
      id: InspectionPointID(rawValue: id),
      title: title,
      displayOrder: displayOrder,
      isRequired: isRequired,
      guidanceInstruction: guidanceInstruction,
      expectedEvidenceType: expectedEvidenceType
    )
  }
}

public struct InspectionPlan: Identifiable, Codable, Equatable, Sendable {
  public var id: InspectionPlanID
  public let version: String
  public let title: String
  public let descriptionText: String?
  public let points: [InspectionPoint]

  public var requiredPoints: [InspectionPoint] {
    points.filter(\.isRequired).sorted {
      if $0.displayOrder != $1.displayOrder { return $0.displayOrder < $1.displayOrder }
      return $0.id.rawValue < $1.id.rawValue
    }
  }

  /// Registry / picker key (`planID@version`).
  public var registryKey: String { "\(id.rawValue)@\(version)" }

  public init(
    id: InspectionPlanID,
    version: String,
    title: String,
    descriptionText: String? = nil,
    points: [InspectionPoint]
  ) {
    self.id = id
    self.version = version
    self.title = title
    self.descriptionText = descriptionText
    self.points = points
  }

  public init(
    id: String,
    version: String,
    title: String,
    descriptionText: String? = nil,
    points: [InspectionPoint]
  ) throws {
    try self.init(
      id: InspectionPlanID(rawValue: id),
      version: version,
      title: title,
      descriptionText: descriptionText,
      points: points
    )
  }
}

// MARK: - Snapshot payload + snapshot (S2-002)

/// Hashed definition payload. Excludes digests and `snapshotCreatedAt`.
public struct InspectionPlanSnapshotPayload: Codable, Equatable, Sendable {
  public static let schemaVersion = "1.0.0"

  public let snapshotSchemaVersion: String
  public let planID: InspectionPlanID
  public let planVersion: String
  public let title: String
  public let descriptionText: String?
  public let points: [InspectionPoint]

  public init(
    snapshotSchemaVersion: String = InspectionPlanSnapshotPayload.schemaVersion,
    planID: InspectionPlanID,
    planVersion: String,
    title: String,
    descriptionText: String? = nil,
    points: [InspectionPoint]
  ) {
    self.snapshotSchemaVersion = snapshotSchemaVersion
    self.planID = planID
    self.planVersion = planVersion
    self.title = title
    self.descriptionText = descriptionText
    self.points = points
  }

  public func asDictionary() -> [String: Any] {
    [
      "snapshot_schema_version": snapshotSchemaVersion,
      "plan_id": planID.rawValue,
      "plan_version": planVersion,
      "title": title,
      "description_text": descriptionText.map { $0 as Any } ?? NSNull(),
      "points": points.map { point in
        [
          "id": point.id.rawValue,
          "title": point.title,
          "display_order": point.displayOrder,
          "is_required": point.isRequired,
          "guidance_instruction": point.guidanceInstruction.map { $0 as Any } ?? NSNull(),
          "expected_evidence_type": point.expectedEvidenceType.rawValue,
        ] as [String: Any]
      },
    ]
  }
}

public struct InspectionPlanSnapshot: Codable, Equatable, Sendable {
  public static let hashAlgorithmID = "sha256-canonical-json-v1"

  public let payload: InspectionPlanSnapshotPayload
  public let snapshotCreatedAt: Date
  public let snapshotSHA256: String
  public let snapshotHashAlgorithm: String

  public init(
    payload: InspectionPlanSnapshotPayload,
    snapshotCreatedAt: Date,
    snapshotSHA256: String,
    snapshotHashAlgorithm: String = InspectionPlanSnapshot.hashAlgorithmID
  ) {
    self.payload = payload
    self.snapshotCreatedAt = snapshotCreatedAt
    self.snapshotSHA256 = snapshotSHA256
    self.snapshotHashAlgorithm = snapshotHashAlgorithm
  }

  public var planID: InspectionPlanID { payload.planID }
  public var planVersion: String { payload.planVersion }
  public var title: String { payload.title }
  public var points: [InspectionPoint] { payload.points }
}
