import Foundation

// MARK: - Errors

public enum EvidenceBindingError: Error, Equatable, Sendable {
  case noAssignedPlan
  case unknownPointID(String)
  case duplicateEvidenceID(String)
  case unknownEvidenceID(String)
  case sessionIDMismatch(expected: String, actual: String)
  case emptyStorageKey
}

// MARK: - Evidence identity

/// Stable identity for a bound evidence metadata record (Sprint 2.1D).
public struct EvidenceID: Hashable, Codable, Sendable, Equatable, CustomStringConvertible {
  public let rawValue: UUID

  public init(_ rawValue: UUID = UUID()) {
    self.rawValue = rawValue
  }

  public var description: String { rawValue.uuidString }

  public init(from decoder: Decoder) throws {
    let c = try decoder.singleValueContainer()
    rawValue = try c.decode(UUID.self)
  }

  public func encode(to encoder: Encoder) throws {
    var c = encoder.singleValueContainer()
    try c.encode(rawValue)
  }
}

// MARK: - Evidence type (captured artifact kind)

/// Kind of evidence referenced by binding metadata.
/// Distinct from plan-template ``ExpectedEvidenceType``.
public enum EvidenceType: String, Codable, Equatable, Sendable {
  case photo
  case video
  case textNote
  case spatialScan
  case thermalImage
  case document
}

// MARK: - Evidence metadata (authoritative facts only)

/// Pure-domain reference binding an opaque storage key to a point within a session.
///
/// Does **not** carry binary payloads, file handles, or derived `isSatisfied`.
public struct EvidenceMetadata: Codable, Equatable, Sendable {
  public let id: EvidenceID
  public let pointID: InspectionPointID
  public let sessionID: SessionID
  public let type: EvidenceType
  public let createdAt: Date
  /// Opaque non-binary reference (path fragment / UUID key) for later file-store binding.
  public let storageKey: String
  public let payloadAttributes: [String: String]

  public init(
    id: EvidenceID = EvidenceID(),
    pointID: InspectionPointID,
    sessionID: SessionID,
    type: EvidenceType,
    createdAt: Date,
    storageKey: String,
    payloadAttributes: [String: String] = [:]
  ) {
    self.id = id
    self.pointID = pointID
    self.sessionID = sessionID
    self.type = type
    self.createdAt = createdAt
    self.storageKey = storageKey
    self.payloadAttributes = payloadAttributes
  }
}

// MARK: - Binding collection

/// Session-owned collection of evidence→point bindings.
public struct EvidenceBindingCollection: Codable, Equatable, Sendable {
  public var bindings: [EvidenceMetadata]

  public init(bindings: [EvidenceMetadata] = []) {
    self.bindings = bindings
  }

  public var isEmpty: Bool { bindings.isEmpty }

  public func evidence(for pointID: InspectionPointID) -> [EvidenceMetadata] {
    bindings.filter { $0.pointID == pointID }
  }

  public func evidenceCount(for pointID: InspectionPointID) -> Int {
    evidence(for: pointID).count
  }

  public func contains(evidenceID: EvidenceID) -> Bool {
    bindings.contains { $0.id == evidenceID }
  }
}

// MARK: - Required binding count (derived from frozen plan facts)

/// Derives the minimum binding count for a point from frozen snapshot facts.
///
/// Plan points expose ``ExpectedEvidenceType`` (not a numeric `requiredCaptures` field).
/// Mapping (documented Sprint 2.1D policy):
/// - `.multiPhoto` → 2
/// - all other expected types → 1
public enum InspectionEvidenceRequirement: Sendable {
  public static func requiredBindingCount(for point: InspectionPoint) -> Int {
    switch point.expectedEvidenceType {
    case .multiPhoto:
      return 2
    case .photo, .video, .lidarScan, .thermalImage, .document:
      return 1
    }
  }
}
