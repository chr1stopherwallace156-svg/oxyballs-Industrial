import Foundation

/// Library-facing grouping of individually immutable captures under one inspection session.
///
/// Grouping key is strictly `inspectionSessionID`. Vehicle identifiers are attributes,
/// never the primary key — the same VIN inspected on different days remains separate groups.
public struct InspectionEvidenceGroup: Identifiable, Sendable, Equatable, Hashable {
  public var id: String { sessionID }

  public let sessionID: String
  public let vehicleIdentifier: String
  public let vehicleIdentifierKind: String
  public let inspectorID: String
  public let inspectorName: String
  public let startedAtUTC: String?
  public let sessionStatusAtLatestCapture: String?
  public let latestCaptureAt: Date
  public let captureCount: Int
  /// Deterministic order: captureTimestamp ascending, then capture id ascending.
  public let captures: [EvidenceLibraryIndexRecord]

  public init(
    sessionID: String,
    vehicleIdentifier: String,
    vehicleIdentifierKind: String,
    inspectorID: String,
    inspectorName: String,
    startedAtUTC: String?,
    sessionStatusAtLatestCapture: String?,
    latestCaptureAt: Date,
    captures: [EvidenceLibraryIndexRecord]
  ) {
    self.sessionID = sessionID
    self.vehicleIdentifier = vehicleIdentifier
    self.vehicleIdentifierKind = vehicleIdentifierKind
    self.inspectorID = inspectorID
    self.inspectorName = inspectorName
    self.startedAtUTC = startedAtUTC
    self.sessionStatusAtLatestCapture = sessionStatusAtLatestCapture
    self.latestCaptureAt = latestCaptureAt
    self.captureCount = captures.count
    self.captures = captures
  }

  public var representativeThumbnailRelativePath: String? {
    captures.last?.thumbnailRelativePath
  }
}

/// Pure, deterministic grouping for Evidence Library catalogs.
public enum InspectionEvidenceGrouping {
  public struct Catalog: Sendable, Equatable {
    /// Groups sorted by latestCaptureAt descending, then sessionID ascending.
    public let groups: [InspectionEvidenceGroup]
    /// Legacy records without inspectionSessionID — never invent session IDs.
    public let unassigned: [EvidenceLibraryIndexRecord]
  }

  public static func catalog(from records: [EvidenceLibraryIndexRecord]) -> Catalog {
    var bySession: [String: [EvidenceLibraryIndexRecord]] = [:]
    var unassigned: [EvidenceLibraryIndexRecord] = []

    for record in records {
      if let sid = record.inspectionSessionID, !sid.isEmpty {
        bySession[sid, default: []].append(record)
      } else {
        unassigned.append(record)
      }
    }

    let groups: [InspectionEvidenceGroup] = bySession.keys.sorted().compactMap { sessionID in
      guard var members = bySession[sessionID], !members.isEmpty else { return nil }
      members.sort { lhs, rhs in
        if lhs.captureTimestamp != rhs.captureTimestamp {
          return lhs.captureTimestamp < rhs.captureTimestamp
        }
        return lhs.id < rhs.id
      }
      let latest = members.max(by: { $0.captureTimestamp < $1.captureTimestamp }) ?? members[0]
      let head = members[0]
      return InspectionEvidenceGroup(
        sessionID: sessionID,
        vehicleIdentifier: head.inspectionVehicleIdentifier ?? head.vehicleOrSessionLabel ?? "",
        vehicleIdentifierKind: head.inspectionVehicleIdentifierKind ?? VehicleIdentifierKind.unknown.rawValue,
        inspectorID: head.inspectionInspectorID ?? "",
        inspectorName: head.inspectionInspectorName ?? "",
        startedAtUTC: head.inspectionStartedAtUTC,
        sessionStatusAtLatestCapture: latest.inspectionStatusAtCapture,
        latestCaptureAt: latest.captureTimestamp,
        captures: members
      )
    }
    .sorted { lhs, rhs in
      if lhs.latestCaptureAt != rhs.latestCaptureAt {
        return lhs.latestCaptureAt > rhs.latestCaptureAt
      }
      return lhs.sessionID < rhs.sessionID
    }

    let sortedUnassigned = unassigned.sorted { lhs, rhs in
      if lhs.captureTimestamp != rhs.captureTimestamp {
        return lhs.captureTimestamp > rhs.captureTimestamp
      }
      return lhs.id < rhs.id
    }

    return Catalog(groups: groups, unassigned: sortedUnassigned)
  }
}
