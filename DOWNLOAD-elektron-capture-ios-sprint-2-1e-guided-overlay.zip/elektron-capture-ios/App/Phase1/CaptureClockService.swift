import Foundation

/// Wall + monotonic capture timestamps. Never claims external discipline unless true.
public struct CaptureClockSnapshot: Equatable, Sendable {
  public var utcISO8601: String
  public var monotonicNanoseconds: UInt64
  public var clockDomain: String
  public var utcSource: String
  public var synchronizationStatus: String

  public init(
    utcISO8601: String,
    monotonicNanoseconds: UInt64,
    clockDomain: String = "wall",
    utcSource: String = "SYSTEM_CLOCK",
    synchronizationStatus: String = "NOT_EXTERNALLY_DISCIPLINED"
  ) {
    self.utcISO8601 = utcISO8601
    self.monotonicNanoseconds = monotonicNanoseconds
    self.clockDomain = clockDomain
    self.utcSource = utcSource
    self.synchronizationStatus = synchronizationStatus
  }

  public func asDictionary() -> [String: Any] {
    // Prefer Int64 so CanonicalJSON does not depend on UInt64→NSNumber bridging.
    let monoJSON: Any =
      Int64(exactly: monotonicNanoseconds).map { $0 as Any }
      ?? NSNumber(value: monotonicNanoseconds)
    return [
      "utc": utcISO8601,
      "monotonic_ns": monoJSON,
      "clock_domain": "monotonic_uptime",
      "utc_source": utcSource,
      "synchronization_status": synchronizationStatus,
    ]
  }
}

public struct CaptureClockService: Sendable {
  public init() {}

  public func snapshot(now: Date = Date()) -> CaptureClockSnapshot {
    let mono = DispatchTime.now().uptimeNanoseconds
    // Create formatters per call — ISO8601DateFormatter is not Sendable.
    let formatter = ISO8601DateFormatter()
    formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    var utc = formatter.string(from: now)
    // Fallback if fractional seconds unsupported on older formatters
    if utc.isEmpty {
      let plain = ISO8601DateFormatter()
      plain.formatOptions = [.withInternetDateTime]
      utc = plain.string(from: now)
    }
    return CaptureClockSnapshot(utcISO8601: utc, monotonicNanoseconds: mono)
  }
}
