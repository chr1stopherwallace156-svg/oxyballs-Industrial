import Foundation

/// Integrity metadata over the canonical encoded ``InspectionSession`` payload in an envelope.
///
/// Distinct from S2-002 ``InspectionPlanSnapshot/snapshotSHA256`` (plan-definition digest).
public struct InspectionSessionEnvelopeIntegrity: Codable, Equatable, Sendable {
  /// Algorithm id for envelope session payload hashing (`sha256-canonical-json-v1` stack).
  public let algorithm: String
  /// Digest of the canonical encoded `session` value only (not filesystem metadata).
  public let sessionDigest: String

  public init(algorithm: String, sessionDigest: String) {
    self.algorithm = algorithm
    self.sessionDigest = sessionDigest
  }
}

/// Authoritative persistent envelope for ``InspectionSession`` (Sprint 2.1B).
///
/// Separates domain state, schema version, save metadata, and integrity.
/// Does not carry filesystem paths, registry objects, or UI state.
public struct InspectionSessionEnvelope: Codable, Equatable, Sendable {
  public let schemaVersion: InspectionSessionSchemaVersion
  public let session: InspectionSession
  public let savedAt: Date
  public let integrity: InspectionSessionEnvelopeIntegrity

  public init(
    schemaVersion: InspectionSessionSchemaVersion = .current,
    session: InspectionSession,
    savedAt: Date,
    integrity: InspectionSessionEnvelopeIntegrity
  ) {
    self.schemaVersion = schemaVersion
    self.session = session
    self.savedAt = savedAt
    self.integrity = integrity
  }
}
