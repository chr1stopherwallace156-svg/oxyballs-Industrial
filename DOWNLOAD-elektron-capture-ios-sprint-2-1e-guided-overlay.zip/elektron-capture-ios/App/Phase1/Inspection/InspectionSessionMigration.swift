import Foundation

/// One ordered migration step between envelope schema versions.
public protocol InspectionSessionMigration: Sendable {
  var sourceVersion: InspectionSessionSchemaVersion { get }
  var destinationVersion: InspectionSessionSchemaVersion { get }
  func migrate(_ envelope: InspectionSessionEnvelope) throws -> InspectionSessionEnvelope
}

/// Registry of deterministic version→version migration steps.
public struct InspectionSessionMigrationRegistry: Sendable {
  private let bySource: [Int: any InspectionSessionMigration]

  public init(migrations: [any InspectionSessionMigration] = []) {
    var map: [Int: any InspectionSessionMigration] = [:]
    for migration in migrations {
      map[migration.sourceVersion.rawValue] = migration
    }
    self.bySource = map
  }

  /// Empty registry — only ``InspectionSessionSchemaVersion/v1`` exists in 2.1B.
  public static let empty = InspectionSessionMigrationRegistry()

  public func migration(from source: InspectionSessionSchemaVersion) -> (any InspectionSessionMigration)? {
    bySource[source.rawValue]
  }
}

/// Applies ordered migrations up to ``InspectionSessionSchemaVersion/current``.
public struct InspectionSessionMigrator: Sendable {
  public var registry: InspectionSessionMigrationRegistry

  public init(registry: InspectionSessionMigrationRegistry = .empty) {
    self.registry = registry
  }

  public func migrateToCurrent(_ envelope: InspectionSessionEnvelope) throws -> InspectionSessionEnvelope {
    if envelope.schemaVersion.isUnsupportedFuture {
      throw InspectionSessionPersistenceError.unsupportedSchemaVersion(envelope.schemaVersion.rawValue)
    }
    var current = envelope
    while current.schemaVersion < .current {
      guard let step = registry.migration(from: current.schemaVersion) else {
        throw InspectionSessionPersistenceError.missingMigrationPath(
          from: current.schemaVersion.rawValue,
          to: InspectionSessionSchemaVersion.current.rawValue
        )
      }
      let next = try step.migrate(current)
      guard next.schemaVersion > current.schemaVersion else {
        throw InspectionSessionPersistenceError.missingMigrationPath(
          from: current.schemaVersion.rawValue,
          to: step.destinationVersion.rawValue
        )
      }
      current = next
    }
    try InspectionSessionEnvelopeCoder.verify(current)
    return current
  }
}

/// Loads bytes that may be a v1 envelope, a pre-2.1B current-session envelope, or a raw session.
///
/// Does **not** overwrite source files. Does **not** consult ``InspectionPlanRegistry``.
/// Does **not** fabricate assigned plan snapshots.
public enum InspectionSessionEnvelopeLoader {
  /// Detect shape and return a verified current-schema envelope (in memory only).
  public static func load(
    from data: Data,
    savedAt: Date = Date(),
    migrator: InspectionSessionMigrator = InspectionSessionMigrator()
  ) throws -> InspectionSessionEnvelope {
    let decoder = InspectionSessionEnvelopeCoder.makeJSONDecoder()

    // 1) Authoritative v1+ envelope
    if let envelope = try? decoder.decode(InspectionSessionEnvelope.self, from: data) {
      if envelope.schemaVersion.isUnsupportedFuture {
        throw InspectionSessionPersistenceError.unsupportedSchemaVersion(envelope.schemaVersion.rawValue)
      }
      try InspectionSessionEnvelopeCoder.verify(envelope)
      return try migrator.migrateToCurrent(envelope)
    }

    // 2) Pre-2.1B current-session envelope (`schemaVersion: "1.0.0"` string)
    if let legacy = try? decoder.decode(CurrentSessionPersistenceEnvelope.self, from: data),
      legacy.schemaVersion == CurrentSessionPersistenceEnvelope.currentSchemaVersion
    {
      // Preserve planState as decoded (assigned or legacyUnassigned) — never invent.
      return try InspectionSessionEnvelopeCoder.makeEnvelope(
        session: legacy.session,
        savedAt: savedAt,
        schemaVersion: .current
      )
    }

    // 3) Raw pre-envelope InspectionSession JSON
    if let session = try? decoder.decode(InspectionSession.self, from: data) {
      return try InspectionSessionEnvelopeCoder.makeEnvelope(
        session: session,
        savedAt: savedAt,
        schemaVersion: .current
      )
    }

    throw InspectionSessionPersistenceError.malformedEnvelope("unrecognized session persistence payload")
  }
}
