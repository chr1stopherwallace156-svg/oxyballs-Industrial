import Foundation

/// Explicit persistence failures for session envelopes / stores (Sprint 2.1B).
public enum InspectionSessionPersistenceError: Error, Equatable, Sendable {
  case fileNotFound(String)
  case malformedEnvelope(String)
  case unsupportedSchemaVersion(Int)
  case missingMigrationPath(from: Int, to: Int)
  case sessionIdentityMismatch(expected: String, actual: String)
  case integrityMismatch(expected: String, actual: String)
  case unsupportedIntegrityAlgorithm(String)
  case atomicWriteFailed(String)
  case invalidStorageLocation(String)
  case invalidSessionPayload(String)
}
