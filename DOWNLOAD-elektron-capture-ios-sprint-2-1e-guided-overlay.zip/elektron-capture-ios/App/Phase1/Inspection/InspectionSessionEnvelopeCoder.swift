import Foundation

/// Build / verify / encode ``InspectionSessionEnvelope`` using the S2-002 canonical JSON + SHA-256 stack.
///
/// Envelope `sessionDigest` hashes the canonical ``InspectionSession`` payload only.
/// Plan-definition digests (`snapshotSHA256`) remain independent.
public enum InspectionSessionEnvelopeCoder {
  public static let integrityAlgorithmID = "sha256-canonical-json-v1"

  public static func makeJSONEncoder() -> JSONEncoder {
    let enc = JSONEncoder()
    enc.dateEncodingStrategy = .iso8601
    enc.outputFormatting = [.sortedKeys]
    return enc
  }

  public static func makeJSONDecoder() -> JSONDecoder {
    let dec = JSONDecoder()
    dec.dateDecodingStrategy = .iso8601
    return dec
  }

  /// Canonical bytes of the session domain value (stable across encode→object→CanonicalJSON).
  public static func canonicalSessionPayload(for session: InspectionSession) throws -> Data {
    let wire = try makeJSONEncoder().encode(session)
    let object: Any
    do {
      object = try JSONSerialization.jsonObject(with: wire, options: [.fragmentsAllowed])
    } catch {
      throw InspectionSessionPersistenceError.invalidSessionPayload(String(describing: error))
    }
    do {
      return try CanonicalJSONEncoder.encode(object, stage: "inspection_session_envelope_payload")
    } catch {
      throw InspectionSessionPersistenceError.invalidSessionPayload(String(describing: error))
    }
  }

  public static func sessionDigest(for session: InspectionSession) throws -> String {
    ContentHasher.sha256Hex(try canonicalSessionPayload(for: session))
  }

  public static func makeEnvelope(
    session: InspectionSession,
    savedAt: Date,
    schemaVersion: InspectionSessionSchemaVersion = .current
  ) throws -> InspectionSessionEnvelope {
    let digest = try sessionDigest(for: session)
    let envelope = InspectionSessionEnvelope(
      schemaVersion: schemaVersion,
      session: session,
      savedAt: savedAt,
      integrity: InspectionSessionEnvelopeIntegrity(
        algorithm: integrityAlgorithmID,
        sessionDigest: digest
      )
    )
    try verify(envelope)
    return envelope
  }

  public static func verify(_ envelope: InspectionSessionEnvelope) throws {
    if envelope.schemaVersion.isUnsupportedFuture {
      throw InspectionSessionPersistenceError.unsupportedSchemaVersion(envelope.schemaVersion.rawValue)
    }
    guard envelope.integrity.algorithm == integrityAlgorithmID else {
      throw InspectionSessionPersistenceError.unsupportedIntegrityAlgorithm(envelope.integrity.algorithm)
    }
    let computed = try sessionDigest(for: envelope.session)
    guard computed == envelope.integrity.sessionDigest else {
      throw InspectionSessionPersistenceError.integrityMismatch(
        expected: envelope.integrity.sessionDigest,
        actual: computed
      )
    }
  }

  public static func encode(_ envelope: InspectionSessionEnvelope) throws -> Data {
    try verify(envelope)
    return try makeJSONEncoder().encode(envelope)
  }

  public static func decodeVerifiedEnvelope(from data: Data) throws -> InspectionSessionEnvelope {
    let envelope: InspectionSessionEnvelope
    do {
      envelope = try makeJSONDecoder().decode(InspectionSessionEnvelope.self, from: data)
    } catch let e as InspectionSessionPersistenceError {
      throw e
    } catch {
      throw InspectionSessionPersistenceError.malformedEnvelope(String(describing: error))
    }
    try verify(envelope)
    return envelope
  }
}
