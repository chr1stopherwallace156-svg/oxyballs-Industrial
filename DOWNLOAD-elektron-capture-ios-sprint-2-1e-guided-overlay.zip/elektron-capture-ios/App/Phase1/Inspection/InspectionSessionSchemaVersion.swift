import Foundation

/// Persistent schema version for ``InspectionSessionEnvelope`` (Sprint 2.1B).
///
/// First persistent envelope schema introduced by 2.1B is ``v1`` (`rawValue == 1`).
/// Integer versions avoid arbitrary string comparison.
public struct InspectionSessionSchemaVersion: RawRepresentable, Codable, Equatable, Comparable, Hashable,
  Sendable
{
  public let rawValue: Int

  public init(rawValue: Int) {
    self.rawValue = rawValue
  }

  /// First authoritative persistent envelope schema (Sprint 2.1B).
  public static let v1 = InspectionSessionSchemaVersion(rawValue: 1)

  /// Current write version.
  public static let current = v1

  public static func < (lhs: InspectionSessionSchemaVersion, rhs: InspectionSessionSchemaVersion) -> Bool {
    lhs.rawValue < rhs.rawValue
  }

  public var isCurrent: Bool { self == .current }

  public var isSupportedLegacy: Bool { self < .current && self.rawValue >= 1 }

  public var isUnsupportedFuture: Bool { self > .current }

  public init(from decoder: Decoder) throws {
    let c = try decoder.singleValueContainer()
    rawValue = try c.decode(Int.self)
  }

  public func encode(to encoder: Encoder) throws {
    var c = encoder.singleValueContainer()
    try c.encode(rawValue)
  }
}
