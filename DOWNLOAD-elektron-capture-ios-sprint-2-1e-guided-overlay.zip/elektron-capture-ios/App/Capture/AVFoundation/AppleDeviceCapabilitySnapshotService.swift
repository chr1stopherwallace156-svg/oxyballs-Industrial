import Foundation

#if canImport(AVFoundation)
import AVFoundation
#endif

/// Production capability snapshot service.
///
/// Uses injectable discovery / authorization so unit tests do not need a physical iPhone.
/// On Apple platforms the defaults query AVFoundation; elsewhere defaults are inert.
public actor AppleDeviceCapabilitySnapshotService: DeviceCapabilitySnapshotProviding {
  private let authorization: any CameraAuthorizationStatusProviding
  private let discovery: any CameraDeviceDiscovering
  private let motion: any MotionCapabilityChecking
  private let identity: any DeviceIdentityProviding
  private let clock: CaptureClockService
  private let snapshotIDGenerator: @Sendable () -> String

  public init(
    authorization: any CameraAuthorizationStatusProviding = DefaultCameraAuthorizationStatusProvider(),
    discovery: any CameraDeviceDiscovering = DefaultCameraDeviceDiscovery(),
    motion: any MotionCapabilityChecking = SystemMotionCapabilityChecker(),
    identity: any DeviceIdentityProviding = SystemDeviceIdentityProvider(),
    clock: CaptureClockService = CaptureClockService(),
    snapshotIDGenerator: @escaping @Sendable () -> String = { "CAPSNAP-\(UUID().uuidString)" }
  ) {
    self.authorization = authorization
    self.discovery = discovery
    self.motion = motion
    self.identity = identity
    self.clock = clock
    self.snapshotIDGenerator = snapshotIDGenerator
  }

  public func captureSnapshot() async -> DeviceCapabilitySnapshot {
    let auth = authorization.videoAuthorizationState()
    let utc = clock.snapshot().utcISO8601
    let snapshotID = snapshotIDGenerator()
    let deviceModel = identity.deviceModel()
    let osVersion = identity.operatingSystemVersion()
    let motionState = motion.motionCapabilityState()

    switch auth {
    case .denied, .restricted:
      return DeviceCapabilitySnapshot(
        snapshotID: snapshotID,
        capturedAtUTC: utc,
        deviceModel: deviceModel,
        operatingSystemVersion: osVersion,
        availableCameras: [],
        motion: motionState,
        depth: .permissionDenied,
        lidar: .permissionDenied
      )

    case .notDetermined, .authorized:
      let discovered = discovery.discoverCameras()
      // Stable order for deterministic encoding when discovery order varies.
      let cameras = discovered
        .map { $0.asCameraCapability() }
        .sorted { $0.cameraID < $1.cameraID }

      let depthState: CapabilityState
      let lidarState: CapabilityState
      if auth == .notDetermined && discovered.isEmpty {
        depthState = .unknown
        lidarState = .unknown
      } else {
        // On platforms that cannot probe iPhone depth/LiDAR, discovery returns empty
        // and these resolve to .unsupported (not falsely .supported).
        depthState = discovered.contains(where: \.supportsDepthData) ? .supported : .unsupported
        lidarState = discovered.contains(where: \.isLiDARDevice) ? .supported : .unsupported
      }

      return DeviceCapabilitySnapshot(
        snapshotID: snapshotID,
        capturedAtUTC: utc,
        deviceModel: deviceModel,
        operatingSystemVersion: osVersion,
        availableCameras: cameras,
        motion: motionState,
        depth: depthState,
        lidar: lidarState
      )
    }
  }
}

// MARK: - Default Apple / fallback providers

public struct DefaultCameraAuthorizationStatusProvider: CameraAuthorizationStatusProviding {
  public init() {}

  public func videoAuthorizationState() -> CameraAuthorizationState {
    #if canImport(AVFoundation)
    switch AVCaptureDevice.authorizationStatus(for: .video) {
    case .authorized: return .authorized
    case .notDetermined: return .notDetermined
    case .denied: return .denied
    case .restricted: return .restricted
    @unknown default: return .denied
    }
    #else
    return .notDetermined
    #endif
  }
}

public struct DefaultCameraDeviceDiscovery: CameraDeviceDiscovering {
  public init() {}

  public func discoverCameras() -> [DiscoveredCameraDevice] {
    #if os(iOS) || targetEnvironment(macCatalyst)
    #if canImport(AVFoundation)
    return IOSAVFoundationCameraDeviceDiscovery().discoverCameras()
    #else
    return []
    #endif
    #elseif os(macOS)
    // A Mac may have a camera, but that is not Elektron’s iPhone evidence-capture contract.
    // Do not enumerate Mac cameras as Capture capability nodes and never claim depth/LiDAR.
    return MacHostCameraCapabilityDiscovery().discoverCameras()
    #else
    return []
    #endif
  }
}

/// Explicit macOS host fallback: no iPhone capability nodes, no depth/LiDAR claims.
public struct MacHostCameraCapabilityDiscovery: CameraDeviceDiscovering {
  public init() {}

  public func discoverCameras() -> [DiscoveredCameraDevice] {
    []
  }
}

#if canImport(AVFoundation) && (os(iOS) || targetEnvironment(macCatalyst))
/// Enumerates rear cameras via `AVCaptureDevice.DiscoverySession` without configuring a session.
/// Compiles only on iOS / Mac Catalyst where phone-class device types and depth APIs exist.
public struct IOSAVFoundationCameraDeviceDiscovery: CameraDeviceDiscovering {
  public init() {}

  public func discoverCameras() -> [DiscoveredCameraDevice] {
    var types: [AVCaptureDevice.DeviceType] = [
      .builtInWideAngleCamera,
      .builtInUltraWideCamera,
      .builtInTelephotoCamera,
      .builtInDualCamera,
      .builtInDualWideCamera,
      .builtInTripleCamera,
    ]
    if #available(iOS 15.4, *) {
      types.append(.builtInLiDARDepthCamera)
    }

    let session = AVCaptureDevice.DiscoverySession(
      deviceTypes: types,
      mediaType: .video,
      position: .back
    )

    var seen = Set<String>()
    var out: [DiscoveredCameraDevice] = []
    for device in session.devices {
      if seen.contains(device.uniqueID) { continue }
      seen.insert(device.uniqueID)
      out.append(Self.map(device))
    }
    return out
  }

  private static func map(_ device: AVCaptureDevice) -> DiscoveredCameraDevice {
    let supportsDepth = device.formats.contains { !$0.supportedDepthDataFormats.isEmpty }
    let isLiDAR: Bool
    if #available(iOS 15.4, *) {
      isLiDAR = device.deviceType == .builtInLiDARDepthCamera
    } else {
      isLiDAR = false
    }
    return DiscoveredCameraDevice(
      uniqueID: device.uniqueID,
      position: positionString(device.position),
      deviceType: device.deviceType.rawValue,
      supportsFocusLock: device.isFocusModeSupported(.locked),
      supportsExposureLock: device.isExposureModeSupported(.locked),
      supportsDepthData: supportsDepth || isLiDAR,
      isLiDARDevice: isLiDAR
    )
  }

  private static func positionString(_ position: AVCaptureDevice.Position) -> String {
    switch position {
    case .back: return "back"
    case .front: return "front"
    case .unspecified: return "unspecified"
    @unknown default: return "unknown"
    }
  }
}
#endif
