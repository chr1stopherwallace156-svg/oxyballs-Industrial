import XCTest
@testable import ElektronCapture

final class CapabilityStateCodingTests: XCTestCase {
  func testRawValuesAreStable() {
    XCTAssertEqual(CapabilityState.supported.rawValue, "SUPPORTED")
    XCTAssertEqual(CapabilityState.unsupported.rawValue, "UNSUPPORTED")
    XCTAssertEqual(CapabilityState.unknown.rawValue, "UNKNOWN")
    XCTAssertEqual(CapabilityState.unavailable.rawValue, "UNAVAILABLE")
    XCTAssertEqual(CapabilityState.permissionDenied.rawValue, "PERMISSION_DENIED")
  }

  func testCodableRoundTrip() throws {
    let encoder = JSONEncoder()
    let decoder = JSONDecoder()
    for state in [
      CapabilityState.supported,
      .unsupported,
      .unknown,
      .unavailable,
      .permissionDenied,
    ] {
      let data = try encoder.encode(state)
      let decoded = try decoder.decode(CapabilityState.self, from: data)
      XCTAssertEqual(decoded, state)
      let text = String(data: data, encoding: .utf8)
      XCTAssertEqual(text, "\"\(state.rawValue)\"")
    }
  }
}
