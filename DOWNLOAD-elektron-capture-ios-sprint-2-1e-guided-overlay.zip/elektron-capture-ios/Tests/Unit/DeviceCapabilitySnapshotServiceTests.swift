import XCTest
@testable import ElektronCapture

private struct FixedAuth: CameraAuthorizationStatusProviding {
  var state: CameraAuthorizationState
  func videoAuthorizationState() -> CameraAuthorizationState { state }
}

private struct FixedDiscovery: CameraDeviceDiscovering {
  var devices: [DiscoveredCameraDevice]
  func discoverCameras() -> [DiscoveredCameraDevice] { devices }
}

private struct FixedMotion: MotionCapabilityChecking {
  var state: CapabilityState
  func motionCapabilityState() -> CapabilityState { state }
}

private struct FixedIdentity: DeviceIdentityProviding {
  func deviceModel() -> String { "TestDevice1,0" }
  func operatingSystemVersion() -> String { "test-os" }
}

final class DeviceCapabilitySnapshotServiceTests: XCTestCase {
  private let wide = DiscoveredCameraDevice(
    uniqueID: "WIDE-1",
    position: "back",
    deviceType: "AVCaptureDeviceTypeBuiltInWideAngleCamera",
    supportsFocusLock: true,
    supportsExposureLock: true,
    supportsDepthData: false,
    isLiDARDevice: false
  )
  private let lidar = DiscoveredCameraDevice(
    uniqueID: "LIDAR-1",
    position: "back",
    deviceType: "AVCaptureDeviceTypeBuiltInLiDARDepthCamera",
    supportsFocusLock: true,
    supportsExposureLock: true,
    supportsDepthData: true,
    isLiDARDevice: true
  )

  func testAuthorizedMapsSupportedUnsupported() async {
    let service = AppleDeviceCapabilitySnapshotService(
      authorization: FixedAuth(state: .authorized),
      discovery: FixedDiscovery(devices: [lidar, wide]),
      motion: FixedMotion(state: .supported),
      identity: FixedIdentity(),
      clock: CaptureClockService(),
      snapshotIDGenerator: { "CAPSNAP-TEST-AUTH" }
    )
    let snap = await service.captureSnapshot()
    XCTAssertEqual(snap.snapshotID, "CAPSNAP-TEST-AUTH")
    XCTAssertEqual(snap.deviceModel, "TestDevice1,0")
    XCTAssertEqual(snap.availableCameras.map(\.cameraID), ["LIDAR-1", "WIDE-1"])
    XCTAssertEqual(snap.motion, .supported)
    XCTAssertEqual(snap.depth, .supported)
    XCTAssertEqual(snap.lidar, .supported)
    XCTAssertTrue(snap.availableCameras.contains { $0.supportsDepthData && $0.cameraID == "LIDAR-1" })
  }

  func testAuthorizedWithoutDepthOrLidarIsUnsupported() async {
    let service = AppleDeviceCapabilitySnapshotService(
      authorization: FixedAuth(state: .authorized),
      discovery: FixedDiscovery(devices: [wide]),
      motion: FixedMotion(state: .unsupported),
      identity: FixedIdentity(),
      snapshotIDGenerator: { "CAPSNAP-TEST-NODEPTH" }
    )
    let snap = await service.captureSnapshot()
    XCTAssertEqual(snap.depth, .unsupported)
    XCTAssertEqual(snap.lidar, .unsupported)
    XCTAssertEqual(snap.motion, .unsupported)
    XCTAssertEqual(snap.availableCameras.count, 1)
  }

  func testPermissionDeniedDoesNotEnumerateHardwareAsUnsupported() async {
    let service = AppleDeviceCapabilitySnapshotService(
      authorization: FixedAuth(state: .denied),
      discovery: FixedDiscovery(devices: [wide, lidar]),
      motion: FixedMotion(state: .supported),
      identity: FixedIdentity(),
      snapshotIDGenerator: { "CAPSNAP-TEST-DENIED" }
    )
    let snap = await service.captureSnapshot()
    XCTAssertTrue(snap.availableCameras.isEmpty)
    XCTAssertEqual(snap.depth, .permissionDenied)
    XCTAssertEqual(snap.lidar, .permissionDenied)
    // Motion does not require camera permission.
    XCTAssertEqual(snap.motion, .supported)
  }

  func testRestrictedMapsToPermissionDenied() async {
    let service = AppleDeviceCapabilitySnapshotService(
      authorization: FixedAuth(state: .restricted),
      discovery: FixedDiscovery(devices: [wide]),
      motion: FixedMotion(state: .unknown),
      identity: FixedIdentity(),
      snapshotIDGenerator: { "CAPSNAP-TEST-RESTRICTED" }
    )
    let snap = await service.captureSnapshot()
    XCTAssertEqual(snap.depth, .permissionDenied)
    XCTAssertEqual(snap.lidar, .permissionDenied)
    XCTAssertTrue(snap.availableCameras.isEmpty)
  }

  func testNotDeterminedWithEmptyDiscoveryIsUnknownDepthLidar() async {
    let service = AppleDeviceCapabilitySnapshotService(
      authorization: FixedAuth(state: .notDetermined),
      discovery: FixedDiscovery(devices: []),
      motion: FixedMotion(state: .unknown),
      identity: FixedIdentity(),
      snapshotIDGenerator: { "CAPSNAP-TEST-UNKNOWN" }
    )
    let snap = await service.captureSnapshot()
    XCTAssertEqual(snap.depth, .unknown)
    XCTAssertEqual(snap.lidar, .unknown)
    XCTAssertTrue(snap.availableCameras.isEmpty)
  }
}
