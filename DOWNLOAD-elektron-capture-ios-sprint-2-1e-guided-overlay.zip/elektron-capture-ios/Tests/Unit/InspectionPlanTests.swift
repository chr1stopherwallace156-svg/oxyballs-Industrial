import XCTest
@testable import ElektronCapture

final class InspectionPlanTests: XCTestCase {
  func testRegistryDefaultTemplatesValidateAndLookup() throws {
    let registry = InspectionPlanRegistry()
    XCTAssertEqual(registry.allPlans.count, 2)
    let commercial = try registry.plan(id: "standard_commercial_intake", version: "1.0.0")
    XCTAssertEqual(commercial.title, "Standard Commercial Intake")
    XCTAssertEqual(commercial.points.count, 6)
    XCTAssertEqual(commercial.requiredPoints.count, 5)
    let quick = try registry.plan(id: "quick_4_point", version: "1.0.0")
    XCTAssertEqual(quick.points.count, 4)
  }

  func testValidatorRejectsDuplicatePointIDs() throws {
    var plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let dup = try InspectionPoint(id: "front", title: "Dup", displayOrder: 99)
    plan = InspectionPlan(
      id: plan.id,
      version: plan.version,
      title: plan.title,
      descriptionText: plan.descriptionText,
      points: plan.points + [dup]
    )
    XCTAssertThrowsError(try InspectionPlanValidator.validate(plan)) { err in
      guard case InspectionPlanError.duplicatePointID("front") = err else {
        return XCTFail("unexpected \(err)")
      }
    }
  }

  func testValidatorRejectsNonDeterministicOrdering() throws {
    let points = [
      try InspectionPoint(id: "b", title: "B", displayOrder: 2),
      try InspectionPoint(id: "a", title: "A", displayOrder: 1),
    ]
    let plan = try InspectionPlan(
      id: "bad_order",
      version: "1.0.0",
      title: "Bad Order",
      points: points
    )
    XCTAssertThrowsError(try InspectionPlanValidator.validate(plan)) { err in
      guard case InspectionPlanError.nonDeterministicPointOrdering = err else {
        return XCTFail("unexpected \(err)")
      }
    }
  }

  func testValidatorRejectsInvalidSemver() throws {
    let plan = try InspectionPlan(
      id: "x",
      version: "1.0",
      title: "X",
      points: [try InspectionPoint(id: "p", title: "P", displayOrder: 1)]
    )
    XCTAssertThrowsError(try InspectionPlanValidator.validate(plan)) { err in
      guard case InspectionPlanError.invalidSemanticVersion("1.0") = err else {
        return XCTFail("unexpected \(err)")
      }
    }
  }

  func testSnapshotHashIsDeterministicForSameDefinition() throws {
    let registry = InspectionPlanRegistry()
    let plan = try registry.plan(id: "standard_commercial_intake", version: "1.0.0")
    let factory = InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(Date(timeIntervalSince1970: 1_700_000_000))
    )
    let a = try factory.makeSnapshot(from: plan)
    let b = try factory.makeSnapshot(from: plan)
    XCTAssertEqual(a.snapshotSHA256, b.snapshotSHA256)
    XCTAssertEqual(a.snapshotSHA256.count, 64)
    XCTAssertEqual(a.snapshotSHA256, a.snapshotSHA256.lowercased())
    XCTAssertFalse(a.snapshotSHA256.contains(where: { !$0.isHexDigit }))
    XCTAssertEqual(a.snapshotHashAlgorithm, "sha256-canonical-json-v1")
    // Created-at differs only if provider advances; same fixed instant → equal metadata too.
    XCTAssertEqual(a.snapshotCreatedAt, b.snapshotCreatedAt)
    try InspectionPlanSnapshotHasher.verify(a)
  }

  func testSnapshotHashIgnoresCreatedAt() throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let early = try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(Date(timeIntervalSince1970: 1_000))
    ).makeSnapshot(from: plan)
    let late = try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(Date(timeIntervalSince1970: 9_000))
    ).makeSnapshot(from: plan)
    XCTAssertEqual(early.snapshotSHA256, late.snapshotSHA256)
    XCTAssertNotEqual(early.snapshotCreatedAt, late.snapshotCreatedAt)
  }

  func testSnapshotHashChangesWhenPointChanges() throws {
    let registry = InspectionPlanRegistry()
    let base = try registry.plan(id: "quick_4_point", version: "1.0.0")
    var alteredPoints = base.points
    alteredPoints[0] = InspectionPoint(
      id: alteredPoints[0].id,
      title: "Front Altered",
      displayOrder: alteredPoints[0].displayOrder,
      isRequired: alteredPoints[0].isRequired,
      guidanceInstruction: alteredPoints[0].guidanceInstruction,
      expectedEvidenceType: alteredPoints[0].expectedEvidenceType
    )
    let altered = InspectionPlan(
      id: base.id,
      version: base.version,
      title: base.title,
      descriptionText: base.descriptionText,
      points: alteredPoints
    )
    let factory = InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(Date(timeIntervalSince1970: 42))
    )
    let a = try factory.makeSnapshot(from: base)
    let b = try factory.makeSnapshot(from: altered)
    XCTAssertNotEqual(a.snapshotSHA256, b.snapshotSHA256)
  }

  func testVerifyRejectsTamperedDigest() throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    var snapshot = try InspectionPlanSnapshotFactory().makeSnapshot(from: plan)
    snapshot = InspectionPlanSnapshot(
      payload: snapshot.payload,
      snapshotCreatedAt: snapshot.snapshotCreatedAt,
      snapshotSHA256: String(repeating: "0", count: 64),
      snapshotHashAlgorithm: snapshot.snapshotHashAlgorithm
    )
    XCTAssertThrowsError(try InspectionPlanSnapshotHasher.verify(snapshot)) { err in
      guard case InspectionPlanError.hashMismatch = err else {
        return XCTFail("unexpected \(err)")
      }
    }
  }

  func testVerifyRejectsUnknownAlgorithm() throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let good = try InspectionPlanSnapshotFactory().makeSnapshot(from: plan)
    let bad = InspectionPlanSnapshot(
      payload: good.payload,
      snapshotCreatedAt: good.snapshotCreatedAt,
      snapshotSHA256: good.snapshotSHA256,
      snapshotHashAlgorithm: "SHA-256"
    )
    XCTAssertThrowsError(try InspectionPlanSnapshotHasher.verify(bad)) { err in
      guard case InspectionPlanError.unsupportedHashAlgorithm("SHA-256") = err else {
        return XCTFail("unexpected \(err)")
      }
    }
  }

  func testCanonicalPayloadBytesAreStable() throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let snapshot = try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(Date(timeIntervalSince1970: 7))
    ).makeSnapshot(from: plan)
    let bytes1 = try CanonicalJSONEncoder.encode(snapshot.payload.asDictionary())
    let bytes2 = try CanonicalJSONEncoder.encode(snapshot.payload.asDictionary())
    XCTAssertEqual(bytes1, bytes2)
    XCTAssertEqual(ContentHasher.sha256Hex(bytes1), snapshot.snapshotSHA256)
  }
}
