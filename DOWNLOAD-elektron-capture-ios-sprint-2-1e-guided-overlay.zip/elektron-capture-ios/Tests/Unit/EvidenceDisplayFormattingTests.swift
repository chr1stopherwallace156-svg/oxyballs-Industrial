import XCTest
@testable import ElektronCapture

final class EvidenceDisplayFormattingTests: XCTestCase {
  func testLocalDateTimeFromDateIncludesTimezoneAbbreviation() {
    var calendar = Calendar(identifier: .gregorian)
    calendar.timeZone = TimeZone(identifier: "America/Los_Angeles")!
    let date = calendar.date(from: DateComponents(year: 2026, month: 7, day: 25, hour: 13, minute: 20))!
    let text = EvidenceDisplayFormatting.localDateTime(
      from: date,
      timeZone: TimeZone(identifier: "America/Los_Angeles")!
    )
    XCTAssertTrue(text.contains("Jul 25, 2026"))
    XCTAssertTrue(text.contains(" at "))
    XCTAssertTrue(text.contains("PDT") || text.contains("PST") || text.contains("GMT"))
    XCTAssertFalse(text.contains("2026-07-25T"))
  }

  func testLocalDateTimeFromISO8601PreservesRawInternally() {
    let raw = "2026-07-25T18:20:00Z"
    let text = EvidenceDisplayFormatting.localDateTime(fromISO8601: raw)
    XCTAssertFalse(text.contains("2026-07-25T"))
    XCTAssertNotEqual(text, raw)
  }

  func testInspectionStatusLabels() {
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel("IN_PROGRESS"), "In Progress")
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel("COMPLETED"), "Completed")
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel("CANCELED"), "Canceled")
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel("PAUSED"), "Paused")
    XCTAssertEqual(EvidenceDisplayFormatting.inspectionStatusLabel(nil), "Unknown")
  }

  func testVINClassifyKindIsHeuristicNotVerified() {
    XCTAssertEqual(VehicleIdentifier.classifyKind(from: "1HGCM82633A004352"), .vinHeuristic)
    XCTAssertEqual(VehicleIdentifier.classifyKind(from: " 1hgcm82633a004352 "), .vinHeuristic)
    XCTAssertEqual(VehicleIdentifier.classifyKind(from: "1HGCM82633A00435O"), .rawIdentifier)
    XCTAssertEqual(VehicleIdentifier.classifyKind(from: "SHORT"), .rawIdentifier)
    XCTAssertEqual(EvidenceDisplayFormatting.vehicleKindLabel("VIN_HEURISTIC"), "VIN (heuristic)")
    XCTAssertEqual(EvidenceDisplayFormatting.vehicleKindLabel("VIN"), "VIN (validated)")
    XCTAssertEqual(EvidenceDisplayFormatting.vehicleKindLabel("VIN_VALIDATED"), "VIN (validated)")
    XCTAssertEqual(EvidenceDisplayFormatting.vehicleKindLabel("RAW_IDENTIFIER"), "Vehicle identifier")
    XCTAssertEqual(EvidenceDisplayFormatting.vehicleKindLabel("UNKNOWN"), "Unknown")
  }
}
