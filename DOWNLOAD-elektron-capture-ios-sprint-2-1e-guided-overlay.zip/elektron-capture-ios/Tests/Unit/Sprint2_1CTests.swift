import XCTest
@testable import ElektronCapture

/// Sprint 2.1C — formal `InspectionProgressionEngine` state machine.
final class Sprint2_1CTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_200_000)
  private let engine = InspectionProgressionEngine()

  private func makeSnapshot() throws -> InspectionPlanSnapshot {
    let plan = try InspectionPlan(
      id: "prog_demo",
      version: "1.0.0",
      title: "Progress Demo",
      points: [
        try InspectionPoint(id: "p0", title: "P0", displayOrder: 1, isRequired: true),
        try InspectionPoint(id: "p1", title: "P1", displayOrder: 2, isRequired: true),
        try InspectionPoint(
          id: "p2",
          title: "P2",
          displayOrder: 3,
          isRequired: false,
          expectedEvidenceType: .multiPhoto
        ),
      ]
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession() throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked("INS-21C"),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "PROG-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: makeSnapshot(),
      assignedAt: fixedInstant
    )
  }

  private func initialized() throws -> InspectionSession {
    try engine.initializeProgress(for: makeSession())
  }

  private func pointID(_ raw: String) -> InspectionPointID {
    InspectionPointID.unchecked(raw)
  }

  // MARK: - Identity-targeted progression

  func testValidPointProgressionByPointID() throws {
    var session = try initialized()
    XCTAssertNil(session.progress?.activePointID)
    XCTAssertEqual(session.progress?.orderedPoints.map(\.status), [
      .notStarted, .notStarted, .notStarted,
    ])

    session = try engine.activate(pointID: pointID("p0"), in: session)
    XCTAssertEqual(session.progress?.activePointID, pointID("p0"))
    XCTAssertEqual(session.progress?.orderedPoints[0].status, .inProgress)

    session = try engine.completeActivePoint(in: session)
    XCTAssertEqual(session.progress?.orderedPoints[0].status, .completed)
    XCTAssertEqual(session.progress?.activePointID, pointID("p0"))

    session = try engine.advanceToNextEligiblePoint(in: session)
    XCTAssertEqual(session.progress?.activePointID, pointID("p1"))
    XCTAssertEqual(session.progress?.orderedPoints[1].status, .inProgress)

    session = try engine.skipActivePoint(reason: "inaccessible", in: session)
    session = try engine.advanceToNextEligiblePoint(in: session)
    XCTAssertEqual(session.progress?.activePointID, pointID("p2"))

    session = try engine.completeActivePoint(in: session)
    XCTAssertThrowsError(try engine.advanceToNextEligiblePoint(in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .noEligiblePoint)
    }
  }

  func testUnknownPointIDRejected() throws {
    let session = try initialized()
    XCTAssertThrowsError(
      try engine.activate(pointID: pointID("does-not-exist"), in: session)
    ) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .unknownPointID("does-not-exist"))
    }
  }

  func testDuplicatePointProgressRejected() throws {
    var session = try initialized()
    var progress = try XCTUnwrap(session.progress)
    progress.orderedPoints.append(
      InspectionPointProgress(pointID: pointID("p0"), status: .notStarted)
    )
    session.progress = progress
    XCTAssertThrowsError(try engine.activate(pointID: pointID("p1"), in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .duplicatePointID("p0"))
    }
  }

  func testProgressPointSetMismatchWithFrozenSnapshotRejected() throws {
    var session = try initialized()
    var progress = try XCTUnwrap(session.progress)
    progress.orderedPoints = [
      InspectionPointProgress(pointID: pointID("p0"), status: .notStarted),
      InspectionPointProgress(pointID: pointID("p1"), status: .notStarted),
    ]
    session.progress = progress
    XCTAssertThrowsError(try engine.activate(pointID: pointID("p0"), in: session)) { err in
      guard case InspectionProgressionError.progressSnapshotMismatch = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testWhitespaceOnlySkipAndBlockReasonsRejected() throws {
    var session = try initialized()
    session = try engine.activate(pointID: pointID("p0"), in: session)
    XCTAssertThrowsError(try engine.skipActivePoint(reason: "  \n\t", in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .emptySkipReason)
    }
    XCTAssertThrowsError(try engine.blockActivePoint(reason: "", in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .emptyBlockReason)
    }
    XCTAssertEqual(session.progress?.orderedPoints[0].status, .inProgress)
  }

  func testAdvanceDoesNotImplicitlyCompleteSkipOrBlockActivePoint() throws {
    var session = try initialized()
    session = try engine.activate(pointID: pointID("p0"), in: session)
    session = try engine.advanceToNextEligiblePoint(in: session)
    XCTAssertEqual(session.progress?.activePointID, pointID("p1"))
    // Prior in-progress demotes to notStarted — never silently completed/skipped/blocked.
    XCTAssertEqual(session.progress?.orderedPoints[0].status, .notStarted)
    XCTAssertEqual(session.progress?.orderedPoints[1].status, .inProgress)
  }

  func testBlockedRequiredPointPreventsSuccessfulCompletion() throws {
    var session = try initialized()
    session = try engine.activate(pointID: pointID("p0"), in: session)
    session = try engine.blockActivePoint(reason: "equipment failure", in: session)
    session = try engine.activate(pointID: pointID("p1"), in: session)
    session = try engine.completeActivePoint(in: session)
    XCTAssertEqual(engine.evaluateCompletion(of: session), .blocked)
  }

  func testCompletionDispositionIsDerivedNotPersisted() throws {
    var session = try initialized()
    XCTAssertEqual(engine.evaluateCompletion(of: session), .incomplete)

    session = try engine.activate(pointID: pointID("p0"), in: session)
    session = try engine.completeActivePoint(in: session)
    session = try engine.activate(pointID: pointID("p1"), in: session)
    session = try engine.skipActivePoint(reason: "covered", in: session)
    XCTAssertEqual(engine.evaluateCompletion(of: session), .complete)

    // Optional p2 still open does not block required-point completion.
    XCTAssertEqual(session.progress?.orderedPoints[2].status, .notStarted)

    // Mutating only statuses changes disposition — no stale persisted isComplete flag.
    session.progress?.orderedPoints[1].status = .inProgress
    XCTAssertEqual(engine.evaluateCompletion(of: session), .incomplete)
  }

  func testActivePointPersistedByIdentityNotIndex() throws {
    var session = try initialized()
    session = try engine.activate(pointID: pointID("p1"), in: session)
    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(
      session: session,
      savedAt: fixedInstant
    )
    let data = try InspectionSessionEnvelopeCoder.encode(envelope)
    let json = try XCTUnwrap(String(data: data, encoding: .utf8))
    XCTAssertTrue(json.contains("\"activePointID\""))
    XCTAssertTrue(json.contains("\"p1\""))
    XCTAssertFalse(json.contains("\"currentPointIndex\""))
    XCTAssertFalse(json.contains("\"activePointIndex\""))

    let decoded = try InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(from: data)
    XCTAssertEqual(decoded.session.progress?.activePointID, pointID("p1"))
    XCTAssertEqual(decoded.schemaVersion, .v1)
  }

  func testOlderV1SessionsDecodeWithoutProgress_OptionA() throws {
    // Pre-2.1C assigned session JSON omits `progress` — additive Option A.
    let session = try makeSession()
    XCTAssertNil(session.progress)
    let encoder = InspectionSessionEnvelopeCoder.makeJSONEncoder()
    let data = try encoder.encode(session)
    let decoded = try InspectionSessionEnvelopeCoder.makeJSONDecoder()
      .decode(InspectionSession.self, from: data)
    XCTAssertNil(decoded.progress)
    XCTAssertTrue(decoded.planState.isAssigned)

    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(
      session: session,
      savedAt: fixedInstant
    )
    XCTAssertEqual(envelope.schemaVersion, .v1)
    XCTAssertEqual(envelope.schemaVersion, .current)
  }

  func testLegacyUnassignedDoesNotReceiveFabricatedProgression() throws {
    let legacy = try InspectionSession(
      id: SessionID.unchecked("INS-21C-LEGACY"),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "LEGACY-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planState: .legacyUnassigned
    )
    XCTAssertNil(legacy.progress)
    XCTAssertThrowsError(try engine.initializeProgress(for: legacy)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .noAssignedPlan)
    }
    XCTAssertNil(legacy.progress)
  }

  func testRepeatedInitializationIsDeterministicAndIdempotent() throws {
    let base = try makeSession()
    let first = try engine.initializeProgress(for: base)
    let second = try engine.initializeProgress(for: first)
    XCTAssertEqual(first.progress, second.progress)
    XCTAssertEqual(
      first.progress?.orderedPoints.map(\.pointID.rawValue),
      ["p0", "p1", "p2"]
    )
    XCTAssertNil(first.progress?.activePointID)
  }

  func testStrictlyTerminalReactivationPolicy() throws {
    var session = try initialized()
    session = try engine.activate(pointID: pointID("p0"), in: session)
    session = try engine.completeActivePoint(in: session)

    // No reactivatePoint API; activate of a terminal point is rejected.
    XCTAssertThrowsError(try engine.activate(pointID: pointID("p0"), in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .pointIsTerminal("p0"))
    }
    XCTAssertThrowsError(try engine.completeActivePoint(in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .pointIsTerminal("p0"))
    }

    session = try engine.activate(pointID: pointID("p1"), in: session)
    session = try engine.skipActivePoint(reason: "n/a", in: session)
    XCTAssertThrowsError(try engine.activate(pointID: pointID("p1"), in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .pointIsTerminal("p1"))
    }

    session = try engine.activate(pointID: pointID("p2"), in: session)
    session = try engine.blockActivePoint(reason: "hazard", in: session)
    XCTAssertThrowsError(try engine.activate(pointID: pointID("p2"), in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .pointIsTerminal("p2"))
    }

    // Documented absence of reopen surface.
    XCTAssertNil(
      Mirror(reflecting: engine).children.first { $0.label == "reactivatePoint" }
    )
  }

  func testEngineHasNoSharedMutableGlobalState() throws {
    // Stateless value type: independently constructed engines do not share mutable state.
    var s1 = try initialized()
    var s2 = try initialized()
    let e1 = InspectionProgressionEngine()
    let e2 = InspectionProgressionEngine()
    s1 = try e1.activate(pointID: pointID("p0"), in: s1)
    s2 = try e2.activate(pointID: pointID("p1"), in: s2)
    XCTAssertEqual(s1.progress?.activePointID, pointID("p0"))
    XCTAssertEqual(s2.progress?.activePointID, pointID("p1"))
    XCTAssertNotEqual(s1.progress, s2.progress)
  }

  func testReturnToPreviousEligiblePointByIdentity() throws {
    var session = try initialized()
    session = try engine.activate(pointID: pointID("p0"), in: session)
    session = try engine.advanceToNextEligiblePoint(in: session)
    XCTAssertEqual(session.progress?.activePointID, pointID("p1"))
    session = try engine.returnToPreviousEligiblePoint(in: session)
    XCTAssertEqual(session.progress?.activePointID, pointID("p0"))
    XCTAssertEqual(session.progress?.orderedPoints[0].status, .inProgress)
    XCTAssertThrowsError(try engine.returnToPreviousEligiblePoint(in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .noEligiblePoint)
    }
  }

  func testCompleteFromNotStartedRejected() throws {
    var session = try initialized()
    // Force active identity without going through activate status path.
    session.progress?.activePointID = pointID("p0")
    XCTAssertThrowsError(try engine.completeActivePoint(in: session)) { err in
      guard case InspectionProgressionError.invalidTransition = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testEnvelopeAndFileStoreRoundTripPreservesProgressFacts() async throws {
    var session = try initialized()
    session = try engine.activate(pointID: pointID("p0"), in: session)
    session = try engine.completeActivePoint(in: session)
    session = try engine.activate(pointID: pointID("p1"), in: session)
    session = try engine.skipActivePoint(reason: "blocked view", in: session)

    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(
      session: session,
      savedAt: fixedInstant
    )
    XCTAssertEqual(envelope.schemaVersion, .v1)
    let decoded = try InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(
      from: InspectionSessionEnvelopeCoder.encode(envelope)
    )
    XCTAssertEqual(decoded.session.progress?.orderedPoints[0].status, .completed)
    guard case .skipped(let reason) = decoded.session.progress?.orderedPoints[1].status else {
      return XCTFail("expected skipped")
    }
    XCTAssertEqual(reason, "blocked view")
    XCTAssertEqual(decoded.session.progress?.activePointID, pointID("p1"))

    let dir = FileManager.default.temporaryDirectory
      .appendingPathComponent("sess-21c-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: dir) }
    let store = FileInspectionSessionStore(directoryURL: dir)
    try await store.save(session, savedAt: fixedInstant)
    let loaded = try await store.load(id: session.id)
    XCTAssertEqual(loaded.progress?.activePointID, session.progress?.activePointID)
    XCTAssertEqual(loaded.progress?.orderedPoints, session.progress?.orderedPoints)
  }

  func testDecodeToleratesEarlierTipFieldNames() throws {
    let tipJSON = """
      {
        "pointsProgress": [
          {"pointID":"p0","status":{"type":"completed"}},
          {"pointID":"p1","status":{"type":"inProgress"}},
          {"pointID":"p2","status":{"type":"notStarted"}}
        ],
        "currentPointIndex": 1
      }
      """
    let decoded = try JSONDecoder().decode(
      InspectionProgressState.self,
      from: Data(tipJSON.utf8)
    )
    XCTAssertEqual(decoded.activePointID, pointID("p1"))
    XCTAssertEqual(decoded.orderedPoints[0].status, .completed)
    XCTAssertEqual(decoded.orderedPoints.map(\.pointID.rawValue), ["p0", "p1", "p2"])
  }

  func testAssigningLeavesProgressNilUntilInitialize() throws {
    let session = try makeSession()
    XCTAssertNil(session.progress)
    XCTAssertThrowsError(try engine.activate(pointID: pointID("p0"), in: session)) { err in
      XCTAssertEqual(err as? InspectionProgressionError, .progressNotInitialized)
    }
  }
}
