import XCTest
@testable import ElektronCapture

/// Sprint 2.1B — session envelope, integrity, file store, migration foundation.
final class Sprint2_1BTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_100_000)

  private func makeVehicle(_ raw: String = "FLEET-21B") throws -> InspectionVehicle {
    try InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: raw))
  }

  private func makeAssignedSession(id: String = "INS-21B-A") throws -> InspectionSession {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let snapshot = try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
    return try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: makeVehicle(),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )
  }

  private func makeLegacySession(id: String = "INS-21B-LEGACY") throws -> InspectionSession {
    try InspectionSession(
      id: SessionID.unchecked(id),
      vehicle: makeVehicle("LEGACY-21B"),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planState: .legacyUnassigned
    )
  }

  private func tempDir() -> URL {
    FileManager.default.temporaryDirectory
      .appendingPathComponent("sess-21b-\(UUID().uuidString)", isDirectory: true)
  }

  // MARK: - Envelope

  func testCurrentSchemaVersionRoundTrip() throws {
    let session = try makeAssignedSession()
    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(
      session: session,
      savedAt: fixedInstant
    )
    XCTAssertEqual(envelope.schemaVersion, .v1)
    XCTAssertEqual(envelope.schemaVersion, .current)
    let data = try InspectionSessionEnvelopeCoder.encode(envelope)
    let decoded = try InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(from: data)
    XCTAssertEqual(decoded, envelope)
  }

  func testAssignedAndLegacyUnassignedEnvelopeRoundTrip() throws {
    let assigned = try makeAssignedSession()
    let legacy = try makeLegacySession()
    let aEnv = try InspectionSessionEnvelopeCoder.makeEnvelope(session: assigned, savedAt: fixedInstant)
    let lEnv = try InspectionSessionEnvelopeCoder.makeEnvelope(session: legacy, savedAt: fixedInstant)
    XCTAssertTrue(aEnv.session.planState.isAssigned)
    XCTAssertEqual(lEnv.session.planState, .legacyUnassigned)
    XCTAssertEqual(
      try InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(
        from: InspectionSessionEnvelopeCoder.encode(aEnv)
      ).session,
      assigned
    )
    XCTAssertEqual(
      try InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(
        from: InspectionSessionEnvelopeCoder.encode(lEnv)
      ).session.planState,
      .legacyUnassigned
    )
  }

  func testDeterministicCanonicalEncodingAndDigest() throws {
    let session = try makeAssignedSession()
    let d1 = try InspectionSessionEnvelopeCoder.sessionDigest(for: session)
    let d2 = try InspectionSessionEnvelopeCoder.sessionDigest(for: session)
    XCTAssertEqual(d1, d2)
    XCTAssertEqual(d1.count, 64)
    let p1 = try InspectionSessionEnvelopeCoder.canonicalSessionPayload(for: session)
    let p2 = try InspectionSessionEnvelopeCoder.canonicalSessionPayload(for: session)
    XCTAssertEqual(p1, p2)
    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(session: session, savedAt: fixedInstant)
    XCTAssertEqual(envelope.integrity.sessionDigest, d1)
    XCTAssertEqual(envelope.integrity.algorithm, InspectionSessionEnvelopeCoder.integrityAlgorithmID)
  }

  func testTamperedSessionPayloadRejected() throws {
    let session = try makeAssignedSession()
    var envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(session: session, savedAt: fixedInstant)
    var text = try XCTUnwrap(
      String(data: InspectionSessionEnvelopeCoder.encode(envelope), encoding: .utf8)
    )
    // Flip a vehicle identifier character inside the payload without updating digest.
    text = text.replacingOccurrences(of: "FLEET-21B", with: "FLEET-XXX")
    XCTAssertThrowsError(
      try InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(from: Data(text.utf8))
    ) { err in
      guard case InspectionSessionPersistenceError.integrityMismatch = err else {
        return XCTFail("unexpected \(err)")
      }
    }
    // Tampered digest field
    envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(session: session, savedAt: fixedInstant)
    let bad = InspectionSessionEnvelope(
      schemaVersion: envelope.schemaVersion,
      session: envelope.session,
      savedAt: envelope.savedAt,
      integrity: InspectionSessionEnvelopeIntegrity(
        algorithm: envelope.integrity.algorithm,
        sessionDigest: String(repeating: "ab", count: 32)
      )
    )
    XCTAssertThrowsError(try InspectionSessionEnvelopeCoder.verify(bad)) { err in
      guard case InspectionSessionPersistenceError.integrityMismatch = err else {
        return XCTFail("unexpected \(err)")
      }
    }
  }

  func testPlanSnapshotDigestRemainsIndependent() throws {
    let session = try makeAssignedSession()
    let planDigest = try XCTUnwrap(session.definitionDigest)
    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(session: session, savedAt: fixedInstant)
    XCTAssertNotEqual(envelope.integrity.sessionDigest, planDigest)
    try InspectionPlanSnapshotHasher.verify(try XCTUnwrap(session.inspectionPlanSnapshot))
    XCTAssertEqual(session.definitionDigest, planDigest)
  }

  // MARK: - Store

  func testSaveLoadPreservesAssignedSessionAndAssignedAt() async throws {
    let dir = tempDir()
    let store = FileInspectionSessionStore(directoryURL: dir)
    let session = try makeAssignedSession(id: "INS-STORE-1")
    try await store.save(session, savedAt: fixedInstant)
    let loaded = try await store.load(id: session.id)
    XCTAssertEqual(loaded, session)
    XCTAssertEqual(loaded.assignedAt, fixedInstant)
    XCTAssertEqual(loaded.definitionDigest, session.definitionDigest)
    XCTAssertEqual(loaded.inspectionPlanSnapshot, session.inspectionPlanSnapshot)
  }

  func testListIsDeterministicAndDeleteIsSelective() async throws {
    let dir = tempDir()
    let store = FileInspectionSessionStore(directoryURL: dir)
    let a = try makeAssignedSession(id: "INS-B")
    let b = try makeLegacySession(id: "INS-A")
    try await store.save(a, savedAt: fixedInstant)
    try await store.save(b, savedAt: fixedInstant.addingTimeInterval(10))
    let listed = try await store.list()
    XCTAssertEqual(listed.map(\.id.rawValue), ["INS-A", "INS-B"])
    try await store.delete(id: a.id)
    let after = try await store.list()
    XCTAssertEqual(after.map(\.id.rawValue), ["INS-A"])
    do {
      _ = try await store.load(id: a.id)
      XCTFail("expected fileNotFound")
    } catch let e as InspectionSessionPersistenceError {
      guard case .fileNotFound("INS-B") = e else { return XCTFail("\(e)") }
    }
  }

  func testMissingSessionAndMalformedFileErrors() async throws {
    let dir = tempDir()
    let store = FileInspectionSessionStore(directoryURL: dir)
    do {
      _ = try await store.load(id: SessionID.unchecked("INS-MISSING"))
      XCTFail("expected not found")
    } catch let e as InspectionSessionPersistenceError {
      guard case .fileNotFound = e else { return XCTFail("\(e)") }
    }
    let badID = SessionID.unchecked("INS-BAD")
    let url = await store.fileURL(for: badID)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    try Data("not-json".utf8).write(to: url)
    do {
      _ = try await store.load(id: SessionID.unchecked("INS-BAD"))
      XCTFail("expected malformed")
    } catch let e as InspectionSessionPersistenceError {
      guard case .malformedEnvelope = e else { return XCTFail("\(e)") }
    }
  }

  func testStorageDirectoryCreatedAndFilenameDeterministic() async throws {
    let dir = tempDir().appendingPathComponent("nested", isDirectory: true)
    XCTAssertFalse(FileManager.default.fileExists(atPath: dir.path))
    let store = FileInspectionSessionStore(directoryURL: dir)
    let session = try makeLegacySession(id: "INS-PATH-1")
    try await store.save(session, savedAt: fixedInstant)
    XCTAssertTrue(FileManager.default.fileExists(atPath: dir.path))
    let expected = dir.appendingPathComponent("INS-PATH-1.json")
    let actual = await store.fileURL(for: session.id)
    XCTAssertEqual(actual, expected)
    XCTAssertTrue(FileManager.default.fileExists(atPath: expected.path))
  }

  func testNoRegistryLookupOnLoad() async throws {
    let dir = tempDir()
    let store = FileInspectionSessionStore(directoryURL: dir)
    let session = try makeAssignedSession(id: "INS-NO-REG")
    try await store.save(session, savedAt: fixedInstant)
    // Load uses only file bytes — registry not required.
    let loaded = try await store.load(id: session.id)
    XCTAssertEqual(loaded.planID?.rawValue, "quick_4_point")
    XCTAssertEqual(loaded.definitionDigest, session.definitionDigest)
  }

  // MARK: - Atomic behavior

  func testAbandonedTemporaryDoesNotReplaceValidDestination() async throws {
    let dir = tempDir()
    let store = FileInspectionSessionStore(directoryURL: dir)
    let original = try makeAssignedSession(id: "INS-ATOMIC")
    try await store.save(original, savedAt: fixedInstant)

    var mutated = original
    mutated.metrics.captureCount = 99
    // Leave a complete temp for a different payload without replacing.
    try await store.writeAbandonedTemporary(session: mutated, savedAt: fixedInstant.addingTimeInterval(5))

    let loaded = try await store.load(id: original.id)
    XCTAssertEqual(loaded.metrics.captureCount, 0)
    XCTAssertEqual(loaded, original)

    // Successful replace loads the new session.
    try await store.save(mutated, savedAt: fixedInstant.addingTimeInterval(5))
    let after = try await store.load(id: original.id)
    XCTAssertEqual(after.metrics.captureCount, 99)
  }

  // MARK: - Migration / legacy

  func testCurrentVersionBypassesMigration() throws {
    let session = try makeAssignedSession()
    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(session: session, savedAt: fixedInstant)
    let migrator = InspectionSessionMigrator(registry: .empty)
    let out = try migrator.migrateToCurrent(envelope)
    XCTAssertEqual(out, envelope)
  }

  func testLegacyCurrentSessionEnvelopeLoadsAsCurrentWithoutFabricatingPlan() throws {
    let legacySession = try makeLegacySession(id: "INS-LEGACY-ENV")
    let legacyEnvelope = CurrentSessionPersistenceEnvelope(session: legacySession)
    let data = try InspectionSessionEnvelopeCoder.makeJSONEncoder().encode(legacyEnvelope)
    let loaded = try InspectionSessionEnvelopeLoader.load(from: data, savedAt: fixedInstant)
    XCTAssertEqual(loaded.schemaVersion, .current)
    XCTAssertEqual(loaded.session.planState, .legacyUnassigned)
    XCTAssertNil(loaded.session.inspectionPlanSnapshot)
    try InspectionSessionEnvelopeCoder.verify(loaded)
  }

  func testRawPreEnvelopeSessionJSONLoadsLegacyUnassigned() throws {
    let session = try makeLegacySession(id: "INS-RAW")
    let data = try InspectionSessionEnvelopeCoder.makeJSONEncoder().encode(session)
    let loaded = try InspectionSessionEnvelopeLoader.load(from: data, savedAt: fixedInstant)
    XCTAssertEqual(loaded.session.planState, .legacyUnassigned)
    XCTAssertEqual(loaded.session.id, session.id)
  }

  func testMissingMigrationPathThrows() throws {
    let session = try makeLegacySession()
    let digest = try InspectionSessionEnvelopeCoder.sessionDigest(for: session)
    let stale = InspectionSessionEnvelope(
      schemaVersion: InspectionSessionSchemaVersion(rawValue: 0),
      session: session,
      savedAt: fixedInstant,
      integrity: InspectionSessionEnvelopeIntegrity(
        algorithm: InspectionSessionEnvelopeCoder.integrityAlgorithmID,
        sessionDigest: digest
      )
    )
    let migrator = InspectionSessionMigrator(registry: .empty)
    XCTAssertThrowsError(try migrator.migrateToCurrent(stale)) { err in
      guard case InspectionSessionPersistenceError.missingMigrationPath(from: 0, to: 1) = err else {
        return XCTFail("unexpected \(err)")
      }
    }
  }

  func testUnsupportedFutureVersionThrows() throws {
    let session = try makeLegacySession()
    let digest = try InspectionSessionEnvelopeCoder.sessionDigest(for: session)
    let future = InspectionSessionEnvelope(
      schemaVersion: InspectionSessionSchemaVersion(rawValue: 99),
      session: session,
      savedAt: fixedInstant,
      integrity: InspectionSessionEnvelopeIntegrity(
        algorithm: InspectionSessionEnvelopeCoder.integrityAlgorithmID,
        sessionDigest: digest
      )
    )
    XCTAssertThrowsError(try InspectionSessionEnvelopeCoder.verify(future)) { err in
      guard case InspectionSessionPersistenceError.unsupportedSchemaVersion(99) = err else {
        return XCTFail("unexpected \(err)")
      }
    }
    let data = try InspectionSessionEnvelopeCoder.makeJSONEncoder().encode(future)
    XCTAssertThrowsError(try InspectionSessionEnvelopeLoader.load(from: data)) { err in
      guard case InspectionSessionPersistenceError.unsupportedSchemaVersion(99) = err else {
        return XCTFail("unexpected \(err)")
      }
    }
  }

  func testFileCurrentSessionRepositoryReadsLegacyAndWritesEnvelope() async throws {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("current-\(UUID().uuidString).json")
    let legacySession = try makeLegacySession(id: "INS-CUR")
    let legacyData = try InspectionSessionEnvelopeCoder.makeJSONEncoder().encode(
      CurrentSessionPersistenceEnvelope(session: legacySession)
    )
    try legacyData.write(to: url)
    let repo = FileCurrentSessionRepository(fileURL: url)
    let loaded = try await repo.load()
    XCTAssertEqual(loaded?.id, legacySession.id)
    XCTAssertEqual(loaded?.planState, .legacyUnassigned)

    let assigned = try makeAssignedSession(id: "INS-CUR")
    try await repo.save(assigned)
    let disk = try Data(contentsOf: url)
    let envelope = try InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(from: disk)
    XCTAssertEqual(envelope.schemaVersion, .current)
    XCTAssertTrue(envelope.session.planState.isAssigned)
  }
}
