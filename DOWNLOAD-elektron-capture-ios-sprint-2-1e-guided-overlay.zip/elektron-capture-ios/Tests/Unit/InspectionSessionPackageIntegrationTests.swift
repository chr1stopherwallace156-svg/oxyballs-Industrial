import XCTest
@testable import ElektronCapture

final class InspectionSessionPackageIntegrationTests: XCTestCase {
  private var workRoot: URL!
  private var fixtureJPEG: Data!

  override func setUpWithError() throws {
    workRoot = FileManager.default.temporaryDirectory
      .appendingPathComponent("insp-pkg-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: workRoot, withIntermediateDirectories: true)
    fixtureJPEG = Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
      0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0xFF, 0xD9,
    ])
  }

  override func tearDownWithError() throws {
    try? FileManager.default.removeItem(at: workRoot)
  }

  func testPackageIncludesImmutableEvidenceContext() throws {
    let ctx = InspectionSessionEvidenceContext(
      sessionID: "INS-20260725-120000-TEST",
      primaryVehicleIdentifier: "1HGCM82633A004352",
      primaryVehicleIdentifierKind: "UNKNOWN",
      inspectorID: "INSPECTOR-LOCAL",
      sessionStartedAtUTC: "2026-07-25T12:00:00.000Z"
    )
    let ids = Phase1CaptureIdentifiers(
      evidenceId: "EVD-INSP-001",
      sessionId: "SESSION-INSP-001",
      artifactId: "ART-INSP-001",
      recordId: "REC-INSP-001"
    )
    let approved = try PendingStillCapture.freezeFromDelegateBytes(fixtureJPEG).promoteToApproved()
    let coordinator = Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: fixtureJPEG),
      workRoot: workRoot,
      inspectionSessionContext: ctx
    )
    let defaults = UserDefaults(suiteName: "insp.pkg.\(UUID().uuidString)")!
    let result = try coordinator.exportApproved(
      approved,
      ids: ids,
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "18.0",
      defaults: defaults,
      inspectionSessionContext: ctx
    )

    let root = result.packageDirectoryURL
    let sidecar = root.appendingPathComponent("sidecars/inspection_session_context.json")
    XCTAssertTrue(FileManager.default.fileExists(atPath: sidecar.path))
    XCTAssertEqual(try Data(contentsOf: sidecar), try CanonicalJSONEncoder.encode(ctx.asDictionary()))

    let meta = try JSONSerialization.jsonObject(
      with: Data(contentsOf: root.appendingPathComponent("sidecars/avcapture_metadata.json"))
    ) as! [String: Any]
    XCTAssertEqual(meta["inspection_session_id"] as? String, "INS-20260725-120000-TEST")

    let inv = try JSONSerialization.jsonObject(
      with: Data(contentsOf: root.appendingPathComponent("package_inventory.json"))
    ) as! [String: Any]
    let paths = Set((inv["entries"] as! [[String: Any]]).map { $0["path"] as! String })
    XCTAssertTrue(paths.contains("sidecars/inspection_session_context.json"))

    let validation = CaptureSidePackageValidator.validate(packageDirectory: root)
    XCTAssertTrue(validation.ok, "\(validation.reasonCodes)")
  }

  func testBackwardCompatiblePackageWithoutSessionContext() throws {
    let ids = Phase1CaptureIdentifiers(
      evidenceId: "EVD-INSP-LEGACY",
      sessionId: "SESSION-INSP-LEGACY",
      artifactId: "ART-INSP-LEGACY",
      recordId: "REC-INSP-LEGACY"
    )
    let approved = try PendingStillCapture.freezeFromDelegateBytes(fixtureJPEG).promoteToApproved()
    let coordinator = Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: fixtureJPEG),
      workRoot: workRoot
    )
    let defaults = UserDefaults(suiteName: "insp.pkg.legacy.\(UUID().uuidString)")!
    let result = try coordinator.exportApproved(
      approved,
      ids: ids,
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "fixture",
      defaults: defaults
    )
    let missing = result.packageDirectoryURL
      .appendingPathComponent("sidecars/inspection_session_context.json").path
    XCTAssertFalse(FileManager.default.fileExists(atPath: missing))
    let meta = try JSONSerialization.jsonObject(
      with: Data(contentsOf: result.packageDirectoryURL.appendingPathComponent("sidecars/avcapture_metadata.json"))
    ) as! [String: Any]
    XCTAssertTrue(meta["inspection_session_id"] is NSNull)
    let validation = CaptureSidePackageValidator.validate(packageDirectory: result.packageDirectoryURL)
    XCTAssertTrue(validation.ok, "\(validation.reasonCodes)")
  }

  func testFailedPackageDoesNotRequireCaptureIncrement() async throws {
    // Service metering is separate from package builder; ensure a failed export path
    // leaves captureCount unchanged when recordSuccessfulCapture is not called.
    let repo = InMemoryCurrentSessionRepository()
    let service = InspectionSessionService(
      repository: repo,
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("INS-FAIL-METER")),
      instantProvider: FixedInstantProvider(Date(timeIntervalSince1970: 1_720_000_000))
    )
    _ = try await service.startInspection(vehicleIdentifierRaw: "X")
    XCTAssertEqual(service.currentSession?.metrics.captureCount, 0)
    // Simulate failed package: do not call recordSuccessfulCapture.
    XCTAssertEqual(service.currentSession?.metrics.captureCount, 0)
  }
}
