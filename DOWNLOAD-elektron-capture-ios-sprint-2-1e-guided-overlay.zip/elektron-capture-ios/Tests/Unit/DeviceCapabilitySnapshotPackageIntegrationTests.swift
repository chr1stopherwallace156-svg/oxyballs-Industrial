import XCTest
@testable import ElektronCapture

final class DeviceCapabilitySnapshotPackageIntegrationTests: XCTestCase {
  private var workRoot: URL!
  private var fixtureJPEG: Data!

  override func setUpWithError() throws {
    workRoot = FileManager.default.temporaryDirectory
      .appendingPathComponent("cap-snap-pkg-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: workRoot, withIntermediateDirectories: true)
    fixtureJPEG = Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01,
      0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0xFF, 0xD9,
    ])
  }

  override func tearDownWithError() throws {
    try? FileManager.default.removeItem(at: workRoot)
  }

  func testPackageIncludesSnapshotSidecarInventoryAndMetadataLink() throws {
    let snapshot = DeviceCapabilitySnapshot(
      snapshotID: "CAPSNAP-PKG-001",
      capturedAtUTC: "2026-07-25T12:34:56.789Z",
      deviceModel: "iPhone17,1",
      operatingSystemVersion: "18.0",
      availableCameras: [
        CameraCapability(
          cameraID: "rear-wide",
          position: "back",
          deviceType: "AVCaptureDeviceTypeBuiltInWideAngleCamera",
          supportsFocusLock: true,
          supportsExposureLock: true,
          supportsDepthData: false
        )
      ],
      motion: .supported,
      depth: .unsupported,
      lidar: .unsupported
    )

    let ids = Phase1CaptureIdentifiers(
      evidenceId: "EVD-CAPSNAP-001",
      sessionId: "SESSION-CAPSNAP-001",
      artifactId: "ART-CAPSNAP-001",
      recordId: "REC-CAPSNAP-001"
    )
    let approved = try PendingStillCapture.freezeFromDelegateBytes(fixtureJPEG).promoteToApproved()
    let coordinator = Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: fixtureJPEG),
      workRoot: workRoot,
      deviceCapabilitySnapshot: snapshot
    )
    let defaults = UserDefaults(suiteName: "cap.snap.\(UUID().uuidString)")!
    let result = try coordinator.exportApproved(
      approved,
      ids: ids,
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "18.0",
      defaults: defaults,
      deviceCapabilitySnapshot: snapshot
    )

    let root = result.packageDirectoryURL
    let snapURL = root.appendingPathComponent("sidecars/device_capability_snapshot.json")
    XCTAssertTrue(FileManager.default.fileExists(atPath: snapURL.path))

    let snapBytes = try Data(contentsOf: snapURL)
    let expectedBytes = try CanonicalJSONEncoder.encode(
      snapshot.asDictionary(),
      stage: "expected_snapshot"
    )
    XCTAssertEqual(snapBytes, expectedBytes)

    let snapObj = try JSONSerialization.jsonObject(with: snapBytes) as! [String: Any]
    XCTAssertEqual(snapObj["snapshot_id"] as? String, "CAPSNAP-PKG-001")
    XCTAssertEqual(snapObj["motion"] as? String, "SUPPORTED")

    let meta = try JSONSerialization.jsonObject(
      with: Data(contentsOf: root.appendingPathComponent("sidecars/avcapture_metadata.json"))
    ) as! [String: Any]
    XCTAssertEqual(meta["device_capability_snapshot_id"] as? String, "CAPSNAP-PKG-001")

    let inv = try JSONSerialization.jsonObject(
      with: Data(contentsOf: root.appendingPathComponent("package_inventory.json"))
    ) as! [String: Any]
    let paths = Set((inv["entries"] as! [[String: Any]]).map { $0["path"] as! String })
    XCTAssertTrue(paths.contains("sidecars/device_capability_snapshot.json"))

    let manifest = try JSONSerialization.jsonObject(
      with: Data(contentsOf: root.appendingPathComponent("manifest.json"))
    ) as! [String: Any]
    let notes = manifest["notes"] as! [String]
    XCTAssertTrue(notes.contains(where: { $0.contains("device_capability_snapshot_id=CAPSNAP-PKG-001") }))

    let validation = CaptureSidePackageValidator.validate(packageDirectory: root)
    XCTAssertTrue(validation.ok, "reasonCodes=\(validation.reasonCodes)")
  }

  func testExistingPathWithoutSnapshotStillValidates() throws {
    let ids = Phase1CaptureIdentifiers(
      evidenceId: "EVD-CAPSNAP-LEGACY",
      sessionId: "SESSION-CAPSNAP-LEGACY",
      artifactId: "ART-CAPSNAP-LEGACY",
      recordId: "REC-CAPSNAP-LEGACY"
    )
    let approved = try PendingStillCapture.freezeFromDelegateBytes(fixtureJPEG).promoteToApproved()
    let coordinator = Phase1CaptureCoordinator(
      appVersion: "0.1.4",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: fixtureJPEG),
      workRoot: workRoot
    )
    let defaults = UserDefaults(suiteName: "cap.snap.legacy.\(UUID().uuidString)")!
    let result = try coordinator.exportApproved(
      approved,
      ids: ids,
      hardwareModelOverride: "iPhone17,1",
      iosVersionOverride: "fixture",
      defaults: defaults
    )
    let snapPath = result.packageDirectoryURL
      .appendingPathComponent("sidecars/device_capability_snapshot.json").path
    XCTAssertFalse(FileManager.default.fileExists(atPath: snapPath))

    let meta = try JSONSerialization.jsonObject(
      with: Data(contentsOf: result.packageDirectoryURL.appendingPathComponent("sidecars/avcapture_metadata.json"))
    ) as! [String: Any]
    XCTAssertTrue(meta["device_capability_snapshot_id"] is NSNull)

    let validation = CaptureSidePackageValidator.validate(packageDirectory: result.packageDirectoryURL)
    XCTAssertTrue(validation.ok, "reasonCodes=\(validation.reasonCodes)")
  }
}
