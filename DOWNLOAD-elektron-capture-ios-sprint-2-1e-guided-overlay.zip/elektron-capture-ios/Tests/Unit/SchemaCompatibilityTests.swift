import Foundation
import XCTest
@testable import ElektronCapture

/// File-based schema longevity suite.
///
/// Authoritative on-disk fixtures: `Tests/Fixtures/SchemaCompatibility/`
/// (mirrored into `Tests/Unit/Fixtures/SchemaCompatibility/` for SPM `Bundle.module`).
final class SchemaCompatibilityTests: XCTestCase {
  private var baseRoot: URL!
  private var libraryRoot: URL!
  private let hasher = ArtifactHashingService()

  override func setUpWithError() throws {
    baseRoot = FileManager.default.temporaryDirectory
      .appendingPathComponent("SchemaCompat-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: baseRoot, withIntermediateDirectories: true)
    libraryRoot = try EvidenceLibraryPaths.root(under: baseRoot)
  }

  override func tearDown() {
    try? FileManager.default.removeItem(at: baseRoot)
    super.tearDown()
  }

  private var fixturesRoot: URL {
    if let url = Bundle.module.url(forResource: "SchemaCompatibility", withExtension: nil, subdirectory: "Fixtures") {
      return url
    }
    return Bundle.module.resourceURL!.appendingPathComponent("Fixtures/SchemaCompatibility", isDirectory: true)
  }

  private func copyVersionIntoLibrary(_ version: String) throws {
    let srcCaptures = fixturesRoot.appendingPathComponent("\(version)/captures", isDirectory: true)
    let dstCaptures = EvidenceLibraryPaths(libraryRoot: libraryRoot).capturesRoot
    let fm = FileManager.default
    let names = try fm.contentsOfDirectory(atPath: srcCaptures.path)
    for name in names {
      let src = srcCaptures.appendingPathComponent(name, isDirectory: true)
      let dst = dstCaptures.appendingPathComponent(name, isDirectory: true)
      if fm.fileExists(atPath: dst.path) { try fm.removeItem(at: dst) }
      try fm.copyItem(at: src, to: dst)
    }
  }

  private func fileSHA256(at url: URL) throws -> String {
    try hasher.sha256HexOfFile(at: url)
  }

  private func assertFixtureArtifactsUnchanged(version: String, under libraryCaptures: URL) throws {
    let manifestURL = fixturesRoot.appendingPathComponent("FIXTURE_SHA256.json")
    let data = try Data(contentsOf: manifestURL)
    let obj = try JSONSerialization.jsonObject(with: data) as! [String: Any]
    let versions = obj["versions"] as! [String: [String: String]]
    let expected = versions[version]!
    for (rel, expectedSHA) in expected where rel.hasSuffix("artifact_original.jpg") {
      // rel like "v1.0.0/captures/EVD-…/artifact_original.jpg"
      let parts = rel.split(separator: "/").map(String.init)
      guard parts.count >= 4 else { continue }
      let evidenceID = parts[2]
      let url = libraryCaptures.appendingPathComponent(evidenceID)
        .appendingPathComponent("artifact_original.jpg")
      XCTAssertEqual(try fileSHA256(at: url), expectedSHA, "mutated \(rel)")
    }
  }

  private func snapshotTreeHashes(at root: URL) throws -> [String: String] {
    var out: [String: String] = [:]
    let fm = FileManager.default
    guard let en = fm.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey]) else {
      return out
    }
    for case let url as URL in en {
      let vals = try url.resourceValues(forKeys: [.isRegularFileKey])
      guard vals.isRegularFile == true else { continue }
      let rel = url.path.replacingOccurrences(of: root.path + "/", with: "")
      out[rel] = try fileSHA256(at: url)
    }
    return out
  }

  func testV100RecordsDecodeWithoutCrashing() async throws {
    try copyVersionIntoLibrary("v1.0.0")
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let doc = try await store.rebuildIndexFromDisk()
    XCTAssertGreaterThanOrEqual(doc.records.count, 2)
    XCTAssertNotNil(doc.records.first { $0.id == "EVD-SCHEMA-100" }?.inspectionSessionID)
    XCTAssertNil(doc.records.first { $0.id == "EVD-SCHEMA-LEGACY" }?.inspectionSessionID)
  }

  func testV110RecordsDecodeWithoutCrashing() async throws {
    try copyVersionIntoLibrary("v1.1.0")
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let doc = try await store.rebuildIndexFromDisk()
    XCTAssertNotNil(doc.records.first { $0.id == "EVD-SCHEMA-110" })
    XCTAssertEqual(
      doc.records.first { $0.id == "EVD-SCHEMA-110" }?.inspectionVehicleIdentifierKind,
      VehicleIdentifierKind.vinHeuristic.rawValue
    )
  }

  func testV120RecordsDecodeWithoutCrashingAndIgnoreAdditiveFields() async throws {
    try copyVersionIntoLibrary("v1.2.0")
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let doc = try await store.rebuildIndexFromDisk()
    XCTAssertEqual(doc.records.filter { $0.inspectionSessionID == "INSP-COMPAT" }.count, 2)
    // future_additive_field in library_status must not prevent rebuild
    XCTAssertNotNil(doc.records.first { $0.id == "EVD-SCHEMA-120" })
  }

  func testLegacyWithoutSessionRemainsUnassigned() async throws {
    try copyVersionIntoLibrary("v1.0.0")
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    _ = try await store.rebuildIndexFromDisk()
    let catalog = try await store.listInspectionCatalog()
    XCTAssertTrue(catalog.unassigned.contains { $0.id == "EVD-SCHEMA-LEGACY" })
    XCTAssertFalse(catalog.groups.contains { g in g.captures.contains { $0.id == "EVD-SCHEMA-LEGACY" } })
  }

  func testGroupingStrictlyByInspectionSessionID() async throws {
    try copyVersionIntoLibrary("v1.0.0")
    try copyVersionIntoLibrary("v1.1.0")
    try copyVersionIntoLibrary("v1.2.0")
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    _ = try await store.rebuildIndexFromDisk()
    let catalog = try await store.listInspectionCatalog()
    let compat = catalog.groups.first { $0.sessionID == "INSP-COMPAT" }
    // v1.0 EVD-SCHEMA-100 + v1.1 EVD-SCHEMA-110 + v1.2 EVD-SCHEMA-120 + EVD-SCHEMA-120B
    XCTAssertEqual(compat?.captureCount, 4)
    XCTAssertEqual(
      Set(compat?.captures.map(\.id) ?? []),
      Set(["EVD-SCHEMA-100", "EVD-SCHEMA-110", "EVD-SCHEMA-120", "EVD-SCHEMA-120B"])
    )
    XCTAssertEqual(
      Set(catalog.groups.map(\.sessionID)),
      Set(["INSP-COMPAT", "INSP-VIN-DAY1", "INSP-VIN-DAY2"])
    )
  }

  func testSameVINDifferentSessionsRemainSeparate() async throws {
    try copyVersionIntoLibrary("v1.0.0")
    try copyVersionIntoLibrary("v1.1.0")
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    _ = try await store.rebuildIndexFromDisk()
    let catalog = try await store.listInspectionCatalog()
    let day1 = catalog.groups.first { $0.sessionID == "INSP-VIN-DAY1" }
    let day2 = catalog.groups.first { $0.sessionID == "INSP-VIN-DAY2" }
    XCTAssertNotNil(day1)
    XCTAssertNotNil(day2)
    XCTAssertEqual(day1?.vehicleIdentifier, day2?.vehicleIdentifier)
    XCTAssertNotEqual(day1?.sessionID, day2?.sessionID)
  }

  func testReconciliationUpgradesDerivedIndexWithoutMutatingCanonicalBytes() async throws {
    try copyVersionIntoLibrary("v1.0.0")
    let paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    let before = try snapshotTreeHashes(at: paths.capturesRoot)

    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let first = try await store.rebuildIndexFromDisk()
    XCTAssertEqual(first.schemaVersion, "1.2.0")

    let mid = try snapshotTreeHashes(at: paths.capturesRoot)
    XCTAssertEqual(mid, before, "rebuild must not mutate captures/sidecars/status")

    _ = try await store.reconcileOnLaunch()
    let second = try await store.rebuildIndexFromDisk()
    let after = try snapshotTreeHashes(at: paths.capturesRoot)
    XCTAssertEqual(after, before)
    XCTAssertEqual(second.records.map(\.originalSha256).sorted(), first.records.map(\.originalSha256).sorted())
    try assertFixtureArtifactsUnchanged(version: "v1.0.0", under: paths.capturesRoot)
  }

  func testRepeatedReconciliationIsIdempotentForDerivedIndex() async throws {
    try copyVersionIntoLibrary("v1.2.0")
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let a = try await store.rebuildIndexFromDisk()
    let b = try await store.rebuildIndexFromDisk()
    let enc = JSONEncoder()
    enc.outputFormatting = [.sortedKeys]
    enc.dateEncodingStrategy = .iso8601
    // Compare durable record identity fields (not updatedAt on the document wrapper).
    let aKeys = a.records.map { "\($0.id)|\($0.originalSha256)|\($0.inspectionSessionID ?? "")" }.sorted()
    let bKeys = b.records.map { "\($0.id)|\($0.originalSha256)|\($0.inspectionSessionID ?? "")" }.sorted()
    XCTAssertEqual(aKeys, bKeys)
  }

  func testUnsupportedFutureMajorVersionFailsExplicitly() throws {
    let url = fixturesRoot.appendingPathComponent("unsupported-v9.0.0/index.json")
    XCTAssertThrowsError(try EvidenceLibraryStore.assertIndexFileSchemaCompatible(at: url)) { err in
      guard let e = err as? EvidenceLibraryError else {
        return XCTFail("expected EvidenceLibraryError, got \(err)")
      }
      if case .unsupportedSchemaVersion(let v) = e {
        XCTAssertEqual(v, "9.0.0")
      } else {
        XCTFail("expected unsupportedSchemaVersion, got \(e)")
      }
    }
    XCTAssertThrowsError(try EvidenceLibraryIndexDocument.validateCompatibleSchemaVersion("9.0.0"))
    // Supported 1.x still passes.
    XCTAssertNoThrow(try EvidenceLibraryIndexDocument.validateCompatibleSchemaVersion("1.2.0"))
  }

  func testLegacyUnknownIdentifierKindStillDecodes() throws {
    let unknown = try VehicleIdentifier(rawValue: "FLEET-1", kind: .unknown)
    XCTAssertEqual(unknown.kind, .unknown)
    XCTAssertEqual(unknown.kind.displayLabel, "Unknown")

    // Historical "VIN" raw value still decodes.
    XCTAssertEqual(VehicleIdentifierKind(rawValue: "VIN"), .vin)
    XCTAssertEqual(VehicleIdentifierKind.vin.displayLabel, "VIN (validated)")
    XCTAssertEqual(VehicleIdentifierKind.vinValidated.displayLabel, "VIN (validated)")
    XCTAssertEqual(VehicleIdentifierKind.vinHeuristic.displayLabel, "VIN (heuristic)")
    XCTAssertEqual(VehicleIdentifierKind.rawIdentifier.displayLabel, "Vehicle identifier")
  }
}
