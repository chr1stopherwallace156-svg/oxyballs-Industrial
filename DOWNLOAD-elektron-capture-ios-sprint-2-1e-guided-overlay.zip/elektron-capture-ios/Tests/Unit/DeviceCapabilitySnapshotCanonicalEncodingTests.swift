import XCTest
@testable import ElektronCapture

final class DeviceCapabilitySnapshotCanonicalEncodingTests: XCTestCase {
  func testCanonicalEncodingIsDeterministicAndSorted() throws {
    let snapshot = DeviceCapabilitySnapshot(
      snapshotID: "CAPSNAP-FIXED-001",
      capturedAtUTC: "2026-07-25T12:00:00.000Z",
      deviceModel: "iPhone17,1",
      operatingSystemVersion: "18.0",
      availableCameras: [
        CameraCapability(
          cameraID: "cam-b",
          position: "back",
          deviceType: "AVCaptureDeviceTypeBuiltInWideAngleCamera",
          supportsFocusLock: true,
          supportsExposureLock: true,
          supportsDepthData: false
        ),
        CameraCapability(
          cameraID: "cam-a",
          position: "back",
          deviceType: "AVCaptureDeviceTypeBuiltInUltraWideCamera",
          supportsFocusLock: true,
          supportsExposureLock: false,
          supportsDepthData: true
        ),
      ],
      motion: .supported,
      depth: .supported,
      lidar: .unsupported
    )

    let bytes1 = try CanonicalJSONEncoder.encode(snapshot.asDictionary(), stage: "capability_test")
    let bytes2 = try CanonicalJSONEncoder.encode(snapshot.asDictionary(), stage: "capability_test")
    XCTAssertEqual(bytes1, bytes2)

    let text = String(data: bytes1, encoding: .utf8)!
    // Sorted keys: available_cameras before captured_at_utc, etc.
    XCTAssertTrue(text.contains("\"schema_id\":\"DeviceCapabilitySnapshot\""))
    XCTAssertTrue(text.contains("\"snapshot_id\":\"CAPSNAP-FIXED-001\""))
    XCTAssertTrue(text.contains("\"motion\":\"SUPPORTED\""))
    XCTAssertTrue(text.contains("\"depth\":\"SUPPORTED\""))
    XCTAssertTrue(text.contains("\"lidar\":\"UNSUPPORTED\""))
    // Camera array preserves asDictionary order (input order).
    let firstCam = text.range(of: "\"camera_id\":\"cam-b\"")!
    let secondCam = text.range(of: "\"camera_id\":\"cam-a\"")!
    XCTAssertLessThan(firstCam.lowerBound, secondCam.lowerBound)
  }

  func testCodableRoundTripPreservesFields() throws {
    let snapshot = DeviceCapabilitySnapshot(
      snapshotID: "CAPSNAP-RT-1",
      capturedAtUTC: "2026-07-25T01:02:03.456Z",
      deviceModel: "iPhone15,2",
      operatingSystemVersion: "17.5",
      availableCameras: [
        CameraCapability(
          cameraID: "uid-1",
          position: "back",
          deviceType: "wide",
          supportsFocusLock: false,
          supportsExposureLock: true,
          supportsDepthData: false
        )
      ],
      motion: .unknown,
      depth: .permissionDenied,
      lidar: .unavailable
    )
    let data = try JSONEncoder().encode(snapshot)
    let decoded = try JSONDecoder().decode(DeviceCapabilitySnapshot.self, from: data)
    XCTAssertEqual(decoded, snapshot)
  }
}
