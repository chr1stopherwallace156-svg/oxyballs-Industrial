import XCTest
@testable import ElektronCapture

/// Platform-neutral fallback semantics for macOS / non-iPhone hosts.
///
/// These tests do not claim iPhone camera, depth, LiDAR, or CoreMotion runtime
/// validation. They verify mapping and fallback contracts only.
final class PlatformCapabilityFallbackTests: XCTestCase {
  func testMacHostDiscoveryReturnsNoIPhoneCapabilityNodes() {
    let discovery = MacHostCameraCapabilityDiscovery()
    XCTAssertTrue(discovery.discoverCameras().isEmpty)
  }

  func testAuthorizedEmptyDiscoveryDoesNotClaimDepthOrLidar() async {
    let service = AppleDeviceCapabilitySnapshotService(
      authorization: FixedAuthState(state: .authorized),
      discovery: MacHostCameraCapabilityDiscovery(),
      motion: FixedMotionState(state: .unsupported),
      identity: FixedHostIdentity(),
      snapshotIDGenerator: { "CAPSNAP-MAC-FALLBACK" }
    )
    let snap = await service.captureSnapshot()
    XCTAssertTrue(snap.availableCameras.isEmpty)
    XCTAssertEqual(snap.depth, .unsupported)
    XCTAssertEqual(snap.lidar, .unsupported)
    XCTAssertEqual(snap.motion, .unsupported)
  }

  func testSystemMotionCheckerDoesNotCrashOnHostWithoutCMMotionManager() {
    // On Linux CI / macOS hosts this must return a safe explicit state without
    // referencing CMMotionManager when unavailable.
    let state = SystemMotionCapabilityChecker().motionCapabilityState()
    #if os(iOS) || targetEnvironment(macCatalyst)
    XCTAssertTrue(
      state == .supported || state == .unsupported,
      "iOS/Catalyst motion probe must resolve supported or unsupported"
    )
    #else
    XCTAssertEqual(state, .unsupported)
    #endif
  }

  func testDefaultDiscoveryOnNonIOSHostDoesNotEnumeratePhoneCameras() {
    #if os(iOS) || targetEnvironment(macCatalyst)
    // On device/simulator this may enumerate hardware; do not assert emptiness.
    _ = DefaultCameraDeviceDiscovery().discoverCameras()
    #else
    XCTAssertTrue(DefaultCameraDeviceDiscovery().discoverCameras().isEmpty)
    #endif
  }
}

private struct FixedAuthState: CameraAuthorizationStatusProviding {
  var state: CameraAuthorizationState
  func videoAuthorizationState() -> CameraAuthorizationState { state }
}

private struct FixedMotionState: MotionCapabilityChecking {
  var state: CapabilityState
  func motionCapabilityState() -> CapabilityState { state }
}

private struct FixedHostIdentity: DeviceIdentityProviding {
  func deviceModel() -> String { "HostFallbackDevice" }
  func operatingSystemVersion() -> String { "host-os" }
}
