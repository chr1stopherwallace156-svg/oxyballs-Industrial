import Foundation
import XCTest
@testable import ElektronCapture

final class InspectionEvidenceGroupingTests: XCTestCase {
  private var baseRoot: URL!
  private var libraryRoot: URL!

  override func setUp() {
    super.setUp()
    baseRoot = FileManager.default.temporaryDirectory
      .appendingPathComponent("InspectionGrouping-\(UUID().uuidString)", isDirectory: true)
    try? FileManager.default.createDirectory(at: baseRoot, withIntermediateDirectories: true)
    libraryRoot = try! EvidenceLibraryPaths.root(under: baseRoot)
  }

  override func tearDown() {
    try? FileManager.default.removeItem(at: baseRoot)
    super.tearDown()
  }

  private var fixtureJPEG: Data {
    Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
      0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14,
      0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7F, 0xFF, 0xD9,
    ])
  }

  private func ids(_ suffix: String) -> Phase1CaptureIdentifiers {
    Phase1CaptureIdentifiers(
      evidenceId: "EVD-\(suffix)",
      sessionId: "SESSION-\(suffix)",
      artifactId: "ART-\(suffix)",
      recordId: "REC-\(suffix)"
    )
  }

  private func context(
    sessionID: String,
    vehicle: String,
    kind: String = VehicleIdentifierKind.unknown.rawValue,
    status: String = SessionStatus.inProgress.rawValue
  ) -> InspectionSessionEvidenceContext {
    InspectionSessionEvidenceContext(
      sessionID: sessionID,
      primaryVehicleIdentifier: vehicle,
      primaryVehicleIdentifierKind: kind,
      inspectorID: "INSPECTOR-LOCAL",
      inspectorName: "Local Inspector",
      sessionStartedAtUTC: "2026-07-25T12:00:00Z",
      sessionStatusAtCapture: status
    )
  }

  private func storeCapture(
    store: EvidenceLibraryStore,
    suffix: String,
    context: InspectionSessionEvidenceContext?,
    at date: Date
  ) async throws -> EvidenceLibraryIndexRecord {
    let jpeg = fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    return try await store.storeApproved(
      jpegBytes: jpeg,
      sha256: sha,
      ids: ids(suffix),
      captureTimestamp: date,
      inspectionContext: context
    )
  }

  func testThreeCapturesSameInspectionSessionBecomeOneGroup() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let ctx = context(sessionID: "INSP-A", vehicle: "VIN-111")
    let t0 = Date(timeIntervalSince1970: 1_700_000_000)
    _ = try await storeCapture(store: store, suffix: "A1", context: ctx, at: t0)
    _ = try await storeCapture(store: store, suffix: "A2", context: ctx, at: t0.addingTimeInterval(10))
    _ = try await storeCapture(store: store, suffix: "A3", context: ctx, at: t0.addingTimeInterval(20))

    let catalog = try await store.listInspectionCatalog()
    XCTAssertEqual(catalog.groups.count, 1)
    XCTAssertEqual(catalog.groups[0].sessionID, "INSP-A")
    XCTAssertEqual(catalog.groups[0].captureCount, 3)
    XCTAssertEqual(catalog.unassigned.count, 0)
  }

  func testSameVINDifferentSessionIDsRemainTwoGroups() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let vin = "VIN-SAME"
    let t0 = Date(timeIntervalSince1970: 1_700_000_100)
    _ = try await storeCapture(
      store: store, suffix: "B1", context: context(sessionID: "INSP-DAY1", vehicle: vin), at: t0
    )
    _ = try await storeCapture(
      store: store, suffix: "B2", context: context(sessionID: "INSP-DAY2", vehicle: vin), at: t0.addingTimeInterval(5)
    )

    let catalog = try await store.listInspectionCatalog()
    XCTAssertEqual(catalog.groups.count, 2)
    XCTAssertEqual(Set(catalog.groups.map(\.sessionID)), Set(["INSP-DAY1", "INSP-DAY2"]))
    XCTAssertTrue(catalog.groups.allSatisfy { $0.vehicleIdentifier == vin })
  }

  func testDifferentVINsDoNotGroupByTimestampProximity() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let t0 = Date(timeIntervalSince1970: 1_700_000_200)
    _ = try await storeCapture(
      store: store, suffix: "C1", context: context(sessionID: "INSP-V1", vehicle: "VIN-AAA"), at: t0
    )
    _ = try await storeCapture(
      store: store, suffix: "C2", context: context(sessionID: "INSP-V2", vehicle: "VIN-BBB"), at: t0.addingTimeInterval(1)
    )

    let catalog = try await store.listInspectionCatalog()
    XCTAssertEqual(catalog.groups.count, 2)
    XCTAssertEqual(Set(catalog.groups.map(\.vehicleIdentifier)), Set(["VIN-AAA", "VIN-BBB"]))
  }

  func testRefreshReloadReconstructsSameGroups() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let ctx = context(sessionID: "INSP-RELOAD", vehicle: "VIN-R")
    let t0 = Date(timeIntervalSince1970: 1_700_000_300)
    _ = try await storeCapture(store: store, suffix: "R1", context: ctx, at: t0)
    _ = try await storeCapture(store: store, suffix: "R2", context: ctx, at: t0.addingTimeInterval(2))
    _ = try await storeCapture(store: store, suffix: "LEGACY", context: nil, at: t0.addingTimeInterval(3))

    let first = try await store.listInspectionCatalog()
    _ = try await store.rebuildIndexFromDisk()
    let second = try await store.listInspectionCatalog()

    XCTAssertEqual(first.groups.map(\.sessionID), second.groups.map(\.sessionID))
    XCTAssertEqual(first.groups.map(\.captureCount), second.groups.map(\.captureCount))
    XCTAssertEqual(first.groups.map { $0.captures.map(\.id) }, second.groups.map { $0.captures.map(\.id) })
    XCTAssertEqual(first.unassigned.map(\.id), second.unassigned.map(\.id))
  }

  func testLegacyRecordsWithoutSessionRemainUnassigned() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let t0 = Date(timeIntervalSince1970: 1_700_000_400)
    _ = try await storeCapture(store: store, suffix: "L1", context: nil, at: t0)
    _ = try await storeCapture(
      store: store, suffix: "L2", context: context(sessionID: "INSP-L", vehicle: "VIN-L"), at: t0.addingTimeInterval(1)
    )

    let catalog = try await store.listInspectionCatalog()
    XCTAssertEqual(catalog.groups.count, 1)
    XCTAssertEqual(catalog.unassigned.count, 1)
    XCTAssertEqual(catalog.unassigned[0].id, "EVD-L1")
    XCTAssertNil(catalog.unassigned[0].inspectionSessionID)
  }

  func testCaptureOrderingIsDeterministic() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let ctx = context(sessionID: "INSP-ORD", vehicle: "VIN-O")
    let t0 = Date(timeIntervalSince1970: 1_700_000_500)
    // Insert out of order by id but with timestamps that force chronological order.
    _ = try await storeCapture(store: store, suffix: "Z-LATE", context: ctx, at: t0.addingTimeInterval(30))
    _ = try await storeCapture(store: store, suffix: "A-EARLY", context: ctx, at: t0)
    _ = try await storeCapture(store: store, suffix: "M-MID", context: ctx, at: t0.addingTimeInterval(10))

    let catalog = try await store.listInspectionCatalog()
    XCTAssertEqual(catalog.groups[0].captures.map(\.id), ["EVD-A-EARLY", "EVD-M-MID", "EVD-Z-LATE"])
  }

  func testFailedCaptureDoesNotIncrementSessionMetrics() async throws {
    let repo = InMemoryCurrentSessionRepository()
    let service = InspectionSessionService(
      repository: repo,
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("INSP-METER")),
      instantProvider: FixedInstantProvider(Date(timeIntervalSince1970: 1_700_000_600))
    )
    _ = try await service.startInspection(vehicleIdentifierRaw: "VIN-M")
    XCTAssertEqual(service.currentSession?.metrics.captureCount, 0)
    // Simulate failed capture: do not call recordSuccessfulCapture.
    XCTAssertEqual(service.currentSession?.metrics.captureCount, 0)
    try await service.recordSuccessfulCapture()
    XCTAssertEqual(service.currentSession?.metrics.captureCount, 1)
  }

  func testCancelPreservesExportedCapturesInLibrary() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let repo = InMemoryCurrentSessionRepository()
    let service = InspectionSessionService(
      repository: repo,
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("INSP-CANCEL")),
      instantProvider: FixedInstantProvider(Date(timeIntervalSince1970: 1_700_000_700))
    )
    _ = try await service.startInspection(vehicleIdentifierRaw: "VIN-C")
    let ctx = service.evidenceContext(for: service.currentSession!)
    _ = try await storeCapture(
      store: store, suffix: "CANCEL1", context: ctx, at: Date(timeIntervalSince1970: 1_700_000_701)
    )
    try await service.recordSuccessfulCapture()
    try await service.cancel()

    let catalog = try await store.listInspectionCatalog()
    XCTAssertEqual(catalog.groups.count, 1)
    XCTAssertEqual(catalog.groups[0].captureCount, 1)
    XCTAssertEqual(service.currentSession?.status, .canceled)
  }

  func testCompletePreservesEvidenceGroup() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let repo = InMemoryCurrentSessionRepository()
    let service = InspectionSessionService(
      repository: repo,
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("INSP-DONE")),
      instantProvider: FixedInstantProvider(Date(timeIntervalSince1970: 1_700_000_800))
    )
    _ = try await service.startInspection(vehicleIdentifierRaw: "VIN-D")
    let ctx = service.evidenceContext(for: service.currentSession!)
    _ = try await storeCapture(
      store: store, suffix: "DONE1", context: ctx, at: Date(timeIntervalSince1970: 1_700_000_801)
    )
    _ = try await storeCapture(
      store: store, suffix: "DONE2", context: ctx, at: Date(timeIntervalSince1970: 1_700_000_802)
    )
    try await service.complete()

    let catalog = try await store.listInspectionCatalog()
    XCTAssertEqual(catalog.groups.count, 1)
    XCTAssertEqual(catalog.groups[0].sessionID, "INSP-DONE")
    XCTAssertEqual(catalog.groups[0].captureCount, 2)
  }

  func testInspectionContextCannotBeReassignedAfterPersistence() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let first = context(sessionID: "INSP-ORIG", vehicle: "VIN-1")
    let record = try await storeCapture(
      store: store, suffix: "IMMUTABLE", context: first, at: Date(timeIntervalSince1970: 1_700_000_900)
    )
    var mutable = record
    do {
      try mutable.applyInspectionContext(context(sessionID: "INSP-OTHER", vehicle: "VIN-2"))
      XCTFail("expected refusingOverwrite")
    } catch EvidenceLibraryError.refusingOverwrite {
      // expected
    }
    XCTAssertEqual(record.inspectionSessionID, "INSP-ORIG")
  }

  func testPureGroupingDoesNotInventSessionIDs() {
    let t0 = Date(timeIntervalSince1970: 1_700_001_000)
    let legacy = EvidenceLibraryIndexRecord(
      id: "EVD-LEG",
      captureTimestamp: t0,
      sessionId: "SESSION-LEG",
      artifactId: "ART-LEG",
      recordId: "REC-LEG",
      originalRelativePath: "captures/EVD-LEG/artifact_original.jpg",
      thumbnailRelativePath: "captures/EVD-LEG/thumbnail.jpg",
      originalSha256: "abc",
      originalByteCount: 1
    )
    let catalog = InspectionEvidenceGrouping.catalog(from: [legacy])
    XCTAssertTrue(catalog.groups.isEmpty)
    XCTAssertEqual(catalog.unassigned.map(\.id), ["EVD-LEG"])
  }

  func testSyntheticFlagPersistsOnRecord() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let jpeg = fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let record = try await store.storeApproved(
      jpegBytes: jpeg,
      sha256: sha,
      ids: ids("SYN"),
      captureTimestamp: Date(timeIntervalSince1970: 1_700_001_100),
      isSynthetic: true
    )
    XCTAssertTrue(record.isSynthetic)
    XCTAssertEqual(record.state.integrityState, .unverified)
    let rebuilt = try await store.rebuildIndexFromDisk()
    XCTAssertTrue(rebuilt.records.first(where: { $0.id == "EVD-SYN" })?.isSynthetic == true)
  }
}
