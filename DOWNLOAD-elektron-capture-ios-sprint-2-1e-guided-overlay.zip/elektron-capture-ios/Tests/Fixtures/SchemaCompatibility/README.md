# Schema Compatibility Fixtures

Authoritative tree for Sprint 1.1.1 longevity tests.

```text
Tests/Fixtures/SchemaCompatibility/
├── FIXTURE_SHA256.json
├── v1.0.0/captures/…
├── v1.1.0/captures/…
├── v1.2.0/captures/…
└── unsupported-v9.0.0/index.json
```

Mirrored into `Tests/Unit/Fixtures/SchemaCompatibility/` so SwiftPM bundles them via `Package.swift` → `ElektronCaptureTests` resources.

Each capture directory mirrors production Evidence Library layout:

- `artifact_original.jpg` (+ `.sha256`)
- `library_status.json`
- `sidecars/inspection_session_context.json` (when session-linked)
- `package_inventory.json` / `manifest.json` references

Do not edit hashes without regenerating `FIXTURE_SHA256.json`.
