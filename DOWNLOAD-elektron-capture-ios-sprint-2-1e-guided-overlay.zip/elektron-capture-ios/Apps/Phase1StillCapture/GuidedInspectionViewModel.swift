import Foundation
import Combine
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// Thin @MainActor presentation & delegation layer for guided inspection (Sprint 2.1E).
///
/// Responsibilities:
/// - Expose ``GuidedInspectionPresentationState`` for SwiftUI
/// - Map UI actions → ``GuidedInspectionIntent``
/// - Delegate to ``GuidedInspectionCoordinator`` (never builds ``EvidenceMetadata``)
/// - Persist updated sessions via ``InspectionSessionService``
/// - Map typed errors into displayable alert text
@MainActor
final class GuidedInspectionViewModel: ObservableObject {
  @Published private(set) var presentation: GuidedInspectionPresentationState = .unavailable
  @Published var alertMessage: String?
  @Published var skipReasonDraft: String = ""
  @Published var showSkipSheet: Bool = false

  private let coordinator: GuidedInspectionCoordinator
  private let inspection: InspectionSessionViewModel

  init(
    inspection: InspectionSessionViewModel,
    coordinator: GuidedInspectionCoordinator = GuidedInspectionCoordinator()
  ) {
    self.inspection = inspection
    self.coordinator = coordinator
    refresh()
  }

  func refresh() {
    presentation = coordinator.presentation(for: inspection.current)
  }

  /// Ensures progress is initialized and an eligible point is active when a plan is assigned.
  func prepareIfNeeded() async {
    guard let session = inspection.current, session.planState.isAssigned else {
      refresh()
      return
    }
    await submit(.prepareGuidedSession)
  }

  func activate(pointID: InspectionPointID) async {
    await submit(.activatePoint(pointID))
  }

  func advance() async {
    await submit(.advanceRequested)
  }

  func goBack() async {
    await submit(.returnRequested)
  }

  func completePoint() async {
    await submit(.completePointRequested)
  }

  func confirmSkip() async {
    let reason = skipReasonDraft
    showSkipSheet = false
    skipReasonDraft = ""
    await submit(.skipRequested(reason: reason))
  }

  /// Validates capture readiness. Returns `true` when the camera shutter may fire.
  func requestCapture() async -> Bool {
    guard let session = inspection.current else {
      alertMessage = displayMessage(for: .noActiveSession)
      return false
    }
    do {
      let handled = try coordinator.handle(.captureRequested, session: session)
      presentation = handled.presentation
      return handled.shouldTriggerShutter
    } catch let error as GuidedInspectionPresentationError {
      alertMessage = displayMessage(for: error)
      return false
    } catch {
      alertMessage = String(describing: error)
      return false
    }
  }

  /// Called after library store succeeds — coordinator owns EvidenceMetadata construction.
  func bindApprovedCapture(libraryEvidenceId: String, sha256Prefix: String?) async {
    var attrs: [String: String] = [:]
    if let sha256Prefix { attrs["sha256_prefix"] = sha256Prefix }
    await submit(
      .bindApprovedCapture(
        storageKey: libraryEvidenceId,
        type: .photo,
        attributes: attrs
      )
    )
  }

  private func submit(_ intent: GuidedInspectionIntent) async {
    guard let session = inspection.current else {
      alertMessage = displayMessage(for: .noActiveSession)
      presentation = .unavailable
      return
    }
    do {
      let handled = try coordinator.handle(intent, session: session)
      let saved = try await inspection.service.applyUpdatedSession(handled.session)
      inspection.adopt(saved)
      presentation = handled.presentation
      alertMessage = nil
    } catch let error as GuidedInspectionPresentationError {
      alertMessage = displayMessage(for: error)
      refresh()
    } catch {
      alertMessage = String(describing: error)
      refresh()
    }
  }

  func displayMessage(for error: GuidedInspectionPresentationError) -> String {
    switch error {
    case .noActiveSession:
      return "No active inspection session."
    case .planNotAssigned:
      return "This session has no assigned inspection plan."
    case .progressUnavailable:
      return "Guided progress is not available."
    case .noActivePoint:
      return "No active inspection point."
    case .captureNotReady(let detail):
      return "Capture not ready: \(detail)"
    case .emptySkipReason:
      return "Skip reason cannot be empty."
    case .emptyBlockReason:
      return "Block reason cannot be empty."
    case .progression(let e):
      return "Workflow: \(String(describing: e))"
    case .evidenceBinding(let e):
      return "Evidence binding: \(String(describing: e))"
    case .persistence(let detail):
      return "Could not save session: \(detail)"
    }
  }
}

#endif
