import Foundation
import Combine
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// Pure presentation adapter for guided inspection (Sprint 2.1E DoD).
///
/// **Allowed:** map UI → ``GuidedInspectionIntent``, hold ephemeral ``GuidedInspectionUIState``,
/// adopt coordinator-returned sessions for display.
///
/// **Forbidden:** repository/disk writes, constructing ``EvidenceMetadata``, camera driver calls,
/// mutating ``InspectionSession`` fields directly.
@MainActor
final class GuidedInspectionViewModel: ObservableObject {
  @Published private(set) var presentation: GuidedInspectionPresentationState = .unavailable
  @Published var ui: GuidedInspectionUIState = .idle

  private let coordinator: GuidedInspectionCoordinator
  private let inspection: InspectionSessionViewModel

  init(
    inspection: InspectionSessionViewModel,
    coordinator: GuidedInspectionCoordinator
  ) {
    self.inspection = inspection
    self.coordinator = coordinator
    refresh()
  }

  func refresh() {
    presentation = coordinator.presentation(for: inspection.current)
  }

  func resetUIEphemeral() {
    ui.resetEphemeral()
  }

  func prepareIfNeeded() async {
    guard let session = inspection.current, session.planState.isAssigned else {
      refresh()
      return
    }
    await submit(.prepareGuidedSession)
  }

  func activate(pointID: InspectionPointID) async {
    await submit(.activatePoint(pointID))
  }

  func advance() async {
    await submit(.advanceRequested)
  }

  func goBack() async {
    await submit(.returnRequested)
  }

  func completePoint() async {
    await submit(.completePointRequested)
  }

  func openSkipDialog() {
    ui.draftSkipReason = ""
    ui.showingSkipDialog = true
  }

  func openBlockDialog() {
    ui.draftBlockReason = ""
    ui.showingBlockDialog = true
  }

  func confirmSkip() async {
    let reason = ui.draftSkipReason
    ui.showingSkipDialog = false
    ui.draftSkipReason = ""
    await submit(.skipRequested(reason: reason))
  }

  func confirmBlock() async {
    let reason = ui.draftBlockReason
    ui.showingBlockDialog = false
    ui.draftBlockReason = ""
    await submit(.blockRequested(reason: reason))
  }

  /// Validates capture via coordinator; sets in-flight UI lock. Does not touch persistence.
  func requestCapture() async -> Bool {
    guard let session = inspection.current else {
      present(error: .noActiveSession)
      return false
    }
    do {
      let handled = try await coordinator.handle(.captureRequested, session: session)
      presentation = handled.presentation
      if handled.shouldTriggerShutter {
        ui.captureInProgress = true
      }
      return handled.shouldTriggerShutter
    } catch let error as GuidedInspectionPresentationError {
      present(error: error)
      return false
    } catch {
      ui.alert = PresentationAlert(message: String(describing: error))
      return false
    }
  }

  func clearCaptureInProgress() {
    ui.captureInProgress = false
  }

  /// Delegates bind + persist entirely to the coordinator.
  func bindApprovedCapture(libraryEvidenceId: String, sha256Prefix: String?) async {
    ui.captureInProgress = false
    var attrs: [String: String] = [:]
    if let sha256Prefix { attrs["sha256_prefix"] = sha256Prefix }
    await submit(
      .bindApprovedCapture(
        storageKey: libraryEvidenceId,
        type: .photo,
        attributes: attrs
      )
    )
  }

  private func submit(_ intent: GuidedInspectionIntent) async {
    guard let session = inspection.current else {
      present(error: .noActiveSession)
      presentation = .unavailable
      return
    }
    do {
      // Coordinator owns persistence. ViewModel only adopts the returned session for display.
      let handled = try await coordinator.handle(intent, session: session)
      inspection.adopt(handled.session)
      presentation = handled.presentation
      ui.alert = nil
    } catch let error as GuidedInspectionPresentationError {
      present(error: error)
      refresh()
    } catch {
      ui.alert = PresentationAlert(message: String(describing: error))
      refresh()
    }
  }

  private func present(error: GuidedInspectionPresentationError) {
    ui.alert = PresentationAlert(message: displayMessage(for: error))
  }

  func displayMessage(for error: GuidedInspectionPresentationError) -> String {
    switch error {
    case .noActiveSession:
      return "No active inspection session."
    case .planNotAssigned:
      return "This session has no assigned inspection plan."
    case .progressUnavailable:
      return "Guided progress is not available."
    case .noActivePoint:
      return "No active inspection point."
    case .captureNotReady(let detail):
      return "Capture not ready: \(detail)"
    case .emptySkipReason:
      return "Skip reason cannot be empty."
    case .emptyBlockReason:
      return "Block reason cannot be empty."
    case .progression(let e):
      return "Workflow: \(String(describing: e))"
    case .evidenceBinding(let e):
      return "Evidence binding: \(String(describing: e))"
    case .persistence(let detail):
      return "Could not save session: \(detail)"
    }
  }
}

#endif
