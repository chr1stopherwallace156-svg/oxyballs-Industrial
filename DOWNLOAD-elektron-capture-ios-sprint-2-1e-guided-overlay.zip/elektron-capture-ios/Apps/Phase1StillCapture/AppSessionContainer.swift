import SwiftUI
import Combine
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// Owns session + guided presentation ViewModels for the app process.
@MainActor
final class AppSessionContainer: ObservableObject {
  let inspection: InspectionSessionViewModel
  let guided: GuidedInspectionViewModel

  init(
    repository: any CurrentSessionRepository = FileCurrentSessionRepository()
  ) {
    let service = InspectionSessionService(repository: repository)
    let inspection = InspectionSessionViewModel(service: service)
    self.inspection = inspection
    self.guided = GuidedInspectionViewModel(inspection: inspection)
  }
}

#endif
