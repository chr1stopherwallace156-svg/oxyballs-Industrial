import SwiftUI
import Combine
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// Owns session + guided presentation ViewModels for the app process.
/// Wires ``GuidedInspectionCoordinator`` with the session service as the sole persister.
@MainActor
final class AppSessionContainer: ObservableObject {
  let inspection: InspectionSessionViewModel
  let guided: GuidedInspectionViewModel
  let sessionService: InspectionSessionService

  init(
    repository: any CurrentSessionRepository = FileCurrentSessionRepository()
  ) {
    let service = InspectionSessionService(repository: repository)
    self.sessionService = service
    let inspection = InspectionSessionViewModel(service: service)
    self.inspection = inspection
    let coordinator = GuidedInspectionCoordinator(persister: service)
    self.guided = GuidedInspectionViewModel(
      inspection: inspection,
      coordinator: coordinator
    )
  }
}

#endif
