import SwiftUI
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

struct NewInspectionSheet: View {
  @ObservedObject var viewModel: InspectionSessionViewModel
  @Environment(\.dismiss) private var dismiss
  @State private var vehicleIdentifier: String = ""

  var body: some View {
    NavigationStack {
      Form {
        Section {
          Picker("Inspection Plan", selection: Binding(
            get: { viewModel.selectedPlanKey },
            set: { newValue in
              let parts = newValue.split(separator: "@", maxSplits: 1).map(String.init)
              if parts.count == 2 {
                viewModel.selectPlan(id: parts[0], version: parts[1])
              }
            }
          )) {
            ForEach(viewModel.availablePlans, id: \.registryKey) { plan in
              Text("\(plan.title) v\(plan.version)")
                .tag(plan.registryKey)
            }
          }
          if let snap = viewModel.selectedPlanSnapshot {
            LabeledContent("Points", value: "\(snap.points.count)")
            LabeledContent("Definition digest") {
              Text(snap.snapshotSHA256)
                .font(.caption2.monospaced())
                .textSelection(.enabled)
            }
            Text("Plan is assigned immutably to the session at start (Sprint 2.1A). Digest is definition-only (S2-002).")
              .font(.caption2)
              .foregroundStyle(.secondary)
          }
        } header: {
          Text("Inspection Plan")
        }

        Section {
          TextField("Vehicle Identifier", text: $vehicleIdentifier)
            .textInputAutocapitalization(.characters)
            .autocorrectionDisabled()
        } header: {
          Text("Vehicle Identifier")
        } footer: {
          Text("Stored as an unknown-kind identifier unless later enriched. Inspector defaults to Local Inspector.")
        }
        if let errorText = viewModel.errorText {
          Text(errorText).foregroundStyle(.red)
        }
      }
      .navigationTitle("New Inspection")
      .navigationBarTitleDisplayMode(.inline)
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Cancel") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Start Inspection") {
            Task {
              await viewModel.start(vehicleIdentifier: vehicleIdentifier)
              if viewModel.hasActiveSession {
                dismiss()
              }
            }
          }
          .disabled(
            vehicleIdentifier.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
              || viewModel.selectedPlanSnapshot == nil
          )
        }
      }
    }
  }
}

struct ActiveInspectionBanner: View {
  @ObservedObject var viewModel: InspectionSessionViewModel

  var body: some View {
    VStack(spacing: 8) {
      HStack(alignment: .center, spacing: 12) {
        VStack(alignment: .leading, spacing: 2) {
          Text(viewModel.sessionIDLabel)
            .font(.caption.monospaced())
            .foregroundStyle(.white)
          Text(viewModel.vehicleLabel)
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(.white)
          if viewModel.selectedPlanSnapshot != nil {
            Text(viewModel.planDisplayLabel)
              .font(.caption2.weight(.medium))
              .foregroundStyle(.white.opacity(0.95))
          }
          Text("\(viewModel.statusLabel) · captures \(viewModel.captureCount) · \(viewModel.elapsedDescription)")
            .font(.caption2)
            .foregroundStyle(.white.opacity(0.85))
        }
        Spacer()
        if viewModel.current?.status == .paused {
          Button("Resume") {
            Task { await viewModel.resume() }
          }
          .font(.caption.weight(.semibold))
          .buttonStyle(.bordered)
          .tint(.white)
        } else if viewModel.current?.status == .inProgress {
          Button("Pause") {
            Task { await viewModel.pause() }
          }
          .font(.caption.weight(.semibold))
          .buttonStyle(.bordered)
          .tint(.white)
        }
        Button("Done") {
          Task { await viewModel.complete() }
        }
        .font(.caption.weight(.semibold))
        .buttonStyle(.borderedProminent)
        Button("Cancel") {
          viewModel.showCancelConfirmation = true
        }
        .font(.caption.weight(.semibold))
        .buttonStyle(.bordered)
        .tint(.red)
      }
    }
    .padding(12)
    .background(Color.blue.opacity(0.85))
    .confirmationDialog(
      "Cancel this inspection?",
      isPresented: $viewModel.showCancelConfirmation,
      titleVisibility: .visible
    ) {
      Button("Cancel Inspection", role: .destructive) {
        Task { await viewModel.cancelConfirmed() }
      }
      Button("Keep Inspection", role: .cancel) {}
    } message: {
      Text("This cannot be undone. Captures already exported remain in the Evidence Library.")
    }
  }
}

#endif
