import SwiftUI
import ElektronCapture

@main
struct Phase1StillCaptureApp: App {
  #if canImport(UIKit) && !os(macOS)
  @StateObject private var sessionContainer = AppSessionContainer()
  #endif

  var body: some Scene {
    WindowGroup {
      #if canImport(UIKit) && !os(macOS)
      Phase1MainTabView()
        .environmentObject(sessionContainer.inspection)
        .environmentObject(sessionContainer.guided)
      #else
      Text("Phase 1 still capture requires iOS.")
      #endif
    }
  }
}
