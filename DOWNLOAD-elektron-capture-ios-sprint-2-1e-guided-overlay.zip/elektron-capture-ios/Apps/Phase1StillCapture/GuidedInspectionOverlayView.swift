import SwiftUI
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// Semi-transparent HUD floating over the live `AVCaptureVideoPreviewLayer`.
/// Camera preview remains the foundational surface; this view never owns or reconfigures capture.
struct GuidedInspectionOverlayView: View {
  @ObservedObject var guided: GuidedInspectionViewModel
  var onCaptureRequested: () -> Void

  var body: some View {
    VStack(spacing: 0) {
      if guided.presentation.isGuidedAvailable {
        hudHeader
        Spacer()
        hudControls
      } else {
        Spacer()
      }
    }
    .padding(.horizontal, 12)
    .padding(.top, 8)
    .padding(.bottom, 120)
    .allowsHitTesting(true)
    .alert(
      guided.ui.alert?.title ?? "Guided Inspection",
      isPresented: Binding(
        get: { guided.ui.alert != nil },
        set: { if !$0 { guided.ui.alert = nil } }
      )
    ) {
      Button("OK", role: .cancel) { guided.ui.alert = nil }
    } message: {
      Text(guided.ui.alert?.message ?? "")
    }
    .sheet(isPresented: Binding(
      get: { guided.ui.showingSkipDialog },
      set: { guided.ui.showingSkipDialog = $0 }
    )) {
      reasonSheet(
        title: "Skip Point",
        draft: Binding(
          get: { guided.ui.draftSkipReason },
          set: { guided.ui.draftSkipReason = $0 }
        ),
        confirmTitle: "Skip",
        onCancel: { guided.ui.showingSkipDialog = false },
        onConfirm: { Task { await guided.confirmSkip() } }
      )
    }
    .sheet(isPresented: Binding(
      get: { guided.ui.showingBlockDialog },
      set: { guided.ui.showingBlockDialog = $0 }
    )) {
      reasonSheet(
        title: "Block Point",
        draft: Binding(
          get: { guided.ui.draftBlockReason },
          set: { guided.ui.draftBlockReason = $0 }
        ),
        confirmTitle: "Block",
        onCancel: { guided.ui.showingBlockDialog = false },
        onConfirm: { Task { await guided.confirmBlock() } }
      )
    }
  }

  private var hudHeader: some View {
    VStack(alignment: .leading, spacing: 8) {
      HStack {
        Text(guided.presentation.pointPositionLabel)
          .font(.caption.weight(.semibold))
          .foregroundStyle(.white.opacity(0.9))
        Spacer()
        Text("\(guided.presentation.planProgressPercent)%")
          .font(.caption.monospaced())
          .foregroundStyle(.white.opacity(0.85))
      }
      Text(guided.presentation.activePointTitle ?? "No active point")
        .font(.title3.weight(.semibold))
        .foregroundStyle(.white)
      if let guidance = guided.presentation.guidanceText, !guidance.isEmpty {
        Text(guidance)
          .font(.subheadline)
          .foregroundStyle(.white.opacity(0.92))
      }
      Text(guided.presentation.evidenceStatusLabel)
        .font(.caption.monospaced())
        .foregroundStyle(
          guided.presentation.isPointSatisfied ? Color.green.opacity(0.95) : Color.white.opacity(0.9)
        )
    }
    .padding(14)
    .frame(maxWidth: .infinity, alignment: .leading)
    .background(.ultraThinMaterial.opacity(0.88))
    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
  }

  private var hudControls: some View {
    VStack(spacing: 10) {
      if guided.presentation.canPrepare && guided.presentation.activePointID == nil {
        Button {
          Task { await guided.prepareIfNeeded() }
        } label: {
          Text("Start Guidance")
            .font(.subheadline.weight(.semibold))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
        }
        .buttonStyle(.borderedProminent)
      }

      Button {
        onCaptureRequested()
      } label: {
        Text(guided.ui.captureInProgress ? "Capturing…" : "CAPTURE")
          .font(.headline.weight(.bold))
          .frame(maxWidth: .infinity)
          .padding(.vertical, 14)
      }
      .buttonStyle(.borderedProminent)
      .tint(.orange)
      .disabled(
        !guided.presentation.canCapture
          || guided.ui.captureInProgress
      )

      HStack(spacing: 10) {
        Button("Previous") {
          Task { await guided.goBack() }
        }
        .buttonStyle(.bordered)
        .tint(.white)
        .disabled(!guided.presentation.canReturn || guided.ui.captureInProgress)

        Button("Next") {
          Task { await guided.advance() }
        }
        .buttonStyle(.borderedProminent)
        .disabled(!guided.presentation.canAdvance || guided.ui.captureInProgress)
      }

      HStack(spacing: 10) {
        Button("Skip") {
          guided.openSkipDialog()
        }
        .buttonStyle(.bordered)
        .tint(.white)
        .disabled(!guided.presentation.canSkip || guided.ui.captureInProgress)

        Button("Block") {
          guided.openBlockDialog()
        }
        .buttonStyle(.bordered)
        .tint(.white)
        .disabled(!guided.presentation.canBlock || guided.ui.captureInProgress)

        Button("Complete") {
          Task { await guided.completePoint() }
        }
        .buttonStyle(.bordered)
        .tint(.white)
        .disabled(!guided.presentation.canComplete || guided.ui.captureInProgress)
      }
    }
    .padding(12)
    .background(.ultraThinMaterial.opacity(0.88))
    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
  }

  private func reasonSheet(
    title: String,
    draft: Binding<String>,
    confirmTitle: String,
    onCancel: @escaping () -> Void,
    onConfirm: @escaping () -> Void
  ) -> some View {
    NavigationStack {
      Form {
        Section("Reason (required)") {
          TextField("Reason", text: draft)
        }
        Section {
          Text("Blank or whitespace-only reasons are rejected by the domain engine.")
            .font(.caption)
            .foregroundStyle(.secondary)
        }
      }
      .navigationTitle(title)
      .navigationBarTitleDisplayMode(.inline)
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Cancel", action: onCancel)
        }
        ToolbarItem(placement: .confirmationAction) {
          Button(confirmTitle, action: onConfirm)
            .disabled(draft.wrappedValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
      }
    }
    .presentationDetents([.medium])
  }
}

#endif
