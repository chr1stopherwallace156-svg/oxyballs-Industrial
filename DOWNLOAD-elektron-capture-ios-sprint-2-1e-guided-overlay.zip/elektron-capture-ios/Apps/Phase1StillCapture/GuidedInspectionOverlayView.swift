import SwiftUI
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// Guided inspection chrome layered over the live camera preview.
/// Emits intents via ``GuidedInspectionViewModel`` only — never builds domain bindings.
struct GuidedInspectionOverlayView: View {
  @ObservedObject var guided: GuidedInspectionViewModel
  var onCaptureRequested: () -> Void

  var body: some View {
    VStack(spacing: 0) {
      if guided.presentation.isGuidedAvailable {
        headerCard
        Spacer()
        controlsBar
      } else {
        Spacer()
      }
    }
    .padding(.horizontal, 12)
    .padding(.top, 8)
    .padding(.bottom, 120)
    .alert("Guided Inspection", isPresented: Binding(
      get: { guided.alertMessage != nil },
      set: { if !$0 { guided.alertMessage = nil } }
    )) {
      Button("OK", role: .cancel) { guided.alertMessage = nil }
    } message: {
      Text(guided.alertMessage ?? "")
    }
    .sheet(isPresented: $guided.showSkipSheet) {
      NavigationStack {
        Form {
          Section("Skip reason") {
            TextField("Reason", text: $guided.skipReasonDraft)
          }
        }
        .navigationTitle("Skip Point")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
          ToolbarItem(placement: .cancellationAction) {
            Button("Cancel") { guided.showSkipSheet = false }
          }
          ToolbarItem(placement: .confirmationAction) {
            Button("Skip") {
              Task { await guided.confirmSkip() }
            }
            .disabled(
              guided.skipReasonDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            )
          }
        }
      }
      .presentationDetents([.medium])
    }
  }

  private var headerCard: some View {
    VStack(alignment: .leading, spacing: 6) {
      HStack {
        Text(guided.presentation.activePointTitle ?? "No active point")
          .font(.headline)
          .foregroundStyle(.white)
        Spacer()
        if guided.presentation.isPointSatisfied {
          Text("Satisfied")
            .font(.caption.weight(.semibold))
            .foregroundStyle(.green)
        } else {
          Text("\(guided.presentation.evidenceCount)/\(guided.presentation.requiredCount)")
            .font(.caption.monospaced())
            .foregroundStyle(.white.opacity(0.9))
        }
      }
      if let guidance = guided.presentation.guidanceText, !guidance.isEmpty {
        Text(guidance)
          .font(.subheadline)
          .foregroundStyle(.white.opacity(0.9))
      } else {
        Text(statusLine)
          .font(.caption)
          .foregroundStyle(.white.opacity(0.75))
      }
      if !guided.presentation.points.isEmpty {
        ScrollView(.horizontal, showsIndicators: false) {
          HStack(spacing: 8) {
            ForEach(guided.presentation.points) { point in
              Button {
                Task { await guided.activate(pointID: point.pointID) }
              } label: {
                Text(point.title)
                  .font(.caption2.weight(point.isActive ? .bold : .regular))
                  .padding(.horizontal, 10)
                  .padding(.vertical, 6)
                  .background(
                    point.isActive
                      ? Color.accentColor.opacity(0.9)
                      : Color.white.opacity(0.15)
                  )
                  .foregroundStyle(.white)
                  .clipShape(Capsule())
              }
              .disabled(point.status?.isTerminal == true)
            }
          }
        }
      }
    }
    .padding(12)
    .background(.ultraThinMaterial.opacity(0.92))
    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
  }

  private var statusLine: String {
    if let status = guided.presentation.activeStatus {
      return "Status: \(statusLabel(status))"
    }
    return guided.presentation.canPrepare
      ? "Tap Start Guidance to begin"
      : "Select or advance to a point"
  }

  private func statusLabel(_ status: InspectionPointStatus) -> String {
    switch status {
    case .notStarted: return "Not started"
    case .inProgress: return "In progress"
    case .completed: return "Completed"
    case .skipped(let reason): return "Skipped (\(reason))"
    case .blocked(let reason): return "Blocked (\(reason))"
    }
  }

  private var controlsBar: some View {
    VStack(spacing: 10) {
      if guided.presentation.canPrepare && guided.presentation.activePointID == nil {
        Button {
          Task { await guided.prepareIfNeeded() }
        } label: {
          Text("Start Guidance")
            .font(.subheadline.weight(.semibold))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
        }
        .buttonStyle(.borderedProminent)
      }

      HStack(spacing: 10) {
        Button("Back") {
          Task { await guided.goBack() }
        }
        .buttonStyle(.bordered)
        .tint(.white)
        .disabled(!guided.presentation.canReturn)

        Button("Skip") {
          guided.showSkipSheet = true
        }
        .buttonStyle(.bordered)
        .tint(.white)
        .disabled(!guided.presentation.canSkip)

        Button("Complete") {
          Task { await guided.completePoint() }
        }
        .buttonStyle(.bordered)
        .tint(.white)
        .disabled(!guided.presentation.canComplete)

        Button("Next") {
          Task { await guided.advance() }
        }
        .buttonStyle(.borderedProminent)
        .disabled(!guided.presentation.canAdvance)
      }

      Button {
        onCaptureRequested()
      } label: {
        Text("Capture for Point")
          .font(.headline)
          .frame(maxWidth: .infinity)
          .padding(.vertical, 12)
      }
      .buttonStyle(.borderedProminent)
      .tint(.orange)
      .disabled(!guided.presentation.canCapture)
    }
    .padding(12)
    .background(.ultraThinMaterial.opacity(0.92))
    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
  }
}

#endif
