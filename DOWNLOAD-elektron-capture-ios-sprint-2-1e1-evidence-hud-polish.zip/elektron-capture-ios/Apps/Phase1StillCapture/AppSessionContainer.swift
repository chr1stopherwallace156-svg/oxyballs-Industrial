import SwiftUI
import Combine
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// Owns session + guided + shared Evidence Library ViewModels for the app process.
@MainActor
final class AppSessionContainer: ObservableObject {
  let inspection: InspectionSessionViewModel
  let guided: GuidedInspectionViewModel
  let library: EvidenceLibraryViewModel
  let sessionService: InspectionSessionService

  /// When set, the next successful Use Photo soft-deletes this library id (retake/replace).
  @Published var pendingRetakeEvidenceId: String?
  @Published var selectedTab: AppTab = .capture
  @Published var retakeBannerText: String?

  enum AppTab: Hashable {
    case capture
    case library
  }

  init(
    repository: any CurrentSessionRepository = FileCurrentSessionRepository()
  ) {
    let service = InspectionSessionService(repository: repository)
    self.sessionService = service
    let inspection = InspectionSessionViewModel(service: service)
    self.inspection = inspection
    let coordinator = GuidedInspectionCoordinator(persister: service)
    self.guided = GuidedInspectionViewModel(
      inspection: inspection,
      coordinator: coordinator
    )
    let library = EvidenceLibraryViewModel()
    // Sprint 2.1E.1 — bind library to session publisher so binding mutations refresh thumbnails.
    library.observeSessionPublisher(inspection.$current.eraseToAnyPublisher())
    self.library = library
  }

  func beginRetake(of evidenceId: String) {
    pendingRetakeEvidenceId = evidenceId
    retakeBannerText = "Retake mode: capture a replacement photo, then Use Photo."
    selectedTab = .capture
  }

  func clearRetakeMode() {
    pendingRetakeEvidenceId = nil
    retakeBannerText = nil
  }
}

#endif
