# Sprint 2.1E.1 — Evidence Management & HUD Ergonomics Polish

| Field | Value |
|---|---|
| **Status** | `SPRINT_2_1E1` (Linux `swift test`; device NOT RUN) |
| **Branch** | `cursor/sprint-2-1e1-evidence-hud-polish-d881` |
| **Baseline** | Field UX polish tip (`1049dcf`) |
| **Next** | Sprint 2.1F hierarchy polish / Sprint 2.2 Hardening |

## Shipped in this sprint

1. **Reactive library refresh**  
   - `EvidenceLibraryViewModel` observes `EvidenceLibraryNotifications.didChange` **and** `inspection.$current`  
   - Binding / unbind / replace mutations refresh thumbnails without app restart  

2. **Single Capture HUD** (confirmed from field polish)  
   - One primary **Capture Photo** control  
   - Skip / Block / Complete under **More** overflow  

3. **Evidence lifecycle mutations**  
   - `EvidenceBindingService.replace(evidenceID:with:in:)` + `unbindLibraryEvidence(...)`  
   - Coordinator intent `replaceLibraryEvidence` preserves the original pointID  
   - Retake Use Photo uses atomic replace (not unbind-then-bind flicker)  

4. **Detail bottom toolbar**  
   - Full-screen preview with **Retake Photo · Replace… · Delete**  
   - Soft-delete still quarantines originals; retake = new capture-id  

5. **Point-grouped Evidence Library (2.1F preview)**  
   - `InspectionPointEvidenceGrouping` sections under frozen plan points  
   - Status chips: `✓ Satisfied` / `● N of M Required`  
   - “Tap to add required photo” when under-satisfied  

## Boundaries

- AVCapture warm-up / permission: **untouched**  
- Envelope schema: **v1** (Option A)  
- Write-once originals: **preserved**  

## Execution

```text
Host: Linux (Swift 5.10.1)
Command: swift test
Result: 242 executed, 1 skipped, 0 failures
Sprint2_1E1Tests: 4 executed, 0 failures
xcodebuild / device: NOT RUN
```
