import Foundation

/// Actor-safe Evidence Library repository.
/// Index can be fully rebuilt from on-disk capture directories.
public actor EvidenceLibraryStore {
  public let paths: EvidenceLibraryPaths
  private let fileManager: FileManager
  private let hasher: ArtifactHashingService
  private let integrity: EvidenceLibraryIntegrityService
  private var cachedIndex: EvidenceLibraryIndexDocument?

  public init(
    libraryRoot: URL,
    fileManager: FileManager = .default,
    hasher: ArtifactHashingService = ArtifactHashingService()
  ) {
    self.paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    self.fileManager = fileManager
    self.hasher = hasher
    self.integrity = EvidenceLibraryIntegrityService(hasher: hasher)
  }

  public static func makeDefault() async throws -> EvidenceLibraryStore {
    let root = try EvidenceLibraryPaths.defaultLibraryRoot()
    let store = EvidenceLibraryStore(libraryRoot: root)
    _ = try await store.reconcileOnLaunch()
    return store
  }

  // MARK: - Index

  public func loadIndex() throws -> EvidenceLibraryIndexDocument {
    if let cachedIndex { return cachedIndex }
    let url = paths.indexURL
    if !fileManager.fileExists(atPath: url.path) {
      let empty = EvidenceLibraryIndexDocument()
      try persistIndex(empty)
      cachedIndex = empty
      return empty
    }
    let data = try Data(contentsOf: url)
    let dec = JSONDecoder()
    dec.dateDecodingStrategy = .iso8601
    let doc = try dec.decode(EvidenceLibraryIndexDocument.self, from: data)
    cachedIndex = doc
    return doc
  }

  private func persistIndex(_ doc: EvidenceLibraryIndexDocument) throws {
    var mutable = doc
    mutable.updatedAt = Date()
    let enc = JSONEncoder()
    enc.outputFormatting = [.prettyPrinted, .sortedKeys]
    enc.dateEncodingStrategy = .iso8601
    let data = try enc.encode(mutable)
    try EvidenceLibraryAtomicIO.writeAtomically(data, to: paths.indexURL, fileManager: fileManager)
    cachedIndex = mutable
  }

  /// Newest-first listing.
  public func listRecordsNewestFirst() throws -> [EvidenceLibraryIndexRecord] {
    try loadIndex().records.sorted { $0.captureTimestamp > $1.captureTimestamp }
  }

  public func record(id: String) throws -> EvidenceLibraryIndexRecord {
    guard let r = try loadIndex().records.first(where: { $0.id == id }) else {
      throw EvidenceLibraryError.recordNotFound(id)
    }
    return r
  }

  // MARK: - Store approved capture

  /// Persists approved JPEG bytes into Application Support library.
  /// Retakes must call this with a **new** capture id — overwrite of artifact_original.jpg is refused.
  @discardableResult
  public func storeApproved(
    jpegBytes: Data,
    sha256: String,
    ids: Phase1CaptureIdentifiers,
    captureTimestamp: Date = Date(),
    vehicleOrSessionLabel: String? = nil
  ) throws -> EvidenceLibraryIndexRecord {
    let recomputed = hasher.sha256HexOfData(jpegBytes)
    guard recomputed == sha256 else {
      throw EvidenceLibraryError.integrityFailed("approved bytes hash mismatch before store")
    }

    let captureDir = paths.captureDirectory(id: ids.evidenceId)
    try fileManager.createDirectory(at: captureDir, withIntermediateDirectories: true)
    try fileManager.createDirectory(at: paths.exportsDirectory(id: ids.evidenceId), withIntermediateDirectories: true)
    try fileManager.createDirectory(at: paths.sidecarsDirectory(id: ids.evidenceId), withIntermediateDirectories: true)

    let artifactURL = paths.artifactOriginalURL(id: ids.evidenceId)
    try EvidenceLibraryAtomicIO.writeOnceExact(jpegBytes, to: artifactURL, fileManager: fileManager)

    // Read-back hash
    let onDisk = try hasher.sha256HexOfFile(at: artifactURL)
    guard onDisk == sha256 else {
      throw EvidenceLibraryError.corruptedArtifact("read-back hash \(onDisk) != \(sha256)")
    }

    let thumb = try EvidenceLibraryThumbnailBuilder.makeThumbnailJPEG(fromOriginal: jpegBytes)
    let thumbURL = paths.thumbnailURL(id: ids.evidenceId)
    if fileManager.fileExists(atPath: thumbURL.path) {
      try fileManager.removeItem(at: thumbURL)
    }
    try EvidenceLibraryAtomicIO.writeAtomically(thumb, to: thumbURL, fileManager: fileManager)

    let record = EvidenceLibraryIndexRecord(
      id: ids.evidenceId,
      captureTimestamp: captureTimestamp,
      sessionId: ids.sessionId,
      artifactId: ids.artifactId,
      recordId: ids.recordId,
      vehicleOrSessionLabel: vehicleOrSessionLabel,
      originalSha256: sha256,
      originalByteCount: jpegBytes.count,
      captureStatus: .storedLocally,
      packageStatus: nil,
      exportStatus: nil
    )

    var doc = try loadIndex()
    doc.records.removeAll { $0.id == record.id }
    doc.records.append(record)
    try persistIndex(doc)

    // Library-local status marker (atomic JSON; not CaptureSideStatus authority for EDTS)
    let statusObj: [String: Any] = [
      "schema_id": "EvidenceLibraryLocalStatus",
      "schema_version": "1.0.0",
      "evidence_id": ids.evidenceId,
      "lifecycle": EvidenceLibraryLifecycleState.storedLocally.rawValue,
      "approved": true,
      "original_sha256": sha256,
    ]
    let statusData = try JSONSerialization.data(withJSONObject: statusObj, options: [.sortedKeys, .prettyPrinted])
    try EvidenceLibraryAtomicIO.writeAtomically(
      statusData,
      to: captureDir.appendingPathComponent("library_status.json"),
      fileManager: fileManager
    )

    return record
  }

  /// Attempting to overwrite an existing approved original must throw.
  public func assertCannotOverwriteOriginal(id: String, newBytes: Data) throws {
    let url = paths.artifactOriginalURL(id: id)
    try EvidenceLibraryAtomicIO.writeOnceExact(newBytes, to: url, fileManager: fileManager)
  }

  // MARK: - Attach export (non-destructive)

  /// Copies package metadata + `.edts-pkg` into the library record.
  /// Does **not** move/delete Documents export or modify `artifact_original.jpg`.
  @discardableResult
  public func attachPackage(
    evidenceId: String,
    packageResult: Phase1PackageResult,
    markExported: Bool
  ) throws -> EvidenceLibraryIndexRecord {
    var record = try record(id: evidenceId)
    guard packageResult.artifactSha256 == record.originalSha256 else {
      throw EvidenceLibraryError.integrityFailed(
        "package artifact hash \(packageResult.artifactSha256) != library \(record.originalSha256)"
      )
    }

    let captureDir = paths.captureDirectory(id: evidenceId)
    let fm = fileManager

    // Copy metadata files from package directory (skip payload/artifact — library already has canonical)
    let copyNames = [
      "manifest.json",
      "package_inventory.json",
      "package_status.json",
      "capture_device.json",
    ]
    for name in copyNames {
      let src = packageResult.packageDirectoryURL.appendingPathComponent(name)
      let dst = captureDir.appendingPathComponent(name)
      guard fm.fileExists(atPath: src.path) else { continue }
      if fm.fileExists(atPath: dst.path) {
        try fm.removeItem(at: dst)
      }
      try fm.copyItem(at: src, to: dst)
    }

    // Sidecars
    let srcSide = packageResult.packageDirectoryURL.appendingPathComponent("sidecars", isDirectory: true)
    let dstSide = paths.sidecarsDirectory(id: evidenceId)
    if fm.fileExists(atPath: srcSide.path) {
      if let en = fm.enumerator(at: srcSide, includingPropertiesForKeys: [.isRegularFileKey]) {
        for case let src as URL in en {
          let vals = try src.resourceValues(forKeys: [.isRegularFileKey])
          guard vals.isRegularFile == true else { continue }
          let rel = src.lastPathComponent
          let dst = dstSide.appendingPathComponent(rel)
          if fm.fileExists(atPath: dst.path) { try fm.removeItem(at: dst) }
          try fm.copyItem(at: src, to: dst)
        }
      }
    }

    // Copy .edts-pkg into exports/ (canonical library export copy)
    try fm.createDirectory(at: paths.exportsDirectory(id: evidenceId), withIntermediateDirectories: true)
    let exportURL = paths.exportPackageURL(id: evidenceId)
    if fm.fileExists(atPath: exportURL.path) {
      try fm.removeItem(at: exportURL)
    }
    try fm.copyItem(at: packageResult.packageZipURL, to: exportURL)

    let pkgHash = try hasher.sha256HexOfFile(at: exportURL)
    let relPkg = "exports/\(evidenceId).edts-pkg"

    record.packageRelativePath = relPkg
    record.packageSha256 = pkgHash
    record.packageStatus = .packageCreated
    if markExported {
      record.exportStatus = .exported
    }
    record.updatedAt = Date()

    // Never touch artifact_original.jpg here — verify still matches
    let artHash = try hasher.sha256HexOfFile(at: paths.artifactOriginalURL(id: evidenceId))
    guard artHash == record.originalSha256 else {
      throw EvidenceLibraryError.corruptedArtifact("canonical original changed during attachPackage")
    }

    var doc = try loadIndex()
    if let idx = doc.records.firstIndex(where: { $0.id == evidenceId }) {
      doc.records[idx] = record
    } else {
      doc.records.append(record)
    }
    try persistIndex(doc)
    return record
  }

  /// Re-export: copy library `.edts-pkg` (or rebuild from stored original via caller) to a destination
  /// without deleting library originals.
  public func copyExportPackage(id: String, to destination: URL) throws -> URL {
    let record = try record(id: id)
    guard let rel = record.packageRelativePath else {
      throw EvidenceLibraryError.packageAttachFailed("no package on record \(id)")
    }
    let src = paths.captureDirectory(id: id).appendingPathComponent(rel)
    guard fileManager.fileExists(atPath: src.path) else {
      throw EvidenceLibraryError.missingArtifact(rel)
    }
    try fileManager.createDirectory(
      at: destination.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if fileManager.fileExists(atPath: destination.path) {
      try fileManager.removeItem(at: destination)
    }
    try fileManager.copyItem(at: src, to: destination)
    return destination
  }

  /// Copy canonical original JPEG to a destination (Files/Photos workflow) — original untouched.
  public func copyOriginalJPEG(id: String, to destination: URL) throws -> URL {
    let src = paths.artifactOriginalURL(id: id)
    guard fileManager.fileExists(atPath: src.path) else {
      throw EvidenceLibraryError.missingArtifact(id)
    }
    try fileManager.createDirectory(
      at: destination.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if fileManager.fileExists(atPath: destination.path) {
      try fileManager.removeItem(at: destination)
    }
    try fileManager.copyItem(at: src, to: destination)
    return destination
  }

  // MARK: - Integrity & reconcile

  @discardableResult
  public func verifyIntegrity(id: String) throws -> EvidenceLibraryIntegrityService.VerificationResult {
    var record = try record(id: id)
    let result = try integrity.verify(record: record, paths: paths, fileManager: fileManager)
    record.lastIntegrityCheckAt = Date()
    record.lastIntegrityResult = result.state
    if result.state == .missing || result.state == .corrupted {
      record.captureStatus = result.state
    } else if result.state == .integrityVerified {
      record.lastIntegrityResult = .integrityVerified
    }
    var doc = try loadIndex()
    if let idx = doc.records.firstIndex(where: { $0.id == id }) {
      doc.records[idx] = record
    }
    try persistIndex(doc)
    return result
  }

  /// Scan disk, index orphans, mark missing/corrupted. Never deletes questionable records.
  @discardableResult
  public func reconcileOnLaunch() throws -> EvidenceLibraryIndexDocument {
    var doc = try loadIndex()
    var byId = Dictionary(uniqueKeysWithValues: doc.records.map { ($0.id, $0) })

    // Discover capture directories
    let contents = (try? fileManager.contentsOfDirectory(
      at: paths.libraryRoot,
      includingPropertiesForKeys: [.isDirectoryKey],
      options: [.skipsHiddenFiles]
    )) ?? []

    for url in contents {
      let name = url.lastPathComponent
      if name == "index.json" { continue }
      var isDir: ObjCBool = false
      guard fileManager.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else { continue }

      if byId[name] == nil {
        // Orphan directory — try to index if artifact present
        if let orphan = try? rebuildRecordFromDirectory(id: name) {
          byId[name] = orphan
        }
      }
    }

    // Verify existing
    var updated: [EvidenceLibraryIndexRecord] = []
    for (_, var rec) in byId {
      let result = try integrity.verify(record: rec, paths: paths, fileManager: fileManager)
      rec.lastIntegrityCheckAt = Date()
      rec.lastIntegrityResult = result.state
      if result.state == .missing || result.state == .corrupted {
        rec.captureStatus = result.state
      }
      updated.append(rec)
    }

    doc.records = updated
    try persistIndex(doc)
    return doc
  }

  /// Full rebuild from raw Application Support folder (ignores prior index contents).
  public func rebuildIndexFromDisk() throws -> EvidenceLibraryIndexDocument {
    var records: [EvidenceLibraryIndexRecord] = []
    let contents = (try? fileManager.contentsOfDirectory(
      at: paths.libraryRoot,
      includingPropertiesForKeys: [.isDirectoryKey],
      options: [.skipsHiddenFiles]
    )) ?? []

    for url in contents {
      let name = url.lastPathComponent
      if name == "index.json" { continue }
      var isDir: ObjCBool = false
      guard fileManager.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else { continue }
      if let rec = try? rebuildRecordFromDirectory(id: name) {
        records.append(rec)
      }
    }

    let doc = EvidenceLibraryIndexDocument(records: records)
    try persistIndex(doc)
    return doc
  }

  private func rebuildRecordFromDirectory(id: String) throws -> EvidenceLibraryIndexRecord {
    let artifact = paths.artifactOriginalURL(id: id)
    guard fileManager.fileExists(atPath: artifact.path) else {
      throw EvidenceLibraryError.missingArtifact(id)
    }
    let sha = try hasher.sha256HexOfFile(at: artifact)
    let size = try fileManager.attributesOfItem(atPath: artifact.path)[.size] as? Int ?? 0
    let exportURL = paths.exportPackageURL(id: id)
    var packageRel: String?
    var packageSha: String?
    var packageStatus: EvidenceLibraryLifecycleState?
    var exportStatus: EvidenceLibraryLifecycleState?
    if fileManager.fileExists(atPath: exportURL.path) {
      packageRel = "exports/\(id).edts-pkg"
      packageSha = try hasher.sha256HexOfFile(at: exportURL)
      packageStatus = .packageCreated
      exportStatus = .exported
    }

    let attrs = try fileManager.attributesOfItem(atPath: artifact.path)
    let created = (attrs[.creationDate] as? Date) ?? Date()

    return EvidenceLibraryIndexRecord(
      id: id,
      captureTimestamp: created,
      sessionId: "SESSION-REBUILT",
      artifactId: "ART-REBUILT",
      recordId: "REC-REBUILT",
      originalSha256: sha,
      originalByteCount: size,
      packageRelativePath: packageRel,
      packageSha256: packageSha,
      captureStatus: .storedLocally,
      packageStatus: packageStatus,
      exportStatus: exportStatus
    )
  }
}
