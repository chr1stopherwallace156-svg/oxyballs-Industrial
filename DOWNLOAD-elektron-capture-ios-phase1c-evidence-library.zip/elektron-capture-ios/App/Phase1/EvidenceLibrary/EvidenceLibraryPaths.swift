import Foundation

/// Application Support layout for Phase 1C Evidence Library (revised).
///
/// ```
/// Application Support/EvidenceLibrary/
///   index.json                    # rebuildable catalog (non-authoritative)
///   .staging/<capture-id>-<uuid>/ # incomplete writes only
///   .quarantine/                  # unrecognized / failed staging (never auto-deleted)
///   captures/<capture-id>/
///     artifact_original.jpg
///     thumbnail.jpg
///     … metadata …
///     exports/<capture-id>.edts-pkg
///     exports/<capture-id>.edts-pkg.sha256
/// ```
public struct EvidenceLibraryPaths: Sendable {
  public var libraryRoot: URL

  public init(libraryRoot: URL) {
    self.libraryRoot = libraryRoot
  }

  public static func defaultLibraryRoot(fileManager: FileManager = .default) throws -> URL {
    guard let base = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
      throw EvidenceLibraryError.rootUnavailable("applicationSupportDirectory unavailable")
    }
    let root = base.appendingPathComponent("EvidenceLibrary", isDirectory: true)
    try ensureLibraryLayout(at: root, fileManager: fileManager)
    return root
  }

  public static func root(under base: URL, fileManager: FileManager = .default) throws -> URL {
    let root = base.appendingPathComponent("EvidenceLibrary", isDirectory: true)
    try ensureLibraryLayout(at: root, fileManager: fileManager)
    return root
  }

  public static func ensureLibraryLayout(at root: URL, fileManager: FileManager = .default) throws {
    try fileManager.createDirectory(at: root, withIntermediateDirectories: true)
    try fileManager.createDirectory(
      at: root.appendingPathComponent("captures", isDirectory: true),
      withIntermediateDirectories: true
    )
    try fileManager.createDirectory(
      at: root.appendingPathComponent(".staging", isDirectory: true),
      withIntermediateDirectories: true
    )
    try fileManager.createDirectory(
      at: root.appendingPathComponent(".quarantine", isDirectory: true),
      withIntermediateDirectories: true
    )
  }

  public var indexURL: URL { libraryRoot.appendingPathComponent("index.json") }
  public var capturesRoot: URL { libraryRoot.appendingPathComponent("captures", isDirectory: true) }
  public var stagingRoot: URL { libraryRoot.appendingPathComponent(".staging", isDirectory: true) }
  public var quarantineRoot: URL { libraryRoot.appendingPathComponent(".quarantine", isDirectory: true) }

  public func captureDirectory(id: String) -> URL {
    capturesRoot.appendingPathComponent(id, isDirectory: true)
  }

  public func stagingDirectory(captureId: String, uuid: String = UUID().uuidString) -> URL {
    stagingRoot.appendingPathComponent("\(captureId)-\(uuid)", isDirectory: true)
  }

  public func artifactOriginalURL(id: String) -> URL {
    captureDirectory(id: id).appendingPathComponent("artifact_original.jpg")
  }

  public func thumbnailURL(id: String) -> URL {
    captureDirectory(id: id).appendingPathComponent("thumbnail.jpg")
  }

  public func exportsDirectory(id: String) -> URL {
    captureDirectory(id: id).appendingPathComponent("exports", isDirectory: true)
  }

  public func exportPackageURL(id: String) -> URL {
    exportsDirectory(id: id).appendingPathComponent("\(id).edts-pkg")
  }

  public func exportPackageSha256URL(id: String) -> URL {
    exportsDirectory(id: id).appendingPathComponent("\(id).edts-pkg.sha256")
  }

  public func sidecarsDirectory(id: String) -> URL {
    captureDirectory(id: id).appendingPathComponent("sidecars", isDirectory: true)
  }

  /// Resolve a library-root-relative path to an absolute URL at runtime.
  public func resolve(_ relativePath: String) -> URL {
    libraryRoot.appendingPathComponent(relativePath)
  }

  public static func relativeOriginalPath(id: String) -> String {
    "captures/\(id)/artifact_original.jpg"
  }

  public static func relativeThumbnailPath(id: String) -> String {
    "captures/\(id)/thumbnail.jpg"
  }

  public static func relativePackagePath(id: String) -> String {
    "captures/\(id)/exports/\(id).edts-pkg"
  }

  public static func relativePackageSha256Path(id: String) -> String {
    "captures/\(id)/exports/\(id).edts-pkg.sha256"
  }
}

/// Atomic JSON / data writers for library metadata (temp + replace).
public enum EvidenceLibraryAtomicIO {
  public static func writeAtomically(_ data: Data, to destination: URL, fileManager: FileManager = .default) throws {
    let dir = destination.deletingLastPathComponent()
    try fileManager.createDirectory(at: dir, withIntermediateDirectories: true)
    let temp = dir.appendingPathComponent(".\(destination.lastPathComponent).\(UUID().uuidString).tmp")
    do {
      try data.write(to: temp, options: [])
      if fileManager.fileExists(atPath: destination.path) {
        let backup = dir.appendingPathComponent(".\(destination.lastPathComponent).bak.\(UUID().uuidString)")
        try fileManager.moveItem(at: destination, to: backup)
        do {
          try fileManager.moveItem(at: temp, to: destination)
          try? fileManager.removeItem(at: backup)
        } catch {
          try? fileManager.moveItem(at: backup, to: destination)
          throw error
        }
      } else {
        try fileManager.moveItem(at: temp, to: destination)
      }
    } catch let e as EvidenceLibraryError {
      try? fileManager.removeItem(at: temp)
      throw e
    } catch {
      try? fileManager.removeItem(at: temp)
      throw EvidenceLibraryError.atomicWriteFailed(String(describing: error))
    }
  }

  /// Exclusive create for originals — never overwrite/truncate.
  public static func writeOnceExact(_ data: Data, to destination: URL, fileManager: FileManager = .default) throws {
    guard !data.isEmpty else {
      throw EvidenceLibraryError.missingArtifact("empty write rejected: \(destination.lastPathComponent)")
    }
    try fileManager.createDirectory(
      at: destination.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if fileManager.fileExists(atPath: destination.path) {
      throw EvidenceLibraryError.refusingOverwrite(destination.path)
    }
    do {
      try data.write(to: destination, options: .withoutOverwriting)
    } catch {
      if fileManager.fileExists(atPath: destination.path) {
        throw EvidenceLibraryError.refusingOverwrite(destination.path)
      }
      throw EvidenceLibraryError.atomicWriteFailed(String(describing: error))
    }
  }
}
