import Foundation

/// Application Support layout for Phase 1C Evidence Library.
///
/// ```
/// Application Support/EvidenceLibrary/
///   index.json
///   <capture-id>/
///     artifact_original.jpg
///     thumbnail.jpg
///     manifest.json
///     package_inventory.json
///     package_status.json
///     capture_device.json
///     sidecars/
///     exports/<capture-id>.edts-pkg
/// ```
public struct EvidenceLibraryPaths: Sendable {
  public var libraryRoot: URL

  public init(libraryRoot: URL) {
    self.libraryRoot = libraryRoot
  }

  /// Default durable root under Application Support (not Caches / tmp).
  public static func defaultLibraryRoot(
    fileManager: FileManager = .default
  ) throws -> URL {
    guard let base = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
      throw EvidenceLibraryError.rootUnavailable("applicationSupportDirectory unavailable")
    }
    let root = base.appendingPathComponent("EvidenceLibrary", isDirectory: true)
    try fileManager.createDirectory(at: root, withIntermediateDirectories: true)
    return root
  }

  /// Test / injectable root (may contain spaces — callers must keep URL-based APIs).
  public static func root(under base: URL, fileManager: FileManager = .default) throws -> URL {
    let root = base.appendingPathComponent("EvidenceLibrary", isDirectory: true)
    try fileManager.createDirectory(at: root, withIntermediateDirectories: true)
    return root
  }

  public var indexURL: URL {
    libraryRoot.appendingPathComponent("index.json")
  }

  public func captureDirectory(id: String) -> URL {
    libraryRoot.appendingPathComponent(id, isDirectory: true)
  }

  public func artifactOriginalURL(id: String) -> URL {
    captureDirectory(id: id).appendingPathComponent("artifact_original.jpg")
  }

  public func thumbnailURL(id: String) -> URL {
    captureDirectory(id: id).appendingPathComponent("thumbnail.jpg")
  }

  public func exportsDirectory(id: String) -> URL {
    captureDirectory(id: id).appendingPathComponent("exports", isDirectory: true)
  }

  public func exportPackageURL(id: String) -> URL {
    exportsDirectory(id: id).appendingPathComponent("\(id).edts-pkg")
  }

  public func sidecarsDirectory(id: String) -> URL {
    captureDirectory(id: id).appendingPathComponent("sidecars", isDirectory: true)
  }
}

/// Atomic JSON / data writers for library metadata (temp + replace).
public enum EvidenceLibraryAtomicIO {
  /// Writes data via temp file in the same directory, then replaces destination.
  public static func writeAtomically(_ data: Data, to destination: URL, fileManager: FileManager = .default) throws {
    let dir = destination.deletingLastPathComponent()
    try fileManager.createDirectory(at: dir, withIntermediateDirectories: true)
    let temp = dir.appendingPathComponent(".\(destination.lastPathComponent).\(UUID().uuidString).tmp")
    do {
      // Avoid Data.write(.atomic) here — on Linux it can leave no stable temp for replaceItemAt.
      try data.write(to: temp, options: [])
      if fileManager.fileExists(atPath: destination.path) {
        // Cross-platform replace: remove then move (same-directory rename).
        let backup = dir.appendingPathComponent(".\(destination.lastPathComponent).bak.\(UUID().uuidString)")
        try fileManager.moveItem(at: destination, to: backup)
        do {
          try fileManager.moveItem(at: temp, to: destination)
          try? fileManager.removeItem(at: backup)
        } catch {
          try? fileManager.moveItem(at: backup, to: destination)
          throw error
        }
      } else {
        try fileManager.moveItem(at: temp, to: destination)
      }
    } catch let e as EvidenceLibraryError {
      try? fileManager.removeItem(at: temp)
      throw e
    } catch {
      try? fileManager.removeItem(at: temp)
      throw EvidenceLibraryError.atomicWriteFailed(String(describing: error))
    }
  }

  /// Write-once exact bytes — refuses overwrite (for artifact_original.jpg).
  public static func writeOnceExact(_ data: Data, to destination: URL, fileManager: FileManager = .default) throws {
    guard !data.isEmpty else {
      throw EvidenceLibraryError.missingArtifact("empty write rejected: \(destination.lastPathComponent)")
    }
    try fileManager.createDirectory(
      at: destination.deletingLastPathComponent(),
      withIntermediateDirectories: true
    )
    if fileManager.fileExists(atPath: destination.path) {
      throw EvidenceLibraryError.refusingOverwrite(destination.path)
    }
    do {
      try data.write(to: destination, options: .withoutOverwriting)
    } catch {
      if fileManager.fileExists(atPath: destination.path) {
        throw EvidenceLibraryError.refusingOverwrite(destination.path)
      }
      // Linux may not honor withoutOverwriting the same way — re-check
      if fileManager.fileExists(atPath: destination.path) {
        throw EvidenceLibraryError.refusingOverwrite(destination.path)
      }
      throw EvidenceLibraryError.atomicWriteFailed(String(describing: error))
    }
  }
}
