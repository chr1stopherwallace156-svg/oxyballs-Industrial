import Foundation

// MARK: - Phase status gate (device validation still required)

/// Exact milestone strings for Phase 1C documentation and runtime checks.
public enum Phase1CStatus {
  /// Initial implementation complete; physical-device proof not yet attached.
  public static let implementedPendingDeviceValidation = "PHASE_1C_IMPLEMENTED_PENDING_DEVICE_VALIDATION"
  /// Only after physical-device acceptance evidence is attached.
  public static let complete = "PHASE_1C_COMPLETE"

  /// Current declared milestone for this tree.
  public static let current = implementedPendingDeviceValidation
}

// MARK: - Orthogonal state dimensions

public enum EvidenceCaptureState: String, Codable, Sendable, CaseIterable, Equatable {
  case captured = "CAPTURED"
  case approved = "APPROVED"
}

public enum EvidenceStorageState: String, Codable, Sendable, CaseIterable, Equatable {
  case pending = "PENDING"
  case storedLocally = "STORED_LOCALLY"
  case missing = "MISSING"
  case unrecognized = "UNRECOGNIZED"
}

public enum EvidencePackageState: String, Codable, Sendable, CaseIterable, Equatable {
  case none = "NONE"
  case created = "CREATED"
  case creationFailed = "CREATION_FAILED"
}

public enum EvidenceExportState: String, Codable, Sendable, CaseIterable, Equatable {
  case notExported = "NOT_EXPORTED"
  case exportedToFiles = "EXPORTED_TO_FILES"
  case shared = "SHARED"
}

public enum EvidenceIntegrityState: String, Codable, Sendable, CaseIterable, Equatable {
  case unverified = "UNVERIFIED"
  case verifiedPass = "VERIFIED_PASS"
  case corruptedHashMismatch = "CORRUPTED_HASH_MISMATCH"
  case corruptedPackage = "CORRUPTED_PACKAGE"
  case missingArtifact = "MISSING_ARTIFACT"
}

/// Orthogonal local evidence state — never collapse into a single linear enum.
public struct LocalEvidenceRecordState: Codable, Sendable, Equatable {
  public var captureState: EvidenceCaptureState
  public var storageState: EvidenceStorageState
  public var packageState: EvidencePackageState
  public var exportState: EvidenceExportState
  public var integrityState: EvidenceIntegrityState

  public init(
    captureState: EvidenceCaptureState = .approved,
    storageState: EvidenceStorageState = .pending,
    packageState: EvidencePackageState = .none,
    exportState: EvidenceExportState = .notExported,
    integrityState: EvidenceIntegrityState = .unverified
  ) {
    self.captureState = captureState
    self.storageState = storageState
    self.packageState = packageState
    self.exportState = exportState
    self.integrityState = integrityState
  }
}

/// Durable index catalog entry. **Non-authoritative** — files on disk are the source of truth.
/// All paths are **relative to EvidenceLibrary/** root (never absolute sandbox URLs).
public struct EvidenceLibraryIndexRecord: Codable, Sendable, Equatable, Identifiable {
  public var id: String
  public var captureTimestamp: Date
  public var sessionId: String
  public var artifactId: String
  public var recordId: String
  public var vehicleOrSessionLabel: String?
  /// e.g. `captures/<id>/artifact_original.jpg`
  public var originalRelativePath: String
  /// e.g. `captures/<id>/thumbnail.jpg`
  public var thumbnailRelativePath: String
  public var originalSha256: String
  public var originalByteCount: Int
  /// e.g. `captures/<id>/exports/<id>.edts-pkg`
  public var packageRelativePath: String?
  public var packageSha256: String?
  public var packageSha256RelativePath: String?
  public var state: LocalEvidenceRecordState
  public var lastIntegrityCheckAt: Date?
  public var storedAt: Date?
  public var updatedAt: Date

  public init(
    id: String,
    captureTimestamp: Date,
    sessionId: String,
    artifactId: String,
    recordId: String,
    vehicleOrSessionLabel: String? = nil,
    originalRelativePath: String,
    thumbnailRelativePath: String,
    originalSha256: String,
    originalByteCount: Int,
    packageRelativePath: String? = nil,
    packageSha256: String? = nil,
    packageSha256RelativePath: String? = nil,
    state: LocalEvidenceRecordState = LocalEvidenceRecordState(),
    lastIntegrityCheckAt: Date? = nil,
    storedAt: Date? = nil,
    updatedAt: Date = Date()
  ) {
    self.id = id
    self.captureTimestamp = captureTimestamp
    self.sessionId = sessionId
    self.artifactId = artifactId
    self.recordId = recordId
    self.vehicleOrSessionLabel = vehicleOrSessionLabel
    self.originalRelativePath = originalRelativePath
    self.thumbnailRelativePath = thumbnailRelativePath
    self.originalSha256 = originalSha256
    self.originalByteCount = originalByteCount
    self.packageRelativePath = packageRelativePath
    self.packageSha256 = packageSha256
    self.packageSha256RelativePath = packageSha256RelativePath
    self.state = state
    self.lastIntegrityCheckAt = lastIntegrityCheckAt
    self.storedAt = storedAt
    self.updatedAt = updatedAt
  }

  public var shortId: String {
    let parts = id.split(separator: "-")
    if let last = parts.last, last.count >= 8 {
      return String(last.prefix(8)).uppercased()
    }
    return String(id.suffix(8)).uppercased()
  }
}

public struct EvidenceLibraryIndexDocument: Codable, Sendable, Equatable {
  public var schemaId: String
  public var schemaVersion: String
  public var phaseStatus: String
  public var records: [EvidenceLibraryIndexRecord]
  public var updatedAt: Date

  public init(
    schemaId: String = "EvidenceLibraryIndex",
    schemaVersion: String = "1.1.0",
    phaseStatus: String = Phase1CStatus.current,
    records: [EvidenceLibraryIndexRecord] = [],
    updatedAt: Date = Date()
  ) {
    self.schemaId = schemaId
    self.schemaVersion = schemaVersion
    self.phaseStatus = phaseStatus
    self.records = records
    self.updatedAt = updatedAt
  }
}

public enum EvidenceLibraryError: Error, Equatable, Sendable {
  case rootUnavailable(String)
  case recordNotFound(String)
  case refusingOverwrite(String)
  case atomicWriteFailed(String)
  case integrityFailed(String)
  case missingArtifact(String)
  case corruptedArtifact(String)
  case packageAttachFailed(String)
  case thumbnailFailed(String)
  case stagingCommitFailed(String)
  case storageGateFailed(String)
}
