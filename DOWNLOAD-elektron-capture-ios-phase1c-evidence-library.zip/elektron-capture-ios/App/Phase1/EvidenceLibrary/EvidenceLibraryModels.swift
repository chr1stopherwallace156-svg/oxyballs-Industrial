import Foundation

/// Phase 1C Evidence Library lifecycle states for UI and validation.
/// These are library-catalog states — distinct from CaptureSideStatus / Pass 2 UI states.
public enum EvidenceLibraryLifecycleState: String, Codable, Sendable, CaseIterable, Equatable {
  case captured = "CAPTURED"
  case approved = "APPROVED"
  case storedLocally = "STORED_LOCALLY"
  case packageCreated = "PACKAGE_CREATED"
  case exported = "EXPORTED"
  case integrityVerified = "INTEGRITY_VERIFIED"
  case missing = "MISSING"
  case corrupted = "CORRUPTED"
}

/// Durable index record for one locally stored evidence capture.
public struct EvidenceLibraryIndexRecord: Codable, Sendable, Equatable, Identifiable {
  public var id: String
  public var captureTimestamp: Date
  public var sessionId: String
  public var artifactId: String
  public var recordId: String
  public var vehicleOrSessionLabel: String?
  public var originalRelativePath: String
  public var thumbnailRelativePath: String
  public var originalSha256: String
  public var originalByteCount: Int
  public var packageRelativePath: String?
  public var packageSha256: String?
  public var captureStatus: EvidenceLibraryLifecycleState
  public var packageStatus: EvidenceLibraryLifecycleState?
  public var exportStatus: EvidenceLibraryLifecycleState?
  public var lastIntegrityCheckAt: Date?
  public var lastIntegrityResult: EvidenceLibraryLifecycleState?
  public var storedAt: Date
  public var updatedAt: Date

  public init(
    id: String,
    captureTimestamp: Date,
    sessionId: String,
    artifactId: String,
    recordId: String,
    vehicleOrSessionLabel: String? = nil,
    originalRelativePath: String = "artifact_original.jpg",
    thumbnailRelativePath: String = "thumbnail.jpg",
    originalSha256: String,
    originalByteCount: Int,
    packageRelativePath: String? = nil,
    packageSha256: String? = nil,
    captureStatus: EvidenceLibraryLifecycleState = .storedLocally,
    packageStatus: EvidenceLibraryLifecycleState? = nil,
    exportStatus: EvidenceLibraryLifecycleState? = nil,
    lastIntegrityCheckAt: Date? = nil,
    lastIntegrityResult: EvidenceLibraryLifecycleState? = nil,
    storedAt: Date = Date(),
    updatedAt: Date = Date()
  ) {
    self.id = id
    self.captureTimestamp = captureTimestamp
    self.sessionId = sessionId
    self.artifactId = artifactId
    self.recordId = recordId
    self.vehicleOrSessionLabel = vehicleOrSessionLabel
    self.originalRelativePath = originalRelativePath
    self.thumbnailRelativePath = thumbnailRelativePath
    self.originalSha256 = originalSha256
    self.originalByteCount = originalByteCount
    self.packageRelativePath = packageRelativePath
    self.packageSha256 = packageSha256
    self.captureStatus = captureStatus
    self.packageStatus = packageStatus
    self.exportStatus = exportStatus
    self.lastIntegrityCheckAt = lastIntegrityCheckAt
    self.lastIntegrityResult = lastIntegrityResult
    self.storedAt = storedAt
    self.updatedAt = updatedAt
  }

  /// Short ID for list UI (last segment of UUID-ish id).
  public var shortId: String {
    let parts = id.split(separator: "-")
    if let last = parts.last, last.count >= 8 {
      return String(last.prefix(8)).uppercased()
    }
    return String(id.suffix(8)).uppercased()
  }
}

/// On-disk index document (rebuildable from capture directories).
public struct EvidenceLibraryIndexDocument: Codable, Sendable, Equatable {
  public var schemaId: String
  public var schemaVersion: String
  public var records: [EvidenceLibraryIndexRecord]
  public var updatedAt: Date

  public init(
    schemaId: String = "EvidenceLibraryIndex",
    schemaVersion: String = "1.0.0",
    records: [EvidenceLibraryIndexRecord] = [],
    updatedAt: Date = Date()
  ) {
    self.schemaId = schemaId
    self.schemaVersion = schemaVersion
    self.records = records
    self.updatedAt = updatedAt
  }
}

public enum EvidenceLibraryError: Error, Equatable, Sendable {
  case rootUnavailable(String)
  case recordNotFound(String)
  case refusingOverwrite(String)
  case atomicWriteFailed(String)
  case integrityFailed(String)
  case missingArtifact(String)
  case corruptedArtifact(String)
  case packageAttachFailed(String)
  case thumbnailFailed(String)
}
