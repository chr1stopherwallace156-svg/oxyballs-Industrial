import Foundation
import XCTest
@testable import ElektronCapture

final class EvidenceLibraryTests: XCTestCase {
  private var baseRoot: URL!
  private var libraryRoot: URL!

  override func setUp() {
    super.setUp()
    baseRoot = FileManager.default.temporaryDirectory
      .appendingPathComponent("Evidence Library Tests \(UUID().uuidString)", isDirectory: true)
    try? FileManager.default.createDirectory(at: baseRoot, withIntermediateDirectories: true)
    libraryRoot = try! EvidenceLibraryPaths.root(under: baseRoot)
  }

  override func tearDown() {
    try? FileManager.default.removeItem(at: baseRoot)
    super.tearDown()
  }

  private var fixtureJPEG: Data {
    Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
      0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14,
      0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7F, 0xFF, 0xD9,
    ])
  }

  private func ids(_ suffix: String = UUID().uuidString) -> Phase1CaptureIdentifiers {
    Phase1CaptureIdentifiers(
      evidenceId: "EVD-\(suffix)",
      sessionId: "SESSION-\(suffix)",
      artifactId: "ART-\(suffix)",
      recordId: "REC-\(suffix)"
    )
  }

  func testStoreApprovedPreservesExactBytesAndHash() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    let jpeg = fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let captureIds = ids()
    let record = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: captureIds)

    XCTAssertEqual(record.captureStatus, .storedLocally)
    XCTAssertEqual(record.originalSha256, sha)

    let onDisk = try Data(contentsOf: paths.artifactOriginalURL(id: captureIds.evidenceId))
    XCTAssertEqual(onDisk, jpeg)
    XCTAssertEqual(ArtifactHashingService().sha256HexOfData(onDisk), sha)

    let thumb = try Data(contentsOf: paths.thumbnailURL(id: captureIds.evidenceId))
    XCTAssertFalse(thumb.isEmpty)
    XCTAssertNotEqual(thumb, jpeg)
  }

  func testOverwriteOfApprovedOriginalThrows() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    let jpeg = fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let captureIds = ids()
    _ = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: captureIds)

    do {
      try await store.assertCannotOverwriteOriginal(id: captureIds.evidenceId, newBytes: Data(jpeg + [0x00]))
      XCTFail("expected refusingOverwrite")
    } catch EvidenceLibraryError.refusingOverwrite {
      // expected
    } catch {
      XCTFail("unexpected \(error)")
    }

    let onDisk = try Data(contentsOf: paths.artifactOriginalURL(id: captureIds.evidenceId))
    XCTAssertEqual(onDisk, jpeg)
  }

  func testAtomicWriteFailureAndRecovery() throws {
    let dest = libraryRoot.appendingPathComponent("atomic-test.json")
    let payload1 = Data(#"{"ok":1}"#.utf8)
    try EvidenceLibraryAtomicIO.writeAtomically(payload1, to: dest)
    XCTAssertEqual(try Data(contentsOf: dest), payload1)

    let payload2 = Data(#"{"ok":2,"recovered":true}"#.utf8)
    try EvidenceLibraryAtomicIO.writeAtomically(payload2, to: dest)
    XCTAssertEqual(try Data(contentsOf: dest), payload2)

    let leftovers = try FileManager.default.contentsOfDirectory(at: libraryRoot, includingPropertiesForKeys: nil)
      .filter { $0.lastPathComponent.contains(".tmp") }
    XCTAssertTrue(leftovers.isEmpty)
  }

  func testFullIndexRebuildFromDisk() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    let jpeg = fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let a = ids("AAA")
    let b = ids("BBB")
    _ = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: a)
    _ = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: b)

    try FileManager.default.removeItem(at: paths.indexURL)

    let rebuilt = try await store.rebuildIndexFromDisk()
    let idsFound = Set(rebuilt.records.map(\.id))
    XCTAssertTrue(idsFound.contains(a.evidenceId))
    XCTAssertTrue(idsFound.contains(b.evidenceId))
    for r in rebuilt.records {
      XCTAssertEqual(r.originalSha256, sha)
    }
  }

  func testMissingAndCorruptedDetection() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    let jpeg = fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let captureIds = ids()
    _ = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: captureIds)

    let art = paths.artifactOriginalURL(id: captureIds.evidenceId)
    var mutated = jpeg
    mutated[mutated.count - 2] ^= 0xFF
    try mutated.write(to: art, options: .atomic)

    let bad = try await store.verifyIntegrity(id: captureIds.evidenceId)
    XCTAssertEqual(bad.state, .corrupted)

    try FileManager.default.removeItem(at: art)
    let missing = try await store.verifyIntegrity(id: captureIds.evidenceId)
    XCTAssertEqual(missing.state, .missing)

    let doc = try await store.reconcileOnLaunch()
    XCTAssertTrue(doc.records.contains { $0.id == captureIds.evidenceId })
  }

  func testNonDestructivePackageReExportAndHashEquality() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    let jpeg = fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let captureIds = ids()
    _ = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: captureIds)

    let workRoot = baseRoot.appendingPathComponent("CapturePackages", isDirectory: true)
    try FileManager.default.createDirectory(at: workRoot, withIntermediateDirectories: true)

    let coordinator = Phase1CaptureCoordinator(
      appVersion: "0.1.4-test",
      photoCapture: FixtureStillPhotoCaptureService(jpegBytes: jpeg),
      workRoot: workRoot
    )
    let approved = ApprovedStillCapture(jpegBytes: jpeg, sha256: sha)
    let result = try coordinator.exportApproved(approved, ids: captureIds)
    XCTAssertEqual(result.artifactSha256, sha)

    let attached = try await store.attachPackage(
      evidenceId: captureIds.evidenceId,
      packageResult: result,
      markExported: true
    )
    XCTAssertEqual(attached.packageStatus, .packageCreated)
    XCTAssertEqual(attached.exportStatus, .exported)
    XCTAssertEqual(attached.originalSha256, sha)

    let libraryOriginal = try Data(contentsOf: paths.artifactOriginalURL(id: captureIds.evidenceId))
    XCTAssertEqual(libraryOriginal, jpeg)

    XCTAssertTrue(FileManager.default.fileExists(atPath: result.packageZipURL.path))

    let copyDest = baseRoot.appendingPathComponent("reexport copy \(UUID().uuidString).edts-pkg")
    let copied = try await store.copyExportPackage(id: captureIds.evidenceId, to: copyDest)
    XCTAssertTrue(FileManager.default.fileExists(atPath: copied.path))
    XCTAssertTrue(FileManager.default.fileExists(atPath: paths.exportPackageURL(id: captureIds.evidenceId).path))

    let verified = try await store.verifyIntegrity(id: captureIds.evidenceId)
    XCTAssertEqual(verified.state, .integrityVerified)
    XCTAssertEqual(verified.currentOriginalSha256, sha)
    XCTAssertEqual(verified.packagePayloadMatchesOriginal, true)
  }

  func testPathsWithSpacesSupported() async throws {
    XCTAssertTrue(baseRoot.path.contains(" "))
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let jpeg = fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let captureIds = ids("SPACE")
    let record = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: captureIds)
    XCTAssertEqual(record.id, captureIds.evidenceId)
    let listed = try await store.listRecordsNewestFirst()
    XCTAssertEqual(listed.first?.id, captureIds.evidenceId)
  }

  func testRetakeGetsNewCaptureIdDoesNotOverwrite() async throws {
    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    let jpeg = fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let first = ids("FIRST")
    let second = ids("SECOND")
    _ = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: first)
    _ = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: second)

    let listed = try await store.listRecordsNewestFirst()
    XCTAssertEqual(Set(listed.map(\.id)).count, 2)
    XCTAssertEqual(
      try Data(contentsOf: paths.artifactOriginalURL(id: first.evidenceId)),
      jpeg
    )
  }
}
