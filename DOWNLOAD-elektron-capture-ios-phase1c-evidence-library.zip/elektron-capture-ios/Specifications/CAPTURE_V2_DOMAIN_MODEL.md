# CAPTURE V2 DOMAIN MODEL SPECIFICATION

| Field | Value |
|---|---|
| Status | **V2_SPEC_BASELINE_REVIEW** (hardened entity schemas) |
| Depends on | `ELEKTRON_CAPTURE_V2_SPEC.md` |
| Next | `CAPTURE_SENSOR_FRAMEWORK.md` |

## 1. Complete Entity Map

```text
InspectionSession (sessionID, temporaryVehicleRef)
    └── GuidedSequence (sequenceID)
            └── CapturePoint (pointID, isRequired)
                    └── CaptureAttempt (attemptID, attemptIndex)
                            ├── CandidateFrame (in-memory)
                            └── CommittedArtifact (immutable, hashed)
                                    └── SupersessionRecord (supersededByID)
```

Supporting records (bound to session / attempt):

- `SensorRecord` / `TelemetryRecord` — \(t_0\)-aligned; reference `attemptID`
- `QualityAssessment` — capture-level or session/export-level outcome
- `CapabilitySnapshot` — immutable hardware capability at session init
- `EvidencePackage` — canonical `.edts-pkg` (manifest, RAW payloads, derived telemetry)

## 2. Enforceable Retake Invariant

```text
CaptureAttempt A (attemptIndex: 1)
  └── CommittedArtifact A (SHA-256: <full 64-char digest>)

[User initiates Retake at CapturePoint]

CaptureAttempt B (attemptIndex: 2)
  └── CommittedArtifact B (SHA-256: <different full digest>)
  └── SupersessionRecord (supersedes: Artifact A, reason: "…")

Result: Artifact A remains untouched, locked, and fully hash-verifiable in the manifest.
```

**Invariant:** Retakes never overwrite or delete prior RAW bytes. Supersession is additive lineage only.

## 3. `InspectionSession`

| Field | Notes |
|---|---|
| `sessionID` | UUIDv4 — primary identity |
| `temporaryVehicleReference` | Optional human label |
| `observedVIN` / `verifiedVIN` / `vehicleUnitID` | Optional; **session identity never depends on VIN** |
| Lifecycle | `draft` → `active` → `paused` → `completed` → `exported` |
| `capabilitySnapshotID` | References immutable `CapabilitySnapshot` taken at init |

Session state must persist across interruption and recover without mutating RAW artifacts.

Export eligibility uses session/export outcomes: `COMPLETE` | `INCOMPLETE` | `BLOCK_EXPORT` (see Quality Policy).

## 4. `GuidedSequence` & `CapturePoint`

| Entity | Fields / rules |
|---|---|
| `GuidedSequence` | `sequenceID`; ordered list of `CapturePoint` |
| `CapturePoint` | `pointID`; `requirementLevel`: `REQUIRED_POINT` \| `OPTIONAL_POINT` |
| Ordering | Stable step index for UI (“Step 3/8: Battery Bay”) |

`REQUIRED_POINT` incompleteness contributes to session `INCOMPLETE` / may `BLOCK_EXPORT`.  
`OPTIONAL_POINT` skip may `WARN` without blocking export unless policy says otherwise.

## 5. `CaptureAttempt`

| Field | Notes |
|---|---|
| `attemptID` | UUIDv4 |
| `attemptIndex` | Monotonic per `CapturePoint` (1, 2, …) |
| Binding | Owns zero or one committed optical artifact plus related sensor/telemetry records |

Each shutter/commit cycle that freezes evidence is a new attempt — never a mutation of a prior attempt’s RAW.

## 6. `CandidateFrame` vs `CommittedArtifact`

| Type | Mutability | Quality | Persistence |
|---|---|---|---|
| `CandidateFrame` | Ephemeral / in-memory | Evaluated by `CaptureQualityPolicy` (capture-level) | Not evidence until commit |
| `CommittedArtifact` | Immutable | `QualityAssessment` recorded | Hashed; library + package reference |

Commit is the `RAW_EVIDENCE` freeze boundary (aligned with Phase 1 still-capture freeze semantics).

## 7. `SupersessionRecord`

| Field | Notes |
|---|---|
| `supersedesArtifactID` | Prior committed artifact |
| `supersededByArtifactID` | Newer committed artifact |
| `reason` | Operator- or policy-supplied string |
| Rule | Preserves raw capture lineage; never deletes historical evidence |

Manifest / inventory list **both** artifacts.

## 8. `SensorRecord` & `TelemetryRecord`

- Bound to session monotonic timeline and `attemptID` (when applicable)
- Carry precision timebase fields per Sensor Framework (`monotonicTimestamp`, optional `wallClockTimestamp`, `clockAnchor` reference)
- Optional sensor failure → `WARN` + error record; continue capture
- Required sensor failure for point → `BLOCK_CAPTURE`; for export completeness → session `INCOMPLETE` / `BLOCK_EXPORT`

## 9. `QualityAssessment`

| Scope | Allowed outcomes |
|---|---|
| Capture-level | `PASS` · `WARN` · `BLOCK_CAPTURE` |
| Session/export-level | `COMPLETE` · `INCOMPLETE` · `BLOCK_EXPORT` |

Holds metric IDs, versions, scores, and policy stage (`OBSERVE_ONLY` … `BLOCK_ACTIVE`). Never a learned classifier label.

## 10. `CapabilitySnapshot`

Immutable hardware capability state captured **at session initialization**, before any sensor stream starts. UI and policy may only offer controls present in this snapshot (plus honest degradation if hardware changes mid-session — change requires new snapshot / session rules in Capability Matrix).

## 11. `EvidencePackage`

Canonical `.edts-pkg` output: manifest, `RAW_EVIDENCE` payloads, `DERIVED_EVIDENCE` with RAW ID + pipeline version references, inventory under Canonical Identity path keys. Extends Phase 1 only via versioned compatible contracts.

## 12. Compatibility with Phase 1C Evidence Library

Phase 1C local library remains the durable still-photo store. v2 sessions may reference library capture IDs; they must not break write-once `artifact_original.jpg` or Canonical Identity path keys.
