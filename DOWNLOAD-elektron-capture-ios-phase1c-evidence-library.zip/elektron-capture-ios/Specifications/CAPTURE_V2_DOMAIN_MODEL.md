# CAPTURE V2 DOMAIN MODEL SPECIFICATION

| Field | Value |
|---|---|
| Status | **DRAFT** |
| Depends on | `ELEKTRON_CAPTURE_V2_SPEC.md` |
| Next | `CAPTURE_SENSOR_FRAMEWORK.md` |

## 1. Hierarchy

```text
InspectionSession
  └── GuidedSequence (optional)
        └── CapturePoint (ordered steps)
              └── CandidateFrame  → (policy) → CommittedArtifact
                    └── TelemetryRecord / SensorRecord (t0-aligned)
```

## 2. `InspectionSession`

| Field | Notes |
|---|---|
| `sessionID` | UUIDv4 — primary identity |
| `temporaryVehicleReference` | Optional human label |
| `observedVIN` / `verifiedVIN` / `vehicleUnitID` | Optional; **identity never depends on VIN** |
| Lifecycle | `draft` → `active` → `paused` → `completed` → `exported` |

Session state must persist across interruption and recover without mutating RAW artifacts.

## 3. `CapturePoint` & `GuidedSequence`

- Ordered viewpoints (e.g. `Step 3/8: Battery Bay`)
- Retakes create **new** artifact versions (supersession), never overwrite RAW bytes
- Superseded artifacts remain addressable for audit

## 4. `CandidateFrame` vs `CommittedArtifact`

| Type | Mutability | Quality | Persistence |
|---|---|---|---|
| `CandidateFrame` | Ephemeral / in-memory | Evaluated by `CaptureQualityPolicy` | Not evidence until commit |
| `CommittedArtifact` | Immutable | Policy outcome recorded | Hashed; library + package reference |

Commit is the RAW freeze boundary (aligned with Phase 1 still-capture freeze semantics).

## 5. `TelemetryRecord` & `SensorRecord`

- Samples from any `EvidenceSensor`
- Timestamps relative to session monotonic \(t_0\)
- Incomplete **optional** auxiliary telemetry may WARN; must not erase optical commit eligibility without policy
- Sensors marked **required** by the active workflow make the capture point incomplete and may BLOCK session export (see Sensor Framework §6)

## 6. Supersession Mechanics

1. New capture at same `CapturePoint` → new `CommittedArtifact` with new ID  
2. Prior artifact marked `supersededBy`  
3. Manifest / inventory list both; RAW files never rewritten  

## 7. Compatibility with Phase 1C Evidence Library

Phase 1C local library (`EvidenceLibrary/`) remains the durable still-photo store. v2 sessions may reference library capture IDs; they must not break write-once `artifact_original.jpg` or Canonical Identity path keys.
