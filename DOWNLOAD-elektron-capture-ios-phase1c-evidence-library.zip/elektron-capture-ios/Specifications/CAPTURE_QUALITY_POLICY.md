# CAPTURE QUALITY POLICY

| Field | Value |
|---|---|
| Status | **DRAFT** (Spec 6) |
| Depends on | `ELEKTRON_CAPTURE_V2_SPEC.md`, `CAPTURE_V2_DOMAIN_MODEL.md`, `CAPTURE_TELEMETRY_CONTRACT.md` |
| Next | Spatial specs (7–8) after 4–6 review |
| Production code | **None** |

## 1. Purpose

Define **deterministic**, versioned, resolution-normalized metrics and dual-tier outcomes that gate commit and export — without learned interpretation.

## 2. Dual-Tier Outcomes

### 2.1 Capture-level (immediate frame feedback)

| Outcome | Meaning |
|---|---|
| `PASS` | Metrics within accept band; commit allowed |
| `WARN` | Soft defect; commit allowed with recorded warning |
| `BLOCK_CAPTURE` | Commit forbidden; user must retry |

Evaluates single-shot optical metrics (e.g. sharpness, exposure clipping) for the current `CandidateFrame` / attempt.

### 2.2 Session / export-level (batch completeness)

| Outcome | Meaning |
|---|---|
| `COMPLETE` | Required points + required sensors satisfied |
| `INCOMPLETE` | Missing required point or required sensor record |
| `BLOCK_EXPORT` | Packaging boundary refuses `.edts-pkg` emission |

Session/export tier does **not** reuse capture-level `PASS`/`WARN` as synonyms for completeness.

## 3. Enforcement Rollout Ladder

| Stage | Behavior |
|---|---|
| `OBSERVE_ONLY` | Compute + log; never block |
| `WARN_ONLY` | Surface warnings; never block |
| `BLOCK_ELIGIBLE` | Policy may block but feature-flagged off by default |
| `BLOCK_ACTIVE` | `BLOCK_CAPTURE` / `BLOCK_EXPORT` enforced |

Promotion between stages requires ADR + fixture evidence — not silent threshold edits in production.

## 4. Metric Contract

Every metric declaration MUST include:

| Field | Rule |
|---|---|
| `metricID` | Stable string |
| `metricVersion` | Semver; score incomparable across versions without explicit map |
| `normalization` | Resolution / sensor normalization recipe |
| `algorithm` | Deterministic description or reference implementation ID |
| `thresholds` | Per-stage bands for PASS / WARN / BLOCK |
| `learned` | **Always `false` in production** |

Examples (names only — thresholds TBD in fixtures):

- `sharpness.laplacianVar`
- `exposure.histogramClip`
- `focus.estimate` (non-learned; optical/metadata only)

## 5. `QualityAssessment` Schema Intent

```text
QualityAssessment
  scope: capture | sessionExport
  subjectID: attemptID | sessionID
  outcome: PASS|WARN|BLOCK_CAPTURE  OR  COMPLETE|INCOMPLETE|BLOCK_EXPORT
  policyStage: OBSERVE_ONLY|…
  metrics[]: { metricID, metricVersion, value, band }
  blockingReasons[]: stable reason codes
```

## 6. Interaction with Required Sensors

| Condition | Capture-level | Session/export-level |
|---|---|---|
| Optional sensor fail | usually `WARN` | usually still `COMPLETE` if points done |
| Required-for-point sensor fail | `BLOCK_CAPTURE` | point incomplete → may `INCOMPLETE` |
| Required-for-export sensor missing | — | `INCOMPLETE` → `BLOCK_EXPORT` |
| Optical metric `BLOCK_CAPTURE` | no commit | export cannot include that attempt |

## 7. Observe-Before-Block Discipline

1. Ship metric under `OBSERVE_ONLY` with logged distributions  
2. Promote to `WARN_ONLY` after fixture review  
3. Enable `BLOCK_ACTIVE` only with documented false-positive budget  

Silent threshold changes in production builds are forbidden.

## 8. Prohibitions

- No Core ML / YOLO / heuristic component ID as a quality gate
- No damage assessment scores
- No dynamic capture-parameter ML loops

## 9. Acceptance

- Golden frames for each metric version
- Unit tests: outcome matrices for capture vs session tiers
- Proof that `OBSERVE_ONLY` never emits `BLOCK_*`
