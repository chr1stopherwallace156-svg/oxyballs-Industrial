# Specifications — Elektron Capture v2+

Locked engineering specification suite. **Not** compiled by SPM.  
**No production v2 actor/camera code** until Specs 1–6 are reviewed and IR-0001 remains an isolated spike.

## Gate status

| Gate | State |
|---|---|
| `V2_SPEC_BASELINE_REVIEW` (Specs 1–3 hardened) | **Done** (constitutional + domain + sensor) |
| Specs 4–6 drafted | **Done** (draft — review next) |
| Phase 1 freeze `v1.0.0-phase1c` | **Pending** authoritative git tag |
| Production v2 modules | **Blocked** |

## Authoring order

1. `ELEKTRON_CAPTURE_V2_SPEC.md` — **V2_SPEC_BASELINE_REVIEW**
2. `CAPTURE_V2_DOMAIN_MODEL.md` — **V2_SPEC_BASELINE_REVIEW**
3. `CAPTURE_SENSOR_FRAMEWORK.md` — **V2_SPEC_BASELINE_REVIEW**
4. `CAPTURE_DEVICE_CAPABILITY_MATRIX.md` — **DRAFT**
5. `CAPTURE_TELEMETRY_CONTRACT.md` — **DRAFT**
6. `CAPTURE_QUALITY_POLICY.md` — **DRAFT**
7. `SPATIAL_COORDINATE_SYSTEMS.md` *(pending)*
8. `SPATIAL_EVIDENCE_CONTRACT.md` *(pending)*
9. `EXTERNAL_SENSOR_ADAPTER_CONTRACT.md` *(pending)*
10. `GITHUB_INTEGRATION_REVIEW_TEMPLATE.md` *(template present)*

## Approved path forward

```text
[V2_BASELINE_APPROVED]  ← Specs 1–3 hardened
        │
        ├── Specs 4–6 drafted (this change set)
        │
        └── Isolated Research Spike IR-0001
              └── Research/Spikes/IR-0001/  (non-production)
```

## Related

- Integration Report: `Research/IntegrationReports/IR-0001-AVFoundation-Manual-Exposure-and-Focus.md`
- Phase 1C status: `PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_GIT_FREEZE`
