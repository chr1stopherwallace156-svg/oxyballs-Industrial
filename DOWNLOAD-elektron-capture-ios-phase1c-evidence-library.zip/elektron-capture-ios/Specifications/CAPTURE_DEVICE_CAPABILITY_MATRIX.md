# CAPTURE DEVICE CAPABILITY MATRIX

| Field | Value |
|---|---|
| Status | **DRAFT** (Spec 4 — post `V2_BASELINE_APPROVED` for Specs 1–3) |
| Depends on | `ELEKTRON_CAPTURE_V2_SPEC.md`, `CAPTURE_SENSOR_FRAMEWORK.md` |
| Next | `CAPTURE_TELEMETRY_CONTRACT.md` |
| Production code | **None** — registry design only |

## 1. Purpose

Define a deterministic, device-truthful map of what hardware and SDK features may be offered to UI and policy for a given `CapabilitySnapshot`. Controls absent from the snapshot must not appear as available.

## 2. Snapshot Contract

| Field | Rule |
|---|---|
| Timing | Captured at `InspectionSession` init, **before** any stream start |
| Identity | `capabilitySnapshotID` (UUIDv4); immutable for session lifetime |
| Honesty | Unknown / unsupported → explicit `unsupported` or `unavailable`, never silent false |
| Mid-session change | Hardware loss (lens disconnect, permission revoke) → typed degradation event; does **not** rewrite snapshot; may `WARN` / `BLOCK_CAPTURE` / `BLOCK_EXPORT` per policy |

## 3. Capability Dimensions

### 3.1 Optical (AVFoundation)

| Capability key | Type | Notes |
|---|---|---|
| `lens.position` | enum | `wide` · `ultraWide` · `tele` · `dual` · … |
| `exposure.mode.custom` | bool | `isExposureModeSupported(.custom)` |
| `exposure.iso.range` | range | min/max ISO |
| `exposure.duration.range` | range | min/max shutter |
| `focus.mode.locked` | bool | `isFocusModeSupported(.locked)` |
| `focus.lensPosition.range` | range | 0…1 if supported |
| `flash.mode` | enum set | off / on / auto if present |
| `torch` | bool | |
| `photo.format.heif` / `.jpeg` / `.raw` | bool | Device + config dependent |
| `depth.supported` | bool | Dual/TrueDepth/LiDAR as applicable |
| `virtualDevice.switchCost` | enum | `seamless` · `reconfigure` · `unsupported` |

### 3.2 Motion (CoreMotion)

| Capability key | Type | Notes |
|---|---|---|
| `imu.accelerometer` | bool | |
| `imu.gyro` | bool | |
| `imu.deviceMotion` | bool | Attitude / gravity derived path availability |
| `imu.sampleRate.maxHz` | number | Declared max; actual rate in telemetry |

### 3.3 Location / Heading

| Capability key | Type | Notes |
|---|---|---|
| `location.authorized` | enum | auth state at snapshot |
| `location.precise` | bool | reduced accuracy flag |
| `heading.true` / `.magnetic` | bool | |

### 3.4 External (v2.0E side-track)

| Capability key | Type | Notes |
|---|---|---|
| `thermal.adapter.present` | bool | Via `ThermalDeviceAdapter` only |
| `thermal.radiometric` | bool | |

## 4. Requirement Binding

Workflows bind sensors/capabilities to points:

| Binding | Effect on failure |
|---|---|
| `OPTIONAL` | `WARN` + `SensorRecord` error; capture continues |
| `REQUIRED_FOR_CAPTURE_POINT` | `BLOCK_CAPTURE` |
| `REQUIRED_FOR_EXPORT` | Session `INCOMPLETE` → `BLOCK_EXPORT` |

Capability Matrix declares **what exists**. Quality Policy + Domain Model declare **what is required**.

## 5. UI Gating Rules

1. Never show a control for `false` / `unsupported` capability.  
2. Show disabled + reason when capability exists but permission/config blocks use.  
3. IR-0001 spike validates exposure/focus lock queries against this matrix — results land in `Research/Spikes/IR-0001/`, not production.

## 6. Registry Shape (design only)

```text
CaptureDeviceCapabilityRegistry
  └── probe() -> CapabilitySnapshot
  └── supports(key) -> CapabilityAvailability
  └── lensCatalog() -> [LensCapability]
```

No production Swift module is authorized by this draft alone.

## 7. Device Matrix Log (fill per physical validation)

| Device | iOS | Snapshot ID | Notes | Status |
|---|---|---|---|---|
| `[INSERT]` | `[INSERT]` | `[INSERT]` | wide / UW / tele locks | `PENDING` |

## 8. Acceptance

- Unit tests for snapshot immutability and key honesty (when registry lands)
- IR-0001 confirms custom exposure / locked focus query paths on target devices
- No production camera actor until Specs 4–6 READY + IR promotion gate
