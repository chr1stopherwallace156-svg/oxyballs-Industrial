# ELEKTRON CAPTURE V2 — SYSTEM SPECIFICATION (CONSTITUTION)

| Field | Value |
|---|---|
| Status | **DRAFT STUB** (Phase 1 freeze still pending) |
| Depends on | Phase 1A/1C contracts in tree; freeze tag `v1.0.0-phase1c` when authoritative |
| Next specs | Domain Model → Sensor Framework |

## 1. Mission Statement

Elektron Capture v2 is a multi-sensor, calibrated evidence instrument designed to **record, measure, organize, validate, synchronize, and verify** physical vehicle evidence.

## 2. Governing Rule

Capture v2 records, measures, organizes, validates, synchronizes, and verifies physical evidence. It does **NOT**:

- infer component identity via learned models
- diagnose vehicle condition via ML
- make automated pass/fail conclusions from computer vision

ML / YOLO / automated interpretation live only under `Research/Deferred/` with **no production interfaces**.

## 3. Scope Boundaries

### In scope

- Professional optics controls and hardware capability discovery
- Inspection session & guided sequence workflows
- Non-destructive evidence supersession (retakes)
- Deterministic quality metrics with observe-before-block rollout; outcomes are scoped as **capture-level** vs **session/export-level** (`PASS` / `WARN` / `BLOCK` at each level)
- Multi-sensor telemetry sync on monotonic timeline \(t_0\) (timebase only; wall-clock trust is a separate contract)
- Depth maps, \(K\)-matrix intrinsics, 6DoF camera poses (RAW spatial)
- Verifiable evidence packaging (extends Phase 1 `.edts-pkg` without silent contract drift)

### Out of scope (deferred)

- Core ML inference, YOLO, component recognition
- Defect diagnosis / learned capture decisions
- Production on-device 3D mesh generation (RAW inputs only; mesh elsewhere)

## 4. Master Architecture

```text
                    CAPTURE SESSION COORDINATOR
                               │
          ┌────────────────────┴────────────────────┐
          ▼                                         ▼
   SENSOR FRAMEWORK                          WORKFLOW ENGINE
   (EvidenceSensor streams)                  (InspectionSession)
          │                                         │
          └────────────────────┬────────────────────┘
                               ▼
                    EVIDENCE PACKAGING ENGINE
                    • Monotonic sync (t0)
                    • Quality & calibration checks
                    • RAW vs DERIVED boundary
                    • Session & artifact hashing
                               ▼
                      VERIFIED .edts-pkg
```

## 5. Pillar Architecture

1. **Professional Camera** — capability discovery, manual locks, interruption handling  
2. **Engineering Capture** — session/vehicle hierarchy, guided sequences, retakes  
3. **Evidence Quality & Telemetry** — deterministic checks, CoreMotion & sensor telemetry  
4. **Spatial Capture Foundation** — depth, intrinsics, poses (no production mesh)

External thermal hardware uses `ThermalDeviceAdapter` / `EvidenceSensor` — never mixed into AVFoundation capture internals.

## 6. RAW vs DERIVED Boundary

| Category | Examples | Rule |
|---|---|---|
| **RAW** | JPEG/HEIF/DNG, depth maps, IMU samples, \(K\)-matrix, 6DoF poses, radiometric arrays, GPS/heading | Immutable; hashed at commit |
| **DERIVED** | Point clouds, thumbnails, distance measurements, photogrammetry packages | Reconstructible from RAW |

## 7. Quality Policy Rollout Ladder

`OBSERVE_ONLY` → `WARN_ONLY` → `BLOCK_ELIGIBLE` → `BLOCK_ACTIVE`

Sharpness and related scores are **versioned, resolution-normalized deterministic metrics** — not learned scores.

## 8. Implementation Stages

| Stage | Focus |
|---|---|
| **v2.0A** | Camera controls, capability discovery, core telemetry |
| **v2.0B** | Inspection sessions and guided workflows |
| **v2.0C** | Deterministic quality metrics and staged policy enforcement |
| **v2.0D** | Spatial evidence (depth, poses, intrinsics) |
| **v2.0E** | External sensor adapter architecture (**thermal** side-track; approved staging even though product-wise thermal is external-sensor) |

Thermal impact on device load remains **`UNMEASURED`** until profiled in Integration Reports. Do not claim reduced thermal load or “direct hardware register locking” without measured IR evidence.

## 9. Phase 1 Freeze Compatibility

Phase 1A package layout, canonical JSON, hashing, inventory self-hash omit, and Canonical Identity path keys remain authoritative until a versioned ADR changes them. Declaring Phase 1 **frozen** still requires the checklist in `Docs/Capture/PHASE_1C_FINAL_VALIDATION.md`.

## 10. Acceptance Gates (v2 stages)

Each stage requires: approved Integration Report(s), spec sections marked READY, unit tests for new contracts, and Mac/device evidence where hardware-dependent.
