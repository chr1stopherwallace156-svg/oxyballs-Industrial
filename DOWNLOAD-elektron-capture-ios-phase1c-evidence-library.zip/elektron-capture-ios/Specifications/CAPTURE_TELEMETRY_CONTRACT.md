# CAPTURE TELEMETRY CONTRACT

| Field | Value |
|---|---|
| Status | **DRAFT** (Spec 5) |
| Depends on | `CAPTURE_SENSOR_FRAMEWORK.md`, `CAPTURE_V2_DOMAIN_MODEL.md` |
| Next | `CAPTURE_QUALITY_POLICY.md` |
| Production code | **None** |

## 1. Purpose

Define the byte-honest shape of `SensorRecord` / `TelemetryRecord` streams so multi-sensor evidence stays synchronizable, auditable, and free of learned interpretation.

## 2. Record Classes

| Class | Role |
|---|---|
| `SensorRecord` | One sample or sample burst from an `EvidenceSensor` |
| `TelemetryRecord` | Session- or attempt-scoped aggregate / status (e.g. interruption, thermal pressure class, permission change) |
| `QualityAssessment` | Deterministic metric outcomes (not telemetry samples) — see Quality Policy |

## 3. Mandatory Time Fields

Every `SensorRecord` MUST include:

| Field | Required | Notes |
|---|---|---|
| `recordID` | yes | UUIDv4 |
| `sessionID` | yes | |
| `attemptID` | when bound to attempt | |
| `sensorID` / `sensorType` | yes | |
| `monotonicTimestamp` | yes | Relative or absolute monotonic per Sensor Framework |
| `sensorNativeTimestamp` | when hardware provides | e.g. CMSampleBuffer PTS |
| `wallClockTimestamp` | optional | Bound label only |
| `clockAnchorID` | yes | References session `clockAnchor` |
| `clockSource` | if wall present | `.systemClock` · `.ntpServer` · `.gpsLocation` |
| `clockUncertainty` | if wall present | Explicit bounds; unknown → declared unknown |

**Integrity:** Monotonic ordering is the sync backbone. Wall-clock fields never silently replace monotonic ordering.

## 4. Payload Classification

| Kind | Evidence class | Rule |
|---|---|---|
| Optical still bytes | `RAW_EVIDENCE` | Hashed at commit |
| IMU sample arrays | `RAW_EVIDENCE` | Immutable after write |
| Depth map buffers | `RAW_EVIDENCE` | |
| Gravity / attitude derived from IMU | `DERIVED_EVIDENCE` | Must cite RAW record IDs + pipeline version |
| Thumbnails | `DERIVED_EVIDENCE` | Must cite optical RAW artifact ID |

## 5. Schema Sketch (normative intent)

```json
{
  "recordID": "uuid",
  "sessionID": "uuid",
  "attemptID": "uuid|null",
  "sensorID": "camera.wide",
  "sensorType": "opticalStill",
  "monotonicTimestamp": 12.345678,
  "sensorNativeTimestamp": 123456789.012,
  "wallClockTimestamp": "2026-07-24T12:00:00.000Z",
  "clockAnchorID": "uuid",
  "clockSource": "systemClock",
  "clockUncertaintyMs": 15,
  "payloadRef": "captures/<id>/artifact_original.jpg",
  "evidenceClass": "RAW_EVIDENCE",
  "derivedFrom": null,
  "pipelineVersion": null,
  "error": null
}
```

Canonical JSON / hashing rules follow Phase 1 contracts when packaged.

## 6. Error & Gap Records

Failures produce records, not silent omission:

| Situation | Record |
|---|---|
| Optional sensor timeout | `SensorRecord` with `error` + capture may continue (`WARN`) |
| Required sensor failure | `error` + `BLOCK_CAPTURE` and/or session `INCOMPLETE` |
| Sample gap detected | Gap `TelemetryRecord` with expected vs actual interval |

## 7. Packaging Placement

- Telemetry and sensor sidecars use Canonical Identity relative paths under the package root
- Inventory declares every file; self-hash omit policy unchanged from Phase 1A
- `DERIVED_EVIDENCE` entries must include `derivedFrom` RAW IDs + `pipelineVersion`

## 8. Prohibitions

- No free-text “AI summary” fields as authoritative telemetry
- No learned component labels in production telemetry schemas
- No wall-clock-only sync without `clockAnchor` + monotonic fields

## 9. Acceptance

- Golden JSON fixtures for record shapes (when implementation lands)
- Cross-sensor ordering tests using monotonic timestamps
- Explicit tests that missing `clockAnchor` fails verification
