# Phase 1C — Persistent Local Evidence Library

## Architecture

Approved captures are stored under **Application Support / EvidenceLibrary** (not `tmp/` or `Caches/`):

```text
Application Support/EvidenceLibrary/
  index.json
  <capture-id>/
    artifact_original.jpg      # exact approved JPEG bytes (write-once)
    thumbnail.jpg              # derived only
    library_status.json
    manifest.json              # after package attach
    package_inventory.json
    package_status.json
    capture_device.json
    sidecars/
    exports/<capture-id>.edts-pkg
```

- **Portable format unchanged:** Documents/`CapturePackages/` `.edts-pkg` export remains the share/Files transport.
- **Library is the working catalog:** reopen, inspect, verify, re-export without weakening package contracts.
- **Immutability:** `artifact_original.jpg` refuses overwrite; Retake allocates a new capture-id.
- **Index rebuild:** `EvidenceLibraryStore.rebuildIndexFromDisk()` / `reconcileOnLaunch()` — never auto-deletes questionable records.

## Lifecycle states

`CAPTURED` · `APPROVED` · `STORED_LOCALLY` · `PACKAGE_CREATED` · `EXPORTED` · `INTEGRITY_VERIFIED` · `MISSING` · `CORRUPTED`

## UI

Tab navigation: **Capture | Evidence Library**

- List: thumbnail, date/time, short ID, status chips
- Detail: full-res view (decode-only), hashes, metadata, verify, re-export `.edts-pkg`, save JPEG copy
- Disclaimer: deleting the app removes app-private storage until Phase 2+ cloud sync

## Key types

| Type | Path |
|---|---|
| `EvidenceLibraryStore` | `App/Phase1/EvidenceLibrary/EvidenceLibraryStore.swift` |
| `EvidenceLibraryIndexRecord` | `EvidenceLibraryModels.swift` |
| `EvidenceLibraryIntegrityService` | `EvidenceLibraryIntegrity.swift` |
| UI | `Apps/Phase1StillCapture/EvidenceLibraryViews.swift` |

## Tests

```bash
swift test --filter EvidenceLibraryTests
```

## Physical device checklist (manual)

1. Capture + approve → appears in Evidence Library  
2. Force-quit + relaunch → record persists  
3. Restart iPhone + relaunch → record persists  
4. Export `.edts-pkg` → payload JPEG SHA-256 == library canonical  
5. Cancel Share sheet → library record untouched  

Mac `xcodebuild` / physical device runtime: **operator-owned** on Linux CI (`HANDOFF_XCODE_BUILD_SKIPPED`).
