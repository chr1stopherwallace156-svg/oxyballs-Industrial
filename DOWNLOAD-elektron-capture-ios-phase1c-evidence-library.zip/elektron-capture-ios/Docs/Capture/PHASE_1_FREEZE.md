# Phase 1 Freeze Notice

| Field | Value |
|---|---|
| Status | **PENDING** — not frozen |
| Milestone | `PHASE_1C_COMPLETE_PENDING_REPOSITORY_COMMIT_AND_TAG` |
| Tag | *None authoritative* (`v1.0.0-phase1c` must not be treated as freeze until remote annotated tag exists) |
| Validation record | `Docs/Capture/PHASE_1C_FINAL_VALIDATION.md` |

## Why not frozen yet

1. Operator validation that claimed freeze ran in a **ZIP snapshot without `.git`**, so commit/branch/tag claims from that tree are unsupported.  
2. Full 64-character SHA-256 digests for manifest artifact, independent JPEG, and `.edts-pkg` are not recorded in the validation document.  
3. Physical acceptance rows lack per-step evidence citations.  
4. There is **no** standard `git lock-branch` command; host branch protection is required for policy freeze.

## Intended frozen contracts (do not change without versioned ADR — when freeze completes)

- Phase 1A `.edts-pkg` layout and PackageInventory self-hash omit policy  
- Canonical JSON byte-identity rules  
- Artifact JPEG write-once / SHA-256 freeze semantics  
- Capture-side status ownership (no EDTS-owned status assignment)  
- Canonical Identity Pattern for package-relative paths (`PackageRelativePath`)

## Allowed now (pre-freeze)

- Correct validation metadata and evidence citations  
- Capture v2 **draft** specifications under `Specifications/`  
- Research spikes and Integration Reports under `Research/`  
- Production Phase 1 contract changes only via explicit ADR (still discouraged)

## Freeze mechanism (when ready)

1. Authoritative clone: clean tree, known `HEAD`, known branch, known `origin`.  
2. Annotated tag `v1.0.0-phase1c` on that commit; push tag; verify remote.  
3. GitHub branch protection / tag rules for the Phase 1 baseline.  
4. Validation document updated with full digests + cited device matrix → status `PHASE_1C_COMPLETE` / `PHASE_1_FROZEN`.
