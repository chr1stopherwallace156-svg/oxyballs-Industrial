# Error dictionary — Elektron Capture iOS

Use:

```bash
./Scripts/diagnose.sh "<paste error text or short key>"
```

Each entry: **error class**, ordered causes, checks, safe fixes, prohibited actions, proof of resolution.

---

## Cannot find CameraPreviewView in scope

| Field | Value |
|---|---|
| **Error class** | `CROSS_MODULE_VISIBILITY` |
| **Likely causes** | 1) `CameraPreviewView` not `public` in package 2) App missing `import ElektronCapture` 3) Wrong/stale repo copy open 4) Package cache pointing elsewhere |
| **Checks** | `grep -n "public struct CameraPreviewView" App/Capture/AVFoundation/CameraPreviewView.swift`; `grep -n "import ElektronCapture" Apps/Phase1StillCapture/Phase1CaptureRootView.swift`; `./Scripts/doctor.sh`; `./Scripts/repo-locator.sh` |
| **Safe corrective actions** | Use tip with public API; open root `Phase1StillCapture.xcworkspace`; Reset Package Caches; `make repair-package-cache` (instructions only) |
| **Prohibited** | Copying `CameraPreviewView.swift` into the app target; weakening tests |
| **Proof** | `xcodebuild` `BUILD SUCCEEDED`; doctor PASS on CameraPreviewView visibility |

---

## Cannot find Phase1StillCaptureUIState / PendingStillCapture / ApprovedStillCapture / InteractiveStillCaptureController in scope

| Field | Value |
|---|---|
| **Error class** | `MISSING_MODULE_IMPORT` |
| **Likely causes** | 1) App `.swift` lacks `import ElektronCapture` 2) Product not linked 3) Wrong workspace |
| **Checks** | Import in that file; pbxproj `ElektronCapture in Frameworks`; open root workspace |
| **Safe corrective actions** | Add `import ElektronCapture`; `make doctor`; `make verify` |
| **Prohibited** | Duplicating types into app |
| **Proof** | Clean app build succeeds |

---

## Missing package product 'ElektronCapture'

| Field | Value |
|---|---|
| **Error class** | `PACKAGE_PRODUCT_RESOLUTION` |
| **Likely causes** | 1) Opened `.xcodeproj` alone 2) Stale package cache 3) Wrong relativePath / wrong repo copy |
| **Checks** | Root `Phase1StillCapture.xcworkspace` exists; `Package.swift` exports product; pbxproj `relativePath = ../..` from Apps/Phase1StillCapture |
| **Safe corrective actions** | `make open`; File → Packages → Reset Package Caches; `make repair-package-cache` |
| **Prohibited** | Creating a new blank Xcode project |
| **Proof** | Product resolves; build finds module |

---

## package already opened from another project or workspace / project already open

| Field | Value |
|---|---|
| **Error class** | `DUPLICATE_XCODE_SESSION` |
| **Likely causes** | Same tree or sibling clone open in another Xcode window |
| **Checks** | `./Scripts/repo-locator.sh`; quit other Xcode windows for this path |
| **Safe corrective actions** | Close other windows; open only current root workspace |
| **Prohibited** | Deleting other clones automatically |
| **Proof** | Single workspace session; build succeeds |

---

## tool-hosted testing unavailable / cannot run tests on physical device destination

| Field | Value |
|---|---|
| **Error class** | `DEVICE_TEST_DESTINATION_UNSUPPORTED` |
| **Likely causes** | ⌘U / `xcodebuild test` aimed at physical iPhone |
| **Checks** | Destination is Simulator or use `swift test` for package |
| **Safe corrective actions** | `make test`; `make simulator-test` |
| **Prohibited** | Claiming device runtime from failed test action |
| **Proof** | Package or simulator tests pass |

---

## Signing for requires a development team / No Account for Team

| Field | Value |
|---|---|
| **Error class** | `SIGNING_TEAM_MISSING` |
| **Likely causes** | Empty DEVELOPMENT_TEAM; no Apple ID in Xcode |
| **Checks** | Xcode → Settings → Accounts; Signing & Capabilities |
| **Safe corrective actions** | Add Apple ID; Automatic signing; select Team |
| **Prohibited** | Committing private keys / provisioning profiles with secrets |
| **Proof** | `DEVICE_SIGNING_READY` via doctor/preflight; device-build compiles |

---

## codesign / keychain permission / User interaction is not allowed

| Field | Value |
|---|---|
| **Error class** | `CODESIGN_KEYCHAIN_PERMISSION` |
| **Likely causes** | Keychain prompt denied; CI without unlock; wrong identity |
| **Checks** | Sign in GUI Xcode once; unlock login keychain on Mac |
| **Safe corrective actions** | Build from Xcode UI first; allow keychain access |
| **Prohibited** | Pasting passwords into repo scripts/logs |
| **Proof** | Codesign succeeds in build log |

---

## No such file or directory / folder not found

| Field | Value |
|---|---|
| **Error class** | `PATH_NOT_FOUND` |
| **Likely causes** | Unquoted spaces; wrong clone; incomplete ZIP |
| **Checks** | `pwd`; quote paths; `find "$HOME/Downloads" -name Phase1StillCapture.xcworkspace` |
| **Safe corrective actions** | `cd "<quoted path>"`; re-unzip handoff ZIP |
| **Prohibited** | `rm -rf` guessing |
| **Proof** | `make doctor` PASS repository root |

---

## not a git repository

| Field | Value |
|---|---|
| **Error class** | `NO_GIT_METADATA` |
| **Likely causes** | `git archive` ZIP snapshot (expected) |
| **Checks** | `.repository-identity.json` present; source tree complete |
| **Safe corrective actions** | Use ZIP workflows; or clone from bundle if git needed |
| **Prohibited** | Pretending tip SHA without `.git` |
| **Proof** | Doctor WARN only; builds still possible |

---

## Stale package cache / Resolved package versions out of date

| Field | Value |
|---|---|
| **Error class** | `STALE_PACKAGE_CACHE` |
| **Likely causes** | Xcode cache after switching clones |
| **Checks** | `repo-locator`; identity file; workspace path |
| **Safe corrective actions** | Reset Package Caches; reopen root workspace |
| **Prohibited** | Deleting `~/Library` wholesale without confirmation |
| **Proof** | Resolve succeeds against current root |

---

## Duplicate repository copies / confusion which tree is open

| Field | Value |
|---|---|
| **Error class** | `DUPLICATE_REPO_COPIES` |
| **Likely causes** | Multiple Downloads unzip folders |
| **Checks** | `./Scripts/repo-locator.sh` |
| **Safe corrective actions** | Work only in CURRENT; archive others manually |
| **Prohibited** | Auto-delete other copies |
| **Proof** | Doctor/locator shows single intended CURRENT |

---

## LaunchServices error -10814

| Field | Value |
|---|---|
| **Error class** | `LAUNCH_SERVICES_OPEN_FAILURE` |
| **Likely causes** | `open` cannot launch app/workspace; bad path; Xcode missing |
| **Checks** | `ls Phase1StillCapture.xcworkspace`; `xcode-select -p` |
| **Safe corrective actions** | Install/select Xcode; open workspace from Finder; quote path |
| **Prohibited** | Ignoring wrong cwd |
| **Proof** | Workspace opens; scheme visible |

---

## NSCocoaErrorDomain Code=3328 / file provider / Files save failure

| Field | Value |
|---|---|
| **Error class** | `FILES_PROVIDER_EXPORT_FAILURE` |
| **Likely causes** | Document picker / Files entitlement / staging URL invalid |
| **Checks** | Package file exists; Share Sheet path; Info.plist file sharing |
| **Safe corrective actions** | Use Share .edts-pkg; diagnostic ZIP copy; confirm Documents export |
| **Prohibited** | Re-encoding JPEG to “fix” export |
| **Proof** | Non-empty `.edts-pkg` on Mac; `unzip -l` works |

---

## Share sheet / AirDrop / custom UTI presentation failure

| Field | Value |
|---|---|
| **Error class** | `SHARE_PRESENTATION` |
| **Likely causes** | Sharing directory instead of `.edts-pkg` file; UTI; staging |
| **Checks** | Export shows `.edts-pkg` path; Share vs Save to Files; diagnostic ZIP |
| **Safe corrective actions** | Use tip with share presentation fix; Save to Files; ZIP copy |
| **Prohibited** | Mutating `artifact_original.jpg` |
| **Proof** | File arrives on Mac; JPEG SHA matches freeze |

---

## ZIP missing / wrong SHA-256

| Field | Value |
|---|---|
| **Error class** | `HANDOFF_ARTIFACT_MISMATCH` |
| **Likely causes** | Incomplete download; old superseded ZIP |
| **Checks** | `shasum -a 256`; compare Industrial `SHA256SUMS.txt` |
| **Safe corrective actions** | Re-download; discard superseded hashes (e.g. old `9ee9951f…`) |
| **Prohibited** | Editing ZIP contents then claiming tip identity |
| **Proof** | SHA matches published sum; doctor PASS |
