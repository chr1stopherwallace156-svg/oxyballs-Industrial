import Foundation

/// Business logic for inspection session lifecycle and capture metering.
public final class InspectionSessionService: @unchecked Sendable {
  private let repository: any CurrentSessionRepository
  private let idGenerator: any SessionIDGenerating
  private let instantProvider: any InstantProviding
  public var defaultInspector: Inspector

  /// In-memory cache of the restored/current session (repository is source of truth for disk).
  private let lock = NSLock()
  private var cached: InspectionSession?

  public init(
    repository: any CurrentSessionRepository,
    idGenerator: any SessionIDGenerating = ProductionSessionIDGenerator(),
    instantProvider: any InstantProviding = SystemInstantProvider(),
    defaultInspector: Inspector = .localDefault
  ) {
    self.repository = repository
    self.idGenerator = idGenerator
    self.instantProvider = instantProvider
    self.defaultInspector = defaultInspector
  }

  public var currentSession: InspectionSession? {
    lock.lock(); defer { lock.unlock() }
    return cached
  }

  /// Restore unfinished session from repository. Terminal/corrupt handling per repository rules.
  @discardableResult
  public func restoreCurrentSession() async throws -> InspectionSession? {
    do {
      let session = try await repository.load()
      setCache(session)
      return session
    } catch InspectionSessionError.corruptPersistence {
      try? await repository.clear()
      setCache(nil)
      throw InspectionSessionError.corruptPersistence("cleared corrupt current session")
    }
  }

  @discardableResult
  public func startInspection(
    vehicleIdentifierRaw: String,
    inspector: Inspector? = nil
  ) async throws -> InspectionSession {
    if let existing = currentSession, existing.status.isActiveOrPaused {
      throw InspectionSessionError.sessionAlreadyActive
    }
    let identifier = try VehicleIdentifier(rawValue: vehicleIdentifierRaw, kind: .unknown)
    let startedAt = instantProvider.now()
    let session = InspectionSession(
      id: idGenerator.makeSessionID(),
      vehicle: InspectionVehicle(primaryIdentifier: identifier),
      inspector: inspector ?? defaultInspector,
      startedAt: startedAt,
      finishedAt: nil,
      status: .inProgress,
      metrics: SessionMetrics(captureCount: 0)
    )
    try await repository.save(session)
    setCache(session)
    return session
  }

  public func pause() async throws {
    try await transition(to: .paused, finishedAt: nil)
  }

  public func resume() async throws {
    try await transition(to: .inProgress, finishedAt: nil)
  }

  public func complete() async throws {
    try await transition(to: .completed, finishedAt: instantProvider.now())
  }

  public func cancel() async throws {
    try await transition(to: .canceled, finishedAt: instantProvider.now())
  }

  /// Increments captureCount once after a capture is successfully approved and persisted
  /// for an in-progress session. Failed / rejected captures must not call this.
  public func recordSuccessfulCapture() async throws {
    guard var session = currentSession else {
      throw InspectionSessionError.noActiveSession
    }
    guard session.status == .inProgress else {
      throw InspectionSessionError.terminalSessionCannotReceiveCaptures
    }
    session.metrics.captureCount += 1
    try await repository.save(session)
    setCache(session)
  }

  public func evidenceContext(for session: InspectionSession) -> InspectionSessionEvidenceContext {
    let snap = CaptureClockService().snapshot(now: session.startedAt)
    return InspectionSessionEvidenceContext.snapshot(from: session, startedAtUTC: snap.utcISO8601)
  }

  private func transition(to newStatus: SessionStatus, finishedAt: Date?) async throws {
    guard var session = currentSession else {
      throw InspectionSessionError.noActiveSession
    }
    guard Self.canTransition(from: session.status, to: newStatus) else {
      throw InspectionSessionError.illegalStatusTransition(from: session.status, to: newStatus)
    }
    session.status = newStatus
    if newStatus.isTerminal {
      session.finishedAt = finishedAt
    } else {
      // pause/resume must not set finishedAt
      session.finishedAt = nil
    }
    try await repository.save(session)
    setCache(session)
  }

  public static func canTransition(from: SessionStatus, to: SessionStatus) -> Bool {
    switch (from, to) {
    case (.inProgress, .paused),
      (.inProgress, .completed),
      (.inProgress, .canceled),
      (.paused, .inProgress),
      (.paused, .completed),
      (.paused, .canceled):
      return true
    default:
      return false
    }
  }

  private func setCache(_ session: InspectionSession?) {
    lock.lock()
    cached = session
    lock.unlock()
  }
}
