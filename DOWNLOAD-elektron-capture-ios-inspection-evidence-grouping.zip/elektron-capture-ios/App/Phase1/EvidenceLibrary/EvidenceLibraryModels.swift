import Foundation

// MARK: - Phase status gate

/// Exact milestone strings for Phase 1C documentation and runtime checks.
public enum Phase1CStatus {
  /// Initial implementation complete; Mac build + physical-device proof not yet attached.
  public static let implementedPendingDeviceValidation = "PHASE_1C_IMPLEMENTED_PENDING_MAC_AND_DEVICE_VALIDATION"
  /// Mac/ZIP validation passed; authoritative repository equivalence + annotated tag freeze not yet proven.
  public static let validationPassedInZipSnapshotPendingAuthoritativeRepositoryEquivalenceAndFreeze =
    "PHASE_1C_VALIDATION_PASSED_IN_ZIP_SNAPSHOT_PENDING_AUTHORITATIVE_REPOSITORY_EQUIVALENCE_AND_FREEZE"
  /// Compatibility alias for the repository-equivalence status.
  public static let validationPassedInZipSnapshotPendingAuthoritativeGitFreeze =
    validationPassedInZipSnapshotPendingAuthoritativeRepositoryEquivalenceAndFreeze
  /// Shorter alias of ``validationPassedInZipSnapshotPendingAuthoritativeRepositoryEquivalenceAndFreeze``.
  public static let validationPassedPendingRepositoryTag = "PHASE_1C_VALIDATION_PASSED_PENDING_REPOSITORY_TAG"
  /// Reserved: set only after annotated tag + full digests + cited device evidence on the authoritative clone.
  public static let complete = "PHASE_1C_COMPLETE"

  /// Current declared milestone for this tree.
  public static let current = validationPassedInZipSnapshotPendingAuthoritativeRepositoryEquivalenceAndFreeze
}

// MARK: - Orthogonal state dimensions

public enum EvidenceCaptureState: String, Codable, Sendable, CaseIterable, Equatable, Hashable {
  case captured = "CAPTURED"
  case approved = "APPROVED"
}

public enum EvidenceStorageState: String, Codable, Sendable, CaseIterable, Equatable, Hashable {
  case pending = "PENDING"
  case storedLocally = "STORED_LOCALLY"
  case missing = "MISSING"
  case unrecognized = "UNRECOGNIZED"
}

public enum EvidencePackageState: String, Codable, Sendable, CaseIterable, Equatable, Hashable {
  case none = "NONE"
  case created = "CREATED"
  case creationFailed = "CREATION_FAILED"
}

public enum EvidenceExportState: String, Codable, Sendable, CaseIterable, Equatable, Hashable {
  case notExported = "NOT_EXPORTED"
  case exportedToFiles = "EXPORTED_TO_FILES"
  case shared = "SHARED"
}

public enum EvidenceIntegrityState: String, Codable, Sendable, CaseIterable, Equatable, Hashable {
  case unverified = "UNVERIFIED"
  case verifiedPass = "VERIFIED_PASS"
  case corruptedHashMismatch = "CORRUPTED_HASH_MISMATCH"
  case corruptedPackage = "CORRUPTED_PACKAGE"
  case missingArtifact = "MISSING_ARTIFACT"
}

/// Orthogonal local evidence state — never collapse into a single linear enum.
public struct LocalEvidenceRecordState: Codable, Sendable, Equatable, Hashable {
  public var captureState: EvidenceCaptureState
  public var storageState: EvidenceStorageState
  public var packageState: EvidencePackageState
  public var exportState: EvidenceExportState
  public var integrityState: EvidenceIntegrityState

  public init(
    captureState: EvidenceCaptureState = .approved,
    storageState: EvidenceStorageState = .pending,
    packageState: EvidencePackageState = .none,
    exportState: EvidenceExportState = .notExported,
    integrityState: EvidenceIntegrityState = .unverified
  ) {
    self.captureState = captureState
    self.storageState = storageState
    self.packageState = packageState
    self.exportState = exportState
    self.integrityState = integrityState
  }
}

/// Durable index catalog entry. **Non-authoritative** — files on disk are the source of truth.
/// All paths are **relative to EvidenceLibrary/** root (never absolute sandbox URLs).
/// `Hashable` is required for SwiftUI `NavigationLink(value:)` / `navigationDestination(for:)`
/// (synthesized — all stored properties are value types; equality semantics unchanged).
public struct EvidenceLibraryIndexRecord: Codable, Sendable, Equatable, Hashable, Identifiable {
  public var id: String
  public var captureTimestamp: Date
  public var sessionId: String
  public var artifactId: String
  public var recordId: String
  public var vehicleOrSessionLabel: String?
  /// Immutable inspection grouping key when capture was approved under an InspectionSession.
  public var inspectionSessionID: String?
  public var inspectionVehicleIdentifier: String?
  public var inspectionVehicleIdentifierKind: String?
  public var inspectionInspectorID: String?
  public var inspectionInspectorName: String?
  public var inspectionStartedAtUTC: String?
  public var inspectionStatusAtCapture: String?
  /// Development/simulator synthetic evidence — never treated as physical-device verified.
  public var isSynthetic: Bool
  /// e.g. `captures/<id>/artifact_original.jpg`
  public var originalRelativePath: String
  /// e.g. `captures/<id>/thumbnail.jpg`
  public var thumbnailRelativePath: String
  public var originalSha256: String
  public var originalByteCount: Int
  /// e.g. `captures/<id>/exports/<id>.edts-pkg`
  public var packageRelativePath: String?
  public var packageSha256: String?
  public var packageSha256RelativePath: String?
  public var state: LocalEvidenceRecordState
  public var lastIntegrityCheckAt: Date?
  public var storedAt: Date?
  public var updatedAt: Date

  public init(
    id: String,
    captureTimestamp: Date,
    sessionId: String,
    artifactId: String,
    recordId: String,
    vehicleOrSessionLabel: String? = nil,
    inspectionSessionID: String? = nil,
    inspectionVehicleIdentifier: String? = nil,
    inspectionVehicleIdentifierKind: String? = nil,
    inspectionInspectorID: String? = nil,
    inspectionInspectorName: String? = nil,
    inspectionStartedAtUTC: String? = nil,
    inspectionStatusAtCapture: String? = nil,
    isSynthetic: Bool = false,
    originalRelativePath: String,
    thumbnailRelativePath: String,
    originalSha256: String,
    originalByteCount: Int,
    packageRelativePath: String? = nil,
    packageSha256: String? = nil,
    packageSha256RelativePath: String? = nil,
    state: LocalEvidenceRecordState = LocalEvidenceRecordState(),
    lastIntegrityCheckAt: Date? = nil,
    storedAt: Date? = nil,
    updatedAt: Date = Date()
  ) {
    self.id = id
    self.captureTimestamp = captureTimestamp
    self.sessionId = sessionId
    self.artifactId = artifactId
    self.recordId = recordId
    self.vehicleOrSessionLabel = vehicleOrSessionLabel
    self.inspectionSessionID = inspectionSessionID
    self.inspectionVehicleIdentifier = inspectionVehicleIdentifier
    self.inspectionVehicleIdentifierKind = inspectionVehicleIdentifierKind
    self.inspectionInspectorID = inspectionInspectorID
    self.inspectionInspectorName = inspectionInspectorName
    self.inspectionStartedAtUTC = inspectionStartedAtUTC
    self.inspectionStatusAtCapture = inspectionStatusAtCapture
    self.isSynthetic = isSynthetic
    self.originalRelativePath = originalRelativePath
    self.thumbnailRelativePath = thumbnailRelativePath
    self.originalSha256 = originalSha256
    self.originalByteCount = originalByteCount
    self.packageRelativePath = packageRelativePath
    self.packageSha256 = packageSha256
    self.packageSha256RelativePath = packageSha256RelativePath
    self.state = state
    self.lastIntegrityCheckAt = lastIntegrityCheckAt
    self.storedAt = storedAt
    self.updatedAt = updatedAt
  }

  public var shortId: String {
    let parts = id.split(separator: "-")
    if let last = parts.last, last.count >= 8 {
      return String(last.prefix(8)).uppercased()
    }
    return String(id.suffix(8)).uppercased()
  }

  /// Apply immutable inspection context. Refuses reassignment when already stamped.
  public mutating func applyInspectionContext(_ context: InspectionSessionEvidenceContext) throws {
    if let existing = inspectionSessionID, !existing.isEmpty, existing != context.sessionID {
      throw EvidenceLibraryError.refusingOverwrite(
        "inspectionSessionID already set to \(existing); cannot reassign to \(context.sessionID)"
      )
    }
    inspectionSessionID = context.sessionID
    inspectionVehicleIdentifier = context.primaryVehicleIdentifier
    inspectionVehicleIdentifierKind = context.primaryVehicleIdentifierKind
    inspectionInspectorID = context.inspectorID
    inspectionInspectorName = context.inspectorName
    inspectionStartedAtUTC = context.sessionStartedAtUTC
    inspectionStatusAtCapture = context.sessionStatusAtCapture
    if vehicleOrSessionLabel == nil || vehicleOrSessionLabel?.isEmpty == true {
      vehicleOrSessionLabel = context.primaryVehicleIdentifier
    }
  }

  enum CodingKeys: String, CodingKey {
    case id, captureTimestamp, sessionId, artifactId, recordId, vehicleOrSessionLabel
    case inspectionSessionID, inspectionVehicleIdentifier, inspectionVehicleIdentifierKind
    case inspectionInspectorID, inspectionInspectorName, inspectionStartedAtUTC, inspectionStatusAtCapture
    case isSynthetic
    case originalRelativePath, thumbnailRelativePath, originalSha256, originalByteCount
    case packageRelativePath, packageSha256, packageSha256RelativePath
    case state, lastIntegrityCheckAt, storedAt, updatedAt
  }

  public init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    id = try c.decode(String.self, forKey: .id)
    captureTimestamp = try c.decode(Date.self, forKey: .captureTimestamp)
    sessionId = try c.decode(String.self, forKey: .sessionId)
    artifactId = try c.decode(String.self, forKey: .artifactId)
    recordId = try c.decode(String.self, forKey: .recordId)
    vehicleOrSessionLabel = try c.decodeIfPresent(String.self, forKey: .vehicleOrSessionLabel)
    inspectionSessionID = try c.decodeIfPresent(String.self, forKey: .inspectionSessionID)
    inspectionVehicleIdentifier = try c.decodeIfPresent(String.self, forKey: .inspectionVehicleIdentifier)
    inspectionVehicleIdentifierKind = try c.decodeIfPresent(String.self, forKey: .inspectionVehicleIdentifierKind)
    inspectionInspectorID = try c.decodeIfPresent(String.self, forKey: .inspectionInspectorID)
    inspectionInspectorName = try c.decodeIfPresent(String.self, forKey: .inspectionInspectorName)
    inspectionStartedAtUTC = try c.decodeIfPresent(String.self, forKey: .inspectionStartedAtUTC)
    inspectionStatusAtCapture = try c.decodeIfPresent(String.self, forKey: .inspectionStatusAtCapture)
    isSynthetic = try c.decodeIfPresent(Bool.self, forKey: .isSynthetic) ?? false
    originalRelativePath = try c.decode(String.self, forKey: .originalRelativePath)
    thumbnailRelativePath = try c.decode(String.self, forKey: .thumbnailRelativePath)
    originalSha256 = try c.decode(String.self, forKey: .originalSha256)
    originalByteCount = try c.decode(Int.self, forKey: .originalByteCount)
    packageRelativePath = try c.decodeIfPresent(String.self, forKey: .packageRelativePath)
    packageSha256 = try c.decodeIfPresent(String.self, forKey: .packageSha256)
    packageSha256RelativePath = try c.decodeIfPresent(String.self, forKey: .packageSha256RelativePath)
    state = try c.decode(LocalEvidenceRecordState.self, forKey: .state)
    lastIntegrityCheckAt = try c.decodeIfPresent(Date.self, forKey: .lastIntegrityCheckAt)
    storedAt = try c.decodeIfPresent(Date.self, forKey: .storedAt)
    updatedAt = try c.decode(Date.self, forKey: .updatedAt)
  }
}

public struct EvidenceLibraryIndexDocument: Codable, Sendable, Equatable {
  public var schemaId: String
  public var schemaVersion: String
  public var phaseStatus: String
  public var records: [EvidenceLibraryIndexRecord]
  public var updatedAt: Date

  public init(
    schemaId: String = "EvidenceLibraryIndex",
    schemaVersion: String = "1.2.0",
    phaseStatus: String = Phase1CStatus.current,
    records: [EvidenceLibraryIndexRecord] = [],
    updatedAt: Date = Date()
  ) {
    self.schemaId = schemaId
    self.schemaVersion = schemaVersion
    self.phaseStatus = phaseStatus
    self.records = records
    self.updatedAt = updatedAt
  }
}

public enum EvidenceLibraryError: Error, Equatable, Sendable {
  case rootUnavailable(String)
  case recordNotFound(String)
  case refusingOverwrite(String)
  case atomicWriteFailed(String)
  case integrityFailed(String)
  case missingArtifact(String)
  case corruptedArtifact(String)
  case packageAttachFailed(String)
  case thumbnailFailed(String)
  case stagingCommitFailed(String)
  case storageGateFailed(String)
}
