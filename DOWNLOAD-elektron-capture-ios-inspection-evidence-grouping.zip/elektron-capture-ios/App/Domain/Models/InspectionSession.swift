import Foundation

// MARK: - Errors

public enum InspectionSessionError: Error, Equatable, Sendable {
  case invalidSessionID
  case emptyVehicleIdentifier
  case sessionAlreadyActive
  case noActiveSession
  case illegalStatusTransition(from: SessionStatus, to: SessionStatus)
  case terminalSessionCannotReceiveCaptures
  case corruptPersistence(String)
  case persistenceFailed(String)
}

// MARK: - SessionID

public struct SessionID: Hashable, Codable, Sendable, CustomStringConvertible {
  public let rawValue: String

  public init(rawValue: String) throws {
    let trimmed = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { throw InspectionSessionError.invalidSessionID }
    self.rawValue = trimmed
  }

  /// Non-throwing convenience for known-good literals in tests/fixtures.
  public static func unchecked(_ rawValue: String) -> SessionID {
    (try? SessionID(rawValue: rawValue)) ?? SessionID(unsafeUnchecked: rawValue)
  }

  private init(unsafeUnchecked rawValue: String) {
    self.rawValue = rawValue
  }

  public var description: String { rawValue }

  public init(from decoder: Decoder) throws {
    let container = try decoder.singleValueContainer()
    try self.init(rawValue: try container.decode(String.self))
  }

  public func encode(to encoder: Encoder) throws {
    var container = encoder.singleValueContainer()
    try container.encode(rawValue)
  }
}

public protocol SessionIDGenerating: Sendable {
  func makeSessionID() -> SessionID
}

/// Production ID generator: `INS-YYYYMMDD-HHMMSS-XXXX` using UTC + random suffix.
/// Not deterministic — wall clock and randomness are involved.
public struct ProductionSessionIDGenerator: SessionIDGenerating {
  public var instantProvider: any InstantProviding
  public var randomSuffixProvider: @Sendable () -> String

  public init(
    instantProvider: any InstantProviding = SystemInstantProvider(),
    randomSuffixProvider: @escaping @Sendable () -> String = {
      String(UUID().uuidString.prefix(4)).uppercased()
    }
  ) {
    self.instantProvider = instantProvider
    self.randomSuffixProvider = randomSuffixProvider
  }

  public func makeSessionID() -> SessionID {
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.calendar = Calendar(identifier: .gregorian)
    formatter.timeZone = TimeZone(secondsFromGMT: 0)
    formatter.dateFormat = "yyyyMMdd-HHmmss"
    let timestamp = formatter.string(from: instantProvider.now())
    let suffix = randomSuffixProvider()
    return SessionID.unchecked("INS-\(timestamp)-\(suffix)")
  }
}

public struct FixedSessionIDGenerator: SessionIDGenerating {
  public let sessionID: SessionID
  public init(sessionID: SessionID) { self.sessionID = sessionID }
  public func makeSessionID() -> SessionID { sessionID }
}

// MARK: - Instant

public protocol InstantProviding: Sendable {
  func now() -> Date
}

public struct SystemInstantProvider: InstantProviding {
  public init() {}
  public func now() -> Date { Date() }
}

public struct FixedInstantProvider: InstantProviding {
  public var instant: Date
  public init(_ instant: Date) { self.instant = instant }
  public func now() -> Date { instant }
}

// MARK: - Vehicle identifier

public enum VehicleIdentifierKind: String, Codable, Sendable, Equatable {
  case vin = "VIN"
  case licensePlate = "LICENSE_PLATE"
  case fleetNumber = "FLEET_NUMBER"
  case assetNumber = "ASSET_NUMBER"
  case unknown = "UNKNOWN"
}

public struct VehicleIdentifier: Hashable, Codable, Sendable, Equatable {
  public let rawValue: String
  public let kind: VehicleIdentifierKind

  public init(rawValue: String, kind: VehicleIdentifierKind = .unknown) throws {
    let trimmed = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { throw InspectionSessionError.emptyVehicleIdentifier }
    self.rawValue = trimmed
    self.kind = kind
  }

  public func asDictionary() -> [String: Any] {
    [
      "raw_value": rawValue,
      "kind": kind.rawValue,
    ]
  }
}

public struct InspectionVehicle: Codable, Sendable, Equatable {
  public var primaryIdentifier: VehicleIdentifier
  public var vin: String?
  public var licensePlate: String?
  public var fleetNumber: String?
  public var assetNumber: String?
  public var make: String?
  public var model: String?
  public var year: Int?

  public init(
    primaryIdentifier: VehicleIdentifier,
    vin: String? = nil,
    licensePlate: String? = nil,
    fleetNumber: String? = nil,
    assetNumber: String? = nil,
    make: String? = nil,
    model: String? = nil,
    year: Int? = nil
  ) {
    self.primaryIdentifier = primaryIdentifier
    self.vin = vin
    self.licensePlate = licensePlate
    self.fleetNumber = fleetNumber
    self.assetNumber = assetNumber
    self.make = make
    self.model = model
    self.year = year
  }

  public func asDictionary() -> [String: Any] {
    [
      "primary_identifier": primaryIdentifier.asDictionary(),
      "vin": vin.map { $0 as Any } ?? NSNull(),
      "license_plate": licensePlate.map { $0 as Any } ?? NSNull(),
      "fleet_number": fleetNumber.map { $0 as Any } ?? NSNull(),
      "asset_number": assetNumber.map { $0 as Any } ?? NSNull(),
      "make": make.map { $0 as Any } ?? NSNull(),
      "model": model.map { $0 as Any } ?? NSNull(),
      "year": year.map { $0 as Any } ?? NSNull(),
    ]
  }
}

// MARK: - Inspector

public struct Inspector: Codable, Sendable, Equatable {
  public let id: String
  public var name: String
  public var organization: String?
  public var role: String?

  public init(id: String, name: String, organization: String? = nil, role: String? = nil) {
    self.id = id
    self.name = name
    self.organization = organization
    self.role = role
  }

  public static let localDefault = Inspector(
    id: "INSPECTOR-LOCAL",
    name: "Local Inspector",
    organization: nil,
    role: "operator"
  )

  public func asDictionary() -> [String: Any] {
    [
      "id": id,
      "name": name,
      "organization": organization.map { $0 as Any } ?? NSNull(),
      "role": role.map { $0 as Any } ?? NSNull(),
    ]
  }
}

// MARK: - Status / metrics / session

public enum SessionStatus: String, Codable, Sendable, Equatable {
  case inProgress = "IN_PROGRESS"
  case paused = "PAUSED"
  case completed = "COMPLETED"
  case canceled = "CANCELED"

  public var isTerminal: Bool {
    self == .completed || self == .canceled
  }

  public var isActiveOrPaused: Bool {
    self == .inProgress || self == .paused
  }
}

public struct SessionMetrics: Codable, Sendable, Equatable {
  public var captureCount: Int

  public init(captureCount: Int = 0) {
    self.captureCount = captureCount
  }

  public func asDictionary() -> [String: Any] {
    ["capture_count": captureCount]
  }
}

public struct InspectionSession: Identifiable, Codable, Sendable, Equatable {
  public let id: SessionID
  public var vehicle: InspectionVehicle
  public var inspector: Inspector
  public let startedAt: Date
  public var finishedAt: Date?
  public var status: SessionStatus
  public var metrics: SessionMetrics

  public init(
    id: SessionID,
    vehicle: InspectionVehicle,
    inspector: Inspector,
    startedAt: Date,
    finishedAt: Date? = nil,
    status: SessionStatus = .inProgress,
    metrics: SessionMetrics = SessionMetrics()
  ) {
    self.id = id
    self.vehicle = vehicle
    self.inspector = inspector
    self.startedAt = startedAt
    self.finishedAt = finishedAt
    self.status = status
    self.metrics = metrics
  }
}

/// Immutable evidence-package snapshot of inspection context (not the live mutable session).
///
/// Once persisted with a capture, this context must not be reassigned.
public struct InspectionSessionEvidenceContext: Codable, Sendable, Equatable {
  public static let schemaVersion = "1.1.0"

  public let schemaVersion: String
  public let sessionID: String
  public let primaryVehicleIdentifier: String
  public let primaryVehicleIdentifierKind: String
  public let inspectorID: String
  public let inspectorName: String
  public let sessionStartedAtUTC: String
  /// Session status frozen at capture/approve time (e.g. IN_PROGRESS).
  public let sessionStatusAtCapture: String

  public init(
    schemaVersion: String = InspectionSessionEvidenceContext.schemaVersion,
    sessionID: String,
    primaryVehicleIdentifier: String,
    primaryVehicleIdentifierKind: String,
    inspectorID: String,
    inspectorName: String = "",
    sessionStartedAtUTC: String,
    sessionStatusAtCapture: String = SessionStatus.inProgress.rawValue
  ) {
    self.schemaVersion = schemaVersion
    self.sessionID = sessionID
    self.primaryVehicleIdentifier = primaryVehicleIdentifier
    self.primaryVehicleIdentifierKind = primaryVehicleIdentifierKind
    self.inspectorID = inspectorID
    self.inspectorName = inspectorName
    self.sessionStartedAtUTC = sessionStartedAtUTC
    self.sessionStatusAtCapture = sessionStatusAtCapture
  }

  public static func snapshot(
    from session: InspectionSession,
    startedAtUTC: String
  ) -> InspectionSessionEvidenceContext {
    InspectionSessionEvidenceContext(
      sessionID: session.id.rawValue,
      primaryVehicleIdentifier: session.vehicle.primaryIdentifier.rawValue,
      primaryVehicleIdentifierKind: session.vehicle.primaryIdentifier.kind.rawValue,
      inspectorID: session.inspector.id,
      inspectorName: session.inspector.name,
      sessionStartedAtUTC: startedAtUTC,
      sessionStatusAtCapture: session.status.rawValue
    )
  }

  public func asDictionary() -> [String: Any] {
    [
      "schema_id": "InspectionSessionEvidenceContext",
      "schema_version": schemaVersion,
      "session_id": sessionID,
      "primary_vehicle_identifier": primaryVehicleIdentifier,
      "primary_vehicle_identifier_kind": primaryVehicleIdentifierKind,
      "inspector_id": inspectorID,
      "inspector_name": inspectorName,
      "session_started_at_utc": sessionStartedAtUTC,
      "session_status_at_capture": sessionStatusAtCapture,
    ]
  }

  enum CodingKeys: String, CodingKey {
    case schemaVersion
    case sessionID
    case primaryVehicleIdentifier
    case primaryVehicleIdentifierKind
    case inspectorID
    case inspectorName
    case sessionStartedAtUTC
    case sessionStatusAtCapture
  }

  public init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    schemaVersion = try c.decodeIfPresent(String.self, forKey: .schemaVersion) ?? "1.0.0"
    sessionID = try c.decode(String.self, forKey: .sessionID)
    primaryVehicleIdentifier = try c.decode(String.self, forKey: .primaryVehicleIdentifier)
    primaryVehicleIdentifierKind = try c.decode(String.self, forKey: .primaryVehicleIdentifierKind)
    inspectorID = try c.decode(String.self, forKey: .inspectorID)
    inspectorName = try c.decodeIfPresent(String.self, forKey: .inspectorName) ?? ""
    sessionStartedAtUTC = try c.decode(String.self, forKey: .sessionStartedAtUTC)
    sessionStatusAtCapture = try c.decodeIfPresent(String.self, forKey: .sessionStatusAtCapture)
      ?? SessionStatus.inProgress.rawValue
  }

  /// Decode from sidecar / status JSON (supports schema 1.0.0 without status/name).
  public static func decode(from object: [String: Any]) -> InspectionSessionEvidenceContext? {
    guard let sessionID = object["session_id"] as? String, !sessionID.isEmpty else { return nil }
    let vehicle = object["primary_vehicle_identifier"] as? String ?? ""
    let kind = object["primary_vehicle_identifier_kind"] as? String ?? VehicleIdentifierKind.unknown.rawValue
    let inspectorID = object["inspector_id"] as? String ?? ""
    let inspectorName = object["inspector_name"] as? String ?? ""
    let started = object["session_started_at_utc"] as? String ?? ""
    let status = object["session_status_at_capture"] as? String ?? SessionStatus.inProgress.rawValue
    let version = object["schema_version"] as? String ?? "1.0.0"
    return InspectionSessionEvidenceContext(
      schemaVersion: version,
      sessionID: sessionID,
      primaryVehicleIdentifier: vehicle,
      primaryVehicleIdentifierKind: kind,
      inspectorID: inspectorID,
      inspectorName: inspectorName,
      sessionStartedAtUTC: started,
      sessionStatusAtCapture: status
    )
  }
}
