import Foundation
import Combine
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// @MainActor presentation layer over InspectionSessionService.
@MainActor
final class InspectionSessionViewModel: ObservableObject {
  @Published private(set) var current: InspectionSession?
  @Published private(set) var errorText: String?
  @Published var showCancelConfirmation = false

  let service: InspectionSessionService

  init(service: InspectionSessionService) {
    self.service = service
  }

  var hasActiveSession: Bool {
    guard let current else { return false }
    return current.status.isActiveOrPaused
  }

  var vehicleLabel: String {
    current?.vehicle.primaryIdentifier.rawValue ?? ""
  }

  var sessionIDLabel: String {
    current?.id.rawValue ?? ""
  }

  var statusLabel: String {
    current?.status.rawValue ?? ""
  }

  var captureCount: Int {
    current?.metrics.captureCount ?? 0
  }

  var elapsedDescription: String {
    guard let started = current?.startedAt else { return "" }
    let seconds = max(0, Int(Date().timeIntervalSince(started)))
    let h = seconds / 3600
    let m = (seconds % 3600) / 60
    let s = seconds % 60
    if h > 0 { return String(format: "%d:%02d:%02d", h, m, s) }
    return String(format: "%02d:%02d", m, s)
  }

  func restore() async {
    do {
      current = try await service.restoreCurrentSession()
      errorText = nil
    } catch {
      current = nil
      errorText = String(describing: error)
    }
  }

  func start(vehicleIdentifier: String) async {
    do {
      current = try await service.startInspection(vehicleIdentifierRaw: vehicleIdentifier)
      errorText = nil
    } catch {
      errorText = String(describing: error)
    }
  }

  func pause() async {
    await run { try await service.pause() }
  }

  func resume() async {
    await run { try await service.resume() }
  }

  func complete() async {
    await run { try await service.complete() }
  }

  func cancelConfirmed() async {
    await run { try await service.cancel() }
    showCancelConfirmation = false
  }

  func recordSuccessfulCaptureIfNeeded() async {
    guard current?.status == .inProgress else { return }
    do {
      try await service.recordSuccessfulCapture()
      current = service.currentSession
      errorText = nil
    } catch {
      // Do not surface metering failure as capture failure; log via error text lightly.
      errorText = String(describing: error)
    }
  }

  /// Immutable inspection context for approve/persist while a session is active (in progress or paused).
  func evidenceContextForCapture() -> InspectionSessionEvidenceContext? {
    guard let session = current, session.status.isActiveOrPaused else { return nil }
    return service.evidenceContext(for: session)
  }

  /// Export still prefers in-progress sessions (matches Sprint 1 package contract).
  func evidenceContextForExport() -> InspectionSessionEvidenceContext? {
    guard let session = current, session.status == .inProgress else { return nil }
    return service.evidenceContext(for: session)
  }

  private func run(_ body: () async throws -> Void) async {
    do {
      try await body()
      current = service.currentSession
      errorText = nil
    } catch {
      errorText = String(describing: error)
    }
  }
}

#endif
