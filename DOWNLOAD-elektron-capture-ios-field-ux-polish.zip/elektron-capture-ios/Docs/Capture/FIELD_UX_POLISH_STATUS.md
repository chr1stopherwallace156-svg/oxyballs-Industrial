# Field UX Polish (pre-2.1F)

| Field | Value |
|---|---|
| **Status** | `FIELD_UX_POLISH` (Linux `swift test`; device NOT RUN) |
| **Branch** | `cursor/field-ux-polish-before-2-1f-d881` |
| **Baseline** | Sprint 2.1E DoD tip |
| **Next** | Sprint 2.1F — point-grouped Evidence Library hierarchy |

## User-facing fixes

1. **Replace / Retake / Delete** for accepted evidence  
   - Soft-delete quarantines originals (never in-place overwrite)  
   - Detail `•••` menu + swipe actions  
   - Retake switches to Capture with banner; Use Photo stores new id then removes old  

2. **Library refresh without app restart**  
   - Shared `EvidenceLibraryViewModel` in `AppSessionContainer`  
   - `EvidenceLibraryNotifications.didChange` after accept / delete  
   - Reload on library tab appear  

3. **Single Capture button**  
   - Guided HUD: Previous · **Capture Photo** · Next  
   - Skip / Block / Complete under **More**  
   - Removed duplicate blue “Take Photo” when guided HUD is active  

## Deferred to 2.1F

- Group library list by inspection **point** (VIN / Front Left / Rear…)  
- Quality indicators (blur / dark / angle)

## Boundaries

- AVCapture warm-up / permission: **untouched**  
- Write-once originals: **preserved** (quarantine + new capture-id on retake)

## Execution

```text
Host: Linux (Swift 5.10.1)
Command: swift test
Result: 238 executed, 1 skipped, 0 failures
xcodebuild / device: NOT RUN
```
