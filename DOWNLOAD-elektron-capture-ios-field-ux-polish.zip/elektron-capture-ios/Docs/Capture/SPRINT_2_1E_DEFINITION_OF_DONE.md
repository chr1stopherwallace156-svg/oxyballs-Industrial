# Sprint 2.1E — Definition of Done & Device Acceptance

## Definition of Done (three tiers)

### 1. Functional verification

| Item | Status (Linux host) |
|---|---|
| Camera preview fully operational | **Operator** — device/Mac (warmup untouched in code) |
| HUD overlay sits over preview | **Implemented** (HUD ZStack layer) |
| Capture intent → Coordinator | **Implemented** |
| Evidence count updates on bind | **Covered** by `Sprint2_1ETests` |
| Next unlocks only when domain permits satisfaction | **Covered** by presenter tests |
| Blank skip/block reasons rejected | **Covered** |
| Session restores on cold relaunch | **Operator** + persistence tests for bind path |

### 2. Architectural boundaries

| Item | Status |
|---|---|
| Zero business rules in SwiftUI | **Pass** — views emit actions only |
| Thin ViewModel (pure presenter) | **Pass** — no repository/save calls |
| No `.shared` singletons | **Pass** — coordinator is a value type |
| No direct `InspectionSession` field mutations in UI | **Pass** — coordinator returns sessions |
| Domain retains rule authority | **Pass** — engines + presenter derive enablement |
| Coordinator owns persistence side-effects | **Pass** — `GuidedSessionPersisting` |

### 3. Quality & regression

| Item | Status |
|---|---|
| Dedicated `Sprint2_1ETests` pass | See status execution block |
| Existing suite stays green | See status execution block |
| Zero camera startup regressions | **No edits** to AVCapture warm-up/permission |
| No retain cycles in Coordinator | Value-type coordinator; no VM back-reference |

## Coordinator side-effect ownership

```text
UI → ViewModel (intent + ephemeral UIState)
        → GuidedInspectionCoordinator.handle (async)
              ├── apply domain transition
              ├── persist via GuidedSessionPersisting  ← sole disk write
              └── return session + presentation
        → ViewModel.adopt (display only)
```

ViewModel **must not** call `InspectionSessionRepository` / `applyUpdatedSession`.

## Industrial Technician Device Acceptance Matrix

| # | Scenario | Action | Expected | Pass |
|---|---|---|---|---|
| 01 | Cold Launch | Launch app | AVCapture starts cleanly | Preview without black flash |
| 02 | Guidance HUD | View screen | Active point text renders | Matches frozen snapshot |
| 03 | Intent Capture | Tap CAPTURE | In-flight lock → evidence bound | Count increments |
| 04 | Enablement | Inspect Next | Pre/post satisfaction | Next only when satisfied |
| 05 | Dialog Validation | Blank skip/block | Submit | Confirm stays disabled |
| 06 | Relaunch | Force-quit / reopen | Restore | Point + evidence intact |
| 07 | Package Export | Export session | Package writer | Existing export 100% |

Detailed checklist: `SPRINT_2_1E_TECHNICIAN_WALKTHROUGH.md`.
