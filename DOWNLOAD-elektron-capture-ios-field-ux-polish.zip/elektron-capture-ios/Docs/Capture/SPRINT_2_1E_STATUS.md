# Sprint 2.1E — Guided Capture Overlay Controls & Guidance UI

| Field | Value |
|---|---|
| **Status** | `SPRINT_2_1E_COMPLETE` (Linux `swift test`; Mac/device acceptance NOT RUN on this host) |
| **Branch** | `cursor/sprint-2-1e-guided-overlay-d881` |
| **Baseline** | Sprint 2.1D evidence binding |
| **Next** | Sprint 2.1F — hierarchical Evidence Library (only when prompted) |
| **DoD** | `Docs/Capture/SPRINT_2_1E_DEFINITION_OF_DONE.md` |
| **Device protocol** | `Docs/Capture/SPRINT_2_1E_TECHNICIAN_WALKTHROUGH.md` |

## Architecture (DoD: coordinator owns persistence)

```text
AVCaptureVideoPreviewLayer          ← foundational camera surface (untouched)
   └─ GuidedInspectionOverlayView   ← semi-transparent HUD
            │ UI actions
            ▼
GuidedInspectionViewModel           ← pure presenter (no disk writes)
   ├─ presentation (derived)
   └─ ui: GuidedInspectionUIState   ← ephemeral only
            │ GuidedInspectionIntent
            ▼
GuidedInspectionCoordinator.handle (async)
   ├── apply domain transition
   ├── persist via GuidedSessionPersisting   ← SOLE persistence owner
   └── return session + presentation
            │
            ▼
ViewModel.adopt (display cache only)
```

## Key enforcements

1. **`GuidedInspectionUIState`** — dialogs/drafts/capture lock never persist on session
2. **Coordinator persistence ownership** — ViewModel does not call repository/save
3. **Satisfaction-gated Next/Complete** — domain-derived enablement
4. **Value-type coordinator** — no `.shared`, no retain cycle with ViewModel
5. **Camera warmup untouched** — shutter still via existing Pass-2 controller after `shouldTriggerShutter`

## Roadmap

After **2.1F**, insert **Sprint 2.2 Hardening & Field Reliability** before Phase 3 (AR/LiDAR).

## Test suite summary

| Suite | Result |
|---|---|
| `Sprint2_1ETests` | **12** executed, **0** failures |
| Full package (`swift test`) | **237** executed, **1** skipped, **0** failures |
| Device acceptance matrix | **NOT RUN** (operator) |

## Boundary confirmations

| Check | Result |
|---|---|
| AVCaptureSession / permission / warm-up modified | **0** |
| ViewModel calls repository/save | **0** |
| View constructs `EvidenceMetadata` | **0** |
| Sprint 2.1F started | **no** |

## Execution

```text
Host: Linux (Swift 5.10.1)
Command: swift test
Result: 237 executed, 1 skipped, 0 failures
Sprint2_1ETests: 12 / 12 passed
Device acceptance: NOT RUN
```
