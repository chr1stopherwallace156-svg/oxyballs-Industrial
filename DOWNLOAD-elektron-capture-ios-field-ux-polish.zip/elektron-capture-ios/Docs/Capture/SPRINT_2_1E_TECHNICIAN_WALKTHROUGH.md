# Sprint 2.1E — Industrial Technician Walkthrough Protocol

Device / simulator validation checklist after `Sprint2_1ETests` are green.
Mac `xcodebuild` and physical-device runs are **operator-executed** on this checklist.

## Preconditions

- Build & run `Phase1StillCapture` from the Sprint 2.1E ZIP / branch tip
- Camera permission granted (physical device) **or** DEBUG “Use Development Test Image” on Simulator
- Start a **New Inspection** with a selected plan (plan is assigned at start)

## Protocol

### 1. Cold Launch & Warmup

- [ ] Force-quit the app, cold launch
- [ ] AVCapture session reaches live preview without flicker loops or permission stalls
- [ ] Guided HUD appears only after an assigned session is active (or after Start Guidance)
- [ ] Confirm no reconfigure of `AVCaptureSession` when opening/closing HUD dialogs

### 2. HUD Gating (snapshot authority)

- [ ] Point title / guidance text match frozen `InspectionPlanSnapshot` (not registry live lookup)
- [ ] Header shows `Point N of M` and plan progress `%`
- [ ] Evidence line shows `Evidence: x of y · Additional required` until satisfied

### 3. Intent Execution (Capture → Bind → Re-render)

- [ ] Tap **CAPTURE** → HUD locks (`Capturing…` / controls disabled)
- [ ] Review → **Use Photo** → library store succeeds
- [ ] Evidence count updates (`1/2` → `2/2` when multi-photo required)
- [ ] Confirm View never constructed `EvidenceMetadata` (coordinator path only)

### 4. Domain-Driven Enablement

- [ ] **Next** remains **disabled** until active point is satisfied (or terminal)
- [ ] After satisfaction, **Complete** enables; completing then advancing moves active point
- [ ] **Previous** only enables when a non-terminal predecessor exists

### 5. Dialog Validation (skip / block)

- [ ] Skip with blank / whitespace-only reason → rejected (confirm disabled or alert)
- [ ] Skip with populated reason → point becomes skipped; HUD refreshes
- [ ] Block with blank reason → rejected
- [ ] Block with populated reason → point blocked; completion disposition reflects `.blocked` when required

### 6. Persistence & Restoration

- [ ] Mid-session: force-quit after at least one bound evidence item
- [ ] Relaunch → restore current session
- [ ] Active point identity, progress statuses, and evidence bindings intact
- [ ] Ephemeral UI (`GuidedInspectionUIState` drafts/sheets) is **not** restored (expected idle)

## Pass criteria

All boxes checked on a physical iPhone for release evidence; Simulator acceptable for UI/intent wiring only (synthetic image path).
