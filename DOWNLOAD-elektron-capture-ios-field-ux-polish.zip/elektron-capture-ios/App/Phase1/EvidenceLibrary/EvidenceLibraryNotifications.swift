import Foundation

/// Cross-tab signal when Evidence Library catalog bytes change (store / soft-delete / attach).
public enum EvidenceLibraryNotifications {
  public static let didChange = Notification.Name("ElektronCapture.EvidenceLibraryDidChange")

  public static func postDidChange(evidenceId: String? = nil) {
    var userInfo: [AnyHashable: Any] = [:]
    if let evidenceId {
      userInfo["evidenceId"] = evidenceId
    }
    NotificationCenter.default.post(name: didChange, object: nil, userInfo: userInfo)
  }
}
