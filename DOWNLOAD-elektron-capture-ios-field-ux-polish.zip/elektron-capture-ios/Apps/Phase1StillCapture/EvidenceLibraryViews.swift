import SwiftUI
import ElektronCapture
import Combine

#if canImport(UIKit) && !os(macOS)
import UIKit

/// Primary navigation: Capture | Evidence Library
struct Phase1MainTabView: View {
  @EnvironmentObject private var inspection: InspectionSessionViewModel
  @EnvironmentObject private var session: AppSessionContainer
  @State private var showNewInspection = false

  var body: some View {
    TabView(selection: $session.selectedTab) {
      Phase1CaptureRootView()
        .tabItem {
          Label("Capture", systemImage: "camera")
        }
        .tag(AppSessionContainer.AppTab.capture)
      EvidenceLibraryListView()
        .tabItem {
          Label("Evidence Library", systemImage: "photo.on.rectangle.angled")
        }
        .tag(AppSessionContainer.AppTab.library)
    }
    .preferredColorScheme(.dark)
    .task {
      await inspection.restore()
      await session.library.reload()
      if !inspection.hasActiveSession {
        showNewInspection = true
      }
    }
    .sheet(isPresented: $showNewInspection) {
      NewInspectionSheet(viewModel: inspection)
    }
  }
}

@MainActor
final class EvidenceLibraryViewModel: ObservableObject {
  @Published var groups: [InspectionEvidenceGroup] = []
  @Published var unassigned: [EvidenceLibraryIndexRecord] = []
  @Published var isLoading = false
  @Published var errorText: String?
  @Published var disclaimerAcknowledged = false
  @Published var toastText: String?

  private var store: EvidenceLibraryStore?
  private var changeObserver: NSObjectProtocol?

  init() {
    changeObserver = NotificationCenter.default.addObserver(
      forName: EvidenceLibraryNotifications.didChange,
      object: nil,
      queue: .main
    ) { [weak self] _ in
      Task { @MainActor in
        await self?.reload()
      }
    }
  }

  deinit {
    if let changeObserver {
      NotificationCenter.default.removeObserver(changeObserver)
    }
  }

  var isEmpty: Bool {
    groups.isEmpty && unassigned.isEmpty
  }

  func ensureStore() async throws -> EvidenceLibraryStore {
    if let store { return store }
    let root = try EvidenceLibraryPaths.defaultLibraryRoot()
    let s = EvidenceLibraryStore(libraryRoot: root)
    _ = try await s.reconcileOnLaunch()
    store = s
    return s
  }

  func reload() async {
    isLoading = true
    errorText = nil
    defer { isLoading = false }
    do {
      let s = try await ensureStore()
      // Always re-read index from disk (actor may be shared across tabs).
      let catalog = try await s.listInspectionCatalog()
      groups = catalog.groups
      unassigned = catalog.unassigned
    } catch {
      errorText = String(describing: error)
    }
  }

  func verify(id: String) async -> String {
    do {
      let s = try await ensureStore()
      let result = try await s.verifyIntegrity(id: id)
      await reload()
      return "\(result.integrityState.rawValue): \(result.detail)"
    } catch {
      return "Verify failed: \(error)"
    }
  }

  func softDelete(id: String) async -> String {
    do {
      let s = try await ensureStore()
      _ = try await s.softDeleteUserInitiated(id: id)
      EvidenceLibraryNotifications.postDidChange(evidenceId: id)
      await reload()
      toastText = "Evidence removed from library (original quarantined)."
      return toastText ?? "Deleted"
    } catch {
      errorText = String(describing: error)
      return "Delete failed: \(error)"
    }
  }

  func storeRef() async throws -> EvidenceLibraryStore {
    try await ensureStore()
  }
}

struct EvidenceLibraryListView: View {
  @EnvironmentObject private var model: EvidenceLibraryViewModel
  @EnvironmentObject private var session: AppSessionContainer
  @EnvironmentObject private var guided: GuidedInspectionViewModel

  var body: some View {
    NavigationStack {
      Group {
        if model.isLoading && model.isEmpty {
          ProgressView("Loading Evidence Library…")
            .tint(.white)
        } else if model.isEmpty {
          emptyState
        } else {
          List {
            Section {
              Text("Local library only. Captures remain individually verifiable; inspections group them by inspectionSessionID. Soft-delete quarantines originals (never overwrites).")
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            if !model.groups.isEmpty {
              Section("Inspections") {
                ForEach(model.groups) { group in
                  NavigationLink(value: group) {
                    InspectionEvidenceGroupRow(group: group)
                  }
                }
              }
            }

            if !model.unassigned.isEmpty {
              Section("Unassigned Captures") {
                ForEach(model.unassigned) { record in
                  NavigationLink(value: record) {
                    EvidenceLibraryRow(record: record)
                  }
                  .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                    Button(role: .destructive) {
                      Task {
                        await guided.unbindLibraryEvidence(record.id)
                        await model.softDelete(id: record.id)
                      }
                    } label: {
                      Label("Delete", systemImage: "trash")
                    }
                    Button {
                      session.beginRetake(of: record.id)
                    } label: {
                      Label("Replace", systemImage: "camera.rotate")
                    }
                    .tint(.orange)
                  }
                }
              }
            }
          }
          .listStyle(.insetGrouped)
        }
      }
      .navigationTitle("Evidence Library")
      .navigationDestination(for: InspectionEvidenceGroup.self) { group in
        InspectionEvidenceGroupDetailView(groupID: group.sessionID, listModel: model)
      }
      .navigationDestination(for: EvidenceLibraryIndexRecord.self) { record in
        EvidenceLibraryDetailView(recordId: record.id, listModel: model)
      }
      .toolbar {
        ToolbarItem(placement: .topBarTrailing) {
          Button("Refresh") {
            Task { await model.reload() }
          }
        }
      }
      .task {
        await model.reload()
      }
      .onAppear {
        Task { await model.reload() }
      }
      .alert("Library Error", isPresented: Binding(
        get: { model.errorText != nil },
        set: { if !$0 { model.errorText = nil } }
      )) {
        Button("OK", role: .cancel) { model.errorText = nil }
      } message: {
        Text(model.errorText ?? "")
      }
    }
  }

  private var emptyState: some View {
    VStack(spacing: 16) {
      Image(systemName: "tray")
        .font(.system(size: 48))
        .foregroundStyle(.secondary)
      Text("No Stored Evidence")
        .font(.title3.bold())
      Text("Approve a capture on the Capture tab to store the original photo in the Evidence Library.")
        .font(.body)
        .foregroundStyle(.secondary)
        .multilineTextAlignment(.center)
        .padding(.horizontal, 32)
      Text("App-private storage only — not backed up to the cloud yet.")
        .font(.caption)
        .foregroundStyle(.orange)
        .multilineTextAlignment(.center)
        .padding(.horizontal, 32)
    }
    .frame(maxWidth: .infinity, maxHeight: .infinity)
  }
}

struct InspectionEvidenceGroupRow: View {
  let group: InspectionEvidenceGroup
  @EnvironmentObject private var inspection: InspectionSessionViewModel

  /// Live persisted session state only — never derived solely from capture sidecars.
  private var inspectionStatusText: String {
    if let live = inspection.current, live.id.rawValue == group.sessionID {
      return live.status.displayName
    }
    return EvidenceDisplayFormatting.orphanedInspectionStatusLabel
  }

  var body: some View {
    HStack(spacing: 12) {
      thumbnail
      VStack(alignment: .leading, spacing: 4) {
        Text(group.vehicleIdentifier.isEmpty ? "Unknown vehicle" : group.vehicleIdentifier)
          .font(.headline)
        Text(group.sessionID)
          .font(.caption.monospaced())
          .foregroundStyle(.secondary)
          .lineLimit(1)
        HStack(spacing: 8) {
          Text("\(group.captureCount) capture\(group.captureCount == 1 ? "" : "s")")
            .font(.caption.weight(.semibold))
          Text("Inspection Status: \(inspectionStatusText)")
            .font(.caption2.weight(.semibold))
            .padding(.horizontal, 6)
            .padding(.vertical, 2)
            .background(Color.blue.opacity(0.2))
            .foregroundStyle(.blue)
            .cornerRadius(4)
        }
        Text(EvidenceDisplayFormatting.localDateTime(from: group.latestCaptureAt))
          .font(.caption2)
          .foregroundStyle(.secondary)
      }
    }
    .padding(.vertical, 4)
  }

  @ViewBuilder
  private var thumbnail: some View {
    let resolved: URL? = {
      guard let rel = group.representativeThumbnailRelativePath,
            let root = try? EvidenceLibraryPaths.defaultLibraryRoot()
      else { return nil }
      return try? EvidenceLibraryPaths(libraryRoot: root).resolve(rel)
    }()
    if let url = resolved, let data = try? Data(contentsOf: url), let img = UIImage(data: data) {
      Image(uiImage: img)
        .resizable()
        .scaledToFill()
        .frame(width: 56, height: 56)
        .clipped()
        .cornerRadius(6)
    } else {
      RoundedRectangle(cornerRadius: 6)
        .fill(Color.gray.opacity(0.3))
        .frame(width: 56, height: 56)
        .overlay {
          Image(systemName: "folder")
            .foregroundStyle(.secondary)
        }
    }
  }
}

struct InspectionEvidenceGroupDetailView: View {
  let groupID: String
  @ObservedObject var listModel: EvidenceLibraryViewModel
  @EnvironmentObject private var inspection: InspectionSessionViewModel
  @EnvironmentObject private var session: AppSessionContainer
  @EnvironmentObject private var guided: GuidedInspectionViewModel

  private var group: InspectionEvidenceGroup? {
    listModel.groups.first { $0.sessionID == groupID }
  }

  /// Live persisted session state only — never derived solely from capture sidecars.
  private var inspectionStatusText: String {
    if let live = inspection.current, live.id.rawValue == groupID {
      return live.status.displayName
    }
    return EvidenceDisplayFormatting.orphanedInspectionStatusLabel
  }

  private var vehicleValue: String {
    guard let group else { return "—" }
    return group.vehicleIdentifier.isEmpty ? "—" : group.vehicleIdentifier
  }

  private var identifierClassification: String {
    guard let group else { return "—" }
    return EvidenceDisplayFormatting.vehicleKindLabel(group.vehicleIdentifierKind)
  }

  private var inspectorLine: String {
    guard let group else { return "—" }
    if group.inspectorName.isEmpty {
      return group.inspectorID.isEmpty ? "—" : group.inspectorID
    }
    if group.inspectorID.isEmpty { return group.inspectorName }
    return "\(group.inspectorName)"
  }

  var body: some View {
    Group {
      if let group {
        List {
          Section {
            VStack(alignment: .leading, spacing: 12) {
              headerRow("Vehicle", vehicleValue, monospaced: false)
              headerRow("Identifier classification", identifierClassification, monospaced: false)
              headerRow("Inspection ID", group.sessionID, monospaced: true)
              headerRow("Inspector", inspectorLine, monospaced: false)
              headerRow(
                "Started",
                group.startedAtUTC.map { EvidenceDisplayFormatting.localDateTime(fromISO8601: $0) } ?? "—",
                monospaced: false
              )
              headerRow("Inspection Status", inspectionStatusText, monospaced: false)
              headerRow("Capture Count", "\(group.captureCount)", monospaced: false)
              headerRow(
                "Latest Capture",
                EvidenceDisplayFormatting.localDateTime(from: group.latestCaptureAt),
                monospaced: false
              )
            }
            .padding(.vertical, 10)
          }

          Section("Captures") {
            ForEach(group.captures) { record in
              NavigationLink(value: record) {
                EvidenceLibraryRow(record: record)
              }
              .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                Button(role: .destructive) {
                  Task {
                    await guided.unbindLibraryEvidence(record.id)
                    await listModel.softDelete(id: record.id)
                  }
                } label: {
                  Label("Delete", systemImage: "trash")
                }
                Button {
                  session.beginRetake(of: record.id)
                } label: {
                  Label("Replace", systemImage: "camera.rotate")
                }
                .tint(.orange)
              }
            }
          }
        }
      } else {
        VStack(spacing: 12) {
          Image(systemName: "folder")
            .font(.largeTitle)
            .foregroundStyle(.secondary)
          Text("Inspection removed")
            .font(.headline)
          Text("All captures for this inspection were deleted or moved.")
            .font(.subheadline)
            .foregroundStyle(.secondary)
            .multilineTextAlignment(.center)
            .padding(.horizontal)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
      }
    }
    .navigationTitle("Inspection")
    .navigationBarTitleDisplayMode(.inline)
    .navigationDestination(for: EvidenceLibraryIndexRecord.self) { record in
      EvidenceLibraryDetailView(recordId: record.id, listModel: listModel)
    }
  }

  private func headerRow(_ title: String, _ value: String, monospaced: Bool) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title)
        .font(.caption)
        .foregroundStyle(.secondary)
      Text(value)
        .font(monospaced ? .body.monospaced() : .body)
        .textSelection(.enabled)
    }
  }
}

struct EvidenceLibraryRow: View {
  let record: EvidenceLibraryIndexRecord

  var body: some View {
    HStack(spacing: 12) {
      thumbnail
      VStack(alignment: .leading, spacing: 4) {
        Text(EvidenceDisplayFormatting.localDateTime(from: record.captureTimestamp))
          .font(.headline)
        Text(record.shortId)
          .font(.caption.monospaced())
          .foregroundStyle(.secondary)
        if let label = record.vehicleOrSessionLabel, !label.isEmpty {
          Text(label)
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        if let capturedWhile = record.inspectionStatusAtCapture, !capturedWhile.isEmpty {
          Text("Captured while: \(EvidenceDisplayFormatting.inspectionStatusLabel(capturedWhile))")
            .font(.caption2)
            .foregroundStyle(.secondary)
        }
        if record.isSynthetic {
          Text("SYNTHETIC")
            .font(.caption2.weight(.bold))
            .foregroundStyle(.orange)
        }
        statusChips
      }
    }
    .padding(.vertical, 4)
  }

  @ViewBuilder
  private var thumbnail: some View {
    let resolved: URL? = {
      guard let root = try? EvidenceLibraryPaths.defaultLibraryRoot() else { return nil }
      return try? EvidenceLibraryPaths(libraryRoot: root).resolve(record.thumbnailRelativePath)
    }()
    if let url = resolved, let data = try? Data(contentsOf: url), let img = UIImage(data: data) {
      Image(uiImage: img)
        .resizable()
        .scaledToFill()
        .frame(width: 56, height: 56)
        .clipped()
        .cornerRadius(6)
    } else {
      RoundedRectangle(cornerRadius: 6)
        .fill(Color.gray.opacity(0.3))
        .frame(width: 56, height: 56)
        .overlay {
          Image(systemName: "photo")
            .foregroundStyle(.secondary)
        }
    }
  }

  private var statusChips: some View {
    HStack(spacing: 6) {
      chip(record.state.storageState.rawValue, color: storageColor(record.state.storageState))
      chip(record.state.packageState.rawValue, color: .blue)
      chip(record.state.integrityState.rawValue, color: integrityColor(record.state.integrityState))
    }
  }

  private func chip(_ text: String, color: Color) -> some View {
    Text(text)
      .font(.caption2.weight(.semibold))
      .padding(.horizontal, 6)
      .padding(.vertical, 2)
      .background(color.opacity(0.2))
      .foregroundStyle(color)
      .cornerRadius(4)
  }

  private func storageColor(_ s: EvidenceStorageState) -> Color {
    switch s {
    case .storedLocally: return .green
    case .missing, .unrecognized: return .red
    case .pending: return .orange
    }
  }

  private func integrityColor(_ s: EvidenceIntegrityState) -> Color {
    switch s {
    case .verifiedPass: return .mint
    case .corruptedHashMismatch, .corruptedPackage, .missingArtifact: return .red
    case .unverified: return .orange
    }
  }
}

struct EvidenceLibraryDetailView: View {
  let recordId: String
  @ObservedObject var listModel: EvidenceLibraryViewModel
  @EnvironmentObject private var session: AppSessionContainer
  @EnvironmentObject private var guided: GuidedInspectionViewModel
  @Environment(\.dismiss) private var dismiss

  @State private var record: EvidenceLibraryIndexRecord?
  @State private var fullImage: UIImage?
  @State private var statusMessage = ""
  @State private var shareItems: [Any] = []
  @State private var showShare = false
  @State private var showFiles = false
  @State private var filesURLs: [URL] = []
  @State private var manifestPreview = ""
  @State private var showDeleteConfirm = false

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 16) {
        if let fullImage {
          Image(uiImage: fullImage)
            .resizable()
            .scaledToFit()
            .frame(maxWidth: .infinity)
        } else {
          ProgressView()
        }

        if let record {
          Group {
            labeled("Capture ID", record.id)
            labeled("Short ID", record.shortId)
            labeled("Captured", EvidenceDisplayFormatting.localDateTime(from: record.captureTimestamp))
            labeled("Original SHA-256", record.originalSha256)
            if let pkg = record.packageSha256 {
              labeled("Package SHA-256", pkg)
            }
            labeled("Capture", record.state.captureState.rawValue)
            labeled("Storage", record.state.storageState.rawValue)
            labeled("Package", record.state.packageState.rawValue)
            labeled("Export", record.state.exportState.rawValue)
            labeled("Integrity", record.state.integrityState.rawValue)
            if let label = record.vehicleOrSessionLabel {
              labeled("Vehicle/Session", label)
            }
            if let sid = record.inspectionSessionID {
              labeled("Inspection Session", sid)
            }
            if let vehicle = record.inspectionVehicleIdentifier {
              labeled("Inspection Vehicle", vehicle)
            }
            if let status = record.inspectionStatusAtCapture {
              labeled(
                "Captured while",
                EvidenceDisplayFormatting.inspectionStatusLabel(status)
              )
            }
            labeled("Synthetic", record.isSynthetic ? "YES — not physical-device verified" : "NO")
            Text("Phase: \(Phase1CStatus.current)")
              .font(.caption2)
              .foregroundStyle(.secondary)
          }
          .font(.footnote.monospaced())
        }

        if !manifestPreview.isEmpty {
          Text("Metadata preview")
            .font(.headline)
          Text(manifestPreview)
            .font(.caption2.monospaced())
            .foregroundStyle(.secondary)
        }

        Text("Soft-delete quarantines the original (never overwrites). Replace opens Capture for a new capture-id.")
          .font(.caption)
          .foregroundStyle(.orange)

        if !statusMessage.isEmpty {
          Text(statusMessage)
            .font(.caption)
            .foregroundStyle(.mint)
        }

        Button("Verify Integrity") {
          Task {
            statusMessage = await listModel.verify(id: recordId)
            await load()
          }
        }
        .buttonStyle(.borderedProminent)

        Button("Re-export .edts-pkg") {
          Task { await reexportPackage() }
        }
        .buttonStyle(.bordered)

        Button("Save Original JPEG Copy") {
          Task { await saveOriginalCopy() }
        }
        .buttonStyle(.bordered)
      }
      .padding()
    }
    .navigationTitle("Evidence Detail")
    .navigationBarTitleDisplayMode(.inline)
    .toolbar {
      ToolbarItem(placement: .topBarTrailing) {
        Menu {
          Button {
            session.beginRetake(of: recordId)
          } label: {
            Label("Replace / Retake", systemImage: "camera.rotate")
          }
          Button(role: .destructive) {
            showDeleteConfirm = true
          } label: {
            Label("Delete", systemImage: "trash")
          }
          Divider()
          Button {
            Task { await saveOriginalCopy() }
          } label: {
            Label("Share JPEG Copy", systemImage: "square.and.arrow.up")
          }
        } label: {
          Image(systemName: "ellipsis.circle")
        }
      }
    }
    .confirmationDialog(
      "Delete this evidence?",
      isPresented: $showDeleteConfirm,
      titleVisibility: .visible
    ) {
      Button("Delete", role: .destructive) {
        Task {
          await guided.unbindLibraryEvidence(recordId)
          statusMessage = await listModel.softDelete(id: recordId)
          dismiss()
        }
      }
      Button("Cancel", role: .cancel) {}
    } message: {
      Text("The original is quarantined on device (not permanently erased). A retake creates a new capture-id.")
    }
    .task { await load() }
    .sheet(isPresented: $showShare) {
      ActivityShareView(items: shareItems) { completed in
        statusMessage = completed ? "Share completed." : "Share dismissed — library record untouched."
      }
    }
    .sheet(isPresented: $showFiles) {
      DocumentExportPicker(urls: filesURLs) {
        statusMessage = "Files picker closed — library record untouched."
      }
    }
  }

  private func labeled(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(.caption).foregroundStyle(.secondary)
      Text(value).textSelection(.enabled)
    }
  }

  private func load() async {
    do {
      let store = try await listModel.storeRef()
      let rec = try await store.record(id: recordId)
      record = rec
      let paths = store.paths
      let art = try paths.resolve(rec.originalRelativePath)
      if let data = try? Data(contentsOf: art) {
        // Decode for display only — does not write back.
        fullImage = UIImage(data: data)
      }
      let manifest = paths.captureDirectory(id: recordId).appendingPathComponent("manifest.json")
      if let data = try? Data(contentsOf: manifest), let s = String(data: data, encoding: .utf8) {
        manifestPreview = String(s.prefix(1200))
      } else {
        let libStatus = paths.captureDirectory(id: recordId).appendingPathComponent("library_status.json")
        if let data = try? Data(contentsOf: libStatus), let s = String(data: data, encoding: .utf8) {
          manifestPreview = s
        }
      }
    } catch {
      statusMessage = "Load failed: \(error)"
    }
  }

  private func reexportPackage() async {
    do {
      let store = try await listModel.storeRef()
      let staging = FileManager.default.temporaryDirectory
        .appendingPathComponent("EvidenceLibraryShare", isDirectory: true)
      try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
      let dest = staging.appendingPathComponent("\(recordId).edts-pkg")
      let url = try await store.copyExportPackage(id: recordId, to: dest)
      shareItems = [url]
      showShare = true
      statusMessage = "Sharing library export copy (canonical library untouched)."
    } catch {
      statusMessage = "Re-export failed: \(error). Export from Capture first if package missing."
    }
  }

  private func saveOriginalCopy() async {
    do {
      let store = try await listModel.storeRef()
      let staging = FileManager.default.temporaryDirectory
        .appendingPathComponent("EvidenceLibraryShare", isDirectory: true)
      try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
      let dest = staging.appendingPathComponent("\(recordId)-original.jpg")
      let url = try await store.copyOriginalJPEG(id: recordId, to: dest)
      filesURLs = [url]
      showFiles = true
      statusMessage = "Saving a copy of the original JPEG — library original not moved."
    } catch {
      statusMessage = "Save original failed: \(error)"
    }
  }
}

#endif
