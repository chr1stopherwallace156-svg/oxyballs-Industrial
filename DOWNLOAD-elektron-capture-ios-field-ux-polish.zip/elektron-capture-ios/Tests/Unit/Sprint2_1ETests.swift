import XCTest
@testable import ElektronCapture

/// Sprint 2.1E — guided inspection intent coordinator & presentation (Linux-testable core).
final class Sprint2_1ETests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_400_000)

  private func makeSnapshot() throws -> InspectionPlanSnapshot {
    let plan = try InspectionPlan(
      id: "guide_demo",
      version: "1.0.0",
      title: "Guide Demo",
      points: [
        try InspectionPoint(
          id: "p0",
          title: "Front",
          displayOrder: 1,
          isRequired: true,
          guidanceInstruction: "Capture the front bumper"
        ),
        try InspectionPoint(
          id: "p1",
          title: "Rear",
          displayOrder: 2,
          isRequired: true,
          expectedEvidenceType: .multiPhoto
        ),
      ]
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession() throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked("INS-21E"),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "GUIDE-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: makeSnapshot(),
      assignedAt: fixedInstant
    )
  }

  /// Pure domain coordinator (no persister) — ViewModel-equivalent dry-run surface.
  private func coordinator() -> GuidedInspectionCoordinator {
    GuidedInspectionCoordinator(instantProvider: FixedInstantProvider(fixedInstant))
  }

  func testPrepareInitializesProgressAndActivatesFirstPoint() throws {
    let c = coordinator()
    let session = try makeSession()
    XCTAssertNil(session.progress)
    let result = try c.apply(.prepareGuidedSession, session: session)
    XCTAssertEqual(result.session.progress?.activePointID?.rawValue, "p0")
    XCTAssertEqual(result.presentation.activePointTitle, "Front")
    XCTAssertEqual(result.presentation.guidanceText, "Capture the front bumper")
    XCTAssertTrue(result.presentation.canCapture)
    XCTAssertTrue(result.presentation.canSkip)
    XCTAssertFalse(result.shouldTriggerShutter)
  }

  func testCaptureRequestedDoesNotConstructEvidenceMetadata() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    let result = try c.apply(.captureRequested, session: session)
    XCTAssertTrue(result.shouldTriggerShutter)
    XCTAssertNil(result.session.evidenceBindings)
    XCTAssertEqual(result.session.progress?.activePointID?.rawValue, "p0")
  }

  func testCaptureRequestedRejectedWhenNoActivePoint() throws {
    let c = coordinator()
    let session = try makeSession()
    XCTAssertThrowsError(try c.apply(.captureRequested, session: session)) { err in
      guard case GuidedInspectionPresentationError.captureNotReady = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testBindApprovedCaptureBuildsMetadataInCoordinator() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    let result = try c.apply(
      .bindApprovedCapture(
        storageKey: "lib-evidence-abc",
        type: .photo,
        attributes: ["sha256_prefix": "deadbeef"]
      ),
      session: session
    )
    let bindings = try XCTUnwrap(result.session.evidenceBindings?.bindings)
    XCTAssertEqual(bindings.count, 1)
    XCTAssertEqual(bindings[0].pointID.rawValue, "p0")
    XCTAssertEqual(bindings[0].sessionID, session.id)
    XCTAssertEqual(bindings[0].type, .photo)
    XCTAssertTrue(bindings[0].storageKey.contains("lib-evidence-abc"))
    XCTAssertTrue(bindings[0].storageKey.contains("p0"))
    XCTAssertEqual(bindings[0].payloadAttributes["sha256_prefix"], "deadbeef")
    XCTAssertTrue(result.presentation.isPointSatisfied)
    XCTAssertEqual(result.presentation.evidenceCount, 1)
    XCTAssertEqual(result.presentation.requiredCount, 1)
  }

  func testAdvanceEnablementRequiresSatisfactionOrTerminal() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    XCTAssertFalse(c.presentation(for: session).canAdvance)
    XCTAssertFalse(c.presentation(for: session).canComplete)
    XCTAssertEqual(c.presentation(for: session).pointPositionLabel, "Point 1 of 2")

    session = try c.apply(
      .bindApprovedCapture(storageKey: "k-sat", type: .photo, attributes: [:]),
      session: session
    ).session
    XCTAssertTrue(c.presentation(for: session).isPointSatisfied)
    XCTAssertTrue(c.presentation(for: session).canComplete)
    XCTAssertTrue(c.presentation(for: session).canAdvance)

    session = try c.apply(.completePointRequested, session: session).session
    XCTAssertTrue(c.presentation(for: session).canAdvance)
    session = try c.apply(.advanceRequested, session: session).session
    XCTAssertEqual(session.progress?.activePointID?.rawValue, "p1")
    XCTAssertEqual(c.presentation(for: session).requiredCount, 2)
    XCTAssertFalse(c.presentation(for: session).canAdvance)
    XCTAssertTrue(c.presentation(for: session).evidenceStatusLabel.contains("Additional required"))
  }

  func testUIStateIsEphemeralAndNotOnSessionWireFormat() throws {
    var ui = GuidedInspectionUIState(
      showingSkipDialog: true,
      draftSkipReason: "temp",
      draftBlockReason: "  "
    )
    ui.resetEphemeral()
    XCTAssertEqual(ui, .idle)

    let session = try makeSession()
    let data = try InspectionSessionEnvelopeCoder.makeJSONEncoder().encode(session)
    let json = try XCTUnwrap(String(data: data, encoding: .utf8))
    XCTAssertFalse(json.contains("showingSkipDialog"))
    XCTAssertFalse(json.contains("draftSkipReason"))
    XCTAssertFalse(json.contains("captureInProgress"))
    XCTAssertFalse(json.contains("GuidedInspectionUIState"))
  }

  func testBlockEmptyReasonMapsToPresentationError() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    XCTAssertThrowsError(try c.apply(.blockRequested(reason: "\n\t"), session: session)) { err in
      XCTAssertEqual(err as? GuidedInspectionPresentationError, .emptyBlockReason)
    }
  }

  func testSkipEmptyReasonMapsToPresentationError() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    XCTAssertThrowsError(try c.apply(.skipRequested(reason: "  "), session: session)) { err in
      XCTAssertEqual(err as? GuidedInspectionPresentationError, .emptySkipReason)
    }
  }

  func testLegacyUnassignedIsUnavailable() throws {
    let legacy = try InspectionSession(
      id: SessionID.unchecked("INS-LEGACY"),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "L")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planState: .legacyUnassigned
    )
    let state = GuidedInspectionPresenter.makeState(from: legacy)
    XCTAssertFalse(state.isGuidedAvailable)
    XCTAssertThrowsError(
      try coordinator().apply(.prepareGuidedSession, session: legacy)
    ) { err in
      XCTAssertEqual(err as? GuidedInspectionPresentationError, .planNotAssigned)
    }
  }

  /// DoD: coordinator (not ViewModel) owns persistence side-effects.
  func testCoordinatorHandlePersistsBindingsViaPersister() async throws {
    let repo = InMemoryCurrentSessionRepository()
    let service = InspectionSessionService(
      repository: repo,
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("INS-21E-P")),
      instantProvider: FixedInstantProvider(fixedInstant)
    )
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    var session = try await service.createSession(
      vehicleIdentifierRaw: "PERSIST-1",
      inspectionPlan: plan,
      assignedAt: fixedInstant
    )
    let c = GuidedInspectionCoordinator(
      instantProvider: FixedInstantProvider(fixedInstant),
      persister: service
    )
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "k1", type: .photo, attributes: [:]),
      session: session
    ).session
    let loaded = try await repo.load()
    XCTAssertEqual(loaded?.evidenceBindings?.bindings.count, 1)
    XCTAssertEqual(loaded?.progress?.activePointID, session.progress?.activePointID)
  }

  func testCoordinatorIsValueTypeWithoutSharedSingleton() throws {
    let a = GuidedInspectionCoordinator(instantProvider: FixedInstantProvider(fixedInstant))
    let b = GuidedInspectionCoordinator(instantProvider: FixedInstantProvider(fixedInstant))
    var s1 = try makeSession()
    var s2 = try makeSession()
    s1 = try a.apply(.prepareGuidedSession, session: s1).session
    s2 = try b.apply(.prepareGuidedSession, session: s2).session
    // Engine-level advance (presentation may gate UI Next until satisfied).
    s2 = try b.apply(.advanceRequested, session: s2).session
    XCTAssertEqual(s1.progress?.activePointID?.rawValue, "p0")
    XCTAssertEqual(s2.progress?.activePointID?.rawValue, "p1")
  }

  func testCaptureRequestedDoesNotPersist() async throws {
    final class CountingPersister: GuidedSessionPersisting, @unchecked Sendable {
      var count = 0
      func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
        count += 1
        return session
      }
    }
    let persister = CountingPersister()
    let c = GuidedInspectionCoordinator(
      instantProvider: FixedInstantProvider(fixedInstant),
      persister: persister
    )
    var session = try makeSession()
    session = try await c.handle(.prepareGuidedSession, session: session).session
    XCTAssertEqual(persister.count, 1)
    _ = try await c.handle(.captureRequested, session: session)
    XCTAssertEqual(persister.count, 1, "captureRequested must not persist")
  }
}
