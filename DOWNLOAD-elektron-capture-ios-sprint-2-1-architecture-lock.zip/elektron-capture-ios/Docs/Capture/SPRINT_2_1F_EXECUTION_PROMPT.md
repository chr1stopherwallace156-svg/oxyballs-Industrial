# Sprint 2.1F — Execution Prompt (Draft)

| Field | Value |
|---|---|
| **Status** | `DRAFT` — do not implement until explicitly kicked off |
| **Depends on** | `Docs/Capture/SPRINT_2_1_ARCHITECTURE.md` **LOCKED** |
| **Baseline** | Sprint 2.1E.1 tip (architecture + field polish) |

---

## Mission (strict)

Deliver **Inspection Review, Point-Grouped Evidence Refinement & Pre-Export Validation** without expanding into 2.2 hardening or Phase 3 spatial work.

### In scope

1. **Point-grouped Evidence hierarchy** — refine `InspectionPointEvidenceGrouping` UX (collapse/expand, clear status tags, deep-link back to active point capture).
2. **Pre-export validation engine** — domain-pure check: every required point satisfied (or legitimately terminal skip/block per product rules) before export is enabled; surface blocking reasons in Review UI.
3. **Inspection review & export package** — review screen summarizing points + evidence; generate / re-verify package manifest integrity; export preview (ZIP / `.edts-pkg`) without mutating originals.

### Out of scope → 2.2

- Memory / battery profiling, long-session soak
- Crash / interruption recovery campaigns
- Export stress beyond clean build + integrity verify
- AR / LiDAR / twin overlays

### Invariants (must not break)

All eight invariants in `SPRINT_2_1_ARCHITECTURE.md`, especially:

- Views never construct `EvidenceMetadata` or mutate session
- Coordinator owns persistence; engines stay stateless
- Soft-delete quarantine / new capture-id on retake
- AVCapture warm-up / permission / resume **untouched**

### Suggested task order

```text
1. Domain: PreExportValidationService (pure Session → ValidationReport)
2. Review UI: point list + satisfaction + jump-to-capture
3. Gate export CTA on ValidationReport.isExportable
4. Package preview / integrity verify wiring
5. Tests + Field Regression Checklist (device or NOT RUN)
6. Status doc + ZIP handoff
```

### Definition of done (draft)

- [ ] Validation report derived only from frozen snapshot + bindings + progression terminals
- [ ] Export disabled with explicit reasons when unsatisfied
- [ ] Grouped library/review hierarchy consistent with binding storage keys
- [ ] `swift test` green; Field Regression Checklist filled
- [ ] Architecture invariants unchanged (no schema bump unless forced)

---

**Kickoff rule:** Begin coding only when an agent/user explicitly starts Sprint 2.1F. Until then this file is planning-only.
