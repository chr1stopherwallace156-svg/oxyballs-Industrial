import Foundation
import XCTest
@testable import ElektronCapture

/// Guards schema longevity: historical library_status / inspection context payloads
/// must load, group, and reconcile without mutating canonical capture bytes.
final class SchemaCompatibilityTests: XCTestCase {
  private var baseRoot: URL!
  private var libraryRoot: URL!
  private let hasher = ArtifactHashingService()

  override func setUp() {
    super.setUp()
    baseRoot = FileManager.default.temporaryDirectory
      .appendingPathComponent("SchemaCompat-\(UUID().uuidString)", isDirectory: true)
    try? FileManager.default.createDirectory(at: baseRoot, withIntermediateDirectories: true)
    libraryRoot = try! EvidenceLibraryPaths.root(under: baseRoot)
  }

  override func tearDown() {
    try? FileManager.default.removeItem(at: baseRoot)
    super.tearDown()
  }

  private var fixtureJPEG: Data {
    Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
      0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14,
      0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7F, 0xFF, 0xD9,
    ])
  }

  /// Plant a committed capture directory with a specific library_status / optional context schema.
  private func plantCapture(
    id: String,
    statusSchema: String,
    captureTimestampUTC: String,
    inspectionSessionID: String?,
    contextSchema: String?,
    includeStatusInspectionFields: Bool
  ) throws -> (sha: String, bytes: Data) {
    let paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    let dir = paths.captureDirectory(id: id)
    let fm = FileManager.default
    try fm.createDirectory(at: dir, withIntermediateDirectories: true)
    try fm.createDirectory(at: paths.sidecarsDirectory(id: id), withIntermediateDirectories: true)
    try fm.createDirectory(at: paths.exportsDirectory(id: id), withIntermediateDirectories: true)

    let jpeg = fixtureJPEG
    let sha = hasher.sha256HexOfData(jpeg)
    try jpeg.write(to: paths.artifactOriginalURL(id: id), options: .atomic)

    var status: [String: Any] = [
      "schema_id": "EvidenceLibraryLocalStatus",
      "schema_version": statusSchema,
      "storage_format_version": statusSchema,
      "evidence_id": id,
      "session_id": "SESSION-\(id)",
      "artifact_id": "ART-\(id)",
      "record_id": "REC-\(id)",
      "capture_timestamp": captureTimestampUTC,
      "capture_state": "APPROVED",
      "storage_state": "STORED_LOCALLY",
      "original_sha256": sha,
      "original_byte_count": jpeg.count,
      "phase_status": Phase1CStatus.current,
      "committed": true,
      "stored_at": captureTimestampUTC,
      "vehicle_or_session_label": NSNull(),
    ]

    if let inspectionSessionID, includeStatusInspectionFields {
      status["inspection_session_id"] = inspectionSessionID
      status["inspection_vehicle_identifier"] = "1HGCM82633A004352"
      status["inspection_vehicle_identifier_kind"] = VehicleIdentifierKind.vinHeuristic.rawValue
      status["inspection_inspector_id"] = "INSPECTOR-LOCAL"
      status["inspection_inspector_name"] = "Local Inspector"
      status["inspection_started_at_utc"] = "2026-07-25T12:00:00Z"
      status["inspection_status_at_capture"] = SessionStatus.inProgress.rawValue
      status["vehicle_or_session_label"] = "1HGCM82633A004352"
    }

    if statusSchema == "1.2.0" {
      status["is_synthetic"] = false
    }

    let statusData = try JSONSerialization.data(withJSONObject: status, options: [.sortedKeys, .prettyPrinted])
    try statusData.write(to: dir.appendingPathComponent("library_status.json"), options: .atomic)

    if let inspectionSessionID, let contextSchema {
      var context: [String: Any] = [
        "schema_id": "InspectionSessionEvidenceContext",
        "schema_version": contextSchema,
        "session_id": inspectionSessionID,
        "primary_vehicle_identifier": "1HGCM82633A004352",
        "primary_vehicle_identifier_kind": contextSchema == "1.0.0"
          ? VehicleIdentifierKind.unknown.rawValue
          : VehicleIdentifierKind.vinHeuristic.rawValue,
        "inspector_id": "INSPECTOR-LOCAL",
        "session_started_at_utc": "2026-07-25T12:00:00Z",
      ]
      if contextSchema != "1.0.0" {
        context["inspector_name"] = "Local Inspector"
        context["session_status_at_capture"] = SessionStatus.inProgress.rawValue
      }
      let contextData = try JSONSerialization.data(
        withJSONObject: context,
        options: [.sortedKeys, .prettyPrinted]
      )
      try contextData.write(
        to: paths.sidecarsDirectory(id: id).appendingPathComponent("inspection_session_context.json"),
        options: .atomic
      )
    }

    return (sha, jpeg)
  }

  func testSchema100101102LoadCleanlyIntoEvidenceLibraryStore() async throws {
    let a = try plantCapture(
      id: "EVD-SCHEMA-100",
      statusSchema: "1.0.0",
      captureTimestampUTC: "2026-07-25T10:00:00Z",
      inspectionSessionID: "INSP-COMPAT",
      contextSchema: "1.0.0",
      includeStatusInspectionFields: false
    )
    let b = try plantCapture(
      id: "EVD-SCHEMA-110",
      statusSchema: "1.1.0",
      captureTimestampUTC: "2026-07-25T10:01:00Z",
      inspectionSessionID: "INSP-COMPAT",
      contextSchema: "1.1.0",
      includeStatusInspectionFields: true
    )
    let c = try plantCapture(
      id: "EVD-SCHEMA-120",
      statusSchema: "1.2.0",
      captureTimestampUTC: "2026-07-25T10:02:00Z",
      inspectionSessionID: "INSP-COMPAT",
      contextSchema: "1.1.0",
      includeStatusInspectionFields: true
    )
    // Legacy unassigned (no inspection context)
    _ = try plantCapture(
      id: "EVD-SCHEMA-LEGACY",
      statusSchema: "1.0.0",
      captureTimestampUTC: "2026-07-25T09:00:00Z",
      inspectionSessionID: nil,
      contextSchema: nil,
      includeStatusInspectionFields: false
    )

    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    let doc = try await store.rebuildIndexFromDisk()
    XCTAssertEqual(doc.records.count, 4)

    let byId = Dictionary(uniqueKeysWithValues: doc.records.map { ($0.id, $0) })
    XCTAssertEqual(byId["EVD-SCHEMA-100"]?.inspectionSessionID, "INSP-COMPAT")
    XCTAssertEqual(byId["EVD-SCHEMA-110"]?.inspectionSessionID, "INSP-COMPAT")
    XCTAssertEqual(byId["EVD-SCHEMA-120"]?.inspectionSessionID, "INSP-COMPAT")
    XCTAssertNil(byId["EVD-SCHEMA-LEGACY"]?.inspectionSessionID)

    XCTAssertEqual(byId["EVD-SCHEMA-100"]?.originalSha256, a.sha)
    XCTAssertEqual(byId["EVD-SCHEMA-110"]?.originalSha256, b.sha)
    XCTAssertEqual(byId["EVD-SCHEMA-120"]?.originalSha256, c.sha)
  }

  func testGroupingIdenticalAcrossSchemaVersions() async throws {
    _ = try plantCapture(
      id: "EVD-G100",
      statusSchema: "1.0.0",
      captureTimestampUTC: "2026-07-25T11:00:00Z",
      inspectionSessionID: "INSP-GROUP",
      contextSchema: "1.0.0",
      includeStatusInspectionFields: false
    )
    _ = try plantCapture(
      id: "EVD-G110",
      statusSchema: "1.1.0",
      captureTimestampUTC: "2026-07-25T11:01:00Z",
      inspectionSessionID: "INSP-GROUP",
      contextSchema: "1.1.0",
      includeStatusInspectionFields: true
    )
    _ = try plantCapture(
      id: "EVD-G120",
      statusSchema: "1.2.0",
      captureTimestampUTC: "2026-07-25T11:02:00Z",
      inspectionSessionID: "INSP-GROUP",
      contextSchema: "1.1.0",
      includeStatusInspectionFields: true
    )
    _ = try plantCapture(
      id: "EVD-GOTHER",
      statusSchema: "1.2.0",
      captureTimestampUTC: "2026-07-25T11:03:00Z",
      inspectionSessionID: "INSP-OTHER",
      contextSchema: "1.1.0",
      includeStatusInspectionFields: true
    )

    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    _ = try await store.rebuildIndexFromDisk()
    let catalog = try await store.listInspectionCatalog()

    XCTAssertEqual(catalog.groups.count, 2)
    let primary = catalog.groups.first { $0.sessionID == "INSP-GROUP" }
    XCTAssertEqual(primary?.captureCount, 3)
    XCTAssertEqual(primary?.captures.map(\.id), ["EVD-G100", "EVD-G110", "EVD-G120"])
    XCTAssertEqual(catalog.groups.first { $0.sessionID == "INSP-OTHER" }?.captureCount, 1)
  }

  func testIndexReconciliationUpgradesDerivedIndexWithoutMutatingCanonicalBytes() async throws {
    let planted = try plantCapture(
      id: "EVD-RECON",
      statusSchema: "1.0.0",
      captureTimestampUTC: "2026-07-25T12:00:00Z",
      inspectionSessionID: "INSP-RECON",
      contextSchema: "1.0.0",
      includeStatusInspectionFields: false
    )
    let paths = EvidenceLibraryPaths(libraryRoot: libraryRoot)
    let artifactURL = paths.artifactOriginalURL(id: "EVD-RECON")
    let contextURL = paths.sidecarsDirectory(id: "EVD-RECON")
      .appendingPathComponent("inspection_session_context.json")
    let statusURL = paths.captureDirectory(id: "EVD-RECON")
      .appendingPathComponent("library_status.json")

    let bytesBefore = try Data(contentsOf: artifactURL)
    let contextBefore = try Data(contentsOf: contextURL)
    let statusBefore = try Data(contentsOf: statusURL)
    let shaBefore = hasher.sha256HexOfData(bytesBefore)
    XCTAssertEqual(shaBefore, planted.sha)

    let store = EvidenceLibraryStore(libraryRoot: libraryRoot)
    // First rebuild creates derived index from disk.
    let first = try await store.rebuildIndexFromDisk()
    XCTAssertEqual(first.schemaVersion, "1.2.0")
    XCTAssertEqual(first.records.first?.inspectionSessionID, "INSP-RECON")

    // Second reconcile/rebuild must not mutate package / original / sidecar bytes.
    _ = try await store.reconcileOnLaunch()
    let second = try await store.rebuildIndexFromDisk()
    XCTAssertEqual(second.records.first?.originalSha256, shaBefore)
    XCTAssertEqual(second.records.first?.inspectionSessionID, "INSP-RECON")

    XCTAssertEqual(try Data(contentsOf: artifactURL), bytesBefore)
    XCTAssertEqual(try Data(contentsOf: contextURL), contextBefore)
    XCTAssertEqual(try Data(contentsOf: statusURL), statusBefore)
    XCTAssertEqual(try hasher.sha256HexOfFile(at: artifactURL), shaBefore)
  }

  func testContextSchema100DecodesWithoutStatusFields() {
    let obj: [String: Any] = [
      "schema_id": "InspectionSessionEvidenceContext",
      "schema_version": "1.0.0",
      "session_id": "INSP-OLD",
      "primary_vehicle_identifier": "ABC",
      "primary_vehicle_identifier_kind": "UNKNOWN",
      "inspector_id": "INSPECTOR-LOCAL",
      "session_started_at_utc": "2026-07-25T12:00:00.000Z",
    ]
    let decoded = InspectionSessionEvidenceContext.decode(from: obj)
    XCTAssertEqual(decoded?.sessionID, "INSP-OLD")
    XCTAssertEqual(decoded?.schemaVersion, "1.0.0")
    XCTAssertEqual(decoded?.inspectorName, "")
    XCTAssertEqual(decoded?.sessionStatusAtCapture, SessionStatus.inProgress.rawValue)
  }
}
