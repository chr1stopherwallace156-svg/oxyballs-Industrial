#!/usr/bin/env python3
"""
Sprint 2.3 execution manifest recorder (Phase F harness cleanup).

Pure recorder when invoked with --results-json: does NOT re-run tests or xcodebuild.
Makefile is the sole executor of build/test commands.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def sh_capture(cmd: list[str], cwd: Path) -> tuple[int, str]:
    proc = subprocess.run(cmd, cwd=str(cwd), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return proc.returncode, proc.stdout


def toolchain_versions(root: Path) -> dict[str, Any]:
    out: dict[str, Any] = {}
    code, text = sh_capture(["swift", "--version"], root)
    out["swift"] = {"exit_code": code, "text": text.strip().splitlines()[:5]}
    code, text = sh_capture(["bash", "-lc", "command -v xcodebuild >/dev/null && xcodebuild -version || true"], root)
    if "Xcode" in text:
        out["xcodebuild"] = {"available": True, "text": text.strip().splitlines()[:5]}
    else:
        out["xcodebuild"] = {"available": False, "text": ""}
    return out


def git_provenance(root: Path) -> dict[str, Any]:
    git_dir = root / ".git"
    if not git_dir.exists():
        commit_file = root / "HANDOFF_COMMIT.txt"
        sha_file = root / "source_archive_sha256.txt"
        return {
            "mode": "PORTABLE_ARCHIVE_NO_GIT",
            "repository_commit_txt": commit_file.read_text().strip() if commit_file.exists() else None,
            "source_archive_sha256_txt": sha_file.read_text().strip() if sha_file.exists() else None,
        }
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    branch = subprocess.check_output(["git", "branch", "--show-current"], cwd=root, text=True).strip()
    dirty = subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True)
    return {
        "mode": "GIT",
        "commit": commit,
        "branch": branch,
        "working_tree": "dirty" if dirty.strip() else "clean",
        "dirty_paths": [ln[3:] for ln in dirty.splitlines() if ln.strip()][:50],
    }


def status_for_exit(exit_code: int | None, *, blocked: bool = False, part_of_full: bool = False) -> str:
    if blocked:
        return "BLOCKED_HOST_CAPABILITY"
    if exit_code is None:
        return "NOT_RECORDED"
    if exit_code == 0:
        return "PASSED_AS_PART_OF_FULL_SUITE" if part_of_full else "PASSED"
    return "FAILED"


def gate_failed(status: str) -> bool:
    return status == "FAILED"


def main() -> int:
    parser = argparse.ArgumentParser(description="Record Sprint 2.3 execution manifest from Makefile results.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--out", type=Path, default=None)
    parser.add_argument(
        "--results-json",
        type=Path,
        required=True,
        help="JSON file produced by Makefile with isolated gate results (no re-execution).",
    )
    parser.add_argument(
        "--before-path",
        type=Path,
        default=None,
        help="Optional path to write a copy labeled as before/after companion.",
    )
    args = parser.parse_args()
    root: Path = args.root
    out = args.out or (root / "Docs" / "Evidence" / "SPRINT_2_3" / "sprint_2_3_execution_manifest.json")
    out.parent.mkdir(parents=True, exist_ok=True)

    results = json.loads(args.results_json.read_text())
    utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    provenance = git_provenance(root)
    toolchains = toolchain_versions(root)

    gates_in = results.get("gates", {})

    def g(name: str) -> dict[str, Any]:
        return dict(gates_in.get(name) or {})

    membership = g("app_source_membership")
    hardening_22 = g("sprint_2_2_hardening")
    revision_23 = g("sprint_2_3_revision_interleaving")
    recovery = g("recovery_monotonicity")
    full_suite = g("swift_package_full")
    xcode = g("xcodebuild_app")

    # Normalize statuses from exit codes when caller only supplied exits.
    for block, part in (
        (membership, False),
        (hardening_22, False),
        (revision_23, False),
        (recovery, False),
        (full_suite, False),
    ):
        if "status" not in block and "exit_code" in block:
            block["status"] = status_for_exit(block.get("exit_code"), part_of_full=False)

    if xcode.get("blocked_host_capability"):
        xcode["status"] = "BLOCKED_HOST_CAPABILITY"
        xcode["exit_code"] = None
    elif "status" not in xcode and "exit_code" in xcode:
        xcode["status"] = status_for_exit(xcode.get("exit_code"))

    # Evidence-bounded success claims (never unconditional MET on untested surfaces).
    success_gate = {
        "single_authoritative_boundary": results.get(
            "single_authoritative_boundary",
            "VERIFIED_FOR_TESTED_CURRENT_AND_MULTI_SESSION_REPOSITORY_PATHS",
        ),
        "deterministic_stale_write_rejection": (
            "VERIFIED_BY_SPRINT_2_3_REVISION_INTERLEAVING_SUITE"
            if revision_23.get("status") in ("PASSED", "PASSED_AS_PART_OF_FULL_SUITE")
            else "FAILED"
            if revision_23.get("status") == "FAILED"
            else "NOT_RECORDED"
        ),
        "zero_residual_side_effects": (
            "VERIFIED_FOR_TESTED_REJECT_PATHS_IN_REVISION_AND_RECOVERY_SUITES"
            if revision_23.get("status") in ("PASSED", "PASSED_AS_PART_OF_FULL_SUITE")
            and recovery.get("status") in ("PASSED", "PASSED_AS_PART_OF_FULL_SUITE")
            else "FAILED"
            if revision_23.get("status") == "FAILED" or recovery.get("status") == "FAILED"
            else "NOT_RECORDED"
        ),
        "monotonic_recovery": (
            "VERIFIED_BY_RECOVERY_MONOTONICITY_SUITE"
            if recovery.get("status") in ("PASSED", "PASSED_AS_PART_OF_FULL_SUITE")
            else "FAILED"
            if recovery.get("status") == "FAILED"
            else "NOT_RECORDED"
        ),
        "slot_replacement_policy": results.get(
            "slot_replacement_policy",
            "FORBIDDEN_SILENT_DIFFERENT_ID_OVERWRITE__REQUIRES_replaceCurrentSession",
        ),
        "clean_app_compilation": xcode.get("status", "NOT_RECORDED"),
        "honest_status": "MANIFEST_RECORDED_FROM_MAKEFILE_RESULTS",
    }

    acceptable = {
        "VERIFIED_FOR_TESTED_CURRENT_AND_MULTI_SESSION_REPOSITORY_PATHS",
        "VERIFIED_BY_SPRINT_2_3_REVISION_INTERLEAVING_SUITE",
        "VERIFIED_FOR_TESTED_REJECT_PATHS_IN_REVISION_AND_RECOVERY_SUITES",
        "VERIFIED_BY_RECOVERY_MONOTONICITY_SUITE",
        "FORBIDDEN_SILENT_DIFFERENT_ID_OVERWRITE__REQUIRES_replaceCurrentSession",
        "MANIFEST_RECORDED_FROM_MAKEFILE_RESULTS",
        "PASSED",
        "PASSED_AS_PART_OF_FULL_SUITE",
        "BLOCKED_HOST_CAPABILITY",  # blocked ≠ failed, but blocks sprint_complete
    }

    blocked_gates = []
    for key, val in success_gate.items():
        if val == "FAILED" or val == "NOT_RECORDED":
            blocked_gates.append(key)
        if key == "clean_app_compilation" and val != "PASSED":
            blocked_gates.append(key)

    # Deduplicate while preserving order
    seen: set[str] = set()
    blocked_unique = []
    for b in blocked_gates:
        if b not in seen:
            seen.add(b)
            blocked_unique.append(b)

    sprint_complete = (
        success_gate["deterministic_stale_write_rejection"].startswith("VERIFIED")
        and success_gate["zero_residual_side_effects"].startswith("VERIFIED")
        and success_gate["monotonic_recovery"].startswith("VERIFIED")
        and success_gate["clean_app_compilation"] == "PASSED"
        and membership.get("status") == "PASSED"
        and full_suite.get("status") in ("PASSED", "PASSED_AS_PART_OF_FULL_SUITE")
    )

    manifest = {
        "schema": "elektron.sprint_2_3_execution_manifest.v2",
        "generated_at_utc": utc,
        "recorder": "Scripts/emit-sprint-2-3-execution-manifest.py",
        "recorder_mode": "PURE_RESULTS_RECORDER",
        "classification": "ADVERSARIAL_HARDENING_AND_RECOVERY_IN_PROGRESS",
        "sprint_2_3_complete": sprint_complete,
        "success_gate": success_gate,
        "blocked_gates": blocked_unique,
        "environment": {
            "git_or_archive": provenance,
            "toolchains": toolchains,
            "portable_checksum_files": {
                "repository_commit.txt": (root / "repository_commit.txt").exists()
                or (root / "HANDOFF_COMMIT.txt").exists(),
                "source_archive_sha256.txt": (root / "source_archive_sha256.txt").exists(),
            },
        },
        "policy_status": {
            "revision_occ_adr": "ACCEPTED_S2_004",
            "slot_replacement": "EXPLICIT_replaceCurrentSession_REQUIRED",
            "recovery_quarantine_adr": "ACCEPTED_POLICY_JOURNAL_DEFERRED",
            "install_recovered_snapshot_bounds": "IDENTITY_MATCH_AND_REVISION_MONOTONICITY_ONLY_NO_SIGNATURE_PROVENANCE",
            "session_json_quarantine_implementation": "PENDING",
            "transaction_journal_engine": "DEFERRED",
            "app_integration_uitests_device_validation": "PENDING_SEPARATE_WORK",
        },
        "targets": {
            "ElektronCaptureTests": "PRESENT",
            "ElektronCaptureGoldenTests": "PRESENT",
            "ElektronCoreHardeningTests": "PRESENT_SPM",
            "ElektronAppIntegrationTests": "ABSENT",
            "ElektronCaptureUITests": "ABSENT",
        },
        "fuzz_seeds": {
            "sprint_2_2_randomized_sequence": 84721953,
            "mode": "fixed_pr_seed",
        },
        "gates": {
            "app_source_membership": membership,
            "sprint_2_2_hardening": hardening_22,
            "sprint_2_3_revision_interleaving": revision_23,
            "recovery_monotonicity": recovery,
            "swift_package_full": full_suite,
            "xcodebuild_app": xcode,
        },
        "pending_future_work": [
            "ElektronAppIntegrationTests",
            "ElektronCaptureUITests",
            "physical device validation",
            "transaction journal engine",
            "session JSON quarantine implementation",
        ],
    }

    text = json.dumps(manifest, indent=2, sort_keys=True) + "\n"
    out.write_text(text)
    if args.before_path:
        # Companion snapshot for before/after diffs in the same run folder.
        args.before_path.parent.mkdir(parents=True, exist_ok=True)
        args.before_path.write_text(text)
    print(f"Wrote {out}")
    print(json.dumps({"sprint_2_3_complete": sprint_complete, "blocked_gates": blocked_unique}, indent=2))

    # Strict: any FAILED evaluated gate ⇒ non-zero (BLOCKED_HOST_CAPABILITY is not FAILED).
    hard_fail = False
    for name, block in manifest["gates"].items():
        st = block.get("status")
        if st == "FAILED":
            hard_fail = True
        if name == "xcodebuild_app" and st == "FAILED":
            hard_fail = True
    # Also fail if required package gates missing
    for req in (
        "app_source_membership",
        "sprint_2_2_hardening",
        "sprint_2_3_revision_interleaving",
        "recovery_monotonicity",
        "swift_package_full",
    ):
        if manifest["gates"][req].get("status") in (None, "NOT_RECORDED", "FAILED"):
            hard_fail = True

    return 1 if hard_fail else 0


if __name__ == "__main__":
    sys.exit(main())
