#!/usr/bin/env python3
"""Verify every Apps/Phase1StillCapture/*.swift is in the Xcode Sources build phase.

Exit 0 on success. Exit 1 if any disk Swift file is missing from PBX Sources.
Runnable on Linux — does not require xcodebuild.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "Apps" / "Phase1StillCapture"
PBX = APP / "Phase1StillCapture.xcodeproj" / "project.pbxproj"


def main() -> int:
  if not PBX.is_file():
    print(f"FAIL: missing {PBX}", file=sys.stderr)
    return 1
  text = PBX.read_text()
  m = re.search(r"/\* Sources \*/ = \{.*?files = \((.*?)\);", text, re.S)
  if not m:
    print("FAIL: Sources build phase not found", file=sys.stderr)
    return 1
  sources = set(re.findall(r"/\* ([^*]+) in Sources \*/", m.group(1)))
  sources = {s.strip() for s in sources}
  disk = sorted(p.name for p in APP.glob("*.swift"))
  missing = [f for f in disk if f not in sources]
  print("Sources membership:")
  for f in disk:
    print(f"  {'OK ' if f in sources else 'OUT'} {f}")
  if missing:
    print("FAIL: not in Xcode Sources:", ", ".join(missing), file=sys.stderr)
    return 1
  print("PASS: all app Swift files are in Sources")
  return 0


if __name__ == "__main__":
  sys.exit(main())
