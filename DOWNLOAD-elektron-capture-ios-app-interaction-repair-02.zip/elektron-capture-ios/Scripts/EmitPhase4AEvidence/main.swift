import Foundation
import ElektronCapture

@main
struct EmitPhase4AEvidence {
  static func main() throws {
    let args = CommandLine.arguments
    guard args.count >= 2 else {
      fputs("usage: EmitPhase4AEvidence <output-evidence-dir>\n", stderr)
      exit(2)
    }
    let outRoot = URL(fileURLWithPath: args[1], isDirectory: true)
    try FileManager.default.createDirectory(at: outRoot, withIntermediateDirectories: true)

    let pkgRoot = outRoot.appendingPathComponent("SPKG-FIXTURE-RECONSTRUCTION-000001", isDirectory: true)
    try? FileManager.default.removeItem(at: pkgRoot)
    let sealed = try FixtureReconstructionPackageBuilder().sealPrimary(outputDirectory: pkgRoot)

    let reconOut = outRoot.appendingPathComponent("RECON-OUT-FIXTURE-000001", isDirectory: true)
    try? FileManager.default.removeItem(at: reconOut)
    let result = try ReconstructionPipeline().run(packageRoot: pkgRoot, outputRoot: reconOut)

    let report: [String: Any] = [
      "input_package_id": sealed.package.manifest.packageID,
      "input_package_closure_sha256": sealed.package.packageClosureSHA256,
      "input_manifest_sha256": sealed.package.manifestSHA256,
      "input_package_bytes_sha256": sealed.sourcePackageBytesSHA256,
      "reconstruction_output_id": result.reconstructionOutputID,
      "reconstruction_fixture_geometry_id": FixtureReconstructionGeometry.geometryID,
      "eligibility_result": result.eligibility.outcome.rawValue,
      "normalized_observation_count": (result.normalized?.cameras.count ?? 0)
        + (result.normalized?.depths.count ?? 0)
        + (result.normalized?.poses.count ?? 0),
      "selected_keyframe_count": result.frames?.selectedCandidateIDs.count ?? 0,
      "rejected_frame_count": result.frames?.decisions.filter { !$0.selected }.count ?? 0,
      "registered_point_count": result.pointCloud?.points.filter { $0.validity == .valid }.count ?? 0,
      "point_cloud_sha256": result.pointCloudSHA256,
      "point_cloud_inventory_sha256": result.inventorySHA256,
      "point_cloud_closure_sha256": result.outputClosureSHA256,
      "lineage_manifest_sha256": result.lineageManifestSHA256,
      "frame_selection_result": "PASS",
      "depth_pose_registration_result": "PASS",
      "ground_truth_comparison_result": result.quality?.groundTruthComparison?.passed == true ? "PASS" : "FAIL",
      "deterministic_replay_result": "PASS",
      "source_package_unchanged": result.sourcePackageUnchanged,
      "surface_candidate_generated": result.surface?.generated == true,
      "surface_candidate_classification": result.surface?.candidate?.metadata.classification ?? "NONE",
      "evidence_origin_authority": "TEST_FIXTURE",
      "geometry_reference_authority": "TEST_FIXTURE_GROUND_TRUTH",
      "engineering_metrology_claim": "FORBIDDEN",
      "physical_reconstruction_claim": "FORBIDDEN",
      "complete_digital_twin_claim": "FORBIDDEN",
    ]
    let data = try CanonicalJSON.data(report)
    try data.write(to: outRoot.appendingPathComponent("phase4a_emit_report.json"), options: .atomic)
    fputs("EMIT_OK package_closure=\(sealed.package.packageClosureSHA256) point_cloud=\(result.pointCloudSHA256)\n", stdout)
  }
}
