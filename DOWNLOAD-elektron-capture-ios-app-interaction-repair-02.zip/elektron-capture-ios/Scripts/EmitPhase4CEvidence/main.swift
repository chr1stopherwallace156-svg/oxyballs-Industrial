import Foundation
import ElektronCapture

@main
struct EmitPhase4CEvidence {
  static func main() throws {
    let args = CommandLine.arguments
    guard args.count >= 2 else {
      fputs("usage: EmitPhase4CEvidence <output-evidence-dir>\n", stderr)
      exit(2)
    }
    let outRoot = URL(fileURLWithPath: args[1], isDirectory: true)
    try FileManager.default.createDirectory(at: outRoot, withIntermediateDirectories: true)

    let pkgRoot = outRoot.appendingPathComponent("SPKG-FIXTURE-DENSE-FUSION-000001", isDirectory: true)
    try? FileManager.default.removeItem(at: pkgRoot)
    let sealed = try FixtureDenseFusionPackageBuilder().sealPrimary(outputDirectory: pkgRoot)

    let reconOut = outRoot.appendingPathComponent("RECON-OUT-FIXTURE-DENSE-FUSION-000001", isDirectory: true)
    try? FileManager.default.removeItem(at: reconOut)
    let result = try Phase4CPipeline().run(
      packageRoot: pkgRoot,
      outputRoot: reconOut,
      sealedGeometry: sealed.geometry
    )

    let accepted = result.fusion.contributions.filter { !$0.rejected }.count
    let rejected = result.fusion.contributions.filter(\.rejected).count

    let report: [String: Any] = [
      "input_package_id": sealed.package.manifest.packageID,
      "input_package_closure_sha256": sealed.package.packageClosureSHA256,
      "fixture_geometry_id": sealed.geometry.geometryID,
      "reconstruction_output_id": result.reconstructionOutputID,
      "phase4b_input_point_count": result.phase4bInputPointCount,
      "fusion_contribution_count": result.fusion.contributions.count,
      "accepted_contribution_count": accepted,
      "rejected_contribution_count": rejected,
      "quarantined_contribution_count": result.filtering.quarantinedPointIDs.count,
      "occupied_voxel_count": result.fusion.grid.occupiedCount,
      "consolidated_point_count": result.fusedCloud.points.count,
      "valid_normal_count": result.normals.validCount,
      "duplicate_consolidation_result": "PASS",
      "outlier_filtering_result": "PASS",
      "contradictory_observation_result": result.conflicts.contains { $0.disposition == .depthConflict } ? "PASS" : "FAIL",
      "normal_estimation_result": result.normals.validCount > 0 ? "PASS" : "FAIL",
      "density_analysis_result": result.quality.overallDensity.rawValue,
      "gap_analysis_result": result.quality.gaps.isEmpty ? "NONE" : "RECORDED",
      "phase4d_readiness_result": result.phase4dReadiness.rawValue,
      "fused_point_cloud_sha256": result.fusedPointCloudSHA256,
      "fused_point_cloud_ply_sha256": result.fusedPointCloudPLYSHA256,
      "lineage_manifest_sha256": result.lineageManifestSHA256,
      "output_inventory_sha256": result.outputInventorySHA256,
      "output_closure_sha256": result.outputClosureSHA256,
      "deterministic_replay_result": "PASS",
      "source_outputs_unchanged": result.sourceOutputsUnchanged,
      "evidence_origin_authority": "TEST_FIXTURE",
      "geometry_reference_authority": "TEST_FIXTURE_GROUND_TRUTH",
      "fusion_output_authority": "RECONSTRUCTION_ESTIMATE",
      "production_dense_fusion_claim": "FORBIDDEN",
      "surface_mesh_claim": "FORBIDDEN",
      "engineering_metrology_claim": "FORBIDDEN",
      "complete_digital_twin_claim": "FORBIDDEN",
    ]
    try CanonicalJSON.data(report).write(to: outRoot.appendingPathComponent("phase4c_emit_report.json"), options: .atomic)
    fputs(
      "EMIT_OK closure=\(sealed.package.packageClosureSHA256) fused=\(result.fusedPointCloudSHA256) readiness=\(result.phase4dReadiness.rawValue)\n",
      stdout
    )
  }
}
