#!/usr/bin/env bash
# run-sprint-2-3-gates.sh — sole executor for Sprint 2.3 verification gates.
# Records isolated results JSON, then invokes the pure manifest recorder.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

EVIDENCE="$ROOT/Docs/Evidence/SPRINT_2_3"
mkdir -p "$EVIDENCE"
RESULTS="$EVIDENCE/gate_results.json"
BEFORE="$EVIDENCE/sprint_2_3_execution_manifest.before.json"
AFTER="$EVIDENCE/sprint_2_3_execution_manifest.json"
LOGDIR="$EVIDENCE/logs"
mkdir -p "$LOGDIR"

# Snapshot prior manifest as "before" if present.
if [[ -f "$AFTER" ]]; then
  cp "$AFTER" "$BEFORE"
else
  echo '{"schema":"elektron.sprint_2_3_execution_manifest.v2","note":"no_prior_manifest"}' >"$BEFORE"
fi

run_gate() {
  local name="$1"
  shift
  local logfile="$LOGDIR/${name}.log"
  local start end elapsed exit_code
  start=$(date +%s)
  set +e
  "$@" >"$logfile" 2>&1
  exit_code=$?
  set -e
  end=$(date +%s)
  elapsed=$((end - start))

  local executed="" skipped="" failures=""
  if command -v rg >/dev/null 2>&1; then
    local summary
    summary=$(rg -N 'Executed [0-9]+ tests' "$logfile" | tail -1 || true)
    executed=$(echo "$summary" | rg -o 'Executed ([0-9]+)' -r '$1' || true)
    skipped=$(echo "$summary" | rg -o '([0-9]+) test skipped' -r '$1' || true)
    failures=$(echo "$summary" | rg -o '([0-9]+) failures' -r '$1' || true)
  fi

  python3 - "$RESULTS" "$name" "$exit_code" "$elapsed" "$*" "$executed" "$skipped" "$failures" <<'PY'
import json, sys
from pathlib import Path
path, name, exit_code, elapsed, cmdline, executed, skipped, failures = sys.argv[1:9]
data = {}
p = Path(path)
if p.exists():
    data = json.loads(p.read_text())
gates = data.setdefault("gates", {})
status = "PASSED" if int(exit_code) == 0 else "FAILED"
entry = {
    "exit_code": int(exit_code),
    "status": status,
    "duration_seconds": int(elapsed),
    "command": cmdline,
}
if executed:
    entry["metrics"] = {
        "executed": int(executed) if executed else None,
        "skipped": int(skipped) if skipped else 0,
        "failures": int(failures) if failures else 0,
    }
gates[name] = entry
p.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
print(f"gate {name}: status={status} exit={exit_code} duration={elapsed}s")
sys.exit(int(exit_code))
PY
}

# Fresh results file for this run.
cat >"$RESULTS" <<EOF
{
  "schema": "elektron.sprint_2_3_gate_results.v1",
  "slot_replacement_policy": "FORBIDDEN_SILENT_DIFFERENT_ID_OVERWRITE__REQUIRES_replaceCurrentSession",
  "single_authoritative_boundary": "VERIFIED_FOR_TESTED_CURRENT_AND_MULTI_SESSION_REPOSITORY_PATHS",
  "gates": {}
}
EOF

OVERALL=0

echo "==> gate: app_source_membership"
if ! run_gate app_source_membership python3 Scripts/verify-app-sources-membership.py; then OVERALL=1; fi

echo "==> gate: sprint_2_2_hardening"
if ! run_gate sprint_2_2_hardening swift test --filter Sprint2_2_HardeningTests; then OVERALL=1; fi

echo "==> gate: sprint_2_3_revision_interleaving"
if ! run_gate sprint_2_3_revision_interleaving swift test --filter Sprint2_3_RevisionGuardTests; then OVERALL=1; fi

echo "==> gate: recovery_monotonicity"
if ! run_gate recovery_monotonicity swift test --filter SessionRecoveryMonotonicityTests; then OVERALL=1; fi

echo "==> gate: swift_package_full"
if ! run_gate swift_package_full swift test; then OVERALL=1; fi

echo "==> gate: xcodebuild_app"
if command -v xcodebuild >/dev/null 2>&1; then
  if ! run_gate xcodebuild_app xcodebuild \
    -workspace Phase1StillCapture.xcworkspace \
    -scheme Phase1StillCapture \
    -destination 'generic/platform=iOS' \
    build; then OVERALL=1; fi
else
  python3 - "$RESULTS" <<'PY'
import json, sys
from pathlib import Path
path = Path(sys.argv[1])
data = json.loads(path.read_text())
data.setdefault("gates", {})["xcodebuild_app"] = {
    "exit_code": None,
    "status": "BLOCKED_HOST_CAPABILITY",
    "blocked_host_capability": True,
    "duration_seconds": 0,
    "command": "xcodebuild (not available on this host)",
}
path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
print("gate xcodebuild_app: status=BLOCKED_HOST_CAPABILITY")
PY
fi

echo "==> record Sprint 2.3 execution manifest (pure recorder)"
set +e
python3 Scripts/emit-sprint-2-3-execution-manifest.py \
  --results-json "$RESULTS" \
  --out "$AFTER" \
  --before-path "$EVIDENCE/sprint_2_3_execution_manifest.after.json"
MANIFEST_EXIT=$?
set -e

# Keep after.json as identical copy for before/after pair clarity.
cp "$AFTER" "$EVIDENCE/sprint_2_3_execution_manifest.after.json"

if [[ "$MANIFEST_EXIT" -ne 0 ]]; then
  OVERALL=1
fi

echo "Sprint 2.3 gate overall exit=$OVERALL (manifest_exit=$MANIFEST_EXIT)"
echo "Before: $BEFORE"
echo "After:  $AFTER"
exit "$OVERALL"
