#!/usr/bin/env bash
# Sprint 3.6 Apple hardware validation gate.
# Executes on macOS + Xcode hosts only. Linux agents must record BLOCKED.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EVIDENCE_OUT="${PHASE36_EVIDENCE_OUT:-$ROOT/Docs/Evidence/SPRINT_3_6}"
mkdir -p "$EVIDENCE_OUT"

have_xcodebuild=0
if command -v xcodebuild >/dev/null 2>&1; then
  have_xcodebuild=1
fi

uname_s="$(uname -s)"
cat >"$EVIDENCE_OUT/apple_environment.json" <<EOF
{
  "schema_id": "AppleEnvironmentRecord",
  "schema_version": "1.0.0-phase3",
  "recorded_at_utc": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "uname": "$(uname -a)",
  "os_family": "$uname_s",
  "xcodebuild_available": $([[ "$have_xcodebuild" == 1 ]] && echo true || echo false),
  "host_gate": "$([[ "$uname_s" == Darwin && "$have_xcodebuild" == 1 ]] && echo APPLE_HOST_AVAILABLE || echo BLOCKED_APPLE_HOST_UNAVAILABLE)",
  "mac_model": "$(sysctl -n hw.model 2>/dev/null || echo NOT_AVAILABLE)",
  "mac_architecture": "$(uname -m)",
  "macos_version": "$(sw_vers -productVersion 2>/dev/null || echo NOT_AVAILABLE)",
  "xcode_version": "$(xcodebuild -version 2>/dev/null | tr '\n' ' ' || echo NOT_AVAILABLE)",
  "swift_version": "$(swift --version 2>/dev/null | head -1 || echo NOT_AVAILABLE)",
  "xcode_select_path": "$(xcode-select -p 2>/dev/null || echo NOT_AVAILABLE)",
  "iphone_model": "NOT_CAPTURED_ON_THIS_HOST",
  "iphone_os_version": "NOT_CAPTURED_ON_THIS_HOST",
  "lidar_capable": "NOT_CAPTURED_ON_THIS_HOST"
}
EOF

if [[ "$uname_s" != "Darwin" || "$have_xcodebuild" != "1" ]]; then
  cat >"$EVIDENCE_OUT/SPRINT_3_6_HOST_GATE.txt" <<EOF
BLOCKED_APPLE_HOST_UNAVAILABLE
This Sprint 3.6 gate requires macOS + Xcode + physical iPhone.
No SPKG-DEVICE package was emitted.
EOF
  echo "phase3-6: BLOCKED_APPLE_HOST_UNAVAILABLE" >&2
  exit 2
fi

# --- Apple host path ---
cd "$ROOT"
swift test 2>&1 | tee "$EVIDENCE_OUT/swift_test.log"
shasum -a 256 "$EVIDENCE_OUT/swift_test.log" | awk '{print $1"  swift_test.log"}' >"$EVIDENCE_OUT/swift_test.log.sha256"

xcodebuild -workspace Phase1StillCapture.xcworkspace -scheme Phase1StillCapture \
  -destination 'platform=iOS Simulator,name=iPhone 16' build \
  2>&1 | tee "$EVIDENCE_OUT/xcodebuild_simulator.log"
shasum -a 256 "$EVIDENCE_OUT/xcodebuild_simulator.log" | awk '{print $1"  xcodebuild_simulator.log"}' >"$EVIDENCE_OUT/xcodebuild_simulator.log.sha256"

xcodebuild -workspace Phase1StillCapture.xcworkspace -scheme Phase1StillCapture \
  -sdk iphoneos -destination 'generic/platform=iOS' build \
  2>&1 | tee "$EVIDENCE_OUT/xcodebuild_device.log" || true
shasum -a 256 "$EVIDENCE_OUT/xcodebuild_device.log" | awk '{print $1"  xcodebuild_device.log"}' >"$EVIDENCE_OUT/xcodebuild_device.log.sha256"

echo "phase3-6: Apple host compile gates executed; continue physical capture runbook manually."
