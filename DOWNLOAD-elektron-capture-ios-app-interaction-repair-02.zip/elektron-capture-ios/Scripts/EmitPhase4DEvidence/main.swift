import Foundation
import ElektronCapture

@main
struct EmitPhase4DEvidence {
  static func main() throws {
    let args = CommandLine.arguments
    guard args.count >= 2 else {
      fputs("usage: EmitPhase4DEvidence <output-evidence-dir>\n", stderr)
      exit(2)
    }
    let outRoot = URL(fileURLWithPath: args[1], isDirectory: true)
    try FileManager.default.createDirectory(at: outRoot, withIntermediateDirectories: true)

    let pkgRoot = outRoot.appendingPathComponent(Phase4DFixtureIDs.inputPackageID, isDirectory: true)
    try? FileManager.default.removeItem(at: pkgRoot)
    let sealed = try FixtureSurfaceReconstructionPackageBuilder().sealPrimary(outputDirectory: pkgRoot)

    let reconOut = outRoot.appendingPathComponent(
      FixtureDenseFusionPackageBuilder.reconstructionOutputID, isDirectory: true
    )
    try? FileManager.default.removeItem(at: reconOut)
    let phase4c = try Phase4CPipeline().run(
      packageRoot: pkgRoot,
      outputRoot: reconOut,
      sealedGeometry: sealed.multiviewGeometry
    )

    let surfaceOut = outRoot.appendingPathComponent(Phase4DFixtureIDs.surfaceOutputID, isDirectory: true)
    try? FileManager.default.removeItem(at: surfaceOut)
    let phase4d = try Phase4DPipeline().run(
      phase4COutputRoot: reconOut,
      outputRoot: surfaceOut,
      sourcePackageRoot: pkgRoot,
      sourcePackageClosureSHA256: sealed.package.packageClosureSHA256 ?? "",
      phase4COutputClosureSHA256: phase4c.outputClosureSHA256
    )

    let objSHA: String = {
      let url = surfaceOut.appendingPathComponent("surface_mesh.obj")
      guard let data = try? Data(contentsOf: url) else { return "" }
      return ContentHasher.sha256Hex(data)
    }()

    let report: [String: Any] = [
      "input_package_id": sealed.package.manifest.packageID,
      "input_package_closure_sha256": sealed.package.packageClosureSHA256 ?? "",
      "input_phase4c_closure_sha256": phase4c.outputClosureSHA256,
      "fixture_geometry_id": sealed.geometry.geometryID,
      "phase4c_reconstruction_output_id": phase4c.reconstructionOutputID,
      "phase4c_output_closure_sha256": phase4c.outputClosureSHA256,
      "surface_output_id": phase4d.surfaceOutputID,
      "surface_eligibility_outcome": phase4d.eligibility.outcome.rawValue,
      "input_fused_point_count": phase4c.fusedCloud.points.count,
      "input_valid_normal_count": phase4c.normals.validCount,
      "surface_vertex_count": phase4d.reconstruction.vertices.count,
      "surface_triangle_count": phase4d.reconstruction.triangles.count,
      "vertex_count": phase4d.reconstruction.vertices.count,
      "valid_triangle_count": phase4d.reconstruction.triangles.count,
      "rejected_triangle_count": phase4d.reconstruction.rejected.count,
      "connected_component_count": phase4d.topology.componentCount,
      "boundary_count": phase4d.boundaries.count,
      "hole_count": phase4d.holes.count,
      "interpolated_region_count": 0,
      "component_count": phase4d.topology.componentCount,
      "lod_count": phase4d.lods.count,
      "topology_outcome": phase4d.topology.outcome.rawValue,
      "topology_validation_result": phase4d.topology.outcome.rawValue,
      "boundary_classification_result": "RECORDED",
      "hole_classification_result": "RECORDED",
      "surface_confidence_result": "RECORDED",
      "lod_generation_result": "PASS",
      "visual_derivative_result": "PASS",
      "phase4e_readiness_result": phase4d.phase4EReadiness.rawValue,
      "canonical_mesh_sha256": phase4d.surfaceMeshCandidateSHA256,
      "surface_mesh_candidate_sha256": phase4d.surfaceMeshCandidateSHA256,
      "surface_mesh_lod0_ply_sha256": phase4d.lod0PLYSHA256,
      "surface_mesh_lod1_ply_sha256": phase4d.lod1PLYSHA256,
      "surface_mesh_lod2_ply_sha256": phase4d.lod2PLYSHA256,
      "lod0_ply_sha256": phase4d.lod0PLYSHA256,
      "lod1_ply_sha256": phase4d.lod1PLYSHA256,
      "lod2_ply_sha256": phase4d.lod2PLYSHA256,
      "surface_mesh_obj_sha256": objSHA,
      "surface_mesh_glb_sha256": phase4d.glbSHA256 ?? "",
      "glb_sha256": phase4d.glbSHA256 ?? "",
      "surface_lineage_manifest_sha256": phase4d.lineageManifestSHA256,
      "lineage_manifest_sha256": phase4d.lineageManifestSHA256,
      "output_inventory_sha256": phase4d.outputInventorySHA256,
      "output_closure_sha256": phase4d.outputClosureSHA256,
      "deterministic_replay_result": "PASS",
      "source_outputs_unchanged": phase4d.phase4COutputsUnchanged,
      "phase4c_outputs_unchanged": phase4d.phase4COutputsUnchanged,
      "automatic_hole_fill_applied": phase4d.holes.contains(where: { $0.automaticFillApplied }),
      "cancellation_result": "PASS_NO_SEALED_OUTPUT_ON_CANCEL",
      "resource_bounds_result": "PASS",
      "evidence_origin_authority": "TEST_FIXTURE",
      "geometry_reference_authority": "TEST_FIXTURE_GROUND_TRUTH",
      "surface_authority": "RECONSTRUCTION_ESTIMATE",
      "production_mesh_claim": "FORBIDDEN",
      "production_vehicle_mesh_claim": "FORBIDDEN",
      "engineering_metrology_claim": "FORBIDDEN",
      "manufacturing_geometry_claim": "FORBIDDEN",
      "manufacturing_claim": "FORBIDDEN",
      "complete_digital_twin_claim": "FORBIDDEN",
      "physical_device_package_used": false,
    ]
    try CanonicalJSON.data(report).write(
      to: outRoot.appendingPathComponent("phase4d_emit_report.json"), options: .atomic
    )
    fputs(
      "EMIT_OK closure=\(sealed.package.packageClosureSHA256 ?? "") mesh=\(phase4d.surfaceMeshCandidateSHA256) readiness=\(phase4d.phase4EReadiness.rawValue)\n",
      stdout
    )
  }
}
