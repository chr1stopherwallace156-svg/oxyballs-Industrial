# POSTMORTEM_INTERACTION_PIPELINES.md

| Field | Value |
|---|---|
| Status | **ADOPTED** (engineering retrospective) |
| Version | 1.0.0 |
| Owner | elektron-capture-ios |
| Last Updated | 2026-07-27 |
| Branch context | `cursor/sprint-2-1f-save-and-exit-d881` |
| Related | `INTERACTION_PIPELINE_GUARDRAILS.md`, `Docs/Capture/AUTHORITATIVE_COMMIT_PROPAGATION_CONTRACT.md`, `Docs/Capture/SPRINT_2_1F_ACTION_PARITY.md` |
| Classification | Explains *why* defects existed — not a change log of patches |

> Preserve this document. Do not treat it as a chat artifact. Extracted permanent rules live in
> [`INTERACTION_PIPELINE_GUARDRAILS.md`](INTERACTION_PIPELINE_GUARDRAILS.md) and
> [`CURSOR_OPERATING_RULES.md`](../../CURSOR_OPERATING_RULES.md) § Interaction pipelines.

---

## Mission of this retrospective

Explain **why** multiple independent-looking field failures were possible while Capture/Retake/persist still worked on device. Ground truth was not cloud sync or a powered-down Mac — it was incomplete action pipelines and overloaded lifecycle gates under a UI-first delivery pattern.

---

## Physical device ground truth (what forced the diagnosis)

| Observation | Implication |
|---|---|
| Photos capture; Retake works; evidence survives relaunch | Persistence and camera paths were alive |
| “Done” stayed disabled with 0 / 2 / all-6 photos | Field exit conflated with terminal completion |
| Delete / Archive / Restart / Assign / View Details → “nothing” | Menus rendered without a completed last-mile effect |
| Manual Refresh did not always heal Library | Projection/catalog ≠ session authority |

---

## Per-defect: why it was possible

### 1. View Details — silent no-op

**Architectural assumption**  
“If the router sets `navigationEvidenceId` and a `navigationDestination(for: String.self)` exists, navigation is done.” That assumes a consumer of the published id. Presentation was split across three pieces (intent → published id → path append) with no compile-time link.

**Cause class**  
AI/scaffold placeholder + incomplete refactor. The `.onChange` handler discarded the id (`_ = newId`). Not a missing coordinator or repository write — a **missing router→presentation connection**.

**Earlier detection**  
Navigation verification test: perform `.viewDetails` → `NavigationPath` contains evidence id. Rule: every published navigation intent has exactly one adopter that mutates path. Lint discarding of action state (`_ = newId`).

**Pattern**  
Intent surface shipped before the last presentation hop was finished.

---

### 2. Delete Photo / Assign / Inspection menus appearing as “nothing”

**Architectural assumption**  
“If swipe/context menu calls `router.perform(.…)` and the switch case is non-empty, the user will see a result.” That ignores confirmation-dialog affinity, `statusMessage` with no alert sink, Assign only when `assignablePoints` is non-empty, and projections that can look unchanged when catalog and session diverge.

**Cause class**  
Incomplete presentation wiring + silent success/failure channels (+ earlier dual-store/refresh issues). Device “nothing” often meant: intent ran, confirm never appeared on the presented hierarchy, or UI never showed status / projection didn’t move — not necessarily an empty `switch`.

**Earlier detection**  
Assert confirmation presentation after `.delete`; assert Assign visibility with/without active plan; assert every `pending*` / `statusMessage` has a visible observer on the screen that owns the menu.

**Pattern**  
Actions terminate in **published pending state or string status** without a guaranteed visible sink.

---

### 3. Create New Inspection from This Plan — unreachable when session active

**Architectural assumption**  
Modeled as “start only if nothing is active,” while the menu lives on an **active** inspection’s detail. Product intent conflicted with a lifecycle gate copied incompletely from Restart (Restart cancels first; Create did not).

**Cause class**  
Incomplete refactor / inconsistent sibling APIs — not a stub enum case.

**Earlier detection**  
Test: with active session, createNewFromPlan yields a new `sessionID`. Rule: sibling mint-session intents share cancel→start or document why they don’t.

---

### 4. Archive — non-durable / looks like a no-op

**Architectural assumption**  
Archive = hide from list via `UserDefaults` while the menu label reads like a domain lifecycle transition.

**Cause class**  
Product/architecture mismatch (presentation filter underweighted in UI). Not a missing switch case.

**Earlier detection**  
Acceptance: Archive removes group from visible list and survives relaunch on this device; label/docs say “Hide from list (local)” vs durable domain archive.

---

### 5. Done always disabled despite photos

**Architectural assumption (earlier model)**  
Top-level Done = Complete Inspection, gated on `canCommitCompletion` (required **workflows** resolved — not merely N photos bound). Photos can exist while points stay non-terminal → Done stays disabled forever.

**Cause class**  
Lifecycle conflation: evidence satisfaction ≠ point workflow completion ≠ field exit. Corrected by splitting **Save & Exit** from **Complete Inspection**. Device reports labeled “Done” may still reflect an older binary or the gated Complete control.

**Earlier detection**  
Field scenario tests: 0/1/mid photos → leave must be enabled. Forbid attaching completion gates to the Capture banner escape hatch.

---

### 6. Dual EvidenceLibraryStore / Refresh that only reloads catalog

**Architectural assumption**  
Each feature owns an `EvidenceLibraryStore` actor; Refresh reloads the catalog. Missed: multi-actor cached index can rewrite disk and resurrect deletes; Refresh without re-adopting the session violates SSOT.

**Cause class**  
Incomplete authority/projection design after splitting Capture vs Library.

---

## Correlation: one choke point or many?

**Mostly several defects under one dominant development pattern**, not one dead repository:

| Shared underlying cause | Symptoms |
|---|---|
| Incomplete last-mile presentation | View Details; some “silent” deletes/confirms |
| Lifecycle/product conflation | Done disabled despite photos |
| Sibling APIs with inconsistent preconditions | Create New vs Restart |
| Projection/catalog ≠ session authority | Delete “returns”; Refresh doesn’t help |
| Soft local filters sold as domain actions | Archive |

Capture/Retake working proved persistence was alive. Failures clustered around **action→presentation and lifecycle gates**.

---

## Practices that allowed silent no-ops to accumulate

1. **UI-first delivery** — menus shipped before every hop had an adopter.  
2. **Compile-green placeholders** (`_ = newId`, empty `onChange`, `statusMessage` with no alert).  
3. **Phase gate skipped in spirit** — interaction surfaces expanded while field exit and authority propagation were still soft.  
4. **Linux unit tests without navigation/UI presentation tests** — domain green ≠ device menu green.  
5. **Published pending flags without “must be observed” invariants.**  
6. **Label/semantics drift** (Done / Archive / Completed) without acceptance tests tied to field language.

---

## If process is unchanged for a year — recurring classes

- Context menus whose intents only set `@Published` flags  
- Confirmation dialogs on the wrong view hierarchy  
- “Refresh” that reloads the wrong layer  
- Lifecycle booleans collapsed into one `isComplete`  
- Dual stores/caches for the same on-disk root  
- UserDefaults presentation state mistaken for domain commits  

---

## Lessons learned

**Primary root cause**  
Actions were treated as complete when the SwiftUI control and intent enum existed, not when the full pipeline (intent → operation → persist/adopt **or** navigation **or** user-visible error) was proven. Silent no-ops are the natural product of that definition of “done.”

**Secondary contributing factors**  
Lifecycle conflation; incomplete sibling APIs; multi-actor catalog caches; presentation status without UI sinks; Phase B/C UI ahead of Phase A field/authority proof; no navigation/pending-dialog tests.

**Preventive measures**  
Define “shipped action” as: *wired UI → handled intent → real operation → durable effect or user-visible failure*. Keep Phase A gates real. Prefer one adoption path. Add intent coverage + navigation + pending-dialog tests before expanding menus. Enforce [`INTERACTION_PIPELINE_GUARDRAILS.md`](INTERACTION_PIPELINE_GUARDRAILS.md).

**Definition of shipped action**

```text
Visible control
  → Typed domain intent
  → Handled router/coordinator case (no default stub)
  → Durable effect OR navigation OR user-visible error
Never: compile-green empty closure / discarded publisher / status string with no sink
```

---

## Recommended repair sequence (historical; for future incidents)

1. Investigation-first action-flow traces (do not patch symptoms).  
2. Close last-mile presentation disconnects (navigation, confirm dialogs).  
3. Align sibling lifecycle APIs (cancel→start).  
4. Enforce SSOT: persist → adopt → recompute; Refresh reloads session.  
5. Separate field Save & Exit from gated Complete Inspection.  
6. Device smoke before claiming tip validated.
