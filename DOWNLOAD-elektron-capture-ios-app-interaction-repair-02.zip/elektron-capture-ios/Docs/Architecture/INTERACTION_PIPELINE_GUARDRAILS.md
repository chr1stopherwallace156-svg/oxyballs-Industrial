# INTERACTION_PIPELINE_GUARDRAILS.md

| Field | Value |
|---|---|
| Status | **APPROVED** (Sprint 2.1F+) |
| Version | 1.0.0 |
| Owner | elektron-capture-ios |
| Last Updated | 2026-07-27 |
| Applies To | All inspection / evidence / point / library interaction work |
| Origin | [`POSTMORTEM_INTERACTION_PIPELINES.md`](POSTMORTEM_INTERACTION_PIPELINES.md) |
| Also | [`AUTHORITATIVE_COMMIT_PROPAGATION_CONTRACT.md`](../Capture/AUTHORITATIVE_COMMIT_PROPAGATION_CONTRACT.md) |

These rules are **permanent**. They are enforced via Cursor operating rules and must not be treated as optional guidance.

---

## IPG-1 — Definition of a shipped action

A visible menu item, swipe action, toolbar button, or context-menu entry is **not shipped** until all of the following are true:

1. UI control is wired to a typed `*ActionIntent` (or an explicitly documented exception).  
2. The intent has a non-default, non-empty router/coordinator branch.  
3. The operation produces a durable effect, a navigation transition, **or** a user-visible error.  
4. There is at least one automated test or an explicit device-smoke checklist item covering the path.

**Forbidden:** empty closures `{}`, `_ = publishedValue`, `TODO` / stub handlers, `try?` that swallows persistence errors without UI feedback, `statusMessage` with no on-screen observer.

---

## IPG-2 — Intent coverage matrix (mandatory for new intents)

Every case in:

- `EvidenceActionIntent`
- `PointActionIntent`
- `InspectionActionIntent`

must appear in an up-to-date matrix (see `Docs/Capture/SPRINT_2_1F_ACTION_PARITY.md` or successor) with columns:

| Intent | UI entry point(s) | Router case | Durable write / navigation | Test or device smoke |

Adding an intent without updating the matrix is incomplete work.

---

## IPG-3 — No completion gate on the field escape hatch

The Capture banner / field leave control **must not** bind `canCommitCompletion` (or equivalent terminal validation).

- Field leave = **Save & Exit** → persist `.inProgress`, same `sessionID`.  
- Terminal finalize = **Complete Inspection** → gated; Review / More / Detail only.

---

## IPG-4 — Published pending / navigation state must have an adopter

Any `@Published` field used for:

- confirmation (`pendingDelete*`, `pendingRestartConfirm`, …)
- navigation (`navigationEvidenceId`, …)
- operator status (`statusMessage`, `mediaWarning`, …)

must have a **compile-time or test-proven consumer** on the view that owns the triggering control. Setting the flag alone is not an implementation.

---

## IPG-5 — Authoritative commit propagation

Session-changing actions obey:

```text
Typed Intent → Operation → Immutable Domain Transition
→ Persist → Exact Committed Session → Adopt current
→ Recompute projections → UI / navigation → Media cleanup last
```

Rules:

1. Same stable `sessionID` unless the action explicitly mints a new inspection.  
2. Child VMs hold read-only projections only — no independently mutable `InspectionSession` copies.  
3. Notifications invalidate; they never carry authoritative session state.  
4. Manual Refresh reloads the committed session from the repository, then recomputes projections. Catalog-only refresh is insufficient.  
5. Failed persistence leaves the previously authoritative session unchanged.

Full contract: `Docs/Capture/AUTHORITATIVE_COMMIT_PROPAGATION_CONTRACT.md`.

---

## IPG-6 — Evidence library store identity

Do not introduce a second long-lived `EvidenceLibraryStore` over the same library root without a disk-merge / invalidate contract. Index mutations must not resurrect soft-deleted rows from a stale actor cache. Prefer one shared store, or always `reloadIndexFromDisk()` before write-merge.

---

## IPG-7 — Sibling lifecycle APIs must be consistent

Inspection intents that mint a new session (`createNewFromPlan`, `restartCurrent`, …) must share the same cancel/replace contract **or** document an intentional difference in the action-parity matrix. Silent “blocked when active” guards on menus that only appear for active sessions are defects.

---

## IPG-8 — Presentation-only vs domain actions

If an action only mutates UserDefaults / UI filters (e.g. local archive hide), the UI label and docs must say so. Do not present presentation filters as durable domain lifecycle transitions unless repository/session status is updated.

---

## IPG-9 — Phase gate discipline

Do not expand Phase B/C interaction surfaces until Phase A (field exit, approval failure semantics, authoritative adoption) is checkpointed and green. Do not claim Phase A passed without the intermediate checkpoint artifact.

---

## IPG-10 — Verification minimum before “device-validated”

Linux `swift test` alone does **not** authorize `DEVICE_VALIDATED`. For interaction tips, require the field smoke items in `Docs/Capture/FIELD_REGRESSION_CHECKLIST.md` (or successor), including at least:

- Save & Exit with 0 and 1 photo; Resume same `sessionID`  
- View Details / Assign / Delete from unassigned context menu  
- Archive / Restart / Delete Inspection (with confirm)  
- Zero legacy approval flash on Use Photo  

Until then, status remains `IMPLEMENTED_PENDING_XCODEBUILD_AND_DEVICE_VALIDATION` (or stricter).

---

## Required tests / CI (minimum set)

| Test class | Catches |
|---|---|
| Intent router case coverage (compile or unit) | Unhandled / orphan intents |
| Navigation after `.viewDetails` | Dead onChange / discarded path |
| Pending-flag ⇒ dialog binding true on host view | Confirm never shown |
| Persist failure leaves prior session | Silent clear of authority |
| Soft-delete then other-store write | Index resurrection |
| Manual Refresh restores committed session by id | Stale projections |
| Save & Exit with 0 photos stays `.inProgress` | Completion gate on field exit |
| Create New / Restart mint new session id | Sibling API inconsistency |

DEBUG builds should prefer runtime assertions over silent no-ops when an intent is performed and neither adoption, navigation, nor error presentation occurs within the same turn.
