# ADR — Session Recovery & Quarantine Policy

| Field | Value |
|---|---|
| Status | **Accepted (policy); Implementation PENDING** |
| Applies to | Inspection session envelopes, multi-session store, evidence library |
| Date | 2026-07-27 |
| Sprint | 2.3 Foundation |
| Related | `SPRINT_2_3_ADVERSARIAL_HARDENING_AND_RECOVERY_SPEC.md`, `SPRINT_2_3_FOUNDATION_AUDIT.md` |

## Context

Evidence Library already quarantines soft-deleted and unrecognized capture directories under `EvidenceLibrary/.quarantine/`. Inspection session JSON does not:

- Truncated / malformed `current_session.json` → `corruptPersistence` → **file cleared**
- Integrity digest mismatch → throw; **no isolate**
- `FileInspectionSessionStore.list()` → silently skips unreadable files

Sprint 2.3 requires deterministic recovery under power loss, partial writes, and corrupt envelopes. Implementing a journal or quarantine engine **before** locking disposition policy risks silent data loss or permanent lockout via ad-hoc Cursor logic.

Atomic temp + `.bak` replace exists today. That is **not** a recovery journal.

## Decision

### A. Disposition matrix (normative)

| Fault class | Disposition | Rationale |
|---|---|---|
| Malformed / truncated inspection JSON | **Quarantine** under `InspectionSessions/.quarantine/` with reason + UTC stamp; do **not** delete | Bytes preserved for forensics; app continues with empty/current-other sessions |
| Integrity digest mismatch | **Quarantine** (same root); surface `integrityMismatch` to UI | Distinguishes bit-rot / partial write from schema issues |
| Unsupported future schema | **Refuse migrate**; leave file in place; optional copy to quarantine as `unsupported_schema_*` | Matches existing fail-closed migrator; quarantine copy is advisory backup |
| Missing referenced media (library) | **Preserve & flag** `.missing` / `.missingArtifact` | Already implemented — keep |
| Orphan media (JPEG, no index) | **Rebuild index row** when reconstructable; else quarantine | Already implemented — keep |
| Soft-delete (user) | **Quarantine** capture dir; remove index row | Already implemented — keep |
| Duplicate evidence IDs | **Explicit conflict state**; never silent pick | Spec requirement — still pending implementation |
| Stale revision commit | **Reject** with `staleRevisionConflict`; durable head unchanged | S2-004 `expectedRevision` OCC |
| Recovery / backup adoption with lower revision | **Refuse overwrite** when `recovered.revision < durable.revision`; quarantine recovered payload instead | **Recovery monotonicity** — automated recovery must not time-travel the durable head backward |
| Interrupted multi-step delete (unbind → media) | **Session commit wins**; media failures → warning + retryable quarantine | Existing router order; journal may record intent later |
| Abrupt process kill mid-write | Temp/bak restore if bak present; else quarantine incomplete tmp; never promote partial dest | Journal Phase 2 |

### B. Forbidden behaviors

1. Silent discard of inspection JSON without quarantine copy.
2. Reconstructing session bindings from capture sidecars as authoritative session state.
3. Last-write-wins overwrite of same-id session without `expectedRevision` check (S2-004).
4. Caller-minted next revision succeeding at the repository boundary.
5. Recovery adoption that overwrites durable head `H` with recovered revision `R` where `R < H`.
6. Inventing recovery-journal semantics in production code before this ADR’s Phase 2 checklist is checked off in a dedicated change.

### C. Quarantine layout (when implemented)

```text
InspectionSessions/
  current_session.json          # authoritative current (or absent)
  sessions/<SessionID>.json
  .quarantine/
    <utc>_<reason>_<name>.json
    <utc>_<reason>_<name>.json.meta.json   # reason, original path, error class
```

Evidence Library quarantine path and naming remain unchanged.

### D. Recovery journal (Phase 2 — not in this ADR’s implementing PR unless separately scoped)

Only after this ADR is Accepted:

1. Define journal record schema (intent id, expected revision, stages, rollback).
2. Injectable FileManager / fault injector for tests.
3. Cold-launch: replay or roll back to last committed atomic state, then quarantine leftovers.
4. No journal → no claim of abrupt-kill recovery.

### E. Implementation order (mandatory)

1. ~~Revision OCC (payload-carried base)~~ → superseded by S2-004
2. ~~Phase A writer inventory + S2-004 `expectedRevision` ADR + repository sole assigner~~ (**done**)
3. Session JSON quarantine on corrupt/integrity paths (replace `clear()`-only behavior)
4. Recovery adoption monotonicity enforcement in code (refuse `R < H`)
5. Duplicate-ID conflict state
6. Recovery journal + kill/fault harnesses
7. App integration / UITest targets + Tier 2/3 CI

## Consequences

- Product may show “session recovered / quarantined corrupt file” instead of silent empty start — UX copy must be explicit.
- Tests that expect corrupt current session to vanish must be updated when quarantine lands.
- Operators can pull `.quarantine/` off device for support without guessing deleted bytes.

## Alternatives rejected

| Alternative | Why rejected |
|---|---|
| Keep clear-on-corrupt forever | Spec forbids silent discard of inspection JSON |
| Auto-repair corrupt JSON | Invents state; violates fail-closed posture |
| Journal before disposition ADR | Encourages ad-hoc recovery; hard to reverse |
| Tombstone-only without bytes | Loses forensics for field failures |

## References

- `Docs/Capture/SPRINT_2_3_ADVERSARIAL_HARDENING_AND_RECOVERY_SPEC.md`
- `Docs/Capture/SPRINT_2_3_FOUNDATION_AUDIT.md`
- `App/Phase1/Inspection/SessionRevisionGuard.swift`
- `App/Phase1/EvidenceLibrary/EvidenceLibraryStore.swift` (media quarantine precedent)
