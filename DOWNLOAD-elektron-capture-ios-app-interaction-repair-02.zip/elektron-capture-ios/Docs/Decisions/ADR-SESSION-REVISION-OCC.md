# ADR — Optimistic Concurrency: `expectedRevision` + Repository Sequence Assignment

| Field | Value |
|---|---|
| Status | **Accepted** |
| Decision ID | **S2-004** |
| Date | 2026-07-27 |
| Sprint | 2.3 Phase B |
| Supersedes | Informal “caller bumps `session.revision`” reading of Step 1 |
| Related | `SessionRevisionGuard.swift`, Phase A writer inventory, S2-003 recovery ADR |

## Context

Step 1 introduced monotonic `InspectionSession.revision` with compare-and-bump inside stores. That stopped last-write-wins, but left an API ambiguity:

- If a caller may set `session.revision = 11` and have that value interpreted as either “I expect base 11” **or** “I am writing revision 11”, the caller can assert a **future** sequence number it has no authority to mint.
- True OCC separates **expectation** (what the caller last observed) from **assignment** (what the repository commits).

Linearizability must be established at the exact boundary where state becomes durable: the repository `save`.

## Decision

### 1. Authoritative sequence assignment

```text
Caller supplies:  payload SessionState + expectedRevision: N
Repository:       load storedRevision
                  require expectedRevision == storedRevision   (empty slot ⇒ storedRevision ≡ 0, expect 0)
                  assign revision := storedRevision + 1        (first write ⇒ 1)
                  persist payload with assigned revision
                  return newly minted SessionState
```

Rules:

1. **Repository is the sole assigner** of `N+1`. Callers never successfully publish a self-chosen next revision.
2. **`expectedRevision` is an explicit save parameter**, not inferred from a caller-mutated `session.revision` at the repository boundary.
3. Incoming `session.revision` on the payload is **ignored for sequencing** (may be overwritten by the assigned value before encode).
4. Same-id only for ``save``: empty slot requires `expectedRevision == 0`. Different-id overwrite via `save` is **forbidden** (`slotOccupied`); use ``replaceCurrentSession(_:expectedIncumbentRevision:)``.
5. Legacy payloads missing `revision` decode as `0`; first valid write migrates to `1`.

### 2. Rejected commits are side-effect free

On `staleRevisionConflict` (or any pre-commit failure):

- **Zero** new durable artifacts (no dest replace, no promoted `.tmp`)
- **Zero** mutation of caller-owned in-memory session values (Swift value semantics + no cache adopt on throw)
- Service / coordinator must not `setCache` / `adopt` on failure

Best-effort cleanup of an unpromoted `.tmp` written after OCC passed but before replace completed remains an atomic-write concern (unchanged); OCC failure must occur **before** any temp write begins.

### 3. Service / coordinator ports

- `CurrentSessionRepository.save(_:expectedRevision:)`
- `InspectionSessionStore.save(_:savedAt:expectedRevision:)`
- `InspectionSessionService.applyUpdatedSession(_:expectedRevision:)` (and create/transition paths pass `0` or cache revision explicitly)
- `GuidedSessionPersisting.persistGuidedSession` passes `expectedRevision: session.revision` where `session` is the last adopted authoritative value (expectation), never a fabricated next id

### 4. Error surface

```swift
InspectionSessionError.staleRevisionConflict(current: Int, attempted: Int)
// current   = durable storedRevision (0 if empty when expectation non-zero)
// attempted = expectedRevision supplied by caller
```

### 5. Recovery monotonicity (cross-link)

Recovery / quarantine adoption **must not** overwrite a durable head `H` with a recovered payload whose revision `R` satisfies `R < H`. See `ADR-SESSION-RECOVERY-AND-QUARANTINE.md`.

## Consequences

- All writers in Phase A inventory that call `save` must pass `expectedRevision`.
- Tests must prove: payload `session.revision = 99` with `expectedRevision = stored` still commits as `stored+1` (repository assignment).
- Controlled interleaving: A and B read `N`; B commits; A’s `expectedRevision: N` fails; head remains B’s `N+1`.

## Alternatives rejected

| Alternative | Why rejected |
|---|---|
| Caller pre-increments `session.revision` then store checks `incoming == stored+1` | Caller asserts the future; races and confused clients mint sequences |
| Compare `savedAt` / digest only | Not a monotonic sequence; clock skew / rewrite hazards |
| Keep dual-meaning `session.revision` on save | Exploitable ambiguity |

## Status label

Until Phase A inventory + this ADR are committed, engineering status remains:

`SPRINT_2_3_SPEC_APPROVED_IMPLEMENTATION_PENDING`

Phase C implements this ADR at every inventoried save boundary.
