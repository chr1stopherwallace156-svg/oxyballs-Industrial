# App Interaction Repair 02 — Mac compile-fix pass

Baseline: PR #71 commit `23f20c02ac560080dd24f13ae7418734038b2aab`,
`DOWNLOAD-elektron-capture-ios-app-interaction-repair-01.zip`
sha256 `1063df0e126ebde1982ee4defda66026b9dc061893553f4125e1b29ee11d3700` (digest re-verified
before any edit).

```
REPAIR_02_SCOPE =
1. Correct invalid optional chaining in clearIfHolding(sessionID:)
2. Decompose EvidenceLibraryListView SwiftUI body to remove compiler type-check timeout
3. Preserve all PR #71 runtime behavior and persistence semantics
```

## Compile-failure evidence

**Blocker 1 — reported by the owner from Xcode.**
`App/Phase1/Inspection/CurrentSessionRepository.swift`, `clearIfHolding(sessionID:)` shipped:

```swift
guard let existing = try? loadExistingForOCC(), existing?.id.rawValue == sessionID else {
```

`try?` flattens nested optionals (SE-0230), so `guard let existing` binds a **non-optional**
`InspectionSession` and optional chaining on it is invalid. Corrected to the owner's exact
expression, `existing.id.rawValue == sessionID`. A throw and an empty slot both still yield
`nil` and still fall through to `return false`.

**Blocker 2 — current Xcode error.**
`Apps/Phase1StillCapture/EvidenceLibraryViews.swift`, `EvidenceLibraryListView`:
*"The compiler is unable to type-check this expression in reasonable time."* Xcode pointed at
the `ProgressView` branch; that is where the timeout surfaced, not the defect. Repair 01 had
grown a single `body` expression containing a three-way content branch, a four-section `List`
with nested `ForEach` + row modifiers, three navigation destinations, a toolbar, `.refreshable`,
`.task`, `.onChange`, two confirmation dialogs and five alerts.

**Additional compile errors found and fixed during this pass** (all would have blocked the
build after blockers 1–2 cleared):

| # | Defect | Sites |
|---|---|---|
| 3 | `await` inside an `XCTAssert…` / `XCTUnwrap` autoclosure — *"'async' call in an autoclosure that does not support concurrency"* | **31** across the three Repair 01 test files |
| 4 | `EvidenceLibraryIndexRecord` constructed with a non-existent initializer (missing `sessionId` / `artifactId` / `recordId` / `originalByteCount`; wrong state type) | new boundary test helper |
| 5 | `Button(role: cond ? .destructive : nil)` — implicit-member lookup opposite `nil` in a ternary; now `ButtonRole.destructive` | `EvidenceLibraryViews.swift` |
| 6 | `InspectionReviewView.body` — same oversized-expression shape as blocker 2 (133 lines, 12 chained modifiers), enlarged by Repair 01 | decomposed preventively |

Item 6 is a judgement call beyond the two named blockers: the view has the identical shape that
just failed, Repair 01 is what enlarged it, and shipping a ZIP that predictably dies on the next
file would waste another Mac cycle. Flagged here rather than done silently.

## How the type-check timeouts were fixed

No `AnyView`. The oversized bodies are split into small named pieces, and the long modifier
chains into narrow `ViewModifier` types so the compiler solves a handful of constraints at a
time:

`EvidenceLibraryListView` — `libraryRoot`, `libraryContent`, `loadingContent`, `emptyContent`,
`populatedLibraryList`, `disclaimerSection`, `inspectionsSection`, `inspectionRow(for:)`,
`inspectionSwipeActions(for:)`, `deletedInspectionEvidenceSection`, `unassignedEvidenceSection`,
`evidenceRow(for:isUnassigned:)`, `refreshToolbarContent`, `refreshToolbarControls`,
`refreshControl`; plus `LibraryNavigationDestinations`, `LibraryDestructiveDialogs`,
`LibraryStatusAlerts`, `LibraryRouterAlerts`.

`InspectionReviewView` — `reviewRoot`, `reviewWithSheets`, `reviewBase`, `reviewList`,
`blockingFindingsSection`, `warningFindingsSection`, `exportPreviewSectionIfVisible`,
`refreshToolbarContent`, `refreshToolbarControls`, `refreshControl`; plus `ReviewAlerts`.

Accessibility identifiers are preserved exactly: `LIB-02`, `LIB-03`, `LIB-07`, `LIB-13`,
`LIB-14`, `LIB-15`, `LIB-16`, `REV-02`, `REV-12`, `REV-25`, `GRP-10`, `GRP-12`, `GRP-13`,
`GRP-06`, `EVD-11`.

## Changed files and why

| File | Change |
|---|---|
| `App/Phase1/Inspection/CurrentSessionRepository.swift` | **Blocker 1.** Optional-chaining fix in `clearIfHolding(sessionID:)`. |
| `Apps/Phase1StillCapture/EvidenceLibraryViews.swift` | **Blocker 2.** Body decomposed; modifier chain split into four `ViewModifier` types; explicit `ButtonRole`; partition logic delegated to production code. |
| `Apps/Phase1StillCapture/InspectionReviewView.swift` | Same defect class, preventively decomposed; alerts extracted. |
| `Apps/Phase1StillCapture/AppSessionContainer.swift` | Refresh bookkeeping delegated to `RefreshActivityState` — one implementation, now testable. Public surface (`isRefreshing`, `lastRefreshedAt`, `lastRefreshOutcome`) unchanged. |
| `App/Phase1/Inspection/RefreshActivityState.swift` *(new)* | Platform-neutral re-entrancy guard, "last updated" stamp and last outcome. |
| `App/Phase1/EvidenceLibrary/InspectionLibraryPartition.swift` *(new)* | Platform-neutral live / retained-from-deleted / unassigned split. |
| `Tests/Unit/ClearIfHoldingTests.swift` *(new)* | 8 compiled tests, both repository conformances. |
| `Tests/Unit/EvidenceLibraryBoundaryTests.swift` *(new)* | 7 compiled tests for refresh state and deletion-retention boundaries. |
| `Tests/Unit/{InspectionRecordStore,InspectionDeletion,RefreshOutcome}Tests.swift` | 31 `await`-in-autoclosure compile errors hoisted to statement level. |

`Package.swift`, `project.pbxproj`, and every Phase 4A–4D, camera, LiDAR and reconstruction file
are untouched.

## What did NOT change

Refresh semantics, terminal-session safety, typed `InspectionRefreshOutcome`, tombstone-only
deletion, the retention policy (capture evidence is never touched by inspection deletion),
inspection and evidence identity, the v1 → v2 store migration and its rollback, confirmation-id
capture, `InspectionActionScope` targeting, pull-to-refresh, swipe actions, the
deleted-inspection evidence section, navigation, and every alert host.

`AppSessionContainer.isRefreshing` / `lastRefreshedAt` / `lastRefreshOutcome` remain readable
with the same names and meanings; only their storage moved.

One behavioural repair rides along with the decomposition, and it is a fix rather than a change:
the Session Sync alert now observes `InspectionSessionViewModel` directly. It previously read
`session.inspection.errorText` while observing only the container, so it could fail to re-render
when the error appeared.

## Validation state

```
SOURCE_IMPLEMENTED     = YES
LINUX_STRUCTURAL       = PASS  (balance across all changed files; identifiers preserved;
                                no await-in-autoclosure; no AnyView; API signatures checked
                                against the real declarations) — these are NOT tests
LINUX_COMPILE_STATE    = NOT_POSSIBLE (no Swift toolchain; download.swift.org blocked by policy)
AUTOMATED_TEST_STATE   = NOT_RUN (54 tests shipped, never executed)
MAC_BUILD_STATE        = PENDING
MAC_RUNTIME_STATE      = PENDING
IPHONE_RUNTIME_STATE   = PENDING
```

This pass fixed six real compile defects, two of them reported from your Xcode and four found by
inspection. It cannot prove the build succeeds — only your Mac can. If more errors appear, send
the exact messages and they will be fixed on this branch.

## Mac instructions

```bash
cd ~/Downloads
shasum -a 256 elektron-capture-ios.zip
unzip -q elektron-capture-ios.zip
cd elektron-capture-ios
swift build && swift test
open Phase1StillCapture.xcworkspace
```
