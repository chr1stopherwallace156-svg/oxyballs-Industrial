# Sprint 2.3 — Phase A: Persistent Writer Inventory

| Field | Value |
|---|---|
| Status | **SPRINT_2_3_SPEC_APPROVED_IMPLEMENTATION_PENDING** → inventory **COMPLETE** |
| Authority | Production Swift + tests only |
| Date | 2026-07-27 |
| Scope | Inspection session durability (`current_session.json`, multi-session store) |

This is the read-only baseline required before refining OCC to `expectedRevision` (Phase B/C).  
Protecting one `save` while leaving side doors open is a false sense of security.

---

## Disk layout

| Slot | Path |
|---|---|
| Current session | `Documents/InspectionSessions/current_session.json` (+ `.tmp` / `.bak` during replace) |
| Multi-session | `Documents/InspectionSessions/sessions/<SessionID>.json` (+ `.tmp` / `.bak`) |

**Production wiring:** `AppSessionContainer` → `FileCurrentSessionRepository` only.  
`FileInspectionSessionStore` is OCC-capable but **not** constructed by the app (tests only today).

---

## Writer table

| ID | Symbol / call site | File | Layer | Pre-Phase-C guard | Notes |
|---|---|---|---|---|---|
| W01 | `FileCurrentSessionRepository.save` | `CurrentSessionRepository.swift` | repo | yes (via session.revision) | Sole production disk commit for current session |
| W02 | `FileCurrentSessionRepository.clear` | same | repo | no | Deletes current + `.tmp` |
| W03 | `load` → terminal `clear()` | same | repo | no | Durable delete on terminal load |
| W04 | `InMemoryCurrentSessionRepository.save` | same | helper | yes | In-process only |
| W05 | `InMemoryCurrentSessionRepository.clear` | same | helper | no | |
| W06 | `FileInspectionSessionStore.save` | `InspectionSessionStore.swift` | repo | yes | Not wired in app |
| W07 | `writeAtomically` | same | repo | partial | Private I/O for W06 |
| W08 | `FileInspectionSessionStore.delete` | same | repo | no | |
| W09 | `writeAbandonedTemporary` | same | test seam | **no** | Writes `*.json.tmp` without OCC |
| W10 | `createSession` → save | `InspectionSessionService.swift` | service | via repo | Tests only (no Apps caller) |
| W11 | `startInspection` → save | same | service | via repo | Production create |
| W12 | `recordSuccessfulCapture` → save | same | service | via repo | Unused by Apps; metering via W25 |
| W13 | `applyUpdatedSession` → save | same | service | via repo | Generic commit |
| W14 | `transition` → save | same | service | via repo | pause/resume/complete/cancel |
| W15 | corrupt `restore` → `clear` | same | service | no | Recovery delete |
| W16 | `persistGuidedSession` | `GuidedInspectionCoordinator.swift` | service | via W13 | |
| W17 | `GuidedInspectionCoordinator.handle` | same | coordinator | via W16 | Skips capture/refresh/review/export intents |
| W18 | `AppSessionContainer` wiring | `AppSessionContainer.swift` | app | n/a | File repo + coordinator persister |
| W19–W25 | `InspectionSessionViewModel` start/pause/resume/saveAndExit/complete/cancel/meter | `InspectionSessionViewModel.swift` | app | via service | |
| W26 | `GuidedInspectionViewModel.submit` | `GuidedInspectionViewModel.swift` | app | via W17 | |
| W27–W34 | Router / Overlay / Review / Use Photo double-commit | Apps/* | app | via guided/service | Use Photo = bind + meter (two commits) |
| W35 | `restore` / `refreshAuthoritativeSession` | ViewModel | app | partial | May clear via W03/W15 |
| W36 | `adopt` | ViewModel | app | n/a | Memory only |
| W37 | archive UserDefaults | AppSessionContainer | app | n/a | Not session envelope |
| W38–W42 | Tests: direct save, abandoned tmp, fakes, raw `Data.write` | Tests/Unit | test | varies | Fakes must not be mistaken for prod OCC |

---

## Side-door risks (must remain gated or documented)

1. **W09 `writeAbandonedTemporary`** — public, no OCC; production unused; keep test-only or require expectedRevision if ever promoted.
2. **W03/W15 clear paths** — delete without revision; governed by Recovery ADR (quarantine migration), not OCC.
3. **Test raw disk writes (W42)** — bypass `save`; test-only fixtures.
4. **MemoryPersister fakes (W40)** — return unbumped session; forbidden in production wiring.
5. **Evidence Library** — writes sidecars/index only; **not** session envelopes (separate domain).
6. **Double-commit Use Photo (W32)** — two sequential OCC saves; second must use post-bind returned revision.

---

## Protocol implementors (complete)

| Protocol | Implementors |
|---|---|
| `CurrentSessionRepository` | `FileCurrentSessionRepository`, `InMemoryCurrentSessionRepository` |
| `InspectionSessionStore` | `FileInspectionSessionStore` only |
| `GuidedSessionPersisting` | `InspectionSessionService` (prod); test fakes |

---

## Exit criteria for Phase A

- [x] Every durable session writer identified
- [x] Side doors listed
- [x] Production vs test-only paths distinguished
- [ ] Phase B OCC ADR committed (next)
- [ ] Phase C `expectedRevision` API landed at W01/W04/W06 and all upstream callers
