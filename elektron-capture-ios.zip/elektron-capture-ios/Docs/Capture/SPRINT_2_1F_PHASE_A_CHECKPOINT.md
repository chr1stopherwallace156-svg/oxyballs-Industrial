# Phase A Checkpoint — Transient Approval Flash, Save & Exit, Lifecycle Semantics

| Field | Value |
|---|---|
| **Gate** | MANDATORY before Phase B/C feature expansion |
| **Branch** | `cursor/sprint-2-1f-save-and-exit-d881` |
| **Status** | Phase A + A2 + Authoritative Commit Contract — `IMPLEMENTED_PENDING_XCODEBUILD_AND_DEVICE_VALIDATION` |
| **SSOT** | `Docs/Capture/AUTHORITATIVE_COMMIT_PROPAGATION_CONTRACT.md` |

## 1. Previous `Done` gating vs new `Save & Exit`

| Prior (parity-gated) | Now (A2) |
|---|---|
| Top Capture banner `Done` disabled until `canCommitCompletion` | Banner **`Save & Exit`** always enabled whenever an active/paused session exists |
| `Done` called session `complete()` (terminal) | **Save & Exit** persists `.inProgress` only — never completes, exports, or archives |
| Partial mid-inspection progress could not leave Capture without finishing required points | Tech can leave with 0 photos, 1 photo, or mid-plan and resume later |

**Top navigation pattern:** `[ Pause \| Resume ] · [ Save & Exit ] · [ Cancel ]`

**Cancel** confirms abandon of the *current UI session operation*; it does not silently delete a previously saved `.inProgress` inspection. Copy steers techs to Save & Exit to keep progress.

## 2. Location of strict `Complete Inspection`

| Surface | Behavior |
|---|---|
| **Review tab** actions | `Complete Inspection` — enabled only when `canCommitCompletion` |
| **Capture HUD More menu** | `Complete Inspection` — same gate; on success switches to Review |
| **Inspection Detail `•••`** | `Complete Inspection` via `InspectionActionIntent.completeInspection` |
| Capture banner | **Does not** host Complete Inspection |

Terminal path: `GuidedInspectionCoordinator.commitSessionCompletion` / `InspectionLifecycleEvaluator.canCommitCompletion`.

## 3. Root cause — transient approval screen

`Phase1CaptureViewModel.usePhoto()` always transitioned UI to `.approved` (legacy “Photo Approved / Export Package”) **before** bind/persist completed. The guided handler then called `returnToPreviewAfterApproval()`, producing a one-frame flash. During that flash the Capture header could show “No active inspection”.

**Fix:** Guided Use Photo keeps UI on `.reviewing` (`presentLegacyApprovedScreen: false`), then after successful store → bind/persist → adopt performs **one** transition to `.previewing` with a non-blocking toast. Active session identity is never cleared on success.

## 4. Phase A failure semantics

| Failure | Behavior |
|---|---|
| Store payload fails | Remain on approval preview; typed store error; no toast; no legacy export screen |
| Bind/persist fails | Remain on approval preview; prior session untouched; no toast; no media quarantine |
| Session identity diverges after adopt | Fatal sync alert; do not dismiss; prior session kept |
| Save & Exit persist fails | Remain on Capture; prior session untouched; typed error; no tab switch |

## 5. Verified lifecycle transition rules

Layers are **not** collapsed:

1. Point evidence satisfaction — derived binding counts  
2. Point workflow — `notStarted` / `inProgress` / `completed` / `skipped` / `blocked`  
3. Inspection workflow presentation — `inProgress` → `readyForReview` → `completed` → `exported`  
4. Export readiness — exclusively from `InspectionExportPolicy` / validation report  
5. Export history — `exported` only when `SessionStatus.completed` **and** package flag  

**Rules:**
- Sufficient evidence without terminal point transition → “Evidence satisfied — ready to complete”
- Unresolved required workflows → cannot show `Completed`; Complete Inspection stays disabled
- Save & Exit with partial evidence → remains `.inProgress` (never Ready/Completed)
- Completed + export-blocked findings → `Lifecycle: Completed` + `Export: Export Blocked`
- Resume restores exact session ID, active point, bindings, and skip/block reasons

## 6. Modified files (Phase A + A2)

**Phase A (flash / lifecycle):**
- `App/Domain/Services/InspectionLifecyclePresentation.swift`
- `Apps/Phase1StillCapture/Phase1CaptureRootView.swift`
- `Apps/Phase1StillCapture/GuidedInspectionViewModel.swift`
- `Tests/Unit/Sprint2_1F_PhaseA_CheckpointTests.swift`

**Phase A2 (Save & Exit):**
- `Apps/Phase1StillCapture/InspectionSessionViewModel.swift` — `saveAndExit()`
- `Apps/Phase1StillCapture/AppSessionContainer.swift` — persist → leave Capture → Review confirmation
- `Apps/Phase1StillCapture/InspectionSessionViews.swift` — banner pattern
- `Apps/Phase1StillCapture/GuidedInspectionOverlayView.swift` — More menu Complete + Save & Exit
- `Apps/Phase1StillCapture/InspectionReviewView.swift` — Resume Capture + Complete Inspection
- `Apps/Phase1StillCapture/InspectionActionRouter.swift` — `InspectionActionIntent.saveAndExit` / `.completeInspection`
- `Apps/Phase1StillCapture/EvidenceLibraryViews.swift` — inspection `•••` menu
- `Tests/Unit/Sprint2_1F_SaveAndExitTests.swift`
- `Docs/Capture/SPRINT_2_1F_PHASE_A_CHECKPOINT.md`

## 7. Test command

```bash
swift test --filter Sprint2_1F_PhaseA_CheckpointTests
swift test --filter Sprint2_1F_SaveAndExitTests
swift test
```

`xcodebuild` / physical device: **NOT RUN** on this Linux host.
