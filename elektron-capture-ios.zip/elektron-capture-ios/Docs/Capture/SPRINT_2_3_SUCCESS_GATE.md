# Sprint 2.3 — Master Sequence & Success Gate

| Field | Value |
|---|---|
| Status | **IN_PROGRESS — NOT COMPLETE** |
| Goal | Authoritative state is **deterministic**, **revision-safe**, and **architecturally verifiable** |
| Out of scope | Full journal replay engines, automatic reconstruction loops, multi-stage quarantine pipelines, infinite reliability rewrites |
| Date | 2026-07-27 |

Bounded contract: do not expand into a rewrite of concurrency + journals + quarantine + fuzz + full UI pipelines in one pass.

---

## Master sequence

| Phase | Name | In-scope deliverable | Status |
|---|---|---|---|
| **A** | Writer & Inventory Audit | Read-only map of all durable write paths | **DONE** — `SPRINT_2_3_PHASE_A_WRITER_INVENTORY.md` |
| **B** | Focused Revision ADR | `expectedRevision`, repository ownership, rejection invariants | **DONE** — `ADR-SESSION-REVISION-OCC.md` (S2-004) |
| **C** | Repository Concurrency + Commit Contract | Protect writes; no adopt/success before durable persist; interleaving tests | **DONE** (package) — service/repo + guided submit; see contract below |
| **D** | Recovery Policy ADR & Baseline Types | Fault disposition ADR + **minimum** types for monotonicity (`R ≤ H ⇒ reject`) | **DONE** (policy + `SessionRecoveryGate`) — journal engine **DEFERRED** |
| **E** | Xcode Target Physical Verification | Core / AppIntegration / UITests exist with compiling code | **PARTIAL** — `ElektronCoreHardeningTests` SPM target added; AppIntegration + UITests + `xcodebuild` **BLOCKED** on this host |
| **F** | CI Evidence & Metrics | Machine-readable `sprint_2_3_execution_manifest.json` | **DONE** (emitter wired into `make hardening-verify`) |

---

## Phase C — Authoritative Commit Contract (invariant)

```text
mutate domain value (memory-local, not published)
  → repository.save(payload, expectedRevision: N)
  → durable persist succeeds
  → adopt returned SessionState (cache / ViewModel)
  → then notify subscribers / refresh projections
```

**Forbidden:** returning success, adopting into ViewModel/service cache, or firing state-change events before durable persistence completes.  
On disk failure or `staleRevisionConflict`: memory authoritative session unchanged; no subscriber publish of the rejected mutation.

---

## Phase D — containment

| In Sprint 2.3 | Deferred |
|---|---|
| ADR disposition per fault class | Full transaction journal replay |
| `SessionRecoveryGate` / `installRecoveredSnapshot` monotonicity | Complex automatic reconstruction loops |
| Refuse `recovered.revision ≤ durable.revision` overwrite | Multi-stage quarantine recovery UX pipelines |

---

## Definitive success gate (6 invariants)

Sprint 2.3 is **COMPLETE** iff all six hold. Current honesty:

| # | Invariant | Evidence | Met? |
|---|---|---|---|
| 1 | **Single authoritative boundary** — every state write passes a protected repository `save`/`installRecoveredSnapshot`/`clear` | Phase A inventory; app uses `FileCurrentSessionRepository` | **YES** (prod session path); W09 abandoned-tmp remains test seam |
| 2 | **Deterministic stale rejection** — `expectedRevision ≠ stored` → `staleRevisionConflict`, no side effects | `Sprint2_3_RevisionGuardTests` | **YES** (package) |
| 3 | **Zero residual side effects** — failed/rejected commits leave memory + disk untouched | Disk byte-identity + no cache adopt on throw | **YES** (package) |
| 4 | **Monotonic recovery** — automated recovery never overwrites with `R ≤ H` | `SessionRecoveryGate` + tests | **YES** (baseline type); corrupt-`clear` path not yet quarantine |
| 5 | **Clean app compilation** — production scheme via `xcodebuild` exit 0 | Makefile soft-skip without xcodebuild | **NO** on this host |
| 6 | **100% honest status** — docs match implementation; execution manifest emitted | Phase F manifest + this gate table | **YES** (this document + manifest) |

**Verdict:** Sprint 2.3 is **NOT COMPLETE** — invariant 5 blocked pending Mac CI. Classification remains `ADVERSARIAL_HARDENING_AND_RECOVERY_IN_PROGRESS`.

---

## Related artifacts

- `Docs/Capture/AUTHORITATIVE_COMMIT_PROPAGATION_CONTRACT.md`
- `Docs/Decisions/ADR-SESSION-REVISION-OCC.md`
- `Docs/Decisions/ADR-SESSION-RECOVERY-AND-QUARANTINE.md`
- `Docs/Capture/SPRINT_2_3_PHASE_E_TARGET_AND_CI_STATUS.md`
- `Docs/Evidence/SPRINT_2_3/sprint_2_3_execution_manifest.json` (generated)
