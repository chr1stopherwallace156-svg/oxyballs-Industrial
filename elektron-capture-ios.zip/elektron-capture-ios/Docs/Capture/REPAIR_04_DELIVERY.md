# App Runtime Stabilization Pass 04

## Scope

Repair 04 addresses the physical-iPhone `NSInternalInconsistencyException` caused by an
uncoordinated SwiftUI List update. It does not alter camera, LiDAR, reconstruction, Phase 4E,
Constitution, or Sentinel work.

## Runtime corrections

- durable inspection/evidence/archive mutations now enter the library mutation coordinator;
- archive/tombstone state is read before snapshot derivation rather than published afterward;
- notification and session invalidations are coalesced during a mutation;
- `LibrarySnapshot` remains an immutable read-only projection, not a durable store;
- duplicate `EvidenceLibraryIndexRecord` navigation destinations were consolidated to one root
  owner;
- root/detail duplicate evidence and inspection confirmation owners were consolidated;
- presentation dismissal setters defer shared observable cleanup until after SwiftUI's active
  update callback;
- deleting the displayed inspection emits one controlled navigation reset after the validated
  snapshot publishes;
- DEBUG snapshot logging emits generation, revision, section counts, reason, and mutation ID;
- snapshot validation now rejects duplicate inspection-section identities.

## Validation

```text
BASE_SWIFT_EQUALITY = PASS
CHANGED_SWIFT_PARSE = PASS
CORE_SNAPSHOT_COORDINATOR_TYPECHECK = PASS
REPAIR_04_CORE_SCENARIO_TESTS = PASS (15 executed, 0 failed)
APP_SOURCE_MEMBERSHIP = PASS
SPM_TEST_EXECUTION = BLOCKED_PREEXISTING_ARKIT_COREMOTION_MACOS_TARGET_ERRORS
XCODE_IOS_BUILD = BLOCKED_ENVIRONMENT_PACKAGE_SANDBOX_AND_CORESIMULATOR_SERVICE
MAC_RUNTIME = PENDING
IPHONE_RUNTIME = PENDING
```

No physical-device success is claimed. The owner must build and execute this delivery on the
same iPhone flow that reproduced the 6-to-7 section-count crash.

## Changed source

- `App/Phase1/EvidenceLibrary/LibraryMutationCoordinator.swift`
- `App/Phase1/EvidenceLibrary/LibrarySnapshot.swift`
- `App/Phase1/EvidenceLibrary/LibrarySnapshotBuilder.swift`
- `Apps/Phase1StillCapture/AppSessionContainer.swift`
- `Apps/Phase1StillCapture/EvidenceLibraryViews.swift`
- `Apps/Phase1StillCapture/GuidedInspectionOverlayView.swift`
- `Apps/Phase1StillCapture/InspectionActionRouter.swift`
- `Apps/Phase1StillCapture/InspectionReviewView.swift`
- `Tests/Unit/LibrarySnapshotRepairTests.swift`
- `Docs/Capture/REPAIR_04_INTERACTION_INVENTORY.md`

## Device regression sequence

1. Open Evidence Library with at least six visible rows in the affected section.
2. Open an inspection, invoke Delete, and confirm exactly once.
3. Verify the detail closes and the inspection is absent.
4. Pull to refresh, use toolbar Refresh, navigate away/back, and delete another inspection.
5. Force-close and relaunch; verify tombstoned inspections remain absent and evidence remains.
6. Confirm the console has one `[SNAPSHOT_PUBLISH]` entry per logical mutation and none of:
   - `Publishing changes from within view updates is not allowed`;
   - duplicate `navigationDestination` warnings;
   - `NavigationRequestObserver tried to update multiple times per frame`;
   - `NSInternalInconsistencyException`.
