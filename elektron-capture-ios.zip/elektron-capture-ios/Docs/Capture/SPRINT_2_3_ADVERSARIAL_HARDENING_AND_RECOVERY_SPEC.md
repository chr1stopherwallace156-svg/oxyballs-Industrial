# Sprint 2.3 — Adversarial Hardening & Recovery Architecture Specification

| Field | Value |
|---|---|
| Status | **ADVERSARIAL_HARDENING_AND_RECOVERY_IN_PROGRESS** |
| Version | 1.1.0 |
| Last Updated | 2026-07-27 |
| Supersedes | ad-hoc chat directives |
| Scope | App/UI + integration + core hardening gates |
| Foundation | [`SPRINT_2_3_FOUNDATION_AUDIT.md`](SPRINT_2_3_FOUNDATION_AUDIT.md) · [`ADR-SESSION-RECOVERY-AND-QUARANTINE.md`](../Decisions/ADR-SESSION-RECOVERY-AND-QUARANTINE.md) |

This is the normative execution contract for Sprint 2.3 (or Sprint 2.2 Phase 2) hardening work.

---

## Test target architecture (hard boundary)

```text
ElektronCaptureUITests
  (XCUITest, simulator, sheets/dialogs/taps)
        ↑
ElektronAppIntegrationTests
  (app target, routers, host alerts, xcodebuild)
        ↑
ElektronCoreHardeningTests
  (state machine, fuzzing, real/injected storage)
```

Package-only success is never treated as app-level execution proof.

---

## Complete recovery & fault matrix (deterministic policy)

Safe defaults that silently discard evidence are forbidden.

| Fault | Required policy | Verifiable assertion |
|---|---|---|
| Metadata references missing media | Preserve & flag | Session loads, item marked missing-media, alert path available, no crash |
| Orphaned media exists | Quarantine & index | Quarantine move logged; cold relaunch preserves main index integrity |
| Inspection JSON malformed/truncated | Quarantine & isolate | Corrupt file isolated; remaining records load |
| Newer unsupported schema | Refuse migration | Explicit `UnsupportedSchemaError`; raw file unchanged |
| Duplicate evidence IDs | Explicit conflict state | No silent pick/overwrite |
| Stale transaction journal | Deterministic rollback/replay | Cold launch restores last committed atomic state before cleanup |

---

## Deterministic concurrency / race verification

Do not rely on probabilistic “many tasks” loops as primary proof.
Use controlled interleavings (continuations/barriers) to force stale-write races and concurrent mutation collisions.

Required stale-race invariant:

- Worker A and B both read rev N
- Worker B commits rev N+1
- Worker A attempts commit against N
- Engine rejects with stale-revision conflict
- Rev N+1 remains authoritative

**Step 1 status:** enforced in `SessionRevisionGuard` + current/multi-session stores.
Package proof: `Sprint2_3_RevisionGuardTests`, `testStaleRevisionRaceRejectsWithStaleRevisionConflict`.
App-host / UITest proof: still **PENDING**.

---

## Fuzzing strategy and invariant suite

After every randomized operation assert:

1. Revision monotonicity (`rev_t >= rev_t-1`)  
2. UUID uniqueness across active/archived scopes  
3. Disk/adopted-memory parity on cold reload  
4. Referential integrity for evidence bindings  
5. Resumability/terminal policy correctness

### Dual seed mode

- PR fixed seeds: `0xDEADBEEF`, `0xC0FFEE`, `0xED750001`
- Nightly exploratory rotating seeds

Failure output must include:

```text
Seed: <seed>
Step: <step>
Failed Intent: <intent>
Replay: swift test --filter <target> --seed <seed>
```

---

## Three-tier execution gate standard

### Tier 1 — Pull Request Gate

- fast unit/state tests
- fixed regression seeds
- revision conflict tests
- real temp-disk roundtrip tests
- production target compile (`xcodebuild` on Mac)
- `verify-app-sources-membership.py`

### Tier 2 — Nightly Adversarial Gate

- rotating exploration seeds (long runs)
- high-contention TaskGroup tests
- extended corruption/fault matrix
- abrupt termination + journal recovery harness
- TSan + strict-concurrency builds

### Tier 3 — Release Hardening Gate

- Tier 1 + Tier 2
- simulator end-to-end journeys (XCUITest)
- migration/schema upgrade checks
- physical hardware verification (camera/LiDAR/low-memory)
- manual device checklist execution

---

## Classification labels

Use these exact labels for historical accuracy:

- Sprint 2.2: `PACKAGE_HARDENING_PASSED_APP_BUILD_AND_ADVERSARIAL_PENDING`
- Sprint 2.3: `ADVERSARIAL_HARDENING_AND_RECOVERY_IN_PROGRESS`

Do not promote to automated-hardened until app-target and adversarial gates are actually executed.
