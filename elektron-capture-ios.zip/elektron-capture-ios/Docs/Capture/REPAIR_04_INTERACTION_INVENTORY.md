# Repair 04 source interaction inventory

This inventory counts source declarations in the active `Phase1StillCapture` target. It does
not force the historical total of 136 because that register is absent from the repository.
Dynamic `ForEach` instances count as one source path each.

| Source file | Discovered declarations |
|---|---:|
| `EvidenceLibraryViews.swift` | 53 |
| `GuidedInspectionOverlayView.swift` | 14 |
| `InspectionActionRouter.swift` | 9 |
| `InspectionReviewView.swift` | 24 |
| `InspectionSessionViews.swift` | 9 |
| `Phase1CaptureRootView.swift` | 15 |
| **Total source paths** | **124** |

The scan includes `Button`, `NavigationLink`, `Toggle`, `Picker`, `Menu`, `Link`,
`swipeActions`, `contextMenu`, `refreshable`, and `onTapGesture` declarations.

Repair 04 laws applied to all discovered paths:

- mutating actions capture an explicit target and enter the serialized domain pipeline;
- navigation-only actions perform one MainActor navigation mutation;
- presentation dismissal does not synchronously publish shared observable state during a view
  update;
- unsupported action states are disabled with a reason or return a visible typed failure;
- no Evidence Library row array is mutated directly by a view;
- each destructive presentation domain has one owner in a NavigationStack hierarchy.

Acceptance targets:

```text
DISCOVERED_SOURCE_INTERACTION_PATHS = 124
SILENT_NO_OP = 0
AMBIGUOUS_TARGET = 0
DIRECT_LIST_MUTATION_BYPASS = 0
DUPLICATE_CONFIRMATION_OWNER = 0
```

Physical iPhone execution remains required to verify runtime behavior.
