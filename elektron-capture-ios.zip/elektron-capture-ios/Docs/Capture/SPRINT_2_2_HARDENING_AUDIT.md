# Sprint 2.2 — Adversarial Hardening Audit & Report

| Field | Value |
|---|---|
| Status | Audit documented → critical/priority fixes applied; remaining mandatory gates tracked |
| Final classification | **`PACKAGE_HARDENING_PASSED_APP_BUILD_AND_ADVERSARIAL_PENDING`** |
| Branch | `cursor/sprint-2-2-adversarial-hardening-d881` |
| Base tip | `420b178` (postmortem + IPG guardrails) |
| Host | Linux cloud agent — `swift` available; **`xcodebuild` NOT AVAILABLE** |
| Last Updated | 2026-07-27 |

---

## 0. Documentation / contract review

### Path corrections (prompt vs repo)

| Prompt path | Actual path |
|---|---|
| `Docs/Architecture/AUTHORITATIVE_COMMIT_PROPAGATION_CONTRACT.md` | **`Docs/Capture/AUTHORITATIVE_COMMIT_PROPAGATION_CONTRACT.md`** |
| `Docs/Architecture/SPRINT_2_1F_ACTION_PARITY.md` | **`Docs/Capture/SPRINT_2_1F_ACTION_PARITY.md`** |

Architecture docs that are correct: `POSTMORTEM_INTERACTION_PIPELINES.md`, `INTERACTION_PIPELINE_GUARDRAILS.md`, `ENGINEERING_GUARDRAILS.md`.

### Conflicts / duplication / ambiguity

| ID | Severity | Issue |
|---|---|---|
| C1 | MED | Postmortem Related line lists Capture contracts without `Docs/Capture/` prefix — appears co-located under Architecture |
| C2 | HIGH | ACTION_PARITY says Create New from Plan keeps “original untouched”; `createNewFromPlan()` **cancels** the active session before minting a new id (`InspectionActionRouter.swift`) |
| C3 | MED | Archive is presentation-only (UserDefaults) while menu language can read as domain lifecycle — documented in code, easy to misread as incomplete |
| C4 | LOW | ENGINEERING_GUARDRAILS (Phase 0) + IPG (2.1F+) overlap; both normative — no contradiction if both obeyed |
| C5 | HIGH | Prompt forbids success from `swift test` alone; this host cannot run `xcodebuild` / Simulator / device — classification must stay pending device |

Contracts enforced: IPG-1…IPG-10, SSOT persist→adopt→recompute, CURSOR_OPERATING_RULES § Interaction pipelines, `.cursor/rules/*.mdc`.

---

## 1. Repository and build identity

| Item | Value |
|---|---|
| Package | `Package.swift` → library `ElektronCapture` (path `App/`, many directories excluded) |
| App project | `Apps/Phase1StillCapture/Phase1StillCapture.xcodeproj` |
| Workspace | `Apps/Phase1StillCapture/Phase1StillCapture.xcworkspace` (+ root `Phase1StillCapture.xcworkspace`) |
| Scheme | `Phase1StillCapture` |
| App target | `Phase1StillCapture` (product `Phase1StillCapture.app`) |
| Package tests | `ElektronCaptureTests`, `ElektronCaptureGoldenTests` |
| App UI tests | **None discovered** |
| Authoritative session owner | `InspectionSessionViewModel.current` via `AppSessionContainer` |
| Intent router | `InspectionActionRouter` (App target) |
| Guided coordinator | `GuidedInspectionCoordinator` (package) |
| Persistence | `FileCurrentSessionRepository` / `InspectionSessionService`; Evidence Library `EvidenceLibraryStore` actor |

### Production source membership (Phase A — verified)

Disk Swift under `Apps/Phase1StillCapture/` vs PBX Sources:

| File | In Sources? |
|---|---|
| Phase1StillCaptureApp.swift | YES |
| AppSessionContainer.swift | YES |
| Phase1CaptureRootView.swift | YES |
| GuidedInspectionViewModel.swift | YES |
| GuidedInspectionOverlayView.swift | YES |
| InspectionSessionViewModel.swift | YES |
| InspectionSessionViews.swift | YES |
| SharePresentation.swift | YES |
| EvidenceLibraryViews.swift | YES |
| InspectionReviewView.swift | YES |
| InspectionReviewViewModel.swift | YES |
| **InspectionActionRouter.swift** | **YES (fixed in Sprint 2.2)** |

Evidence: `project.pbxproj` PBXBuildFile / PBXFileReference / Sources build phase omit `InspectionActionRouter.swift` while `EvidenceLibraryViews.swift` and others reference `EvidenceActionIntent` / `InspectionActionRouter` defined only in that file.

**Resolution:** `InspectionActionRouter.swift` was added to PBX FileReference + Sources. Membership is now enforced by `Scripts/verify-app-sources-membership.py` and `make hardening-verify`.

---

## 2–4. Architecture pipeline matrix & findings

Full row-level matrix: see Phase A audit narrative in this sprint’s working notes; summary status:

| Action | Pipeline status | First failing / weak layer |
|---|---|---|
| View Details | Wired (path append) | Was disconnected; repaired earlier |
| Retake | PASS | — |
| Delete Photo | Durable PASS; feedback WEAK | `actions.statusMessage` / `mediaWarning` unobserved |
| Assign to Point | Durable PASS; failure WEAK | Error via Capture-only alert / unobserved status |
| Open / Add Photo / Redo | PASS | — |
| Skip / Block | Durable PASS; failure WEAK off Capture | Same |
| Clear Point Evidence | PASS (confirm host) | statusMessage unobserved |
| Save & Exit | PASS | — |
| Complete Inspection | PASS on Review/HUD; Detail failure WEAK | statusMessage unobserved |
| Create New from Plan | PASS; **doc conflict C2** | Cancels prior session |
| Restart | PASS (confirm); refusal WEAK | statusMessage unobserved |
| Archive | PASS presentation-only | IPG-8 / C3 |
| Delete Inspection | PASS (confirm) | unbind `_ =` discard |
| Manual Refresh | Success PASS; failure WEAK | Library/Review don’t show `errorText` |
| Use Photo / Pause / Resume / Cancel | PASS | — |

### Explicit search results

| Pattern | Result |
|---|---|
| Empty closures | Cancel-role `{}` dismissals only (low) |
| TODO/FIXME in Apps/Domain Swift | None |
| `default` on GuidedInspectionIntent | Persist fallthrough + `intentAllowsSessionReplacement` → false |
| Intent cases without handlers | All `*ActionIntent` cases have router branches **in source**; **file not in target** |
| `try?` at boundaries | Repository clear / optional advance — documented MED |
| Empty catch | Not found in Apps/Domain |
| Published nav without consumer | `navigationEvidenceId` has consumer |
| Pending without host | Delete/Restart/Clear/Skip/Block hosts present on Detail |
| `statusMessage` / `mediaWarning` without consumer | **CRITICAL/HIGH — no View binds `actions.statusMessage`** |
| Dual `EvidenceLibraryStore` | Capture VM + Library VM — IPG-6 |
| Local mutable session copies | Not found as child VM forks |
| Mocks in production app | Not found |

---

## 5. State-machine matrix (Phase B)

### SessionStatus (domain)

`inProgress` | `paused` | `completed` | `canceled` — **no** domain `archived`.

### Presentation lifecycle

`InspectionLifecycleEvaluator`: inProgress → readyForReview → completed → exported (export orthogonal).

| Scenario | Save & Exit | Complete | Restart | Delete insp | Archive | Resume | Refresh |
|---|---|---|---|---|---|---|---|
| No session | error | error | n/a | n/a | filter only | n/a | load nil |
| In progress 0 evidence | enabled, stays inProgress | disabled | confirm→new id | cancel+quarantine | hide list | same id | reload |
| Partial evidence | enabled | disabled | confirm→new id | cancel+quarantine | hide | same id | reload |
| Completion-ready | enabled | enabled | confirm→new id | … | hide | … | … |
| Completed | n/a active | n/a | refused (status only) | … | hide | n/a guided | reload |
| Canceled | n/a | n/a | … | … | … | n/a | … |

**Rule verified in source:** Save & Exit banner is **not** gated on `canCommitCompletion` (IPG-3). Complete Inspection **is** gated.

**Declared outcome rule (IPG-1):** Several paths currently terminate in **unobserved `statusMessage`** — classified as unexplained no-op from the operator’s perspective even when durable mutation succeeded.

---

## 6–11. Automated phases (this host)

| Phase | Capability on Linux | Result |
|---|---|---|
| C Exhaustive ActionIntent router tests | App types not in SPM | Partial — GuidedInspectionIntent + membership script; app UITest target absent |
| D Real disk persistence | YES (package) | Extended with cold reload + resurrection + corruption cases |
| E Concurrency / sequencing | YES (deterministic + seeded randomized) | Added; stale overwrite risk captured |
| F Fault injection | YES | Added persist failure and corruption fault tests |
| G `xcodebuild` / Simulator | **NOT AVAILABLE** | NOT RUN — recorded as obligation |
| H XCUITest journeys | No UITest target | NOT RUN |
| I Physical device | Not run here | Checklist generated only |

---

## 12. Remaining physical-device obligations

See `Docs/Capture/SPRINT_2_2_DEVICE_VALIDATION_CHECKLIST.md`. Until filled with device/iOS/build commit/pass-fail, tip remains non-device-validated.

---

## 13. Exact defects changed (authorized after findings documented)

Applied **smallest** corrections only:

1. **CRITICAL** — Add `InspectionActionRouter.swift` to Xcode PBXFileReference, group, and Sources.  
2. **HIGH** — Host `actions.statusMessage` / `mediaWarning` as visible alerts on Library list + Inspection Detail (+ Review where menus live).  
3. **MED** — Membership verification script for CI/Linux.  
4. **Tests** — Sprint 2.2 persistence / fault / sequencing / membership / lifecycle assertions.  
5. **Docs** — Fix Create New vs “untouched” wording to match cancel→mint behavior; fix postmortem Related paths.

Not changed (deferred, not silent): shared single EvidenceLibraryStore injection; domain `.archived` status; full XCUITest suite; Mac `xcodebuild` (environment).

---

## 14. Tests added

- `Tests/Unit/Sprint2_2_HardeningTests.swift` (15 tests): disk round-trip, no resurrection, malformed/truncated/unsupported persistence, missing-media/missing-metadata recovery, persist-fault injection, duplicate destructive sequencing, stale-overwrite risk characterization, seeded randomized action sequence, Guided intent case coverage, membership file presence  
- `Scripts/verify-app-sources-membership.py` (wired into `make hardening-verify`)  
- `Makefile` → `hardening-verify` gate (membership + Sprint2_2 + full swift test + xcodebuild-if-available)

---

## 15. Risks / unresolved

- Dual EvidenceLibraryStore remains (mitigated by disk-merge writes).  
- `createNewFromPlan` still cancels prior session — product may want stronger confirm.  
- No app-target unit/UI test host for ActionIntent spies on Linux.  
- `xcodebuild` / Simulator / device NOT RUN on this agent.

---

## 16. Final classification

**`PACKAGE_HARDENING_PASSED_APP_BUILD_AND_ADVERSARIAL_PENDING`** after closing critical target-membership and core Linux adversarial gates.

After smallest corrections + Linux `swift test` green:

**`PACKAGE_HARDENING_PASSED_APP_BUILD_AND_ADVERSARIAL_PENDING`**

Not `DEVICE_VALIDATED_PENDING_ACCEPTANCE` — no physical hardware execution on this agent.  
Not `ACCEPTED_HARDENED_BASELINE` — acceptance not granted.


## Addendum — post-gap execution update (2026-07-27)

After the initial Sprint 2.2 pass, mandatory hardening gaps were executed in priority order:

- Added deterministic corruption/recovery tests (truncated JSON, unsupported schema, missing media/metadata)
- Added stale-overwrite race characterization test
- Added seeded randomized action sequence test with reproducible seed reporting
- Wired `Scripts/verify-app-sources-membership.py` into permanent `make hardening-verify`
- Executed `make hardening-verify` on this host:
  - membership verifier PASS
  - `Sprint2_2_HardeningTests`: 15/15 PASS
  - full `swift test`: 318 executed, 1 skipped, 0 failures
  - `xcodebuild`: unavailable on Linux host (explicitly reported)

### Corrected finding status

The earlier findings table referenced pre-fix states for:

- `InspectionActionRouter.swift` target membership
- unobserved router `statusMessage` / `mediaWarning`

Both were fixed in Sprint 2.2 before this addendum.

### Remaining blockers for automated hardening completion

The following gates remain mandatory and unexecuted on this host:

1. Production-scheme `xcodebuild` on Mac
2. Simulator/UI journey assertions in app/XCUITest target for navigation/dialog/alert outcomes
3. Physical-device checklist execution (separate gate)

Therefore classification remains **`PACKAGE_HARDENING_PASSED_APP_BUILD_AND_ADVERSARIAL_PENDING`**.
