# Sprint 2.2 — Mandatory Hardening Execution Specification

| Field | Value |
|---|---|
| Status | **MANDATORY** |
| Version | 1.0.0 |
| Last Updated | 2026-07-27 |
| Scope | Automated hardening gates before device validation |

## Non-negotiable requirements

The following are mandatory Sprint 2.2 work items, not optional recommendations:

1. App-level navigation, sheet, dialog, and alert verification.
2. Stale-revision race tests and simultaneous concurrency tests.
3. Malformed/truncated persistence tests and corruption recovery.
4. Interrupted transaction simulation (rollback / deterministic recovery).
5. Expanded filesystem fault injection (permissions, missing dirs, disk bounds).
6. Randomized action-sequence testing with reproducible seeds.
7. Reproducible random-seed output on failure.
8. Permanent gate integration of `Scripts/verify-app-sources-membership.py`.

## Critical execution rules

- **No source-string inspection as behavioral proof.**
  Tests must dispatch real operations and verify durable state, navigation, recovery, or visible error outcomes.
- **Real isolated disk repos for persistence/fault tests.**
  Use temporary directories and cold reload checks.
- **App target required for presentation verification.**
  Package tests are insufficient for SwiftUI host routing assertions.
- **Deterministic before randomized.**
  Finish deterministic faults/races first.
- **Seed reproducibility required.**
  Failures must report seed and step in rerunnable form.
- **Classification gate.**
  Do not classify as `AUTOMATED_HARDENING_PASSED_PENDING_DEVICE` until all automated requirements execute under `xcodebuild` where applicable.

## Required order

```text
Phase A  Production integrity
  1) App navigation/dialog tests
  2) Production target xcodebuild + membership wiring

Phase B  Deterministic concurrency/storage faults
  3) Stale-revision races + simultaneous mutation tests
  4) Corruption + missing-media/missing-metadata recovery
  5) Interrupted transaction simulation
  6) Filesystem fault injection

Phase C  Generative adversarial fuzzing
  7) Seeded randomized sequences (recorded seeds)

Phase D  Final gates
  8) Simulator journeys
  9) Physical device checklist
```

## Existing permanent command

`make hardening-verify` currently runs:

1. `Scripts/verify-app-sources-membership.py`
2. `swift test --filter Sprint2_2_HardeningTests`
3. `swift test`
4. `xcodebuild` compile when available on host

Mac CI / local Mac runs must execute this target to satisfy automated hardening evidence.


## Forward contract

Sprint 2.3 execution architecture: `Docs/Capture/SPRINT_2_3_ADVERSARIAL_HARDENING_AND_RECOVERY_SPEC.md`
