# Sprint 2.3 — Foundation Audit

| Field | Value |
|---|---|
| Status | **FOUNDATION_AUDIT_COMPLETE — S2-004 expectedRevision OCC LANDED** |
| Classification | `ADVERSARIAL_HARDENING_AND_RECOVERY_IN_PROGRESS` |
| Prior gate label | `SPRINT_2_3_SPEC_APPROVED_IMPLEMENTATION_PENDING` (held until Phase A inventory + S2-004 ADR committed) |
| Authority | Production Swift + executed tests (not Markdown claims) |
| Date | 2026-07-27 |
| Branch intent | `cursor/sprint-2-3-foundation-audit-d881` |

This audit establishes the unvarnished delta between Sprint 2.3 specification claims and executable reality, then records what Step 1 closed.

---

## Method

1. Treat `App/**/*.swift`, `Apps/**/*.swift`, `Tests/**/*.swift`, `Package.swift`, and `project.pbxproj` as authoritative.
2. Treat Sprint 2.3 Markdown as a target contract, not proof of implementation.
3. Prefer failing characterization tests and repository behavior over aspirational labels.

---

## Baseline (pre–Step 1) — code-proven

| Capability | Spec claim | Pre-Step-1 reality |
|---|---|---|
| Stale-revision reject | Required OCC | **ABSENT** — LWW on `FileCurrentSessionRepository` / `FileInspectionSessionStore`; characterized by `testStaleRevisionRaceShowsOverwriteRiskWithoutRevisionGuard` |
| Session corrupt → quarantine | Quarantine & isolate | **ABSENT** — `corruptPersistence` → `repository.clear()` |
| Evidence media quarantine | Soft-delete quarantine | **PRESENT** — `EvidenceLibrary/.quarantine/` |
| Unsupported schema refuse | Explicit error | **PRESENT** — session Int schema + library major |
| Reference model + shrinker | Required | **ABSENT** |
| Named Xcode adversarial targets | `ElektronCoreHardeningTests` / `AppIntegration` / `UITests` | **ABSENT** (docs only); real SPM: `ElektronCaptureTests` + `ElektronCaptureGoldenTests` |
| Fuzz harness | Dual seeds + long runs | Minimal: 80-op LCG seed `84721953` in package tests |
| Recovery journal | Deterministic replay | **ABSENT** — temp+`.bak` atomic replace only |
| Recovery ADR | Policy before mechanics | **ABSENT** (pre-Step-1) |
| App Sources membership | Permanent gate | **PASS** via `Scripts/verify-app-sources-membership.py` |

Honest ceiling before Step 1: **`PACKAGE_HARDENING_PASSED_APP_BUILD_AND_ADVERSARIAL_PENDING`**.

---

## Step 1 closed in this change set

### 1. Revision guards (production)

- Added `InspectionSession.revision: Int` with `decodeIfPresent` → `0` (envelope schema remains **v1**; S2-002 untouched).
- Added `InspectionSessionError.staleRevisionConflict(current:attempted:)` and matching `InspectionSessionPersistenceError` case.
- Added `SessionRevisionGuard.prepareCommit(incoming:existing:)`:
  - first durable write → revision `1`
  - same-id commit requires `incoming.revision == existing.revision`, then writes `N+1`
  - mismatch → explicit stale conflict; durable head unchanged
- OCC enforced inside:
  - `FileCurrentSessionRepository.save` / `InMemoryCurrentSessionRepository.save` (returns bumped session)
  - `FileInspectionSessionStore.save` (per-file OCC)
- `InspectionSessionService` adopts returned bumped sessions for create / transition / apply paths.

### 2. Tests flipped from LWW characterization → rejection proof

- `testStaleRevisionRaceRejectsWithStaleRevisionConflict` (was overwrite-risk characterization)
- `Sprint2_3_RevisionGuardTests` (first persist, legacy omit, dual-writer reject, multi-session store)
- Randomized seed loop asserts revision monotonicity on cold reload

### 3. Recovery ADR drafted (policy lock, no journal engine yet)

See [`../Decisions/ADR-SESSION-RECOVERY-AND-QUARANTINE.md`](../Decisions/ADR-SESSION-RECOVERY-AND-QUARANTINE.md).

**No recovery journal or session-JSON quarantine mechanics were invented in this change.** Policy is locked first.

---

## Still ABSENT (do not claim otherwise)

1. Mac `xcodebuild` production scheme compile / app UITest targets
2. True reference-model oracle + shrinker (5k+ step adversarial)
3. Session JSON quarantine (current policy until ADR implementation: clear-on-corrupt — ADR mandates migrate to quarantine)
4. Interrupted multi-step rollback journal with injectable FileManager
5. Abrupt process-kill recovery harnesses
6. Nightly/PR three-tier CI YAML for Tier 2/3
7. Physical device checklist execution

---

## Classification after Step 1

| Label | Meaning |
|---|---|
| `ADVERSARIAL_HARDENING_AND_RECOVERY_IN_PROGRESS` | Accurate — revision OCC landed; recovery journal / app adversarial targets still pending |
| Do **not** promote to automated-hardened | App-target + Tier 2/3 gates not executed on this Linux host |

---

## Gate evidence (this host)

- `swift test` package suite + `make hardening-verify` (membership + package tests)
- `xcodebuild` / Simulator: **NOT RUN**
