# Sprint 2.1F — Inspection Review, Grouped Evidence & Pre-Export Validation

| Field | Value |
|---|---|
| **Status** | `IMPLEMENTED_PENDING_XCODEBUILD_AND_DEVICE_VALIDATION` |
| **Branch** | `cursor/sprint-2-1f-inspection-review-d881` |
| **Architecture** | `SPRINT_2_1_ARCHITECTURE.md` LOCKED (session aggregate vs envelope; soft-delete = local-media policy) |
| **Corrective pass** | Device-regression sync fix (post–2.1F physical findings) |
| **Next** | Physical-device acceptance matrix → then Sprint **2.2** (explicit kickoff only) |

## Device regression corrective pass (this tip)

### Confirmed root causes

| Defect | Root cause |
|---|---|
| Auto-switch to Evidence Library after Use Photo | `Phase1CaptureRootView` explicitly set `session.selectedTab = .library` after bind; also left UI in `.approved` instead of returning to `.previewing` |
| Stale Library Refresh until force-quit | Capture and Library each held a separate `EvidenceLibraryStore` actor; Library `loadIndex()` returned a stale in-memory `cachedIndex` and never re-read disk |
| “No active inspection” + Point N / Satisfied | Guided HUD stayed `isGuidedAvailable` for terminal sessions, and Guided VM did not observe `inspection.$current`, so banner (`!hasActiveSession`) and HUD could diverge |

### Fixes

1. **Use Photo** — remain on Capture; return to live preview; brief “✓ Photo saved — N of M”; library reloads silently (no tab switch).
2. **Authority** — Capture / Library / Review all adopt or recompute from `InspectionSessionViewModel.current`; Review + Guided observe `$current`; metering increments the adopted session via `applyUpdatedSession`.
3. **Library Refresh** — `listInspectionCatalog(forceReload:)` / `reloadIndexFromDisk()`; notifications carry `sessionId`.
4. **Workflow labels** — satisfied + open → “Evidence satisfied — ready to complete”; bind promotes active `notStarted` → `inProgress`.
5. **Skip** — still available on unsatisfied points; nonblank reason required; successful skip persists and advances to next eligible point.

### Verification

```text
Host: Linux (Swift 5.10.1)
Command: swift test
Result: 269 executed, 1 skipped, 0 failures
Sprint2_1F_DeviceRegressionTests: 15 executed, 0 failures
Sprint2_1FTests: 12 executed, 0 failures
xcodebuild → NOT RUN (Linux host)
Physical device acceptance matrix → NOT RUN
```

**Do not classify device-validated until the acceptance sequence runs on hardware.**

## Delivered (2.1F base)

### Domain
- `InspectionPreExportValidator` → `InspectionValidationReport` + typed findings
- `InspectionExportPolicy` — **skip permits export**; **block denies export**
- `EvidencePointSectionPresentation` / presenter
- Intents: `refreshValidationRequested`, `reviewPointRequested`, `generateExportRequested`

### App
- **Review** tab — findings, point disclosures, export preview, TOCTOU generate
- Library point sections + jump-to-point
- HUD More → Open Review / Skip / Block

## Skip / Block export policy (unchanged)

| Condition | Result |
|---|---|
| Required **skipped** + non-blank reason | Export **allowed** |
| Required **blocked** | Export **blocked** |
| Open / insufficient evidence | Export **blocked** |

## Device acceptance sequence (required)

```text
Cold launch → New Inspection
→ capture Point 1 → Use Photo
→ verify stay on Capture, no glitch, saved confirmation
→ verify next photo/point behavior
→ open Evidence Library → photo visible
→ Refresh → no disappearance/duplicates
→ Capture → More → Skip incomplete point with reason → advances
→ Review → satisfied/skipped/workflow coherent
→ force quit → relaunch → state restored
Repeat on 4-point and 6-point plans.
```

## Known limitations
- Mac `xcodebuild` and physical-device matrix remain outstanding on this host.
- Session-level Generate still shares existing per-capture `.edts-pkg` copies.
- Explicit Mark Complete remains required for export when evidence is satisfied but workflow is still open (by design); UI now labels that coherently.
