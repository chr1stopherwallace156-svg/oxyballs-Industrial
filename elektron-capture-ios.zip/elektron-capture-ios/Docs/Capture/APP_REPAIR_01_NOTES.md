# App Interaction Repair 01 — implementation notes

Baseline: `DOWNLOAD-elektron-reconstruction-phase-4d-surface-foundation.zip`
sha256 `bb54c481da50c9c42e444b523eb8a1b7a810d257fc30d59d842af591734f5be4` (PR #68 delivery).

## Verification state — read this first

```
SOURCE_IMPLEMENTED     = YES
LINUX_STRUCTURAL       = PASS  (5 checks — these are NOT tests)
LINUX_COMPILED         = NOT_POSSIBLE  (no Swift toolchain; download.swift.org blocked by policy)
AUTOMATED_TEST_STATE   = NOT_RUN       (39 tests written and shipped, never executed)
MAC_BUILD_STATE        = PENDING
MAC_RUNTIME_STATE      = PENDING
IPHONE_RUNTIME_STATE   = PENDING
```

No test in this repair has ever been executed. The tests are real XCTest code that exercises
real production types — they are not source-text assertions — but the first machine to compile
and run them will be your Mac. Treat every repair below as **implemented and unverified** until
`swift test` passes there.

The structural checks that did run on Linux are: brace/paren/bracket balance on all 18 changed
files; `unarchiveSession` absent from every deletion path; no commit handler re-reading shared
`pending*` state; protocol-conformance completeness for all `InspectionRecordStore` and
`CurrentSessionRepository` implementations; and `load()` containing no `clear()` call. They
prove structure, not behaviour.

## What changed

### Refresh (D-A05, D-A06, D-A07)

- `FileCurrentSessionRepository.load()` no longer deletes the record when the session is
  terminal. Reading is byte-neutral.
- `InspectionRefreshOutcome` replaces `Bool`, distinguishing `updated` / `noActiveSession` /
  `terminalSession` / `repositoryFailure` / `recordDisappeared` / `identityDivergence`.
- `InspectionRefreshResolution` is a pure decision function — unit-testable without a view —
  enforcing that a refresh never destroys state.
- `AppSessionContainer` publishes `isRefreshing` and `lastRefreshedAt`, and drops re-entrant
  refreshes while one is in flight.
- Library and Review show a progress spinner, an "Updated HH:mm:ss" stamp, and host an alert
  for the refresh outcome. Both gained `.refreshable` (pull-to-refresh), which did not exist
  anywhere in the app before.

### Delete Inspection (D-A01, D-A02, D-A03, D-A10, D-A11)

- New durable multi-inspection store with an explicit `delete(sessionID:)` + tombstone.
- `unarchiveSession` is gone from the deletion path entirely.
- `InspectionDeletionService` re-reads the tombstone before reporting success.
- The live current-session slot is retired only via identity-checked
  `clearIfHolding(sessionID:)` → `retireCurrentSlot(sessionID:)`.
- Completed inspections delete normally; the old path threw `illegalStatusTransition` into a
  swallowed error and then announced success.
- The detail view pops only on a **proven** deletion.

### Confirmation identity (D-A04)

Every destructive commit takes its target id as a parameter, captured while the dialog is
built: `commitDeleteInspection(sessionID:)`, `commitDeleteEvidence(id:)`,
`commitClearPointEvidence(pointID:)`, `commitRestart(sessionID:)`,
`cancelConfirmed(expectedSessionID:)`. Nothing is re-read from `pending*` state inside a
`Task`, which SwiftUI clears as part of dismissing the dialog.

### Action targeting (D-A08)

`InspectionActionScope` decides availability for **the viewed `groupID`**. Actions that can
only apply to the live session are shown disabled with an explicit reason instead of silently
acting on a different inspection.

### Reload coalescing and list affordances (D-A09, D-A12, D-A14)

Overlapping reloads collapse into one follow-up pass; the duplicate `.onAppear` reload is
gone; inspection rows gained swipe Delete and swipe Archive.

## Deliberately out of scope

`Replace…` duplicating `Retake Photo` (D-A15) is untouched — it was not in the authorised
repair list. The `AppCore` target extraction from the earlier draft manifest was dropped: the
router and view models are inside `#if canImport(UIKit) && !os(macOS)` and cannot execute on
Linux at all, so the repair logic was placed in platform-neutral types under `App/` instead,
where the existing test target already reaches it. `project.pbxproj` and `Package.swift` are
unchanged, so the Xcode open-and-build path is exactly as it was.

## Known risk

This code has never been compiled. Expect the possibility of compile errors on first build;
they will be ordinary type/signature issues, not design problems. Report them and they will be
fixed in a follow-up commit on the same branch.
