# Authoritative Commit Propagation Contract

| Field | Value |
|---|---|
| **Status** | Normative for Sprint 2.1F+ session-changing actions |
| **Branch** | `cursor/sprint-2-1f-save-and-exit-d881` |
| **Classification** | `IMPLEMENTED_PENDING_XCODEBUILD_AND_DEVICE_VALIDATION` |

## Authority chain

```text
Typed Domain Intent
→ Application/Coordinator Operation
→ Pure Immutable Domain Transition
→ Persist Through Repository Boundary
→ Return Exact Committed InspectionSession
→ Adopt Into InspectionSessionViewModel.current
→ Recompute All Presentation Projections
```

`InspectionSessionViewModel.current` is the application’s authoritative in-memory representation of the session that was **successfully persisted**. It is not a disposable ViewModel cache.

Every screen must be driven by:

- same stable `sessionID`
- same committed session aggregate (bindings, progress, lifecycle)
- same frozen plan snapshot
- same workflow states

Capture / Library / Review / Detail / export validation are **projections**, not independent authorities.

## Rules

1. The persisted and adopted session must retain the same stable `sessionID` unless the action explicitly creates a new inspection or revision.
2. Capture, Evidence Library, Review, Inspection Detail, and export validation must derive from the same committed session.
3. Child ViewModels may hold read-only derived presentation data, but must not maintain independently mutable session snapshots.
4. A notification may signal invalidation, but it may not carry or become authoritative state.
5. Manual Refresh must reload by stable session ID from the repository and then adopt/recompute from the returned session; catalog reload alone is insufficient.
6. No screen may patch its own count, status, lifecycle, or evidence list after an action.
7. Every successful operation must expose one deterministic committed-session adoption point.
8. Every failed persistence operation must leave the previously authoritative session unchanged.

## Transaction order (session-changing actions)

1. Validate the requested action  
2. Produce a new immutable session  
3. Persist the new session  
4. Receive/confirm the committed result  
5. Adopt it as `InspectionSessionViewModel.current`  
6. Recompute presentation projections  
7. Update navigation or dismiss UI  
8. Perform post-commit media cleanup  

**Delete example (correct):** remove binding → persist → adopt → projections update → quarantine binary  

**Delete example (incorrect):** hide thumbnail → delete file → maybe persist later  

## Domain intents share one authority path

`EvidenceActionIntent`, `PointActionIntent`, and `InspectionActionIntent` remain domain-separated, but all converge on the same persist → adopt → recompute path. No mega-enum is required.

## Save & Exit / Complete / Export

| Action | Meaning |
|---|---|
| **Save & Exit** | Persist current partial aggregate as `.inProgress`; same `sessionID`; leave Capture |
| **Complete Inspection** | Terminal workflow transition only when policy allows |
| **Export readiness** | Orthogonal — `Completed` ≠ `Export Ready` |

## Commit identity (revision) — S2-004

Sprint 2.3 requires optimistic concurrency with **repository-assigned** sequences:

| Token | Role |
|---|---|
| `sessionID` | Stable identity |
| `expectedRevision` | Caller assertion of last observed durable revision (`0` if none) |
| `revision` (on returned session) | Minted solely by repository as `stored+1` (first write → `1`) |
| envelope `savedAt` | Write timestamp metadata |
| envelope `integrity.sessionDigest` | Load-time integrity over encoded session (includes assigned revision) |

Callers must not successfully publish a self-chosen next revision. Payload `session.revision` is ignored for sequencing at `save`. See `Docs/Decisions/ADR-SESSION-REVISION-OCC.md`.

### Authoritative commit sequence (Phase C)

```text
mutate domain value (local only)
  → repository.save(payload, expectedRevision: N)
  → durable persist succeeds
  → adopt returned SessionState (service cache / ViewModel)
  → then refresh projections / notify UI
```

Publishing success, adopting into ViewModel/service cache, or firing state-change events **before** durable persistence completes is forbidden. On failure or `staleRevisionConflict`, prior authoritative memory and disk remain unchanged.

When debugging desync: compare adopted `sessionID` + `revision` + binding set + `SessionStatus` + active point.

**Recovery:** `SessionRecoveryGate` — never install recovered `R` over durable `H` when `R ≤ H`. See `Docs/Decisions/ADR-SESSION-RECOVERY-AND-QUARANTINE.md`.  
**Success gate:** `Docs/Capture/SPRINT_2_3_SUCCESS_GATE.md`.

## Manual Refresh contract

```text
prior = InspectionSessionViewModel.current
loaded = repository.load()  // by current-session store / stable ID
if prior != nil && loaded != nil && loaded.id != prior.id → keep prior; sync error
else adopt(loaded)          // may be nil only when repo has no current session
→ guided / review / library projections recompute from adopted session
→ Evidence Library catalog force-reloads from disk (non-authoritative media index)
```

## Gate discipline

Phase A (flash + Save & Exit + this contract’s critical adoption paths) must stay green and reported before expanding interaction surfaces. Do not bury authority defects under Phase B/C UI work.

**Interaction pipeline rules:** [`../Architecture/INTERACTION_PIPELINE_GUARDRAILS.md`](../Architecture/INTERACTION_PIPELINE_GUARDRAILS.md)  
**Why silent no-ops happened:** [`../Architecture/POSTMORTEM_INTERACTION_PIPELINES.md`](../Architecture/POSTMORTEM_INTERACTION_PIPELINES.md)
