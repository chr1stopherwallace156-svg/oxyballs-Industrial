# Sprint 2.3 — Phase E: Target Physical Existence & Mac CI Verification

| Field | Value |
|---|---|
| Status | **PARTIAL — CORE SPM PRESENT; APP/UI + xcodebuild BLOCKED** |
| Date | 2026-07-27 |

## Named adversarial targets

| Spec name | Reality |
|---|---|
| `ElektronCoreHardeningTests` | **PRESENT** as SPM test target (`Tests/Hardening`) |
| `ElektronAppIntegrationTests` | **ABSENT** — requires Xcode app-host; not invented as empty stub |
| `ElektronCaptureUITests` | **ABSENT** — requires XCUITest host; not invented as empty stub |

## Compile gates

| Gate | This host |
|---|---|
| `swift test` (all SPM targets) | Runnable |
| `xcodebuild` Phase1StillCapture | **NOT_RUN_HOST_MISSING_XCODEBUILD** |
| Success-gate invariant 5 | **UNMET** until Mac CI |

Do not claim Sprint 2.3 COMPLETE without a `PASSED` xcodebuild entry in `sprint_2_3_execution_manifest.json`.
