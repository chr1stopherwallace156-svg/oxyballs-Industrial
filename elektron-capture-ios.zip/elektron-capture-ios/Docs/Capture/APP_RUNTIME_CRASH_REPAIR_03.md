# App runtime crash repair 03

## RUNTIME_CRASH_BINDING

The observed iPhone failure was `NSInternalInconsistencyException`: `UICollectionView invalid
update`, expected post-delete count 7, actual count 8. Before this repair,
`EvidenceLibraryViewModel.groups` and `.unassigned` were separate `@Published` arrays while
`EvidenceLibraryListView.visibleGroups` was recomputed against independently published archive
and tombstone sets. Delete completion called `reload()` directly; EvidenceLibraryStore
`didChange`, NotificationCenter, the inspection session publisher, toolbar Refresh,
`.refreshable`, navigation mutation, and other explicit reloads could publish another catalog
between SwiftUI's pre-delete and post-delete reads. One path could remove the live inspection
while another still exposed its evidence through the old partition, yielding 8 where the list
diff had committed to 7.

The repaired transaction is owned as follows:

```
Pre-delete validated LibrarySnapshot (N items)                 EvidenceLibraryViewModel
↓
Delete request enters LibraryMutationCoordinator              InspectionActionRouter
↓
Durable persistence commit                                    InspectionDeletionService/store
  - tombstone written and verified
  - inspection lifecycle state committed
↓
Generation advances to Gen K+1                                LibraryMutationCoordinator
↓
One authoritative repository read                             EvidenceLibraryStore/record store
↓
Pure LibrarySnapshotBuilder derivation                        LibrarySnapshotBuilder
↓
LibrarySnapshot validation                                    LibrarySnapshotBuilder
  - stable IDs unique
  - cross-section duplication prohibited
  - section membership mutually exclusive
↓
Exactly one atomic publication of Gen K+1 snapshot            EvidenceLibraryViewModel
  - deleted inspection absent from live section
  - retained evidence appears only in its permitted section
↓
navigation selection/path referencing deleted inspection cleared once  SwiftUI owner
↓
one SwiftUI List diff transaction                             EvidenceLibraryListView
```

For deletion of one visible item, the validated candidate has `N - 1` visible items. The view
reads every section from the same immutable snapshot, so it cannot observe an old N-item array
while processing the deletion.

NotificationCenter and session subscribers only request coordinator work. While a generation
is active, requests join/coalesce; results undergo generation comparison before publication,
and stale results are rejected. Subscribers never publish directly, and coordinator output is
not reposted as an invalidation. A genuinely newer external invalidation can set only one queued
follow-up generation.

```
SOURCE_LOGIC_BASE = f870b57462654a225a55e75aa039d45dac7180db
BRANCH_BASE = 4b3d7e527c2c0a47b6b6d385db8e983ef472c1ba
SOURCE_TREE_SWIFT_DELTA_BETWEEN_BASES = NONE
COMPLETED_RESTART_POLICY = OWNER_DECISION_REQUIRED
```
