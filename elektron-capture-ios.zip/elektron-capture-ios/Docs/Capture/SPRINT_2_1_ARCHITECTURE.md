# Elektron Capture — Sprint 2.1 Architecture Baseline & Invariants

| Field | Value |
|---|---|
| **Status** | `LOCKED` |
| **Series** | Sprint 2.1A → 2.1F |
| **Refinements** | Session aggregate vs envelope · soft-delete as local-media policy |
| **Next sprint** | **2.2** Hardening & Field Reliability |
| **Deferred** | Phase 3 Spatial |

This document is the **authoritative contract** for domain layering, unidirectional data flow, and field regression. Pseudocode in planning notes must yield to the types and boundaries named here.

---

## 1. Architecture Layering & Data Flow

```text
1. Immutable Plan Snapshot (`InspectionPlanSnapshot`)     → Domain Authority (requirements)
2. Stateless Engine (`InspectionProgressionEngine`)       → Workflow Transitions
3. Stateless Binder (`EvidenceBindingService`)            → Evidence Lifecycle & Validation
4. Session Aggregate (`InspectionSession`)                → Authoritative Immutable State
5. Session Envelope (`InspectionSessionEnvelope`)         → Serialization & Integrity Boundary
6. App Orchestrator (`GuidedInspectionCoordinator`)       → Async Intent & Persistence
7. Presentation Adapter (`GuidedInspectionPresenter` /
   `GuidedInspectionViewModel` / Review presenters)       → UI State Mapping
8. SwiftUI Views                                          → Pure Render + Intent Emission
```

### Session vs envelope (locked clarification)

1. **Authoritative session aggregate vs envelope boundary**
   - **`InspectionSession`** is the authoritative, immutable **aggregate root** containing active state, progress, and bound evidence.
   - The persisted envelope (**`InspectionSessionEnvelope`**) plus **`GuidedSessionPersisting`** serve strictly as the **serialization format**, disk layout manager, and **cryptographic integrity boundary**. The envelope does not invent workflow authority.

2. **Media retention policy flexibility**
   - Soft-delete quarantine (isolating orphaned or replaced binary media into an isolated directory) is the **current local-media storage policy**, *not* a permanent domain invariant.
   - Future retention, audit logging, server sync purging, or compliance policies may replace or extend this storage policy **without** modifying domain evidence-binding semantics or breaking `InspectionSession` purity.

### Unidirectional flow (shipped)

```text
SwiftUI Overlay / Library / Review
        │ emits GuidedInspectionIntent (typed)
        ▼
GuidedInspectionViewModel / Review adapter
        │ ephemeral UI state only
        │ delegates intent (no disk / no EvidenceMetadata construction)
        ▼
GuidedInspectionCoordinator (struct, Sendable)
        │ apply intent → domain services
        │ persist via GuidedSessionPersisting (sole owner of session saves)
        │ captureRequested → shouldTriggerShutter only (no AVCapture call)
        ▼
InspectionProgressionEngine  +  EvidenceBindingService  +  InspectionPreExportValidator
        │ pure (Session) → Session / ValidationReport
        ▼
Updated InspectionSession (+ derived presentation state)
        │
        ▼
ViewModel adopts session / publishes presentation
```

**Camera boundary:** `AVCaptureSession` warm-up, permission, resume, and shutter live in the Phase 1 capture path. The coordinator **signals** shutter readiness; it does **not** own the camera controller.

---

## 2. Strict Architecture Invariants

1. SwiftUI views **NEVER** mutate `InspectionSession` or construct domain `EvidenceMetadata`, manifests, or export-domain records.
2. `GuidedInspectionCoordinator` (**struct**) is the **SOLE** owner of guided-session persistence side-effects (`GuidedSessionPersisting` / `persistGuidedSession`).
3. `EvidenceBindingService`, `InspectionProgressionEngine`, and `InspectionPreExportValidator` **MUST** remain strictly stateless — no singletons, no `.shared`.
4. `InspectionPlanSnapshot` is frozen and authoritative for all point thresholds and instructions (`snapshotSHA256` per S2-002).
5. All domain mutations **MUST** be pure: `(InspectionSession) → new InspectionSession`.
6. Camera preview lifecycle (`AVCaptureSession`) operates independently of workflow state transitions.
7. Unbinding, replacing, or deleting evidence **MUST** immediately trigger dynamic requirement satisfaction re-evaluation (derived; never persisted as a flag).
8. **Local media policy (current, not permanent domain law):** Soft-delete quarantine is the **current** retention approach (see Session vs envelope clarification §2). Retake uses a **new capture-id**; evidence is never destructively overwritten in place. Binding semantics stay `storageKey` + derived satisfaction regardless of future retention backends.

### Additional shipped locks

- Envelope schema remains **v1** (Option A) unless a material incompatibility forces a bump.
- Satisfaction is **derived** from binding count vs frozen `expectedEvidenceType` / `InspectionEvidenceRequirement`.
- Ephemeral UI (`GuidedInspectionUIState`, review/export sheet flags) **MUST NOT** appear on the session wire format.
- Point identities for binding come only from the session’s frozen snapshot.
- Existing package integrity, canonical JSON, hashes, and `.edts-pkg` contracts must not be weakened.

---

## 3. Intent Surface (authoritative)

```swift
public enum GuidedInspectionIntent: Equatable, Sendable {
  case prepareGuidedSession
  case activatePoint(InspectionPointID)
  case advanceRequested
  case returnRequested
  case completePointRequested
  case skipRequested(reason: String)
  case blockRequested(reason: String)
  case captureRequested                          // validate + shouldTriggerShutter
  case bindApprovedCapture(storageKey:type:attributes:)
  case unbindLibraryEvidence(libraryEvidenceId:)
  case replaceLibraryEvidence(oldLibraryEvidenceId:storageKey:type:attributes:)
  // Sprint 2.1F — review / export orchestration
  case reviewInspectionRequested                 // open/refresh review projection (no mutation)
  case refreshValidationRequested
  case reviewPointRequested(InspectionPointID)   // activate + navigate to capture
  case generateExportRequested                   // TOCTOU re-validate; app then uses existing exporter
}
```

Bindings live on `InspectionSession.evidenceBindings` (`EvidenceBindingCollection`).

---

## 4. Presentation Split

| Type | Role |
|---|---|
| `GuidedInspectionPresentationState` | Derived HUD model |
| `GuidedInspectionPresenter` | Pure factory for HUD state |
| `GuidedInspectionUIState` | Ephemeral HUD only |
| `InspectionReviewUIState` | Ephemeral review/export sheets & in-flight flags |
| `EvidencePointSectionPresentation` | Derived library/review grouping (not persisted) |
| `InspectionValidationReport` | Stateless pre-export findings |

Views bind to presentation flags; they do not re-implement satisfaction or export policy math.

---

## 5. Export policy (explicit)

| Condition | Export |
|---|---|
| Required point **completed** + evidence satisfied | Allow |
| Required point **skipped** with non-blank reason | **Allow** (structural completion) |
| Required point **blocked** (any reason) | **Block** |
| Required point open / insufficient evidence | **Block** |
| Binding integrity failures (unknown point, blank key, duplicate ID, session mismatch) | **Block** |

Policy is evaluated by `InspectionPreExportValidator` / `InspectionExportPolicy` — **not** by SwiftUI.

**TOCTOU:** Preview validation is advisory. Generation **must** re-run validation immediately before calling the existing package builder/exporter.

---

## 6. Field Regression Checklist

See `Docs/Capture/FIELD_REGRESSION_CHECKLIST.md` (gate for every sprint ≥ 2.1F).

---

## 7. Master Roadmap Status

```text
2.1A–2.1E.1  Guided workflow foundation     ✅
SPRINT_2_1_ARCHITECTURE.md                  🔒 LOCKED (with session/envelope + media-policy refinements)
2.1F  Inspection Review & Pre-Export        ✅ (device/xcodebuild pending)

-------------------------------------------------------------------
2.2   Hardening, Memory/Battery & Field Resilience ──► NEXT
3.0   Spatial Computing (AR / LiDAR / Twin)         deferred
```

---

## 9. Sprint 2.1F implementation map (repository-native paths)

Kickoff diagrams that reference `Sources/ElektronCapture/...` map to this repo as:

| Kickoff concept | Actual path |
|---|---|
| Domain validator / report / policy | `App/Domain/Services/PreExportValidationService.swift` (`InspectionPreExportValidator`, `InspectionValidationReport`, `InspectionExportPolicy`) |
| Grouped presentation | same file (`EvidencePointSectionPresentation`) + `App/Phase1/EvidenceLibrary/InspectionPointEvidenceGrouping.swift` |
| Review UI / VM | `Apps/Phase1StillCapture/InspectionReviewView.swift`, `InspectionReviewViewModel.swift` |
| Intents / coordinator | `App/Domain/Services/GuidedInspectionPresentation.swift`, `GuidedInspectionCoordinator.swift` |
| Tests | `Tests/Unit/Sprint2_1FTests.swift` |

```text
InspectionSession (immutable aggregate)
        │
        ├─► InspectionPreExportValidator → InspectionValidationReport
        │         │
        │         ▼
        │   InspectionReviewViewModel / InspectionReviewView
        │         │ generateExportRequested (TOCTOU)
        │         ▼
        │   Existing EvidenceLibraryStore.copyExportPackage / Phase1 builder
        │
        └─► Evidence Library (EvidencePointSectionPresentation)
                  │ reviewPointRequested
                  ▼
            GuidedInspectionCoordinator → activate point
```
