# Sprint 2.1F — Technician Walkthrough

## Tabs

1. **Capture** — guided HUD, single Capture control, More → Skip / Block / Complete / Open Review  
2. **Evidence Library** — sessions → point sections (`Point N — Title` + status)  
3. **Review** — export readiness, findings, point list, Export Preview, Generate

## Happy path (4-point or 6-point plan)

1. Start New Inspection and select a plan.  
2. Capture required evidence per active point (Next unlocks when satisfied).  
3. Open **Evidence Library** — confirm sections follow plan order; empty points still listed.  
4. Open **Review** — header shows satisfied / skipped / blocked counts.  
5. Open **Export Preview** — confirm proposed filename and evidence list.  
6. Tap **Generate Evidence Package** only when Export ready.  
7. Share sheet presents `.edts-pkg` **copies**; library originals stay untouched.

## Deficiency path

1. Leave a required point short of evidence.  
2. Review shows a blocking finding in plain language (e.g. “Battery needs 1 more photo”).  
3. Tap the finding or **Fix this point** → Capture activates that point.  
4. Capture the missing photo → return to Review → finding clears.

## Rollback after preview

1. Reach Export ready.  
2. Delete a required photo from Library (soft-delete quarantine).  
3. Return to Review / Generate — validation re-runs (TOCTOU) and Export blocks.  
4. Retake / re-capture → Export becomes available again.

## Skip / Block policy (documented)

| Terminal | Export |
|---|---|
| **Skipped** with non-blank reason | **Allowed** |
| **Blocked** (any reason) | **Blocked** |

## Architecture reminders

- Views emit intents only; they do not mutate `InspectionSession`.  
- Soft-delete quarantine is **current local-media policy**, not a permanent domain law.  
- Frozen `InspectionPlanSnapshot` remains the requirement authority.
