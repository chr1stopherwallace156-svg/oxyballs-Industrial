# Sprint 2.2 — Physical Device Validation Checklist

| Field | Value |
|---|---|
| Status | **NOT RUN** on cloud agent |
| Required for | `DEVICE_VALIDATED_PENDING_ACCEPTANCE` |
| Build commit | _(fill)_ |
| Device / iOS | _(fill)_ |

Each row must record expected, actual, pass/fail, device/iOS, build commit, evidence note.

| # | Item | Expected | Actual | Pass/Fail | Device/iOS | Commit | Evidence |
|---|---|---|---|---|---|---|---|
| 1 | First install | App launches; no crash | | | | | |
| 2 | Upgrade from prior persisted data | Prior session/evidence restored or clean migrate | | | | | |
| 3 | Camera permission allowed | Preview live | | | | | |
| 4 | Camera permission denied | Permission UI; no crash | | | | | |
| 5 | Permission changed in Settings | App recovers on return | | | | | |
| 6 | Save & Exit with 0 photos | Enabled; `.inProgress`; resumable | | | | | |
| 7 | Save & Exit with partial photos | Same session id on Resume | | | | | |
| 8 | Force quit and resume | Same session, bindings, active point | | | | | |
| 9 | Background/foreground during capture | No ghost session; preview recovers | | | | | |
| 10 | Lock/unlock during active session | Session intact | | | | | |
| 11 | Orientation | No crash; usable layout | | | | | |
| 12 | Low storage (if safe) | Visible error; no silent success | | | | | |
| 13 | View Details | Opens evidence detail | | | | | |
| 14 | Assign to Point | Binding persists; list updates | | | | | |
| 15 | Retake | Replacement after Use Photo | | | | | |
| 16 | Delete evidence | Gone after Refresh + relaunch | | | | | |
| 17 | Delete inspection | Confirm; session gone; media quarantined | | | | | |
| 18 | Restart | Confirm; new session id | | | | | |
| 19 | Archive | Hidden from list (local filter); data retained | | | | | |
| 20 | Complete Inspection | Enabled only when workflows resolved | | | | | |
| 21 | Manual Refresh | Reloads session + catalog; errors visible | | | | | |
| 22 | Cold relaunch | No resurrection of deleted records | | | | | |
| 23 | Visible failure handling | Injected/forced fail shows alert | | | | | |
| 24 | No Use Photo legacy flash | Direct return to live capture | | | | | |

**Classification gate:** Do not claim `DEVICE_VALIDATED_*` until every applicable row is Pass with commit + device filled.
