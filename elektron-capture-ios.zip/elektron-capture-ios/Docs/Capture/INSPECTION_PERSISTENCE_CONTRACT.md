# Inspection Persistence Contract

Applies to `App/Phase1/Inspection/`. Introduced by App Interaction Repair 01.

## Why this exists

Before the repair the engine persisted exactly **one** current-session slot
(`current_session.json`). An inspection therefore had no record of its own, and the only way
one could "disappear" was as a side effect of every one of its captures being removed. Absence
of captures was being used as evidence of deletion. It is not.

## Layout

```
Documents/InspectionSessions/
  current_session.json          v1 slot — retained, still written by the live session path
  inspections/<sessionID>.json  v2: one InspectionSessionEnvelope per inspection
  archive.json                  InspectionArchiveDocument
  tombstones.json               InspectionTombstoneDocument
  migration_v2.json             migration completion marker
```

`InspectionStoreLayoutVersion` versions the **directory layout**.
`InspectionSessionSchemaVersion` versions the **envelope payload** and is deliberately
unchanged at `v1`: the repair moves records, it does not reshape them. Bumping the envelope
version with an empty migration registry would have made every pre-repair envelope on every
device fail to load with `missingMigrationPath`.

## The seven operations

| Operation | Method | Contract |
|---|---|---|
| list inspections | `listInspections()` | Every non-tombstoned record, newest `startedAt` first. One unreadable record never hides the rest. |
| load by session id | `load(sessionID:)` | The record, or `nil` when none exists. Throws `alreadyDeleted` when a tombstone exists, so a deleted inspection can never be mistaken for a merely absent one. |
| save | `save(_:)` | Insert or replace exactly one record. Other records are not read or written. |
| archive | `archive(sessionID:)` | Reversible visibility state. Does not change `status`, does not touch evidence. |
| unarchive | `unarchive(sessionID:)` | Clears the archived flag. **Never** used to express, implement or undo a deletion. |
| delete | `delete(sessionID:reason:retainedEvidenceIDs:)` | Writes the tombstone first, then removes the record file. Idempotent. |
| tombstones | `tombstones()` / `deletedSessionIDs()` | The durable proof set. |

Reload after process restart is not a separate operation: every write is durable before it
returns, so a fresh store over the same directory observes the same facts.

## Deletion semantics

- **Keyed on `inspectionSessionID`.** Nothing else identifies an inspection for deletion.
- **Proven, not inferred.** A tombstone is a positive recorded fact. No code may conclude an
  inspection was deleted because it has no captures, no record file, or no projection entry.
- **Ordered for crash safety.** Tombstone first, then record removal. A crash between the two
  leaves the inspection deleted with a stale record file that every read path ignores. The
  reverse order could lose the record with no proof it was ever deleted.
- **Verified before it is claimed.** `InspectionDeletionService` re-reads `deletedSessionIDs()`
  after the write and returns `.failed` if the tombstone cannot be observed. Success is never
  announced on an unverified write.
- **Isolated.** Deleting one inspection never reads or writes another's record.
- **Archive-independent.** The archived flag is untouched by deletion.
- **Terminal-agnostic.** Completed and canceled inspections delete exactly like active ones.
- **Zero-capture safe.** An inspection with no captures is a real record; it is listed and
  deletable.

## Retention policy — evidence is never touched by inspection deletion

Deleting an inspection removes the **inspection record only**.

Capture directories, `artifact_original.jpg` bytes, sidecars, manifests, packages and library
index rows are **not** quarantined, moved, overwritten or removed. Every capture of a deleted
inspection stays on disk and stays individually addressable and verifiable; the Evidence
Library lists them under *"Evidence from deleted inspections"*.

`InspectionTombstone.evidenceDisposition` records `RETAINED_INTACT`, and the tombstone lists
the retained capture ids so a later audit can prove which evidence survived.

Removing capture media remains a **separate, explicitly user-initiated evidence action**
(`EvidenceLibraryStore.softDeleteUserInitiated`, which quarantines rather than erases). It is
never a side effect of deleting an inspection.

## Migration and rollback

`InspectionStoreMigration.migrateIfNeeded(root:legacyCurrentSessionURL:archivedSessionIDs:store:)`

- **Non-destructive** — `current_session.json` is copied, never moved or deleted.
- **Idempotent** — guarded by `migration_v2.json`; re-running is always safe.
- **Terminal-inclusive** — a finished v1 session migrates too; v2 does not discard history.
- **Archive import** — the v1 `UserDefaults` archived set is passed in and becomes durable.

**Rollback:** `InspectionStoreMigration.rollback(root:)` deletes `inspections/`,
`tombstones.json`, `archive.json` and `migration_v2.json`. The untouched v1 file is then
authoritative again. Rollback loses only records created after the migration; it cannot damage
pre-migration data.

## Refresh safety

`FileCurrentSessionRepository.load()` is **byte-neutral**. It previously deleted
`current_session.json` whenever the stored session was terminal and returned `nil`, so a plain
Refresh after "Complete Inspection" destroyed the record and reported success. Only `clear()`
and the identity-checked `clearIfHolding(sessionID:)` remove the file, and only when a caller
explicitly asks.

`InspectionRefreshResolution.resolve(prior:load:)` is a pure function enforcing one rule:
**a refresh may never destroy state.** A read failure, a vanished record and a diverged
identity all preserve the prior projection; a terminal session is adopted and shown read-only.
