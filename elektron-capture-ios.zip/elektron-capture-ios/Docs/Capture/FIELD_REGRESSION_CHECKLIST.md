# Field Regression Checklist

Gate for every sprint **≥ 2.1F** prior to sign-off. Mark each row with Pass / Fail / **NOT RUN**.

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                       FIELD REGRESSION CHECKLIST                            │
├──────────────────────────────────────┬──────────────────────────────────────┤
│ 1. CAMERA & HUD LAYOUT               │ 2. WORKFLOW & SATISFACTION           │
│  □ First-launch camera starts        │  □ "Next" unlocks ONLY when domain   │
│  □ App resume keeps preview active   │    evaluates requirement satisfaction│
│  □ Single Capture button responds    │  □ Skip & Block require valid text   │
│  □ Guidance HUD overlays correctly   │  □ Return / Previous navigation works│
├──────────────────────────────────────┼──────────────────────────────────────┤
│ 3. EVIDENCE LIFECYCLE                │ 4. PERSISTENCE & RECOVERY            │
│  □ Immediate thumbnail refresh       │  □ Force-quit mid-session preserves  │
│  □ Retake replaces & updates count   │    active point, bound evidence, and │
│  □ Delete quarantines & re-evaluates │    satisfaction / export readiness   │
│  □ Satisfaction rollback re-locks    │  □ Export package builds cleanly with│
│    "Next" / Export instantly         │    correct metadata & manifest integrity│
├──────────────────────────────────────┼──────────────────────────────────────┤
│ 5. REVIEW & PRE-EXPORT (2.1F)        │                                      │
│  □ Review lists every plan point     │                                      │
│  □ Findings navigate to correct point│                                      │
│  □ Export blocked with typed reasons │                                      │
│  □ TOCTOU re-validation before gen   │                                      │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Sprint 2.1F host results

| Area | Result |
|---|---|
| 1–5 device scenarios | **NOT RUN** (Linux host; no physical iPhone / xcodebuild) |
| Domain validation / suite | Covered by `Sprint2_1FTests` + full `swift test` |

See also: `Docs/Capture/SPRINT_2_1_ARCHITECTURE.md`, `Docs/Capture/SPRINT_2_1F_STATUS.md`.
