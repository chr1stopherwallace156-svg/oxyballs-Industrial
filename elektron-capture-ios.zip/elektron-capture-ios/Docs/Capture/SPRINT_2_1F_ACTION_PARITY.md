# Sprint 2.1F — Gated Action Parity (Phases A → C)

| Field | Value |
|---|---|
| **Status** | `IMPLEMENTED_PENDING_XCODEBUILD_AND_DEVICE_VALIDATION` |
| **Branch** | `cursor/sprint-2-1f-save-and-exit-d881` |
| **Phase A** | `SPRINT_2_1F_PHASE_A_CHECKPOINT.md` (mandatory gate + A2 Save & Exit) |
| **SSOT** | `AUTHORITATIVE_COMMIT_PROPAGATION_CONTRACT.md` |
| **Postmortem / guardrails** | `Docs/Architecture/POSTMORTEM_INTERACTION_PIPELINES.md`, `Docs/Architecture/INTERACTION_PIPELINE_GUARDRAILS.md` |

## Domain Action-Intent Mapping

### EvidenceActionIntent
| Intent | Operation |
|---|---|
| `viewDetails` | Navigate Evidence Detail |
| `retake` | `beginRetake` → Capture |
| `delete` | confirm → unbind (persist) → soft-delete media |
| `assignToPoint` | `assignLibraryEvidenceToPoint` (explicit only) |

Swipe Retake/Delete and long-press Retake/Delete emit the **same** `EvidenceActionIntent` cases via `EvidenceActionModifier`.

### PointActionIntent
| Intent | Operation |
|---|---|
| `open` / `addPhoto` | `reviewPointRequested` + Capture tab |
| `redo` | Non-destructive `beginRetake` of first bound id |
| `skip` / `block` | Coordinator skip/block + non-blank reason |
| `clearEvidence` | confirm → clear bindings (persist) → quarantine media |

### InspectionActionIntent
| Intent | Operation |
|---|---|
| `saveAndExit` | Persist `.inProgress` partial progress; leave Capture → Review; never complete/export/archive |
| `completeInspection` | Gated terminal completion (`canCommitCompletion`); Review / More / Detail only |
| `createNewFromPlan` | Cancel active session if present, then mint new session id with empty evidence; plan/vehicle carried over. Original canceled session remains on disk history only via current-session store semantics (single current). |
| `restartCurrent` | Confirm; new session (refuses completed overwrite) |
| `archive` | Presentation filter; data/media retained |
| `delete` | Session cancel/tombstone **first**; media quarantine **after** |

**Field escape hatch:** Capture banner exposes **Save & Exit** (always for active session), not Complete Inspection.

## Media cleanup transaction order

1. Persist session mutation (unbind / clear / cancel)  
2. Adopt committed session  
3. Update presentation  
4. Quarantine media — failures logged; do **not** roll back session authority  

## Verification

```text
swift test → see handoff commit
xcodebuild → NOT RUN (Linux)
Physical device → NOT RUN
```
