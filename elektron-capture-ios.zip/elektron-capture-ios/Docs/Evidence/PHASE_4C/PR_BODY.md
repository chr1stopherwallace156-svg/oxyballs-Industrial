# Phase 4C: Dense fusion and point-cloud filtering foundation

Stacks on Phase 4B (`f54b63e`). Adds deterministic voxel fusion, confidence weighting, duplicate consolidation, outlier/conflict audit records, normals, density/gaps, and a Phase 4D handoff contract — without generating a mesh.

## Results
- package: `SPKG-FIXTURE-DENSE-FUSION-000001`
- fused points: `13`
- readiness: `READY_FOR_SYNTHETIC_SURFACE_CANDIDATE`
- fused cloud SHA-256: `e2864a73bb6a1a7df7235fed067a6fd3ad24036445eb8cb80f084634fd58ca2d`
- suite: 678 / 7 skipped / 0 failed

## Verify
```
make phase4c-dense-fusion-verify
swift run EmitPhase4CEvidence Docs/Evidence/PHASE_4C
```

## Non-claims
Production dense fusion, surface mesh, metrology, and digital twin remain FORBIDDEN.
