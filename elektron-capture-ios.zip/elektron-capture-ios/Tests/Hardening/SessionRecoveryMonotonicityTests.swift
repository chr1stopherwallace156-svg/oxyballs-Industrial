import XCTest
@testable import ElektronCapture

/// ElektronCoreHardeningTests — Phase D recovery monotonicity (Sprint 2.3 bounded scope).
final class SessionRecoveryMonotonicityTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_721_300_000)

  private func makeSession(id: String, revision: Int) throws -> InspectionSession {
    let plan = try InspectionPlan(
      id: "s23_rec",
      version: "1.0.0",
      title: "S23 Rec",
      points: [try InspectionPoint(id: "p1", title: "P1", displayOrder: 1, isRequired: true)]
    )
    let snapshot = try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
    var session = try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "REC-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )
    session.revision = revision
    return session
  }

  func testGateRejectsLowerOrEqualRecoveredRevision() throws {
    let durable = try makeSession(id: "INS-REC-1", revision: 5)
    let lower = try makeSession(id: "INS-REC-1", revision: 4)
    let equal = try makeSession(id: "INS-REC-1", revision: 5)
    let newer = try makeSession(id: "INS-REC-1", revision: 6)

    XCTAssertEqual(
      SessionRecoveryGate.evaluate(durable: durable, recovered: lower),
      .rejectLowerOrEqualRevision(durable: 5, recovered: 4)
    )
    XCTAssertEqual(
      SessionRecoveryGate.evaluate(durable: durable, recovered: equal),
      .rejectLowerOrEqualRevision(durable: 5, recovered: 5)
    )
    XCTAssertEqual(
      SessionRecoveryGate.evaluate(durable: durable, recovered: newer),
      .adoptNewer(durable: 5, recovered: 6)
    )
    XCTAssertEqual(
      SessionRecoveryGate.evaluate(durable: nil, recovered: lower),
      .adoptEmptySlot
    )
  }

  func testInstallRecoveredRejectsRegressionWithoutTouchingDisk() async throws {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("s23-rec-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)

    var head = try makeSession(id: "INS-REC-DISK", revision: 0)
    head = try await repo.save(head, expectedRevision: 0) // rev 1
    var bumped = head
    bumped.status = .paused
    head = try await repo.save(bumped, expectedRevision: 1) // rev 2
    let before = try Data(contentsOf: url)

    var older = head
    older.revision = 1
    older.status = .inProgress
    do {
      _ = try await repo.installRecoveredSnapshot(older)
      XCTFail("expected recoveryRevisionRegression")
    } catch let InspectionSessionError.recoveryRevisionRegression(durable, recovered) {
      XCTAssertEqual(durable, 2)
      XCTAssertEqual(recovered, 1)
    }

    XCTAssertEqual(try Data(contentsOf: url), before)
    let loadedOpt = try await repo.load()
    let loaded = try XCTUnwrap(loadedOpt)
    XCTAssertEqual(loaded.revision, 2)
    XCTAssertEqual(loaded.status, .paused)
  }

  func testInstallRecoveredAcceptsStrictlyNewerSnapshot() async throws {
    let repo = InMemoryCurrentSessionRepository()
    var head = try makeSession(id: "INS-REC-NEW", revision: 0)
    head = try await repo.save(head, expectedRevision: 0) // 1

    var recovered = head
    recovered.revision = 3
    recovered.status = .paused
    let installed = try await repo.installRecoveredSnapshot(recovered)
    XCTAssertEqual(installed.revision, 3)
    XCTAssertEqual(installed.status, .paused)
    let loadedOpt = try await repo.load()
    let loaded = try XCTUnwrap(loadedOpt)
    XCTAssertEqual(loaded.revision, 3)
  }
}
