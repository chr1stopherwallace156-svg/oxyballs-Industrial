import XCTest
@testable import ElektronCapture

final class Phase38PrivacyTransferTests: XCTestCase {
  private func tempDir(_ name: String = UUID().uuidString) throws -> URL {
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("p38-\(name)", isDirectory: true)
    try? FileManager.default.removeItem(at: url)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  // MARK: Privacy

  func testRawEvidencePreservedSeparately() throws {
    let policy = EvidencePrivacyPolicy.fixtureRawRestricted()
    let raw = Data("RAW-SRC".utf8)
    let result = try FixtureRedactionEngine().apply(sourceBytes: raw, sourceArtifactID: "A1", policy: policy)
    XCTAssertNotNil(result.raw)
    XCTAssertNotEqual(result.raw?.sha256, result.redacted.sha256)
    XCTAssertEqual(result.raw?.sha256, ContentHasher.sha256Hex(raw))
  }

  func testRedactionNeverOverwritesSource() throws {
    let dir = try tempDir()
    let rawPath = dir.appendingPathComponent("restricted_raw/A1.bin")
    try FileManager.default.createDirectory(at: rawPath.deletingLastPathComponent(), withIntermediateDirectories: true)
    let raw = Data("UNCHANGED".utf8)
    try raw.write(to: rawPath)
    let result = try FixtureRedactionEngine().apply(
      sourceBytes: raw,
      sourceArtifactID: "A1",
      policy: .fixtureRawRestricted()
    )
    let redacted = FixtureRedactionEngine().materializeRedactedBytes(
      sourceBytes: raw,
      operations: result.derivation.operations
    )
    let redPath = dir.appendingPathComponent("client_safe/red.bin")
    try FileManager.default.createDirectory(at: redPath.deletingLastPathComponent(), withIntermediateDirectories: true)
    try redacted.write(to: redPath)
    XCTAssertEqual(try Data(contentsOf: rawPath), raw)
  }

  func testMissingDerivationReferenceRejected() throws {
    var d = try FixtureRedactionEngine().apply(
      sourceBytes: Data("x".utf8),
      sourceArtifactID: "A",
      policy: .fixtureRawRestricted()
    ).derivation
    d.sourceArtifactID = ""
    XCTAssertThrowsError(try FixtureRedactionEngine().verifyDerivation(derivation: d, expectedSourceSHA: d.sourceArtifactSHA256))
  }

  func testIncorrectSourceDigestRejected() throws {
    let d = try FixtureRedactionEngine().apply(
      sourceBytes: Data("x".utf8),
      sourceArtifactID: "A",
      policy: .fixtureRawRestricted()
    ).derivation
    XCTAssertThrowsError(try FixtureRedactionEngine().verifyDerivation(derivation: d, expectedSourceSHA: String(repeating: "0", count: 64)))
  }

  func testForbiddenRawExportRejected() throws {
    XCTAssertThrowsError(try { throw SpatialEvidenceError.forbiddenRawExport("inspection") }())
  }

  func testRequiredRedactionMissing() throws {
    var policy = EvidencePrivacyPolicy.fixtureRawRestricted()
    policy.redactionRequirements = [
      RedactionRequirement(detectionKind: "CUSTOM_POLICY_REGION", required: true, minimumConfidence: 0.99, preferredOperations: ["SOLID_MASK"]),
    ]
    XCTAssertThrowsError(
      try FixtureRedactionEngine().apply(sourceBytes: Data("x".utf8), sourceArtifactID: "A", policy: policy)
    )
  }

  func testPrivacyFirstPersistsNoProhibitedRaw() throws {
    let policy = EvidencePrivacyPolicy.fixturePrivacyFirst()
    let result = try FixtureRedactionEngine().apply(
      sourceBytes: Data("RAW".utf8),
      sourceArtifactID: "A",
      policy: policy
    )
    XCTAssertNil(result.raw)
    XCTAssertEqual(policy.captureMode, .privacyFirstCapture)
  }

  func testMetadataOmissionRecorded() throws {
    var ledger = MetadataPrivacyLedger()
    ledger.record(from: .fixtureRawRestricted())
    try ledger.assertFieldLedgered("precise_latitude_longitude")
    let omit = ledger.entries.first { $0.metadataField == "precise_latitude_longitude" }
    XCTAssertEqual(omit?.action, .omitByPolicy)
  }

  func testSilentMetadataStrippingRejected() throws {
    let ledger = MetadataPrivacyLedger()
    XCTAssertThrowsError(try ledger.assertFieldLedgered("precise_latitude_longitude"))
    XCTAssertThrowsError(try PrivacyPolicyEvaluator().rejectSilentMetadataStrip(field: "x", policyID: "p"))
  }

  func testUnknownPrivacyPolicyRejected() throws {
    XCTAssertThrowsError(try PrivacyPolicyEvaluator().activate(nil))
  }

  func testExpiredPolicyRejected() throws {
    var p = EvidencePrivacyPolicy.fixtureRawRestricted()
    p.expirationTimestampUTC = "2020-01-01T00:00:00Z"
    XCTAssertThrowsError(try PrivacyPolicyEvaluator(nowUTC: "2026-08-03T00:00:00Z").activate(p))
  }

  // MARK: Chunking

  func testDeterministicChunkBoundaries() throws {
    let bytes = Data(repeating: 7, count: 200)
    let a = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "a", count: 64))
    let b = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "a", count: 64))
    XCTAssertEqual(a.0.chunks.map(\.chunkSHA256), b.0.chunks.map(\.chunkSHA256))
    XCTAssertEqual(a.0.chunks.map(\.byteOffset), b.0.chunks.map(\.byteOffset))
  }

  func testChunkHashVerification() throws {
    let bytes = Data(repeating: 1, count: 70)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "b", count: 64))
    let ok = ChunkSequence().verifyChunk(m.chunks[0], bytes: payloads[0])
    XCTAssertTrue(ok.ok)
  }

  func testTruncatedChunkDetected() throws {
    let bytes = Data(repeating: 1, count: 70)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "b", count: 64))
    let bad = ChunkSequence().verifyChunk(m.chunks[0], bytes: payloads[0].prefix(10))
    XCTAssertFalse(bad.ok)
  }

  func testModifiedChunkDetected() throws {
    let bytes = Data(repeating: 1, count: 70)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "b", count: 64))
    var mutated = payloads[0]
    mutated[0] ^= 0xff
    XCTAssertFalse(ChunkSequence().verifyChunk(m.chunks[0], bytes: mutated).ok)
  }

  func testDuplicateSequenceRejected() throws {
    let bytes = Data(repeating: 1, count: 130)
    var (m, _) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "c", count: 64))
    m.chunks[1].sequence = m.chunks[0].sequence
    XCTAssertThrowsError(try ChunkSequence().validateManifestLayout(m))
  }

  func testMissingSequenceRejected() throws {
    let bytes = Data(repeating: 1, count: 130)
    var (m, _) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "c", count: 64))
    m.chunks[1].sequence = 9
    XCTAssertThrowsError(try ChunkSequence().validateManifestLayout(m))
  }

  func testOverlappingOffsetsRejected() throws {
    let bytes = Data(repeating: 1, count: 130)
    var (m, _) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "c", count: 64))
    m.chunks[1].byteOffset = 0
    XCTAssertThrowsError(try ChunkSequence().validateManifestLayout(m))
  }

  func testGapInOffsetsRejected() throws {
    let bytes = Data(repeating: 1, count: 130)
    var (m, _) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "c", count: 64))
    m.chunks[1].byteOffset = m.chunks[1].byteOffset + 10
    m.totalByteLength += 10
    XCTAssertThrowsError(try ChunkSequence().validateManifestLayout(m))
  }

  func testWrongSourcePackageClosureRejected() throws {
    let bytes = Data(repeating: 1, count: 70)
    var (m, _) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "d", count: 64))
    m.chunks[0].sourcePackageClosureSHA256 = String(repeating: "e", count: 64)
    XCTAssertThrowsError(try ChunkSequence().validateManifestLayout(m))
  }

  func testAbsolutePathRejected() throws {
    let bytes = Data(repeating: 1, count: 70)
    var (m, _) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "d", count: 64))
    m.chunks[0].chunkID = "/absolute/chunk"
    XCTAssertThrowsError(try ChunkSequence().validateManifestLayout(m))
  }

  func testCrossTenantReuseRejected() throws {
    var server = FixtureTransferServer()
    XCTAssertThrowsError(
      try server.rejectCrossTenantReuse(sha256: "x", fromTenant: "T1", toTenant: "T2", securityDomainID: "S")
    )
  }

  func testCrossSecurityDomainReuseRejected() throws {
    var server = FixtureTransferServer()
    XCTAssertThrowsError(
      try server.rejectCrossSecurityDomainReuse(sha256: "x", tenantID: "T", fromDomain: "A", toDomain: "B")
    )
  }

  // MARK: Transfer

  func testPauseAndResume() throws {
    let bytes = Data(repeating: 2, count: 150)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U1", packageID: "P", manifest: m)
    var server = FixtureTransferServer()
    try session.beginUpload()
    _ = try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server)
    try session.pause()
    XCTAssertEqual(session.state, .paused)
    let plan = try session.resume()
    XCTAssertFalse(plan.chunksToUpload.contains(m.chunks[0].chunkID))
  }

  func testNetworkInterruptionAndResume() throws {
    let bytes = Data(repeating: 2, count: 150)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U2", packageID: "P", manifest: m)
    var server = FixtureTransferServer()
    try session.beginUpload()
    _ = try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server)
    session.interrupt()
    XCTAssertEqual(session.state, .interrupted)
    let plan = try session.resume()
    for c in m.chunks where plan.chunksToUpload.contains(c.chunkID) {
      _ = try session.submitChunk(descriptor: c, bytes: payloads[Int(c.sequence)], server: &server)
    }
    let receipt = try session.finalize(manifest: m)
    XCTAssertEqual(receipt.state, .complete)
  }

  func testRetryLimit() throws {
    let bytes = Data(repeating: 2, count: 70)
    let (m, _) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U3", packageID: "P", manifest: m, maxRetries: 1)
    var server = FixtureTransferServer()
    try session.beginUpload()
    var bad = Data(repeating: 9, count: m.chunks[0].byteLength)
    XCTAssertThrowsError(try session.submitChunk(descriptor: m.chunks[0], bytes: bad, server: &server))
    XCTAssertThrowsError(try session.submitChunk(descriptor: m.chunks[0], bytes: bad, server: &server))
  }

  func testUploadExpiration() throws {
    let bytes = Data(repeating: 2, count: 70)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U4", packageID: "P", manifest: m, expiresAtUTC: "2026-08-01T00:00:00Z")
    var server = FixtureTransferServer()
    XCTAssertThrowsError(try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server, nowUTC: "2026-08-03T00:00:00Z"))
  }

  func testCancelledUpload() throws {
    let bytes = Data(repeating: 2, count: 70)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U5", packageID: "P", manifest: m)
    var server = FixtureTransferServer()
    session.cancel()
    XCTAssertThrowsError(try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server))
  }

  func testServerReceiptMismatch() throws {
    let bytes = Data(repeating: 2, count: 70)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U6", packageID: "P", manifest: m)
    var server = FixtureTransferServer()
    try session.beginUpload()
    _ = try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server)
    session.receipts[m.chunks[0].chunkID]?.chunkSHA256 = String(repeating: "0", count: 64)
    XCTAssertThrowsError(try session.finalize(manifest: m))
  }

  func testMissingReceipt() throws {
    let bytes = Data(repeating: 2, count: 130)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U7", packageID: "P", manifest: m)
    var server = FixtureTransferServer()
    try session.beginUpload()
    _ = try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server)
    // Force-mark second accepted without receipt
    session.chunkStates[m.chunks[1].chunkID] = .accepted
    XCTAssertThrowsError(try session.finalize(manifest: m))
  }

  func testAcceptedChunkNotResent() throws {
    let bytes = Data(repeating: 2, count: 130)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U8", packageID: "P", manifest: m)
    var server = FixtureTransferServer()
    try session.beginUpload()
    _ = try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server)
    let attemptsBefore = session.attempts.count
    _ = try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server)
    XCTAssertEqual(session.attempts.count, attemptsBefore)
    XCTAssertTrue(session.resentAcceptedChunkIDs.isEmpty)
  }

  func testRequestedChunkResentCorrectly() throws {
    let bytes = Data(repeating: 2, count: 70)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U9", packageID: "P", manifest: m)
    var server = FixtureTransferServer()
    try session.beginUpload()
    _ = try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server)
    _ = try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server, serverRequestsResend: true)
    XCTAssertTrue(session.resentAcceptedChunkIDs.contains(m.chunks[0].chunkID))
  }

  func testTransferCheckpointReplay() throws {
    let bytes = Data(repeating: 2, count: 130)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U10", packageID: "P", manifest: m)
    var server = FixtureTransferServer()
    try session.beginUpload()
    _ = try session.submitChunk(descriptor: m.chunks[0], bytes: payloads[0], server: &server)
    let cp = session.checkpoint()
    XCTAssertEqual(cp.acceptedChunkIDs, [m.chunks[0].chunkID])
    XCTAssertTrue(cp.missingChunkIDs.contains(m.chunks[1].chunkID))
  }

  func testNoDuplicateCompletion() throws {
    let bytes = Data(repeating: 2, count: 70)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "f", count: 64))
    var session = ResumableUploadSession(sessionID: "U11", packageID: "P", manifest: m)
    var server = FixtureTransferServer()
    try session.beginUpload()
    for (i, c) in m.chunks.enumerated() {
      _ = try session.submitChunk(descriptor: c, bytes: payloads[i], server: &server)
    }
    _ = try session.finalize(manifest: m)
    XCTAssertThrowsError(try session.finalize(manifest: m))
  }

  func testReassemblyByteIdentity() throws {
    let bytes = Data(repeating: 3, count: 200)
    let (m, payloads) = try ChunkSequence().chunk(packageBytes: bytes, packageID: "P", sourcePackageClosureSHA256: String(repeating: "1", count: 64))
    var map: [String: Data] = [:]
    for (i, c) in m.chunks.enumerated() { map[c.chunkID] = payloads[i] }
    let out = try PackageReassembler().reassemble(manifest: m, payloadsByChunkID: map)
    XCTAssertEqual(out, bytes)
  }

  // MARK: Delivery profiles + primary fixture

  func testPrimaryFieldTransferFixture() throws {
    let dir = try tempDir("field")
    let result = try FixtureFieldTransferPackageBuilder().sealPrimary(outputDirectory: dir)
    XCTAssertEqual(result.privacyPolicy.policyID, EvidencePrivacyPolicy.fixturePolicyID)
    XCTAssertEqual(result.inspection.profileID, EvidenceDeliveryProfile.inspectionProfileID)
    XCTAssertEqual(result.engineering.profileID, EvidenceDeliveryProfile.engineeringProfileID)
    XCTAssertNotNil(result.transformation.raw)
    XCTAssertEqual(result.reassembledZIPSHA256, result.sourceZIPSHA256)
    XCTAssertTrue(result.reassembly.ok)
    XCTAssertTrue(result.reassembly.packageClosureMatch)
    XCTAssertTrue(result.reassembly.signaturePreserved)
    XCTAssertTrue(result.reassembly.journalRootPreserved)
    XCTAssertFalse(result.acceptedChunksResent)
    XCTAssertEqual(result.uploadSession.state, .complete)
    XCTAssertFalse(result.inspection.includedRelativePaths.contains { $0.contains("restricted_raw") })
    XCTAssertTrue(result.engineering.includedRelativePaths.contains { $0.contains("restricted_raw") })
    try result.metadataLedger.assertFieldLedgered("precise_latitude_longitude")

    if let emit = ProcessInfo.processInfo.environment["ELEKTRON_EMIT_DIR"] {
      let dest = URL(fileURLWithPath: emit).appendingPathComponent(FixtureFieldTransferPackageBuilder.primaryPackageID)
      try? FileManager.default.removeItem(at: dest)
      try FileManager.default.copyItem(at: dir, to: dest)
      let meta: [String: Any] = [
        "package_id": FixtureFieldTransferPackageBuilder.primaryPackageID,
        "privacy_policy_id": result.privacyPolicy.policyID,
        "inspection_profile_id": result.inspection.profileID,
        "engineering_profile_id": result.engineering.profileID,
        "source_package_closure_sha256": result.sourcePackageClosureSHA256,
        "inspection_package_closure_sha256": result.inspectionPackageClosureSHA256,
        "engineering_package_closure_sha256": result.engineeringPackageClosureSHA256,
        "chunking_algorithm": result.chunkManifest.algorithm.rawValue,
        "chunk_count": result.chunkManifest.chunks.count,
        "chunk_manifest_sha256": result.chunkManifestSHA256,
        "source_zip_sha256": result.sourceZIPSHA256,
        "reassembled_zip_sha256": result.reassembledZIPSHA256,
        "journal_root_sha256": result.journalRootSHA256,
        "accepted_chunks_resent": result.acceptedChunksResent,
        "tenant_id": result.dedup.tenantID,
        "bytes_saved": result.dedup.bytesSaved,
      ]
      try CanonicalJSON.data(meta).write(
        to: URL(fileURLWithPath: emit).appendingPathComponent("field-transfer-000001_meta.json"),
        options: .atomic
      )
    }
  }

  func testInspectionExcludesRestrictedRaw() throws {
    let dir = try tempDir("insp")
    let result = try FixtureFieldTransferPackageBuilder().sealPrimary(outputDirectory: dir)
    let inspRoot = dir.appendingPathComponent("inspection_package")
    XCTAssertFalse(FileManager.default.fileExists(atPath: inspRoot.appendingPathComponent("restricted_raw").path))
    XCTAssertEqual(result.inspection.packageID, FixtureFieldTransferPackageBuilder.inspectionPackageID)
  }

  func testEngineeringIncludesAuthorizedRaw() throws {
    let dir = try tempDir("eng")
    let result = try FixtureFieldTransferPackageBuilder().sealPrimary(outputDirectory: dir)
    XCTAssertTrue(result.engineering.includedRelativePaths.contains { $0.contains("restricted_raw") })
  }

  func testDerivativeManifestBindsToSource() throws {
    let dir = try tempDir("bind")
    _ = try FixtureFieldTransferPackageBuilder().sealPrimary(outputDirectory: dir)
    let binding = try JSONSerialization.jsonObject(
      with: Data(contentsOf: dir.appendingPathComponent("inspection_package/source_binding.json"))
    ) as? [String: Any]
    XCTAssertEqual(binding?["source_package_id"] as? String, FixtureFieldTransferPackageBuilder.engineeringPackageID)
  }

  func testProfileOutputDeterministic() throws {
    let a = try tempDir("det-a")
    let b = try tempDir("det-b")
    let ra = try FixtureFieldTransferPackageBuilder().sealPrimary(outputDirectory: a)
    let rb = try FixtureFieldTransferPackageBuilder().sealPrimary(outputDirectory: b)
    XCTAssertEqual(ra.sourceZIPSHA256, rb.sourceZIPSHA256)
    XCTAssertEqual(ra.engineeringPackageClosureSHA256, rb.engineeringPackageClosureSHA256)
    XCTAssertEqual(ra.inspectionPackageClosureSHA256, rb.inspectionPackageClosureSHA256)
    XCTAssertEqual(ra.chunkManifestSHA256, rb.chunkManifestSHA256)
  }

  func testSourcePackageBytesUnchangedAcrossProfiles() throws {
    let dir = try tempDir("unchanged")
    let result = try FixtureFieldTransferPackageBuilder().sealPrimary(outputDirectory: dir)
    let zip1 = try Data(contentsOf: dir.appendingPathComponent("engineering_package.zip"))
    XCTAssertEqual(ContentHasher.sha256Hex(zip1), result.sourceZIPSHA256)
    // Re-read after inspection generation already done in seal — bytes stable
    let zip2 = try Data(contentsOf: dir.appendingPathComponent("engineering_package.zip"))
    XCTAssertEqual(zip1, zip2)
  }

  func testApplePrivacyCandidatesUnavailableOnLinux() throws {
    XCTAssertEqual(AppleVisionRedactionDetector().availabilityStatus, "UNAVAILABLE_ON_THIS_PLATFORM")
    XCTAssertEqual(AppleCoreMLPrivacyFilter().availabilityStatus, "UNAVAILABLE_ON_THIS_PLATFORM")
    XCTAssertThrowsError(try AppleVisionRedactionDetector().detect(in: Data()))
  }

  func testCompressionProfileRecorded() throws {
    let insp = EvidenceDeliveryProfile.inspection(privacyPolicyID: "P")
    let eng = EvidenceDeliveryProfile.engineering(privacyPolicyID: "P")
    XCTAssertEqual(insp.compression, .fixtureGzipLight)
    XCTAssertEqual(eng.compression, .fixtureUncompressed)
  }
}
