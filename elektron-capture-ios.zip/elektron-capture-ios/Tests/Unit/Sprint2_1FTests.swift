import XCTest
@testable import ElektronCapture

final class Sprint2_1FTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_500_000)
  private let binding = EvidenceBindingService()
  private let progression = InspectionProgressionEngine()
  private let validator = InspectionPreExportValidator()
  private let policy = InspectionExportPolicy()

  private func makeSnapshot(pointCount: Int = 3) throws -> InspectionPlanSnapshot {
    var points: [InspectionPoint] = [
      try InspectionPoint(id: "vin", title: "VIN Plate", displayOrder: 1, isRequired: true),
      try InspectionPoint(
        id: "battery",
        title: "Battery",
        displayOrder: 2,
        isRequired: true,
        expectedEvidenceType: .multiPhoto
      ),
    ]
    if pointCount >= 3 {
      points.append(
        try InspectionPoint(id: "note", title: "Optional Note", displayOrder: 3, isRequired: false)
      )
    }
    if pointCount >= 4 {
      points.append(contentsOf: [
        try InspectionPoint(id: "front", title: "Front", displayOrder: 4, isRequired: true),
        try InspectionPoint(id: "rear", title: "Rear", displayOrder: 5, isRequired: true),
        try InspectionPoint(id: "side", title: "Side", displayOrder: 6, isRequired: true),
      ])
    }
    let plan = try InspectionPlan(
      id: pointCount >= 4 ? "six_point" : "f_demo",
      version: "1.0.0",
      title: pointCount >= 4 ? "Six Point" : "F Demo",
      points: points
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession(id: String = "INS-21F", pointCount: Int = 3) throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "F-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: makeSnapshot(pointCount: pointCount),
      assignedAt: fixedInstant
    )
  }

  private func pointID(_ raw: String) -> InspectionPointID {
    InspectionPointID.unchecked(raw)
  }

  private func bind(
    _ session: InspectionSession,
    point: String,
    key: String,
    id: EvidenceID = EvidenceID()
  ) throws -> InspectionSession {
    try binding.bind(
      evidence: EvidenceMetadata(
        id: id,
        pointID: pointID(point),
        sessionID: session.id,
        type: .photo,
        createdAt: fixedInstant,
        storageKey: key,
        payloadAttributes: [:]
      ),
      to: session
    )
  }

  private func completeRequiredMinimal(_ session: InspectionSession) throws -> InspectionSession {
    var session = session
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)
    session = try bind(session, point: "vin", key: "k-vin")
    session = try progression.completeActivePoint(in: session)
    session = try progression.activate(pointID: pointID("battery"), in: session)
    session = try bind(session, point: "battery", key: "k-b1")
    session = try bind(session, point: "battery", key: "k-b2")
    session = try progression.completeActivePoint(in: session)
    return session
  }

  // MARK: - Validator

  func testMissingSnapshotBlocksExport() throws {
    let legacy = try InspectionSession(
      id: SessionID.unchecked("INS-LEGACY-F"),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "L")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planState: .legacyUnassigned
    )
    let report = validator.validate(legacy)
    XCTAssertFalse(report.isExportReady)
    XCTAssertTrue(report.findings.contains { $0.code == .missingPlanSnapshot })
  }

  func testOpenRequiredPointsBlockExport() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)
    let report = validator.validate(session)
    XCTAssertFalse(report.isExportReady)
    XCTAssertTrue(report.findings.contains { $0.code == .insufficientEvidence || $0.code == .incompletePoint })
  }

  func testCompleteValidInspectionIsExportReady() throws {
    let session = try completeRequiredMinimal(try makeSession())
    let report = validator.validate(session)
    XCTAssertTrue(report.isExportReady, report.summaryLine)
    XCTAssertEqual(report.blockingFindings, [])
    XCTAssertEqual(report.exportPreview.count, 3)
    XCTAssertEqual(policy.evaluate(session: session, validationReport: report).isAllowed, true)
  }

  func testSkipAllowsExportBlockDoesNot() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)
    session = try bind(session, point: "vin", key: "k-vin")
    session = try progression.completeActivePoint(in: session)
    session = try progression.activate(pointID: pointID("battery"), in: session)
    session = try progression.skipActivePoint(reason: "inaccessible", in: session)

    var report = validator.validate(session)
    XCTAssertTrue(report.isExportReady)
    XCTAssertEqual(report.disposition, .complete)
    XCTAssertEqual(report.skippedRequiredCount, 1)

    session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)
    session = try bind(session, point: "vin", key: "k-vin-2")
    session = try progression.completeActivePoint(in: session)
    session = try progression.activate(pointID: pointID("battery"), in: session)
    session = try progression.blockActivePoint(reason: "hazmat", in: session)

    report = validator.validate(session)
    XCTAssertFalse(report.isExportReady)
    XCTAssertEqual(report.disposition, .blocked)
    XCTAssertTrue(report.findings.contains { $0.code == .requiredPointBlocked })
  }

  func testUnbindAfterCompleteDropsExportability() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)
    let eid = EvidenceID()
    session = try bind(
      session,
      point: "vin",
      key: "INS-21F/vin/\(eid.rawValue.uuidString)/EVD-X",
      id: eid
    )
    session = try progression.completeActivePoint(in: session)
    session = try progression.activate(pointID: pointID("battery"), in: session)
    session = try progression.skipActivePoint(reason: "n/a", in: session)
    XCTAssertTrue(validator.validate(session).isExportReady)

    session = try binding.unbind(evidenceID: eid, from: session)
    let report = validator.validate(session)
    XCTAssertFalse(report.isExportReady)
    XCTAssertTrue(report.findings.contains { $0.code == .insufficientEvidence })
  }

  func testUnknownPointBindingAndEmptyStorageKeyAndDuplicateID() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    // Force-insert integrity problems via collection mutation on a copy path:
    // bind valid then manually craft second session with bad bindings is hard without
    // bypassing service — use service for empty key / unknown point.
    XCTAssertThrowsError(
      try binding.bind(
        evidence: EvidenceMetadata(
          pointID: pointID("does-not-exist"),
          sessionID: session.id,
          type: .photo,
          createdAt: fixedInstant,
          storageKey: "k",
          payloadAttributes: [:]
        ),
        to: session
      )
    )

    // Simulate unknown binding by assembling a session with raw collection
    let bad = EvidenceMetadata(
      pointID: pointID("ghost"),
      sessionID: session.id,
      type: .photo,
      createdAt: fixedInstant,
      storageKey: "ghost-key",
      payloadAttributes: [:]
    )
    var collection = EvidenceBindingCollection()
    collection.bindings = [bad]
    session.evidenceBindings = collection
    var report = validator.validate(session)
    XCTAssertTrue(report.findings.contains { $0.code == .unknownPointBinding })

    let blank = EvidenceMetadata(
      pointID: pointID("vin"),
      sessionID: session.id,
      type: .photo,
      createdAt: fixedInstant,
      storageKey: "   ",
      payloadAttributes: [:]
    )
    collection.bindings = [blank]
    session.evidenceBindings = collection
    report = validator.validate(session)
    XCTAssertTrue(report.findings.contains { $0.code == .emptyStorageKey })

    let id = EvidenceID()
    let a = EvidenceMetadata(
      id: id,
      pointID: pointID("vin"),
      sessionID: session.id,
      type: .photo,
      createdAt: fixedInstant,
      storageKey: "a",
      payloadAttributes: [:]
    )
    let b = EvidenceMetadata(
      id: id,
      pointID: pointID("battery"),
      sessionID: session.id,
      type: .photo,
      createdAt: fixedInstant,
      storageKey: "b",
      payloadAttributes: [:]
    )
    collection.bindings = [a, b]
    session.evidenceBindings = collection
    report = validator.validate(session)
    XCTAssertTrue(report.findings.contains { $0.code == .duplicateEvidenceID })
  }

  func testDeterministicFindingOrderAndStatelessness() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    let r1 = validator.validate(session)
    let r2 = validator.validate(session)
    XCTAssertEqual(r1.findings.map(\.id), r2.findings.map(\.id))
    XCTAssertEqual(r1, r2)
  }

  func testExportPreviewLibraryHint() {
    let key = GuidedInspectionCoordinator.makeStorageKey(
      sessionID: SessionID.unchecked("INS-21F"),
      pointID: pointID("vin"),
      evidenceID: EvidenceID(),
      approvedKey: "EVD-LIB-99"
    )
    XCTAssertEqual(InspectionPreExportValidator.libraryIdHint(from: key), "EVD-LIB-99")
  }

  // MARK: - Grouped presentation

  func testPointSectionsFollowSnapshotOrderIncludingEmpty() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try bind(session, point: "vin", key: "INS-21F/vin/\(EvidenceID().rawValue.uuidString)/EVD-VIN")

    let captures = [
      EvidenceLibraryIndexRecord(
        id: "EVD-VIN",
        captureTimestamp: fixedInstant,
        sessionId: "SESSION",
        artifactId: "ART",
        recordId: "REC",
        inspectionSessionID: session.id.rawValue,
        isSynthetic: true,
        originalRelativePath: "captures/EVD-VIN/artifact_original.jpg",
        thumbnailRelativePath: "captures/EVD-VIN/thumbnail.jpg",
        originalSha256: String(repeating: "a", count: 64),
        originalByteCount: 10
      )
    ]
    let group = InspectionEvidenceGroup(
      sessionID: session.id.rawValue,
      vehicleIdentifier: "F-1",
      vehicleIdentifierKind: VehicleIdentifierKind.unknown.rawValue,
      inspectorID: "I",
      inspectorName: "N",
      startedAtUTC: nil,
      sessionStatusAtLatestCapture: nil,
      latestCaptureAt: fixedInstant,
      captures: captures
    )
    let sections = EvidencePointSectionPresenter.sections(group: group, session: session)
    XCTAssertEqual(sections.map(\.title), ["VIN Plate", "Battery", "Optional Note"])
    XCTAssertEqual(sections[0].sequenceNumber, 1)
    XCTAssertEqual(sections[0].captures.map(\.id), ["EVD-VIN"])
    XCTAssertTrue(sections[1].captures.isEmpty)
    XCTAssertTrue(sections[1].requiresAttention || !sections[1].isSatisfied)
  }

  func testReviewPointIntentActivatesWithoutViewMutation() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)
    let coordinator = GuidedInspectionCoordinator(persister: nil)
    let handled = try coordinator.apply(
      .reviewPointRequested(pointID("battery")),
      session: session
    )
    XCTAssertEqual(handled.session.progress?.activePointID, pointID("battery"))
  }

  func testGenerateExportRequestedTOCTOU() throws {
    let ready = try completeRequiredMinimal(try makeSession())
    let coordinator = GuidedInspectionCoordinator(persister: nil)
    let allowed = try coordinator.apply(.generateExportRequested, session: ready)
    XCTAssertNotNil(allowed.exportDecision)
    XCTAssertEqual(allowed.exportDecision?.isAllowed, true)

    var blocked = try makeSession()
    blocked = try progression.initializeProgress(for: blocked)
    XCTAssertThrowsError(try coordinator.apply(.generateExportRequested, session: blocked)) { err in
      guard case GuidedInspectionPresentationError.exportBlocked = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testNoActiveSessionFactory() {
    let report = InspectionValidationReport.noActiveSession()
    XCTAssertNil(report.sessionID)
    XCTAssertFalse(report.isExportReady)
    XCTAssertEqual(report.disposition, .incomplete)
    XCTAssertEqual(report.blockingFindings.count, 1)
    XCTAssertEqual(report.blockingFindings.first?.code, .missingPlanSnapshot)
    XCTAssertEqual(report.proposedExportFilename, "inspection-evidence.edts-pkg")
  }
}
