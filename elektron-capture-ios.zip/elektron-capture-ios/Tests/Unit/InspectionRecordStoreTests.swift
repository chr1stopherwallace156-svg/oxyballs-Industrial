import XCTest
@testable import ElektronCapture

/// Durability contract for the v2 inspection record store.
/// Every assertion runs against the real `FileInspectionRecordStore` on a real temp directory.
final class InspectionRecordStoreTests: XCTestCase {
  private func tempRoot() -> URL {
    FileManager.default.temporaryDirectory
      .appendingPathComponent("recstore-\(UUID().uuidString)", isDirectory: true)
  }

  private func makeSession(
    _ id: String,
    status: SessionStatus = .inProgress,
    startedAt: Date = Date(timeIntervalSince1970: 1_700_000_000)
  ) throws -> InspectionSession {
    InspectionSession(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: try VehicleIdentifier(rawValue: "FLEET-\(id)")),
      inspector: .localDefault,
      startedAt: startedAt,
      status: status,
      planState: .legacyUnassigned
    )
  }

  // MARK: Round trip

  func testSaveThenLoadRoundTrips() async throws {
    let root = tempRoot()
    defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)

    let session = try makeSession("INS-RT-1")
    try await store.save(session)

    let loaded = try await store.load(sessionID: "INS-RT-1")
    XCTAssertEqual(loaded?.id, session.id)
    XCTAssertEqual(loaded?.status, .inProgress)
  }

  func testListReturnsEveryNonDeletedRecordNewestFirst() async throws {
    let root = tempRoot()
    defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)

    try await store.save(try makeSession("INS-A", startedAt: Date(timeIntervalSince1970: 100)))
    try await store.save(try makeSession("INS-B", startedAt: Date(timeIntervalSince1970: 300)))
    try await store.save(try makeSession("INS-C", startedAt: Date(timeIntervalSince1970: 200)))

    let ids = try await store.listInspections().map(\.id.rawValue)
    XCTAssertEqual(ids, ["INS-B", "INS-C", "INS-A"])
  }

  /// T-DEL-03 — a completely fresh object graph over the same directory must see the deletion.
  func testDeletionSurvivesFreshObjectGraph() async throws {
    let root = tempRoot()
    defer { try? FileManager.default.removeItem(at: root) }

    let first = FileInspectionRecordStore(root: root)
    try await first.save(try makeSession("INS-RELAUNCH"))
    _ = try await first.delete(sessionID: "INS-RELAUNCH", reason: .userInitiated, retainedEvidenceIDs: [])

    // Simulated relaunch: nothing in memory is shared with `first`.
    let second = FileInspectionRecordStore(root: root)
    let awaited1 = try await second.deletedSessionIDs().contains("INS-RELAUNCH")
    XCTAssertTrue(awaited1)
    let awaited2 = try await second.listInspections().isEmpty
    XCTAssertTrue(awaited2)
  }

  /// Deletion must be proven by a tombstone, never inferred from a missing file.
  func testLoadOfDeletedSessionThrowsRatherThanReturningNil() async throws {
    let root = tempRoot()
    defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await store.save(try makeSession("INS-PROOF"))
    _ = try await store.delete(sessionID: "INS-PROOF", reason: .userInitiated, retainedEvidenceIDs: [])

    do {
      _ = try await store.load(sessionID: "INS-PROOF")
      XCTFail("expected alreadyDeleted")
    } catch let e as InspectionRecordStoreError {
      XCTAssertEqual(e, .alreadyDeleted("INS-PROOF"))
    }
  }

  func testDeleteIsIdempotentAndKeepsOriginalTombstone() async throws {
    let root = tempRoot()
    defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await store.save(try makeSession("INS-IDEM"))

    let first = try await store.delete(sessionID: "INS-IDEM", reason: .userInitiated, retainedEvidenceIDs: ["EVD-1"])
    let second = try await store.delete(sessionID: "INS-IDEM", reason: .userInitiated, retainedEvidenceIDs: ["EVD-2"])

    XCTAssertEqual(first, second, "repeat delete must not rewrite the original proof")
    let awaited3 = try await store.tombstones().count
    XCTAssertEqual(awaited3, 1)
  }

  func testArchiveAndDeleteAreIndependentStates() async throws {
    let root = tempRoot()
    defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await store.save(try makeSession("INS-ARCH"))

    try await store.archive(sessionID: "INS-ARCH")
    let awaited4 = try await store.archivedSessionIDs().contains("INS-ARCH")
    XCTAssertTrue(awaited4)

    _ = try await store.delete(sessionID: "INS-ARCH", reason: .userInitiated, retainedEvidenceIDs: [])

    // T-DEL-09: deleting must not clear the archived flag as a way of "hiding" the record.
    let awaited5 = try await store.archivedSessionIDs().contains("INS-ARCH")
    XCTAssertTrue(awaited5)
    let awaited6 = try await store.deletedSessionIDs().contains("INS-ARCH")
    XCTAssertTrue(awaited6)
  }

  func testSessionIDValidationRejectsPathTraversal() {
    XCTAssertThrowsError(try FileInspectionRecordStore.validateSessionID("../escape"))
    XCTAssertThrowsError(try FileInspectionRecordStore.validateSessionID("a/b"))
    XCTAssertThrowsError(try FileInspectionRecordStore.validateSessionID(".hidden"))
    XCTAssertNoThrow(try FileInspectionRecordStore.validateSessionID("INS-20260101-000000-AB12"))
  }

  // MARK: Migration

  func testMigrationCopiesV1SlotAndIsIdempotent() async throws {
    let root = tempRoot()
    defer { try? FileManager.default.removeItem(at: root) }
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)

    let legacyURL = root.appendingPathComponent("current_session.json")
    let legacyRepo = FileCurrentSessionRepository(fileURL: legacyURL)
    let session = try makeSession("INS-MIG-1")
    _ = try await legacyRepo.save(session, expectedRevision: 0)

    let store = FileInspectionRecordStore(root: root)
    let outcome = await InspectionStoreMigration.migrateIfNeeded(
      root: root,
      legacyCurrentSessionURL: legacyURL,
      archivedSessionIDs: ["INS-OLD-ARCHIVED"],
      store: store
    )
    XCTAssertEqual(outcome, .migrated(sessionID: "INS-MIG-1"))
    let awaited7 = try await store.listInspections().map(\.id.rawValue)
    XCTAssertEqual(awaited7, ["INS-MIG-1"])
    let awaited8 = try await store.archivedSessionIDs().contains("INS-OLD-ARCHIVED")
    XCTAssertTrue(awaited8)

    // Non-destructive: the v1 file is still there and still readable.
    XCTAssertTrue(FileManager.default.fileExists(atPath: legacyURL.path))
    let awaited9 = try await legacyRepo.load()
    XCTAssertNotNil(awaited9)

    // Idempotent.
    let again = await InspectionStoreMigration.migrateIfNeeded(
      root: root,
      legacyCurrentSessionURL: legacyURL,
      archivedSessionIDs: [],
      store: store
    )
    XCTAssertEqual(again, .alreadyMigrated)
  }

  func testRollbackRemovesV2ArtifactsAndLeavesV1Intact() async throws {
    let root = tempRoot()
    defer { try? FileManager.default.removeItem(at: root) }
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)

    let legacyURL = root.appendingPathComponent("current_session.json")
    let legacyRepo = FileCurrentSessionRepository(fileURL: legacyURL)
    _ = try await legacyRepo.save(try makeSession("INS-ROLLBACK"), expectedRevision: 0)

    let store = FileInspectionRecordStore(root: root)
    _ = await InspectionStoreMigration.migrateIfNeeded(
      root: root,
      legacyCurrentSessionURL: legacyURL,
      store: store
    )
    let awaited10 = try await store.listInspections().isEmpty
    XCTAssertFalse(awaited10)

    InspectionStoreMigration.rollback(root: root)

    XCTAssertFalse(
      FileManager.default.fileExists(
        atPath: root.appendingPathComponent(InspectionStoreMigration.markerFilename).path
      )
    )
    XCTAssertTrue(FileManager.default.fileExists(atPath: legacyURL.path))
    let awaited11 = try await legacyRepo.load()
    XCTAssertNotNil(awaited11, "v1 must remain authoritative after rollback")
  }
}
