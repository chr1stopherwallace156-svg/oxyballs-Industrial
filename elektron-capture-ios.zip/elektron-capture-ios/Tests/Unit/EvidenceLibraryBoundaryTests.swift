import XCTest
@testable import ElektronCapture

/// Repair 02 — Evidence Library behaviour boundaries, exercised through production types.
///
/// `EvidenceLibraryListView` and `AppSessionContainer` are inside
/// `#if canImport(UIKit) && !os(macOS)` and cannot be instantiated by this target on any host.
/// The behaviour they depend on therefore lives in `RefreshActivityState` and
/// `InspectionLibraryPartition`, which the view and container *call* — these tests execute
/// those exact production types. Nothing is copied.
final class EvidenceLibraryBoundaryTests: XCTestCase {
  private let t0 = Date(timeIntervalSince1970: 1_700_000_000)

  private func record(_ id: String, session: String?, at offset: TimeInterval) -> EvidenceLibraryIndexRecord {
    EvidenceLibraryIndexRecord(
      id: id,
      captureTimestamp: t0.addingTimeInterval(offset),
      sessionId: "CAP-\(id)",
      artifactId: "ART-\(id)",
      recordId: "REC-\(id)",
      inspectionSessionID: session,
      originalRelativePath: "captures/\(id)/artifact_original.jpg",
      thumbnailRelativePath: "captures/\(id)/thumbnail.jpg",
      originalSha256: String(repeating: "a", count: 64),
      originalByteCount: 1
    )
  }

  private func catalog(_ records: [EvidenceLibraryIndexRecord]) -> InspectionEvidenceGrouping.Catalog {
    InspectionEvidenceGrouping.catalog(from: records)
  }

  // MARK: Refresh state

  func testRefresh_success_updatesTimestamp() {
    var state = RefreshActivityState()
    XCTAssertNil(state.lastRefreshedAt)
    XCTAssertEqual(state.stamp(), "Not refreshed yet")

    XCTAssertTrue(state.begin())
    state.finish(outcome: .updated(sessionID: "INS-1"), at: t0)

    XCTAssertEqual(state.lastRefreshedAt, t0)
    XCTAssertFalse(state.isRefreshing)
    XCTAssertTrue(state.stamp().hasPrefix("Updated "))
    XCTAssertNil(state.visibleErrorMessage, "a clean refresh must not raise an alert")
  }

  func testRefresh_failure_preservesPriorProjection() throws {
    let prior = InspectionSession(
      id: SessionID.unchecked("INS-KEEP"),
      vehicle: InspectionVehicle(primaryIdentifier: try VehicleIdentifier(rawValue: "FLEET-1")),
      inspector: .localDefault,
      startedAt: t0,
      status: .inProgress,
      planState: .legacyUnassigned
    )
    let decision = InspectionRefreshResolution.resolve(prior: prior, load: .failed("io error"))

    XCTAssertTrue(decision.preservedPrior)
    XCTAssertEqual(decision.adoptedSession?.id, prior.id)

    // And the stamp must not advance on a failure.
    var state = RefreshActivityState()
    XCTAssertTrue(state.begin())
    state.finish(outcome: decision.outcome, at: t0)
    XCTAssertNil(state.lastRefreshedAt)
    XCTAssertEqual(state.stamp(), "Not refreshed yet")
  }

  func testRefresh_failure_exposesVisibleErrorState() {
    var state = RefreshActivityState()
    XCTAssertTrue(state.begin())
    state.finish(outcome: .repositoryFailure(detail: "disk offline"), at: t0)

    let message = state.visibleErrorMessage
    XCTAssertNotNil(message, "a failed refresh must be visible on the screen that ran it")
    XCTAssertTrue(message?.contains("disk offline") ?? false)
    XCTAssertTrue(message?.contains("previous data is still shown") ?? false)

    state.clearOutcome()
    XCTAssertNil(state.visibleErrorMessage)
    XCTAssertNil(state.lastRefreshedAt, "dismissing the alert must not fake a successful refresh")
  }

  func testRefresh_reentrantRequest_isRejectedOrCoalesced() {
    var state = RefreshActivityState()
    XCTAssertTrue(state.begin(), "first refresh claims the slot")
    XCTAssertFalse(state.begin(), "a second refresh while one is in flight must be rejected")
    XCTAssertFalse(state.begin())

    state.finish(outcome: .updated(sessionID: "INS-1"), at: t0)
    XCTAssertTrue(state.begin(), "the slot is released once the refresh completes")
  }

  // MARK: Deletion / evidence retention

  func testDeletedInspectionEvidence_remainsAvailable() {
    let records = [
      record("EVD-1", session: "INS-DELETED", at: 10),
      record("EVD-2", session: "INS-DELETED", at: 20),
      record("EVD-3", session: "INS-LIVE", at: 30),
    ]
    let cat = catalog(records)

    let result = InspectionLibraryPartition.partition(
      groups: cat.groups,
      unassigned: cat.unassigned,
      archivedSessionIDs: [],
      deletedSessionIDs: ["INS-DELETED"]
    )

    XCTAssertEqual(result.live.map(\.sessionID), ["INS-LIVE"],
                   "a deleted inspection leaves the Inspections list")
    XCTAssertEqual(result.retainedFromDeleted.map(\.id), ["EVD-2", "EVD-1"],
                   "its captures stay listed, newest first, and remain individually openable")
  }

  func testInspectionDeletion_doesNotDeleteEvidence() {
    let records = [
      record("EVD-1", session: "INS-X", at: 10),
      record("EVD-2", session: "INS-X", at: 20),
    ]
    let cat = catalog(records)

    let before = InspectionLibraryPartition.partition(
      groups: cat.groups, unassigned: cat.unassigned,
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    let after = InspectionLibraryPartition.partition(
      groups: cat.groups, unassigned: cat.unassigned,
      archivedSessionIDs: [], deletedSessionIDs: ["INS-X"]
    )

    let beforeIDs = Set(before.live.flatMap(\.captures).map(\.id))
    let afterIDs = Set(after.retainedFromDeleted.map(\.id)).union(after.live.flatMap(\.captures).map(\.id))
    XCTAssertEqual(beforeIDs, afterIDs, "no capture may be dropped by deleting its inspection")
    XCTAssertTrue(after.live.isEmpty)
    XCTAssertEqual(after.retainedFromDeleted.count, 2)
  }

  /// Archived and deleted are independent filters and must not be conflated.
  func testArchivedAndDeletedArePartitionedIndependently() {
    let records = [
      record("EVD-A", session: "INS-ARCHIVED", at: 10),
      record("EVD-B", session: "INS-DELETED", at: 20),
      record("EVD-C", session: "INS-LIVE", at: 30),
      record("EVD-D", session: nil, at: 40),
    ]
    let cat = catalog(records)

    let result = InspectionLibraryPartition.partition(
      groups: cat.groups,
      unassigned: cat.unassigned,
      archivedSessionIDs: ["INS-ARCHIVED"],
      deletedSessionIDs: ["INS-DELETED"]
    )

    XCTAssertEqual(result.live.map(\.sessionID), ["INS-LIVE"])
    XCTAssertEqual(result.retainedFromDeleted.map(\.id), ["EVD-B"],
                   "only deleted inspections contribute retained evidence")
    XCTAssertEqual(result.unassigned.map(\.id), ["EVD-D"])
  }
}
