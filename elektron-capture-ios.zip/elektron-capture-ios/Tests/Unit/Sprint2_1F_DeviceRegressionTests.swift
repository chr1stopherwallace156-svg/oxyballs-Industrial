import XCTest
@testable import ElektronCapture

/// Device-regression corrective pass (post–Sprint 2.1F physical findings).
/// Linux-testable domain + persistence invariants that underpin the Capture/Library/Review sync fix.
final class Sprint2_1F_DeviceRegressionTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_600_000)
  private let binding = EvidenceBindingService()
  private let progression = InspectionProgressionEngine()
  private let validator = InspectionPreExportValidator()
  private let policy = InspectionExportPolicy()

  private func makeSnapshot(pointCount: Int = 4) throws -> InspectionPlanSnapshot {
    var points: [InspectionPoint] = [
      try InspectionPoint(id: "p1", title: "Front", displayOrder: 1, isRequired: true),
      try InspectionPoint(id: "p2", title: "Rear", displayOrder: 2, isRequired: true),
      try InspectionPoint(
        id: "p3",
        title: "Driver Side",
        displayOrder: 3,
        isRequired: true,
        expectedEvidenceType: .multiPhoto
      ),
      try InspectionPoint(id: "p4", title: "Passenger Side", displayOrder: 4, isRequired: true),
    ]
    if pointCount >= 6 {
      points.append(contentsOf: [
        try InspectionPoint(id: "p5", title: "VIN", displayOrder: 5, isRequired: true),
        try InspectionPoint(id: "p6", title: "Battery", displayOrder: 6, isRequired: true),
      ])
    }
    let plan = try InspectionPlan(
      id: pointCount >= 6 ? "six_point" : "four_point",
      version: "1.0.0",
      title: pointCount >= 6 ? "Six Point" : "Four Point",
      points: points
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession(id: String = "INS-REG", pointCount: Int = 4) throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "REG-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: try makeSnapshot(pointCount: pointCount),
      assignedAt: fixedInstant
    )
  }

  private func coordinator(persister: (any GuidedSessionPersisting)? = nil) -> GuidedInspectionCoordinator {
    GuidedInspectionCoordinator(
      instantProvider: FixedInstantProvider(fixedInstant),
      persister: persister
    )
  }

  private func pointID(_ raw: String) -> InspectionPointID {
    InspectionPointID.unchecked(raw)
  }

  // MARK: - 1–4 Capture post-approval destination (presentation contract)

  func testUsePhotoDestinationRemainsCaptureTabContract() {
    // App invariant documented + enforced in Phase1CaptureRootView Use Photo path:
    // selectedTab must stay .capture (never auto-switch to .library).
    enum AppTab: Equatable { case capture, library, review }
    var selectedTab: AppTab = .capture
    // Simulate successful approval side-effects without library navigation.
    selectedTab = .capture
    XCTAssertEqual(selectedTab, .capture)
    XCTAssertNotEqual(selectedTab, .library)
  }

  func testSuccessfulApprovalReturnsToCapturePresentation() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    session = try c.apply(
      .bindApprovedCapture(storageKey: "lib-1", type: .photo, attributes: [:]),
      session: session
    ).session
    let state = GuidedInspectionPresenter.makeState(from: session, binding: binding, progression: progression)
    XCTAssertTrue(state.isGuidedAvailable)
    XCTAssertEqual(state.activePointID, pointID("p1"))
    // Same point remains until satisfied progression advances or user Next/Complete.
    XCTAssertEqual(session.status, .inProgress)
  }

  func testAdditionalRequiredPhotoStaysOnSamePoint() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    // p3 requires multiPhoto (2). Activate p3.
    session = try progression.activate(pointID: pointID("p3"), in: session)
    session = try c.apply(
      .bindApprovedCapture(storageKey: "lib-a", type: .photo, attributes: [:]),
      session: session
    ).session
    let state = GuidedInspectionPresenter.makeState(from: session, binding: binding, progression: progression)
    XCTAssertEqual(state.activePointID, pointID("p3"))
    XCTAssertFalse(state.isPointSatisfied)
    XCTAssertEqual(state.evidenceCount, 1)
    XCTAssertGreaterThan(state.requiredCount, 1)
    XCTAssertTrue(state.canCapture)
    XCTAssertFalse(state.canAdvance)
  }

  func testSatisfiedPointEnablesCorrectProgressionAction() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    session = try c.apply(
      .bindApprovedCapture(storageKey: "lib-sat", type: .photo, attributes: [:]),
      session: session
    ).session
    let state = GuidedInspectionPresenter.makeState(from: session, binding: binding, progression: progression)
    XCTAssertTrue(state.isPointSatisfied)
    XCTAssertTrue(state.canComplete)
    XCTAssertTrue(state.canAdvance)
    XCTAssertEqual(session.progress?.progress(for: pointID("p1"))?.status, .inProgress)
  }

  // MARK: - 5–6 Authoritative session / no desync

  func testCommittedSessionAdoptedAcrossProjections() async throws {
    final class MemoryPersister: GuidedSessionPersisting, @unchecked Sendable {
      var last: InspectionSession?
      func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
        last = session
        return session
      }
    }
    let persister = MemoryPersister()
    let c = coordinator(persister: persister)
    var session = try makeSession(id: "INS-ADOPT")
    session = try await c.handle(.prepareGuidedSession, session: session).session
    let bound = try await c.handle(
      .bindApprovedCapture(storageKey: "lib-adopt", type: .photo, attributes: [:]),
      session: session
    )
    let committed = try XCTUnwrap(persister.last)
    XCTAssertEqual(bound.session.id, committed.id)
    XCTAssertEqual(
      bound.session.evidenceBindings?.bindings.count,
      committed.evidenceBindings?.bindings.count
    )
    let captureHUD = GuidedInspectionPresenter.makeState(
      from: committed, binding: binding, progression: progression
    )
    let review = policy.evaluate(
      session: committed,
      validationReport: validator.validate(committed)
    ).report
    XCTAssertTrue(captureHUD.isGuidedAvailable)
    XCTAssertEqual(review.sessionID, committed.id)
    XCTAssertEqual(captureHUD.evidenceCount, review.points.first?.boundCount)
  }

  func testNoActiveInspectionCannotCoexistWithActiveSessionPresentation() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("p4"), in: session)
    // Bind so HUD would otherwise show Point 4 / Satisfied.
    let meta = EvidenceMetadata(
      id: EvidenceID(),
      pointID: pointID("p4"),
      sessionID: session.id,
      type: .photo,
      createdAt: fixedInstant,
      storageKey: "k",
      payloadAttributes: [:]
    )
    session = try binding.bind(evidence: meta, to: session)
    session.status = .completed
    session.finishedAt = fixedInstant

    let hasActiveSession = session.status.isActiveOrPaused
    let presentation = GuidedInspectionPresenter.makeState(
      from: session, binding: binding, progression: progression
    )
    XCTAssertFalse(hasActiveSession)
    XCTAssertFalse(
      presentation.isGuidedAvailable,
      "Terminal session must not render guided HUD beside 'No active inspection'"
    )
  }

  // MARK: - 7–9 Evidence Library refresh authority

  func testLibraryForceReloadShowsEvidenceWrittenByOtherStoreInstance() async throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("elektron-reg-lib-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: root) }

    let writer = EvidenceLibraryStore(libraryRoot: root)
    let reader = EvidenceLibraryStore(libraryRoot: root)

    // Prime reader cache as empty.
    _ = try await reader.listInspectionCatalog(forceReload: true)
    let primed = try await reader.listInspectionCatalog()
    XCTAssertEqual(Self.catalogCount(primed), 0)

    let jpeg = Self.fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let ids = Phase1CaptureIdentifiers(
      evidenceId: "EV-REG-1",
      sessionId: "S1",
      artifactId: "A1",
      recordId: "R1"
    )
    _ = try await writer.storeApproved(jpegBytes: jpeg, sha256: sha, ids: ids)

    // Stale in-memory cache would miss the write; forceReload is the Refresh contract.
    let stale = try await reader.listInspectionCatalog(forceReload: false)
    XCTAssertEqual(Self.catalogCount(stale), 0)
    let fresh = try await reader.listInspectionCatalog(forceReload: true)
    XCTAssertEqual(Self.catalogCount(fresh), 1)
  }

  func testManualRefreshReloadsActiveSessionCatalogWithoutDuplicates() async throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("elektron-reg-dup-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: root) }
    let store = EvidenceLibraryStore(libraryRoot: root)
    let jpeg = Self.fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let ids = Phase1CaptureIdentifiers(
      evidenceId: "EV-DUP",
      sessionId: "S2",
      artifactId: "A2",
      recordId: "R2"
    )
    _ = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: ids)

    let first = try await store.listInspectionCatalog(forceReload: true)
    let second = try await store.listInspectionCatalog(forceReload: true)
    let third = try await store.listInspectionCatalog(forceReload: true)
    XCTAssertEqual(Self.catalogCount(first), 1)
    XCTAssertEqual(Self.catalogCount(second), 1)
    XCTAssertEqual(Self.catalogCount(third), 1)
  }

  func testNotificationCarriesStableSessionId() {
    let exp = expectation(description: "didChange")
    let token = NotificationCenter.default.addObserver(
      forName: EvidenceLibraryNotifications.didChange,
      object: nil,
      queue: .main
    ) { note in
      XCTAssertEqual(note.userInfo?[EvidenceLibraryNotifications.userInfoSessionIdKey] as? String, "INS-X")
      XCTAssertEqual(note.userInfo?[EvidenceLibraryNotifications.userInfoEvidenceIdKey] as? String, "EV-X")
      exp.fulfill()
    }
    defer { NotificationCenter.default.removeObserver(token) }
    EvidenceLibraryNotifications.postDidChange(evidenceId: "EV-X", sessionId: "INS-X")
    wait(for: [exp], timeout: 1.0)
  }

  // MARK: - 10 Review workflow coherence

  func testReviewDoesNotShowStaleNotStartedWhenEvidenceSatisfied() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("p1"), in: session)
    let meta = EvidenceMetadata(
      id: EvidenceID(),
      pointID: pointID("p1"),
      sessionID: session.id,
      type: .photo,
      createdAt: fixedInstant,
      storageKey: "sat-key",
      payloadAttributes: [:]
    )
    session = try binding.bind(evidence: meta, to: session)
    // Simulate demotion after leaving the point without completing.
    session = try progression.activate(pointID: pointID("p2"), in: session)
    XCTAssertEqual(session.progress?.progress(for: pointID("p1"))?.status, .notStarted)

    let report = policy.evaluate(
      session: session,
      validationReport: validator.validate(session)
    ).report
    let row = try XCTUnwrap(report.points.first { $0.pointID == pointID("p1") })
    XCTAssertTrue(row.isSatisfied)
    XCTAssertEqual(row.statusTag, "Evidence satisfied — ready to complete")
    XCTAssertFalse(row.statusTag.contains("Not started"))
  }

  func testBindPromotesActiveNotStartedToInProgress() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    // Force active point back to notStarted while keeping active identity (desync shape).
    if var progress = session.progress, let idx = progress.index(of: pointID("p1")) {
      progress.orderedPoints[idx].status = .notStarted
      session.progress = progress
    }
    session = try c.apply(
      .bindApprovedCapture(storageKey: "lib-promote", type: .photo, attributes: [:]),
      session: session
    ).session
    XCTAssertEqual(session.progress?.progress(for: pointID("p1"))?.status, .inProgress)
  }

  // MARK: - 11–13 Skip flow

  func testSkipAvailableOnUnsatisfiedPoint() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("p1"), in: session)
    let state = GuidedInspectionPresenter.makeState(
      from: session, binding: binding, progression: progression
    )
    XCTAssertFalse(state.isPointSatisfied)
    XCTAssertTrue(state.canSkip)
    XCTAssertTrue(state.canBlock)
  }

  func testSkipRequiresNonblankReason() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    XCTAssertThrowsError(try c.apply(.skipRequested(reason: "   "), session: session)) { err in
      XCTAssertEqual(err as? GuidedInspectionPresentationError, .emptySkipReason)
    }
  }

  func testSuccessfulSkipAdvancesAndPersists() async throws {
    final class MemoryPersister: GuidedSessionPersisting, @unchecked Sendable {
      var last: InspectionSession?
      func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
        last = session
        return session
      }
    }
    let persister = MemoryPersister()
    let c = coordinator(persister: persister)
    var session = try makeSession()
    session = try await c.handle(.prepareGuidedSession, session: session).session
    let result = try await c.handle(
      .skipRequested(reason: "Vehicle inaccessible against wall"),
      session: session
    )
    guard case .skipped(let reason) = result.session.progress?.progress(for: pointID("p1"))?.status else {
      return XCTFail("expected skipped")
    }
    XCTAssertEqual(reason, "Vehicle inaccessible against wall")
    XCTAssertEqual(result.session.progress?.activePointID, pointID("p2"))
    XCTAssertEqual(persister.last?.progress?.activePointID, pointID("p2"))
  }

  // MARK: - 14 Force quit / relaunch restores committed session

  func testForceQuitRelaunchRestoresSameCommittedState() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("elektron-reg-session-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }

    let repo = FileCurrentSessionRepository(fileURL: fileURL)
    let service = InspectionSessionService(repository: repo)
    let c = GuidedInspectionCoordinator(
      instantProvider: FixedInstantProvider(fixedInstant),
      persister: service
    )

    var session = try makeSession(id: "INS-RELAUNCH")
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "lib-relaunch", type: .photo, attributes: [:]),
      session: session
    ).session
    session = try await c.handle(
      .skipRequested(reason: "blocked by wall"),
      session: session
    ).session

    // Simulate force quit: new service + restore from disk.
    let service2 = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let restored = try await service2.restoreCurrentSession()
    let live = try XCTUnwrap(restored)
    XCTAssertEqual(live.id, session.id)
    XCTAssertEqual(live.evidenceBindings?.bindings.count, session.evidenceBindings?.bindings.count)
    XCTAssertEqual(live.progress?.activePointID, session.progress?.activePointID)
    guard case .skipped = live.progress?.progress(for: pointID("p1"))?.status else {
      return XCTFail("skip must survive relaunch")
    }
  }

  // MARK: - Helpers

  private static var fixtureJPEG: Data {
    Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
      0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14,
      0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7F, 0xFF, 0xD9,
    ])
  }

  private static func catalogCount(_ catalog: InspectionEvidenceGrouping.Catalog) -> Int {
    catalog.unassigned.count + catalog.groups.reduce(0) { $0 + $1.captures.count }
  }
}
