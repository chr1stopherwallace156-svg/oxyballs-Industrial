import XCTest
@testable import ElektronCapture

final class Phase31RGBMotionFoundationTests: XCTestCase {
  private func tempDir(_ name: String = UUID().uuidString) throws -> URL {
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("p31-\(name)", isDirectory: true)
    try? FileManager.default.removeItem(at: url)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  private func frames() -> [CoordinateFrameDescriptor] {
    [
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAMERA_OPTICAL",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "opencv",
        clockDomain: .avfoundationCapture,
        authority: "TEST_FIXTURE"
      ),
      CoordinateFrameDescriptor(
        frameID: "FRAME_DEVICE_IMU",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "n/a",
        clockDomain: .coreMotion,
        authority: "TEST_FIXTURE"
      ),
    ]
  }

  private func correlations() -> [ClockCorrelation] {
    // Explicit correlation required before claiming shared timebase — identity within each domain only.
    [
      ClockCorrelation(
        correlationID: "fixture-identity-avfoundation-capture",
        sourceDomain: .avfoundationCapture,
        destinationDomain: .avfoundationCapture,
        offsetNanoseconds: 0,
        authority: "TEST_FIXTURE",
        method: "domain_identity"
      ),
      ClockCorrelation(
        correlationID: "fixture-identity-core-motion",
        sourceDomain: .coreMotion,
        destinationDomain: .coreMotion,
        offsetNanoseconds: 0,
        authority: "TEST_FIXTURE",
        method: "domain_identity"
      ),
    ]
  }

  private func collectDeviceStreams(
    camera: ControllableCameraSensorAdapter,
    motion: ControllableMotionSensorAdapter
  ) async throws -> (cam: [SpatialSampleEnvelope<CameraSample>], mot: [SpatialSampleEnvelope<MotionSample>]) {
    try await camera.start()
    try await motion.start()
    var cams: [SpatialSampleEnvelope<CameraSample>] = []
    var mots: [SpatialSampleEnvelope<MotionSample>] = []
    for try await s in camera.samples() { cams.append(s) }
    for try await s in motion.samples() { mots.append(s) }
    await camera.stop()
    await motion.stop()
    return (cams, mots)
  }

  func testCameraPermissionDenied() async {
    let cam = ControllableCameraSensorAdapter()
    cam.permissionDenied = true
    do {
      try await cam.start()
      XCTFail("expected permission denied")
    } catch let ProductionSensorError.permissionDenied(s) {
      XCTAssertEqual(s, "camera")
    } catch {
      XCTFail("wrong \(error)")
    }
  }

  func testMotionUnavailable() async {
    let mot = ControllableMotionSensorAdapter()
    mot.unavailable = true
    do {
      try await mot.start()
      XCTFail("expected unavailable")
    } catch let ProductionSensorError.unavailable(s) {
      XCTAssertEqual(s, "motion")
    } catch {
      XCTFail("wrong \(error)")
    }
  }

  func testCameraStartsButMotionFails() async throws {
    let cam = ControllableCameraSensorAdapter()
    let mot = ControllableMotionSensorAdapter()
    mot.failOnStart = true
    try await cam.start()
    do {
      try await mot.start()
      XCTFail("expected motion fail")
    } catch {
      XCTAssertEqual(error as? ProductionSensorError, .unavailable("motion"))
    }
    await cam.stop()
  }

  func testMotionStartsButCameraFails() async throws {
    let cam = ControllableCameraSensorAdapter()
    let mot = ControllableMotionSensorAdapter()
    cam.failOnStart = true
    try await mot.start()
    do {
      try await cam.start()
      XCTFail("expected camera fail")
    } catch {
      XCTAssertEqual(error as? ProductionSensorError, .unavailable("camera"))
    }
    await mot.stop()
  }

  func testBackgroundDuringCapture() async {
    let cam = ControllableCameraSensorAdapter()
    cam.backgroundAfterStart = true
    do {
      try await cam.start()
      XCTFail("expected background")
    } catch {
      XCTAssertEqual(error as? ProductionSensorError, .backgrounded)
    }
  }

  func testInterruption() async {
    let cam = ControllableCameraSensorAdapter()
    cam.interruptAfterStart = true
    do {
      try await cam.start()
      XCTFail("expected interrupt")
    } catch let ProductionSensorError.interrupted(r) {
      XCTAssertFalse(r.isEmpty)
    } catch {
      XCTFail("wrong \(error)")
    }
  }

  func testUserCancellation() async {
    let cam = ControllableCameraSensorAdapter()
    cam.cancelAfterStart = true
    do {
      try await cam.start()
      XCTFail("expected cancel")
    } catch {
      XCTAssertEqual(error as? ProductionSensorError, .cancelled)
    }
  }

  func testAdapterStartCalledTwice() async throws {
    let cam = ControllableCameraSensorAdapter()
    try await cam.start()
    do {
      try await cam.start()
      XCTFail("expected already started")
    } catch {
      XCTAssertEqual(error as? ProductionSensorError, .alreadyStarted)
    }
    await cam.stop()
  }

  func testAdapterStopCalledTwice() async throws {
    let cam = ControllableCameraSensorAdapter()
    try await cam.start()
    await cam.stop()
    await cam.stop() // idempotent
  }

  func testFrameDeliveredAfterStop() async throws {
    let cam = ControllableCameraSensorAdapter()
    try await cam.start()
    await cam.stop()
    XCTAssertThrowsError(try cam.injectPostStopSampleAttempt()) { err in
      XCTAssertEqual(err as? ProductionSensorError, .postStopSample)
    }
  }

  func testTimestampRegression() async throws {
    let cam = ControllableCameraSensorAdapter()
    cam.regressTimestamps = true
    try await cam.start()
    do {
      for try await _ in cam.samples() {}
      XCTFail("expected regression")
    } catch let ProductionSensorError.timestampRegression(_, _) {
      // ok
    } catch {
      XCTFail("wrong \(error)")
    }
    await cam.stop()
  }

  func testUnknownPixelFormat() async throws {
    let cam = ControllableCameraSensorAdapter()
    cam.unknownPixelFormat = true
    try await cam.start()
    do {
      for try await _ in cam.samples() {}
      XCTFail("expected unknown format")
    } catch let ProductionSensorError.unknownPixelFormat(fmt) {
      XCTAssertEqual(fmt, "UNKNOWN_PIXEL_FMT")
    } catch {
      XCTFail("wrong \(error)")
    }
    await cam.stop()
  }

  func testDevicePackageNoFakeDepthOrPose() async throws {
    let cam = ControllableCameraSensorAdapter(adapterID: "fixture.camera")
    let mot = ControllableMotionSensorAdapter(adapterID: "fixture.motion")
    let streams = try await collectDeviceStreams(camera: cam, motion: mot)
    let dir = try tempDir("device-pkg")
    let pkg = try DeviceRGBMotionPackageBuilder().seal(
      camera: streams.cam,
      motion: streams.mot,
      cameraCapability: cam.capability,
      motionCapability: mot.capability,
      frames: frames(),
      clockCorrelations: correlations(),
      outputDirectory: dir
    )
    XCTAssertEqual(pkg.manifest.packageID, "SPKG-FIXTURE-RGBMOTION-000001")
    XCTAssertEqual(pkg.manifest.vehicleID, "VEH-000001")
    XCTAssertEqual(pkg.manifest.pilotID, "PILOT-000001")
    XCTAssertEqual(pkg.manifest.captureSessionID, "SESS-FIXTURE-RGBMOTION-000001")
    XCTAssertFalse(pkg.manifest.artifacts.contains { $0.streamID == "depth" || $0.streamID == "pose" })
    let depth = pkg.manifest.capability.streams.first { $0.streamID == "depth" }
    let pose = pkg.manifest.capability.streams.first { $0.streamID == "pose" }
    XCTAssertEqual(depth?.declared, false)
    XCTAssertEqual(depth?.finalOutcome, .notRequested)
    XCTAssertEqual(pose?.declared, false)
    XCTAssertEqual(pose?.finalOutcome, .notRequested)
    let camera = pkg.manifest.capability.streams.first { $0.streamID == "camera" }
    let motion = pkg.manifest.capability.streams.first { $0.streamID == "motion" }
    XCTAssertEqual(camera?.finalOutcome, .acquired)
    XCTAssertEqual(motion?.finalOutcome, .acquired)
    XCTAssertTrue(camera?.observed ?? false)
    XCTAssertTrue(motion?.observed ?? false)
    // Layout files
    for name in [
      "manifest.json", "sample_index.json", "capability_snapshot.json",
      "coordinate_frames.json", "clock_correlation.json", "package_inventory.json",
    ] {
      XCTAssertTrue(FileManager.default.fileExists(atPath: dir.appendingPathComponent(name).path))
    }
  }

  func testMissingCameraArtifact() async throws {
    let pkg = try await sealDevice()
    let victim = pkg.manifest.artifacts.first { $0.streamID == "camera" }!
    try FileManager.default.removeItem(at: pkg.rootURL.appendingPathComponent(victim.relativePath))
    XCTAssertThrowsError(
      try SpatialPackageClosureVerifier.verifyDevicePayload(
        packageRoot: pkg.rootURL,
        manifestArtifacts: pkg.manifest.artifacts
      )
    ) { err in
      guard case SpatialEvidenceError.missingArtifact = err else { return XCTFail("\(err)") }
    }
  }

  func testMissingMotionArtifact() async throws {
    let pkg = try await sealDevice()
    let victim = pkg.manifest.artifacts.first { $0.streamID == "motion" }!
    try FileManager.default.removeItem(at: pkg.rootURL.appendingPathComponent(victim.relativePath))
    XCTAssertThrowsError(
      try SpatialPackageClosureVerifier.verifyDevicePayload(
        packageRoot: pkg.rootURL,
        manifestArtifacts: pkg.manifest.artifacts
      )
    ) { err in
      guard case SpatialEvidenceError.missingArtifact = err else { return XCTFail("\(err)") }
    }
  }

  func testArtifactHashMismatch() async throws {
    let pkg = try await sealDevice()
    let victim = pkg.manifest.artifacts[0]
    try Data([9, 9, 9, 9]).write(to: pkg.rootURL.appendingPathComponent(victim.relativePath))
    XCTAssertThrowsError(
      try SpatialPackageClosureVerifier.verifyDevicePayload(
        packageRoot: pkg.rootURL,
        manifestArtifacts: pkg.manifest.artifacts
      )
    ) { err in
      guard case SpatialEvidenceError.byteLengthMismatch = err else {
        // length changed — also acceptable as mismatch class
        if case SpatialEvidenceError.sha256Mismatch = err { return }
        return XCTFail("\(err)")
      }
    }
  }

  func testOrphanPayload() async throws {
    let pkg = try await sealDevice()
    let orphan = pkg.rootURL.appendingPathComponent("payload/camera/orphan.bin")
    try Data([1]).write(to: orphan)
    XCTAssertThrowsError(
      try SpatialPackageClosureVerifier.verifyDevicePayload(
        packageRoot: pkg.rootURL,
        manifestArtifacts: pkg.manifest.artifacts
      )
    ) { err in
      guard case SpatialEvidenceError.orphanArtifact = err else { return XCTFail("\(err)") }
    }
  }

  func testCustodyChangesDoNotMutatePackageBytes() async throws {
    let pkg = try await sealDevice()
    let before = try Data(contentsOf: pkg.rootURL.appendingPathComponent("manifest.json"))
    let store = EvidenceCustodyStore()
    var rec = try store.registerSealedPackage(pkg)
    rec = try store.verifyClosure(packageContentSHA256: pkg.packageContentSHA256, expectedRevision: rec.revision)
    _ = try store.archive(packageContentSHA256: pkg.packageContentSHA256, expectedRevision: rec.revision)
    let after = try Data(contentsOf: pkg.rootURL.appendingPathComponent("manifest.json"))
    XCTAssertEqual(before, after)
    let rehash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: pkg.rootURL)
    XCTAssertEqual(rehash, pkg.packageContentSHA256)
  }

  func testVerifiedHandleCannotIssueBeforeVerification() async throws {
    let pkg = try await sealDevice()
    let store = EvidenceCustodyStore()
    _ = try store.registerSealedPackage(pkg)
    XCTAssertThrowsError(try store.verifiedPackage(packageContentSHA256: pkg.packageContentSHA256))
  }

  func testStaleCustodyOCC() async throws {
    let pkg = try await sealDevice()
    let store = EvidenceCustodyStore()
    let rec = try store.registerSealedPackage(pkg)
    XCTAssertThrowsError(
      try store.commit(packageContentSHA256: pkg.packageContentSHA256, expectedRevision: 0) { $0.status = .verified }
    ) { err in
      guard case SpatialEvidenceError.custodyStaleRevision = err else { return XCTFail("\(err)") }
    }
    XCTAssertEqual(store.record(packageContentSHA256: pkg.packageContentSHA256)?.revision, rec.revision)
    XCTAssertEqual(store.record(packageContentSHA256: pkg.packageContentSHA256)?.status, .unverified)
  }

  func testAppleAdaptersUnavailableOnLinuxHost() async {
    #if !canImport(AVFoundation)
    let cam = AppleProductionCameraSensorAdapter()
    do {
      try await cam.start()
      XCTFail("expected blocked")
    } catch let ProductionSensorError.unavailable(s) {
      XCTAssertTrue(s.contains("BLOCKED_HOST_CAPABILITY"))
    } catch {
      XCTFail("\(error)")
    }
    #endif
    #if !canImport(CoreMotion)
    let mot = AppleProductionMotionSensorAdapter()
    do {
      try await mot.start()
      XCTFail("expected blocked")
    } catch let ProductionSensorError.unavailable(s) {
      XCTAssertTrue(s.contains("BLOCKED_HOST_CAPABILITY"))
    } catch {
      XCTFail("\(error)")
    }
    #endif
  }

  func testWriteDeviceGoldenWhenRequested() async throws {
    guard ProcessInfo.processInfo.environment["PHASE31_WRITE_GOLDEN"] == "1" else {
      throw XCTSkip("Set PHASE31_WRITE_GOLDEN=1 to emit device package fixture")
    }
    let out = ProcessInfo.processInfo.environment["PHASE31_GOLDEN_OUT"].flatMap {
      $0.isEmpty ? nil : URL(fileURLWithPath: $0, isDirectory: true)
    } ?? URL(fileURLWithPath: #file)
      .deletingLastPathComponent().deletingLastPathComponent()
      .appendingPathComponent("Docs/Evidence/SPRINT_3_1/SPKG-FIXTURE-RGBMOTION-000001", isDirectory: true)
    try? FileManager.default.removeItem(at: out)
    let pkg = try await sealDevice(dirName: "golden-device")
    try FileManager.default.createDirectory(at: out.deletingLastPathComponent(), withIntermediateDirectories: true)
    try FileManager.default.copyItem(at: pkg.rootURL, to: out)
    let closure = try XCTUnwrap(pkg.packageClosureSHA256)
    let inv: [String: Any] = [
      "schema_id": "Sprint31FixturePackageInventory",
      "schema_version": "1.0.0",
      "fixture_payload_content_sha256": pkg.packageContentSHA256,
      "fixture_manifest_sha256": pkg.manifestSHA256,
      "fixture_package_closure_sha256": closure,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "package_id": pkg.manifest.packageID,
      "note": "Controllable Foundation adapters on Linux — fixture-only; no physical-device claim; authority=TEST_FIXTURE. fixture_payload_content_sha256 = manifest identity + artifact descriptors only.",
      "host_claim": "NO_PHYSICAL_DEVICE_EXECUTION",
    ]
    try CanonicalJSON.data(inv).write(
      to: out.deletingLastPathComponent().appendingPathComponent("fixture_package_inventory.json"),
      options: .atomic
    )
  }

  // MARK: - helpers

  private func sealDevice(dirName: String = UUID().uuidString) async throws -> SpatialEvidencePackage {
    let cam = ControllableCameraSensorAdapter(adapterID: "fixture.camera")
    let mot = ControllableMotionSensorAdapter(adapterID: "fixture.motion")
    let streams = try await collectDeviceStreams(camera: cam, motion: mot)
    return try DeviceRGBMotionPackageBuilder().seal(
      camera: streams.cam,
      motion: streams.mot,
      cameraCapability: cam.capability,
      motionCapability: mot.capability,
      frames: frames(),
      clockCorrelations: correlations(),
      outputDirectory: try tempDir(dirName)
    )
  }
}
