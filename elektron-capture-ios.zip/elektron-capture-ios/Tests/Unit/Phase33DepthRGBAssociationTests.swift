import XCTest
@testable import ElektronCapture

final class Phase33DepthRGBAssociationTests: XCTestCase {
  private func tempDir(_ name: String = UUID().uuidString) throws -> URL {
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("p33-\(name)", isDirectory: true)
    try? FileManager.default.removeItem(at: url)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  private func collectCameraDepth(
    camera: ControllableCameraSensorAdapter = ControllableCameraSensorAdapter(),
    depth: ControllableDepthSensorAdapter = ControllableDepthSensorAdapter()
  ) async throws -> (
    cam: [SpatialSampleEnvelope<CameraSample>],
    depth: [SpatialSampleEnvelope<DepthSample>],
    camera: ControllableCameraSensorAdapter,
    depthAdapter: ControllableDepthSensorAdapter
  ) {
    camera.clockDomain = .fixtureCamera
    camera.coordinateFrameID = "FRAME_CAMERA_OPTICAL"
    depth.clockDomain = .fixtureDepth
    try await camera.start()
    try await depth.start()
    var cams: [SpatialSampleEnvelope<CameraSample>] = []
    var depths: [SpatialSampleEnvelope<DepthSample>] = []
    for try await s in camera.samples() { cams.append(s) }
    for try await s in depth.samples() { depths.append(s) }
    await camera.stop()
    await depth.stop()
    return (cams, depths, camera, depth)
  }

  private func sealPrimary(dirName: String = UUID().uuidString) async throws -> SpatialEvidencePackage {
    let streams = try await collectCameraDepth()
    let correlations = FixtureCameraDepthPackageBuilder.defaultClockCorrelations()
    let associations = try FixtureCameraDepthPackageBuilder.defaultAssociations(
      camera: streams.cam,
      depth: streams.depth,
      correlations: correlations
    )
    return try FixtureCameraDepthPackageBuilder().seal(
      camera: streams.cam,
      depth: streams.depth,
      cameraCapability: streams.camera.capability,
      depthCapability: streams.depthAdapter.capability,
      frames: FixtureCameraDepthPackageBuilder.defaultFrames(),
      transformEdges: FixtureCameraDepthPackageBuilder.defaultTransformEdges(),
      clockCorrelations: correlations,
      calibrations: [FixtureCameraDepthPackageBuilder.defaultCalibration()],
      associations: associations,
      outputDirectory: try tempDir(dirName)
    )
  }

  // MARK: - Depth sample integrity

  func testValidDepthSampleAccepted() throws {
    let bytes = FixtureDepthPayload.deterministicBytes()
    let sample = makeDepth(bytes: bytes)
    try DepthSampleValidator.validate(sample)
  }

  func testZeroWidthRejected() {
    var s = makeDepth(bytes: FixtureDepthPayload.deterministicBytes())
    s = DepthSample(
      width: 0, height: s.height, bytes: s.bytes, sourceKind: s.sourceKind, pixelFormat: s.pixelFormat,
      byteOrder: s.byteOrder, rowStrideBytes: s.rowStrideBytes, depthUnit: s.depthUnitEnum,
      minimumValidDepth: s.minimumValidDepth, maximumValidDepth: s.maximumValidDepth,
      invalidValueEncoding: s.invalidValueEncoding, depthArtifactID: s.depthArtifactID,
      calibrationID: s.calibrationID, confidenceArtifactID: nil, validityArtifactID: nil,
      confidenceAbsenceReason: s.confidenceAbsenceReason, validityAbsenceReason: s.validityAbsenceReason,
      timestampNanoseconds: s.timestampNanoseconds, clockDomain: s.clockDomain,
      coordinateFrameID: s.coordinateFrameID, frameEpochID: s.frameEpochID, sessionRunID: s.sessionRunID,
      worldOriginRevision: s.worldOriginRevision, evidenceOriginAuthority: s.evidenceOriginAuthority,
      depthEstimateAuthority: s.depthEstimateAuthority, adapterID: s.adapterID
    )
    XCTAssertThrowsError(try DepthSampleValidator.validate(s))
  }

  func testZeroHeightRejected() {
    let s = mutatedDepth(width: FixtureDepthPayload.width, height: 0)
    XCTAssertThrowsError(try DepthSampleValidator.validate(s))
  }

  func testInvalidRowStrideRejected() {
    let s = mutatedDepth(rowStride: 1)
    XCTAssertThrowsError(try DepthSampleValidator.validate(s))
  }

  func testNegativeDepthRejectedWhenNotSentinelPolicy() throws {
    var bytes = Data()
    var neg = Float(-2.0).bitPattern.littleEndian
    withUnsafeBytes(of: &neg) { bytes.append(contentsOf: $0) }
    while bytes.count < FixtureDepthPayload.expectedByteLength() { bytes.append(0) }
    let s = makeDepth(bytes: bytes, encoding: .noneDeclared, minV: 0.1, maxV: 10)
    XCTAssertThrowsError(try DepthSampleValidator.validate(s))
  }

  func testInfinityRejected() {
    var bytes = Data()
    var inf = Float.infinity.bitPattern.littleEndian
    withUnsafeBytes(of: &inf) { bytes.append(contentsOf: $0) }
    while bytes.count < FixtureDepthPayload.expectedByteLength() { bytes.append(0) }
    let s = makeDepth(bytes: bytes)
    XCTAssertThrowsError(try DepthSampleValidator.validate(s))
  }

  func testNaNRejectedUnlessDeclared() {
    var bytes = Data()
    var nan = Float.nan.bitPattern.littleEndian
    withUnsafeBytes(of: &nan) { bytes.append(contentsOf: $0) }
    while bytes.count < FixtureDepthPayload.expectedByteLength() { bytes.append(0) }
    let s = makeDepth(bytes: bytes, encoding: .noneDeclared)
    XCTAssertThrowsError(try DepthSampleValidator.validate(s))
  }

  func testTruncatedArtifactRejected() {
    let s = makeDepth(bytes: Data(count: 8))
    XCTAssertThrowsError(try DepthSampleValidator.validate(s))
  }

  func testArtifactHashMismatchRejected() {
    let s = makeDepth(bytes: FixtureDepthPayload.deterministicBytes())
    XCTAssertThrowsError(try DepthSampleValidator.validate(s, expectedArtifactSHA: "00"))
  }

  // MARK: - Calibration

  func testValidCalibrationAccepted() throws {
    try DepthCalibrationValidator.validate(FixtureCameraDepthPackageBuilder.defaultCalibration())
  }

  func testCalibrationDimensionMismatchRejected() async throws {
    let streams = try await collectCameraDepth()
    var cal = FixtureCameraDepthPackageBuilder.defaultCalibration()
    cal = DepthCalibration(
      calibrationID: cal.calibrationID,
      depthWidth: 99,
      depthHeight: cal.depthHeight,
      cameraReferenceWidth: cal.cameraReferenceWidth,
      cameraReferenceHeight: cal.cameraReferenceHeight,
      intrinsicsMatrix: cal.intrinsicsMatrix,
      focalLengthX: cal.focalLengthX,
      focalLengthY: cal.focalLengthY,
      principalPointX: cal.principalPointX,
      principalPointY: cal.principalPointY,
      depthFrameID: cal.depthFrameID,
      cameraFrameID: cal.cameraFrameID,
      depthToCameraTransformID: cal.depthToCameraTransformID,
      frameEpochID: cal.frameEpochID,
      sessionRunID: cal.sessionRunID,
      worldOriginRevision: cal.worldOriginRevision
    )
    XCTAssertThrowsError(
      try DepthCalibrationValidator.validate(cal, depthSample: streams.depth[0].payload)
    )
  }

  func testNonFiniteIntrinsicsRejected() {
    var cal = FixtureCameraDepthPackageBuilder.defaultCalibration()
    var m = cal.intrinsicsMatrix
    m[0] = .nan
    cal = DepthCalibration(
      calibrationID: cal.calibrationID,
      depthWidth: cal.depthWidth,
      depthHeight: cal.depthHeight,
      cameraReferenceWidth: cal.cameraReferenceWidth,
      cameraReferenceHeight: cal.cameraReferenceHeight,
      intrinsicsMatrix: m,
      focalLengthX: cal.focalLengthX,
      focalLengthY: cal.focalLengthY,
      principalPointX: cal.principalPointX,
      principalPointY: cal.principalPointY,
      depthFrameID: cal.depthFrameID,
      cameraFrameID: cal.cameraFrameID,
      depthToCameraTransformID: cal.depthToCameraTransformID,
      frameEpochID: cal.frameEpochID,
      sessionRunID: cal.sessionRunID,
      worldOriginRevision: cal.worldOriginRevision
    )
    XCTAssertThrowsError(try DepthCalibrationValidator.validate(cal))
  }

  func testCrossEpochCalibrationRejected() {
    let cal = FixtureCameraDepthPackageBuilder.defaultCalibration()
    XCTAssertThrowsError(
      try DepthCalibrationValidator.validate(
        cal,
        packageFrameEpochID: "other-epoch",
        packageSessionRunID: cal.sessionRunID,
        packageWorldOriginRevision: cal.worldOriginRevision
      )
    )
  }

  // MARK: - RGB/depth association

  func testValidAssociationPackageSeals() async throws {
    let pkg = try await sealPrimary(dirName: "assoc-ok")
    XCTAssertEqual(pkg.manifest.packageID, FixtureCameraDepthPackageBuilder.primaryPackageID)
    XCTAssertNotNil(pkg.packageClosureSHA256)
    XCTAssertFalse(FileManager.default.fileExists(
      atPath: pkg.rootURL.appendingPathComponent("payload/motion").path
    ))
    XCTAssertFalse(FileManager.default.fileExists(
      atPath: pkg.rootURL.appendingPathComponent("payload/pose").path
    ))
  }

  func testMissingCorrelationRejected() async throws {
    let streams = try await collectCameraDepth()
    let badCorr = [
      ClockCorrelation(
        correlationID: "wrong-id",
        sourceDomain: .fixtureCamera,
        destinationDomain: .fixtureDepth,
        offsetNanoseconds: 0,
        authority: "TEST_FIXTURE"
      ),
    ]
    XCTAssertThrowsError(
      try FixtureCameraDepthPackageBuilder.defaultAssociations(
        camera: streams.cam,
        depth: streams.depth,
        correlations: badCorr
      )
    )
  }

  func testDuplicateAssociationRejected() async throws {
    let streams = try await collectCameraDepth()
    let corrs = FixtureCameraDepthPackageBuilder.defaultClockCorrelations()
    var assocs = try FixtureCameraDepthPackageBuilder.defaultAssociations(
      camera: streams.cam, depth: streams.depth, correlations: corrs
    )
    assocs.append(assocs[0])
    XCTAssertThrowsError(
      try FixtureCameraDepthPackageBuilder().seal(
        camera: streams.cam,
        depth: streams.depth,
        cameraCapability: streams.camera.capability,
        depthCapability: streams.depthAdapter.capability,
        frames: FixtureCameraDepthPackageBuilder.defaultFrames(),
        transformEdges: FixtureCameraDepthPackageBuilder.defaultTransformEdges(),
        clockCorrelations: corrs,
        calibrations: [FixtureCameraDepthPackageBuilder.defaultCalibration()],
        associations: assocs,
        outputDirectory: try tempDir("dup-assoc")
      )
    )
  }

  func testCrossEpochAssociationRejected() async throws {
    let streams = try await collectCameraDepth()
    let corrs = FixtureCameraDepthPackageBuilder.defaultClockCorrelations()
    var assocs = try FixtureCameraDepthPackageBuilder.defaultAssociations(
      camera: streams.cam, depth: streams.depth, correlations: corrs
    )
    let a = assocs[0]
    assocs[0] = RGBDepthAssociationRecord(
      associationID: a.associationID,
      cameraSampleID: a.cameraSampleID,
      depthSampleID: a.depthSampleID,
      cameraClockDomain: a.cameraClockDomain,
      depthClockDomain: a.depthClockDomain,
      correlationID: a.correlationID,
      associationTimestampNanoseconds: a.associationTimestampNanoseconds,
      timestampDifferenceNanoseconds: a.timestampDifferenceNanoseconds,
      calibrationID: a.calibrationID,
      cameraFrameID: a.cameraFrameID,
      depthFrameID: a.depthFrameID,
      transformID: a.transformID,
      frameEpochID: "epoch-other",
      sessionRunID: a.sessionRunID,
      worldOriginRevision: a.worldOriginRevision
    )
    XCTAssertThrowsError(
      try FixtureCameraDepthPackageBuilder().seal(
        camera: streams.cam,
        depth: streams.depth,
        cameraCapability: streams.camera.capability,
        depthCapability: streams.depthAdapter.capability,
        frames: FixtureCameraDepthPackageBuilder.defaultFrames(),
        transformEdges: FixtureCameraDepthPackageBuilder.defaultTransformEdges(),
        clockCorrelations: corrs,
        calibrations: [FixtureCameraDepthPackageBuilder.defaultCalibration()],
        associations: assocs,
        outputDirectory: try tempDir("cross-epoch")
      )
    )
  }

  // MARK: - Capability truth

  func testNotRequestedDistinctFromUnavailableDevice() throws {
    try DepthCapabilityTruthValidator.assertNotRequestedDistinctFromUnavailableDevice(
      notRequested: .notRequested,
      unavailableDevice: .unavailableDevice
    )
  }

  func testUnavailableDeviceProducesNoDepthEvidence() async throws {
    let cam = ControllableCameraSensorAdapter()
    cam.clockDomain = .fixtureCamera
    try await cam.start()
    var cams: [SpatialSampleEnvelope<CameraSample>] = []
    for try await s in cam.samples() { cams.append(s) }
    await cam.stop()

    let depthCap = SpatialStreamCapability(
      streamID: SpatialStreamID.depth,
      adapterID: "none",
      sensorKind: "depth",
      declared: true
    )
    let pkg = try FixtureNonLidarDepthPackageBuilder().seal(
      camera: cams,
      cameraCapability: cam.capability,
      depthCapability: depthCap,
      frames: FixtureNonLidarDepthPackageBuilder.defaultFrames(),
      clockCorrelations: [],
      outputDirectory: try tempDir("nonlidar")
    )
    XCTAssertEqual(pkg.manifest.packageID, FixtureNonLidarDepthPackageBuilder.packageID)
    XCTAssertFalse(FileManager.default.fileExists(
      atPath: pkg.rootURL.appendingPathComponent("payload/depth").path
    ))
    let capData = try Data(contentsOf: pkg.rootURL.appendingPathComponent("capability_snapshot.json"))
    let capObj = try JSONSerialization.jsonObject(with: capData) as! [String: Any]
    let streams = capObj["streams"] as! [[String: Any]]
    let depthStream = streams.first { ($0["stream_id"] as? String) == "depth" }!
    XCTAssertEqual(depthStream["final_outcome"] as? String, "UNAVAILABLE_DEVICE")
    let motion = streams.first { ($0["stream_id"] as? String) == "motion" }!
    XCTAssertEqual(motion["final_outcome"] as? String, "NOT_REQUESTED")
  }

  func testDepthActivationFailedDoesNotClaimAcquisition() async {
    let depth = ControllableDepthSensorAdapter()
    depth.failOnStart = true
    do {
      try await depth.start()
      XCTFail("expected activation failure")
    } catch {
      XCTAssertEqual(depth.capability.samplesAcquired, 0)
      XCTAssertNotEqual(depth.capability.finalOutcome, .acquired)
    }
  }

  func testAppleDepthAdapterUncompiledOnLinux() async {
    #if !canImport(ARKit)
    let adapter = AppleARKitDepthSensorAdapter()
    do {
      try await adapter.start()
      XCTFail("expected uncompiled")
    } catch let ProductionSensorError.unavailable(s) {
      XCTAssertTrue(s.contains("APPLE_DEPTH_SOURCE_CANDIDATE_UNCOMPILED"), s)
    } catch {
      XCTFail("\(error)")
    }
    #endif
  }

  // MARK: - Package integrity / digests

  func testCapabilityStandaloneMatchesEmbedded() async throws {
    let pkg = try await sealPrimary(dirName: "cap-agree")
    let stand = try Data(contentsOf: pkg.rootURL.appendingPathComponent("capability_snapshot.json"))
    let manifest = try Data(contentsOf: pkg.rootURL.appendingPathComponent("manifest.json"))
    let standObj = try JSONSerialization.jsonObject(with: stand) as! [String: Any]
    let manObj = try JSONSerialization.jsonObject(with: manifest) as! [String: Any]
    let embedded = manObj["capability"] as! [String: Any]
    XCTAssertEqual(standObj["schema_version"] as? String, "1.0.0-phase3-fixture")
    XCTAssertEqual(embedded["schema_version"] as? String, "1.0.0-phase3-fixture")
    XCTAssertEqual(standObj["snapshot_id"] as? String, embedded["snapshot_id"] as? String)
  }

  func testInventoryReorderDoesNotChangeClosure() async throws {
    let pkg = try await sealPrimary(dirName: "closure-reorder")
    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: pkg.rootURL)
    let h1 = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    let h2 = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: Array(entries.reversed()))
    XCTAssertEqual(h1, h2)
    XCTAssertEqual(h1, pkg.packageClosureSHA256)
  }

  func testMetadataMutationChangesClosureNotPayload() async throws {
    let pkg = try await sealPrimary(dirName: "meta-mut")
    let payloadBefore = pkg.packageContentSHA256
    let closureBefore = try XCTUnwrap(pkg.packageClosureSHA256)
    let url = pkg.rootURL.appendingPathComponent("capability_snapshot.json")
    var data = try Data(contentsOf: url)
    data.append(0x0A)
    try data.write(to: url, options: .atomic)
    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: pkg.rootURL)
    let refreshed = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    try CanonicalJSON.data([
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": pkg.manifest.packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": refreshed,
      "entries": entries,
    ] as [String: Any]).write(to: pkg.rootURL.appendingPathComponent("package_inventory.json"), options: .atomic)
    let payloadAfter = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: pkg.rootURL)
    let closureAfter = try SpatialPackageClosureVerifier.issueInventoryClosureDigest(packageRoot: pkg.rootURL)
    XCTAssertEqual(payloadAfter, payloadBefore)
    XCTAssertNotEqual(closureAfter, closureBefore)
  }

  func testAbsolutePathsRejectedInClosureInput() {
    XCTAssertThrowsError(
      try SpatialPackageClosureVerifier.inventoryClosureHash(entries: [
        ["relative_path": "/tmp/x.bin", "byte_length": 1, "sha256": "aa"],
      ])
    )
  }

  func testDeterministicPrimaryPackageBytes() async throws {
    let a = try await sealPrimary(dirName: "det-a")
    let b = try await sealPrimary(dirName: "det-b")
    XCTAssertEqual(a.packageContentSHA256, b.packageContentSHA256)
    XCTAssertEqual(a.manifestSHA256, b.manifestSHA256)
    XCTAssertEqual(a.packageClosureSHA256, b.packageClosureSHA256)
  }

  func testWriteDepthGoldenWhenRequested() async throws {
    guard ProcessInfo.processInfo.environment["PHASE33_WRITE_GOLDEN"] == "1" else {
      throw XCTSkip("Set PHASE33_WRITE_GOLDEN=1 to emit depth package fixtures")
    }
    let outRoot = ProcessInfo.processInfo.environment["PHASE33_GOLDEN_OUT"].flatMap {
      $0.isEmpty ? nil : URL(fileURLWithPath: $0, isDirectory: true)
    } ?? URL(fileURLWithPath: #file)
      .deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
      .appendingPathComponent("Docs/Evidence/SPRINT_3_3", isDirectory: true)

    // Primary
    let primaryOut = outRoot.appendingPathComponent(
      FixtureCameraDepthPackageBuilder.primaryPackageID, isDirectory: true
    )
    try? FileManager.default.removeItem(at: primaryOut)
    let primary = try await sealPrimary(dirName: "golden-primary")
    try FileManager.default.createDirectory(at: outRoot, withIntermediateDirectories: true)
    try FileManager.default.copyItem(at: primary.rootURL, to: primaryOut)
    let primaryClosure = try XCTUnwrap(primary.packageClosureSHA256)
    try CanonicalJSON.data([
      "schema_id": "Sprint33FixturePackageInventory",
      "schema_version": "1.0.0",
      "package_id": primary.manifest.packageID,
      "capture_session_id": primary.manifest.captureSessionID,
      "fixture_payload_content_sha256": primary.packageContentSHA256,
      "fixture_manifest_sha256": primary.manifestSHA256,
      "fixture_package_closure_sha256": primaryClosure,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "adapter_id": "fixture.depth",
      "evidence_origin_authority": "TEST_FIXTURE",
      "depth_estimate_authority": "GUIDANCE_ESTIMATE",
      "host_claim": "NO_PHYSICAL_DEVICE_EXECUTION",
      "note": "Primary camera+depth fixture; motion/pose NOT_REQUESTED",
    ] as [String: Any]).write(
      to: outRoot.appendingPathComponent("camera_depth_package_inventory.json"),
      options: .atomic
    )

    // Non-LiDAR
    let cam = ControllableCameraSensorAdapter()
    cam.clockDomain = .fixtureCamera
    try await cam.start()
    var cams: [SpatialSampleEnvelope<CameraSample>] = []
    for try await s in cam.samples() { cams.append(s) }
    await cam.stop()
    let nonOut = outRoot.appendingPathComponent(
      FixtureNonLidarDepthPackageBuilder.packageID, isDirectory: true
    )
    try? FileManager.default.removeItem(at: nonOut)
    let depthCap = SpatialStreamCapability(
      streamID: SpatialStreamID.depth,
      adapterID: "none",
      sensorKind: "depth",
      declared: true
    )
    let non = try FixtureNonLidarDepthPackageBuilder().seal(
      camera: cams,
      cameraCapability: cam.capability,
      depthCapability: depthCap,
      frames: FixtureNonLidarDepthPackageBuilder.defaultFrames(),
      clockCorrelations: [],
      outputDirectory: try tempDir("golden-nonlidar")
    )
    try FileManager.default.copyItem(at: non.rootURL, to: nonOut)
    let nonClosure = try XCTUnwrap(non.packageClosureSHA256)
    try CanonicalJSON.data([
      "schema_id": "Sprint33NonLidarFixturePackageInventory",
      "schema_version": "1.0.0",
      "package_id": non.manifest.packageID,
      "capture_session_id": non.manifest.captureSessionID,
      "fixture_payload_content_sha256": non.packageContentSHA256,
      "fixture_manifest_sha256": non.manifestSHA256,
      "fixture_package_closure_sha256": nonClosure,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "depth_outcome": "UNAVAILABLE_DEVICE",
      "host_claim": "NO_PHYSICAL_DEVICE_EXECUTION",
      "note": "Camera-capable non-LiDAR fixture; depth UNAVAILABLE_DEVICE with no depth evidence",
    ] as [String: Any]).write(
      to: outRoot.appendingPathComponent("nonlidar_depth_package_inventory.json"),
      options: .atomic
    )
  }

  // MARK: - helpers

  private func makeDepth(
    bytes: Data,
    encoding: DepthInvalidValueEncoding = .negativeSentinel,
    minV: Double = 0.1,
    maxV: Double = 10.0,
    rowStride: Int = FixtureDepthPayload.rowStrideBytes,
    width: Int = FixtureDepthPayload.width,
    height: Int = FixtureDepthPayload.height
  ) -> DepthSample {
    DepthSample(
      width: width,
      height: height,
      bytes: bytes,
      sourceKind: .fixture,
      pixelFormat: .float32Meters,
      byteOrder: FixtureDepthPayload.byteOrder,
      rowStrideBytes: rowStride,
      depthUnit: .meters,
      minimumValidDepth: minV,
      maximumValidDepth: maxV,
      invalidValueEncoding: encoding,
      depthArtifactID: "depth-artifact-0",
      calibrationID: FixtureCameraDepthPackageBuilder.calibrationID,
      confidenceArtifactID: nil,
      validityArtifactID: nil,
      confidenceAbsenceReason: "OPTIONAL_CONFIDENCE_NOT_EMITTED_BY_FIXTURE",
      validityAbsenceReason: "OPTIONAL_VALIDITY_NOT_EMITTED_BY_FIXTURE",
      timestampNanoseconds: 33_333_333,
      clockDomain: .fixtureDepth,
      coordinateFrameID: "FRAME_DEPTH_SENSOR",
      frameEpochID: FixtureCameraDepthPackageBuilder.frameEpochID,
      sessionRunID: FixtureCameraDepthPackageBuilder.sessionRunID,
      worldOriginRevision: FixtureCameraDepthPackageBuilder.worldOriginRevision,
      evidenceOriginAuthority: "TEST_FIXTURE",
      depthEstimateAuthority: "GUIDANCE_ESTIMATE",
      adapterID: "fixture.depth"
    )
  }

  private func mutatedDepth(width: Int? = nil, height: Int? = nil, rowStride: Int? = nil) -> DepthSample {
    makeDepth(
      bytes: FixtureDepthPayload.deterministicBytes(),
      rowStride: rowStride ?? FixtureDepthPayload.rowStrideBytes,
      width: width ?? FixtureDepthPayload.width,
      height: height ?? FixtureDepthPayload.height
    )
  }
}
