import XCTest
@testable import ElektronCapture

/// Sprint 2.1A — immutable plan assignment via `SessionPlanState` + `AssignedInspectionPlan`.
final class Sprint2_1ATests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_000_000)

  private func makeFactory(at instant: Date = Date(timeIntervalSince1970: 1_720_000_000))
    -> InspectionPlanSnapshotFactory
  {
    InspectionPlanSnapshotFactory(instantProvider: FixedInstantProvider(instant))
  }

  private func makeVehicle(_ raw: String = "FLEET-21A") throws -> InspectionVehicle {
    try InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: raw))
  }

  private func sessionEncoder() -> JSONEncoder {
    let enc = JSONEncoder()
    enc.dateEncodingStrategy = .iso8601
    enc.outputFormatting = [.sortedKeys]
    return enc
  }

  private func sessionDecoder() -> JSONDecoder {
    let dec = JSONDecoder()
    dec.dateDecodingStrategy = .iso8601
    return dec
  }

  private func encodeSession(_ session: InspectionSession) throws -> Data {
    try sessionEncoder().encode(session)
  }

  private func decodeSession(_ data: Data) throws -> InspectionSession {
    try sessionDecoder().decode(InspectionSession.self, from: data)
  }

  // MARK: - Assignment + accessors

  func testAssigningVerifiesDigestAndExposesAccessors() throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let snapshot = try makeFactory().makeSnapshot(from: plan)
    let session = try InspectionSession.assigning(
      id: SessionID.unchecked("INS-21A-1"),
      vehicle: makeVehicle(),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )

    XCTAssertTrue(session.planState.isAssigned)
    XCTAssertEqual(session.assignedPlan?.snapshot, snapshot)
    XCTAssertEqual(session.inspectionPlanSnapshot, snapshot)
    XCTAssertEqual(session.planID, snapshot.planID)
    XCTAssertEqual(session.planVersion, snapshot.planVersion)
    XCTAssertEqual(session.definitionDigest, snapshot.snapshotSHA256)
    XCTAssertEqual(session.assignedAt, fixedInstant)
    XCTAssertEqual(session.assignedPlan?.assignedAt, fixedInstant)
    XCTAssertEqual(session.definitionDigest?.count, 64)
  }

  func testDigestMismatchRejection() throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    var snapshot = try makeFactory().makeSnapshot(from: plan)
    snapshot = InspectionPlanSnapshot(
      payload: snapshot.payload,
      snapshotCreatedAt: snapshot.snapshotCreatedAt,
      snapshotSHA256: String(repeating: "0", count: 64),
      snapshotHashAlgorithm: snapshot.snapshotHashAlgorithm
    )
    XCTAssertThrowsError(
      try InspectionSession.assigning(
        id: SessionID.unchecked("INS-21A-BAD"),
        vehicle: makeVehicle(),
        inspector: .localDefault,
        startedAt: fixedInstant,
        planSnapshot: snapshot,
        assignedAt: fixedInstant
      )
    ) { err in
      guard case InspectionPlanError.hashMismatch = err else {
        return XCTFail("unexpected \(err)")
      }
    }
  }

  func testLegacyUnassignedHasNilPlanAccessors() throws {
    let session = try InspectionSession(
      id: SessionID.unchecked("INS-LEGACY"),
      vehicle: makeVehicle(),
      inspector: .localDefault,
      startedAt: fixedInstant
    )
    XCTAssertEqual(session.planState, .legacyUnassigned)
    XCTAssertNil(session.inspectionPlanSnapshot)
    XCTAssertNil(session.planID)
    XCTAssertNil(session.planVersion)
    XCTAssertNil(session.definitionDigest)
    XCTAssertNil(session.assignedAt)
  }

  // MARK: - Immutability / registry independence

  func testRegistryMutationDoesNotAffectSessionA() throws {
    let original = try InspectionPlan(
      id: "mutable_demo",
      version: "1.0.0",
      title: "Mutable Demo",
      descriptionText: "v1",
      points: [
        try InspectionPoint(
          id: "a",
          title: "A",
          displayOrder: 1,
          guidanceInstruction: "Stand 2m back"
        ),
        try InspectionPoint(id: "b", title: "B", displayOrder: 2, isRequired: false),
      ]
    )
    var registry = InspectionPlanRegistry(plans: [original])
    let planA = try registry.plan(id: "mutable_demo", version: "1.0.0")
    let snapshotA = try makeFactory(at: fixedInstant).makeSnapshot(from: planA)
    let sessionA = try InspectionSession.assigning(
      id: SessionID.unchecked("INS-A"),
      vehicle: makeVehicle("VIN-A"),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshotA,
      assignedAt: fixedInstant
    )
    let digestA = sessionA.definitionDigest
    let pointsA = sessionA.inspectionPlanSnapshot?.points.map(\.id.rawValue)
    let guidanceA = sessionA.inspectionPlanSnapshot?.points.first?.guidanceInstruction

    let mutated = try InspectionPlan(
      id: "mutable_demo",
      version: "1.0.0",
      title: "Mutable Demo CHANGED",
      descriptionText: "v1-mutated",
      points: [
        try InspectionPoint(id: "a", title: "A-changed", displayOrder: 1),
        try InspectionPoint(id: "b", title: "B", displayOrder: 2),
        try InspectionPoint(id: "c", title: "C-new", displayOrder: 3),
      ]
    )
    registry = InspectionPlanRegistry(plans: [mutated])
    let planB = try registry.plan(id: "mutable_demo", version: "1.0.0")
    let snapshotB = try makeFactory(at: Date(timeIntervalSince1970: 1_720_000_100))
      .makeSnapshot(from: planB)
    let sessionB = try InspectionSession.assigning(
      id: SessionID.unchecked("INS-B"),
      vehicle: makeVehicle("VIN-B"),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshotB,
      assignedAt: Date(timeIntervalSince1970: 1_720_000_100)
    )

    // Session A keeps original snapshot after registry mutation.
    XCTAssertEqual(sessionA.definitionDigest, digestA)
    XCTAssertEqual(sessionA.inspectionPlanSnapshot?.points.map(\.id.rawValue), pointsA)
    XCTAssertEqual(sessionA.inspectionPlanSnapshot?.title, "Mutable Demo")
    XCTAssertEqual(sessionA.inspectionPlanSnapshot?.points.count, 2)
    XCTAssertEqual(guidanceA, "Stand 2m back")
    XCTAssertEqual(
      sessionA.inspectionPlanSnapshot?.points.map(\.isRequired),
      [true, false]
    )

    // Session B receives updated snapshot while Session A retains original.
    XCTAssertNotEqual(sessionB.definitionDigest, sessionA.definitionDigest)
    XCTAssertEqual(sessionB.inspectionPlanSnapshot?.title, "Mutable Demo CHANGED")
    XCTAssertEqual(sessionB.inspectionPlanSnapshot?.points.count, 3)
    XCTAssertEqual(sessionB.planID?.rawValue, "mutable_demo")
    XCTAssertEqual(sessionB.planVersion, "1.0.0")
  }

  func testSessionBGetsUpdatedSnapshotWhileSessionARetainsOriginal() throws {
    // Same guarantee as registry-mutation test; explicit blueprint name.
    try testRegistryMutationDoesNotAffectSessionA()
  }

  func testEqualCanonicalPlansProduceEqualDigests() throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let a = try makeFactory(at: fixedInstant).makeSnapshot(from: plan)
    let b = try makeFactory(at: Date(timeIntervalSince1970: 1_720_000_999))
      .makeSnapshot(from: plan)
    XCTAssertEqual(a.snapshotSHA256, b.snapshotSHA256)
    XCTAssertNotEqual(a.snapshotCreatedAt, b.snapshotCreatedAt)
  }

  func testChangedCanonicalPlanProducesChangedDigest() throws {
    let base = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let changed = try InspectionPlan(
      id: base.id,
      version: base.version,
      title: base.title,
      descriptionText: base.descriptionText,
      points: base.points.map { point in
        if point.id.rawValue == "front" {
          return InspectionPoint(
            id: point.id,
            title: "Front CHANGED",
            displayOrder: point.displayOrder,
            isRequired: point.isRequired,
            guidanceInstruction: point.guidanceInstruction,
            expectedEvidenceType: point.expectedEvidenceType
          )
        }
        return point
      }
    )
    let digestBase = try makeFactory().makeSnapshot(from: base).snapshotSHA256
    let digestChanged = try makeFactory().makeSnapshot(from: changed).snapshotSHA256
    XCTAssertNotEqual(digestBase, digestChanged)
  }

  func testPointOrderAndOptionalMetadataSurviveAssignment() throws {
    let plan = try InspectionPlan(
      id: "ordered_meta",
      version: "1.0.0",
      title: "Ordered",
      points: [
        try InspectionPoint(
          id: "first",
          title: "First",
          displayOrder: 1,
          guidanceInstruction: "Include bumper",
          expectedEvidenceType: .photo
        ),
        try InspectionPoint(
          id: "second",
          title: "Second",
          displayOrder: 2,
          isRequired: false,
          guidanceInstruction: nil,
          expectedEvidenceType: .multiPhoto
        ),
        try InspectionPoint(
          id: "third",
          title: "Third",
          displayOrder: 3,
          guidanceInstruction: "Wide angle",
          expectedEvidenceType: .document
        ),
      ]
    )
    let snapshot = try makeFactory().makeSnapshot(from: plan)
    let session = try InspectionSession.assigning(
      id: SessionID.unchecked("INS-ORDER"),
      vehicle: makeVehicle(),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )
    let points = try XCTUnwrap(session.inspectionPlanSnapshot?.points)
    XCTAssertEqual(points.map(\.id.rawValue), ["first", "second", "third"])
    XCTAssertEqual(points.map(\.displayOrder), [1, 2, 3])
    XCTAssertEqual(points[0].guidanceInstruction, "Include bumper")
    XCTAssertNil(points[1].guidanceInstruction)
    XCTAssertEqual(points[1].expectedEvidenceType, .multiPhoto)
    XCTAssertEqual(points[2].expectedEvidenceType, .document)
    XCTAssertFalse(points[1].isRequired)
  }

  func testSessionDoesNotRequireRegistryToDecode() throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let snapshot = try makeFactory().makeSnapshot(from: plan)
    let session = try InspectionSession.assigning(
      id: SessionID.unchecked("INS-NO-REG"),
      vehicle: makeVehicle(),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )
    let data = try encodeSession(session)
    let decoded = try decodeSession(data)
    XCTAssertEqual(decoded.definitionDigest, session.definitionDigest)
    XCTAssertEqual(decoded.inspectionPlanSnapshot?.points.count, 4)
    XCTAssertEqual(decoded.assignedAt, fixedInstant)
  }

  // MARK: - Codable round-trip

  func testCodableRoundTripPreservesSnapshotAndIdentity() throws {
    let plan = try InspectionPlanRegistry().plan(
      id: "standard_commercial_intake",
      version: "1.0.0"
    )
    let snapshot = try makeFactory().makeSnapshot(from: plan)
    let original = try InspectionSession.assigning(
      id: SessionID.unchecked("INS-RT-ASSIGNED"),
      vehicle: makeVehicle("1HGCM82633A004352"),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )
    let data1 = try encodeSession(original)
    let data2 = try encodeSession(original)
    XCTAssertEqual(data1, data2, "canonical re-encoding must be deterministic")
    let decoded = try decodeSession(data1)
    XCTAssertEqual(decoded, original)
    XCTAssertEqual(decoded.id, original.id)
    XCTAssertEqual(decoded.planID, original.planID)
    XCTAssertEqual(decoded.planVersion, original.planVersion)
    XCTAssertEqual(decoded.definitionDigest, original.definitionDigest)
    XCTAssertEqual(decoded.assignedAt, original.assignedAt)
    XCTAssertEqual(decoded.inspectionPlanSnapshot, snapshot)
    XCTAssertEqual(
      decoded.assignedPlan,
      AssignedInspectionPlan(snapshot: snapshot, assignedAt: fixedInstant)
    )
    let reencoded = try encodeSession(decoded)
    XCTAssertEqual(reencoded, data1)
  }

  func testLegacySessionDecodesToLegacyUnassigned() throws {
    let original = try InspectionSession(
      id: SessionID.unchecked("INS-RT-LEGACY"),
      vehicle: makeVehicle("LEGACY-1"),
      inspector: .localDefault,
      startedAt: fixedInstant,
      status: .inProgress,
      metrics: SessionMetrics(captureCount: 2)
    )
    let data = try encodeSession(original)
    let json = try XCTUnwrap(String(data: data, encoding: .utf8))
    XCTAssertFalse(json.contains("planState"), "legacy encode must omit planState; got \(json)")
    XCTAssertFalse(json.contains("inspectionPlanSnapshot"))
    XCTAssertFalse(json.contains("assignedAt"))
    let decoded = try decodeSession(data)
    XCTAssertEqual(decoded, original)
    XCTAssertEqual(decoded.planState, .legacyUnassigned)
    XCTAssertNil(decoded.assignedAt)
  }

  func testPre21JSONWithoutSnapshotDecodesAsLegacyUnassigned() throws {
    let json = """
      {
        "id": "INS-PRE-21",
        "vehicle": {
          "primaryIdentifier": { "rawValue": "OLD-1", "kind": "RAW_IDENTIFIER" },
          "vin": null,
          "licensePlate": null,
          "fleetNumber": null,
          "assetNumber": null,
          "make": null,
          "model": null,
          "year": null
        },
        "inspector": {
          "id": "INSPECTOR-LOCAL",
          "name": "Local Inspector",
          "organization": null,
          "role": "operator"
        },
        "startedAt": "2024-07-03T12:26:40Z",
        "status": "IN_PROGRESS",
        "metrics": { "captureCount": 0 }
      }
      """
    let decoded = try decodeSession(Data(json.utf8))
    XCTAssertEqual(decoded.planState, .legacyUnassigned)
    XCTAssertNil(decoded.inspectionPlanSnapshot)
    XCTAssertNil(decoded.assignedAt)
    XCTAssertEqual(decoded.id.rawValue, "INS-PRE-21")
  }

  func testDecodeRejectsTamperedAssignedSnapshot() throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let snapshot = try makeFactory().makeSnapshot(from: plan)
    let session = try InspectionSession.assigning(
      id: SessionID.unchecked("INS-TAMPER"),
      vehicle: makeVehicle(),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )
    var text = try XCTUnwrap(String(data: encodeSession(session), encoding: .utf8))
    text = text.replacingOccurrences(
      of: snapshot.snapshotSHA256,
      with: String(repeating: "a", count: 64)
    )
    XCTAssertThrowsError(try decodeSession(Data(text.utf8)))
  }

  // MARK: - Service creation path

  func testCreateSessionValidatesPlanSnapshotsAndAssigns() async throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let service = InspectionSessionService(
      repository: InMemoryCurrentSessionRepository(),
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("INS-CREATE-21A")),
      instantProvider: FixedInstantProvider(fixedInstant)
    )
    let created = try await service.createSession(
      vehicleIdentifierRaw: "UNIT-21A",
      inspectionPlan: plan,
      assignedAt: fixedInstant
    )
    XCTAssertEqual(created.id.rawValue, "INS-CREATE-21A")
    XCTAssertTrue(created.planState.isAssigned)
    XCTAssertEqual(created.planID?.rawValue, "quick_4_point")
    XCTAssertEqual(created.planVersion, "1.0.0")
    XCTAssertEqual(created.assignedAt, fixedInstant)
    XCTAssertEqual(created.definitionDigest?.count, 64)
    try InspectionPlanSnapshotHasher.verify(try XCTUnwrap(created.inspectionPlanSnapshot))
  }

  func testInvalidPlanRejection() async throws {
    let invalid = try InspectionPlan(
      id: "bad",
      version: "1.0",
      title: "Bad",
      points: [try InspectionPoint(id: "p", title: "P", displayOrder: 1)]
    )
    let service = InspectionSessionService(
      repository: InMemoryCurrentSessionRepository(),
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("INS-BAD")),
      instantProvider: FixedInstantProvider(fixedInstant)
    )
    do {
      _ = try await service.createSession(
        vehicleIdentifierRaw: "X",
        inspectionPlan: invalid,
        assignedAt: fixedInstant
      )
      XCTFail("expected rejection")
    } catch let e as InspectionPlanError {
      guard case .invalidSemanticVersion("1.0") = e else {
        return XCTFail("unexpected \(e)")
      }
    }
  }

  func testStartInspectionWithoutSnapshotRemainsLegacyUnassigned() async throws {
    let service = InspectionSessionService(
      repository: InMemoryCurrentSessionRepository(),
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("INS-SVC-LEGACY")),
      instantProvider: FixedInstantProvider(fixedInstant)
    )
    let created = try await service.startInspection(vehicleIdentifierRaw: "UNIT-LEGACY")
    XCTAssertEqual(created.planState, .legacyUnassigned)
    XCTAssertNil(created.assignedAt)
  }

  func testFileRepositoryRoundTripsAssignedSession() async throws {
    let plan = try InspectionPlanRegistry().plan(id: "quick_4_point", version: "1.0.0")
    let snapshot = try makeFactory().makeSnapshot(from: plan)
    let session = try InspectionSession.assigning(
      id: SessionID.unchecked("INS-FILE-21A"),
      vehicle: makeVehicle("FILE-1"),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("sess-21a-\(UUID().uuidString).json")
    let repo = FileCurrentSessionRepository(fileURL: url)
    let saved = try await repo.save(session, expectedRevision: 0)
    let loaded = try await repo.load()
    XCTAssertEqual(loaded, saved)
    XCTAssertEqual(saved.revision, 1)
    XCTAssertEqual(loaded?.definitionDigest, snapshot.snapshotSHA256)
    XCTAssertEqual(loaded?.assignedAt, fixedInstant)
  }
}
