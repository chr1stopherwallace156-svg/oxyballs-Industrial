import XCTest
@testable import ElektronCapture

/// Repair 02 — compiled coverage for `clearIfHolding(sessionID:)`.
///
/// PR #71 shipped this method with invalid optional chaining
/// (`guard let existing = try? … , existing?.id.rawValue == sessionID`) which failed to
/// compile on Mac. These tests execute the corrected implementation on **both** repository
/// conformances.
final class ClearIfHoldingTests: XCTestCase {
  private func tempURL() -> URL {
    FileManager.default.temporaryDirectory
      .appendingPathComponent("clearif-\(UUID().uuidString).json")
  }

  private func makeSession(_ id: String) throws -> InspectionSession {
    InspectionSession(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: try VehicleIdentifier(rawValue: "FLEET-\(id)")),
      inspector: .localDefault,
      startedAt: Date(timeIntervalSince1970: 1_700_000_000),
      status: .inProgress,
      planState: .legacyUnassigned
    )
  }

  // MARK: File-backed conformance

  func testClearIfHolding_matchingID_clearsAndReturnsTrue() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    _ = try await repo.save(try makeSession("INS-MATCH"), expectedRevision: 0)

    let cleared = try await repo.clearIfHolding(sessionID: "INS-MATCH")
    XCTAssertTrue(cleared)

    let after = try await repo.load()
    XCTAssertNil(after)
    XCTAssertFalse(FileManager.default.fileExists(atPath: url.path))
  }

  func testClearIfHolding_nonmatchingID_preservesAndReturnsFalse() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    _ = try await repo.save(try makeSession("INS-HELD"), expectedRevision: 0)
    let before = try Data(contentsOf: url)

    let cleared = try await repo.clearIfHolding(sessionID: "INS-OTHER")
    XCTAssertFalse(cleared)

    let after = try await repo.load()
    XCTAssertEqual(after?.id.rawValue, "INS-HELD")
    XCTAssertEqual(try Data(contentsOf: url), before, "a mismatched id must not touch the bytes")
  }

  func testClearIfHolding_emptySlot_returnsFalse() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)

    let cleared = try await repo.clearIfHolding(sessionID: "INS-ANY")
    XCTAssertFalse(cleared)
    XCTAssertFalse(FileManager.default.fileExists(atPath: url.path))
  }

  /// The slot holds one session at a time; clearing must be keyed on identity, so a request
  /// naming a different inspection can never retire the one that is actually held.
  func testClearIfHolding_neverClearsDifferentInspection() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    _ = try await repo.save(try makeSession("INS-A"), expectedRevision: 0)

    for wrongID in ["INS-B", "INS-C", "", "ins-a", "INS-A "] {
      let cleared = try await repo.clearIfHolding(sessionID: wrongID)
      XCTAssertFalse(cleared, "\(wrongID) must not clear INS-A")
      let still = try await repo.load()
      XCTAssertEqual(still?.id.rawValue, "INS-A")
    }

    let cleared = try await repo.clearIfHolding(sessionID: "INS-A")
    XCTAssertTrue(cleared)
  }

  // MARK: In-memory conformance

  func testClearIfHolding_inMemory_matchingID_clearsAndReturnsTrue() async throws {
    let repo = InMemoryCurrentSessionRepository()
    _ = try await repo.save(try makeSession("INS-MEM"), expectedRevision: 0)

    let cleared = try await repo.clearIfHolding(sessionID: "INS-MEM")
    XCTAssertTrue(cleared)
    let after = try await repo.load()
    XCTAssertNil(after)
  }

  func testClearIfHolding_inMemory_nonmatchingID_preservesAndReturnsFalse() async throws {
    let repo = InMemoryCurrentSessionRepository()
    _ = try await repo.save(try makeSession("INS-MEM"), expectedRevision: 0)

    let cleared = try await repo.clearIfHolding(sessionID: "INS-OTHER")
    XCTAssertFalse(cleared)
    let after = try await repo.load()
    XCTAssertEqual(after?.id.rawValue, "INS-MEM")
  }

  func testClearIfHolding_inMemory_emptySlot_returnsFalse() async throws {
    let repo = InMemoryCurrentSessionRepository()
    let cleared = try await repo.clearIfHolding(sessionID: "INS-ANY")
    XCTAssertFalse(cleared)
  }

  /// Both conformances must agree, so the behaviour cannot drift between test and production
  /// storage.
  func testClearIfHolding_bothConformancesAgree() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let file = FileCurrentSessionRepository(fileURL: url)
    let memory = InMemoryCurrentSessionRepository()
    let session = try makeSession("INS-PARITY")
    _ = try await file.save(session, expectedRevision: 0)
    _ = try await memory.save(session, expectedRevision: 0)

    let fileWrong = try await file.clearIfHolding(sessionID: "INS-NOPE")
    let memoryWrong = try await memory.clearIfHolding(sessionID: "INS-NOPE")
    XCTAssertEqual(fileWrong, memoryWrong)
    XCTAssertFalse(fileWrong)

    let fileRight = try await file.clearIfHolding(sessionID: "INS-PARITY")
    let memoryRight = try await memory.clearIfHolding(sessionID: "INS-PARITY")
    XCTAssertEqual(fileRight, memoryRight)
    XCTAssertTrue(fileRight)
  }
}
