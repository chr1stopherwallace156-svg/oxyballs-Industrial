import XCTest
@testable import ElektronCapture

/// Sprint 2.3 Mac build-gate repair — presentation-boundary for
/// `InspectionSessionViewModel.errorText` (`private(set)` + `presentError` / `clearError`).
///
/// ViewModel lives under `Apps/Phase1StillCapture` (Xcode app target). Package tests
/// prove the authorized mutation contract, identity-divergence fail-closed behavior,
/// and that app sources no longer assign `errorText` externally.
final class Sprint2_3_ErrorPresentationBoundaryTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_721_300_000)

  // MARK: - presentError / clearError publishing contract

  /// Mirrors InspectionSessionViewModel's authorized error surface (private(set) + methods).
  private final class ErrorSurfaceMirror {
    private(set) var errorText: String?
    private(set) var current: InspectionSession?

    func adoptForTest(_ session: InspectionSession) {
      current = session
    }

    func presentError(_ message: String) {
      errorText = message
    }

    func clearError() {
      errorText = nil
    }
  }

  func testPresentErrorPublishesSuppliedMessage() {
    let surface = ErrorSurfaceMirror()
    surface.presentError("Save & Exit sync error: session identity changed; staying on Capture.")
    XCTAssertEqual(
      surface.errorText,
      "Save & Exit sync error: session identity changed; staying on Capture."
    )
  }

  func testClearErrorRemovesMessage() {
    let surface = ErrorSurfaceMirror()
    surface.presentError("temporary")
    XCTAssertNotNil(surface.errorText)
    surface.clearError()
    XCTAssertNil(surface.errorText)
  }

  func testPresentErrorDoesNotMutateCurrentSession() throws {
    let surface = ErrorSurfaceMirror()
    let session = try makeSession(id: "INS-ERR-PRESERVE")
    surface.adoptForTest(session)
    surface.presentError("sync error")
    XCTAssertEqual(surface.current?.id, session.id)
    XCTAssertEqual(surface.errorText, "sync error")
    surface.clearError()
    XCTAssertEqual(surface.current?.id, session.id)
    XCTAssertNil(surface.errorText)
  }

  // MARK: - Save & Exit identity divergence (container contract)

  /// AppSessionContainer.saveAndExit identity-divergence: stay on Capture, keep authority,
  /// present error without an additional repository write.
  func testIdentityDivergencePresentsErrorWithoutClearingAuthorityOrExtraWrite() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("s23-err-id-div-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }

    let repository = FileCurrentSessionRepository(fileURL: fileURL)
    let service = InspectionSessionService(repository: repository)
    let prior = try makeSession(id: "INS-PRIOR-AUTH")
    _ = try await service.applyUpdatedSession(prior)
    let revisionAfterPrior = try XCTUnwrap(service.currentSession?.revision)

    let adoptedPrior = try XCTUnwrap(service.currentSession)
    let priorID = adoptedPrior.id

    let presented =
      "Save & Exit sync error: session identity changed; staying on Capture."
    var errorText: String? = presented
    let authoritative = service.currentSession

    XCTAssertEqual(authoritative?.id, priorID)
    XCTAssertEqual(errorText, presented)
    XCTAssertEqual(service.currentSession?.revision, revisionAfterPrior)

    errorText = nil
    XCTAssertNil(errorText)
    XCTAssertEqual(service.currentSession?.id, priorID)
    XCTAssertEqual(service.currentSession?.revision, revisionAfterPrior)

    let reloaded = try await repository.load()
    XCTAssertEqual(reloaded?.id, priorID)
    XCTAssertEqual(reloaded?.revision, revisionAfterPrior)
  }

  // MARK: - App source architecture (no external errorText writes)

  func testInspectionSessionViewModelDeclaresPrivateSetErrorTextAndIntentMethods() throws {
    let source = try readAppSource("InspectionSessionViewModel.swift")
    XCTAssertTrue(
      source.contains("@Published private(set) var errorText: String?"),
      "errorText must remain private(set)"
    )
    XCTAssertTrue(source.contains("func presentError(_ message: String)"), "missing presentError")
    XCTAssertTrue(source.contains("func clearError()"), "missing clearError")
  }

  func testAppSessionContainerUsesPresentErrorNotDirectAssignment() throws {
    let source = try readAppSource("AppSessionContainer.swift")
    XCTAssertTrue(
      externalErrorTextAssignments(in: source).isEmpty,
      "AppSessionContainer must not assign inspection.errorText directly; found \(externalErrorTextAssignments(in: source))"
    )
    XCTAssertTrue(
      source.contains("inspection.presentError("),
      "identity-divergence path must call presentError"
    )
    XCTAssertTrue(
      source.contains("Save & Exit sync error: session identity changed; staying on Capture."),
      "identity-divergence message must be preserved"
    )
  }

  func testInspectionReviewViewUsesClearErrorNotDirectAssignment() throws {
    let source = try readAppSource("InspectionReviewView.swift")
    XCTAssertTrue(
      externalErrorTextAssignments(in: source).isEmpty,
      "InspectionReviewView must not assign inspection.errorText directly; found \(externalErrorTextAssignments(in: source))"
    )
    XCTAssertTrue(source.contains("inspection.clearError()"), "alert dismiss must call clearError")
  }

  func testEvidenceLibraryViewModelErrorTextRemainsSeparatelyWritable() throws {
    let source = try readAppSource("EvidenceLibraryViews.swift")
    XCTAssertTrue(
      source.contains("@Published var errorText: String?"),
      "Evidence library model keeps its own writable errorText"
    )
  }

  // MARK: - Helpers

  private func makeSession(id: String) throws -> InspectionSession {
    let plan = try InspectionPlan(
      id: "s23_err",
      version: "1.0.0",
      title: "S23 Err",
      points: [
        try InspectionPoint(id: "p1", title: "P1", displayOrder: 1, isRequired: true),
      ]
    )
    let snapshot = try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
    return try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "S23-ERR")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )
  }

  private func readAppSource(_ fileName: String) throws -> String {
    let testsDir = URL(fileURLWithPath: #filePath).deletingLastPathComponent()
    let root = testsDir
      .deletingLastPathComponent() // Unit
      .deletingLastPathComponent() // Tests
    let url = root
      .appendingPathComponent("Apps/Phase1StillCapture", isDirectory: true)
      .appendingPathComponent(fileName)
    return try String(contentsOf: url, encoding: .utf8)
  }

  /// Matches `inspection.errorText =` but not `==` / `!=` / `===`.
  private func externalErrorTextAssignments(in source: String) -> [String] {
    var hits: [String] = []
    for (idx, line) in source.split(separator: "\n", omittingEmptySubsequences: false).enumerated() {
      let trimmed = line.trimmingCharacters(in: .whitespaces)
      guard let range = trimmed.range(of: "inspection.errorText") else { continue }
      let after = trimmed[range.upperBound...].drop(while: { $0 == " " })
      guard after.hasPrefix("=") else { continue }
      let rest = after.dropFirst()
      if rest.first == "=" || rest.first == "!" { continue } // == or unlikely =!
      hits.append("L\(idx + 1): \(trimmed)")
    }
    return hits
  }
}
