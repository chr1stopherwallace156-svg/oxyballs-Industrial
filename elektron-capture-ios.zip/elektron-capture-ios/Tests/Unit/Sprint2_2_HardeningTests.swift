import XCTest
@testable import ElektronCapture

/// Sprint 2.2 — adversarial hardening (package-layer: disk, fault, lifecycle, membership).
/// App-target ActionIntent UI spies require Mac xcodebuild / XCUITest (NOT RUN on Linux).
final class Sprint2_2_HardeningTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_721_100_000)

  private func makeSnapshot(pointCount: Int = 2) throws -> InspectionPlanSnapshot {
    var points: [InspectionPoint] = []
    for i in 1...pointCount {
      points.append(
        try InspectionPoint(
          id: "p\(i)",
          title: "Point \(i)",
          displayOrder: i,
          isRequired: true
        )
      )
    }
    let plan = try InspectionPlan(
      id: "s22_\(pointCount)",
      version: "1.0.0",
      title: "S22 \(pointCount)",
      points: points
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession(id: String, pointCount: Int = 2) throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "S22-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: try makeSnapshot(pointCount: pointCount),
      assignedAt: fixedInstant
    )
  }

  private func pointID(_ raw: String) -> InspectionPointID { .unchecked(raw) }

  private func coordinator(persister: (any GuidedSessionPersisting)? = nil)
    -> GuidedInspectionCoordinator
  {
    GuidedInspectionCoordinator(
      instantProvider: FixedInstantProvider(fixedInstant),
      persister: persister
    )
  }

  // MARK: Phase B — Save & Exit vs Complete gate

  func testSaveAndExitSemanticsIndependentOfCompletionGate() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("s22-save-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    var session = try makeSession(id: "INS-S22-SAVE", pointCount: 6)
    session = try await service.applyUpdatedSession(session)
    session = try await coordinator(persister: service)
      .handle(.prepareGuidedSession, session: session).session
    XCTAssertEqual(session.metrics.captureCount, 0)
    XCTAssertFalse(InspectionLifecycleEvaluator.canCommitCompletion(session))
    // Persist partial state without completion — Save & Exit contract.
    let saved = try await service.applyUpdatedSession(session)
    XCTAssertEqual(saved.status, .inProgress)
    XCTAssertEqual(saved.id, session.id)
  }

  func testCompleteBlockedUntilRequiredWorkflowsResolved() throws {
    var session = try makeSession(id: "INS-S22-COMPLETE")
    session = try coordinator().apply(.prepareGuidedSession, session: session).session
    session = try coordinator().apply(
      .bindApprovedCapture(storageKey: "lib-1", type: .photo, attributes: [:]),
      session: session
    ).session
    XCTAssertFalse(InspectionLifecycleEvaluator.canCommitCompletion(session))
    XCTAssertNotNil(InspectionLifecycleEvaluator.completionBlockReason(for: session))
  }

  // MARK: Phase D — cold reload after mutation

  func testColdReloadPreservesBindingsAndRejectsResurrectionAfterUnbind() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("s22-cold-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let c = coordinator(persister: service)
    var session = try makeSession(id: "INS-S22-COLD")
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "EVD-S22", type: .photo, attributes: [:]),
      session: session
    ).session
    XCTAssertEqual(session.evidenceBindings?.bindings.count, 1)
    session = try await c.handle(
      .unbindLibraryEvidence(libraryEvidenceId: "EVD-S22"),
      session: session
    ).session
    XCTAssertEqual(session.evidenceBindings?.bindings.count ?? 0, 0)

    let cold = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let loaded = try await cold.restoreCurrentSession()
    let live = try XCTUnwrap(loaded)
    XCTAssertEqual(live.id, session.id)
    XCTAssertEqual(live.evidenceBindings?.bindings.count ?? 0, 0)
  }

  func testLibrarySoftDeleteDoesNotResurrectAfterOtherActorWrite() async throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("s22-lib-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: root) }
    let a = EvidenceLibraryStore(libraryRoot: root)
    let b = EvidenceLibraryStore(libraryRoot: root)
    let jpeg = Self.fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let deleted = Phase1CaptureIdentifiers(
      evidenceId: "EVD-GONE",
      sessionId: "S22",
      artifactId: "A1",
      recordId: "R1"
    )
    _ = try await a.storeApproved(jpegBytes: jpeg, sha256: sha, ids: deleted)
    _ = try await b.listInspectionCatalog(forceReload: true)
    _ = try await a.softDeleteUserInitiated(id: "EVD-GONE")
    let next = Phase1CaptureIdentifiers(
      evidenceId: "EVD-NEXT",
      sessionId: "S22",
      artifactId: "A2",
      recordId: "R2"
    )
    _ = try await b.storeApproved(jpegBytes: jpeg, sha256: sha, ids: next)
    let fresh = try await a.listInspectionCatalog(forceReload: true)
    let ids = Self.allIDs(fresh)
    XCTAssertFalse(ids.contains("EVD-GONE"))
    XCTAssertTrue(ids.contains("EVD-NEXT"))
  }

  // MARK: Phase F — fault injection

  func testPersistFailureDoesNotAdoptAndLeavesCallerUntouched() async throws {
    final class Boom: GuidedSessionPersisting, @unchecked Sendable {
      func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
        throw GuidedInspectionPresentationError.persistence("injected write failure")
      }
    }
    let c = coordinator(persister: Boom())
    var session = try makeSession(id: "INS-S22-FAULT")
    session = try await coordinator().handle(.prepareGuidedSession, session: session).session
    let priorID = session.id
    let priorCount = session.evidenceBindings?.bindings.count ?? 0
    do {
      _ = try await c.handle(
        .bindApprovedCapture(storageKey: "lib-boom", type: .photo, attributes: [:]),
        session: session
      )
      XCTFail("expected injected failure")
    } catch {
      XCTAssertEqual(session.id, priorID)
      XCTAssertEqual(session.evidenceBindings?.bindings.count ?? 0, priorCount)
    }
  }

  func testFailingPersisterOnSkipLeavesCallerSessionUntouched() async throws {
    final class Boom: GuidedSessionPersisting, @unchecked Sendable {
      func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
        throw GuidedInspectionPresentationError.persistence("skip write fail")
      }
    }
    var session = try makeSession(id: "INS-S22-SKIPF")
    session = try await coordinator().handle(.prepareGuidedSession, session: session).session
    let prior = session
    do {
      _ = try await coordinator(persister: Boom()).handle(
        .skipPoint(pointID("p1"), reason: "blocked"),
        session: session
      )
      XCTFail("expected failure")
    } catch {
      XCTAssertEqual(session.id, prior.id)
      XCTAssertEqual(
        session.progress?.progress(for: pointID("p1"))?.status,
        prior.progress?.progress(for: pointID("p1"))?.status
      )
    }
  }

  // MARK: Phase E — duplicate destructive sequencing (deterministic)

  func testRepeatedUnbindIsIdempotentOnCommittedSession() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("s22-dup-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let c = coordinator(persister: service)
    var session = try makeSession(id: "INS-S22-DUP")
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "EVD-DUP", type: .photo, attributes: [:]),
      session: session
    ).session
    session = try await c.handle(
      .unbindLibraryEvidence(libraryEvidenceId: "EVD-DUP"),
      session: session
    ).session
    session = try await c.handle(
      .unbindLibraryEvidence(libraryEvidenceId: "EVD-DUP"),
      session: session
    ).session
    XCTAssertEqual(session.evidenceBindings?.bindings.count ?? 0, 0)
    let cold = try await InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    ).restoreCurrentSession()
    XCTAssertEqual(try XCTUnwrap(cold).evidenceBindings?.bindings.count ?? 0, 0)
  }

  // MARK: Guided intent exhaustiveness (package)

  func testGuidedInspectionIntentCasesAreExplicitlyHandled() {
    // Compile-time proxy: constructing every known case must be possible.
    // New cases without updating this list fail the test intentionally.
    let cases: [GuidedInspectionIntent] = [
      .prepareGuidedSession,
      .activatePoint(pointID("p1")),
      .advanceRequested,
      .returnRequested,
      .completePointRequested,
      .skipRequested(reason: "r"),
      .blockRequested(reason: "r"),
      .captureRequested,
      .bindApprovedCapture(storageKey: "k", type: .photo, attributes: [:]),
      .unbindLibraryEvidence(libraryEvidenceId: "a"),
      .replaceLibraryEvidence(
        oldLibraryEvidenceId: "a",
        storageKey: "b",
        type: .photo,
        attributes: [:]
      ),
      .clearPointEvidence(pointID("p1")),
      .assignLibraryEvidenceToPoint(
        libraryEvidenceId: "a",
        pointID: pointID("p1"),
        type: .photo,
        attributes: [:]
      ),
      .skipPoint(pointID("p1"), reason: "r"),
      .blockPoint(pointID("p1"), reason: "r"),
      .reviewInspectionRequested,
      .refreshValidationRequested,
      .reviewPointRequested(pointID("p1")),
      .generateExportRequested,
      .commitSessionCompletionRequested,
    ]
    XCTAssertEqual(
      cases.count,
      20,
      "Update Sprint 2.2 tests when GuidedInspectionIntent gains cases"
    )
  }

  // MARK: Membership file exists (complements Scripts/verify-app-sources-membership.py)

  func testInspectionActionRouterSourceFileExistsOnDisk() {
    // Package tests run from repo checkout; assert production router source is present.
    let candidates = [
      "Apps/Phase1StillCapture/InspectionActionRouter.swift",
      "../Apps/Phase1StillCapture/InspectionActionRouter.swift",
    ]
    let fm = FileManager.default
    let cwd = fm.currentDirectoryPath
    let found = candidates.contains { fm.fileExists(atPath: "\(cwd)/\($0)") }
      || fm.fileExists(
        atPath: "\(cwd)/Apps/Phase1StillCapture/InspectionActionRouter.swift"
      )
    // Also accept relative discovery from .build execution context.
    let url = URL(fileURLWithPath: cwd)
    var probe = url
    var hit = found
    for _ in 0..<6 {
      let p = probe.appendingPathComponent("Apps/Phase1StillCapture/InspectionActionRouter.swift")
      if fm.fileExists(atPath: p.path) { hit = true; break }
      probe = probe.deletingLastPathComponent()
    }
    XCTAssertTrue(hit, "InspectionActionRouter.swift must exist for app target membership")
  }

  // MARK: Phase D/F — corruption, stale revision, interrupted sequences

  func testSessionLoadTruncatedJSONSurfacesCorruptAndClears() async throws {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("s22-trunc-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: url) }
    try Data("{\"schemaVersion\":1,".utf8).write(to: url)
    let repo = FileCurrentSessionRepository(fileURL: url)
    let service = InspectionSessionService(repository: repo)
    do {
      _ = try await service.restoreCurrentSession()
      XCTFail("expected corrupt persistence")
    } catch let e as InspectionSessionError {
      guard case .corruptPersistence = e else { return XCTFail("wrong error \(e)") }
    }
    let after = try await repo.load()
    XCTAssertNil(after)
  }

  func testLibraryIndexUnsupportedSchemaFailsClosed() async throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("s22-schema-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: root) }
    let paths = EvidenceLibraryPaths(libraryRoot: root)
    try EvidenceLibraryPaths.ensureLibraryLayout(at: root)
    let payload = """
    {
      "schemaId": "EvidenceLibraryIndex",
      "schemaVersion": "99.0.0",
      "phaseStatus": "X",
      "records": [],
      "updatedAt": "2026-07-27T00:00:00Z"
    }
    """.data(using: .utf8)!
    try payload.write(to: paths.indexURL)
    let store = EvidenceLibraryStore(libraryRoot: root)
    do {
      _ = try await store.listInspectionCatalog(forceReload: true)
      XCTFail("expected unsupported schema")
    } catch let e as EvidenceLibraryError {
      guard case .unsupportedSchemaVersion(let v) = e else {
        return XCTFail("wrong error \(e)")
      }
      XCTAssertEqual(v, "99.0.0")
    }
  }

  func testMetadataExistsButMediaMissingMarkedMissingOnReconcile() async throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("s22-missing-media-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: root) }
    let store = EvidenceLibraryStore(libraryRoot: root)
    let paths = EvidenceLibraryPaths(libraryRoot: root)
    let jpeg = Self.fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)
    let ids = Phase1CaptureIdentifiers(evidenceId: "EVD-MISS", sessionId: "S", artifactId: "A", recordId: "R")
    _ = try await store.storeApproved(jpegBytes: jpeg, sha256: sha, ids: ids)
    try FileManager.default.removeItem(at: paths.artifactOriginalURL(id: ids.evidenceId))
    let doc = try await store.reconcileOnLaunch()
    let rec = try XCTUnwrap(doc.records.first(where: { $0.id == ids.evidenceId }))
    XCTAssertEqual(rec.state.storageState, .missing)
    XCTAssertEqual(rec.state.integrityState, .missingArtifact)
  }

  func testMediaExistsButMetadataMissingRebuildsOnReconcile() async throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("s22-orphan-media-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: root) }
    let store = EvidenceLibraryStore(libraryRoot: root)
    let paths = EvidenceLibraryPaths(libraryRoot: root)
    let id = "EVD-ORPHAN"
    try FileManager.default.createDirectory(at: paths.captureDirectory(id: id), withIntermediateDirectories: true)
    try Self.fixtureJPEG.write(to: paths.artifactOriginalURL(id: id), options: .atomic)
    let doc = try await store.reconcileOnLaunch()
    XCTAssertTrue(doc.records.contains(where: { $0.id == id }))
  }

  func testStaleRevisionRaceRejectsWithStaleRevisionConflict() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("s23-race-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }

    let repo = FileCurrentSessionRepository(fileURL: fileURL)
    let serviceA = InspectionSessionService(repository: repo)
    let serviceB = InspectionSessionService(repository: repo)
    var base = try makeSession(id: "INS-S23-RACE", pointCount: 2)
    base = try await serviceA.applyUpdatedSession(base, expectedRevision: 0)
    XCTAssertEqual(base.revision, 1)

    // serviceB commits a newer state (p1 skipped) against base revision
    base = try coordinator().apply(.prepareGuidedSession, session: base).session
    var newer = try coordinator().apply(.skipPoint(pointID("p1"), reason: "new"), session: base).session
    newer = try await serviceB.applyUpdatedSession(newer, expectedRevision: 1)
    XCTAssertEqual(newer.revision, 2)

    // stale writer (base snapshot @ expected 1) must be rejected — durable head stays rev 2
    var stale = base
    stale.status = .paused
    do {
      _ = try await serviceA.applyUpdatedSession(stale, expectedRevision: 1)
      XCTFail("expected staleRevisionConflict")
    } catch let InspectionSessionError.staleRevisionConflict(current, attempted) {
      XCTAssertEqual(current, 2)
      XCTAssertEqual(attempted, 1)
    }

    let cold = InspectionSessionService(repository: repo)
    let loadedOpt = try await cold.restoreCurrentSession()
    let loaded = try XCTUnwrap(loadedOpt)
    XCTAssertEqual(loaded.revision, newer.revision)
    XCTAssertEqual(loaded.id, newer.id)
    XCTAssertNotEqual(loaded.status, .paused)
    XCTAssertEqual(loaded.status, newer.status)
  }

  func testRandomizedActionSequenceWithRecordedSeed() async throws {
    let seed: UInt64 = 84_721_953
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("s22-rand-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }

    func fail(_ message: String, op: Int) -> Never {
      XCTFail("Hardening sequence failed | seed=\(seed) op=\(op) :: \(message)")
      fatalError(message)
    }

    var rng = LCG(seed: seed)
    let service = InspectionSessionService(repository: FileCurrentSessionRepository(fileURL: fileURL))
    let c = coordinator(persister: service)
    var session = try makeSession(id: "INS-S22-RAND", pointCount: 3)
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    var lastRevision = session.revision

    let evidences = ["EVD-A", "EVD-B", "EVD-C", "EVD-D", "EVD-E"]
    for op in 0..<80 {
      let action = Int(rng.next() % 7)
      do {
        switch action {
        case 0:
          let id = evidences[Int(rng.next() % UInt64(evidences.count))]
          session = try await c.handle(.bindApprovedCapture(storageKey: id, type: .photo, attributes: [:]), session: session).session
        case 1:
          session = try await c.handle(.advanceRequested, session: session).session
        case 2:
          session = try await c.handle(.returnRequested, session: session).session
        case 3:
          let p = pointID("p\(1 + Int(rng.next() % 3))")
          session = try await c.handle(.skipPoint(p, reason: "r\(op)"), session: session).session
        case 4:
          let p = pointID("p\(1 + Int(rng.next() % 3))")
          session = try await c.handle(.blockPoint(p, reason: "r\(op)"), session: session).session
        case 5:
          let id = evidences[Int(rng.next() % UInt64(evidences.count))]
          session = try await c.handle(.unbindLibraryEvidence(libraryEvidenceId: id), session: session).session
        default:
          session = try await c.handle(.reviewInspectionRequested, session: session).session
        }
      } catch {
        // allowed branch in randomized hardening; continue while checking invariants
      }

      let loadedSvc = InspectionSessionService(repository: FileCurrentSessionRepository(fileURL: fileURL))
      let loadedOpt = try await loadedSvc.restoreCurrentSession()
      let loaded = try XCTUnwrap(loadedOpt)
      // invariant: authoritative disk and in-memory committed session align by id
      if loaded.id != session.id { fail("session id diverged", op: op) }
      // invariant: revision monotonicity (disk never regresses)
      if loaded.revision < lastRevision { fail("revision regressed disk=\(loaded.revision) prior=\(lastRevision)", op: op) }
      lastRevision = max(lastRevision, loaded.revision)
      if loaded.revision != session.revision {
        // memory may lag only when last intent was non-persisting; disk is source of truth
        session = loaded
      }
      // invariant: no duplicate bindings IDs
      let keys = loaded.evidenceBindings?.bindings.map(\.storageKey) ?? []
      if Set(keys).count != keys.count { fail("duplicate storage keys", op: op) }
      // invariant: completion policy consistency
      if loaded.status == .completed, !InspectionLifecycleEvaluator.readiness(for: loaded).lifecycleLabel.contains("Completed") {
        fail("completed status not reflected in readiness", op: op)
      }
    }
  }

  struct LCG {
    private(set) var state: UInt64
    init(seed: UInt64) { self.state = seed }
    mutating func next() -> UInt64 {
      state = 6364136223846793005 &* state &+ 1
      return state
    }
  }


  // MARK: Helpers

  private static func allIDs(_ catalog: InspectionEvidenceGrouping.Catalog) -> Set<String> {
    var ids = Set(catalog.unassigned.map(\.id))
    for g in catalog.groups { ids.formUnion(g.captures.map(\.id)) }
    return ids
  }

  private static var fixtureJPEG: Data {
    Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
      0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14,
      0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7F, 0xFF, 0xD9,
    ])
  }
}
