import XCTest
@testable import ElektronCapture

/// Sprint 3.6 Linux-side gate tests.
/// Physical Apple compilation/runtime remains host-blocked on non-Mac agents.
final class Phase36AppleValidationGateTests: XCTestCase {
  func testAppleAdapterIDsAreProductionIdentities() {
    XCTAssertEqual(AppleProductionCameraSensorAdapter().adapterID, "apple.avfoundation.camera")
    XCTAssertEqual(AppleProductionMotionSensorAdapter().adapterID, "apple.coremotion.motion")
    XCTAssertEqual(AppleARKitPoseSensorAdapter().adapterID, "apple.arkit.pose")
    XCTAssertEqual(AppleARKitDepthSensorAdapter().adapterID, "apple.arkit.depth")
  }

  func testLinuxAppleCameraStubRefusesStart() async {
    let adapter = AppleProductionCameraSensorAdapter()
    do {
      try await adapter.start()
      #if canImport(AVFoundation)
      // May succeed only on Apple hosts with camera permission — not asserted here.
      #else
      XCTFail("Linux stub must throw")
      #endif
    } catch {
      #if !canImport(AVFoundation)
      // expected
      #endif
    }
  }

  func testLinuxApplePoseStubRefusesStart() async {
    #if !canImport(ARKit)
    let adapter = AppleARKitPoseSensorAdapter()
    do {
      try await adapter.start()
      XCTFail("expected APPLE_POSE_SOURCE_CANDIDATE_UNCOMPILED")
    } catch {
      // expected
    }
    #endif
  }

  func testCoordinatorAcceptsAppleProductionFactory() {
    let coord = SpatialCaptureSessionCoordinator.appleProductionSession(
      sessionID: DeviceSpatialPackageBuilder.reservedSessionID
    )
    XCTAssertEqual(coord.sessionID, "SESS-DEVICE-000001")
    XCTAssertEqual(coord.state, .idle)
  }

  func testDeviceBuilderRejectsFixtureAuthority() throws {
    let builder = DeviceSpatialPackageBuilder()
    let streams = try makeMinimalStreams()
    let inputs = DeviceSpatialPackageBuilder.DeviceSealInputs(
      camera: streams.cams,
      motion: streams.mots,
      pose: [],
      depth: [],
      cameraCapability: streams.camCap,
      motionCapability: streams.motCap,
      poseCapability: streams.poseCapNotRequested,
      depthCapability: streams.depthCapNotRequested,
      activationPlan: SensorActivationPlan(planID: "PLAN-X", entries: []),
      activationResults: [],
      sessionPolicy: .primaryFixture(),
      timeline: CaptureSessionTimeline(),
      interruptions: [],
      bufferState: CaptureBufferState(),
      evidenceOriginAuthority: .testFixture,
      createdAtUTC: "2026-08-03T00:00:00Z",
      hostClaim: "PHYSICAL_IPHONE_EXECUTION"
    )
    XCTAssertThrowsError(try builder.validateIdentity(inputs)) { err in
      XCTAssertEqual(err as? SpatialEvidenceError, .deviceEvidenceAuthorityRequired("TEST_FIXTURE"))
    }
  }

  func testDeviceBuilderRejectsFixturePackageID() throws {
    let builder = DeviceSpatialPackageBuilder()
    let streams = try makeMinimalStreams()
    let inputs = DeviceSpatialPackageBuilder.DeviceSealInputs(
      camera: streams.cams,
      motion: streams.mots,
      pose: [],
      depth: [],
      cameraCapability: streams.camCap,
      motionCapability: streams.motCap,
      poseCapability: streams.poseCapNotRequested,
      depthCapability: streams.depthCapNotRequested,
      activationPlan: SensorActivationPlan(planID: "PLAN-X", entries: []),
      activationResults: [],
      sessionPolicy: .primaryFixture(),
      timeline: CaptureSessionTimeline(),
      interruptions: [],
      bufferState: CaptureBufferState(),
      packageID: "SPKG-FIXTURE-GUIDED-CAPTURE-000001",
      captureSessionID: "SESS-DEVICE-000001",
      evidenceOriginAuthority: .deviceReported,
      createdAtUTC: "2026-08-03T00:00:00Z",
      hostClaim: "PHYSICAL_IPHONE_EXECUTION"
    )
    XCTAssertThrowsError(try builder.validateIdentity(inputs))
  }

  func testDeviceBuilderRejectsNoPhysicalHostClaim() throws {
    let builder = DeviceSpatialPackageBuilder()
    let streams = try makeMinimalStreams()
    var camCap = streams.camCap
    camCap = try freezeAcquired(base: camCap, adapterID: "apple.avfoundation.camera", count: streams.cams.count)
    var motCap = streams.motCap
    motCap = try freezeAcquired(base: motCap, adapterID: "apple.coremotion.motion", count: streams.mots.count)
    let inputs = DeviceSpatialPackageBuilder.DeviceSealInputs(
      camera: streams.cams,
      motion: streams.mots,
      pose: [],
      depth: [],
      cameraCapability: camCap,
      motionCapability: motCap,
      poseCapability: streams.poseCapNotRequested,
      depthCapability: streams.depthCapNotRequested,
      activationPlan: SensorActivationPlan(planID: "PLAN-X", entries: []),
      activationResults: [],
      sessionPolicy: .primaryFixture(),
      timeline: CaptureSessionTimeline(),
      interruptions: [],
      bufferState: CaptureBufferState(),
      evidenceOriginAuthority: .deviceReported,
      createdAtUTC: "2026-08-03T00:00:00Z",
      hostClaim: "NO_PHYSICAL_DEVICE_EXECUTION"
    )
    XCTAssertThrowsError(try builder.validateIdentity(inputs))
  }

  func testAppleHostGateRecordsUnavailableOnLinux() throws {
    #if os(macOS) || os(iOS)
    throw XCTSkip("Apple host present — physical gates execute outside this Linux unit")
    #else
    let record: [String: Any] = [
      "apple_host_available": false,
      "xcodebuild_available": false,
      "physical_iphone_attached": false,
      "gate_status": "BLOCKED_APPLE_HOST_UNAVAILABLE",
      "spkg_device_emitted": false,
      "note": "Linux cloud agent cannot execute Sprint 3.6 Mac/device validation",
    ]
    XCTAssertEqual(record["gate_status"] as? String, "BLOCKED_APPLE_HOST_UNAVAILABLE")
    XCTAssertEqual(record["spkg_device_emitted"] as? Bool, false)
    #endif
  }

  func testCompiledSourceInventoryListsAppleAdapters() throws {
    // Source presence proof (files exist in package tree).
    let root = URL(fileURLWithPath: #file)
      .deletingLastPathComponent() // Unit
      .deletingLastPathComponent() // Tests
      .deletingLastPathComponent() // package root
    let adapters = [
      "App/AppleSensors/AppleProductionCameraSensorAdapter.swift",
      "App/AppleSensors/AppleProductionMotionSensorAdapter.swift",
      "App/AppleSensors/AppleARKitPoseSensorAdapter.swift",
      "App/AppleSensors/AppleARKitDepthSensorAdapter.swift",
      "App/Domain/SpatialEvidence/SpatialCaptureSessionCoordinator.swift",
      "App/Domain/SpatialEvidence/CaptureQualityAnalyzer.swift",
      "App/Domain/SpatialEvidence/CaptureCoverageEngine.swift",
      "App/Domain/SpatialEvidence/CaptureGuidanceEngine.swift",
      "App/Domain/SpatialEvidence/DeviceSpatialPackageBuilder.swift",
    ]
    for rel in adapters {
      let url = root.appendingPathComponent(rel)
      XCTAssertTrue(FileManager.default.fileExists(atPath: url.path), "missing \(rel)")
    }
  }

  // MARK: - helpers

  private func makeMinimalStreams() throws -> (
    cams: [SpatialSampleEnvelope<CameraSample>],
    mots: [SpatialSampleEnvelope<MotionSample>],
    camCap: SpatialStreamCapability,
    motCap: SpatialStreamCapability,
    poseCapNotRequested: SpatialStreamCapability,
    depthCapNotRequested: SpatialStreamCapability
  ) {
    // Use controllable adapters briefly for envelope bytes only — not DEVICE evidence.
    let camera = ControllableCameraSensorAdapter()
    let motion = ControllableMotionSensorAdapter()
    // We only need capability shells here; empty sample arrays are fine for identity tests.
    var pose = SpatialStreamCapability(streamID: "pose", adapterID: "none", sensorKind: "pose", declared: false)
    try pose.freeze(outcome: .notRequested)
    var depth = SpatialStreamCapability(streamID: "depth", adapterID: "none", sensorKind: "depth", declared: false)
    try depth.freeze(outcome: .notRequested)
    return ([], [], camera.capability, motion.capability, pose, depth)
  }

  private func freezeAcquired(base: SpatialStreamCapability, adapterID: String, count: Int) throws -> SpatialStreamCapability {
    var cap = SpatialStreamCapability(
      streamID: base.streamID,
      adapterID: adapterID,
      sensorKind: base.sensorKind,
      declared: true
    )
    cap.activate()
    for _ in 0..<max(count, 1) { cap.recordSample() }
    try cap.freeze(outcome: .acquired)
    return cap
  }
}
