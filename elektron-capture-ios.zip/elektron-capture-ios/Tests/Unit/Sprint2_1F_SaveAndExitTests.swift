import XCTest
@testable import ElektronCapture

/// Phase A2 — Save & Exit vs Complete Inspection lifecycle decoupling.
/// Mirrors field semantics of InspectionSessionViewModel.saveAndExit() /
/// AppSessionContainer.saveAndExit() using domain + persistence APIs available on Linux.
final class Sprint2_1F_SaveAndExitTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_900_000)
  private let progression = InspectionProgressionEngine()

  private func makeSnapshot(pointCount: Int) throws -> InspectionPlanSnapshot {
    var points: [InspectionPoint] = []
    for i in 1...pointCount {
      points.append(
        try InspectionPoint(
          id: "p\(i)",
          title: "Point \(i)",
          displayOrder: i,
          isRequired: true
        )
      )
    }
    let plan = try InspectionPlan(
      id: "save_exit_\(pointCount)",
      version: "1.0.0",
      title: "\(pointCount)-Point",
      points: points
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession(id: String, pointCount: Int) throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "SAVE-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: try makeSnapshot(pointCount: pointCount),
      assignedAt: fixedInstant
    )
  }

  private func pointID(_ raw: String) -> InspectionPointID { .unchecked(raw) }

  private func coordinator(persister: (any GuidedSessionPersisting)? = nil)
    -> GuidedInspectionCoordinator
  {
    GuidedInspectionCoordinator(
      instantProvider: FixedInstantProvider(fixedInstant),
      persister: persister
    )
  }

  /// Domain equivalent of Save & Exit: persist authoritative snapshot as `.inProgress`
  /// without completion validation or export.
  @discardableResult
  private func saveAndExit(
    _ session: InspectionSession,
    via service: InspectionSessionService
  ) async throws -> InspectionSession {
    var working = session
    if working.status == .paused {
      try await service.resume()
      working = try XCTUnwrap(service.currentSession)
    }
    let committed = try await service.applyUpdatedSession(working)
    XCTAssertEqual(committed.status, .inProgress)
    XCTAssertEqual(committed.id, working.id)
    return committed
  }

  // MARK: Save & Exit flexibility

  func testSaveAndExitWithZeroPhotosFourPointRemainsInProgress() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("save-exit-0-4-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    var session = try makeSession(id: "INS-SE-0-4", pointCount: 4)
    session = try await service.applyUpdatedSession(session)
    session = try await coordinator(persister: service)
      .handle(.prepareGuidedSession, session: session).session

    XCTAssertEqual(session.metrics.captureCount, 0)
    XCTAssertFalse(InspectionLifecycleEvaluator.canCommitCompletion(session))

    let saved = try await saveAndExit(session, via: service)
    XCTAssertEqual(saved.status, .inProgress)
    XCTAssertEqual(saved.id, session.id)
    XCTAssertNotEqual(
      InspectionLifecycleEvaluator.presentation(for: saved),
      .completed
    )
    XCTAssertFalse(InspectionLifecycleEvaluator.canCommitCompletion(saved))
  }

  func testSaveAndExitWithZeroPhotosSixPointRemainsInProgress() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("save-exit-0-6-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    var session = try makeSession(id: "INS-SE-0-6", pointCount: 6)
    session = try await service.applyUpdatedSession(session)
    session = try await coordinator(persister: service)
      .handle(.prepareGuidedSession, session: session).session

    let saved = try await saveAndExit(session, via: service)
    XCTAssertEqual(saved.status, .inProgress)
    XCTAssertEqual(saved.planSnapshot?.points.count, 6)
    XCTAssertFalse(InspectionLifecycleEvaluator.canCommitCompletion(saved))
  }

  func testSaveAndExitWithOnePhotoMidInspectionStaysInProgress() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("save-exit-1-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let c = coordinator(persister: service)
    var session = try makeSession(id: "INS-SE-1", pointCount: 6)
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "lib-one", type: .photo, attributes: [:]),
      session: session
    ).session

    XCTAssertEqual(session.evidenceBindings?.bindings.count, 1)
    XCTAssertFalse(InspectionLifecycleEvaluator.canCommitCompletion(session))
    XCTAssertEqual(
      InspectionLifecycleEvaluator.presentation(for: session),
      .inProgress
    )

    let saved = try await saveAndExit(session, via: service)
    XCTAssertEqual(saved.status, .inProgress)
    XCTAssertEqual(saved.id, session.id)
    XCTAssertEqual(saved.evidenceBindings?.bindings.count, 1)
    XCTAssertNotEqual(
      InspectionLifecycleEvaluator.presentation(for: saved),
      .completed
    )
  }

  func testSaveAndExitFromPausedNormalizesToInProgress() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("save-exit-paused-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    var session = try makeSession(id: "INS-SE-PAUSE", pointCount: 4)
    session = try await service.applyUpdatedSession(session)
    session = try await coordinator(persister: service)
      .handle(.prepareGuidedSession, session: session).session
    try await service.pause()
    XCTAssertEqual(service.currentSession?.status, .paused)

    let saved = try await saveAndExit(try XCTUnwrap(service.currentSession), via: service)
    XCTAssertEqual(saved.status, .inProgress)
    XCTAssertEqual(saved.id, session.id)
  }

  // MARK: Resume accuracy

  func testResumeRestoresExactSessionIDActivePointAndBindings() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("save-exit-resume-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let c = coordinator(persister: service)
    var session = try makeSession(id: "INS-SE-RESUME", pointCount: 6)
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "lib-resume", type: .photo, attributes: [:]),
      session: session
    ).session
    let activeBefore = session.progress?.activePointID
    let bindingCount = session.evidenceBindings?.bindings.count ?? 0
    let originalID = session.id

    _ = try await saveAndExit(session, via: service)

    // Simulate leave + relaunch (new service, same file) — Resume must not mint a new ID.
    let restored = try await InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    ).restoreCurrentSession()
    let live = try XCTUnwrap(restored)
    XCTAssertEqual(live.id, originalID)
    XCTAssertEqual(live.status, .inProgress)
    XCTAssertEqual(live.progress?.activePointID, activeBefore)
    XCTAssertEqual(live.evidenceBindings?.bindings.count, bindingCount)
    XCTAssertEqual(live.progress?.progress(for: pointID("p1"))?.status, .inProgress)
  }

  // MARK: Complete Inspection remains gated

  func testCompleteInspectionDisabledWhilePointsUnresolved() throws {
    let c = coordinator()
    var session = try makeSession(id: "INS-SE-GATE", pointCount: 4)
    session = try c.apply(.prepareGuidedSession, session: session).session
    session = try c.apply(
      .bindApprovedCapture(storageKey: "lib-gate", type: .photo, attributes: [:]),
      session: session
    ).session

    XCTAssertFalse(InspectionLifecycleEvaluator.canCommitCompletion(session))
    XCTAssertNotNil(InspectionLifecycleEvaluator.completionBlockReason(for: session))
    XCTAssertEqual(
      InspectionLifecycleEvaluator.presentation(for: session),
      .inProgress
    )
    XCTAssertNotEqual(
      InspectionLifecycleEvaluator.presentation(for: session),
      .completed
    )
  }

  func testSaveAndExitDoesNotTriggerCompletionOrExportReadiness() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("save-exit-no-export-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let c = coordinator(persister: service)
    var session = try makeSession(id: "INS-SE-NX", pointCount: 4)
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "lib-nx", type: .photo, attributes: [:]),
      session: session
    ).session

    let saved = try await saveAndExit(session, via: service)
    let ready = InspectionLifecycleEvaluator.readiness(for: saved)
    XCTAssertEqual(ready.lifecycle, .inProgress)
    XCTAssertFalse(ready.isExportReady)
    XCTAssertFalse(InspectionLifecycleEvaluator.canCommitCompletion(saved))
    // Export policy still blocked — Save & Exit must not bypass.
    XCTAssertEqual(ready.exportLabel, "Export Blocked")
  }

  // MARK: Status accuracy (A2 + prior Phase A)

  func testCannotDisplayCompletedAfterPartialSaveAndExit() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("save-exit-status-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let c = coordinator(persister: service)
    var session = try makeSession(id: "INS-SE-STATUS", pointCount: 4)
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    // Evidence satisfied on p1 only — still not workflow-complete.
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "lib-st", type: .photo, attributes: [:]),
      session: session
    ).session
    let saved = try await saveAndExit(session, via: service)
    XCTAssertNotEqual(
      InspectionLifecycleEvaluator.presentation(for: saved),
      .completed
    )
    XCTAssertNotEqual(
      InspectionLifecycleEvaluator.presentation(for: saved),
      .readyForReview
    )
  }

  func testGuidedUsePhotoStillSkipsLegacyApprovedState() throws {
    XCTAssertTrue(
      Phase1StillCaptureUIStateMachine.canTransition(from: .reviewing, to: .previewing)
    )
    let next = try Phase1StillCaptureUIStateMachine.transition(
      from: .reviewing,
      to: .previewing
    )
    XCTAssertEqual(next, .previewing)
    XCTAssertNotEqual(next, .approved)
  }
}
