import XCTest
@testable import ElektronCapture

final class Phase4AReconstructionTests: XCTestCase {
  private func tempDir(_ name: String = UUID().uuidString) throws -> URL {
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("p4a-\(name)", isDirectory: true)
    try? FileManager.default.removeItem(at: url)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  private func sealPrimary() throws -> (FixtureReconstructionPackageBuilder.SealResult, URL) {
    let root = try tempDir("pkg")
    let sealed = try FixtureReconstructionPackageBuilder().sealPrimary(outputDirectory: root)
    return (sealed, root)
  }

  // MARK: Happy path

  func testValidReconstructionFixtureIngests() throws {
    let (sealed, root) = try sealPrimary()
    XCTAssertEqual(sealed.package.manifest.packageID, FixtureReconstructionPackageBuilder.primaryPackageID)
    XCTAssertEqual(sealed.package.manifest.captureSessionID, FixtureReconstructionPackageBuilder.primarySessionID)
    let ingest = try ReconstructionPackageIngestor().ingest(packageRoot: root)
    XCTAssertEqual(ingest.eligibility.outcome, .eligibleCameraDepthPose)
    XCTAssertTrue(ingest.eligibility.isEligible)
    XCTAssertEqual(ingest.descriptor?.evidenceOriginAuthority, "TEST_FIXTURE")
    XCTAssertEqual(ingest.descriptor?.geometryReferenceAuthority, "TEST_FIXTURE_GROUND_TRUTH")
  }

  func testEligibilityClassificationDeterministic() throws {
    let (_, root) = try sealPrimary()
    let a = try ReconstructionPackageIngestor().ingest(packageRoot: root)
    let b = try ReconstructionPackageIngestor().ingest(packageRoot: root)
    XCTAssertEqual(a.eligibility.outcome, b.eligibility.outcome)
    XCTAssertEqual(a.eligibility.outcome, .eligibleCameraDepthPose)
  }

  func testEndToEndPipelineDeterministic() throws {
    let (sealed, root) = try sealPrimary()
    let out1 = try tempDir("out1")
    let out2 = try tempDir("out2")
    let r1 = try ReconstructionPipeline().run(packageRoot: root, outputRoot: out1)
    let r2 = try ReconstructionPipeline().run(packageRoot: root, outputRoot: out2)
    XCTAssertEqual(r1.pointCloudSHA256, r2.pointCloudSHA256)
    XCTAssertEqual(r1.lineageManifestSHA256, r2.lineageManifestSHA256)
    XCTAssertEqual(r1.inventorySHA256, r2.inventorySHA256)
    XCTAssertEqual(r1.frames?.selectedCandidateIDs, r2.frames?.selectedCandidateIDs)
    XCTAssertTrue(r1.sourcePackageUnchanged)
    XCTAssertEqual(sealed.package.packageClosureSHA256, r1.sourcePackageClosureSHA256)
    XCTAssertEqual(r1.eligibility.outcome, .eligibleCameraDepthPose)
    XCTAssertGreaterThan(r1.normalized?.cameras.count ?? 0, 0)
    XCTAssertGreaterThan(r1.frames?.selectedCandidateIDs.count ?? 0, 0)
    XCTAssertGreaterThan(r1.pointCloud?.points.filter { $0.validity == .valid }.count ?? 0, 0)
    XCTAssertEqual(r1.surface?.candidate?.metadata.classification, "SYNTHETIC_FIXTURE_SURFACE_CANDIDATE")
    XCTAssertEqual(r1.quality?.groundTruthComparison?.passed, true)
    XCTAssertEqual(r1.quality?.engineeringMetrologyClaim, "FORBIDDEN")
    XCTAssertEqual(r1.quality?.characterizationStatus, "DETERMINISTIC_TEST_FIXTURE")
  }

  func testKeyframeSelectionDeterministicAndReasonCodes() throws {
    let (_, root) = try sealPrimary()
    let out = try tempDir("frames")
    let r = try ReconstructionPipeline().run(packageRoot: root, outputRoot: out)
    let frames = try XCTUnwrap(r.frames)
    XCTAssertFalse(frames.selectedCandidateIDs.isEmpty)
    for d in frames.decisions where d.selected {
      XCTAssertEqual(d.reasonCodes, ["SELECTED"])
      XCTAssertEqual(d.policyID, FrameSelectionPolicy.fixture.policyID)
      XCTAssertFalse(d.derivationID.isEmpty)
    }
  }

  func testRejectedFramesHaveReasonCodes() throws {
    let cam = NormalizedCameraObservation(
      observationID: "OBS-CAM-x", sampleID: "c", artifactID: "a", artifactSHA256: "h1",
      timestampNanoseconds: 1, clockDomain: "fixture_camera", calibrationID: "cal",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, blurScore: 0.1, exposureScore: 0.1
    )
    let depth = NormalizedDepthObservation(
      observationID: "OBS-DEPTH-x", sampleID: "d", artifactID: "a", artifactSHA256: "h2",
      timestampNanoseconds: 1, clockDomain: "fixture_depth", calibrationID: "cal",
      width: 4, height: 4, pixelFormat: "FLOAT32_METERS", depthBytes: Data(count: 64),
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, depthValidityPercent: 10
    )
    let pose = NormalizedPoseObservation(
      observationID: "OBS-POSE-x", sampleID: "p", timestampNanoseconds: 1, clockDomain: "arkit_frame",
      translation: [0, 0, 0], transform4x4: HomogeneousMatrix4x4.identity(), trackingState: "LOST",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1
    )
    let cand = ReconstructionFrameCandidate(
      candidateID: "CAND-1", associationID: "a1",
      cameraObservationID: cam.observationID, depthObservationID: depth.observationID,
      poseObservationID: pose.observationID, metrics: []
    )
    let set = try KeyframeSelector().select(candidates: [cand], cameras: [cam], depths: [depth], poses: [pose])
    let d = try XCTUnwrap(set.decisions.first)
    XCTAssertFalse(d.selected)
    XCTAssertTrue(d.reasonCodes.contains(FrameRejectionReason.blurTooHigh.rawValue))
    XCTAssertTrue(d.reasonCodes.contains(FrameRejectionReason.depthValidityLow.rawValue))
    XCTAssertTrue(d.reasonCodes.contains(FrameRejectionReason.trackingLost.rawValue))
  }

  func testDepthBackProjectionAgainstKnownFixtureValues() throws {
    let depthBytes = ReconstructionFixtureDepthPayload.deterministicBytes()
    let depth = NormalizedDepthObservation(
      observationID: "OBS-DEPTH-t", sampleID: "recon-depth-0", artifactID: "payload/depth/0000.bin",
      artifactSHA256: ContentHasher.sha256Hex(depthBytes), timestampNanoseconds: 1,
      clockDomain: "fixture_depth", calibrationID: FixtureReconstructionPackageBuilder.calibrationID,
      width: 4, height: 4, pixelFormat: "FLOAT32_METERS", depthBytes: depthBytes,
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, depthValidityPercent: 93.75
    )
    let pose = NormalizedPoseObservation(
      observationID: "OBS-POSE-t", sampleID: "recon-pose-0", timestampNanoseconds: 1,
      clockDomain: "arkit_frame", translation: [0, 0, 0],
      transform4x4: HomogeneousMatrix4x4.identity(), trackingState: "NORMAL",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1
    )
    let cal = DepthPoseRegistrationEngine.CalibrationIntrinsics(
      calibrationID: FixtureReconstructionPackageBuilder.calibrationID,
      fx: 100, fy: 100, cx: 1.5, cy: 1.5, width: 4, height: 4
    )
    let reg = try DepthPoseRegistrationEngine().register(
      depth: depth, pose: pose, calibration: cal,
      depthToCamera: HomogeneousMatrix4x4.identity(),
      sourcePackageClosureSHA256: String(repeating: "a", count: 64),
      derivationID: "DER-T"
    )
    let expected = FixtureReconstructionGeometry.planarTarget().expectedPointPositions
    for pt in expected {
      let u = Int(pt["u"]!), v = Int(pt["v"]!)
      let match = reg.points.first { $0.source.pixelU == u && $0.source.pixelV == v && $0.validity == .valid }
      let p = try XCTUnwrap(match)
      XCTAssertEqual(p.x, pt["x"]!, accuracy: 1e-12)
      XCTAssertEqual(p.y, pt["y"]!, accuracy: 1e-12)
      XCTAssertEqual(p.z, pt["z"]!, accuracy: 1e-12)
      XCTAssertEqual(p.source.depthSampleID, "recon-depth-0")
      XCTAssertEqual(p.source.poseSampleID, "recon-pose-0")
      XCTAssertFalse(p.source.derivationID.isEmpty)
    }
    XCTAssertEqual(reg.invalidDepthCount, 1)
  }

  func testRegisteredPointsTraceToSource() throws {
    let (_, root) = try sealPrimary()
    let r = try ReconstructionPipeline().run(packageRoot: root, outputRoot: try tempDir("trace"))
    let pts = try XCTUnwrap(r.pointCloud?.points.filter { $0.validity == .valid })
    XCTAssertFalse(pts.isEmpty)
    for p in pts.prefix(5) {
      XCTAssertFalse(p.source.depthSampleID.isEmpty)
      XCTAssertFalse(p.source.depthArtifactID.isEmpty)
      XCTAssertFalse(p.source.calibrationID.isEmpty)
      XCTAssertFalse(p.source.poseSampleID.isEmpty)
      XCTAssertEqual(p.source.sourcePackageClosureSHA256, r.sourcePackageClosureSHA256)
      XCTAssertFalse(p.source.transformIDs.isEmpty)
    }
  }

  func testGroundTruthComparisonPasses() throws {
    let (_, root) = try sealPrimary()
    let r = try ReconstructionPipeline().run(packageRoot: root, outputRoot: try tempDir("gt"))
    XCTAssertEqual(r.quality?.groundTruthComparison?.classification, "FIXTURE_GROUND_TRUTH_DELTA")
    XCTAssertEqual(r.quality?.groundTruthComparison?.residual.classification, "FIXTURE_REGISTRATION_ERROR")
    XCTAssertEqual(r.quality?.groundTruthComparison?.passed, true)
  }

  func testMetadataMutationChangesLineageDigest() throws {
    let (_, root) = try sealPrimary()
    let r = try ReconstructionPipeline().run(packageRoot: root, outputRoot: try tempDir("lin1"))
    var records = try XCTUnwrap(r.lineage?.records)
    records[0].generationTimestamp = "2099-01-01T00:00:00Z"
    let mutated = try ReconstructionLineageBuilder.sealLineage(records)
    XCTAssertNotEqual(mutated.lineageManifestSHA256, r.lineageManifestSHA256)
  }

  func testSourcePayloadMutationChangesReconstructionOutput() throws {
    let (_, root) = try sealPrimary()
    let outA = try tempDir("mutA")
    let a = try ReconstructionPipeline().run(packageRoot: root, outputRoot: outA)
    let depthURL = root.appendingPathComponent("payload/depth/0000.bin")
    var bytes = try Data(contentsOf: depthURL)
    bytes[0] ^= 0xff
    try bytes.write(to: depthURL)
    // Closure should fail ingest
    let ingest = try ReconstructionPackageIngestor().ingest(packageRoot: root)
    XCTAssertFalse(ingest.eligibility.isEligible)
    XCTAssertEqual(ingest.eligibility.outcome, .ineligibleInvalidPackage)
    _ = a
  }

  func testOutputOrderingDeterministic() throws {
    let (_, root) = try sealPrimary()
    let r = try ReconstructionPipeline().run(packageRoot: root, outputRoot: try tempDir("ord"))
    let ids = try XCTUnwrap(r.pointCloud?.points.map(\.pointID))
    XCTAssertEqual(ids, ids.sorted())
    let invPaths = try XCTUnwrap(r.inventory?.items.map(\.relativePath))
    XCTAssertEqual(invPaths, invPaths.sorted())
  }

  func testSourcePackageBytesUnchanged() throws {
    let (sealed, root) = try sealPrimary()
    let before = sealed.sourcePackageBytesSHA256
    _ = try ReconstructionPipeline().run(packageRoot: root, outputRoot: try tempDir("immut"))
    let after = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: root)
    XCTAssertEqual(before, after)
  }

  func testAllOutputsInventoriedNoOrphans() throws {
    let (_, root) = try sealPrimary()
    let out = try tempDir("inv")
    let r = try ReconstructionPipeline().run(packageRoot: root, outputRoot: out)
    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: out)
    let paths = Set(entries.compactMap { $0["relative_path"] as? String })
    XCTAssertTrue(paths.contains("registered_point_cloud.json"))
    XCTAssertTrue(paths.contains("lineage_manifest.json"))
    XCTAssertTrue(paths.contains("output_inventory.json"))
    XCTAssertTrue(paths.contains("output_closure.json"))
    XCTAssertTrue(paths.contains("selected_keyframes.json"))
    XCTAssertFalse(r.outputClosureSHA256.isEmpty)
    // No orphan: every regular file is in inventory entries
    let fm = FileManager.default
    let enumerator = fm.enumerator(at: out, includingPropertiesForKeys: [.isRegularFileKey])
    while let item = enumerator?.nextObject() as? URL {
      var isFile: ObjCBool = false
      guard fm.fileExists(atPath: item.path, isDirectory: &isFile), !isFile.boolValue else { continue }
      let rel = item.path.replacingOccurrences(of: out.path + "/", with: "")
      XCTAssertTrue(paths.contains(rel), "orphan \(rel)")
    }
  }

  func testReconstructionOutputClosurePasses() throws {
    let (_, root) = try sealPrimary()
    let out = try tempDir("closure")
    let r = try ReconstructionPipeline().run(packageRoot: root, outputRoot: out)
    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: out)
    let recomputed = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    XCTAssertEqual(recomputed, r.outputClosureSHA256)
  }

  func testDeterministicReplayIdentical() throws {
    let (_, root) = try sealPrimary()
    let a = try ReconstructionPipeline().run(packageRoot: root, outputRoot: try tempDir("rep1"))
    let b = try ReconstructionPipeline().run(packageRoot: root, outputRoot: try tempDir("rep2"))
    XCTAssertEqual(a.pointCloudSHA256, b.pointCloudSHA256)
    XCTAssertEqual(a.lineageManifestSHA256, b.lineageManifestSHA256)
    XCTAssertEqual(a.outputClosureSHA256, b.outputClosureSHA256)
  }

  // MARK: Failure fixtures

  func testInvalidPackageClosure() throws {
    let (_, root) = try sealPrimary()
    var inv = try SpatialPackageReader().readJSONObject(packageRoot: root, name: "package_inventory.json")
    inv["fixture_package_closure_sha256"] = String(repeating: "0", count: 64)
    try CanonicalJSON.data(inv).write(to: root.appendingPathComponent("package_inventory.json"))
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: root)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleInvalidPackage)
  }

  func testMissingManifest() throws {
    let root = try tempDir("nomf")
    try Data("{}".utf8).write(to: root.appendingPathComponent("package_inventory.json"))
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: root)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleInvalidPackage)
  }

  func testMissingCameraArtifact() throws {
    let (_, root) = try sealPrimary()
    try FileManager.default.removeItem(at: root.appendingPathComponent("payload/camera/0000.bin"))
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: root)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleInvalidPackage)
  }

  func testMissingDepthArtifact() throws {
    let (_, root) = try sealPrimary()
    try FileManager.default.removeItem(at: root.appendingPathComponent("payload/depth/0000.bin"))
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: root)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleInvalidPackage)
  }

  func testMissingPoseSample() throws {
    let root = try tempDir("nopose")
    _ = try FixtureReconstructionPackageBuilder().seal(outputDirectory: root, frameCount: 2)
    // Remove pose from sample index by sealing then deleting pose associations + emptying pose ids via inventory mutation path:
    // Use eligibility policy requiring pose with emptied pose stream file list — delete pose payload and expect failure on artifact.
    try FileManager.default.removeItem(at: root.appendingPathComponent("payload/pose/0000.bin"))
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: root)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleInvalidPackage)
  }

  func testMissingCalibration() throws {
    let (_, root) = try sealPrimary()
    try FileManager.default.removeItem(at: root.appendingPathComponent("depth_calibration.json"))
    // Also need inventory/closure to still pass — removing file breaks closure.
    // Rebuild inventory isn't needed: closure verify walks files vs inventory entries → fail invalid package OR missing cal after fix.
    // Force re-seal style: write empty calibrations but update inventory by rehashing is hard.
    // Instead unit-test policy path with synthetic ingest via emptied cal file + refreshed inventory.
    let sealed = try FixtureReconstructionPackageBuilder().seal(outputDirectory: try tempDir("cal2"))
    try writeJSON(["calibrations": []], to: sealed.package.rootURL.appendingPathComponent("depth_calibration.json"))
    try refreshInventory(packageRoot: sealed.package.rootURL)
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleMissingCalibration)
  }

  func testInvalidCalibration() throws {
    let sealed = try FixtureReconstructionPackageBuilder().seal(outputDirectory: try tempDir("badcal"))
    var cal = try SpatialPackageReader().readJSONObject(packageRoot: sealed.package.rootURL, name: "depth_calibration.json")
    var list = cal["calibrations"] as! [[String: Any]]
    list[0]["focal_length_x"] = 0.0
    cal["calibrations"] = list
    try writeJSON(cal, to: sealed.package.rootURL.appendingPathComponent("depth_calibration.json"))
    try refreshInventory(packageRoot: sealed.package.rootURL)
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleMissingCalibration)
  }

  func testBrokenCameraDepthAssociation() throws {
    let sealed = try FixtureReconstructionPackageBuilder().seal(outputDirectory: try tempDir("bada"))
    try writeJSON(["associations": []], to: sealed.package.rootURL.appendingPathComponent("rgb_depth_associations.json"))
    try refreshInventory(packageRoot: sealed.package.rootURL)
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleBrokenAssociation)
  }

  func testBrokenCameraPoseAssociation() throws {
    let sealed = try FixtureReconstructionPackageBuilder().seal(outputDirectory: try tempDir("badp"))
    try writeJSON(["associations": []], to: sealed.package.rootURL.appendingPathComponent("pose_associations.json"))
    try refreshInventory(packageRoot: sealed.package.rootURL)
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleBrokenAssociation)
  }

  func testMissingClockCorrelation() throws {
    let sealed = try FixtureReconstructionPackageBuilder().seal(outputDirectory: try tempDir("noclk"))
    try writeJSON(["correlations": []], to: sealed.package.rootURL.appendingPathComponent("clock_correlation.json"))
    try refreshInventory(packageRoot: sealed.package.rootURL)
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleBrokenAssociation)
  }

  func testStaleClockCorrelation() throws {
    let sealed = try FixtureReconstructionPackageBuilder().seal(outputDirectory: try tempDir("stale"))
    try writeJSON(
      ["correlations": [[
        "correlation_id": "stale",
        "valid_from_nanoseconds": 100,
        "valid_until_nanoseconds": 50,
      ]]],
      to: sealed.package.rootURL.appendingPathComponent("clock_correlation.json")
    )
    try refreshInventory(packageRoot: sealed.package.rootURL)
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleBrokenAssociation)
    XCTAssertTrue(r.failures.contains { $0.code == "STALE_CLOCK_CORRELATION" })
  }

  func testMissingTransformPath() throws {
    let sealed = try FixtureReconstructionPackageBuilder().seal(outputDirectory: try tempDir("notf"))
    try writeJSON(
      ["edges": [], "characterization_status": "DETERMINISTIC_TEST_FIXTURE", "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED"],
      to: sealed.package.rootURL.appendingPathComponent("transform_graph.json")
    )
    try refreshInventory(packageRoot: sealed.package.rootURL)
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleBrokenAssociation)
  }

  func testAmbiguousTransformPath() throws {
    let sealed = try FixtureReconstructionPackageBuilder().seal(outputDirectory: try tempDir("ambig"))
    let edge: [String: Any] = [
      "transform_id": "DUP", "from_frame_id": "A", "to_frame_id": "B",
      "matrix": HomogeneousMatrix4x4.identity(),
    ]
    try writeJSON(
      ["edges": [edge, edge], "characterization_status": "DETERMINISTIC_TEST_FIXTURE", "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED"],
      to: sealed.package.rootURL.appendingPathComponent("transform_graph.json")
    )
    try refreshInventory(packageRoot: sealed.package.rootURL)
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleBrokenAssociation)
    XCTAssertTrue(r.failures.contains { $0.code == "AMBIGUOUS_TRANSFORM_PATH" })
  }

  func testUnsupportedDepthFormatRejectedByRegistration() {
    let depth = NormalizedDepthObservation(
      observationID: "d", sampleID: "d", artifactID: "a", artifactSHA256: "h",
      timestampNanoseconds: 1, clockDomain: "fixture_depth", calibrationID: "c",
      width: 1, height: 1, pixelFormat: "UINT16_MM", depthBytes: Data([0, 0]),
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, depthValidityPercent: 100
    )
    let pose = NormalizedPoseObservation(
      observationID: "p", sampleID: "p", timestampNanoseconds: 1, clockDomain: "arkit_frame",
      translation: [0, 0, 0], transform4x4: HomogeneousMatrix4x4.identity(), trackingState: "NORMAL",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1
    )
    XCTAssertThrowsError(
      try DepthPoseRegistrationEngine().register(
        depth: depth, pose: pose,
        calibration: .init(calibrationID: "c", fx: 1, fy: 1, cx: 0, cy: 0, width: 1, height: 1),
        depthToCamera: HomogeneousMatrix4x4.identity(),
        sourcePackageClosureSHA256: String(repeating: "b", count: 64),
        derivationID: "x"
      )
    )
  }

  func testCrossEpochRegistrationRejected() {
    let depthBytes = ReconstructionFixtureDepthPayload.deterministicBytes()
    let depth = NormalizedDepthObservation(
      observationID: "d", sampleID: "d", artifactID: "a", artifactSHA256: "h",
      timestampNanoseconds: 1, clockDomain: "fixture_depth", calibrationID: "c",
      width: 4, height: 4, pixelFormat: "FLOAT32_METERS", depthBytes: depthBytes,
      frameEpochID: "epoch-a", sessionRunID: "r", worldOriginRevision: 1, depthValidityPercent: 90
    )
    let pose = NormalizedPoseObservation(
      observationID: "p", sampleID: "p", timestampNanoseconds: 1, clockDomain: "arkit_frame",
      translation: [0, 0, 0], transform4x4: HomogeneousMatrix4x4.identity(), trackingState: "NORMAL",
      frameEpochID: "epoch-b", sessionRunID: "r", worldOriginRevision: 1
    )
    XCTAssertThrowsError(
      try DepthPoseRegistrationEngine().register(
        depth: depth, pose: pose,
        calibration: .init(calibrationID: "c", fx: 100, fy: 100, cx: 1.5, cy: 1.5, width: 4, height: 4),
        depthToCamera: HomogeneousMatrix4x4.identity(),
        sourcePackageClosureSHA256: String(repeating: "c", count: 64),
        derivationID: "x"
      )
    )
  }

  func testInsufficientFrameCount() throws {
    let sealed = try FixtureReconstructionPackageBuilder().seal(outputDirectory: try tempDir("few"), frameCount: 2)
    var policy = ReconstructionEligibilityPolicy.fixture
    policy.minCameraSamples = 99
    let r = try ReconstructionPackageIngestor(policy: policy).ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligibleInsufficientObservations)
  }

  func testAllFramesRejected() throws {
    let cam = NormalizedCameraObservation(
      observationID: "OBS-CAM-x", sampleID: "c", artifactID: "a", artifactSHA256: "h1",
      timestampNanoseconds: 1, clockDomain: "fixture_camera", calibrationID: "cal",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, blurScore: 0.0, exposureScore: 0.0
    )
    let depth = NormalizedDepthObservation(
      observationID: "OBS-DEPTH-x", sampleID: "d", artifactID: "a", artifactSHA256: "h2",
      timestampNanoseconds: 1, clockDomain: "fixture_depth", calibrationID: "cal",
      width: 4, height: 4, pixelFormat: "FLOAT32_METERS", depthBytes: Data(count: 64),
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, depthValidityPercent: 0
    )
    let pose = NormalizedPoseObservation(
      observationID: "OBS-POSE-x", sampleID: "p", timestampNanoseconds: 1, clockDomain: "arkit_frame",
      translation: [0, 0, 0], transform4x4: HomogeneousMatrix4x4.identity(), trackingState: "LOST",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1
    )
    let set = try KeyframeSelector().select(
      candidates: [
        ReconstructionFrameCandidate(
          candidateID: "C1", associationID: "a", cameraObservationID: cam.observationID,
          depthObservationID: depth.observationID, poseObservationID: pose.observationID, metrics: []
        ),
      ],
      cameras: [cam], depths: [depth], poses: [pose]
    )
    XCTAssertTrue(set.selectedCandidateIDs.isEmpty)
    XCTAssertFalse(set.decisions.first!.reasonCodes.isEmpty)
  }

  func testDuplicateFrameIdentityRejected() throws {
    let cam1 = NormalizedCameraObservation(
      observationID: "OBS-CAM-1", sampleID: "c1", artifactID: "a", artifactSHA256: "SAME",
      timestampNanoseconds: 1, clockDomain: "fixture_camera", calibrationID: "cal",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, blurScore: 0.9, exposureScore: 0.9
    )
    let cam2 = NormalizedCameraObservation(
      observationID: "OBS-CAM-2", sampleID: "c2", artifactID: "a", artifactSHA256: "SAME",
      timestampNanoseconds: 2, clockDomain: "fixture_camera", calibrationID: "cal",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, blurScore: 0.9, exposureScore: 0.9
    )
    let depth1 = NormalizedDepthObservation(
      observationID: "OBS-DEPTH-1", sampleID: "d1", artifactID: "a", artifactSHA256: "d1",
      timestampNanoseconds: 1, clockDomain: "fixture_depth", calibrationID: "cal",
      width: 4, height: 4, pixelFormat: "FLOAT32_METERS", depthBytes: Data(count: 64),
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, depthValidityPercent: 90
    )
    let depth2 = NormalizedDepthObservation(
      observationID: "OBS-DEPTH-2", sampleID: "d2", artifactID: "a", artifactSHA256: "d2",
      timestampNanoseconds: 2, clockDomain: "fixture_depth", calibrationID: "cal",
      width: 4, height: 4, pixelFormat: "FLOAT32_METERS", depthBytes: Data(count: 64),
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, depthValidityPercent: 90
    )
    let pose1 = NormalizedPoseObservation(
      observationID: "OBS-POSE-1", sampleID: "p1", timestampNanoseconds: 1, clockDomain: "arkit_frame",
      translation: [0, 0, 0], transform4x4: HomogeneousMatrix4x4.identity(), trackingState: "NORMAL",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1
    )
    let pose2 = NormalizedPoseObservation(
      observationID: "OBS-POSE-2", sampleID: "p2", timestampNanoseconds: 2, clockDomain: "arkit_frame",
      translation: [0, 0, 0], transform4x4: HomogeneousMatrix4x4.identity(), trackingState: "NORMAL",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1
    )
    let set = try KeyframeSelector().select(
      candidates: [
        ReconstructionFrameCandidate(candidateID: "C1", associationID: "a1", cameraObservationID: "OBS-CAM-1", depthObservationID: "OBS-DEPTH-1", poseObservationID: "OBS-POSE-1", metrics: []),
        ReconstructionFrameCandidate(candidateID: "C2", associationID: "a2", cameraObservationID: "OBS-CAM-2", depthObservationID: "OBS-DEPTH-2", poseObservationID: "OBS-POSE-2", metrics: []),
      ],
      cameras: [cam1, cam2], depths: [depth1, depth2], poses: [pose1, pose2]
    )
    XCTAssertEqual(set.selectedCandidateIDs.count, 1)
    XCTAssertTrue(set.decisions.contains { !$0.selected && $0.reasonCodes.contains(FrameRejectionReason.duplicateFrame.rawValue) })
  }

  func testPrivacyPolicyForbidsReconstruction() throws {
    let sealed = try FixtureReconstructionPackageBuilder().seal(
      outputDirectory: try tempDir("priv"),
      allowReconstruction: false
    )
    let r = try ReconstructionPackageIngestor().ingest(packageRoot: sealed.package.rootURL)
    XCTAssertEqual(r.eligibility.outcome, .ineligiblePrivacyPolicy)
  }

  func testLineageReferenceMissingRejected() throws {
    var d = ReconstructionDerivationRecord(
      derivationID: "D", sourcePackageID: "", sourcePackageClosureSHA256: "",
      sourceManifestSHA256: "", sourceSampleIDs: [], sourceArtifactHashes: [],
      algorithm: ReconstructionLineageBuilder.algorithm,
      configuration: ReconstructionLineageBuilder.configurationDigest(policyIDs: ["p"], versions: ["v"]),
      policyIDs: ["p"], outputArtifactIDs: [], outputArtifactHashes: [],
      generationTimestamp: "2026-08-04T00:00:00Z", authority: "TEST_FIXTURE",
      reproducibilityStatus: "DETERMINISTIC_FIXTURE_REPLAY"
    )
    XCTAssertTrue(d.sourcePackageID.isEmpty)
    d.sourcePackageID = "P"
    let sealed = try ReconstructionLineageBuilder.sealLineage([d])
    XCTAssertFalse(sealed.lineageManifestSHA256.isEmpty)
  }

  func testNonFiniteDepthRegistrationMarksInvalid() throws {
    var bytes = ReconstructionFixtureDepthPayload.deterministicBytes()
    // Set first pixel to NaN
    var nan = Float.nan.bitPattern.littleEndian
    withUnsafeBytes(of: &nan) { bytes.replaceSubrange(0..<4, with: $0) }
    let depth = NormalizedDepthObservation(
      observationID: "d", sampleID: "d", artifactID: "a", artifactSHA256: "h",
      timestampNanoseconds: 1, clockDomain: "fixture_depth", calibrationID: "c",
      width: 4, height: 4, pixelFormat: "FLOAT32_METERS", depthBytes: bytes,
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1, depthValidityPercent: 50
    )
    let pose = NormalizedPoseObservation(
      observationID: "p", sampleID: "p", timestampNanoseconds: 1, clockDomain: "arkit_frame",
      translation: [0, 0, 0], transform4x4: HomogeneousMatrix4x4.identity(), trackingState: "NORMAL",
      frameEpochID: "e", sessionRunID: "r", worldOriginRevision: 1
    )
    let reg = try DepthPoseRegistrationEngine().register(
      depth: depth, pose: pose,
      calibration: .init(calibrationID: "c", fx: 100, fy: 100, cx: 1.5, cy: 1.5, width: 4, height: 4),
      depthToCamera: HomogeneousMatrix4x4.identity(),
      sourcePackageClosureSHA256: String(repeating: "d", count: 64),
      derivationID: "x"
    )
    XCTAssertGreaterThanOrEqual(reg.invalidDepthCount, 2) // nan + sentinel
  }

  func testSurfaceCandidateNotProductionMesh() throws {
    let (_, root) = try sealPrimary()
    let r = try ReconstructionPipeline().run(packageRoot: root, outputRoot: try tempDir("surf"))
    let meta = try XCTUnwrap(r.surface?.candidate?.metadata)
    XCTAssertEqual(meta.classification, "SYNTHETIC_FIXTURE_SURFACE_CANDIDATE")
    XCTAssertEqual(meta.productionMeshClaim, "FORBIDDEN")
    XCTAssertEqual(meta.vehicleMeshClaim, "FORBIDDEN")
    XCTAssertEqual(meta.engineeringDigitalTwinClaim, "FORBIDDEN")
  }

  func testAuthoritiesAreTestFixtureOnly() throws {
    let (sealed, _) = try sealPrimary()
    XCTAssertFalse(sealed.package.manifest.packageID.hasPrefix("SPKG-DEVICE-"))
    XCTAssertEqual(sealed.geometry.authority, "TEST_FIXTURE_GROUND_TRUTH")
  }

  // MARK: Helpers

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    try CanonicalJSON.data(object).write(to: url, options: .atomic)
  }

  private func refreshInventory(packageRoot: URL) throws {
    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: packageRoot)
    let closure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    let inv = try SpatialPackageReader().readJSONObject(packageRoot: packageRoot, name: "package_inventory.json")
    var next = inv
    next["entries"] = entries
    next["fixture_package_closure_sha256"] = closure
    try writeJSON(next, to: packageRoot.appendingPathComponent("package_inventory.json"))
  }
}
