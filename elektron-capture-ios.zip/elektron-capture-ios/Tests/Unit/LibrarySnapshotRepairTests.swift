import XCTest
@testable import ElektronCapture

private actor Repair04TestGate {
  private var entered = false
  private var entryWaiters: [CheckedContinuation<Void, Never>] = []
  private var releaseContinuation: CheckedContinuation<Void, Never>?

  func enterAndWait() async {
    entered = true
    entryWaiters.forEach { $0.resume() }
    entryWaiters.removeAll()
    await withCheckedContinuation { releaseContinuation = $0 }
  }

  func waitUntilEntered() async {
    if entered { return }
    await withCheckedContinuation { entryWaiters.append($0) }
  }

  func release() {
    releaseContinuation?.resume()
    releaseContinuation = nil
  }
}

final class LibrarySnapshotRepairTests: XCTestCase {
  private func record(_ id: String, session: String? = "INS-1") -> EvidenceLibraryIndexRecord {
    EvidenceLibraryIndexRecord(
      id: id, captureTimestamp: Date(timeIntervalSince1970: 1_700_000_000),
      sessionId: "CAP-\(id)", artifactId: "ART-\(id)", recordId: "REC-\(id)",
      inspectionSessionID: session,
      originalRelativePath: "captures/\(id)/artifact_original.jpg",
      thumbnailRelativePath: "captures/\(id)/thumbnail.jpg",
      originalSha256: String(repeating: "a", count: 64), originalByteCount: 1
    )
  }

  private func group(_ records: [EvidenceLibraryIndexRecord], session: String = "INS-1") -> InspectionEvidenceGroup {
    InspectionEvidenceGroup(
      sessionID: session, vehicleIdentifier: "VIN", vehicleIdentifierKind: "VIN",
      inspectorID: "I", inspectorName: "Inspector", startedAtUTC: "2026-01-01T00:00:00Z",
      sessionStatusAtLatestCapture: "IN_PROGRESS", latestCaptureAt: Date(), captures: records
    )
  }

  func testDeleteOneVisibleItem_sectionCountTransitionIsConsistent() throws {
    let before = try LibrarySnapshotBuilder.build(
      generation: 1, groups: [group([record("A"), record("B")])], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    let after = try LibrarySnapshotBuilder.build(
      generation: 2, groups: [group([record("B")])], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    XCTAssertEqual(after.itemCount, before.itemCount - 1)
  }

  func testInvalidSnapshot_preservesLastKnownGoodSnapshotAndSurfacesTypedError() throws {
    let good = try LibrarySnapshotBuilder.build(
      generation: 1, groups: [group([record("A")])], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    var published = good
    var surfaced: LibrarySnapshotError?
    do {
      published = try LibrarySnapshotBuilder.build(
        generation: 2, groups: [group([record("A"), record("A")])], unassigned: [],
        archivedSessionIDs: [], deletedSessionIDs: []
      )
    } catch let error as LibrarySnapshotError { surfaced = error }
    XCTAssertEqual(published, good)
    XCTAssertEqual(surfaced, .duplicateRowID(id: "A", section: "inspection:INS-1"))
  }

  func testDuplicateIDsCannotReachPublishedSnapshot() {
    XCTAssertThrowsError(try LibrarySnapshotBuilder.build(
      generation: 1, groups: [group([record("A"), record("A")])], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    ))
  }

  func testCrossSectionDuplicateCannotReachPublishedSnapshot() {
    XCTAssertThrowsError(try LibrarySnapshotBuilder.validate(LibrarySnapshot(
      generation: 1, live: [group([record("A")])],
      retainedFromDeleted: [], unassigned: [record("A", session: nil)]
    )))
  }

  func testTombstonedInspectionCannotReappearAfterRefresh() throws {
    let snapshot = try LibrarySnapshotBuilder.build(
      generation: 1, groups: [group([record("A")])], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: ["INS-1"]
    )
    XCTAssertTrue(snapshot.live.isEmpty)
    XCTAssertEqual(snapshot.retainedFromDeleted.map(\.id), ["A"])
  }

  func testStaleGenerationCannotOverwritePostDeleteSnapshot() async {
    let coordinator = LibraryMutationCoordinator()
    _ = try? await coordinator.perform(reason: .mutation) { generation in
      LibrarySnapshot(generation: generation, live: [], retainedFromDeleted: [], unassigned: [])
    }
    let acceptsStale = await coordinator.acceptsForPublication(0)
    XCTAssertFalse(acceptsStale)
  }

  func testDeletePublishesExactlyOneSnapshot() async throws {
    let coordinator = LibraryMutationCoordinator()
    var publications = 0
    if try await coordinator.perform(reason: .mutation, derive: { generation in
      LibrarySnapshot(generation: generation, live: [], retainedFromDeleted: [], unassigned: [])
    }) != nil { publications += 1 }
    XCTAssertEqual(publications, 1)
  }

  func testDeleteAndRefreshAreSerialized() async throws {
    let coordinator = LibraryMutationCoordinator()
    async let deletion = coordinator.perform(reason: .mutation, mutation: {
      await Task.yield()
    }, derive: { generation in
      LibrarySnapshot(generation: generation, live: [], retainedFromDeleted: [], unassigned: [])
    })
    async let refresh = coordinator.perform(reason: .refresh, derive: { generation in
      LibrarySnapshot(generation: generation, live: [], retainedFromDeleted: [], unassigned: [])
    })
    let results = try await [deletion, refresh]
    XCTAssertEqual(results.compactMap { $0 }.count, 1)
  }

  func testDuplicateDeleteRequestIsIdempotentOrRejected() async throws {
    let coordinator = LibraryMutationCoordinator()
    _ = try await coordinator.perform(reason: .mutation, derive: { generation in
      LibrarySnapshot(generation: generation, live: [], retainedFromDeleted: [], unassigned: [])
    })
    let generation = await coordinator.currentGeneration()
    XCTAssertEqual(generation, 1)
  }

  func testRuntimeCrashRegression_sectionOneCannotChangeFrom6To7WithoutSnapshotPublication() throws {
    let six = (0..<6).map { record("R\($0)") }
    let before = try LibrarySnapshotBuilder.build(
      generation: 10, groups: [group(six)], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    let seven = six + [record("R6")]
    let after = try LibrarySnapshotBuilder.build(
      generation: 11, groups: [group(seven)], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    XCTAssertEqual(before.live[0].captures.count, 6)
    XCTAssertEqual(after.live[0].captures.count, 7)
    XCTAssertEqual(after.revision, before.revision + 1)
    XCTAssertNotEqual(after, before)
  }

  func testSnapshotSectionsChangeAtomically() throws {
    let source = group([record("A"), record("B")])
    let live = try LibrarySnapshotBuilder.build(
      generation: 1, groups: [source], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    let deleted = try LibrarySnapshotBuilder.build(
      generation: 2, groups: [source], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: ["INS-1"]
    )
    XCTAssertEqual(live.live.count, 1)
    XCTAssertTrue(live.retainedFromDeleted.isEmpty)
    XCTAssertTrue(deleted.live.isEmpty)
    XCTAssertEqual(deleted.retainedFromDeleted.map(\.id), ["A", "B"])
  }

  func testDuplicateInspectionSectionCannotReachPublishedSnapshot() {
    XCTAssertThrowsError(try LibrarySnapshotBuilder.build(
      generation: 1,
      groups: [group([record("A")]), group([record("B")])],
      unassigned: [], archivedSessionIDs: [], deletedSessionIDs: []
    )) { error in
      XCTAssertEqual(error as? LibrarySnapshotError, .duplicateSectionID(id: "INS-1"))
    }
  }

  func testCoalescedInvalidationDoesNotCreateSecondPublication() async throws {
    let coordinator = LibraryMutationCoordinator()
    let gate = Repair04TestGate()
    async let first = coordinator.perform(
      reason: .mutation,
      mutationID: "delete:INS-1",
      mutation: { await gate.enterAndWait() },
      derive: { generation in
        LibrarySnapshot(generation: generation, live: [], retainedFromDeleted: [], unassigned: [])
      }
    )
    await gate.waitUntilEntered()
    let second = try await coordinator.perform(
      reason: .notification,
      derive: { generation in
        LibrarySnapshot(generation: generation, live: [], retainedFromDeleted: [], unassigned: [])
      }
    )
    await gate.release()
    let firstResult = try await first
    let results = [firstResult, second]
    XCTAssertEqual(results.compactMap { $0 }.count, 1)
    let coalesced = await coordinator.consumeQueuedReload()
    XCTAssertTrue(coalesced)
  }

  func testScenario_create_addEvidence_archive_refresh_unarchive_delete_refresh_relaunch() throws {
    let captured = group([record("A")])
    let created = try LibrarySnapshotBuilder.build(
      generation: 1, groups: [captured], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    let archived = try LibrarySnapshotBuilder.build(
      generation: 2, groups: [captured], unassigned: [],
      archivedSessionIDs: ["INS-1"], deletedSessionIDs: []
    )
    let restored = try LibrarySnapshotBuilder.build(
      generation: 3, groups: [captured], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    let deleted = try LibrarySnapshotBuilder.build(
      generation: 4, groups: [captured], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: ["INS-1"]
    )
    let relaunched = try LibrarySnapshotBuilder.build(
      generation: 5, groups: [captured], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: ["INS-1"]
    )
    XCTAssertEqual(created.live.count, 1)
    XCTAssertTrue(archived.live.isEmpty)
    XCTAssertEqual(restored.live.count, 1)
    XCTAssertTrue(deleted.live.isEmpty)
    XCTAssertEqual(deleted.retainedFromDeleted, relaunched.retainedFromDeleted)
  }

  func testScenario_viewInspection_createFromPlan_verifyNewID_restart_complete_delete() throws {
    let original = group([record("A")], session: "INS-1")
    let replacement = group([], session: "INS-2")
    let active = try LibrarySnapshotBuilder.build(
      generation: 1, groups: [original, replacement], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: []
    )
    let completedThenDeleted = try LibrarySnapshotBuilder.build(
      generation: 2, groups: [original, replacement], unassigned: [],
      archivedSessionIDs: [], deletedSessionIDs: ["INS-2"]
    )
    XCTAssertEqual(Set(active.live.map(\.sessionID)), ["INS-1", "INS-2"])
    XCTAssertFalse(completedThenDeleted.live.contains { $0.sessionID == "INS-2" })
    XCTAssertTrue(completedThenDeleted.live.contains { $0.sessionID == "INS-1" })
  }
}
