import XCTest
@testable import ElektronCapture

/// Authoritative Commit Propagation Contract — domain/persistence SSOT tests.
final class Sprint2_1F_AuthoritativeCommitTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_721_000_000)

  private func makeSnapshot(pointCount: Int = 2) throws -> InspectionPlanSnapshot {
    var points: [InspectionPoint] = []
    for i in 1...pointCount {
      points.append(
        try InspectionPoint(
          id: "p\(i)",
          title: "Point \(i)",
          displayOrder: i,
          isRequired: true
        )
      )
    }
    let plan = try InspectionPlan(
      id: "ssot_\(pointCount)",
      version: "1.0.0",
      title: "SSOT \(pointCount)",
      points: points
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession(id: String = "INS-20260726-215740-727C") throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "SSOT-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: try makeSnapshot(),
      assignedAt: fixedInstant
    )
  }

  private func pointID(_ raw: String) -> InspectionPointID { .unchecked(raw) }

  private func coordinator(persister: (any GuidedSessionPersisting)? = nil)
    -> GuidedInspectionCoordinator
  {
    GuidedInspectionCoordinator(
      instantProvider: FixedInstantProvider(fixedInstant),
      persister: persister
    )
  }

  // MARK: Persist → adopt identity

  func testSuccessfulBindKeepsStableSessionID() async throws {
    final class MemoryPersister: GuidedSessionPersisting, @unchecked Sendable {
      var last: InspectionSession?
      func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
        last = session
        return session
      }
    }
    let persister = MemoryPersister()
    let c = coordinator(persister: persister)
    var session = try makeSession()
    let originalID = session.id
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "lib-ssot-1", type: .photo, attributes: [:]),
      session: session
    ).session
    XCTAssertEqual(session.id, originalID)
    XCTAssertEqual(persister.last?.id, originalID)
    XCTAssertEqual(session.evidenceBindings?.bindings.count, 1)
  }

  func testPersistFailureLeavesCallerSessionUntouched() async throws {
    final class FailingPersister: GuidedSessionPersisting, @unchecked Sendable {
      func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
        throw GuidedInspectionPresentationError.persistence("disk full")
      }
    }
    let c = coordinator(persister: FailingPersister())
    var session = try makeSession()
    session = try await coordinator().handle(.prepareGuidedSession, session: session).session
    let priorID = session.id
    let priorBindings = session.evidenceBindings?.bindings.count ?? 0
    do {
      _ = try await c.handle(
        .bindApprovedCapture(storageKey: "lib-fail", type: .photo, attributes: [:]),
        session: session
      )
      XCTFail("expected persistence failure")
    } catch {
      XCTAssertEqual(session.id, priorID)
      XCTAssertEqual(session.evidenceBindings?.bindings.count ?? 0, priorBindings)
    }
  }

  func testManualRefreshReloadsCommittedSessionByStableID() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("ssot-refresh-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let c = coordinator(persister: service)
    var session = try makeSession(id: "INS-SSOT-REFRESH")
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "lib-refresh", type: .photo, attributes: [:]),
      session: session
    ).session
    let originalID = session.id
    let bindingCount = session.evidenceBindings?.bindings.count ?? 0

    // Simulate a separate process adopting from disk (Manual Refresh contract).
    let service2 = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let loaded = try await service2.restoreCurrentSession()
    let live = try XCTUnwrap(loaded)
    XCTAssertEqual(live.id, originalID)
    XCTAssertEqual(live.evidenceBindings?.bindings.count, bindingCount)
    XCTAssertEqual(live.progress?.activePointID, session.progress?.activePointID)
  }

  func testUnbindThenReloadDoesNotRestoreBinding() async throws {
    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("ssot-unbind-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: fileURL) }
    let service = InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    )
    let c = coordinator(persister: service)
    var session = try makeSession(id: "INS-SSOT-UNBIND")
    session = try await service.applyUpdatedSession(session)
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "EVD-4812", type: .photo, attributes: [:]),
      session: session
    ).session
    XCTAssertEqual(session.evidenceBindings?.bindings.count, 1)

    session = try await c.handle(
      .unbindLibraryEvidence(libraryEvidenceId: "EVD-4812"),
      session: session
    ).session
    XCTAssertEqual(session.evidenceBindings?.bindings.count ?? 0, 0)

    let restored = try await InspectionSessionService(
      repository: FileCurrentSessionRepository(fileURL: fileURL)
    ).restoreCurrentSession()
    let live = try XCTUnwrap(restored)
    XCTAssertEqual(live.id, session.id)
    XCTAssertEqual(live.evidenceBindings?.bindings.count ?? 0, 0)
  }

  // MARK: Multi-actor library index (deleted rows must not resurrect)

  func testSoftDeleteThenOtherStoreWriteDoesNotResurrectDeletedRow() async throws {
    let root = FileManager.default.temporaryDirectory
      .appendingPathComponent("ssot-lib-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: root) }

    let library = EvidenceLibraryStore(libraryRoot: root)
    let capture = EvidenceLibraryStore(libraryRoot: root)
    let jpeg = Self.fixtureJPEG
    let sha = ArtifactHashingService().sha256HexOfData(jpeg)

    let deletedIDs = Phase1CaptureIdentifiers(
      evidenceId: "EVD-4812",
      sessionId: "S1",
      artifactId: "A1",
      recordId: "R1"
    )
    _ = try await library.storeApproved(jpegBytes: jpeg, sha256: sha, ids: deletedIDs)
    // Prime Capture actor cache while EVD-4812 still exists.
    _ = try await capture.listInspectionCatalog(forceReload: true)
    let primed = try await capture.listInspectionCatalog(forceReload: false)
    XCTAssertEqual(Self.catalogCount(primed), 1)

    _ = try await library.softDeleteUserInitiated(id: "EVD-4812")
    EvidenceLibraryNotifications.postDidChange(evidenceId: "EVD-4812", sessionId: "S1")

    // Capture writes a *new* capture with a stale actor — must not resurrect EVD-4812.
    let nextIDs = Phase1CaptureIdentifiers(
      evidenceId: "EVD-4813",
      sessionId: "S1",
      artifactId: "A2",
      recordId: "R2"
    )
    _ = try await capture.storeApproved(jpegBytes: jpeg, sha256: sha, ids: nextIDs)

    let fresh = try await library.listInspectionCatalog(forceReload: true)
    let allIDs = Self.allRecordIDs(fresh)
    XCTAssertFalse(allIDs.contains("EVD-4812"), "soft-deleted id must stay gone after Capture write")
    XCTAssertTrue(allIDs.contains("EVD-4813"))
  }

  func testNotificationIsInvalidationOnlyNotAuthoritativeState() {
    // Contract: notifications carry ids for invalidation, not session aggregates.
    let exp = expectation(description: "didChange")
    let token = NotificationCenter.default.addObserver(
      forName: EvidenceLibraryNotifications.didChange,
      object: nil,
      queue: .main
    ) { note in
      XCTAssertEqual(
        note.userInfo?[EvidenceLibraryNotifications.userInfoEvidenceIdKey] as? String,
        "EVD-4812"
      )
      XCTAssertNil(note.userInfo?["session"])
      XCTAssertNil(note.userInfo?["bindings"])
      exp.fulfill()
    }
    defer { NotificationCenter.default.removeObserver(token) }
    EvidenceLibraryNotifications.postDidChange(
      evidenceId: "EVD-4812",
      sessionId: "INS-20260726-215740-727C"
    )
    wait(for: [exp], timeout: 1.0)
  }

  func testCompletedDoesNotImplyExportReady() throws {
    var session = try makeSession(id: "INS-SSOT-EXPORT")
    session = try coordinator().apply(.prepareGuidedSession, session: session).session
    session.status = .completed
    session.finishedAt = fixedInstant
    let ready = InspectionLifecycleEvaluator.readiness(for: session)
    XCTAssertEqual(ready.lifecycle, .completed)
    XCTAssertFalse(ready.isExportReady)
    XCTAssertEqual(ready.exportLabel, "Export Blocked")
  }

  // MARK: Helpers

  private static func catalogCount(_ catalog: InspectionEvidenceGrouping.Catalog) -> Int {
    catalog.unassigned.count + catalog.groups.reduce(0) { $0 + $1.captures.count }
  }

  private static func allRecordIDs(_ catalog: InspectionEvidenceGrouping.Catalog) -> Set<String> {
    var ids = Set(catalog.unassigned.map(\.id))
    for group in catalog.groups {
      ids.formUnion(group.captures.map(\.id))
    }
    return ids
  }

  private static var fixtureJPEG: Data {
    Data([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01,
      0x00, 0x01, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0xFF, 0xC4, 0x00, 0x14,
      0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F, 0x00, 0x7F, 0xFF, 0xD9,
    ])
  }
}
