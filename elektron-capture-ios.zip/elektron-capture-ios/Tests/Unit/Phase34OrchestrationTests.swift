import XCTest
@testable import ElektronCapture

final class Phase34OrchestrationTests: XCTestCase {
  private func tempDir(_ name: String = UUID().uuidString) throws -> URL {
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("p34-\(name)", isDirectory: true)
    try? FileManager.default.removeItem(at: url)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  private func makeCoordinator(
    camera: ControllableCameraSensorAdapter = ControllableCameraSensorAdapter(),
    motion: ControllableMotionSensorAdapter = ControllableMotionSensorAdapter(),
    pose: ControllablePoseSensorAdapter = ControllablePoseSensorAdapter(),
    depth: ControllableDepthSensorAdapter = ControllableDepthSensorAdapter(),
    policy: SpatialCaptureSessionPolicy = .primaryFixture(),
    sessionID: String = FixtureCoordinatedPackageBuilder.primarySessionID
  ) -> SpatialCaptureSessionCoordinator {
    SpatialCaptureSessionCoordinator(
      sessionID: sessionID,
      policy: policy,
      camera: camera,
      motion: motion,
      pose: pose,
      depth: depth
    )
  }

  // MARK: - Happy path

  func testValidFullCoordinatedSessionSealsPackage() async throws {
    let coord = makeCoordinator()
    let result = try await coord.runCoordinatedSession(outputDirectory: try tempDir("full"))
    XCTAssertTrue(result.sealed)
    let pkg = try XCTUnwrap(result.package)
    XCTAssertEqual(pkg.manifest.packageID, FixtureCoordinatedPackageBuilder.primaryPackageID)
    XCTAssertEqual(coord.state, .packaged)
    XCTAssertNil(result.degradedSummary)
    let root = pkg.rootURL
    for name in [
      "capability_snapshot.json",
      "session_policy.json",
      "session_timeline.json",
      "activation_plan.json",
      "stream_outcomes.json",
      "interruption_history.json",
      "buffer_summary.json",
      "clock_correlation.json",
      "coordinate_frames.json",
      "sample_index.json",
      "pose_associations.json",
      "rgb_depth_associations.json",
      "depth_calibration.json",
      "transform_graph.json",
      "manifest.json",
      "package_inventory.json",
    ] {
      XCTAssertTrue(
        FileManager.default.fileExists(atPath: root.appendingPathComponent(name).path),
        "missing \(name)"
      )
    }
    XCTAssertTrue(
      FileManager.default.fileExists(atPath: root.appendingPathComponent("payload/camera/0000.bin").path)
    )
    XCTAssertTrue(
      FileManager.default.fileExists(atPath: root.appendingPathComponent("payload/motion/0000.bin").path)
    )
    XCTAssertTrue(
      FileManager.default.fileExists(atPath: root.appendingPathComponent("payload/pose/0000.bin").path)
    )
    XCTAssertTrue(
      FileManager.default.fileExists(atPath: root.appendingPathComponent("payload/depth/0000.bin").path)
    )
  }

  func testDeterministicActivationPlan() throws {
    let a = makeCoordinator()
    try a.discoverAndPlan()
    let b = makeCoordinator()
    try b.discoverAndPlan()
    let pa = try XCTUnwrap(a.activationPlan)
    let pb = try XCTUnwrap(b.activationPlan)
    XCTAssertEqual(pa.planID, pb.planID)
    XCTAssertEqual(pa.entries.map(\.streamID), pb.entries.map(\.streamID))
    XCTAssertEqual(pa.entries.map(\.adapterID), pb.entries.map(\.adapterID))
    XCTAssertEqual(pa.entries.map(\.requirement), pb.entries.map(\.requirement))
    XCTAssertEqual(
      try CanonicalJSON.data(pa.asDictionary()),
      try CanonicalJSON.data(pb.asDictionary())
    )
  }

  // MARK: - Optional degradation

  func testOptionalDepthUnavailableDeviceDegradedValidPackage() async throws {
    let depth = ControllableDepthSensorAdapter()
    depth.unavailableDevice = true
    let coord = makeCoordinator(depth: depth)
    let result = try await coord.runCoordinatedSession(
      outputDirectory: try tempDir("nodepth"),
      packageID: FixtureCoordinatedPackageBuilder.noDepthPackageID
    )
    XCTAssertTrue(result.sealed)
    let summary = try XCTUnwrap(result.degradedSummary)
    XCTAssertTrue(summary.degradedStreams.contains(SpatialStreamID.depth))
    XCTAssertTrue(summary.stillValid)
    let pkg = try XCTUnwrap(result.package)
    XCTAssertFalse(
      FileManager.default.fileExists(
        atPath: pkg.rootURL.appendingPathComponent("rgb_depth_associations.json").path
      )
    )
    XCTAssertFalse(
      FileManager.default.fileExists(
        atPath: pkg.rootURL.appendingPathComponent("depth_calibration.json").path
      )
    )
    XCTAssertFalse(
      FileManager.default.fileExists(
        atPath: pkg.rootURL.appendingPathComponent("payload/depth").path
      )
    )
    let outcomes = coord.activationResults.first { $0.streamID == SpatialStreamID.depth }
    XCTAssertEqual(outcomes?.runtimeState, .unavailableDevice)
  }

  func testOptionalPoseInterruptDegradedPackage() async throws {
    let pose = ControllablePoseSensorAdapter()
    pose.interruptAfterStart = true
    let coord = makeCoordinator(
      pose: pose,
      sessionID: FixtureCoordinatedPackageBuilder.poseInterruptedSessionID
    )
    let result = try await coord.runCoordinatedSession(
      outputDirectory: try tempDir("poseint"),
      packageID: FixtureCoordinatedPackageBuilder.poseInterruptedPackageID
    )
    XCTAssertTrue(result.sealed)
    let summary = try XCTUnwrap(result.degradedSummary)
    XCTAssertTrue(summary.degradedStreams.contains(SpatialStreamID.pose))
    let pkg = try XCTUnwrap(result.package)
    XCTAssertFalse(
      FileManager.default.fileExists(
        atPath: pkg.rootURL.appendingPathComponent("pose_associations.json").path
      )
    )
    XCTAssertFalse(
      FileManager.default.fileExists(
        atPath: pkg.rootURL.appendingPathComponent("payload/pose").path
      )
    )
  }

  func testRequiredMotionActivationFailureFailedNoPackage() async throws {
    let motion = ControllableMotionSensorAdapter()
    motion.failOnStart = true
    let coord = makeCoordinator(motion: motion)
    do {
      _ = try await coord.runCoordinatedSession(outputDirectory: try tempDir("motfail"))
      XCTFail("expected required stream failure")
    } catch let SpatialEvidenceError.requiredStreamFailed(streamID, _) {
      XCTAssertEqual(streamID, SpatialStreamID.motion)
    }
    XCTAssertEqual(coord.state, .failed)
    XCTAssertNil(coord.sealedPackage)
  }

  // MARK: - Lifecycle guards

  func testDuplicateStartRejected() async throws {
    let coord = makeCoordinator()
    try coord.discoverAndPlan()
    try await coord.startStreams()
    do {
      try await coord.startStreams()
      XCTFail("expected duplicate start")
    } catch SpatialEvidenceError.duplicateStart {
      // expected
    }
  }

  func testDuplicateStopIdempotent() async throws {
    let coord = makeCoordinator()
    try coord.discoverAndPlan()
    try await coord.startStreams()
    try await coord.collectSamples()
    let first = try await coord.stopStreams()
    XCTAssertTrue(first)
    let second = try await coord.stopStreams()
    XCTAssertFalse(second) // already finalizing/stopped path
    XCTAssertEqual(coord.state, .finalizing)
  }

  func testStopBeforeStartCancelsWithoutPackage() async throws {
    let coord = makeCoordinator()
    let sealed = try await coord.stopStreams()
    XCTAssertFalse(sealed)
    XCTAssertEqual(coord.state, .cancelled)
    XCTAssertNil(coord.sealedPackage)
  }

  func testCancellationDuringCaptureNoSealedPackage() async throws {
    let coord = makeCoordinator()
    try coord.discoverAndPlan()
    try await coord.startStreams()
    try await coord.collectSamples()
    try coord.cancel()
    XCTAssertEqual(coord.state, .cancelled)
    let result = try coord.finalizePackage(outputDirectory: try tempDir("cancel"))
    XCTAssertFalse(result.sealed)
    XCTAssertNil(coord.sealedPackage)
  }

  func testInterruptionAndRecoverySuccess() async throws {
    let coord = makeCoordinator()
    try coord.discoverAndPlan()
    try await coord.startStreams()
    try coord.interrupt(streamID: SpatialStreamID.pose, reason: "test_interrupt", recoverable: true)
    XCTAssertEqual(coord.state, .interrupted)
    let decision = try coord.recover(decision: .resumeCapturing)
    XCTAssertEqual(decision, .resumeCapturing)
    XCTAssertEqual(coord.state, .capturing)
    try await coord.collectSamples()
    _ = try await coord.stopStreams()
    let result = try coord.finalizePackage(outputDirectory: try tempDir("recover"))
    XCTAssertTrue(result.sealed)
  }

  func testInvalidStateTransitionRejected() throws {
    let coord = makeCoordinator()
    XCTAssertThrowsError(try coord.interrupt(streamID: SpatialStreamID.pose, reason: "nope")) { err in
      guard case SpatialEvidenceError.invalidTransition = err else {
        return XCTFail("\(err)")
      }
    }
  }

  // MARK: - Sample acceptance

  func testSampleAfterStopRejected() async throws {
    let coord = makeCoordinator()
    try coord.discoverAndPlan()
    try await coord.startStreams()
    try await coord.collectSamples()
    _ = try await coord.stopStreams()
    let cam = ControllableCameraSensorAdapter()
    cam.clockDomain = .fixtureCamera
    try await cam.start()
    var samples: [SpatialSampleEnvelope<CameraSample>] = []
    for try await s in cam.samples() { samples.append(s) }
    await cam.stop()
    let sample = try XCTUnwrap(samples.first)
    XCTAssertThrowsError(try coord.acceptCameraSample(sample)) { err in
      guard case SpatialEvidenceError.sampleRejected = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testDuplicateSampleIDRejected() async throws {
    let coord = makeCoordinator()
    try coord.discoverAndPlan()
    try await coord.startStreams()
    try await coord.collectSamples()
    let first = try XCTUnwrap(coord.cameraSamples.first)
    XCTAssertThrowsError(try coord.acceptCameraSample(first)) { err in
      guard case SpatialEvidenceError.sampleRejected(let reason) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertTrue(reason.contains("duplicate_sample_id"), reason)
    }
  }

  func testTimestampRegressionRejected() async throws {
    let coord = makeCoordinator()
    try coord.discoverAndPlan()
    try await coord.startStreams()
    try await coord.collectSamples()
    let first = try XCTUnwrap(coord.cameraSamples.first)
    let regress = SpatialSampleEnvelope(
      sampleID: "cam-regress",
      sequenceIndex: 99,
      acquisitionTimestampNs: first.acquisitionTimestampNs &- 1,
      clockDomain: .fixtureCamera,
      coordinateFrameID: first.coordinateFrameID,
      payload: first.payload,
      mediaType: first.mediaType,
      schemaID: first.schemaID,
      schemaVersion: first.schemaVersion
    )
    XCTAssertThrowsError(try coord.acceptCameraSample(regress)) { err in
      guard case SpatialEvidenceError.sampleRejected(let reason) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertTrue(reason.contains("timestamp_regression"), reason)
    }
  }

  func testBufferOverflowWithDropOldestPolicy() async throws {
    var policy = SpatialCaptureSessionPolicy.primaryFixture()
    policy.bufferPolicy = CaptureBufferPolicy(
      maxQueuedSamplesPerStream: 1,
      maxQueuedBytes: 1_000_000,
      dropPolicy: .dropOldest
    )
    let coord = makeCoordinator(policy: policy)
    try coord.discoverAndPlan()
    try await coord.startStreams()
    let bytes = Data(count: 16)
    let payload = CameraSample(
      width: 4, height: 4, pixelFormat: "BGRA8", bytes: bytes,
      orientation: "up", cameraIdentity: "t", intrinsicsAvailable: false
    )
    for i in 0..<3 {
      let env = SpatialSampleEnvelope(
        sampleID: "cam-buf-\(i)",
        sequenceIndex: UInt64(i),
        acquisitionTimestampNs: UInt64(i + 1) * 1_000_000,
        clockDomain: .fixtureCamera,
        coordinateFrameID: "FRAME_CAMERA_OPTICAL",
        payload: payload,
        mediaType: "application/octet-stream",
        schemaID: "CameraSample",
        schemaVersion: "1.0.0-phase3-fixture"
      )
      _ = try coord.acceptCameraSample(env)
    }
    XCTAssertEqual(coord.cameraSamples.count, 1)
    XCTAssertEqual(coord.cameraSamples.first?.sampleID, "cam-buf-2")
    XCTAssertGreaterThan(coord.bufferState.droppedOldestCount, 0)
  }

  func testBufferOverflowDropNewest() async throws {
    var policy = SpatialCaptureSessionPolicy.primaryFixture()
    policy.bufferPolicy = CaptureBufferPolicy(
      maxQueuedSamplesPerStream: 1,
      maxQueuedBytes: 1_000_000,
      dropPolicy: .dropNewest
    )
    let coord = makeCoordinator(policy: policy)
    try coord.discoverAndPlan()
    try await coord.startStreams()
    let bytes = Data(count: 16)
    let payload = CameraSample(
      width: 4, height: 4, pixelFormat: "BGRA8", bytes: bytes,
      orientation: "up", cameraIdentity: "t", intrinsicsAvailable: false
    )
    let a = SpatialSampleEnvelope(
      sampleID: "cam-a", sequenceIndex: 0, acquisitionTimestampNs: 1_000_000,
      clockDomain: .fixtureCamera, coordinateFrameID: "FRAME_CAMERA_OPTICAL",
      payload: payload, mediaType: "application/octet-stream",
      schemaID: "CameraSample", schemaVersion: "1.0.0-phase3-fixture"
    )
    let b = SpatialSampleEnvelope(
      sampleID: "cam-b", sequenceIndex: 1, acquisitionTimestampNs: 2_000_000,
      clockDomain: .fixtureCamera, coordinateFrameID: "FRAME_CAMERA_OPTICAL",
      payload: payload, mediaType: "application/octet-stream",
      schemaID: "CameraSample", schemaVersion: "1.0.0-phase3-fixture"
    )
    XCTAssertEqual(try coord.acceptCameraSample(a), .accepted)
    let dropped = try coord.acceptCameraSample(b)
    guard case .droppedByPolicy = dropped else {
      return XCTFail("expected drop newest, got \(dropped)")
    }
    XCTAssertEqual(coord.cameraSamples.count, 1)
    XCTAssertEqual(coord.cameraSamples.first?.sampleID, "cam-a")
  }

  func testFinalizationWithActiveAdapterRejected() async throws {
    let coord = makeCoordinator()
    try coord.discoverAndPlan()
    try await coord.startStreams()
    try await coord.collectSamples()
    XCTAssertThrowsError(try coord.finalizePackage(outputDirectory: try tempDir("active"))) { err in
      guard case SpatialEvidenceError.finalizationRejected = err else {
        return XCTFail("\(err)")
      }
    }
    _ = try await coord.stopStreams()
    // Simulate leaked active adapters after reaching FINALIZING.
    coord.markAdaptersActiveForTesting(true)
    XCTAssertThrowsError(try coord.finalizePackage(outputDirectory: try tempDir("active2"))) { err in
      guard case SpatialEvidenceError.finalizationRejected(let reason) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertTrue(reason.contains("active_adapters"), reason)
    }
  }

  // MARK: - Package integrity

  func testCapabilityStandaloneMatchesEmbedded() async throws {
    let coord = makeCoordinator()
    let result = try await coord.runCoordinatedSession(outputDirectory: try tempDir("cap-agree"))
    let pkg = try XCTUnwrap(result.package)
    let stand = try Data(contentsOf: pkg.rootURL.appendingPathComponent("capability_snapshot.json"))
    let manifest = try Data(contentsOf: pkg.rootURL.appendingPathComponent("manifest.json"))
    let standObj = try JSONSerialization.jsonObject(with: stand) as! [String: Any]
    let manObj = try JSONSerialization.jsonObject(with: manifest) as! [String: Any]
    let embedded = manObj["capability"] as! [String: Any]
    XCTAssertEqual(standObj["schema_version"] as? String, "1.0.0-phase3-fixture")
    XCTAssertEqual(embedded["schema_version"] as? String, "1.0.0-phase3-fixture")
    XCTAssertEqual(standObj["snapshot_id"] as? String, embedded["snapshot_id"] as? String)
  }

  func testInventoryReorderDoesNotChangeClosure() async throws {
    let coord = makeCoordinator()
    let result = try await coord.runCoordinatedSession(outputDirectory: try tempDir("closure-reorder"))
    let pkg = try XCTUnwrap(result.package)
    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: pkg.rootURL)
    let h1 = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    let h2 = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: Array(entries.reversed()))
    XCTAssertEqual(h1, h2)
    XCTAssertEqual(h1, pkg.packageClosureSHA256)
  }

  func testDeterministicRegenerationIdenticalDigests() async throws {
    let a = try await makeCoordinator().runCoordinatedSession(outputDirectory: try tempDir("det-a"))
    let b = try await makeCoordinator().runCoordinatedSession(outputDirectory: try tempDir("det-b"))
    let pa = try XCTUnwrap(a.package)
    let pb = try XCTUnwrap(b.package)
    XCTAssertEqual(pa.packageContentSHA256, pb.packageContentSHA256)
    XCTAssertEqual(pa.manifestSHA256, pb.manifestSHA256)
    XCTAssertEqual(pa.packageClosureSHA256, pb.packageClosureSHA256)
  }

  func testCheckpointPreventsDuplicateSampleIDsOnRecovery() async throws {
    let coord = makeCoordinator()
    try coord.discoverAndPlan()
    try await coord.startStreams()
    try await coord.collectSamples()
    let cp = try coord.checkpoint()
    XCTAssertFalse(cp.acceptedSampleIDs.isEmpty)
    try coord.interrupt(streamID: SpatialStreamID.depth, reason: "ckpt_test")
    _ = try coord.recover(decision: .resumeCapturing)
    try coord.restoreCheckpoint(cp)
    let first = try XCTUnwrap(coord.cameraSamples.first)
    XCTAssertThrowsError(try coord.acceptCameraSample(first)) { err in
      guard case SpatialEvidenceError.sampleRejected(let reason) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertTrue(reason.contains("duplicate_sample_id"), reason)
    }
  }

  // MARK: - Golden writer

  func testWriteCoordinatedGoldenWhenRequested() async throws {
    guard ProcessInfo.processInfo.environment["PHASE34_WRITE_GOLDEN"] == "1" else {
      throw XCTSkip("Set PHASE34_WRITE_GOLDEN=1 to emit coordinated package fixtures")
    }
    let outRoot = ProcessInfo.processInfo.environment["PHASE34_GOLDEN_OUT"].flatMap {
      $0.isEmpty ? nil : URL(fileURLWithPath: $0, isDirectory: true)
    } ?? URL(fileURLWithPath: #file)
      .deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
      .appendingPathComponent("Docs/Evidence/SPRINT_3_4", isDirectory: true)
    try FileManager.default.createDirectory(at: outRoot, withIntermediateDirectories: true)

    // 1) Full coordinated
    let primaryOut = outRoot.appendingPathComponent(
      FixtureCoordinatedPackageBuilder.primaryPackageID, isDirectory: true
    )
    try? FileManager.default.removeItem(at: primaryOut)
    let primary = try await makeCoordinator().runCoordinatedSession(
      outputDirectory: try tempDir("golden-primary")
    )
    let primaryPkg = try XCTUnwrap(primary.package)
    try FileManager.default.copyItem(at: primaryPkg.rootURL, to: primaryOut)
    try writeInventorySidecar(
      outRoot: outRoot,
      filename: "coordinated_package_inventory.json",
      schemaID: "Sprint34FixturePackageInventory",
      package: primaryPkg,
      note: "Primary coordinated camera+motion+pose+depth fixture"
    )

    // 2) No depth
    let depth = ControllableDepthSensorAdapter()
    depth.unavailableDevice = true
    let noDepthOut = outRoot.appendingPathComponent(
      FixtureCoordinatedPackageBuilder.noDepthPackageID, isDirectory: true
    )
    try? FileManager.default.removeItem(at: noDepthOut)
    let noDepth = try await makeCoordinator(
      depth: depth,
      sessionID: FixtureCoordinatedPackageBuilder.noDepthSessionID
    ).runCoordinatedSession(
      outputDirectory: try tempDir("golden-nodepth"),
      packageID: FixtureCoordinatedPackageBuilder.noDepthPackageID
    )
    let noDepthPkg = try XCTUnwrap(noDepth.package)
    try FileManager.default.copyItem(at: noDepthPkg.rootURL, to: noDepthOut)
    try writeInventorySidecar(
      outRoot: outRoot,
      filename: "coordinated_nodepth_package_inventory.json",
      schemaID: "Sprint34NoDepthFixturePackageInventory",
      package: noDepthPkg,
      note: "Coordinated fixture with optional depth UNAVAILABLE_DEVICE"
    )

    // 3) Pose interrupted
    let pose = ControllablePoseSensorAdapter()
    pose.interruptAfterStart = true
    let poseIntOut = outRoot.appendingPathComponent(
      FixtureCoordinatedPackageBuilder.poseInterruptedPackageID, isDirectory: true
    )
    try? FileManager.default.removeItem(at: poseIntOut)
    let poseInt = try await makeCoordinator(
      pose: pose,
      sessionID: FixtureCoordinatedPackageBuilder.poseInterruptedSessionID
    ).runCoordinatedSession(
      outputDirectory: try tempDir("golden-poseint"),
      packageID: FixtureCoordinatedPackageBuilder.poseInterruptedPackageID
    )
    let poseIntPkg = try XCTUnwrap(poseInt.package)
    try FileManager.default.copyItem(at: poseIntPkg.rootURL, to: poseIntOut)
    try writeInventorySidecar(
      outRoot: outRoot,
      filename: "coordinated_poseint_package_inventory.json",
      schemaID: "Sprint34PoseInterruptedFixturePackageInventory",
      package: poseIntPkg,
      note: "Coordinated fixture with optional pose INTERRUPTED_AFTER_ACTIVATION"
    )
  }

  private func writeInventorySidecar(
    outRoot: URL,
    filename: String,
    schemaID: String,
    package: SpatialEvidencePackage,
    note: String
  ) throws {
    let closure = try XCTUnwrap(package.packageClosureSHA256)
    try CanonicalJSON.data([
      "schema_id": schemaID,
      "schema_version": "1.0.0",
      "package_id": package.manifest.packageID,
      "capture_session_id": package.manifest.captureSessionID,
      "fixture_payload_content_sha256": package.packageContentSHA256,
      "fixture_manifest_sha256": package.manifestSHA256,
      "fixture_package_closure_sha256": closure,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "evidence_origin_authority": "TEST_FIXTURE",
      "host_claim": "NO_PHYSICAL_DEVICE_EXECUTION",
      "note": note,
    ] as [String: Any]).write(
      to: outRoot.appendingPathComponent(filename),
      options: .atomic
    )
  }
}
