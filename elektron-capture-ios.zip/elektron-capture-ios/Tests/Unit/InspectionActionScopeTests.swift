import XCTest
@testable import ElektronCapture

/// T-XC-03 — detail-screen actions target the inspection being viewed, never `current`.
final class InspectionActionScopeTests: XCTestCase {
  private func availability(
    _ action: InspectionDetailAction,
    groupID: String = "INS-VIEWED",
    currentSessionID: String? = "INS-CURRENT",
    currentStatus: SessionStatus? = .inProgress,
    isArchived: Bool = false,
    isDeleted: Bool = false,
    canCommitCompletion: Bool = true
  ) -> InspectionActionAvailability {
    InspectionActionScope.availability(
      action: action,
      groupID: groupID,
      currentSessionID: currentSessionID,
      currentStatus: currentStatus,
      isArchived: isArchived,
      isDeleted: isDeleted,
      canCommitCompletion: canCommitCompletion
    )
  }

  /// Every action, in every configuration, targets the viewed group.
  func testEveryActionTargetsTheViewedGroup() {
    for action in InspectionDetailAction.allCases {
      for current in ["INS-CURRENT", "INS-VIEWED", nil] as [String?] {
        let entry = availability(action, currentSessionID: current)
        XCTAssertEqual(
          entry.targetSessionID,
          "INS-VIEWED",
          "\(action.rawValue) must act on the viewed inspection"
        )
      }
    }
  }

  /// Live-session-only actions are disabled — with a reason — on a historical inspection.
  func testCurrentSessionActionsAreDisabledWithAReasonOnHistoricalGroups() {
    for action in InspectionDetailAction.allCases where action.requiresBeingTheActiveSession {
      let entry = availability(action, currentSessionID: "INS-SOMETHING-ELSE")
      XCTAssertFalse(entry.isEnabled, "\(action.rawValue) must not act on a different inspection")
      XCTAssertEqual(entry.disabledReason, "Only available for the inspection currently open in Capture.")
    }
  }

  func testCurrentSessionActionsAreEnabledWhenTheGroupIsTheActiveSession() {
    for action in InspectionDetailAction.allCases where action.requiresBeingTheActiveSession {
      let entry = availability(action, currentSessionID: "INS-VIEWED")
      XCTAssertTrue(entry.isEnabled, "\(action.rawValue) should be available for the live session")
      XCTAssertNil(entry.disabledReason)
    }
  }

  func testFinishedSessionCannotBeChanged() {
    let entry = availability(.saveAndExit, currentSessionID: "INS-VIEWED", currentStatus: .completed)
    XCTAssertFalse(entry.isEnabled)
    XCTAssertEqual(entry.disabledReason, "This inspection is finished and cannot be changed.")
  }

  func testCompleteRequiresResolvedPoints() {
    let entry = availability(
      .completeInspection,
      currentSessionID: "INS-VIEWED",
      canCommitCompletion: false
    )
    XCTAssertFalse(entry.isEnabled)
    XCTAssertEqual(entry.disabledReason, "Resolve every required point before completing.")
  }

  /// Delete works in every lifecycle state, on any group, including with zero captures.
  func testDeleteIsAvailableRegardlessOfLifecycleOrCurrency() {
    for status in [SessionStatus.inProgress, .paused, .completed, .canceled] {
      let entry = availability(.deleteInspection, currentSessionID: "INS-OTHER", currentStatus: status)
      XCTAssertTrue(entry.isEnabled, "delete must be offered for a \(status.rawValue) inspection")
    }
    XCTAssertTrue(availability(.deleteInspection, currentSessionID: nil, currentStatus: nil).isEnabled)
  }

  func testArchiveAndUnarchiveAreMutuallyExclusive() {
    XCTAssertTrue(availability(.archiveInspection, isArchived: false).isEnabled)
    XCTAssertFalse(availability(.archiveInspection, isArchived: true).isEnabled)
    XCTAssertFalse(availability(.unarchiveInspection, isArchived: false).isEnabled)
    XCTAssertTrue(availability(.unarchiveInspection, isArchived: true).isEnabled)
  }

  func testDeletedInspectionOffersNothing() {
    for action in InspectionDetailAction.allCases {
      let entry = availability(action, isDeleted: true)
      XCTAssertFalse(entry.isEnabled)
      XCTAssertEqual(entry.disabledReason, "This inspection has been deleted.")
    }
  }

  func testMenuCoversEveryActionExactlyOnce() {
    let menu = InspectionActionScope.menu(
      groupID: "INS-VIEWED",
      currentSessionID: "INS-VIEWED",
      currentStatus: .inProgress,
      isArchived: false,
      isDeleted: false,
      canCommitCompletion: true
    )
    XCTAssertEqual(menu.count, InspectionDetailAction.allCases.count)
    XCTAssertEqual(Set(menu.map(\.action)).count, menu.count)
    XCTAssertTrue(menu.allSatisfy { $0.targetSessionID == "INS-VIEWED" })
  }
}
