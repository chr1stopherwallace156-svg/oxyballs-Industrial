import XCTest
@testable import ElektronCapture

final class Phase3SyntheticSpatialEvidenceTests: XCTestCase {
  private func tempDir(_ name: String = UUID().uuidString) throws -> URL {
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("p3-\(name)", isDirectory: true)
    try? FileManager.default.removeItem(at: url)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  func testDeterministicSyntheticReplayStableHash() async throws {
    let a = try await sealDefault(dirName: "a")
    let b = try await sealDefault(dirName: "b")
    XCTAssertEqual(a.packageContentSHA256, b.packageContentSHA256)
    XCTAssertEqual(a.manifestSHA256, b.manifestSHA256)
    XCTAssertEqual(a.manifest.artifacts.map(\.relativePath), b.manifest.artifacts.map(\.relativePath))
  }

  func testStableCanonicalOrdering() async throws {
    let pkg = try await sealDefault(dirName: "order")
    let paths = pkg.manifest.artifacts.map(\.relativePath)
    XCTAssertEqual(paths, paths.sorted())
    let data = try CanonicalJSON.data(pkg.manifest.asDictionary())
    let again = try CanonicalJSON.data(pkg.manifest.asDictionary())
    XCTAssertEqual(data, again)
  }

  func testRGBOnlyOperation() async throws {
    let coord = SyntheticSpatialSensorCoordinator(includeDepth: false, depthEmitsSamples: false)
    let session = DraftSpatialCaptureSession(
      sessionID: "SESS-RGB",
      vehicleID: "VEH-000001",
      pilotID: "PILOT-000001",
      coordinator: coord,
      allowedFrameIDs: [CoordinateFrameDescriptor.syntheticWorld.frameID]
    )
    let dir = try tempDir("rgb")
    let pkg = try await session.runToPackaged(outputDirectory: dir)
    XCTAssertTrue(pkg.manifest.artifacts.contains { $0.streamID == "camera" })
    XCTAssertFalse(pkg.manifest.artifacts.contains { $0.streamID == "depth" })
    let depthCap = pkg.manifest.capability.streams.first { $0.sensorKind == "depth" }
    XCTAssertEqual(depthCap?.finalOutcome, .unavailable)
    XCTAssertEqual(depthCap?.samplesAcquired, 0)
    XCTAssertEqual(session.status, .packagedBoundary)
  }

  func testHonestNoDepthBehavior() async throws {
    let coord = SyntheticSpatialSensorCoordinator(includeDepth: true, depthEmitsSamples: false)
    let session = DraftSpatialCaptureSession(
      sessionID: "SESS-NODEPTH",
      vehicleID: "VEH-000001",
      coordinator: coord,
      allowedFrameIDs: [CoordinateFrameDescriptor.syntheticWorld.frameID]
    )
    let pkg = try await session.runToPackaged(outputDirectory: try tempDir("nodepth"))
    let depth = pkg.manifest.capability.streams.first { $0.sensorKind == "depth" }
    XCTAssertEqual(depth?.stage, .finalOutcome)
    XCTAssertEqual(depth?.finalOutcome, .unavailable)
    XCTAssertEqual(depth?.samplesAcquired, 0)
  }

  func testOptionalDepthStreamDegradationPresentWhenEmitted() async throws {
    let pkg = try await sealDefault(dirName: "depth-on")
    let depth = pkg.manifest.capability.streams.first { $0.sensorKind == "depth" }
    XCTAssertEqual(depth?.finalOutcome, .acquired)
    XCTAssertGreaterThan(depth?.samplesAcquired ?? 0, 0)
  }

  func testClockMismatchRejection() async throws {
    let bad = SyntheticCameraSensorAdapter(clockDomain: .wall)
    let samples = try await bad.nextSamples(count: 1)
    XCTAssertEqual(samples.first?.clockDomain, .wall)
    let coord = SyntheticSpatialSensorCoordinator()
    // Inject via custom session validation path using mismatched coordinator frame clock on a custom bundle seal.
    var bundle = try await coord.collectDeterministicBundle()
    // Replace camera with wrong clock domain samples.
    bundle.camera = samples
    let builder = SpatialEvidencePackageBuilder()
    // Draft session validates before seal — exercise session path:
    let session = DraftSpatialCaptureSession(
      sessionID: "SESS-CLK",
      vehicleID: "VEH-000001",
      coordinator: MismatchedClockCoordinator(inner: coord, cameraOverride: samples),
      allowedFrameIDs: [CoordinateFrameDescriptor.syntheticWorld.frameID],
      expectedClockDomain: .syntheticDeterministic
    )
    do {
      _ = try await session.runToPackaged(outputDirectory: try tempDir("clk"))
      XCTFail("expected clock mismatch")
    } catch let SpatialEvidenceError.clockDomainMismatch(expected, actual) {
      XCTAssertEqual(expected, ClockDomain.syntheticDeterministic.rawValue)
      XCTAssertEqual(actual, ClockDomain.wall.rawValue)
    }
    XCTAssertEqual(session.status, .capturing) // failed before captureComplete if throw during collect... actually after activate, during validate after collect - status set captureComplete then validating. Wait: validate is after captureComplete assignment. Looking at code: collect then validate then status=captureComplete. Order is: collect, validate, then captureComplete. So on validate fail status still capturing. Good.
    _ = builder
  }

  func testCoordinateFrameRejection() async throws {
    let session = DraftSpatialCaptureSession(
      sessionID: "SESS-FRAME",
      vehicleID: "VEH-000001",
      coordinator: SyntheticSpatialSensorCoordinator(),
      allowedFrameIDs: ["FRAME_OTHER_ONLY"]
    )
    do {
      _ = try await session.runToPackaged(outputDirectory: try tempDir("frame"))
      XCTFail("expected frame reject")
    } catch let SpatialEvidenceError.coordinateFrameRejected(id) {
      XCTAssertEqual(id, CoordinateFrameDescriptor.syntheticWorld.frameID)
    }
  }

  func testMissingArtifactRejection() async throws {
    let pkg = try await sealDefault(dirName: "missing")
    let victim = pkg.manifest.artifacts[0]
    try FileManager.default.removeItem(at: pkg.rootURL.appendingPathComponent(victim.relativePath))
    XCTAssertThrowsError(try SpatialPackageClosureVerifier.verify(packageRoot: pkg.rootURL, manifest: pkg.manifest)) { err in
      guard case SpatialEvidenceError.missingArtifact = err else {
        return XCTFail("wrong error \(err)")
      }
    }
  }

  func testOrphanPayloadRejection() async throws {
    let pkg = try await sealDefault(dirName: "orphan")
    let orphan = pkg.rootURL.appendingPathComponent("artifacts/camera/orphan.bin")
    try Data([1, 2, 3]).write(to: orphan)
    XCTAssertThrowsError(try SpatialPackageClosureVerifier.verify(packageRoot: pkg.rootURL, manifest: pkg.manifest)) { err in
      guard case SpatialEvidenceError.orphanArtifact = err else {
        return XCTFail("wrong error \(err)")
      }
    }
  }

  func testByteLengthMismatchRejection() async throws {
    let pkg = try await sealDefault(dirName: "bytelen")
    let victim = pkg.manifest.artifacts[0]
    try Data([9, 9, 9, 9, 9]).write(to: pkg.rootURL.appendingPathComponent(victim.relativePath))
    XCTAssertThrowsError(try SpatialPackageClosureVerifier.verify(packageRoot: pkg.rootURL, manifest: pkg.manifest)) { err in
      guard case SpatialEvidenceError.byteLengthMismatch = err else {
        return XCTFail("wrong error \(err)")
      }
    }
  }

  func testSHA256MismatchRejection() async throws {
    let pkg = try await sealDefault(dirName: "sha")
    var arts = pkg.manifest.artifacts
    let bad = SpatialArtifactDescriptor(
      relativePath: arts[0].relativePath,
      byteLength: arts[0].byteLength,
      sha256: String(repeating: "0", count: 64),
      mediaType: arts[0].mediaType,
      schemaID: arts[0].schemaID,
      schemaVersion: arts[0].schemaVersion,
      sampleID: arts[0].sampleID,
      streamID: arts[0].streamID,
      adapterID: arts[0].adapterID
    )
    arts[0] = bad
    let mangled = SpatialEvidenceManifest(
      packageID: pkg.manifest.packageID,
      vehicleID: pkg.manifest.vehicleID,
      captureSessionID: pkg.manifest.captureSessionID,
      pilotID: pkg.manifest.pilotID,
      createdAtUTC: pkg.manifest.createdAtUTC,
      capability: pkg.manifest.capability,
      frames: pkg.manifest.frames,
      clockCorrelations: pkg.manifest.clockCorrelations,
      artifacts: arts,
      sampleIndex: pkg.manifest.sampleIndex
    )
    XCTAssertThrowsError(try SpatialPackageClosureVerifier.verify(packageRoot: pkg.rootURL, manifest: mangled)) { err in
      guard case SpatialEvidenceError.sha256Mismatch = err else {
        return XCTFail("wrong error \(err)")
      }
    }
  }

  func testUnsupportedSchemaRejection() async throws {
    let coord = SyntheticSpatialSensorCoordinator()
    _ = try await coord.activateAll()
    var bundle = try await coord.collectDeterministicBundle()
    // Corrupt schema on first camera sample via rebuild
    let s = bundle.camera[0]
    bundle.camera[0] = SpatialSampleEnvelope(
      sampleID: s.sampleID,
      sequenceIndex: s.sequenceIndex,
      acquisitionTimestampNs: s.acquisitionTimestampNs,
      clockDomain: s.clockDomain,
      coordinateFrameID: s.coordinateFrameID,
      payload: s.payload,
      mediaType: s.mediaType,
      schemaID: "CameraSample",
      schemaVersion: "9.9.9-unsupported"
    )
    let builder = SpatialEvidencePackageBuilder()
    XCTAssertThrowsError(
      try builder.seal(
        sessionID: "SESS-SCHEMA",
        vehicleID: "VEH-000001",
        pilotID: nil,
        bundle: &bundle,
        outputDirectory: try tempDir("schema")
      )
    ) { err in
      guard case SpatialEvidenceError.unsupportedSchema = err else {
        return XCTFail("wrong error \(err)")
      }
    }
  }

  func testCancellationBehavior() async throws {
    let session = DraftSpatialCaptureSession(
      sessionID: "SESS-CANCEL",
      vehicleID: "VEH-000001",
      coordinator: SyntheticSpatialSensorCoordinator(),
      allowedFrameIDs: [CoordinateFrameDescriptor.syntheticWorld.frameID]
    )
    XCTAssertThrowsError(try session.cancel()) { err in
      XCTAssertEqual(err as? SpatialEvidenceError, .cancelled)
    }
    XCTAssertEqual(session.status, .cancelled)
  }

  func testInterruptionBehavior() async throws {
    let session = DraftSpatialCaptureSession(
      sessionID: "SESS-INT",
      vehicleID: "VEH-000001",
      coordinator: SyntheticSpatialSensorCoordinator(),
      allowedFrameIDs: [CoordinateFrameDescriptor.syntheticWorld.frameID]
    )
    XCTAssertThrowsError(try session.interrupt("lock_screen")) { err in
      guard case SpatialEvidenceError.interrupted(let r) = err else {
        return XCTFail("wrong \(err)")
      }
      XCTAssertEqual(r, "lock_screen")
    }
    XCTAssertEqual(session.status, .interrupted)
  }

  func testCustodyPackageHashSeparation() async throws {
    let pkg = try await sealDefault(dirName: "custody-sep")
    let store = EvidenceCustodyStore()
    let before = try Data(contentsOf: pkg.rootURL.appendingPathComponent("manifest.json"))
    let beforeHash = pkg.packageContentSHA256
    var rec = try store.registerSealedPackage(pkg)
    XCTAssertEqual(rec.status, .unverified)
    rec = try store.verifyClosure(packageContentSHA256: beforeHash, expectedRevision: rec.revision)
    XCTAssertEqual(rec.status, .verified)
    rec = try store.archive(packageContentSHA256: beforeHash, expectedRevision: rec.revision)
    XCTAssertEqual(rec.status, .archived)
    let after = try Data(contentsOf: pkg.rootURL.appendingPathComponent("manifest.json"))
    XCTAssertEqual(before, after)
    let rehash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: pkg.rootURL)
    XCTAssertEqual(rehash, beforeHash)
    // Manifest must not gain custody fields
    let text = String(data: after, encoding: .utf8)!
    XCTAssertFalse(text.contains("custody_status"))
    XCTAssertFalse(text.contains("EVIDENCE_CUSTODY"))
  }

  func testVerifiedHandleIssuanceGate() async throws {
    let pkg = try await sealDefault(dirName: "handle")
    let store = EvidenceCustodyStore()
    let rec = try store.registerSealedPackage(pkg)
    XCTAssertThrowsError(try store.verifiedPackage(packageContentSHA256: pkg.packageContentSHA256))
    _ = try store.verifyClosure(packageContentSHA256: pkg.packageContentSHA256, expectedRevision: rec.revision)
    let handle = try store.verifiedPackage(packageContentSHA256: pkg.packageContentSHA256)
    XCTAssertEqual(handle.packageID, pkg.manifest.packageID)
    XCTAssertEqual(handle.vehicleID, "VEH-000001")
    XCTAssertEqual(handle.captureSessionID, pkg.manifest.captureSessionID)
  }

  func testStaleOCCRejectionWithoutSideEffects() async throws {
    let pkg = try await sealDefault(dirName: "occ")
    let store = EvidenceCustodyStore()
    let rec = try store.registerSealedPackage(pkg)
    XCTAssertEqual(rec.revision, 1)
    // Stale expectedRevision must not advance status.
    XCTAssertThrowsError(
      try store.commit(packageContentSHA256: pkg.packageContentSHA256, expectedRevision: 0) { r in
        r.status = .verified
      }
    ) { err in
      guard case SpatialEvidenceError.custodyStaleRevision(let current, let attempted) = err else {
        return XCTFail("wrong \(err)")
      }
      XCTAssertEqual(current, 1)
      XCTAssertEqual(attempted, 0)
    }
    let still = store.record(packageContentSHA256: pkg.packageContentSHA256)
    XCTAssertEqual(still?.status, .unverified)
    XCTAssertEqual(still?.revision, 1)
  }

  func testSessionVehiclePackageBinding() async throws {
    let pkg = try await sealDefault(dirName: "bind")
    XCTAssertEqual(pkg.manifest.vehicleID, "VEH-000001")
    XCTAssertEqual(pkg.manifest.captureSessionID, "SESS-SYNTHETIC-000001")
    XCTAssertEqual(pkg.manifest.pilotID, "PILOT-000001")
    XCTAssertEqual(pkg.manifest.packageID, "SPKG-SYNTH-0001")
  }

  func testObservedRequiresSamples() throws {
    var stream = SpatialStreamCapability(streamID: SpatialStreamID.camera, adapterID: "synth.camera", sensorKind: "camera", stage: .activated)
    XCTAssertThrowsError(try stream.freeze(outcome: .acquired))
    stream.recordSample()
    try stream.freeze(outcome: .acquired)
    XCTAssertEqual(stream.stage, .finalOutcome)
  }

  func testForbidsEDTSPackageQuarantinedOnCustody() async throws {
    let pkg = try await sealDefault(dirName: "edts-forbid")
    let store = EvidenceCustodyStore()
    _ = try store.registerSealedPackage(pkg)
    // Capture custody uses EVIDENCE_CUSTODY_QUARANTINED, never PACKAGE_QUARANTINED.
    XCTAssertNotEqual(EvidenceCustodyStatus.quarantined.rawValue, "PACKAGE_QUARANTINED")
    XCTAssertEqual(StatusOwnerRegistry.owner(of: "PACKAGE_QUARANTINED"), .edts)
  }

  func testStreamAdapterReferentialIntegrity() async throws {
    let pkg = try await sealDefault(dirName: "stream-ids")
    let expected: [(String, String)] = [
      ("camera", "synth.camera"),
      ("depth", "synth.depth"),
      ("motion", "synth.motion"),
      ("pose", "synth.pose"),
    ]
    for (stream, adapter) in expected {
      let cap = pkg.manifest.capability.streams.first { $0.streamID == stream }
      XCTAssertEqual(cap?.adapterID, adapter)
      XCTAssertFalse(cap?.streamID.hasPrefix("synth.") ?? true)
      let arts = pkg.manifest.artifacts.filter { $0.streamID == stream }
      XCTAssertFalse(arts.isEmpty)
      XCTAssertTrue(arts.allSatisfy { $0.adapterID == adapter })
      XCTAssertTrue(arts.allSatisfy { $0.streamID == stream })
    }
  }

  func testPortableSHA256SidecarBasenameOnly() throws {
    let line = try PortableSHA256Sidecar.formatLine(
      sha256: String(repeating: "a", count: 64),
      filename: "DOWNLOAD-elektron-capture-ios-sprint-3-0-synthetic-spatial.zip"
    )
    XCTAssertFalse(line.contains("/"))
    XCTAssertFalse(line.contains("workspace"))
    let parsed = try PortableSHA256Sidecar.parse(line)
    XCTAssertEqual(parsed.count, 1)
    XCTAssertEqual(parsed[0].filename, "DOWNLOAD-elektron-capture-ios-sprint-3-0-synthetic-spatial.zip")

    XCTAssertThrowsError(try PortableSHA256Sidecar.basenameOnly("/workspace/foo.zip"))
    XCTAssertThrowsError(try PortableSHA256Sidecar.basenameOnly("dir/foo.zip"))
    XCTAssertThrowsError(try PortableSHA256Sidecar.parse("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb  /workspace/foo.zip"))
    XCTAssertThrowsError(try PortableSHA256Sidecar.parse("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb  path/foo.zip"))
  }

  func testWriteGoldenSyntheticPackageInventory() async throws {
    guard ProcessInfo.processInfo.environment["PHASE3_WRITE_GOLDEN"] == "1" else {
      throw XCTSkip("Set PHASE3_WRITE_GOLDEN=1 to emit golden package artifacts")
    }
    let envPath = ProcessInfo.processInfo.environment["PHASE3_GOLDEN_OUT"]
    let outRoot: URL
    if let envPath, !envPath.isEmpty {
      outRoot = URL(fileURLWithPath: envPath, isDirectory: true)
    } else {
      outRoot = URL(fileURLWithPath: #file)
        .deletingLastPathComponent() // Unit
        .deletingLastPathComponent() // Tests
        .appendingPathComponent("Docs/Evidence/SPRINT_3_0/synthetic_spatial_package", isDirectory: true)
    }
    try? FileManager.default.removeItem(at: outRoot)
    let pkg = try await sealDefault(dirName: "golden-live")
    // Copy sealed package into repo evidence path
    try FileManager.default.createDirectory(at: outRoot.deletingLastPathComponent(), withIntermediateDirectories: true)
    try FileManager.default.copyItem(at: pkg.rootURL, to: outRoot)
    let inventory: [String: Any] = [
      "schema_id": "Sprint30SyntheticPackageInventory",
      "schema_version": "1.0.0",
      "package_content_sha256": pkg.packageContentSHA256,
      "manifest_sha256": pkg.manifestSHA256,
      "package_id": pkg.manifest.packageID,
      "vehicle_id": pkg.manifest.vehicleID,
      "capture_session_id": pkg.manifest.captureSessionID,
      "pilot_id": pkg.manifest.pilotID as Any,
      "artifacts": pkg.manifest.artifacts.map { $0.asDictionary() },
      "note": "Custody records are intentionally absent from package bytes",
    ]
    let invData = try CanonicalJSON.data(inventory)
    try invData.write(
      to: outRoot.deletingLastPathComponent().appendingPathComponent("package_inventory.json"),
      options: .atomic
    )
    // Prove custody mutation does not alter package hash
    let store = EvidenceCustodyStore()
    var rec = try store.registerSealedPackage(
      SpatialEvidencePackage(
        rootURL: outRoot,
        manifest: pkg.manifest,
        packageContentSHA256: pkg.packageContentSHA256,
        manifestSHA256: pkg.manifestSHA256
      )
    )
    rec = try store.verifyClosure(packageContentSHA256: pkg.packageContentSHA256, expectedRevision: rec.revision)
    _ = try store.archive(packageContentSHA256: pkg.packageContentSHA256, expectedRevision: rec.revision)
    let rehash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outRoot)
    XCTAssertEqual(rehash, pkg.packageContentSHA256)
    let isoFormatter = ISO8601DateFormatter()
    isoFormatter.formatOptions = [.withInternetDateTime]
    let proof: [String: Any] = [
      "schema_id": "CustodyHashSeparationProof",
      "schema_version": "1.0.0-phase3-synthetic",
      "capture_source_tip": "09a3c36f8413ac59608572d665d08c0b3c4e2c75",
      "capture_source_zip": "DOWNLOAD-elektron-capture-ios-sprint-2-3-xcodebuild-errortext.zip",
      "test_case": "Phase3SyntheticSpatialEvidenceTests.testWriteGoldenSyntheticPackageInventory",
      "generated_at": isoFormatter.string(from: Date()),
      "generator_version": "sprint-3.0-synthetic-1.0.0",
      "package_id": pkg.manifest.packageID,
      "vehicle_id": pkg.manifest.vehicleID,
      "capture_session_id": pkg.manifest.captureSessionID,
      "package_content_sha256_before_custody": pkg.packageContentSHA256,
      "package_content_sha256_after_verify_archive": rehash,
      "custody_transitions": [
        ["from": "UNVERIFIED", "to": "VERIFIED", "authority": "CAPTURE_CUSTODY_STORE"],
        ["from": "VERIFIED", "to": "ARCHIVED", "authority": "CAPTURE_CUSTODY_STORE"],
      ],
      "custody_changed_package_bytes": false,
    ]
    try CanonicalJSON.data(proof).write(
      to: outRoot.deletingLastPathComponent().appendingPathComponent("custody_hash_separation_proof.json"),
      options: .atomic
    )
  }

  // MARK: - helpers

  private func sealDefault(dirName: String) async throws -> SpatialEvidencePackage {
    let session = DraftSpatialCaptureSession(
      sessionID: "SESS-SYNTHETIC-000001",
      vehicleID: "VEH-000001",
      pilotID: "PILOT-000001",
      coordinator: SyntheticSpatialSensorCoordinator(),
      allowedFrameIDs: [CoordinateFrameDescriptor.syntheticWorld.frameID]
    )
    return try await session.runToPackaged(outputDirectory: try tempDir(dirName))
  }
}

/// Test double that overrides camera samples with mismatched clocks.
private struct MismatchedClockCoordinator: SpatialSensorCoordinator {
  let inner: SyntheticSpatialSensorCoordinator
  let cameraOverride: [SpatialSampleEnvelope<CameraSample>]
  var capabilitySnapshot: SpatialCapabilitySnapshot { inner.capabilitySnapshot }
  func activateAll() async throws { try await inner.activateAll() }
  func collectDeterministicBundle() async throws -> SpatialSampleBundle {
    var bundle = try await inner.collectDeterministicBundle()
    bundle.camera = cameraOverride
    return bundle
  }
}
