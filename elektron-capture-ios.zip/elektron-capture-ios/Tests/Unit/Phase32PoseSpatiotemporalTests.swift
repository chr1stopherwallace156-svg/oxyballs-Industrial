import XCTest
@testable import ElektronCapture

final class Phase32PoseSpatiotemporalTests: XCTestCase {
  private func tempDir(_ name: String = UUID().uuidString) throws -> URL {
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("p32-\(name)", isDirectory: true)
    try? FileManager.default.removeItem(at: url)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  private func collectCameraPose(
    camera: ControllableCameraSensorAdapter = ControllableCameraSensorAdapter(),
    pose: ControllablePoseSensorAdapter = ControllablePoseSensorAdapter()
  ) async throws -> (
    cam: [SpatialSampleEnvelope<CameraSample>],
    pose: [SpatialSampleEnvelope<PoseSample>],
    camera: ControllableCameraSensorAdapter,
    poseAdapter: ControllablePoseSensorAdapter
  ) {
    try await camera.start()
    try await pose.start()
    var cams: [SpatialSampleEnvelope<CameraSample>] = []
    var poses: [SpatialSampleEnvelope<PoseSample>] = []
    for try await s in camera.samples() { cams.append(s) }
    for try await s in pose.samples() { poses.append(s) }
    await camera.stop()
    await pose.stop()
    return (cams, poses, camera, pose)
  }

  private func edge(
    id: String,
    from: String,
    to: String,
    domain: ClockDomain,
    matrix: [Double],
    timestamp: UInt64 = 0
  ) -> TransformEdge {
    TransformEdge(
      transformID: id,
      fromFrameID: from,
      toFrameID: to,
      timestampNanoseconds: timestamp,
      clockDomain: domain,
      matrix: matrix,
      authority: "TEST_FIXTURE"
    )
  }

  private func sealFixture(
    dirName: String = UUID().uuidString,
    poseEmitCount: Int = 2,
    trackingSequence: [PoseTrackingState] = [],
    frames: [CoordinateFrameDescriptor]? = nil,
    transformEdges: [TransformEdge]? = nil,
    clockCorrelations: [ClockCorrelation]? = nil
  ) async throws -> SpatialEvidencePackage {
    let cam = ControllableCameraSensorAdapter(adapterID: "fixture.camera")
    cam.emitCount = poseEmitCount
    let pose = ControllablePoseSensorAdapter(adapterID: "fixture.pose")
    pose.emitCount = poseEmitCount
    pose.trackingStateSequence = trackingSequence
    let streams = try await collectCameraPose(camera: cam, pose: pose)
    let poses = Array(streams.pose.prefix(streams.cam.count))
    let correlations = clockCorrelations ?? FixturePosePackageBuilder.defaultClockCorrelations()
    let associations = try FixturePosePackageBuilder.defaultAssociations(
      camera: streams.cam,
      pose: poses,
      correlations: correlations
    )
    let motionCap = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "none",
      sensorKind: "motion",
      declared: false
    )
    return try FixturePosePackageBuilder().seal(
      camera: streams.cam,
      motion: [],
      pose: poses,
      cameraCapability: streams.camera.capability,
      motionCapability: motionCap,
      poseCapability: streams.poseAdapter.capability,
      frames: frames ?? FixturePosePackageBuilder.defaultFrames(),
      transformEdges: transformEdges ?? FixturePosePackageBuilder.defaultTransformEdges(),
      clockCorrelations: correlations,
      associations: associations,
      outputDirectory: try tempDir(dirName)
    )
  }

  // MARK: - Adapter failure paths

  func testPoseTimestampRegression() async throws {
    let pose = ControllablePoseSensorAdapter()
    pose.regressTimestamps = true
    pose.emitCount = 2
    try await pose.start()
    do {
      for try await _ in pose.samples() {}
      XCTFail("expected regression")
    } catch let ProductionSensorError.timestampRegression(_, _) {
      // ok
    } catch {
      XCTFail("wrong \(error)")
    }
    await pose.stop()
  }

  func testTrackingNormalLimitedNormal() async throws {
    let pose = ControllablePoseSensorAdapter()
    pose.trackingStateSequence = [.normal, .limited, .normal]
    pose.emitCount = 3
    try await pose.start()
    var states: [PoseTrackingState] = []
    for try await s in pose.samples() {
      states.append(s.payload.trackingState)
    }
    await pose.stop()
    XCTAssertEqual(states, [.normal, .limited, .normal])
    XCTAssertEqual(pose.samplesAcquiredProxy, 3)
  }

  func testTrackingFailure() async throws {
    let pose = ControllablePoseSensorAdapter()
    pose.trackingFailure = true
    try await pose.start()
    do {
      for try await _ in pose.samples() {}
      XCTFail("expected tracking failure")
    } catch let ProductionSensorError.poseTrackingFailed(r) {
      XCTAssertEqual(r, "TRACKING_LOST")
    } catch {
      XCTFail("wrong \(error)")
    }
    await pose.stop()
  }

  func testSessionInterruption() async {
    let pose = ControllablePoseSensorAdapter()
    pose.interruptAfterStart = true
    do {
      try await pose.start()
      XCTFail("expected interrupt")
    } catch let ProductionSensorError.interrupted(r) {
      XCTAssertTrue(r.contains("interrupted"))
    } catch {
      XCTFail("wrong \(error)")
    }
  }

  func testRelocalizationRequested() async {
    let pose = ControllablePoseSensorAdapter()
    pose.requestRelocalization = true
    do {
      try await pose.start()
      XCTFail("expected relocalization")
    } catch {
      XCTAssertEqual(error as? ProductionSensorError, .poseRelocalizationRequired)
    }
  }

  func testControllablePoseAuthorityIsGuidanceEstimate() async throws {
    let pose = ControllablePoseSensorAdapter()
    pose.emitCount = 1
    try await pose.start()
    var samples: [SpatialSampleEnvelope<PoseSample>] = []
    for try await s in pose.samples() { samples.append(s) }
    await pose.stop()
    XCTAssertEqual(samples[0].payload.authority, "GUIDANCE_ESTIMATE")
    XCTAssertEqual(samples[0].payload.asDictionary()["pose_estimate_authority"] as? String, "GUIDANCE_ESTIMATE")
    XCTAssertEqual(samples[0].payload.frameEpochID, "epoch-fixture-1")
    XCTAssertEqual(samples[0].payload.sessionRunID, "run-fixture-1")
    XCTAssertEqual(samples[0].payload.worldOriginRevision, 1)
  }

  // MARK: - Frame graph

  func testUnknownCoordinateFrame() throws {
    let frames = FixturePosePackageBuilder.defaultFrames()
    let graph = CoordinateFrameGraph(frames: frames, edges: [])
    XCTAssertThrowsError(try graph.requireKnownFrame("FRAME_DOES_NOT_EXIST")) { err in
      guard case SpatialEvidenceError.unknownCoordinateFrame(let id) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertEqual(id, "FRAME_DOES_NOT_EXIST")
    }
  }

  func testDuplicateFrameID() throws {
    var frames = FixturePosePackageBuilder.defaultFrames()
    frames.append(frames[0])
    let graph = CoordinateFrameGraph(frames: frames)
    XCTAssertThrowsError(try graph.validateRegistry()) { err in
      guard case SpatialEvidenceError.duplicateCoordinateFrameID(let id) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertEqual(id, "FRAME_CAMERA_OPTICAL")
    }
  }

  func testTransformCycleDetection() throws {
    let frames = FixturePosePackageBuilder.defaultFrames()
    let m = FixturePosePackageBuilder.defaultIdentityMatrix()
    let edges = [
      edge(id: "c0", from: "FRAME_AR_SESSION_WORLD", to: "FRAME_CAPTURE_SESSION_ROOT", domain: .arkitFrame, matrix: m),
      edge(id: "c1", from: "FRAME_CAPTURE_SESSION_ROOT", to: "FRAME_CAMERA_OPTICAL", domain: .monotonicUptime, matrix: m),
      edge(id: "c2", from: "FRAME_CAMERA_OPTICAL", to: "FRAME_AR_SESSION_WORLD", domain: .arkitFrame, matrix: m),
    ]
    let graph = CoordinateFrameGraph(frames: frames, edges: edges)
    XCTAssertThrowsError(try graph.validateTransformGraph()) { err in
      guard case SpatialEvidenceError.unsupportedComplexCycle(let cycle) = err else {
        return XCTFail("expected UNSUPPORTED_COMPLEX_CYCLE, got \(err)")
      }
      XCTAssertGreaterThanOrEqual(cycle.count - 1, 3)
      XCTAssertEqual(
        (err as? SpatialEvidenceError)?.transformGraphCode,
        TransformGraphClassification.unsupportedComplexCycle.rawValue
      )
      // Must NOT be mislabeled as inconsistent reciprocal.
      if case SpatialEvidenceError.inconsistentReciprocalTransform = err {
        XCTFail("three-edge cycle must not be INCONSISTENT_RECIPROCAL_TRANSFORM")
      }
    }
  }

  func testUnsupportedComplexCycleNotInconsistent() throws {
    let frames = FixturePosePackageBuilder.defaultFrames()
    let m = FixturePosePackageBuilder.defaultIdentityMatrix()
    let edges = [
      edge(id: "c0", from: "FRAME_AR_SESSION_WORLD", to: "FRAME_CAPTURE_SESSION_ROOT", domain: .arkitFrame, matrix: m),
      edge(id: "c1", from: "FRAME_CAPTURE_SESSION_ROOT", to: "FRAME_CAMERA_OPTICAL", domain: .monotonicUptime, matrix: m),
      edge(id: "c2", from: "FRAME_CAMERA_OPTICAL", to: "FRAME_AR_SESSION_WORLD", domain: .arkitFrame, matrix: m),
    ]
    XCTAssertThrowsError(
      try CoordinateFrameGraph(frames: frames, edges: edges).validateTransformGraph()
    ) { err in
      XCTAssertEqual(
        (err as? SpatialEvidenceError)?.transformGraphCode,
        "UNSUPPORTED_COMPLEX_CYCLE"
      )
      XCTAssertNotEqual(
        (err as? SpatialEvidenceError)?.transformGraphCode,
        "INCONSISTENT_RECIPROCAL_TRANSFORM"
      )
    }
  }

  func testReciprocalTransformsAllowed() throws {
    let frames = FixturePosePackageBuilder.defaultFrames()
    let m = FixturePosePackageBuilder.defaultIdentityMatrix()
    let edges = [
      edge(id: "r0", from: "FRAME_AR_SESSION_WORLD", to: "FRAME_CAPTURE_SESSION_ROOT", domain: .arkitFrame, matrix: m),
      edge(id: "r1", from: "FRAME_CAPTURE_SESSION_ROOT", to: "FRAME_AR_SESSION_WORLD", domain: .monotonicUptime, matrix: m),
    ]
    let classification = try CoordinateFrameGraph(frames: frames, edges: edges).validateTransformGraph()
    XCTAssertEqual(classification, .consistentReciprocalTransform)
  }

  func testInconsistentReciprocalRejected() throws {
    let frames = FixturePosePackageBuilder.defaultFrames()
    let identity = FixturePosePackageBuilder.defaultIdentityMatrix()
    var translationOnly = identity
    translationOnly[12] = 1.0
    let edges = [
      edge(id: "i0", from: "FRAME_AR_SESSION_WORLD", to: "FRAME_CAPTURE_SESSION_ROOT", domain: .arkitFrame, matrix: identity),
      edge(id: "i1", from: "FRAME_CAPTURE_SESSION_ROOT", to: "FRAME_AR_SESSION_WORLD", domain: .monotonicUptime, matrix: translationOnly),
    ]
    let graph = CoordinateFrameGraph(frames: frames, edges: edges)
    XCTAssertThrowsError(try graph.validateTransformGraph()) { err in
      guard case SpatialEvidenceError.inconsistentReciprocalTransform = err else {
        return XCTFail("\(err)")
      }
      XCTAssertEqual(
        (err as? SpatialEvidenceError)?.transformGraphCode,
        TransformGraphClassification.inconsistentReciprocalTransform.rawValue
      )
    }
  }

  func testAmbiguousTransformPathRejected() throws {
    let frames = FixturePosePackageBuilder.defaultFrames()
    let identity = FixturePosePackageBuilder.defaultIdentityMatrix()
    var shifted = identity
    shifted[12] = 0.5
    let edges = [
      edge(id: "a0", from: "FRAME_AR_SESSION_WORLD", to: "FRAME_CAPTURE_SESSION_ROOT", domain: .arkitFrame, matrix: identity),
      edge(id: "a1", from: "FRAME_AR_SESSION_WORLD", to: "FRAME_CAPTURE_SESSION_ROOT", domain: .arkitFrame, matrix: shifted, timestamp: 1),
    ]
    let graph = CoordinateFrameGraph(frames: frames, edges: edges)
    XCTAssertThrowsError(try graph.validateTransformGraph()) { err in
      guard case SpatialEvidenceError.ambiguousTransformPath = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testDegenerateZeroTransformRejected() throws {
    let frames = FixturePosePackageBuilder.defaultFrames()
    let zero = [Double](repeating: 0, count: 16)
    let edges = [
      edge(id: "d0", from: "FRAME_AR_SESSION_WORLD", to: "FRAME_CAPTURE_SESSION_ROOT", domain: .arkitFrame, matrix: zero),
    ]
    let graph = CoordinateFrameGraph(frames: frames, edges: edges)
    XCTAssertThrowsError(try graph.validateTransformGraph()) { err in
      guard case SpatialEvidenceError.degenerateTransform = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testMissingTransformPath() throws {
    let frames = FixturePosePackageBuilder.graphTestFramesIncludingIMU()
    let edges = [
      edge(
        id: "m0",
        from: "FRAME_DEVICE_IMU",
        to: "FRAME_CAPTURE_SESSION_ROOT",
        domain: .coreMotion,
        matrix: FixturePosePackageBuilder.defaultIdentityMatrix()
      ),
    ]
    let graph = CoordinateFrameGraph(frames: frames, edges: edges)
    XCTAssertThrowsError(
      try graph.requirePath(from: "FRAME_CAMERA_OPTICAL", to: "FRAME_AR_SESSION_WORLD")
    ) { err in
      guard case SpatialEvidenceError.missingTransformPath(let from, let to) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertEqual(from, "FRAME_CAMERA_OPTICAL")
      XCTAssertEqual(to, "FRAME_AR_SESSION_WORLD")
    }
  }

  // MARK: - Quaternion / transform math

  func testInvalidQuaternion() {
    let q = QuaternionD(x: 0, y: 0, z: 0, w: 0)
    XCTAssertThrowsError(try PoseMathValidator.validateQuaternion(q)) { err in
      guard case SpatialEvidenceError.invalidQuaternion = err else { return XCTFail("\(err)") }
    }
    let nanQ = QuaternionD(x: .nan, y: 0, z: 0, w: 1)
    XCTAssertThrowsError(try PoseMathValidator.validateQuaternion(nanQ)) { err in
      guard case SpatialEvidenceError.invalidQuaternion = err else { return XCTFail("\(err)") }
    }
  }

  func testNonNormalizedQuaternion() {
    let q = QuaternionD(x: 1, y: 1, z: 1, w: 1)
    XCTAssertThrowsError(try PoseMathValidator.validateQuaternion(q)) { err in
      guard case SpatialEvidenceError.nonNormalizedQuaternion = err else { return XCTFail("\(err)") }
    }
  }

  func testNaNInfiniteTransformValue() {
    var m = FixturePosePackageBuilder.defaultIdentityMatrix()
    m[12] = .infinity
    XCTAssertThrowsError(try PoseMathValidator.validateTransformMatrix(m)) { err in
      guard case SpatialEvidenceError.nanOrInfiniteTransform = err else { return XCTFail("\(err)") }
    }
    m[12] = .nan
    XCTAssertThrowsError(try PoseMathValidator.validateTransformMatrix(m)) { err in
      guard case SpatialEvidenceError.nanOrInfiniteTransform = err else { return XCTFail("\(err)") }
    }
  }

  func testControllableEmitsInvalidQuaternionPayload() async throws {
    let pose = ControllablePoseSensorAdapter()
    pose.emitInvalidQuaternion = true
    pose.emitCount = 1
    try await pose.start()
    var samples: [SpatialSampleEnvelope<PoseSample>] = []
    for try await s in pose.samples() { samples.append(s) }
    await pose.stop()
    XCTAssertThrowsError(try PoseMathValidator.validatePoseSample(samples[0].payload))
  }

  // MARK: - Associations

  private func stubAssociation(
    id: String = "a0",
    camera: String = "cam-0",
    pose: String = "pose-0"
  ) -> PoseAssociationRecord {
    PoseAssociationRecord(
      associationID: id,
      cameraSampleID: camera,
      poseSampleID: pose,
      cameraClockDomain: .monotonicUptime,
      poseClockDomain: .arkitFrame,
      correlationID: FixturePosePackageBuilder.monotonicToArkitCorrelationID,
      associationTimestampNs: 0,
      timestampDifferenceNs: 0,
      frameEpochID: "epoch-fixture-1",
      sessionRunID: "run-fixture-1",
      worldOriginRevision: 1
    )
  }

  func testCameraSampleWithNoPoseAssociation() {
    let associations = [stubAssociation()]
    XCTAssertThrowsError(
      try PoseAssociationValidator.requireCameraHasPose(cameraSampleID: "cam-orphan", associations: associations)
    ) { err in
      guard case SpatialEvidenceError.poseAssociationMissing(let cam, let pose) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertEqual(cam, "cam-orphan")
      XCTAssertNil(pose)
    }
  }

  func testPoseSampleWithNoCameraAssociation() {
    let associations = [stubAssociation()]
    XCTAssertThrowsError(
      try PoseAssociationValidator.requirePoseHasCamera(poseSampleID: "pose-orphan", associations: associations)
    ) { err in
      guard case SpatialEvidenceError.poseAssociationMissing(let cam, let pose) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertNil(cam)
      XCTAssertEqual(pose, "pose-orphan")
    }
  }

  func testAssociationClockProofBinding() async throws {
    let streams = try await collectCameraPose()
    let cams = Array(streams.cam.prefix(1))
    let poses = Array(streams.pose.prefix(1))
    let correlations = FixturePosePackageBuilder.defaultClockCorrelations()
    let associations = try FixturePosePackageBuilder.defaultAssociations(
      camera: cams,
      pose: poses,
      correlations: correlations
    )
    XCTAssertNoThrow(
      try PoseAssociationValidator.validateAll(
        cameraSamples: cams,
        poseSamples: poses,
        associations: associations,
        correlations: correlations
      )
    )
    XCTAssertEqual(associations[0].correlationID, FixturePosePackageBuilder.monotonicToArkitCorrelationID)
    XCTAssertEqual(associations[0].asDictionary()["association_method"] as? String, "explicit_fixture_binding")
    XCTAssertNil(associations[0].asDictionary()["method"])
  }

  func testAssociationCrossEpochFails() async throws {
    let streams = try await collectCameraPose()
    let cams = Array(streams.cam.prefix(1))
    let poses = Array(streams.pose.prefix(1))
    let correlations = FixturePosePackageBuilder.defaultClockCorrelations()
    var associations = try FixturePosePackageBuilder.defaultAssociations(
      camera: cams,
      pose: poses,
      correlations: correlations
    )
    associations = [
      PoseAssociationRecord(
        associationID: associations[0].associationID,
        cameraSampleID: associations[0].cameraSampleID,
        poseSampleID: associations[0].poseSampleID,
        cameraClockDomain: associations[0].cameraClockDomain,
        poseClockDomain: associations[0].poseClockDomain,
        correlationID: associations[0].correlationID,
        associationTimestampNs: associations[0].associationTimestampNs,
        timestampDifferenceNs: associations[0].timestampDifferenceNs,
        frameEpochID: "epoch-other",
        sessionRunID: associations[0].sessionRunID,
        worldOriginRevision: associations[0].worldOriginRevision
      ),
    ]
    XCTAssertThrowsError(
      try PoseAssociationValidator.validateAll(
        cameraSamples: cams,
        poseSamples: poses,
        associations: associations,
        correlations: correlations
      )
    ) { err in
      guard case SpatialEvidenceError.associationEpochMismatch = err else {
        return XCTFail("\(err)")
      }
    }
  }

  // MARK: - Clock correlation

  func testCrossDomainComparisonWithoutCorrelation() {
    let validator = ClockCorrelationValidator(correlations: [
      ClockCorrelation(
        correlationID: "id-arkit",
        sourceDomain: .arkitFrame,
        destinationDomain: .arkitFrame,
        offsetNanoseconds: 0,
        authority: "TEST_FIXTURE",
        method: "domain_identity"
      ),
    ])
    XCTAssertThrowsError(
      try validator.requireComparable(
        source: .avfoundationCapture,
        destination: .arkitFrame,
        atSourceTimestampNs: 1_000
      )
    ) { err in
      guard case SpatialEvidenceError.crossDomainCompareWithoutCorrelation = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testStaleCorrelation() {
    let corr = ClockCorrelation(
      correlationID: "stale-avf-arkit",
      sourceDomain: .avfoundationCapture,
      destinationDomain: .arkitFrame,
      offsetNanoseconds: 0,
      authority: "TEST_FIXTURE",
      method: "fixture_explicit_cross_domain",
      validFromNanoseconds: 0,
      validUntilNanoseconds: 1_000
    )
    let validator = ClockCorrelationValidator(correlations: [corr])
    XCTAssertThrowsError(
      try validator.requireComparable(
        source: .avfoundationCapture,
        destination: .arkitFrame,
        atSourceTimestampNs: 5_000
      )
    ) { err in
      guard case SpatialEvidenceError.staleClockCorrelation = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testAmbiguousCorrelationPath() {
    let correlations = [
      ClockCorrelation(
        correlationID: "path-a",
        sourceDomain: .avfoundationCapture,
        destinationDomain: .arkitFrame,
        offsetNanoseconds: 0,
        authority: "TEST_FIXTURE",
        method: "path_a"
      ),
      ClockCorrelation(
        correlationID: "path-b",
        sourceDomain: .avfoundationCapture,
        destinationDomain: .arkitFrame,
        offsetNanoseconds: 100,
        authority: "TEST_FIXTURE",
        method: "path_b"
      ),
    ]
    let validator = ClockCorrelationValidator(correlations: correlations)
    XCTAssertThrowsError(
      try validator.requireComparable(
        source: .avfoundationCapture,
        destination: .arkitFrame,
        atSourceTimestampNs: 1
      )
    ) { err in
      guard case SpatialEvidenceError.ambiguousClockCorrelationPath = err else {
        return XCTFail("\(err)")
      }
    }
  }

  func testRequireCorrelationByID() throws {
    let correlations = FixturePosePackageBuilder.defaultClockCorrelations()
    let validator = ClockCorrelationValidator(correlations: correlations)
    let found = try validator.requireByID(FixturePosePackageBuilder.monotonicToArkitCorrelationID)
    XCTAssertEqual(found.sourceDomain, .monotonicUptime)
    XCTAssertEqual(found.destinationDomain, .arkitFrame)
    XCTAssertThrowsError(try validator.requireByID("missing-id")) { err in
      guard case SpatialEvidenceError.unknownClockCorrelationID = err else {
        return XCTFail("\(err)")
      }
    }
  }

  // MARK: - World epochs

  func testCrossEpochPoseJoinRejected() {
    let a = PoseSample(
      translationMeters: Vector3D(x: 0, y: 0, z: 0),
      rotationQuaternion: .identity,
      timestampNanoseconds: 0,
      clockDomain: .arkitFrame,
      sourceFrameID: "FRAME_AR_SESSION_WORLD",
      destinationFrameID: "FRAME_CAPTURE_SESSION_ROOT",
      frameEpochID: "epoch-a",
      sessionRunID: "run-a",
      worldOriginRevision: 1,
      bytes: Data([0])
    )
    let b = PoseSample(
      translationMeters: Vector3D(x: 0, y: 0, z: 0),
      rotationQuaternion: .identity,
      timestampNanoseconds: 1,
      clockDomain: .arkitFrame,
      sourceFrameID: "FRAME_AR_SESSION_WORLD",
      destinationFrameID: "FRAME_CAPTURE_SESSION_ROOT",
      frameEpochID: "epoch-b",
      sessionRunID: "run-a",
      worldOriginRevision: 2,
      bytes: Data([1])
    )
    XCTAssertThrowsError(try PoseWorldEpochValidator.requireSameEpoch(a, b)) { err in
      guard case SpatialEvidenceError.crossEpochPoseJoin = err else {
        return XCTFail("\(err)")
      }
    }
  }

  // MARK: - NOT_REQUESTED motion evidence

  func testNotRequestedHasNoPayload() throws {
    let motCap = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "none",
      sensorKind: "motion",
      declared: false,
      stage: .finalOutcome,
      finalOutcome: .notRequested
    )
    let artifact = SpatialArtifactDescriptor(
      relativePath: "payload/motion/0000.bin",
      byteLength: 1,
      sha256: "abc",
      mediaType: "application/octet-stream",
      schemaID: "MotionSample",
      schemaVersion: "1.0.0-phase3-fixture",
      sampleID: "motion-0",
      streamID: "motion",
      adapterID: "none"
    )
    XCTAssertThrowsError(
      try NotRequestedStreamEvidenceValidator.validateMotionNotRequested(
        capability: motCap,
        artifacts: [artifact],
        frames: FixturePosePackageBuilder.defaultFrames(),
        clockCorrelations: FixturePosePackageBuilder.defaultClockCorrelations()
      )
    ) { err in
      guard case SpatialEvidenceError.notRequestedStreamContributesEvidence(let detail) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertTrue(detail.contains("payload"))
    }
  }

  func testNotRequestedNoActiveAdapter() throws {
    let motCap = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "fixture.motion",
      sensorKind: "motion",
      declared: false,
      stage: .finalOutcome,
      finalOutcome: .notRequested
    )
    XCTAssertThrowsError(
      try NotRequestedStreamEvidenceValidator.validateMotionNotRequested(
        capability: motCap,
        artifacts: [],
        frames: FixturePosePackageBuilder.defaultFrames(),
        clockCorrelations: FixturePosePackageBuilder.defaultClockCorrelations()
      )
    ) { err in
      guard case SpatialEvidenceError.notRequestedStreamContributesEvidence(let detail) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertTrue(detail.contains("adapter"))
    }
  }

  func testNotRequestedNoStreamFrame() throws {
    let motCap = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "none",
      sensorKind: "motion",
      declared: false,
      stage: .finalOutcome,
      finalOutcome: .notRequested
    )
    XCTAssertThrowsError(
      try NotRequestedStreamEvidenceValidator.validateMotionNotRequested(
        capability: motCap,
        artifacts: [],
        frames: FixturePosePackageBuilder.graphTestFramesIncludingIMU(),
        clockCorrelations: FixturePosePackageBuilder.defaultClockCorrelations()
      )
    ) { err in
      guard case SpatialEvidenceError.notRequestedStreamContributesEvidence(let detail) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertTrue(detail.contains("FRAME_DEVICE_IMU"))
    }
  }

  func testNotRequestedNoStreamCorrelation() throws {
    let motCap = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "none",
      sensorKind: "motion",
      declared: false,
      stage: .finalOutcome,
      finalOutcome: .notRequested
    )
    let badCorrelations = FixturePosePackageBuilder.defaultClockCorrelations() + [
      ClockCorrelation(
        correlationID: "fixture-identity-core-motion",
        sourceDomain: .coreMotion,
        destinationDomain: .coreMotion,
        offsetNanoseconds: 0,
        authority: "TEST_FIXTURE",
        method: "domain_identity"
      ),
    ]
    XCTAssertThrowsError(
      try NotRequestedStreamEvidenceValidator.validateMotionNotRequested(
        capability: motCap,
        artifacts: [],
        frames: FixturePosePackageBuilder.defaultFrames(),
        clockCorrelations: badCorrelations
      )
    ) { err in
      guard case SpatialEvidenceError.notRequestedStreamContributesEvidence(let detail) = err else {
        return XCTFail("\(err)")
      }
      XCTAssertTrue(detail.contains("clock"))
    }
  }

  func testPackageFailsWhenNotRequestedStillContributesEvidence() async throws {
    do {
      _ = try await sealFixture(
        dirName: "not-requested-imu",
        frames: FixturePosePackageBuilder.graphTestFramesIncludingIMU()
      )
      XCTFail("expected seal failure when IMU frame present with motion NOT_REQUESTED")
    } catch let SpatialEvidenceError.notRequestedStreamContributesEvidence(detail) {
      XCTAssertTrue(detail.contains("FRAME_DEVICE_IMU"), detail)
    } catch {
      XCTFail("wrong \(error)")
    }
  }

  // MARK: - Capability schema

  func testCapabilityEmbeddedMatchesStandalone() async throws {
    let pkg = try await sealFixture(dirName: "cap-embed", poseEmitCount: 2)
    let standaloneData = try Data(contentsOf: pkg.rootURL.appendingPathComponent("capability_snapshot.json"))
    let standalone = try JSONSerialization.jsonObject(with: standaloneData) as! [String: Any]
    let manifestData = try Data(contentsOf: pkg.rootURL.appendingPathComponent("manifest.json"))
    let manifest = try JSONSerialization.jsonObject(with: manifestData) as! [String: Any]
    let embedded = manifest["capability"] as! [String: Any]

    XCTAssertEqual(standalone["schema_id"] as? String, embedded["schema_id"] as? String)
    XCTAssertEqual(standalone["schema_version"] as? String, "1.0.0-phase3-fixture")
    XCTAssertEqual(embedded["schema_version"] as? String, "1.0.0-phase3-fixture")
    XCTAssertEqual(standalone["snapshot_id"] as? String, embedded["snapshot_id"] as? String)

    let standaloneStreams = standalone["streams"] as! [[String: Any]]
    let embeddedStreams = embedded["streams"] as! [[String: Any]]
    XCTAssertEqual(standaloneStreams.count, embeddedStreams.count)
    for (s, e) in zip(standaloneStreams, embeddedStreams) {
      XCTAssertEqual(s["stream_id"] as? String, e["stream_id"] as? String)
      XCTAssertEqual(s["adapter_id"] as? String, e["adapter_id"] as? String)
      XCTAssertEqual(s["final_outcome"] as? String, e["final_outcome"] as? String)
      XCTAssertEqual(s["outcome"] as? String, e["outcome"] as? String)
    }
  }

  // MARK: - Package seal

  func testFixturePosePackageSealAndNoDeviceIdentities() async throws {
    let pkg = try await sealFixture(dirName: "seal", poseEmitCount: 2)
    XCTAssertEqual(pkg.manifest.packageID, "SPKG-FIXTURE-CAMERA-POSE-000001")
    XCTAssertEqual(pkg.manifest.captureSessionID, "SESS-FIXTURE-CAMERA-POSE-000001")
    XCTAssertFalse(pkg.manifest.packageID.hasPrefix("SPKG-DEVICE-"))
    XCTAssertFalse(pkg.manifest.captureSessionID.hasPrefix("SESS-DEVICE-"))
    XCTAssertTrue(pkg.manifest.artifacts.contains { $0.streamID == "pose" })
    XCTAssertTrue(pkg.manifest.artifacts.contains { $0.streamID == "camera" })
    XCTAssertFalse(pkg.manifest.artifacts.contains { $0.streamID == "motion" })
    XCTAssertFalse(pkg.manifest.artifacts.contains { $0.streamID == "depth" })
    let poseCap = pkg.manifest.capability.streams.first { $0.streamID == "pose" }
    XCTAssertEqual(poseCap?.adapterID, "fixture.pose")
    XCTAssertEqual(poseCap?.finalOutcome, .acquired)
    let motionCap = pkg.manifest.capability.streams.first { $0.streamID == "motion" }
    XCTAssertEqual(motionCap?.finalOutcome, .notRequested)
    let depthCap = pkg.manifest.capability.streams.first { $0.streamID == "depth" }
    XCTAssertEqual(depthCap?.finalOutcome, .notRequested)
    XCTAssertEqual(pkg.manifest.capability.snapshotID, "cap-fixture-camera-pose-1")
    XCTAssertEqual(pkg.manifest.capability.schemaVersion, "1.0.0-phase3-fixture")

    let manifestData = try Data(contentsOf: pkg.rootURL.appendingPathComponent("manifest.json"))
    let obj = try JSONSerialization.jsonObject(with: manifestData) as! [String: Any]
    XCTAssertEqual(obj["host_claim"] as? String, "NO_PHYSICAL_DEVICE_EXECUTION")
    XCTAssertEqual(obj["evidence_origin_authority"] as? String, "TEST_FIXTURE")
    XCTAssertEqual(obj["pose_estimate_authority"] as? String, "GUIDANCE_ESTIMATE")
    XCTAssertNil(obj["authority"])
    XCTAssertEqual(obj["package_layout"] as? String, "fixture_camera_pose_v1")
    XCTAssertEqual(obj["pose_adapter_id"] as? String, "fixture.pose")

    for name in [
      "manifest.json", "sample_index.json", "capability_snapshot.json",
      "coordinate_frames.json", "clock_correlation.json", "transform_graph.json",
      "pose_associations.json", "package_inventory.json",
    ] {
      XCTAssertTrue(FileManager.default.fileExists(atPath: pkg.rootURL.appendingPathComponent(name).path), name)
    }

    // Primary frame set — no IMU.
    let frameIDs = Set(pkg.manifest.frames.map(\.frameID))
    XCTAssertEqual(
      frameIDs,
      [
        "FRAME_CAMERA_OPTICAL",
        "FRAME_AR_SESSION_WORLD",
        "FRAME_CAPTURE_SESSION_ROOT",
      ]
    )
    XCTAssertFalse(frameIDs.contains("FRAME_DEVICE_IMU"))

    // No motion payload directory.
    let motionDir = pkg.rootURL.appendingPathComponent("payload/motion")
    XCTAssertFalse(FileManager.default.fileExists(atPath: motionDir.path))

    // Transform graph characterization — no engineering tolerance claims.
    let tgData = try Data(contentsOf: pkg.rootURL.appendingPathComponent("transform_graph.json"))
    let tg = try JSONSerialization.jsonObject(with: tgData) as! [String: Any]
    XCTAssertEqual(tg["characterization_status"] as? String, "PENDING_CHARACTERIZATION")
    XCTAssertEqual(tg["system_tolerance"] as? String, "NO_SYSTEM_TOLERANCE_ASSIGNED")
    let edges = tg["edges"] as! [[String: Any]]
    XCTAssertFalse(edges.contains { ($0["from_frame_id"] as? String) == "FRAME_DEVICE_IMU" })
    XCTAssertEqual(edges[0]["source_sample_id"] as? String, "FIXTURE_STATIC_TRANSFORM")

    // Clock correlations — no core_motion.
    let clockData = try Data(contentsOf: pkg.rootURL.appendingPathComponent("clock_correlation.json"))
    let clockObj = try JSONSerialization.jsonObject(with: clockData) as! [String: Any]
    let corrs = clockObj["correlations"] as! [[String: Any]]
    XCTAssertFalse(corrs.contains {
      ($0["source_domain"] as? String) == "core_motion"
        || ($0["destination_domain"] as? String) == "core_motion"
    })
    XCTAssertTrue(corrs.contains {
      ($0["correlation_id"] as? String) == FixturePosePackageBuilder.monotonicToArkitCorrelationID
    })

    let assocData = try Data(contentsOf: pkg.rootURL.appendingPathComponent("pose_associations.json"))
    let assocObj = try JSONSerialization.jsonObject(with: assocData) as! [String: Any]
    let assocs = assocObj["associations"] as! [[String: Any]]
    XCTAssertEqual(assocs[0]["evidence_origin_authority"] as? String, "TEST_FIXTURE")
    XCTAssertEqual(assocs[0]["frame_epoch_id"] as? String, "epoch-fixture-1")
    XCTAssertEqual(assocs[0]["correlation_id"] as? String, FixturePosePackageBuilder.monotonicToArkitCorrelationID)
    XCTAssertEqual(assocs[0]["association_method"] as? String, "explicit_fixture_binding")
  }

  func testApplePoseAdapterUncompiledOnLinux() async {
    #if !canImport(ARKit)
    let adapter = AppleARKitPoseSensorAdapter()
    do {
      try await adapter.start()
      XCTFail("expected uncompiled")
    } catch let ProductionSensorError.unavailable(s) {
      XCTAssertTrue(
        s.contains("APPLE_POSE_SOURCE_CANDIDATE_UNCOMPILED") || s.contains("BLOCKED_HOST_CAPABILITY"),
        s
      )
    } catch {
      XCTFail("\(error)")
    }
    #endif
  }

  func testSyntheticPoseAdapterStillCompatible() async throws {
    let adapter = SyntheticPoseSensorAdapter()
    let samples = try await adapter.nextSamples(count: 2)
    XCTAssertEqual(samples.count, 2)
    XCTAssertEqual(samples[0].payload.authority, "GUIDANCE_ESTIMATE")
    XCTAssertEqual(samples[0].payload.trackingState, .normal)
    XCTAssertEqual(samples[0].schemaVersion, "1.0.0-phase3-synthetic")
    try PoseMathValidator.validatePoseSample(samples[0].payload)
  }

  func testWritePoseGoldenWhenRequested() async throws {
    guard ProcessInfo.processInfo.environment["PHASE32_WRITE_GOLDEN"] == "1" else {
      throw XCTSkip("Set PHASE32_WRITE_GOLDEN=1 to emit pose package fixture")
    }
    let out = ProcessInfo.processInfo.environment["PHASE32_GOLDEN_OUT"].flatMap {
      $0.isEmpty ? nil : URL(fileURLWithPath: $0, isDirectory: true)
    } ?? URL(fileURLWithPath: #file)
      .deletingLastPathComponent() // Unit
      .deletingLastPathComponent() // Tests
      .deletingLastPathComponent() // repo root
      .appendingPathComponent("Docs/Evidence/SPRINT_3_2/SPKG-FIXTURE-CAMERA-POSE-000001", isDirectory: true)
    try? FileManager.default.removeItem(at: out)
    let pkg = try await sealFixture(dirName: "golden-pose", poseEmitCount: 2)
    try FileManager.default.createDirectory(at: out.deletingLastPathComponent(), withIntermediateDirectories: true)
    try FileManager.default.copyItem(at: pkg.rootURL, to: out)
    let closure = try XCTUnwrap(pkg.packageClosureSHA256)
    let inv: [String: Any] = [
      "schema_id": "Sprint32FixturePackageInventory",
      "schema_version": "1.0.0",
      "fixture_payload_content_sha256": pkg.packageContentSHA256,
      "fixture_manifest_sha256": pkg.manifestSHA256,
      "fixture_package_closure_sha256": closure,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "package_id": pkg.manifest.packageID,
      "capture_session_id": pkg.manifest.captureSessionID,
      "adapter_id": "fixture.pose",
      "evidence_origin_authority": "TEST_FIXTURE",
      "pose_estimate_authority": "GUIDANCE_ESTIMATE",
      "host_claim": "NO_PHYSICAL_DEVICE_EXECUTION",
      "note": "Controllable Foundation camera+pose dual-stream fixture — motion NOT_REQUESTED; no physical-device claim. fixture_payload_content_sha256 hashes manifest identity + artifact descriptors only; fixture_package_closure_sha256 hashes canonical inventory entries (sha256-canonical-inventory-v1).",
    ]
    try CanonicalJSON.data(inv).write(
      to: out.deletingLastPathComponent().appendingPathComponent("pose_package_inventory.json"),
      options: .atomic
    )
  }

  // MARK: - Digest scope (payload content vs inventory closure)

  func testInventoryClosureIdenticalEntriesSameDigest() throws {
    let entries: [[String: Any]] = [
      ["relative_path": "b.bin", "byte_length": 2, "sha256": "bb"],
      ["relative_path": "a.bin", "byte_length": 1, "sha256": "aa"],
    ]
    let shuffled: [[String: Any]] = [
      ["relative_path": "a.bin", "byte_length": 1, "sha256": "aa"],
      ["relative_path": "b.bin", "byte_length": 2, "sha256": "bb"],
    ]
    let a = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    let b = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: shuffled)
    XCTAssertEqual(a, b)
    XCTAssertEqual(
      SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "sha256-canonical-inventory-v1"
    )
  }

  func testInventoryReorderDoesNotChangeClosureDigest() async throws {
    let pkg = try await sealFixture(dirName: "closure-reorder")
    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: pkg.rootURL
    )
    let reversed = Array(entries.reversed())
    let h1 = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    let h2 = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: reversed)
    XCTAssertEqual(h1, h2)
    XCTAssertEqual(h1, pkg.packageClosureSHA256)
  }

  func testMetadataMutationChangesClosureNotPayloadContent() async throws {
    let pkg = try await sealFixture(dirName: "closure-meta")
    let payloadBefore = pkg.packageContentSHA256
    let closureBefore = try XCTUnwrap(pkg.packageClosureSHA256)

    let capURL = pkg.rootURL.appendingPathComponent("capability_snapshot.json")
    var capData = try Data(contentsOf: capURL)
    capData.append(contentsOf: [0x0A]) // metadata-only mutation
    try capData.write(to: capURL, options: .atomic)

    // Refresh declared inventory so completeness still holds; closure must change.
    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: pkg.rootURL
    )
    let refreshedClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": pkg.manifest.packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": refreshedClosure,
      "entries": entries,
    ]
    try CanonicalJSON.data(inventory).write(
      to: pkg.rootURL.appendingPathComponent("package_inventory.json"),
      options: .atomic
    )

    let payloadAfter = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: pkg.rootURL)
    let closureAfter = try SpatialPackageClosureVerifier.issueInventoryClosureDigest(
      packageRoot: pkg.rootURL
    )
    XCTAssertEqual(payloadAfter, payloadBefore, "metadata-only mutation must not change payload-content digest")
    XCTAssertNotEqual(closureAfter, closureBefore, "metadata-file mutation must change package closure digest")
  }

  func testPayloadMutationChangesPayloadContentAndClosure() async throws {
    let pkg = try await sealFixture(dirName: "closure-payload")
    let payloadBefore = pkg.packageContentSHA256
    let closureBefore = try XCTUnwrap(pkg.packageClosureSHA256)

    let camURL = pkg.rootURL.appendingPathComponent("payload/camera/0000.bin")
    var cam = try Data(contentsOf: camURL)
    cam[0] ^= 0xFF
    try cam.write(to: camURL, options: .atomic)

    // Manifest artifact descriptor still has old sha — rehash uses descriptor list from manifest,
    // so first update manifest artifact sha to match mutated bytes for a coherent payload digest change.
    let manifestURL = pkg.rootURL.appendingPathComponent("manifest.json")
    let manifestData = try Data(contentsOf: manifestURL)
    var manifestObj = try JSONSerialization.jsonObject(with: manifestData) as! [String: Any]
    var arts = manifestObj["artifacts"] as! [[String: Any]]
    let newSHA = ContentHasher.sha256Hex(cam)
    for i in arts.indices where (arts[i]["relative_path"] as? String) == "payload/camera/0000.bin" {
      arts[i]["sha256"] = newSHA
      arts[i]["byte_length"] = cam.count
    }
    manifestObj["artifacts"] = arts
    try CanonicalJSON.data(manifestObj).write(to: manifestURL, options: .atomic)

    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: pkg.rootURL
    )
    let refreshedClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": pkg.manifest.packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": refreshedClosure,
      "entries": entries,
    ]
    try CanonicalJSON.data(inventory).write(
      to: pkg.rootURL.appendingPathComponent("package_inventory.json"),
      options: .atomic
    )

    let payloadAfter = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: pkg.rootURL)
    let closureAfter = try SpatialPackageClosureVerifier.issueInventoryClosureDigest(
      packageRoot: pkg.rootURL
    )
    XCTAssertNotEqual(payloadAfter, payloadBefore)
    XCTAssertNotEqual(closureAfter, closureBefore)
  }

  func testMissingAndOrphanFailBeforeClosureIssuance() async throws {
    let pkg = try await sealFixture(dirName: "closure-gate")
    // Orphan file
    let orphan = pkg.rootURL.appendingPathComponent("orphan_meta.json")
    try Data("{}".utf8).write(to: orphan)
    XCTAssertThrowsError(
      try SpatialPackageClosureVerifier.issueInventoryClosureDigest(packageRoot: pkg.rootURL)
    ) { err in
      guard case SpatialEvidenceError.orphanArtifact = err else {
        return XCTFail("expected orphanArtifact, got \(err)")
      }
    }
    try FileManager.default.removeItem(at: orphan)

    // Missing declared entry
    var entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: pkg.rootURL
    )
    entries.append([
      "relative_path": "missing_sidecar.json",
      "byte_length": 1,
      "sha256": "00",
    ])
    XCTAssertThrowsError(
      try SpatialPackageClosureVerifier.verifyInventoryCompleteness(
        packageRoot: pkg.rootURL,
        entries: entries
      )
    ) { err in
      guard case SpatialEvidenceError.missingArtifact = err else {
        return XCTFail("expected missingArtifact, got \(err)")
      }
    }
  }

  func testClosureInputRejectsAbsolutePaths() throws {
    let bad: [[String: Any]] = [
      ["relative_path": "/tmp/abs.bin", "byte_length": 1, "sha256": "aa"],
    ]
    XCTAssertThrowsError(try SpatialPackageClosureVerifier.inventoryClosureHash(entries: bad)) { err in
      guard case SpatialEvidenceError.packageClosureFailed(let msg) = err else {
        return XCTFail("expected packageClosureFailed, got \(err)")
      }
      XCTAssertTrue(msg.contains("absolute") || msg.contains("host"), msg)
    }
  }

  func testSealedFixtureExposesDistinctPayloadAndClosureDigests() async throws {
    let pkg = try await sealFixture(dirName: "closure-distinct")
    let closure = try XCTUnwrap(pkg.packageClosureSHA256)
    XCTAssertFalse(closure.isEmpty)
    XCTAssertNotEqual(pkg.packageContentSHA256, closure)
    let reissued = try SpatialPackageClosureVerifier.issueInventoryClosureDigest(
      packageRoot: pkg.rootURL
    )
    XCTAssertEqual(reissued, closure)
  }
}

private extension ControllablePoseSensorAdapter {
  var samplesAcquiredProxy: UInt64 { capability.samplesAcquired }
}
