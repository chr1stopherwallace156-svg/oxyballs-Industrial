import XCTest
@testable import ElektronCapture

/// Phase A mandatory gate — post-capture order + lifecycle/export decoupling.
final class Sprint2_1F_PhaseA_CheckpointTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_800_000)
  private let progression = InspectionProgressionEngine()
  private let binding = EvidenceBindingService()

  private func makeSnapshot() throws -> InspectionPlanSnapshot {
    let plan = try InspectionPlan(
      id: "phase_a",
      version: "1.0.0",
      title: "Phase A",
      points: [
        try InspectionPoint(id: "p1", title: "Front", displayOrder: 1, isRequired: true),
        try InspectionPoint(id: "p2", title: "Rear", displayOrder: 2, isRequired: true),
      ]
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession(id: String = "INS-PHA") throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "PHA-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: try makeSnapshot(),
      assignedAt: fixedInstant
    )
  }

  private func pointID(_ raw: String) -> InspectionPointID { .unchecked(raw) }

  private func coordinator(persister: (any GuidedSessionPersisting)? = nil)
    -> GuidedInspectionCoordinator
  {
    GuidedInspectionCoordinator(
      instantProvider: FixedInstantProvider(fixedInstant),
      persister: persister
    )
  }

  // MARK: Post-capture UI order

  func testGuidedPathNeverRequiresApprovedState() throws {
    XCTAssertTrue(
      Phase1StillCaptureUIStateMachine.canTransition(from: .reviewing, to: .previewing)
    )
    let next = try Phase1StillCaptureUIStateMachine.transition(
      from: .reviewing,
      to: .previewing
    )
    XCTAssertEqual(next, .previewing)
    XCTAssertNotEqual(next, .approved)
  }

  func testSessionIdentityPreservedAcrossBindPersistAdopt() async throws {
    final class MemoryPersister: GuidedSessionPersisting, @unchecked Sendable {
      var last: InspectionSession?
      func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
        last = session
        return session
      }
    }
    let persister = MemoryPersister()
    let c = coordinator(persister: persister)
    var session = try makeSession()
    let originalID = session.id
    session = try await c.handle(.prepareGuidedSession, session: session).session
    session = try await c.handle(
      .bindApprovedCapture(storageKey: "lib-1", type: .photo, attributes: [:]),
      session: session
    ).session
    XCTAssertEqual(session.id, originalID)
    XCTAssertEqual(persister.last?.id, originalID)
    XCTAssertEqual(session.status, .inProgress)
    XCTAssertNotNil(session.evidenceBindings)
  }

  // MARK: Lifecycle vs export decoupling

  func testCannotDisplayCompletedWhilePointsOnlyEvidenceSatisfied() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    session = try c.apply(
      .bindApprovedCapture(storageKey: "lib-a", type: .photo, attributes: [:]),
      session: session
    ).session
    let ready = InspectionLifecycleEvaluator.readiness(for: session)
    XCTAssertEqual(ready.lifecycle, .inProgress)
    XCTAssertNotEqual(ready.lifecycle, .completed)
    XCTAssertFalse(ready.isExportReady)
    XCTAssertFalse(InspectionLifecycleEvaluator.canCommitCompletion(session))
  }

  func testCompletedInspectionMayStillBeExportBlocked() throws {
    let c = coordinator()
    var session = try makeSession(id: "INS-PHA-DECOUPLE")
    session = try c.apply(.prepareGuidedSession, session: session).session
    session = try c.apply(
      .bindApprovedCapture(storageKey: "lib-only-p1", type: .photo, attributes: [:]),
      session: session
    ).session
    // Simulate a session that was marked completed while required workflow remains unresolved
    // (historical ungated Done). Lifecycle follows SessionStatus; export follows policy.
    session.status = .completed
    session.finishedAt = fixedInstant
    let ready = InspectionLifecycleEvaluator.readiness(for: session)
    XCTAssertEqual(ready.lifecycle, .completed)
    XCTAssertEqual(ready.exportLabel, "Export Blocked")
    XCTAssertFalse(ready.isExportReady)
    XCTAssertFalse(ready.exportBlockedMessages.isEmpty)

    // Exported is orthogonal history — only when package flag is set on a completed session.
    XCTAssertEqual(
      InspectionLifecycleEvaluator.presentation(for: session, hasExportedPackage: false),
      .completed
    )
    XCTAssertEqual(
      InspectionLifecycleEvaluator.presentation(for: session, hasExportedPackage: true),
      .exported
    )
  }

  func testInProgressNeverShowsExportedEvenIfPackageFlagSet() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("p1"), in: session)
    let life = InspectionLifecycleEvaluator.presentation(
      for: session,
      hasExportedPackage: true
    )
    XCTAssertEqual(life, .inProgress)
    XCTAssertNotEqual(life, .exported)
    XCTAssertNotEqual(life, .completed)
  }

  func testReadyForReviewThenCompletedSeparatesExportLabel() throws {
    let c = coordinator()
    var session = try makeSession()
    session = try c.apply(.prepareGuidedSession, session: session).session
    session = try c.apply(
      .bindApprovedCapture(storageKey: "lib-a", type: .photo, attributes: [:]),
      session: session
    ).session
    session = try c.apply(.completePointRequested, session: session).session
    session = try c.apply(
      .skipPoint(pointID("p2"), reason: "ok"),
      session: session
    ).session
    let before = InspectionLifecycleEvaluator.readiness(for: session)
    XCTAssertEqual(before.lifecycle, .readyForReview)
    XCTAssertTrue(before.isExportReady)

    session = try c.apply(.commitSessionCompletionRequested, session: session).session
    let after = InspectionLifecycleEvaluator.readiness(for: session)
    XCTAssertEqual(after.lifecycle, .completed)
    XCTAssertTrue(after.isExportReady)
    XCTAssertEqual(after.exportLabel, "Export Ready")
  }

  func testPersistenceFailureLeavesSessionUntouched() async throws {
    final class FailingPersister: GuidedSessionPersisting, @unchecked Sendable {
      func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
        throw GuidedInspectionPresentationError.persistence("disk full")
      }
    }
    let c = coordinator(persister: FailingPersister())
    var session = try makeSession()
    session = try await coordinator().handle(.prepareGuidedSession, session: session).session
    let beforeBindings = session.evidenceBindings?.bindings.count ?? 0
    let beforeID = session.id
    do {
      _ = try await c.handle(
        .bindApprovedCapture(storageKey: "lib-fail", type: .photo, attributes: [:]),
        session: session
      )
      XCTFail("expected persistence failure")
    } catch {
      // Caller keeps prior session; domain apply is not adopted when handle throws after apply.
      // handle applies then persists — on persist failure, throw; caller must not adopt.
      XCTAssertEqual(session.id, beforeID)
      XCTAssertEqual(session.evidenceBindings?.bindings.count ?? 0, beforeBindings)
    }
  }
}
