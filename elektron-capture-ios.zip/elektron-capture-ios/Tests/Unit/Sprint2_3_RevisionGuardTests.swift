import XCTest
@testable import ElektronCapture

/// Sprint 2.3 Phase C — `expectedRevision` OCC (S2-004).
final class Sprint2_3_RevisionGuardTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_721_200_000)

  private func makeSession(id: String) throws -> InspectionSession {
    let plan = try InspectionPlan(
      id: "s23_rev",
      version: "1.0.0",
      title: "S23 Rev",
      points: [
        try InspectionPoint(id: "p1", title: "P1", displayOrder: 1, isRequired: true),
      ]
    )
    let snapshot = try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
    return try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "S23-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: snapshot,
      assignedAt: fixedInstant
    )
  }

  func testSaveDifferentIDIntoOccupiedSlotIsRejected() async throws {
    let repo = InMemoryCurrentSessionRepository()
    var incumbent = try makeSession(id: "INS-SLOT-OLD")
    incumbent = try await repo.save(incumbent, expectedRevision: 0) // rev 1
    XCTAssertEqual(incumbent.revision, 1)

    let interloper = try makeSession(id: "INS-SLOT-NEW")
    do {
      _ = try await repo.save(interloper, expectedRevision: 0)
      XCTFail("expected slotOccupied — silent different-id overwrite is forbidden")
    } catch let InspectionSessionError.slotOccupied(incumbentID, incumbentRevision) {
      XCTAssertEqual(incumbentID, "INS-SLOT-OLD")
      XCTAssertEqual(incumbentRevision, 1)
    }

    let loadedOpt = try await repo.load()
    let loaded = try XCTUnwrap(loadedOpt)
    XCTAssertEqual(loaded.id.rawValue, "INS-SLOT-OLD")
    XCTAssertEqual(loaded.revision, 1)
  }

  func testReplaceCurrentSessionRequiresIncumbentRevisionAwareness() async throws {
    let repo = InMemoryCurrentSessionRepository()
    var incumbent = try makeSession(id: "INS-SLOT-A")
    incumbent = try await repo.save(incumbent, expectedRevision: 0)

    let replacement = try makeSession(id: "INS-SLOT-B")
    do {
      _ = try await repo.replaceCurrentSession(replacement, expectedIncumbentRevision: 0)
      XCTFail("expected staleRevisionConflict for wrong incumbent expectation")
    } catch let InspectionSessionError.staleRevisionConflict(current, attempted) {
      XCTAssertEqual(current, 1)
      XCTAssertEqual(attempted, 0)
    }

    let installed = try await repo.replaceCurrentSession(
      replacement,
      expectedIncumbentRevision: 1
    )
    XCTAssertEqual(installed.id.rawValue, "INS-SLOT-B")
    XCTAssertEqual(installed.revision, 1)
  }

  func testFirstPersistRequiresExpectedZeroAndAssignsOne() async throws {
    let repo = InMemoryCurrentSessionRepository()
    var session = try makeSession(id: "INS-S23-FIRST")
    XCTAssertEqual(session.revision, 0)
    session = try await repo.save(session, expectedRevision: 0)
    XCTAssertEqual(session.revision, 1)
  }

  func testCallerMintedFutureRevisionOnPayloadIsIgnored() async throws {
    let repo = InMemoryCurrentSessionRepository()
    var session = try makeSession(id: "INS-S23-IGN")
    session = try await repo.save(session, expectedRevision: 0) // rev 1

    var mutated = session
    mutated.status = .paused
    mutated.revision = 99 // caller asserts a future sequence — must be ignored
    let saved = try await repo.save(mutated, expectedRevision: 1)
    XCTAssertEqual(saved.revision, 2)
    XCTAssertEqual(saved.status, .paused)
  }

  func testNonZeroExpectationAgainstEmptySlotIsRejectedWithoutAdopting() async throws {
    let repo = InMemoryCurrentSessionRepository()
    var session = try makeSession(id: "INS-S23-EMPTY")
    session.revision = 11
    do {
      _ = try await repo.save(session, expectedRevision: 11)
      XCTFail("expected staleRevisionConflict")
    } catch let InspectionSessionError.staleRevisionConflict(current, attempted) {
      XCTAssertEqual(current, 0)
      XCTAssertEqual(attempted, 11)
    }
    let loaded = try await repo.load()
    XCTAssertNil(loaded)
  }

  func testRejectedCommitLeavesDiskUnchanged() async throws {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("s23-sidefx-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    var head = try makeSession(id: "INS-S23-SIDE")
    head = try await repo.save(head, expectedRevision: 0)
    let before = try Data(contentsOf: url)

    var stale = head
    stale.status = .paused
    do {
      _ = try await repo.save(stale, expectedRevision: 0) // wrong expectation
      XCTFail("expected conflict")
    } catch InspectionSessionError.staleRevisionConflict {
      // expected
    }

    let after = try Data(contentsOf: url)
    XCTAssertEqual(before, after)
    XCTAssertFalse(FileManager.default.fileExists(atPath: url.appendingPathExtension("tmp").path))
    let loadedOpt = try await repo.load()
    let loaded = try XCTUnwrap(loadedOpt)
    XCTAssertEqual(loaded.revision, 1)
    XCTAssertEqual(loaded.status, .inProgress)
  }

  func testLegacyPayloadMissingRevisionDecodesAsZeroThenCommits() async throws {
    let session = try makeSession(id: "INS-S23-LEGACY-REV")
    let data = try InspectionSessionEnvelopeCoder.makeJSONEncoder().encode(session)
    var obj = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    obj.removeValue(forKey: "revision")
    let stripped = try JSONSerialization.data(withJSONObject: obj)
    let decoded = try InspectionSessionEnvelopeCoder.makeJSONDecoder()
      .decode(InspectionSession.self, from: stripped)
    XCTAssertEqual(decoded.revision, 0)

    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("s23-leg-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    let saved = try await repo.save(decoded, expectedRevision: 0)
    XCTAssertEqual(saved.revision, 1)
  }

  func testControlledInterleavingRejectsStaleExpectedRevision() async throws {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("s23-occ-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    let serviceA = InspectionSessionService(repository: repo)
    let serviceB = InspectionSessionService(repository: repo)

    var head = try makeSession(id: "INS-S23-OCC")
    head = try await serviceA.applyUpdatedSession(head, expectedRevision: 0) // rev 1
    var fromA = head
    fromA.status = .paused
    fromA = try await serviceA.applyUpdatedSession(fromA, expectedRevision: 1) // rev 2

    var stale = head // still expects 1
    stale.metrics.captureCount = 9
    do {
      _ = try await serviceB.applyUpdatedSession(stale, expectedRevision: 1)
      XCTFail("expected staleRevisionConflict")
    } catch let InspectionSessionError.staleRevisionConflict(current, attempted) {
      XCTAssertEqual(current, 2)
      XCTAssertEqual(attempted, 1)
    }

    // Rejected path must not poison serviceB cache with stale payload
    XCTAssertNil(serviceB.currentSession)
    let restored = try await serviceB.restoreCurrentSession()
    let loaded = try XCTUnwrap(restored)
    XCTAssertEqual(loaded.revision, 2)
    XCTAssertEqual(loaded.status, .paused)
    XCTAssertEqual(loaded.metrics.captureCount, 0)
    XCTAssertEqual(fromA.revision, 2)
  }

  func testMultiSessionStoreEnforcesPerFileExpectedRevision() async throws {
    let dir = FileManager.default.temporaryDirectory
      .appendingPathComponent("s23-store-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: dir) }
    let store = FileInspectionSessionStore(directoryURL: dir)
    var session = try makeSession(id: "INS-S23-STORE")
    session = try await store.save(session, savedAt: fixedInstant, expectedRevision: 0)
    XCTAssertEqual(session.revision, 1)

    var next = session
    next.status = .paused
    next = try await store.save(
      next,
      savedAt: fixedInstant.addingTimeInterval(1),
      expectedRevision: session.revision
    )
    XCTAssertEqual(next.revision, 2)

    var stale = session
    stale.status = .canceled
    do {
      _ = try await store.save(
        stale,
        savedAt: fixedInstant.addingTimeInterval(2),
        expectedRevision: stale.revision
      )
      XCTFail("expected staleRevisionConflict")
    } catch let InspectionSessionPersistenceError.staleRevisionConflict(current, attempted) {
      XCTAssertEqual(current, 2)
      XCTAssertEqual(attempted, 1)
    }
    let loaded = try await store.load(id: session.id)
    XCTAssertEqual(loaded.revision, 2)
    XCTAssertEqual(loaded.status, .paused)
  }
}
