import XCTest
@testable import ElektronCapture

/// Sprint 2.1D — evidence-to-point binding metadata.
final class Sprint2_1DTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_300_000)
  private let service = EvidenceBindingService()

  private func makeSnapshot() throws -> InspectionPlanSnapshot {
    let plan = try InspectionPlan(
      id: "bind_demo",
      version: "1.0.0",
      title: "Bind Demo",
      points: [
        try InspectionPoint(id: "p0", title: "P0", displayOrder: 1, isRequired: true),
        try InspectionPoint(
          id: "p1",
          title: "P1",
          displayOrder: 2,
          isRequired: true,
          expectedEvidenceType: .multiPhoto
        ),
        try InspectionPoint(id: "p2", title: "P2", displayOrder: 3, isRequired: false),
      ]
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession(id: String = "INS-21D") throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "BIND-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: makeSnapshot(),
      assignedAt: fixedInstant
    )
  }

  private func pointID(_ raw: String) -> InspectionPointID {
    InspectionPointID.unchecked(raw)
  }

  private func meta(
    id: EvidenceID = EvidenceID(),
    point: String,
    session: InspectionSession,
    type: EvidenceType = .photo,
    key: String = "opaque-key-1",
    attrs: [String: String] = [:]
  ) -> EvidenceMetadata {
    EvidenceMetadata(
      id: id,
      pointID: pointID(point),
      sessionID: session.id,
      type: type,
      createdAt: fixedInstant,
      storageKey: key,
      payloadAttributes: attrs
    )
  }

  // MARK: - Bind / query / unbind

  func testBindAndRetrieveEvidenceByPointID() throws {
    var session = try makeSession()
    XCTAssertNil(session.evidenceBindings)

    let e1 = meta(point: "p0", session: session, key: "k-p0-a")
    let e2 = meta(point: "p0", session: session, type: .textNote, key: "k-p0-b")
    let e3 = meta(point: "p1", session: session, type: .photo, key: "k-p1-a")

    session = try service.bind(evidence: e1, to: session)
    session = try service.bind(evidence: e2, to: session)
    session = try service.bind(evidence: e3, to: session)

    let forP0 = service.evidence(for: pointID("p0"), in: session)
    XCTAssertEqual(forP0.map(\.id), [e1.id, e2.id])
    XCTAssertEqual(service.evidenceCount(for: pointID("p0"), in: session), 2)
    XCTAssertEqual(service.evidenceCount(for: pointID("p1"), in: session), 1)
    XCTAssertEqual(service.evidence(for: pointID("p2"), in: session), [])
  }

  func testUnbindEvidenceByID() throws {
    var session = try makeSession()
    let e1 = meta(point: "p0", session: session, key: "k1")
    let e2 = meta(point: "p0", session: session, key: "k2")
    session = try service.bind(evidence: e1, to: session)
    session = try service.bind(evidence: e2, to: session)

    session = try service.unbind(evidenceID: e1.id, from: session)
    XCTAssertEqual(service.evidence(for: pointID("p0"), in: session).map(\.id), [e2.id])

    session = try service.unbind(evidenceID: e2.id, from: session)
    XCTAssertNil(session.evidenceBindings)
    XCTAssertEqual(service.evidenceCount(for: pointID("p0"), in: session), 0)

    XCTAssertThrowsError(try service.unbind(evidenceID: e1.id, from: session)) { err in
      XCTAssertEqual(
        err as? EvidenceBindingError,
        .unknownEvidenceID(e1.id.rawValue.uuidString)
      )
    }
  }

  func testRejectUnknownPointID() throws {
    let session = try makeSession()
    let bad = meta(point: "does-not-exist", session: session)
    XCTAssertThrowsError(try service.bind(evidence: bad, to: session)) { err in
      XCTAssertEqual(err as? EvidenceBindingError, .unknownPointID("does-not-exist"))
    }
  }

  func testRejectDuplicateEvidenceID() throws {
    var session = try makeSession()
    let id = EvidenceID()
    let first = meta(id: id, point: "p0", session: session, key: "a")
    let dup = meta(id: id, point: "p1", session: session, key: "b")
    session = try service.bind(evidence: first, to: session)
    XCTAssertThrowsError(try service.bind(evidence: dup, to: session)) { err in
      XCTAssertEqual(
        err as? EvidenceBindingError,
        .duplicateEvidenceID(id.rawValue.uuidString)
      )
    }
  }

  func testRejectSessionIDMismatchAndEmptyStorageKey() throws {
    let session = try makeSession()
    let wrongSession = EvidenceMetadata(
      pointID: pointID("p0"),
      sessionID: SessionID.unchecked("OTHER"),
      type: .photo,
      createdAt: fixedInstant,
      storageKey: "k"
    )
    XCTAssertThrowsError(try service.bind(evidence: wrongSession, to: session)) { err in
      guard case EvidenceBindingError.sessionIDMismatch = err else {
        return XCTFail("\(err)")
      }
    }
    let emptyKey = meta(point: "p0", session: session, key: "   ")
    XCTAssertThrowsError(try service.bind(evidence: emptyKey, to: session)) { err in
      XCTAssertEqual(err as? EvidenceBindingError, .emptyStorageKey)
    }
  }

  // MARK: - Derived satisfaction

  func testPointSatisfactionDerivedFromFrozenExpectedEvidenceType() throws {
    var session = try makeSession()
    // p0 is .photo → required 1
    XCTAssertEqual(try service.requiredBindingCount(for: pointID("p0"), in: session), 1)
    // p1 is .multiPhoto → required 2
    XCTAssertEqual(try service.requiredBindingCount(for: pointID("p1"), in: session), 2)

    XCTAssertFalse(service.isPointSatisfied(pointID: pointID("p0"), in: session))
    session = try service.bind(evidence: meta(point: "p0", session: session, key: "p0-1"), to: session)
    XCTAssertTrue(service.isPointSatisfied(pointID: pointID("p0"), in: session))

    XCTAssertFalse(service.isPointSatisfied(pointID: pointID("p1"), in: session))
    session = try service.bind(evidence: meta(point: "p1", session: session, key: "p1-1"), to: session)
    XCTAssertFalse(service.isPointSatisfied(pointID: pointID("p1"), in: session))
    session = try service.bind(evidence: meta(point: "p1", session: session, key: "p1-2"), to: session)
    XCTAssertTrue(service.isPointSatisfied(pointID: pointID("p1"), in: session))

    // Unbind drops satisfaction dynamically — no persisted isSatisfied flag.
    let bound = service.evidence(for: pointID("p1"), in: session)
    session = try service.unbind(evidenceID: bound[0].id, from: session)
    XCTAssertFalse(service.isPointSatisfied(pointID: pointID("p1"), in: session))
  }

  func testSatisfactionFalseForUnknownOrLegacySession() throws {
    let legacy = try InspectionSession(
      id: SessionID.unchecked("INS-21D-LEGACY"),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "L")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planState: .legacyUnassigned
    )
    XCTAssertFalse(service.isPointSatisfied(pointID: pointID("p0"), in: legacy))
    XCTAssertThrowsError(try service.bind(evidence: meta(point: "p0", session: legacy), to: legacy))
    { err in
      XCTAssertEqual(err as? EvidenceBindingError, .noAssignedPlan)
    }
  }

  // MARK: - Persistence Option A

  func testEnvelopeRoundTripPreservesBindings() throws {
    var session = try makeSession()
    let e = meta(
      point: "p0",
      session: session,
      type: .spatialScan,
      key: "scan/opaque-1",
      attrs: ["note": "front"]
    )
    session = try service.bind(evidence: e, to: session)

    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(
      session: session,
      savedAt: fixedInstant
    )
    XCTAssertEqual(envelope.schemaVersion, .v1)
    let decoded = try InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(
      from: InspectionSessionEnvelopeCoder.encode(envelope)
    )
    XCTAssertEqual(decoded.session.evidenceBindings, session.evidenceBindings)
    XCTAssertEqual(
      decoded.session.evidenceBindings?.bindings.first?.payloadAttributes["note"],
      "front"
    )
  }

  func testFileStoreRoundTripPreservesBindings() async throws {
    var session = try makeSession(id: "INS-21D-STORE")
    session = try service.bind(
      evidence: meta(point: "p1", session: session, key: "store-key"),
      to: session
    )
    let dir = FileManager.default.temporaryDirectory
      .appendingPathComponent("sess-21d-\(UUID().uuidString)", isDirectory: true)
    defer { try? FileManager.default.removeItem(at: dir) }
    let store = FileInspectionSessionStore(directoryURL: dir)
    try await store.save(session, savedAt: fixedInstant, expectedRevision: 0)
    let loaded = try await store.load(id: session.id)
    XCTAssertEqual(loaded.evidenceBindings, session.evidenceBindings)
    XCTAssertEqual(service.evidenceCount(for: pointID("p1"), in: loaded), 1)
  }

  func testPre2_1DSessionsDecodeWithoutEvidenceBindings_OptionA() throws {
    let session = try makeSession()
    XCTAssertNil(session.evidenceBindings)
    let data = try InspectionSessionEnvelopeCoder.makeJSONEncoder().encode(session)
    let json = try XCTUnwrap(String(data: data, encoding: .utf8))
    XCTAssertFalse(json.contains("evidenceBindings"))

    let decoded = try InspectionSessionEnvelopeCoder.makeJSONDecoder()
      .decode(InspectionSession.self, from: data)
    XCTAssertNil(decoded.evidenceBindings)

    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(
      session: session,
      savedAt: fixedInstant
    )
    XCTAssertEqual(envelope.schemaVersion, .v1)
    XCTAssertEqual(envelope.schemaVersion, .current)
  }

  func testServiceHasNoSharedMutableGlobalState() throws {
    var s1 = try makeSession(id: "INS-A")
    var s2 = try makeSession(id: "INS-B")
    let a = EvidenceBindingService()
    let b = EvidenceBindingService()
    s1 = try a.bind(evidence: meta(point: "p0", session: s1, key: "a"), to: s1)
    s2 = try b.bind(evidence: meta(point: "p1", session: s2, key: "b"), to: s2)
    XCTAssertEqual(a.evidenceCount(for: pointID("p0"), in: s1), 1)
    XCTAssertEqual(b.evidenceCount(for: pointID("p0"), in: s2), 0)
    XCTAssertEqual(b.evidenceCount(for: pointID("p1"), in: s2), 1)
  }
}
