import XCTest
@testable import ElektronCapture

final class Phase35GuidanceTests: XCTestCase {
  private func tempDir(_ name: String = UUID().uuidString) throws -> URL {
    let url = FileManager.default.temporaryDirectory.appendingPathComponent("p35-\(name)", isDirectory: true)
    try? FileManager.default.removeItem(at: url)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  private struct StreamBundle {
    var camera: ControllableCameraSensorAdapter
    var motion: ControllableMotionSensorAdapter
    var pose: ControllablePoseSensorAdapter
    var depth: ControllableDepthSensorAdapter
    var cams: [SpatialSampleEnvelope<CameraSample>]
    var mots: [SpatialSampleEnvelope<MotionSample>]
    var poses: [SpatialSampleEnvelope<PoseSample>]
    var depths: [SpatialSampleEnvelope<DepthSample>]
    var plan: SensorActivationPlan
    var results: [SensorActivationResult]
    var policy: SpatialCaptureSessionPolicy
    var timeline: CaptureSessionTimeline
  }

  private struct FrozenCaps {
    var camera: SpatialStreamCapability
    var motion: SpatialStreamCapability
    var pose: SpatialStreamCapability
    var depth: SpatialStreamCapability
  }

  private func freezeCap(
    base: SpatialStreamCapability,
    sampleCount: Int,
    unavailableDevice: Bool = false
  ) throws -> SpatialStreamCapability {
    var cap = base
    if unavailableDevice {
      try cap.freeze(outcome: .unavailableDevice)
      return cap
    }
    if sampleCount > 0 {
      while cap.samplesAcquired < UInt64(sampleCount) { cap.recordSample() }
      if cap.stage == .declared { cap.activate() }
      try cap.freeze(outcome: .acquired)
    } else {
      try cap.freeze(outcome: .failed)
    }
    return cap
  }

  private func collectStreams(
    sessionID: String,
    depthUnavailable: Bool = false
  ) async throws -> (StreamBundle, FrozenCaps) {
    let camera = ControllableCameraSensorAdapter()
    let motion = ControllableMotionSensorAdapter()
    let pose = ControllablePoseSensorAdapter()
    let depth = ControllableDepthSensorAdapter()
    depth.unavailableDevice = depthUnavailable
    let coord = SpatialCaptureSessionCoordinator(
      sessionID: sessionID,
      policy: .primaryFixture(),
      camera: camera,
      motion: motion,
      pose: pose,
      depth: depth
    )
    try coord.discoverAndPlan()
    try await coord.startStreams()
    try await coord.collectSamples()
    _ = try await coord.stopStreams()
    let bundle = StreamBundle(
      camera: camera,
      motion: motion,
      pose: pose,
      depth: depth,
      cams: coord.cameraSamples,
      mots: coord.motionSamples,
      poses: coord.poseSamples,
      depths: coord.depthSamples,
      plan: try XCTUnwrap(coord.activationPlan),
      results: coord.activationResults,
      policy: coord.policy,
      timeline: coord.timeline
    )
    let caps = FrozenCaps(
      camera: try freezeCap(base: camera.capability, sampleCount: bundle.cams.count),
      motion: try freezeCap(base: motion.capability, sampleCount: bundle.mots.count),
      pose: try freezeCap(base: pose.capability, sampleCount: bundle.poses.count),
      depth: try freezeCap(
        base: depth.capability,
        sampleCount: bundle.depths.count,
        unavailableDevice: depthUnavailable
      )
    )
    return (bundle, caps)
  }

  private func coverageObs(
    id: String,
    region: CoverageRegionID,
    sessionID: String,
    cameraIDs: [String],
    poseIDs: [String] = [],
    depthIDs: [String] = [],
    viewpoint: ViewpointClass,
    ts: UInt64,
    overlap: Double = 0.4
  ) -> CoverageObservation {
    CoverageObservation(
      coverageObservationID: id,
      regionID: region,
      cameraSampleIDs: cameraIDs,
      poseSampleIDs: poseIDs,
      depthSampleIDs: depthIDs,
      frameEpochID: FixtureGuidedCapturePackageBuilder.frameEpochID,
      sessionRunID: FixtureGuidedCapturePackageBuilder.sessionRunID,
      captureSessionID: sessionID,
      observationTimestampNanoseconds: ts,
      viewpointClass: viewpoint,
      overlapRatio: overlap,
      evidenceOriginAuthority: .testFixture,
      coverageClassification: .partiallyObserved
    )
  }

  private func qObs(
    id: String,
    type: CaptureQualitySignalType,
    value: Double,
    sessionID: String,
    evidence: [String],
    ts: UInt64,
    stream: String? = "camera",
    unit: String = "ratio"
  ) -> CaptureQualityObservation {
    CaptureQualityObservation(
      observationID: id,
      signalType: type,
      observedValue: value,
      unit: unit,
      timestampNanoseconds: ts,
      clockDomain: "fixture_camera",
      captureSessionID: sessionID,
      streamID: stream,
      supportingEvidenceIDs: evidence
    )
  }

  private func fullCoverage(sessionID: String, cams: [String], poses: [String], depths: [String]) -> [CoverageObservation] {
    let regions: [(CoverageRegionID, ViewpointClass, ViewpointClass)] = [
      (.frontExterior, .frontal, .oblique),
      (.rearExterior, .frontal, .oblique),
      (.driverSide, .lateral, .oblique),
      (.passengerSide, .lateral, .oblique),
    ]
    var out: [CoverageObservation] = []
    var t: UInt64 = 10_000_000
    for (i, r) in regions.enumerated() {
      out.append(coverageObs(id: "cov-\(i)a", region: r.0, sessionID: sessionID, cameraIDs: [cams[0]], poseIDs: poses, depthIDs: depths, viewpoint: r.1, ts: t))
      t += 1_000_000
      out.append(coverageObs(id: "cov-\(i)b", region: r.0, sessionID: sessionID, cameraIDs: [cams[min(1, cams.count - 1)]], poseIDs: poses, depthIDs: depths, viewpoint: r.2, ts: t))
      t += 1_000_000
    }
    return out
  }

  private func primaryQualitySequence(sessionID: String, cam0: String, motion0: String) -> [CaptureQualityObservation] {
    [
      // excessive motion then resolved
      qObs(id: "q-motion-hi", type: .excessiveAngularMotion, value: 2.5, sessionID: sessionID, evidence: [motion0], ts: 5_000_000, stream: "motion", unit: "rad_s"),
      qObs(id: "q-motion-ok", type: .excessiveAngularMotion, value: 0.2, sessionID: sessionID, evidence: [motion0], ts: 8_000_000, stream: "motion", unit: "rad_s"),
      qObs(id: "q-blur-ok", type: .imageBlurEstimate, value: 0.1, sessionID: sessionID, evidence: [cam0], ts: 9_000_000),
      qObs(id: "q-depth-ok", type: .depthAvailability, value: 1.0, sessionID: sessionID, evidence: ["capability:depth"], ts: 12_000_000, stream: "depth"),
      qObs(id: "q-track-ok", type: .trackingQuality, value: 0.9, sessionID: sessionID, evidence: [cam0], ts: 13_000_000, stream: "pose"),
    ]
  }

  private func sealGuided(
    sessionID: String,
    packageID: String,
    streams: StreamBundle,
    caps: FrozenCaps,
    quality: [CaptureQualityObservation],
    coverage: [CoverageObservation],
    requiredFailed: Bool = false,
    activeInterruption: Bool = false,
    dir: String = UUID().uuidString
  ) throws -> FixtureGuidedCapturePackageBuilder.GuidedSealResult {
    let inputs = FixtureGuidedCapturePackageBuilder.GuidedSealInputs(
      camera: streams.cams,
      motion: streams.mots,
      pose: streams.poses,
      depth: streams.depths,
      cameraCapability: caps.camera,
      motionCapability: caps.motion,
      poseCapability: caps.pose,
      depthCapability: caps.depth,
      activationPlan: streams.plan,
      activationResults: streams.results,
      sessionPolicy: streams.policy,
      timeline: streams.timeline,
      interruptions: [],
      bufferState: CaptureBufferState(),
      qualityObservations: quality,
      coverageObservations: coverage,
      cancelled: false,
      requiredStreamFailed: requiredFailed,
      activeInterruption: activeInterruption,
      packageID: packageID,
      captureSessionID: sessionID
    )
    return try FixtureGuidedCapturePackageBuilder().seal(inputs, outputDirectory: try tempDir(dir))
  }

  // MARK: - Quality

  func testBlurSignalGeneratedAndResolved() throws {
    let analyzer = CaptureQualityAnalyzer()
    let sid = "SESS-T-BLUR"
    let (signals, _) = try analyzer.evaluate(
      observations: [
        qObs(id: "b1", type: .imageBlurEstimate, value: 0.9, sessionID: sid, evidence: ["cam-0"], ts: 1),
        qObs(id: "b2", type: .imageBlurEstimate, value: 0.1, sessionID: sid, evidence: ["cam-0"], ts: 2),
      ],
      captureSessionID: sid
    )
    XCTAssertEqual(signals[0].thresholdComparison, .aboveMaximum)
    XCTAssertFalse(signals[0].resolved)
    XCTAssertEqual(signals[1].thresholdComparison, .withinRange)
    XCTAssertTrue(signals[1].resolved)
    XCTAssertEqual(signals[0].guidanceAuthority, .guidanceEstimate)
    XCTAssertEqual(signals[0].evidenceOriginAuthority, .testFixture)
  }

  func testUnderexposureAndOverexposureSignals() throws {
    let analyzer = CaptureQualityAnalyzer()
    let sid = "SESS-T-EXP"
    let (signals, _) = try analyzer.evaluate(
      observations: [
        qObs(id: "u", type: .underexposure, value: 0.5, sessionID: sid, evidence: ["cam-0"], ts: 1),
        qObs(id: "o", type: .overexposure, value: 0.5, sessionID: sid, evidence: ["cam-0"], ts: 2),
      ],
      captureSessionID: sid
    )
    XCTAssertEqual(signals.map(\.signalType), [.underexposure, .overexposure])
    XCTAssertTrue(signals.allSatisfy { $0.thresholdComparison == .aboveMaximum })
  }

  func testExcessiveAngularAndTranslationMotion() throws {
    let analyzer = CaptureQualityAnalyzer()
    let sid = "SESS-T-MOT"
    let (signals, _) = try analyzer.evaluate(
      observations: [
        qObs(id: "a", type: .excessiveAngularMotion, value: 3.0, sessionID: sid, evidence: ["m0"], ts: 1, stream: "motion"),
        qObs(id: "t", type: .excessiveTranslationRate, value: 5.0, sessionID: sid, evidence: ["m0"], ts: 2, stream: "motion"),
      ],
      captureSessionID: sid
    )
    XCTAssertEqual(signals.count, 2)
    XCTAssertTrue(signals.allSatisfy { !$0.resolved })
  }

  func testDuplicateFrameAndDroppedSampleAndStorage() throws {
    let analyzer = CaptureQualityAnalyzer()
    let sid = "SESS-T-DROP"
    let (signals, _) = try analyzer.evaluate(
      observations: [
        qObs(id: "d", type: .cameraFrameDuplication, value: 0.2, sessionID: sid, evidence: ["cam-0"], ts: 1),
        qObs(id: "r", type: .droppedSampleRate, value: 0.3, sessionID: sid, evidence: ["cam-0"], ts: 2),
        qObs(id: "s", type: .storagePressure, value: 0.95, sessionID: sid, evidence: ["session"], ts: 3, stream: nil),
      ],
      captureSessionID: sid
    )
    XCTAssertEqual(signals[2].severity, .blocking)
  }

  func testTrackingDegradationAndDepthQualityAndSyncFailure() throws {
    let analyzer = CaptureQualityAnalyzer()
    let sid = "SESS-T-TRK"
    let (signals, _) = try analyzer.evaluate(
      observations: [
        qObs(id: "t", type: .trackingQuality, value: 0.2, sessionID: sid, evidence: ["pose-0"], ts: 1, stream: "pose"),
        qObs(id: "dv", type: .depthValidityPercentage, value: 0.2, sessionID: sid, evidence: ["depth-0"], ts: 2, stream: "depth"),
        qObs(id: "sy", type: .timestampSynchronizationHealth, value: 0.1, sessionID: sid, evidence: ["cam-0"], ts: 3),
      ],
      captureSessionID: sid
    )
    XCTAssertTrue(signals.allSatisfy { $0.thresholdComparison == .belowMinimum })
  }

  func testNonFiniteObservedValueRejected() {
    let analyzer = CaptureQualityAnalyzer()
    XCTAssertThrowsError(
      try analyzer.evaluate(
        observations: [
          qObs(id: "bad", type: .imageBlurEstimate, value: .nan, sessionID: "S", evidence: ["e"], ts: 1),
        ],
        captureSessionID: "S"
      )
    )
  }

  func testCrossSessionQualityRejected() {
    let analyzer = CaptureQualityAnalyzer()
    XCTAssertThrowsError(
      try analyzer.evaluate(
        observations: [
          qObs(id: "x", type: .imageBlurEstimate, value: 0.1, sessionID: "OTHER", evidence: ["e"], ts: 1),
        ],
        captureSessionID: "S"
      )
    )
  }

  // MARK: - Coverage

  func testRequiredRegionMissingAndSatisfied() throws {
    var engine = CaptureCoverageEngine(
      expectedSessionID: "SESS-C",
      expectedFrameEpochID: FixtureGuidedCapturePackageBuilder.frameEpochID,
      expectedSessionRunID: FixtureGuidedCapturePackageBuilder.sessionRunID,
      knownEvidenceIDs: ["cam-0", "cam-1"]
    )
    let partial = [
      coverageObs(id: "c1", region: .frontExterior, sessionID: "SESS-C", cameraIDs: ["cam-0"], viewpoint: .frontal, ts: 1),
    ]
    let (_, sum1, _) = try engine.ingest(partial)
    XCTAssertFalse(sum1.policySatisfied)
    XCTAssertTrue(sum1.requiredMissing.contains(CoverageRegionID.rearExterior.rawValue))

    let full = fullCoverage(sessionID: "SESS-C", cams: ["cam-0", "cam-1"], poses: [], depths: [])
    let (_, sum2, _) = try engine.ingest(full)
    XCTAssertTrue(sum2.policySatisfied)
    XCTAssertTrue(sum2.requiredMissing.isEmpty)
  }

  func testOptionalRegionMissingDoesNotBlock() throws {
    var engine = CaptureCoverageEngine(
      expectedSessionID: "SESS-C2",
      expectedFrameEpochID: FixtureGuidedCapturePackageBuilder.frameEpochID,
      expectedSessionRunID: FixtureGuidedCapturePackageBuilder.sessionRunID,
      knownEvidenceIDs: ["cam-0", "cam-1"]
    )
    let full = fullCoverage(sessionID: "SESS-C2", cams: ["cam-0", "cam-1"], poses: [], depths: [])
    let (_, sum, _) = try engine.ingest(full)
    XCTAssertTrue(sum.policySatisfied)
    XCTAssertFalse(sum.optionalMissing.isEmpty)
  }

  func testDuplicateCoverageDoesNotInflate() throws {
    var engine = CaptureCoverageEngine(
      expectedSessionID: "SESS-C3",
      expectedFrameEpochID: FixtureGuidedCapturePackageBuilder.frameEpochID,
      expectedSessionRunID: FixtureGuidedCapturePackageBuilder.sessionRunID,
      knownEvidenceIDs: ["cam-0"]
    )
    let a = coverageObs(id: "c1", region: .frontExterior, sessionID: "SESS-C3", cameraIDs: ["cam-0"], viewpoint: .frontal, ts: 1)
    let dup = coverageObs(id: "c2", region: .frontExterior, sessionID: "SESS-C3", cameraIDs: ["cam-0"], viewpoint: .frontal, ts: 2)
    let (map, _, accepted) = try engine.ingest([a, dup])
    XCTAssertEqual(accepted.count, 1)
    XCTAssertEqual(map.cells.first { $0.regionID == .frontExterior }?.observationCount, 1)
  }

  func testCrossSessionAndUnknownEvidenceRejected() {
    var engine = CaptureCoverageEngine(
      expectedSessionID: "SESS-C4",
      expectedFrameEpochID: FixtureGuidedCapturePackageBuilder.frameEpochID,
      expectedSessionRunID: FixtureGuidedCapturePackageBuilder.sessionRunID,
      knownEvidenceIDs: ["cam-0"]
    )
    XCTAssertThrowsError(
      try engine.ingest([
        coverageObs(id: "x", region: .frontExterior, sessionID: "OTHER", cameraIDs: ["cam-0"], viewpoint: .frontal, ts: 1),
      ])
    )
    XCTAssertThrowsError(
      try engine.ingest([
        coverageObs(id: "y", region: .frontExterior, sessionID: "SESS-C4", cameraIDs: ["missing"], viewpoint: .frontal, ts: 1),
      ])
    )
  }

  func testCrossEpochCoverageRejected() {
    var engine = CaptureCoverageEngine(
      expectedSessionID: "SESS-C5",
      expectedFrameEpochID: FixtureGuidedCapturePackageBuilder.frameEpochID,
      expectedSessionRunID: FixtureGuidedCapturePackageBuilder.sessionRunID,
      knownEvidenceIDs: ["cam-0"]
    )
    var obs = coverageObs(id: "z", region: .frontExterior, sessionID: "SESS-C5", cameraIDs: ["cam-0"], viewpoint: .frontal, ts: 1)
    obs = CoverageObservation(
      coverageObservationID: obs.coverageObservationID,
      regionID: obs.regionID,
      cameraSampleIDs: obs.cameraSampleIDs,
      poseSampleIDs: [],
      depthSampleIDs: [],
      frameEpochID: "epoch-other",
      sessionRunID: obs.sessionRunID,
      captureSessionID: obs.captureSessionID,
      observationTimestampNanoseconds: obs.observationTimestampNanoseconds,
      viewpointClass: obs.viewpointClass,
      overlapRatio: obs.overlapRatio,
      evidenceOriginAuthority: .testFixture,
      coverageClassification: .partiallyObserved
    )
    XCTAssertThrowsError(try engine.ingest([obs]))
  }

  // MARK: - Guidance + completion

  func testMoveSlowerEmittedBeforeViewpointAndResolved() throws {
    let engine = CaptureGuidanceEngine()
    let sid = "SESS-G1"
    let signals = [
      CaptureQualitySignal(
        signalID: "QS-1", signalType: .excessiveAngularMotion, severity: .severe,
        timestampNanoseconds: 1, clockDomain: "fixture_motion", captureSessionID: sid,
        streamID: "motion", regionID: nil, supportingEvidenceIDs: ["m0"], observedValue: 3,
        thresholdProfileID: CaptureQualityThresholdProfile.fixtureProfileID,
        thresholdComparison: .aboveMaximum, evidenceOriginAuthority: .testFixture,
        guidanceAuthority: .guidanceEstimate,
        characterizationStatus: .pendingPhysicalCharacterization, resolved: false
      ),
      CaptureQualitySignal(
        signalID: "QS-2", signalType: .excessiveAngularMotion, severity: .informational,
        timestampNanoseconds: 5, clockDomain: "fixture_motion", captureSessionID: sid,
        streamID: "motion", regionID: nil, supportingEvidenceIDs: ["m0"], observedValue: 0.1,
        thresholdProfileID: CaptureQualityThresholdProfile.fixtureProfileID,
        thresholdComparison: .withinRange, evidenceOriginAuthority: .testFixture,
        guidanceAuthority: .guidanceEstimate,
        characterizationStatus: .pendingPhysicalCharacterization, resolved: true
      ),
    ]
    let summary = CoverageSummary(
      summaryID: "CS", captureSessionID: sid, coveragePolicyID: CoveragePolicy.fixturePolicyID,
      requiredSatisfied: [], requiredMissing: [CoverageRegionID.rearExterior.rawValue],
      optionalObserved: [], optionalMissing: [], policySatisfied: false,
      evidenceOriginAuthority: .testFixture, guidanceAuthority: .guidanceEstimate
    )
    let gaps = [
      CoverageGap(gapID: "GAP-REAR_EXTERIOR", regionID: .rearExterior, reason: "unobserved", required: true),
    ]
    let (history, completion, _) = try engine.generate(
      captureSessionID: sid,
      signals: signals,
      coverageSummary: summary,
      coverageGaps: gaps,
      depthOutcomeAcquired: true,
      activeInterruption: false,
      requiredStreamFailed: false,
      cancelled: false
    )
    XCTAssertTrue(history.contains { $0.guidanceCode == .moveSlower })
    XCTAssertTrue(history.contains { $0.guidanceCode == .returnToRegion && $0.lifecycle == .active })
    // MOVE_SLOWER priority precedes RETURN_TO_REGION
    let moveIdx = history.firstIndex { $0.guidanceCode == .moveSlower }!
    let retIdx = history.firstIndex { $0.guidanceCode == .returnToRegion }!
    XCTAssertLessThan(history[moveIdx].priority, history[retIdx].priority)
    XCTAssertEqual(completion.recommendation, .continueCapture)
  }

  func testDuplicateActiveGuidancePrevented() throws {
    let engine = CaptureGuidanceEngine()
    let sid = "SESS-G2"
    let s1 = CaptureQualitySignal(
      signalID: "QS-A", signalType: .storagePressure, severity: .blocking,
      timestampNanoseconds: 1, clockDomain: "fixture_camera", captureSessionID: sid,
      streamID: nil, regionID: nil, supportingEvidenceIDs: ["s"], observedValue: 0.99,
      thresholdProfileID: CaptureQualityThresholdProfile.fixtureProfileID,
      thresholdComparison: .aboveMaximum, evidenceOriginAuthority: .testFixture,
      guidanceAuthority: .guidanceEstimate,
      characterizationStatus: .pendingPhysicalCharacterization, resolved: false
    )
    let s2 = CaptureQualitySignal(
      signalID: "QS-B", signalType: .storagePressure, severity: .blocking,
      timestampNanoseconds: 2, clockDomain: "fixture_camera", captureSessionID: sid,
      streamID: nil, regionID: nil, supportingEvidenceIDs: ["s"], observedValue: 0.99,
      thresholdProfileID: CaptureQualityThresholdProfile.fixtureProfileID,
      thresholdComparison: .aboveMaximum, evidenceOriginAuthority: .testFixture,
      guidanceAuthority: .guidanceEstimate,
      characterizationStatus: .pendingPhysicalCharacterization, resolved: false
    )
    let summary = CoverageSummary(
      summaryID: "CS", captureSessionID: sid, coveragePolicyID: CoveragePolicy.fixturePolicyID,
      requiredSatisfied: CoveragePolicy.fixtureDefault().requiredRegions.map(\.rawValue),
      requiredMissing: [], optionalObserved: [], optionalMissing: [], policySatisfied: true,
      evidenceOriginAuthority: .testFixture, guidanceAuthority: .guidanceEstimate
    )
    let (history, _, _) = try engine.generate(
      captureSessionID: sid, signals: [s1, s2], coverageSummary: summary, coverageGaps: [],
      depthOutcomeAcquired: true, activeInterruption: false, requiredStreamFailed: false, cancelled: false
    )
    XCTAssertEqual(history.filter { $0.guidanceCode == .storagePressure && $0.lifecycle == .active }.count, 1)
  }

  func testCancelledProducesCancelledCompletion() throws {
    let engine = CaptureGuidanceEngine()
    let (_, completion, _) = try engine.generate(
      captureSessionID: "SESS-X",
      signals: [],
      coverageSummary: CoverageSummary(
        summaryID: "CS", captureSessionID: "SESS-X", coveragePolicyID: "P",
        requiredSatisfied: [], requiredMissing: [], optionalObserved: [], optionalMissing: [],
        policySatisfied: false, evidenceOriginAuthority: .testFixture, guidanceAuthority: .guidanceEstimate
      ),
      coverageGaps: [],
      depthOutcomeAcquired: true,
      activeInterruption: false,
      requiredStreamFailed: false,
      cancelled: true
    )
    XCTAssertEqual(completion.recommendation, .cancelled)
    XCTAssertFalse(completion.note.uppercased().contains("ENGINEERING_COMPLETE"))
  }

  func testCompletionLanguageForbidsEngineeringClaims() throws {
    let engine = CaptureGuidanceEngine()
    let summary = CoverageSummary(
      summaryID: "CS", captureSessionID: "SESS-Y", coveragePolicyID: CoveragePolicy.fixturePolicyID,
      requiredSatisfied: CoveragePolicy.fixtureDefault().requiredRegions.map(\.rawValue),
      requiredMissing: [], optionalObserved: [], optionalMissing: [], policySatisfied: true,
      evidenceOriginAuthority: .testFixture, guidanceAuthority: .guidanceEstimate
    )
    let (_, completion, _) = try engine.generate(
      captureSessionID: "SESS-Y", signals: [], coverageSummary: summary, coverageGaps: [],
      depthOutcomeAcquired: true, activeInterruption: false, requiredStreamFailed: false, cancelled: false
    )
    XCTAssertEqual(completion.recommendation, .sufficientForPackageFinalization)
    let upper = completion.note.uppercased()
    for banned in ["GEOMETRY_COMPLETE", "ENGINEERING_COMPLETE", "DIGITAL_TWIN_COMPLETE", "FULLY_SCANNED"] {
      XCTAssertFalse(upper.contains(banned))
    }
  }

  // MARK: - Primary guided package + determinism

  func testValidGuidedCaptureSealsWithHistory() async throws {
    let sid = FixtureGuidedCapturePackageBuilder.primarySessionID
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let cams = streams.cams.map(\.sampleID)
    let poses = streams.poses.map(\.sampleID)
    let depths = streams.depths.map(\.sampleID)
    let result = try sealGuided(
      sessionID: sid,
      packageID: FixtureGuidedCapturePackageBuilder.primaryPackageID,
      streams: streams,
      caps: caps,
      quality: primaryQualitySequence(sessionID: sid, cam0: cams[0], motion0: streams.mots[0].sampleID),
      coverage: fullCoverage(sessionID: sid, cams: cams, poses: poses, depths: depths),
      dir: "primary"
    )
    XCTAssertEqual(result.completion.recommendation, .sufficientForPackageFinalization)
    XCTAssertTrue(result.guidanceHistory.contains { $0.guidanceCode == .moveSlower })
    XCTAssertTrue(result.guidanceHistory.contains { $0.guidanceCode == .capturePolicySatisfied })
    XCTAssertEqual(result.package.manifest.packageID, FixtureGuidedCapturePackageBuilder.primaryPackageID)
    let root = result.package.rootURL
    for name in [
      "quality_threshold_profile.json", "quality_signals.json", "quality_summary.json",
      "coverage_policy.json", "coverage_observations.json", "coverage_map.json", "coverage_summary.json",
      "guidance_history.json", "completion_recommendation.json", "derivation_record.json",
      "manifest.json", "package_inventory.json", "payload/camera/0000.bin",
    ] {
      XCTAssertTrue(FileManager.default.fileExists(atPath: root.appendingPathComponent(name).path), name)
    }
    XCTAssertEqual(result.derivation.evidenceAuthority, .guidanceEstimate)
    XCTAssertEqual(result.derivation.reproducibilityStatus, .deterministicReplay)
  }

  func testDeterministicReplayIdenticalDerivedDigests() async throws {
    let sid = FixtureGuidedCapturePackageBuilder.primarySessionID
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let cams = streams.cams.map(\.sampleID)
    let poses = streams.poses.map(\.sampleID)
    let depths = streams.depths.map(\.sampleID)
    let quality = primaryQualitySequence(sessionID: sid, cam0: cams[0], motion0: streams.mots[0].sampleID)
    let coverage = fullCoverage(sessionID: sid, cams: cams, poses: poses, depths: depths)
    let a = try sealGuided(sessionID: sid, packageID: FixtureGuidedCapturePackageBuilder.primaryPackageID, streams: streams,
      caps: caps, quality: quality, coverage: coverage, dir: "det-a")
    let b = try sealGuided(sessionID: sid, packageID: FixtureGuidedCapturePackageBuilder.primaryPackageID, streams: streams,
      caps: caps, quality: quality, coverage: coverage, dir: "det-b")
    XCTAssertEqual(a.derivedEvidenceSHA256, b.derivedEvidenceSHA256)
    XCTAssertEqual(a.package.packageContentSHA256, b.package.packageContentSHA256)
    XCTAssertEqual(a.package.manifestSHA256, b.package.manifestSHA256)
    XCTAssertEqual(a.package.packageClosureSHA256, b.package.packageClosureSHA256)
    XCTAssertEqual(
      try CanonicalJSON.data(["h": a.guidanceHistory.map { $0.dictionary() }]),
      try CanonicalJSON.data(["h": b.guidanceHistory.map { $0.dictionary() }])
    )
    XCTAssertEqual(a.completion.recommendation, b.completion.recommendation)
  }

  func testThresholdChangeChangesDerivedDigest() async throws {
    let sid = FixtureGuidedCapturePackageBuilder.primarySessionID
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let cams = streams.cams.map(\.sampleID)
    let quality = [qObs(id: "b", type: .imageBlurEstimate, value: 0.3, sessionID: sid, evidence: [cams[0]], ts: 1)]
    let coverage = fullCoverage(sessionID: sid, cams: cams, poses: streams.poses.map(\.sampleID), depths: streams.depths.map(\.sampleID))
    let a = try sealGuided(sessionID: sid, packageID: "SPKG-A", streams: streams,
      caps: caps, quality: quality, coverage: coverage, dir: "thr-a")
    var profile = CaptureQualityThresholdProfile()
    profile.maximumLimits[CaptureQualitySignalType.imageBlurEstimate.rawValue] = 0.05
    let inputs = FixtureGuidedCapturePackageBuilder.GuidedSealInputs(
      camera: streams.cams, motion: streams.mots, pose: streams.poses, depth: streams.depths,
      cameraCapability: caps.camera, motionCapability: caps.motion,
      poseCapability: caps.pose, depthCapability: caps.depth,
      activationPlan: streams.plan, activationResults: streams.results, sessionPolicy: streams.policy,
      timeline: streams.timeline, interruptions: [], bufferState: CaptureBufferState(),
      qualityObservations: quality, coverageObservations: coverage, thresholdProfile: profile,
      packageID: "SPKG-B", captureSessionID: sid
    )
    let b = try FixtureGuidedCapturePackageBuilder().seal(inputs, outputDirectory: try tempDir("thr-b"))
    XCTAssertNotEqual(a.derivedEvidenceSHA256, b.derivedEvidenceSHA256)
  }

  func testMissingRegionFixtureContinueCapture() async throws {
    let sid = FixtureGuidedCapturePackageBuilder.missingRegionSessionID
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let cams = streams.cams.map(\.sampleID)
    var coverage = fullCoverage(sessionID: sid, cams: cams, poses: streams.poses.map(\.sampleID), depths: streams.depths.map(\.sampleID))
    coverage = coverage.filter { $0.regionID != .rearExterior }
    let result = try sealGuided(
      sessionID: sid,
      packageID: FixtureGuidedCapturePackageBuilder.missingRegionPackageID,
      streams: streams,
      caps: caps,
      quality: [qObs(id: "ok", type: .imageBlurEstimate, value: 0.1, sessionID: sid, evidence: [cams[0]], ts: 1)],
      coverage: coverage,
      dir: "missing"
    )
    XCTAssertEqual(result.completion.recommendation, .continueCapture)
    XCTAssertTrue(result.guidanceHistory.contains { $0.guidanceCode == .returnToRegion && $0.lifecycle == .active })
  }

  func testPersistentBlurRequiresRecapture() async throws {
    let sid = FixtureGuidedCapturePackageBuilder.blurSessionID
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let cams = streams.cams.map(\.sampleID)
    let result = try sealGuided(
      sessionID: sid,
      packageID: FixtureGuidedCapturePackageBuilder.blurPackageID,
      streams: streams,
      caps: caps,
      quality: [qObs(id: "blur", type: .imageBlurEstimate, value: 0.95, sessionID: sid, evidence: [cams[0]], ts: 1)],
      coverage: fullCoverage(sessionID: sid, cams: cams, poses: streams.poses.map(\.sampleID), depths: streams.depths.map(\.sampleID)),
      dir: "blur"
    )
    XCTAssertEqual(result.completion.recommendation, .recaptureRequired)
    XCTAssertTrue(result.guidanceHistory.contains { $0.guidanceCode == .holdSteadier })
  }

  func testOptionalDepthUnavailableStillCompletes() async throws {
    let sid = FixtureGuidedCapturePackageBuilder.noDepthSessionID
    let (streams, caps) = try await collectStreams(sessionID: sid, depthUnavailable: true)
    let cams = streams.cams.map(\.sampleID)
    let result = try sealGuided(
      sessionID: sid,
      packageID: FixtureGuidedCapturePackageBuilder.noDepthPackageID,
      streams: streams,
      caps: caps,
      quality: [
        qObs(id: "ok", type: .imageBlurEstimate, value: 0.1, sessionID: sid, evidence: [cams[0]], ts: 1),
        qObs(id: "d", type: .depthAvailability, value: 0.0, sessionID: sid, evidence: ["capability:depth"], ts: 2, stream: "depth"),
      ],
      coverage: fullCoverage(sessionID: sid, cams: cams, poses: streams.poses.map(\.sampleID), depths: []),
      dir: "nodepth"
    )
    XCTAssertEqual(result.completion.recommendation, .sufficientForPackageFinalization)
    XCTAssertTrue(result.guidanceHistory.contains { $0.guidanceCode == .depthUnavailable })
  }

  func testTrackingDegradationGuidance() async throws {
    let sid = FixtureGuidedCapturePackageBuilder.trackingSessionID
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let cams = streams.cams.map(\.sampleID)
    let result = try sealGuided(
      sessionID: sid,
      packageID: FixtureGuidedCapturePackageBuilder.trackingPackageID,
      streams: streams,
      caps: caps,
      quality: [
        qObs(id: "t", type: .trackingQuality, value: 0.1, sessionID: sid, evidence: [streams.poses[0].sampleID], ts: 1, stream: "pose"),
      ],
      coverage: fullCoverage(sessionID: sid, cams: cams, poses: streams.poses.map(\.sampleID), depths: streams.depths.map(\.sampleID)),
      dir: "track"
    )
    XCTAssertTrue(result.guidanceHistory.contains { $0.guidanceCode == .trackingDegraded })
  }

  func testStoragePressureGuidance() async throws {
    let sid = FixtureGuidedCapturePackageBuilder.storageSessionID
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let cams = streams.cams.map(\.sampleID)
    let result = try sealGuided(
      sessionID: sid,
      packageID: FixtureGuidedCapturePackageBuilder.storagePackageID,
      streams: streams,
      caps: caps,
      quality: [
        qObs(id: "s", type: .storagePressure, value: 0.99, sessionID: sid, evidence: ["session"], ts: 1, stream: nil),
      ],
      coverage: fullCoverage(sessionID: sid, cams: cams, poses: streams.poses.map(\.sampleID), depths: streams.depths.map(\.sampleID)),
      dir: "storage"
    )
    XCTAssertEqual(result.completion.recommendation, .pauseAndRecover)
    XCTAssertTrue(result.guidanceHistory.contains { $0.guidanceCode == .storagePressure })
  }

  func testRequiredInterruptionFailsPolicy() async throws {
    let sid = "SESS-FIXTURE-GUIDED-REQFAIL-000001"
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let cams = streams.cams.map(\.sampleID)
    let result = try sealGuided(
      sessionID: sid,
      packageID: "SPKG-FIXTURE-GUIDED-REQFAIL-000001",
      streams: streams,
      caps: caps,
      quality: [qObs(id: "ok", type: .imageBlurEstimate, value: 0.1, sessionID: sid, evidence: [cams[0]], ts: 1)],
      coverage: fullCoverage(sessionID: sid, cams: cams, poses: streams.poses.map(\.sampleID), depths: streams.depths.map(\.sampleID)),
      requiredFailed: true,
      dir: "reqfail"
    )
    XCTAssertEqual(result.completion.recommendation, .failedRequiredPolicy)
  }

  func testCancelledSealRejected() async throws {
    let sid = "SESS-FIXTURE-GUIDED-CANCEL-000001"
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let inputs = FixtureGuidedCapturePackageBuilder.GuidedSealInputs(
      camera: streams.cams, motion: streams.mots, pose: streams.poses, depth: streams.depths,
      cameraCapability: caps.camera, motionCapability: caps.motion,
      poseCapability: caps.pose, depthCapability: caps.depth,
      activationPlan: streams.plan, activationResults: streams.results, sessionPolicy: streams.policy,
      timeline: streams.timeline, interruptions: [], bufferState: CaptureBufferState(),
      qualityObservations: [], coverageObservations: [], cancelled: true,
      packageID: "SPKG-FIXTURE-GUIDED-CANCEL-000001", captureSessionID: sid
    )
    XCTAssertThrowsError(try FixtureGuidedCapturePackageBuilder().seal(inputs, outputDirectory: try tempDir("cancel"))) { err in
      XCTAssertEqual(err as? SpatialEvidenceError, .sessionCancelled)
    }
  }

  func testGuidanceAuthorityRemainsGuidanceEstimate() async throws {
    let sid = FixtureGuidedCapturePackageBuilder.primarySessionID
    let (streams, caps) = try await collectStreams(sessionID: sid)
    let cams = streams.cams.map(\.sampleID)
    let result = try sealGuided(
      sessionID: sid,
      packageID: FixtureGuidedCapturePackageBuilder.primaryPackageID,
      streams: streams,
      caps: caps,
      quality: primaryQualitySequence(sessionID: sid, cam0: cams[0], motion0: streams.mots[0].sampleID),
      coverage: fullCoverage(sessionID: sid, cams: cams, poses: streams.poses.map(\.sampleID), depths: streams.depths.map(\.sampleID)),
      dir: "auth"
    )
    XCTAssertTrue(result.guidanceHistory.allSatisfy { $0.guidanceAuthority == .guidanceEstimate })
    XCTAssertTrue(result.guidanceHistory.allSatisfy { !$0.humanReadableInstruction.isEmpty })
  }

  func testWriteGuidedGoldenWhenRequested() async throws {
    guard ProcessInfo.processInfo.environment["PHASE35_WRITE_GOLDEN"] == "1" else {
      throw XCTSkip("Set PHASE35_WRITE_GOLDEN=1 to emit guided package fixtures")
    }
    let outRoot = URL(fileURLWithPath: ProcessInfo.processInfo.environment["PHASE35_GOLDEN_OUT"]
      ?? "Docs/Evidence/SPRINT_3_5")
    try FileManager.default.createDirectory(at: outRoot, withIntermediateDirectories: true)

    func emit(packageID: String, sessionID: String, depthUnavailable: Bool, quality: ([String], [String], [String], StreamBundle) -> [CaptureQualityObservation], coverageFilter: ((CoverageObservation) -> Bool)? = nil, requiredFailed: Bool = false) async throws -> FixtureGuidedCapturePackageBuilder.GuidedSealResult {
      let (streams, caps) = try await collectStreams(sessionID: sessionID, depthUnavailable: depthUnavailable)
      let cams = streams.cams.map(\.sampleID)
      let poses = streams.poses.map(\.sampleID)
      let depths = streams.depths.map(\.sampleID)
      var coverage = fullCoverage(sessionID: sessionID, cams: cams, poses: poses, depths: depths)
      if let coverageFilter { coverage = coverage.filter(coverageFilter) }
      let dir = outRoot.appendingPathComponent(packageID)
      try? FileManager.default.removeItem(at: dir)
      let inputs = FixtureGuidedCapturePackageBuilder.GuidedSealInputs(
        camera: streams.cams, motion: streams.mots, pose: streams.poses, depth: streams.depths,
        cameraCapability: caps.camera, motionCapability: caps.motion,
        poseCapability: caps.pose, depthCapability: caps.depth,
        activationPlan: streams.plan, activationResults: streams.results, sessionPolicy: streams.policy,
        timeline: streams.timeline, interruptions: [], bufferState: CaptureBufferState(),
        qualityObservations: quality(cams, poses, depths, streams),
        coverageObservations: coverage,
        requiredStreamFailed: requiredFailed,
        packageID: packageID, captureSessionID: sessionID
      )
      let result = try FixtureGuidedCapturePackageBuilder().seal(inputs, outputDirectory: dir)
      try writeInventorySidecar(result: result, outRoot: outRoot, filename: "\(packageID.lowercased().replacingOccurrences(of: "spkg-fixture-", with: ""))_package_inventory.json")
      return result
    }

    _ = try await emit(
      packageID: FixtureGuidedCapturePackageBuilder.primaryPackageID,
      sessionID: FixtureGuidedCapturePackageBuilder.primarySessionID,
      depthUnavailable: false,
      quality: { cams, _, _, streams in
        self.primaryQualitySequence(sessionID: FixtureGuidedCapturePackageBuilder.primarySessionID, cam0: cams[0], motion0: streams.mots[0].sampleID)
      }
    )
    _ = try await emit(
      packageID: FixtureGuidedCapturePackageBuilder.missingRegionPackageID,
      sessionID: FixtureGuidedCapturePackageBuilder.missingRegionSessionID,
      depthUnavailable: false,
      quality: { cams, _, _, _ in
        [self.qObs(id: "ok", type: .imageBlurEstimate, value: 0.1, sessionID: FixtureGuidedCapturePackageBuilder.missingRegionSessionID, evidence: [cams[0]], ts: 1)]
      },
      coverageFilter: { $0.regionID != .rearExterior }
    )
    _ = try await emit(
      packageID: FixtureGuidedCapturePackageBuilder.blurPackageID,
      sessionID: FixtureGuidedCapturePackageBuilder.blurSessionID,
      depthUnavailable: false,
      quality: { cams, _, _, _ in
        [self.qObs(id: "blur", type: .imageBlurEstimate, value: 0.95, sessionID: FixtureGuidedCapturePackageBuilder.blurSessionID, evidence: [cams[0]], ts: 1)]
      }
    )
    _ = try await emit(
      packageID: FixtureGuidedCapturePackageBuilder.noDepthPackageID,
      sessionID: FixtureGuidedCapturePackageBuilder.noDepthSessionID,
      depthUnavailable: true,
      quality: { cams, _, _, _ in
        [
          self.qObs(id: "ok", type: .imageBlurEstimate, value: 0.1, sessionID: FixtureGuidedCapturePackageBuilder.noDepthSessionID, evidence: [cams[0]], ts: 1),
          self.qObs(id: "d", type: .depthAvailability, value: 0.0, sessionID: FixtureGuidedCapturePackageBuilder.noDepthSessionID, evidence: ["capability:depth"], ts: 2, stream: "depth"),
        ]
      }
    )
  }

  private func writeInventorySidecar(
    result: FixtureGuidedCapturePackageBuilder.GuidedSealResult,
    outRoot: URL,
    filename: String
  ) throws {
    let closure = try XCTUnwrap(result.package.packageClosureSHA256)
    try CanonicalJSON.data([
      "schema_id": "Sprint35FixturePackageInventory",
      "schema_version": "1.0.0",
      "package_id": result.package.manifest.packageID,
      "capture_session_id": result.package.manifest.captureSessionID,
      "evidence_origin_authority": "TEST_FIXTURE",
      "guidance_authority": "GUIDANCE_ESTIMATE",
      "fixture_payload_content_sha256": result.package.packageContentSHA256,
      "fixture_manifest_sha256": result.package.manifestSHA256,
      "fixture_package_closure_sha256": closure,
      "derived_evidence_sha256": result.derivedEvidenceSHA256,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "completion_recommendation": result.completion.recommendation.rawValue,
      "host_claim": "NO_PHYSICAL_DEVICE_EXECUTION",
    ] as [String: Any]).write(to: outRoot.appendingPathComponent(filename), options: .atomic)
  }
}
