import XCTest
@testable import ElektronCapture

final class Phase4DSurfaceReconstructionTests: XCTestCase {
  private func tempDir(_ name: String) throws -> URL {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("phase4d-\(name)-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
    return url
  }

  private func sealAndRun4C4D(
    cancelDuring: SurfaceReconstructionJobState? = nil
  ) throws -> (
    sealed: FixtureSurfaceReconstructionPackageBuilder.SealResult,
    pkgRoot: URL,
    phase4c: Phase4CPipelineResult,
    phase4d: Phase4DPipelineResult
  ) {
    let pkgRoot = try tempDir("pkg")
    let sealed = try FixtureSurfaceReconstructionPackageBuilder().sealPrimary(outputDirectory: pkgRoot)
    let reconOut = try tempDir("4c")
    let phase4c = try Phase4CPipeline().run(
      packageRoot: pkgRoot,
      outputRoot: reconOut,
      sealedGeometry: sealed.multiviewGeometry
    )
    let surfaceOut = try tempDir("4d")
    let phase4d = try Phase4DPipeline(cancelDuring: cancelDuring).run(
      phase4COutputRoot: reconOut,
      outputRoot: surfaceOut,
      sourcePackageRoot: pkgRoot,
      sourcePackageClosureSHA256: sealed.package.packageClosureSHA256 ?? "",
      phase4COutputClosureSHA256: phase4c.outputClosureSHA256
    )
    return (sealed, pkgRoot, phase4c, phase4d)
  }

  // MARK: - Package / eligibility

  func testSurfacePackageIDs() throws {
    let root = try tempDir("ids")
    let sealed = try FixtureSurfaceReconstructionPackageBuilder().sealPrimary(outputDirectory: root)
    XCTAssertEqual(sealed.package.manifest.packageID, Phase4DFixtureIDs.inputPackageID)
    XCTAssertEqual(sealed.geometry.geometryID, Phase4DFixtureIDs.fixtureGeometryID)
  }

  func testEligibleSyntheticSurface() throws {
    let r = try sealAndRun4C4D()
    XCTAssertTrue(r.phase4d.eligibility.isEligible)
    XCTAssertTrue(
      r.phase4d.eligibility.outcome == .eligibleSyntheticSurface
        || r.phase4d.eligibility.outcome == .eligibleWithSparseRegions
    )
  }

  func testMissingFusedCloudIneligible() throws {
    var inventory = SurfaceInputInventory(
      sourcePackageID: "P", sourcePackageClosureSHA256: "aa",
      phase4COutputID: "R", phase4COutputClosureSHA256: "bb",
      fusedPointCloudID: "F", fusedPointCount: 0, validNormalCount: 0,
      quarantinedRegionCount: 0, gapCount: 0, conflictCount: 0,
      phase4DReadiness: Phase4DReadinessOutcome.readyForSyntheticSurfaceCandidate.rawValue,
      units: "meters", handedness: "right"
    )
    let empty = FusedPointCloud(
      cloudID: "F", reconstructionOutputID: "R", authority: "RECONSTRUCTION_ESTIMATE",
      points: [], coordinate: .fixture
    )
    let bundle = Phase4CSurfaceHandoffBundle(
      fusedCloud: empty, normals: [], gaps: [], conflictIDs: [],
      quarantinedRegions: [], lineageManifestID: "L",
      phase4COutputClosureSHA256: "bb",
      phase4DReadiness: Phase4DReadinessOutcome.readyForSyntheticSurfaceCandidate.rawValue,
      phase4CReconstructionOutputID: "R", coordinate: .fixture
    )
    let result = SurfaceInputValidator().validate(inventory: inventory, bundle: bundle, expectedPhase4CClosure: "bb")
    XCTAssertEqual(result.outcome, .ineligibleMissingFusedCloud)
    _ = inventory
  }

  func testInvalidNormalsIneligible() throws {
    let points = (0..<10).map {
      ConsolidatedPoint(
        fusedPointID: "FP-\($0)", x: Double($0) * 0.01, y: 0, z: 2,
        contributionCount: 1, sourcePointIDs: ["a"], sourceObservationIDs: ["o"],
        confidenceMean: 1, confidenceMin: 1, confidenceMax: 1,
        voxelID: "VX:\($0)", derivationID: "d", classification: .nearbyDistinctPoint,
        authority: "RECONSTRUCTION_ESTIMATE"
      )
    }
    let cloud = FusedPointCloud(
      cloudID: "F", reconstructionOutputID: "R", authority: "RECONSTRUCTION_ESTIMATE",
      points: points, coordinate: .fixture
    )
    let normals = points.map {
      PointNormal(
        fusedPointID: $0.fusedPointID, nx: 0, ny: 0, nz: -1, neighborIDs: [],
        algorithmID: "a", algorithmVersion: "1", neighborhoodPolicy: "p",
        orientationConvention: "o", validity: .insufficientNeighborhood,
        confidence: 0, derivationID: "d"
      )
    }
    let inventory = SurfaceInputInventory(
      sourcePackageID: "P", sourcePackageClosureSHA256: "aa",
      phase4COutputID: "R", phase4COutputClosureSHA256: "bb",
      fusedPointCloudID: "F", fusedPointCount: points.count, validNormalCount: 0,
      quarantinedRegionCount: 0, gapCount: 0, conflictCount: 0,
      phase4DReadiness: Phase4DReadinessOutcome.readyForSyntheticSurfaceCandidate.rawValue,
      units: "meters", handedness: "right"
    )
    let bundle = Phase4CSurfaceHandoffBundle(
      fusedCloud: cloud, normals: normals, gaps: [], conflictIDs: [],
      quarantinedRegions: [], lineageManifestID: "L",
      phase4COutputClosureSHA256: "bb",
      phase4DReadiness: Phase4DReadinessOutcome.readyForSyntheticSurfaceCandidate.rawValue,
      phase4CReconstructionOutputID: "R", coordinate: .fixture
    )
    let result = SurfaceInputValidator().validate(inventory: inventory, bundle: bundle, expectedPhase4CClosure: "bb")
    XCTAssertEqual(result.outcome, .ineligibleInvalidNormals)
  }

  func testPhase4CNotReadyIneligible() throws {
    let points = (0..<10).map {
      ConsolidatedPoint(
        fusedPointID: "FP-\($0)", x: Double($0) * 0.01, y: 0, z: 2,
        contributionCount: 1, sourcePointIDs: ["a"], sourceObservationIDs: ["o"],
        confidenceMean: 1, confidenceMin: 1, confidenceMax: 1,
        voxelID: "VX:\($0)", derivationID: "d", classification: .nearbyDistinctPoint,
        authority: "RECONSTRUCTION_ESTIMATE"
      )
    }
    let normals = points.map {
      PointNormal(
        fusedPointID: $0.fusedPointID, nx: 0, ny: 0, nz: -1, neighborIDs: [],
        algorithmID: "a", algorithmVersion: "1", neighborhoodPolicy: "p",
        orientationConvention: "o", validity: .valid, confidence: 1, derivationID: "d"
      )
    }
    let inventory = SurfaceInputInventory(
      sourcePackageID: "P", sourcePackageClosureSHA256: "aa",
      phase4COutputID: "R", phase4COutputClosureSHA256: "bb",
      fusedPointCloudID: "F", fusedPointCount: 10, validNormalCount: 10,
      quarantinedRegionCount: 0, gapCount: 0, conflictCount: 0,
      phase4DReadiness: Phase4DReadinessOutcome.notReadyInvalidNormals.rawValue,
      units: "meters", handedness: "right"
    )
    let bundle = Phase4CSurfaceHandoffBundle(
      fusedCloud: FusedPointCloud(cloudID: "F", reconstructionOutputID: "R", authority: "RECONSTRUCTION_ESTIMATE", points: points, coordinate: .fixture),
      normals: normals, gaps: [], conflictIDs: [], quarantinedRegions: [],
      lineageManifestID: "L", phase4COutputClosureSHA256: "bb",
      phase4DReadiness: Phase4DReadinessOutcome.notReadyInvalidNormals.rawValue,
      phase4CReconstructionOutputID: "R", coordinate: .fixture
    )
    let result = SurfaceInputValidator().validate(inventory: inventory, bundle: bundle, expectedPhase4CClosure: "bb")
    XCTAssertEqual(result.outcome, .ineligiblePhase4CNotReady)
  }

  // MARK: - Meshing

  func testDeterministicReplay() throws {
    let a = try sealAndRun4C4D()
    let b = try sealAndRun4C4D()
    XCTAssertEqual(a.phase4d.surfaceMeshCandidateSHA256, b.phase4d.surfaceMeshCandidateSHA256)
    XCTAssertEqual(a.phase4d.lod0PLYSHA256, b.phase4d.lod0PLYSHA256)
    XCTAssertEqual(a.phase4d.outputClosureSHA256, b.phase4d.outputClosureSHA256)
    XCTAssertEqual(a.phase4d.glbSHA256, b.phase4d.glbSHA256)
  }

  func testVerticesFromTrustedFusedPointsOnly() throws {
    let r = try sealAndRun4C4D()
    let quarantine = Set(r.phase4c.handoff.quarantinedRegions)
    for v in r.phase4d.reconstruction.vertices {
      XCTAssertFalse(quarantine.contains(v.fusedPointID))
      XCTAssertTrue(v.vertexID.hasPrefix("SV-"))
      XCTAssertEqual(v.authority, "RECONSTRUCTION_ESTIMATE")
    }
  }

  func testValidTrianglesAndInjectedRejects() throws {
    let r = try sealAndRun4C4D()
    XCTAssertGreaterThanOrEqual(r.phase4d.reconstruction.vertices.count, 8)
    XCTAssertGreaterThanOrEqual(r.phase4d.reconstruction.triangles.count, 1)
    XCTAssertGreaterThanOrEqual(r.phase4d.reconstruction.rejected.count, 2)
    XCTAssertTrue(r.phase4d.reconstruction.rejected.contains { $0.reason == .duplicateVertices })
    XCTAssertTrue(
      r.phase4d.reconstruction.rejected.contains {
        $0.reason == .degenerateCollinear || $0.detail.contains("injected")
      }
    )
  }

  func testQuarantinedPointsExcludedFromMesh() throws {
    let r = try sealAndRun4C4D()
    let q = Set(r.phase4c.filtering.quarantinedPointIDs + r.phase4c.handoff.quarantinedRegions)
    let fusedIDs = Set(r.phase4d.reconstruction.vertices.map(\.fusedPointID))
    for id in q {
      XCTAssertFalse(fusedIDs.contains(id), "quarantined \(id) should not be a surface vertex")
    }
  }

  func testIntentionalHoleAndOpenBoundary() throws {
    let r = try sealAndRun4C4D()
    XCTAssertGreaterThanOrEqual(r.phase4d.boundaries.count, 1)
    XCTAssertGreaterThanOrEqual(r.phase4d.holes.count, 1)
    XCTAssertTrue(
      r.phase4d.holes.contains {
        $0.classification == .intentionalOpenBoundary || $0.classification == .unobservedRegion
      }
    )
    XCTAssertFalse(r.phase4d.holes.contains(where: \.automaticFillApplied))
  }

  func testNoAutomaticHoleFill() throws {
    let r = try sealAndRun4C4D()
    XCTAssertFalse(r.phase4d.quality.automaticHoleFillApplied)
    XCTAssertEqual(SurfaceMeshingPolicy.fixture.allowAutomaticHoleFill, false)
  }

  func testTopologyValidationRecorded() throws {
    let r = try sealAndRun4C4D()
    switch r.phase4d.topology.outcome {
    case .validManifoldOpen, .validWithHoles, .invalidNonManifold,
         .invalidDuplicateFaces, .invalidDegenerate, .manualReviewRequired:
      XCTAssertTrue(true)
    }
    XCTAssertGreaterThanOrEqual(r.phase4d.topology.componentCount, 1)
  }

  func testConfidenceRecordsPresent() throws {
    let r = try sealAndRun4C4D()
    XCTAssertFalse(r.phase4d.confidence.isEmpty)
    XCTAssertTrue(r.phase4d.confidence.contains { $0.kind == "VERTEX" })
    XCTAssertTrue(r.phase4d.confidence.contains { $0.kind == "TRIANGLE" })
  }

  // MARK: - LOD / exports

  func testThreeLODsWithBoundaryPreservation() throws {
    let r = try sealAndRun4C4D()
    XCTAssertEqual(r.phase4d.lods.count, 3)
    let lod0 = r.phase4d.lods.first { $0.lodLevel == 0 }!
    let lod1 = r.phase4d.lods.first { $0.lodLevel == 1 }!
    let lod2 = r.phase4d.lods.first { $0.lodLevel == 2 }!
    XCTAssertEqual(lod0.vertices.count, r.phase4d.reconstruction.vertices.count)
    XCTAssertEqual(lod0.simplificationMethod, "NONE")
    XCTAssertEqual(lod1.simplificationMethod, "SPATIAL_VOXEL_CENTROID_CLUSTER_COLLAPSE")
    XCTAssertEqual(lod1.requestedTargetTriangleFraction, 0.50, accuracy: 1e-9)
    XCTAssertEqual(lod2.requestedTargetTriangleFraction, 0.25, accuracy: 1e-9)
    XCTAssertLessThanOrEqual(lod1.achievedTriangleCount, lod0.achievedTriangleCount)
    XCTAssertLessThanOrEqual(lod2.achievedTriangleCount, lod1.achievedTriangleCount)
    XCTAssertFalse(lod1.preservationConstraints.isEmpty)
    XCTAssertNotEqual(r.phase4d.lod0PLYSHA256, r.phase4d.lod1PLYSHA256)
  }

  func testPLYOBJGLBArtifactsWritten() throws {
    let r = try sealAndRun4C4D()
    let root = r.phase4d.outputRoot
    for name in [
      "surface_mesh_lod0.ply", "surface_mesh_lod1.ply", "surface_mesh_lod2.ply",
      "surface_mesh.obj", "surface_mesh.mtl",
      "visual_derivation_manifest.json",
    ] {
      XCTAssertTrue(FileManager.default.fileExists(atPath: root.appendingPathComponent(name).path), name)
    }
    let ply = try String(contentsOf: root.appendingPathComponent("surface_mesh_lod0.ply"), encoding: .utf8)
    XCTAssertTrue(ply.contains("format ascii 1.0"))
    let obj = try String(contentsOf: root.appendingPathComponent("surface_mesh.obj"), encoding: .utf8)
    XCTAssertTrue(obj.contains("v "))
    let glbURL = root.appendingPathComponent("surface_mesh.glb")
    let statusURL = root.appendingPathComponent("glb_export_status.json")
    if FileManager.default.fileExists(atPath: glbURL.path) {
      let glb = try Data(contentsOf: glbURL)
      XCTAssertEqual(String(data: glb.prefix(4), encoding: .ascii), "glTF")
      XCTAssertEqual(glb.count % 4, 0)
      XCTAssertFalse(r.phase4d.glbSHA256?.isEmpty ?? true)
    } else {
      XCTAssertTrue(FileManager.default.fileExists(atPath: statusURL.path))
      let status = try JSONSerialization.jsonObject(with: Data(contentsOf: statusURL)) as! [String: Any]
      XCTAssertEqual(status["status"] as? String, "GLB_EXPORT_SKIPPED")
    }
  }

  func testGLBSoftFailOnEmptyMeshDoesNotThrowPipelineWriter() throws {
    let empty = SurfaceLODMesh(
      lodLevel: 0,
      meshID: "EMPTY",
      vertices: [],
      triangles: [],
      collapseRecords: [],
      requestedTargetTriangleFraction: 1,
      requestedTargetTriangleCount: 0,
      achievedTriangleCount: 0,
      reductionRatio: 1,
      preservationConstraints: [],
      simplificationMethod: "NONE"
    )
    XCTAssertThrowsError(try DeterministicGLBWriter.write(mesh: empty)) { err in
      XCTAssertEqual(err as? GLBExportFailure, .emptyMesh)
    }
  }

  func testAmbiguousWindingClassificationsExist() throws {
    XCTAssertEqual(TriangleRejectionReason.quarantinedAmbiguousTopology.rawValue, "QUARANTINED_AMBIGUOUS_TOPOLOGY")
    XCTAssertEqual(TriangleRejectionReason.normalConflict.rawValue, "REJECTED_NORMAL_CONFLICT")
  }

  func testCanonicalMeshJSONArtifacts() throws {
    let r = try sealAndRun4C4D()
    let root = r.phase4d.outputRoot
    for name in [
      "surface_mesh_candidate.json", "canonical_vertices.json", "canonical_triangles.json",
      "rejected_triangles.json", "topology.json", "adjacency.json", "connected_components.json",
      "boundaries.json", "holes.json", "interpolated_regions.json", "surface_confidence.json",
      "surface_policy.json", "surface_lineage_manifest.json",
      "fixture_truth.json", "phase4e_handoff.json",
    ] {
      XCTAssertTrue(FileManager.default.fileExists(atPath: root.appendingPathComponent(name).path), name)
    }
  }

  // MARK: - Lineage / immutability / claims

  func testPhase4COutputsRemainByteIdentical() throws {
    let r = try sealAndRun4C4D()
    XCTAssertTrue(r.phase4d.phase4COutputsUnchanged)
  }

  func testLineageMapsVerticesToFusedPoints() throws {
    let r = try sealAndRun4C4D()
    let fused = Set(r.phase4c.fusedCloud.points.map(\.fusedPointID))
    for v in r.phase4d.reconstruction.vertices {
      XCTAssertTrue(fused.contains(v.fusedPointID), v.fusedPointID)
    }
  }

  func testForbiddenClaimsInQualityAndHandoff() throws {
    let r = try sealAndRun4C4D()
    let q = r.phase4d.quality.dictionary()
    XCTAssertEqual(q["engineering_metrology_claim"] as? String, "FORBIDDEN")
    XCTAssertEqual(q["production_mesh_claim"] as? String, "FORBIDDEN")
    XCTAssertEqual(q["complete_digital_twin_claim"] as? String, "FORBIDDEN")
    let h = r.phase4d.handoff.dictionary()
    XCTAssertEqual(h["engineering_metrology_claim"] as? String, "FORBIDDEN")
  }

  func testFixtureTruthMinsSatisfied() throws {
    let r = try sealAndRun4C4D()
    let data = try Data(contentsOf: r.phase4d.outputRoot.appendingPathComponent("fixture_truth.json"))
    let obj = try JSONSerialization.jsonObject(with: data) as! [String: Any]
    XCTAssertEqual(obj["schema_id"] as? String, "Phase4DFixtureTruth")
    XCTAssertEqual(obj["characterization_status"] as? String, "DETERMINISTIC_TEST_FIXTURE")
    let observed = obj["observed"] as! [String: Any]
    XCTAssertGreaterThanOrEqual(
      observed["vertex_count"] as! Int, obj["expected_vertex_count_min"] as! Int
    )
    XCTAssertGreaterThanOrEqual(
      observed["valid_triangle_count"] as! Int, obj["expected_valid_triangle_count_min"] as! Int
    )
    XCTAssertGreaterThanOrEqual(
      observed["rejected_triangle_count"] as! Int, obj["expected_rejected_triangle_count_min"] as! Int
    )
    XCTAssertGreaterThanOrEqual(
      observed["boundary_count"] as! Int, obj["expected_boundary_count_min"] as! Int
    )
    XCTAssertGreaterThanOrEqual(
      observed["hole_count"] as! Int, obj["expected_hole_count_min"] as! Int
    )
    XCTAssertEqual(observed["lod_count"] as? Int, 3)
  }

  func testPhase4EHandoffReadiness() throws {
    let r = try sealAndRun4C4D()
    switch r.phase4d.phase4EReadiness {
    case .readyForFixtureScaleAndDatum, .readyWithUnresolvedBoundaries:
      XCTAssertTrue(true)
    default:
      XCTFail("unexpected readiness \(r.phase4d.phase4EReadiness)")
    }
  }

  func testCancellationCreatesNoSealedOutput() throws {
    let pkgRoot = try tempDir("cancel-pkg")
    let sealed = try FixtureSurfaceReconstructionPackageBuilder().sealPrimary(outputDirectory: pkgRoot)
    let reconOut = try tempDir("cancel-4c")
    let phase4c = try Phase4CPipeline().run(
      packageRoot: pkgRoot, outputRoot: reconOut, sealedGeometry: sealed.multiviewGeometry
    )
    let surfaceOut = try tempDir("cancel-4d")
    do {
      _ = try Phase4DPipeline(cancelDuring: .generatingTriangles).run(
        phase4COutputRoot: reconOut,
        outputRoot: surfaceOut,
        sourcePackageRoot: pkgRoot,
        sourcePackageClosureSHA256: sealed.package.packageClosureSHA256 ?? "",
        phase4COutputClosureSHA256: phase4c.outputClosureSHA256
      )
      XCTFail("expected cancel")
    } catch SurfaceFailure.cancelled {
      XCTAssertFalse(
        FileManager.default.fileExists(atPath: surfaceOut.appendingPathComponent("output_closure.json").path)
      )
    }
  }

  func testInventoryCoversRequiredArtifacts() throws {
    let r = try sealAndRun4C4D()
    let invData = try Data(contentsOf: r.phase4d.outputRoot.appendingPathComponent("output_inventory.json"))
    let inv = try JSONSerialization.jsonObject(with: invData) as! [String: Any]
    let items = inv["items"] as! [[String: Any]]
    let paths = Set(items.compactMap { $0["relative_path"] as? String })
    let required = [
      "surface_mesh_candidate.json", "canonical_vertices.json", "canonical_triangles.json",
      "rejected_triangles.json", "surface_mesh_lod0.ply", "surface_mesh.glb",
      "phase4e_handoff.json", "surface_lineage_manifest.json", "fixture_truth.json",
      "surface_policy.json", "topology.json", "boundaries.json", "holes.json",
    ]
    for name in required {
      XCTAssertTrue(paths.contains(name), "missing inventory \(name)")
    }
  }

  func testOutputOrderDeterministic() throws {
    let r = try sealAndRun4C4D()
    let vids = r.phase4d.reconstruction.vertices.map(\.vertexID)
    XCTAssertEqual(vids, vids.sorted())
    let tids = r.phase4d.reconstruction.triangles.map(\.triangleID)
    XCTAssertEqual(tids, tids.sorted())
  }

  func testDegenerateTriangleRejectUnit() throws {
    let pts = [
      ConsolidatedPoint(fusedPointID: "A", x: 0, y: 0, z: 2, contributionCount: 1, sourcePointIDs: ["a"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v0", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
      ConsolidatedPoint(fusedPointID: "B", x: 0.02, y: 0, z: 2, contributionCount: 1, sourcePointIDs: ["b"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v1", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
      ConsolidatedPoint(fusedPointID: "C", x: 0.01, y: 0.02, z: 2, contributionCount: 1, sourcePointIDs: ["c"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v2", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
    ]
    let normals = pts.map {
      PointNormal(fusedPointID: $0.fusedPointID, nx: 0, ny: 0, nz: -1, neighborIDs: [], algorithmID: "a", algorithmVersion: "1", neighborhoodPolicy: "p", orientationConvention: "o", validity: .valid, confidence: 1, derivationID: "d")
    }
    let cloud = FusedPointCloud(cloudID: "F", reconstructionOutputID: "R", authority: "RECONSTRUCTION_ESTIMATE", points: pts, coordinate: .fixture)
    let result = try DeterministicFixtureSurfaceBackend().reconstruct(
      fusedCloud: cloud, normals: normals, gaps: [], quarantinedRegions: [], configurationDigest: "cfg"
    )
    XCTAssertTrue(result.rejected.contains { $0.reason == .duplicateVertices })
  }

  func testExcessiveEdgeLengthRejected() throws {
    let pts = [
      ConsolidatedPoint(fusedPointID: "A", x: 0, y: 0, z: 2, contributionCount: 1, sourcePointIDs: ["a"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v0", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
      ConsolidatedPoint(fusedPointID: "B", x: 0.5, y: 0, z: 2, contributionCount: 1, sourcePointIDs: ["b"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v1", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
      ConsolidatedPoint(fusedPointID: "C", x: 0.25, y: 0.4, z: 2, contributionCount: 1, sourcePointIDs: ["c"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v2", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
    ]
    let normals = pts.map {
      PointNormal(fusedPointID: $0.fusedPointID, nx: 0, ny: 0, nz: -1, neighborIDs: [], algorithmID: "a", algorithmVersion: "1", neighborhoodPolicy: "p", orientationConvention: "o", validity: .valid, confidence: 1, derivationID: "d")
    }
    let cloud = FusedPointCloud(cloudID: "F", reconstructionOutputID: "R", authority: "RECONSTRUCTION_ESTIMATE", points: pts, coordinate: .fixture)
    let result = try DeterministicFixtureSurfaceBackend().reconstruct(
      fusedCloud: cloud, normals: normals, gaps: [], quarantinedRegions: [], configurationDigest: "cfg"
    )
    XCTAssertTrue(result.rejected.contains { $0.reason == .excessiveEdgeLength })
    XCTAssertTrue(result.triangles.isEmpty)
  }

  func testGapBridgingRejected() throws {
    let pts = [
      ConsolidatedPoint(fusedPointID: "A", x: 0.07, y: -0.005, z: 2, contributionCount: 1, sourcePointIDs: ["a"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v0", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
      ConsolidatedPoint(fusedPointID: "B", x: 0.13, y: -0.005, z: 2, contributionCount: 1, sourcePointIDs: ["b"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v1", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
      ConsolidatedPoint(fusedPointID: "C", x: 0.10, y: 0.005, z: 2, contributionCount: 1, sourcePointIDs: ["c"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v2", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
    ]
    // Keep edges under max by using closer points but centroid in intentional hole
    let close = [
      ConsolidatedPoint(fusedPointID: "A", x: 0.085, y: -0.005, z: 2, contributionCount: 1, sourcePointIDs: ["a"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v0", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
      ConsolidatedPoint(fusedPointID: "B", x: 0.115, y: -0.005, z: 2, contributionCount: 1, sourcePointIDs: ["b"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v1", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
      ConsolidatedPoint(fusedPointID: "C", x: 0.100, y: 0.005, z: 2, contributionCount: 1, sourcePointIDs: ["c"], sourceObservationIDs: ["o"], confidenceMean: 1, confidenceMin: 1, confidenceMax: 1, voxelID: "v2", derivationID: "d", classification: .nearbyDistinctPoint, authority: "RECONSTRUCTION_ESTIMATE"),
    ]
    _ = pts
    let normals = close.map {
      PointNormal(fusedPointID: $0.fusedPointID, nx: 0, ny: 0, nz: -1, neighborIDs: [], algorithmID: "a", algorithmVersion: "1", neighborhoodPolicy: "p", orientationConvention: "o", validity: .valid, confidence: 1, derivationID: "d")
    }
    let cloud = FusedPointCloud(cloudID: "F", reconstructionOutputID: "R", authority: "RECONSTRUCTION_ESTIMATE", points: close, coordinate: .fixture)
    let result = try DeterministicFixtureSurfaceBackend().reconstruct(
      fusedCloud: cloud, normals: normals, gaps: [], quarantinedRegions: [], configurationDigest: "cfg"
    )
    XCTAssertTrue(
      result.rejected.contains {
        $0.reason == .intentionalOpenBoundary || $0.reason == .gapBridging
      }
    )
  }

  func testSelfDigestBlankedBeforeHash() throws {
    var cfg = SurfaceConfigurationDigest.fixture()
    let d1 = cfg.digest
    cfg.digest = cfg.computeDigest()
    XCTAssertEqual(d1, cfg.digest)
    XCTAssertFalse(d1.isEmpty)
  }

  func testPhase4CFilterStillCompilesViaSmoke() throws {
    let root = try tempDir("4c-smoke")
    let sealed = try FixtureDenseFusionPackageBuilder().sealPrimary(outputDirectory: root)
    let r = try Phase4CPipeline().run(
      packageRoot: root, outputRoot: try tempDir("4c-smoke-out"), sealedGeometry: sealed.geometry
    )
    XCTAssertTrue(r.eligibility.isEligible)
    XCTAssertGreaterThan(r.fusedCloud.points.count, 0)
  }

  func testSurfaceAuthorityIsReconstructionEstimate() throws {
    let r = try sealAndRun4C4D()
    XCTAssertEqual(r.phase4d.reconstruction.vertices.first?.authority, "RECONSTRUCTION_ESTIMATE")
    let mesh = try Data(contentsOf: r.phase4d.outputRoot.appendingPathComponent("surface_mesh_candidate.json"))
    let obj = try JSONSerialization.jsonObject(with: mesh) as! [String: Any]
    XCTAssertEqual(obj["surface_authority"] as? String, "RECONSTRUCTION_ESTIMATE")
  }

  func testCoordinateMismatchIneligible() throws {
    let points = (0..<10).map {
      ConsolidatedPoint(
        fusedPointID: "FP-\($0)", x: Double($0) * 0.01, y: 0, z: 2,
        contributionCount: 1, sourcePointIDs: ["a"], sourceObservationIDs: ["o"],
        confidenceMean: 1, confidenceMin: 1, confidenceMax: 1,
        voxelID: "VX:\($0)", derivationID: "d", classification: .nearbyDistinctPoint,
        authority: "RECONSTRUCTION_ESTIMATE"
      )
    }
    let normals = points.map {
      PointNormal(
        fusedPointID: $0.fusedPointID, nx: 0, ny: 0, nz: -1, neighborIDs: [],
        algorithmID: "a", algorithmVersion: "1", neighborhoodPolicy: "p",
        orientationConvention: "o", validity: .valid, confidence: 1, derivationID: "d"
      )
    }
    let inventory = SurfaceInputInventory(
      sourcePackageID: "P", sourcePackageClosureSHA256: "aa",
      phase4COutputID: "R", phase4COutputClosureSHA256: "bb",
      fusedPointCloudID: "F", fusedPointCount: 10, validNormalCount: 10,
      quarantinedRegionCount: 0, gapCount: 0, conflictCount: 0,
      phase4DReadiness: Phase4DReadinessOutcome.readyForSyntheticSurfaceCandidate.rawValue,
      units: "millimeters", handedness: "left"
    )
    let bundle = Phase4CSurfaceHandoffBundle(
      fusedCloud: FusedPointCloud(cloudID: "F", reconstructionOutputID: "R", authority: "RECONSTRUCTION_ESTIMATE", points: points, coordinate: .fixture),
      normals: normals, gaps: [], conflictIDs: [], quarantinedRegions: [],
      lineageManifestID: "L", phase4COutputClosureSHA256: "bb",
      phase4DReadiness: Phase4DReadinessOutcome.readyForSyntheticSurfaceCandidate.rawValue,
      phase4CReconstructionOutputID: "R", coordinate: .fixture
    )
    let result = SurfaceInputValidator().validate(inventory: inventory, bundle: bundle, expectedPhase4CClosure: "bb")
    XCTAssertEqual(result.outcome, .ineligibleCoordinateMismatch)
  }
}
