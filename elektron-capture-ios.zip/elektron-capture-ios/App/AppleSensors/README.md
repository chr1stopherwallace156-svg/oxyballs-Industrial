# AppleSensors

Production sensor adapters for Sprint 3.1+ / pose candidate for Sprint 3.2.

| Adapter | Framework | Condition |
|---|---|---|
| `AppleProductionCameraSensorAdapter` | AVFoundation | `#if canImport(AVFoundation)` |
| `AppleProductionMotionSensorAdapter` | CoreMotion | `#if canImport(CoreMotion)` |
| `AppleARKitPoseSensorAdapter` | ARKit | `#if canImport(ARKit)` |

On Linux / hosts without these frameworks:

- Camera/motion stubs throw `ProductionSensorError.unavailable("*_BLOCKED_HOST_CAPABILITY")`.
- Pose stub throws `APPLE_POSE_SOURCE_CANDIDATE_UNCOMPILED` (or `*_BLOCKED_HOST_CAPABILITY` on capability-gated hosts) until **Sprint 3.6** physical-device validation.

**Clock law:** Do **not** claim shared camera / motion / pose clocks without an explicit `ClockCorrelation` record. Same wall-clock host time is not sufficient.

**Out of scope here:** LiDAR/depth, meshing, SfM, CAD, AI, Phase 4 reconstruction.
