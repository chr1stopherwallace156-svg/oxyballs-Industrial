import Foundation

#if canImport(CoreMotion)
import CoreMotion

/// Production CoreMotion adapter (Apple-only).
/// Does not share the camera clock unless an explicit ClockCorrelation is supplied by the coordinator.
public final class AppleProductionMotionSensorAdapter: MotionSensorAdapter, @unchecked Sendable {
  public let adapterID = "apple.coremotion.motion"
  public private(set) var capability: SpatialStreamCapability

  private let manager = CMMotionManager()
  private var started = false
  private var stopped = false
  private var continuation: AsyncThrowingStream<SpatialSampleEnvelope<MotionSample>, Error>.Continuation?
  private var sequence: UInt64 = 0
  private let interval: TimeInterval

  public init(sampleIntervalSeconds: TimeInterval = 0.01) {
    self.interval = sampleIntervalSeconds
    self.capability = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "apple.coremotion.motion",
      sensorKind: "motion"
    )
  }

  public func start() async throws {
    if started && !stopped { throw ProductionSensorError.alreadyStarted }
    guard manager.isDeviceMotionAvailable || manager.isAccelerometerAvailable else {
      throw ProductionSensorError.unavailable("motion")
    }
    manager.deviceMotionUpdateInterval = interval
    manager.accelerometerUpdateInterval = interval
    manager.gyroUpdateInterval = interval
    started = true
    stopped = false
    capability.activate()

    if manager.isDeviceMotionAvailable {
      manager.startDeviceMotionUpdates(to: .main) { [weak self] motion, error in
        guard let self else { return }
        if self.stopped {
          self.continuation?.finish(throwing: ProductionSensorError.postStopSample)
          return
        }
        if let error {
          self.continuation?.finish(throwing: ProductionSensorError.interrupted(error.localizedDescription))
          return
        }
        guard let motion else { return }
        self.emit(motion: motion)
      }
    } else {
      manager.startAccelerometerUpdates(to: .main) { [weak self] data, error in
        guard let self else { return }
        if let error {
          self.continuation?.finish(throwing: ProductionSensorError.interrupted(error.localizedDescription))
          return
        }
        guard let data else { return }
        self.emitAccelOnly(data)
      }
    }
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<MotionSample>, Error> {
    AsyncThrowingStream { continuation in
      self.continuation = continuation
    }
  }

  public func stop() async {
    if stopped { return }
    stopped = true
    started = false
    manager.stopDeviceMotionUpdates()
    manager.stopAccelerometerUpdates()
    manager.stopGyroUpdates()
    continuation?.finish()
    continuation = nil
  }

  private func emit(motion: CMDeviceMotion) {
    let accel = [motion.userAcceleration.x, motion.userAcceleration.y, motion.userAcceleration.z]
    let gyro = [motion.rotationRate.x, motion.rotationRate.y, motion.rotationRate.z]
    let grav = [motion.gravity.x, motion.gravity.y, motion.gravity.z]
    let user = accel
    let q = motion.attitude.quaternion
    let quat = [q.x, q.y, q.z, q.w]
    var bytes = Data()
    for v in accel + gyro + grav + user + quat {
      var le = v.bitPattern.littleEndian
      withUnsafeBytes(of: &le) { bytes.append(contentsOf: $0) }
    }
    let ts = UInt64(ProcessInfo.processInfo.systemUptime * 1_000_000_000)
    let payload = MotionSample(
      accelerationXYZ: accel,
      rotationRateXYZ: gyro,
      attitudeQuaternion: quat,
      bytes: bytes,
      gravityXYZ: grav,
      userAccelerationXYZ: user,
      samplingIntervalNs: UInt64(interval * 1_000_000_000)
    )
    let env = SpatialSampleEnvelope(
      sampleID: "motion-\(sequence)",
      sequenceIndex: sequence,
      acquisitionTimestampNs: ts,
      clockDomain: .coreMotion,
      coordinateFrameID: "FRAME_DEVICE_IMU",
      payload: payload,
      mediaType: "application/octet-stream",
      schemaID: "MotionSample",
      schemaVersion: "1.0.0-phase3-device"
    )
    sequence &+= 1
    capability.recordSample()
    continuation?.yield(env)
  }

  private func emitAccelOnly(_ data: CMAccelerometerData) {
    let accel = [data.acceleration.x, data.acceleration.y, data.acceleration.z]
    var bytes = Data()
    for v in accel {
      var le = v.bitPattern.littleEndian
      withUnsafeBytes(of: &le) { bytes.append(contentsOf: $0) }
    }
    let ts = UInt64(ProcessInfo.processInfo.systemUptime * 1_000_000_000)
    let payload = MotionSample(
      accelerationXYZ: accel,
      rotationRateXYZ: [0, 0, 0],
      attitudeQuaternion: [0, 0, 0, 1],
      bytes: bytes,
      gravityXYZ: [0, 0, 0],
      userAccelerationXYZ: accel,
      samplingIntervalNs: UInt64(interval * 1_000_000_000)
    )
    let env = SpatialSampleEnvelope(
      sampleID: "motion-\(sequence)",
      sequenceIndex: sequence,
      acquisitionTimestampNs: ts,
      clockDomain: .coreMotion,
      coordinateFrameID: "FRAME_DEVICE_IMU",
      payload: payload,
      mediaType: "application/octet-stream",
      schemaID: "MotionSample",
      schemaVersion: "1.0.0-phase3-device"
    )
    sequence &+= 1
    capability.recordSample()
    continuation?.yield(env)
  }
}

#else

/// Linux / non-Apple stub — production motion requires CoreMotion host.
public final class AppleProductionMotionSensorAdapter: MotionSensorAdapter, @unchecked Sendable {
  public let adapterID = "apple.coremotion.motion"
  public private(set) var capability: SpatialStreamCapability = SpatialStreamCapability(
    streamID: SpatialStreamID.motion,
    adapterID: "apple.coremotion.motion",
    sensorKind: "motion"
  )
  public init(sampleIntervalSeconds: TimeInterval = 0.01) {}
  public func start() async throws {
    throw ProductionSensorError.unavailable("CoreMotion_BLOCKED_HOST_CAPABILITY")
  }
  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<MotionSample>, Error> {
    AsyncThrowingStream { $0.finish(throwing: ProductionSensorError.unavailable("CoreMotion_BLOCKED_HOST_CAPABILITY")) }
  }
  public func stop() async {}
}

#endif
