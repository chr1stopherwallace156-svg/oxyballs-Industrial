import Foundation

#if canImport(ARKit)
import ARKit

/// Apple ARKit pose source **candidate** — structure only until Sprint 3.6 device validation.
/// Does NOT claim shared camera/motion/pose clocks without an explicit `ClockCorrelation`.
public final class AppleARKitPoseSensorAdapter: NSObject, PoseSensorAdapter, @unchecked Sendable {
  public let adapterID = "apple.arkit.pose"
  public private(set) var capability: SpatialStreamCapability

  private var session: ARSession?
  private var started = false
  private var stopped = false
  private var sequence: UInt64 = 0
  private var lastTs: UInt64 = 0
  private var continuation: AsyncThrowingStream<SpatialSampleEnvelope<PoseSample>, Error>.Continuation?

  /// Generated at `start()` — new UUID string per session run.
  private var sessionRunID: String = ""
  /// Starts at 1; increments on relocalization / tracking recovery.
  private var worldOriginRevision: UInt64 = 1
  /// `"\(sessionRunID)#\(worldOriginRevision)"` — stable per world-origin revision.
  private var frameEpochID: String = ""
  private var lastTrackingState: PoseTrackingState = .notAvailable

  public override init() {
    self.capability = SpatialStreamCapability(
      streamID: SpatialStreamID.pose,
      adapterID: "apple.arkit.pose",
      sensorKind: "pose"
    )
    super.init()
  }

  public func start() async throws {
    if started && !stopped { throw ProductionSensorError.alreadyStarted }
    let arSession = ARSession()
    let config = ARWorldTrackingConfiguration()
    guard ARWorldTrackingConfiguration.isSupported else {
      throw ProductionSensorError.unavailable("ARKit_world_tracking_unsupported")
    }
    sessionRunID = UUID().uuidString
    worldOriginRevision = 1
    frameEpochID = "\(sessionRunID)#\(worldOriginRevision)"
    lastTrackingState = .notAvailable
    arSession.delegate = self
    arSession.run(config)
    self.session = arSession
    started = true
    stopped = false
    capability.activate()
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<PoseSample>, Error> {
    AsyncThrowingStream { continuation in
      self.continuation = continuation
    }
  }

  public func stop() async {
    if stopped { return }
    stopped = true
    started = false
    session?.pause()
    session?.delegate = nil
    session = nil
    continuation?.finish()
    continuation = nil
  }

  private func bumpWorldOriginRevision() {
    worldOriginRevision &+= 1
    frameEpochID = "\(sessionRunID)#\(worldOriginRevision)"
  }

  private func mapTrackingState(_ state: ARCamera.TrackingState) -> (PoseTrackingState, PoseFailureReason?) {
    switch state {
    case .normal:
      return (.normal, nil)
    case .limited(let reason):
      switch reason {
      case .initializing, .relocalizing:
        return (.relocalizing, .relocalizationRequired)
      case .excessiveMotion:
        return (.limited, .excessiveMotion)
      case .insufficientFeatures:
        return (.limited, .insufficientFeatures)
      @unknown default:
        return (.limited, .unknown)
      }
    case .notAvailable:
      return (.notAvailable, .trackingLost)
    @unknown default:
      return (.notAvailable, .unknown)
    }
  }
}

extension AppleARKitPoseSensorAdapter: ARSessionDelegate {
  public func session(_ session: ARSession, didUpdate frame: ARFrame) {
    if stopped {
      continuation?.finish(throwing: ProductionSensorError.postStopSample)
      return
    }
    let ts = UInt64(max(0, frame.timestamp) * 1_000_000_000)
    if lastTs > 0 && ts < lastTs {
      continuation?.finish(
        throwing: ProductionSensorError.timestampRegression(previous: lastTs, next: ts)
      )
      return
    }
    lastTs = ts

    let (trackingState, reason) = mapTrackingState(frame.camera.trackingState)
    // Increment world origin revision when recovering from relocalization / lost tracking
    // after at least one sample was emitted (skip cold-start .notAvailable → .normal).
    if trackingState == .normal
      && (lastTrackingState == .relocalizing || lastTrackingState == .notAvailable)
      && sequence > 0
    {
      bumpWorldOriginRevision()
    }
    lastTrackingState = trackingState

    if trackingState == .notAvailable {
      continuation?.finish(throwing: ProductionSensorError.poseTrackingFailed(reason?.rawValue ?? "NOT_AVAILABLE"))
      return
    }

    let transform = frame.camera.transform
    // Column-major flatten of simd_float4x4
    var m = [Double](repeating: 0, count: 16)
    m[0] = Double(transform.columns.0.x); m[1] = Double(transform.columns.0.y)
    m[2] = Double(transform.columns.0.z); m[3] = Double(transform.columns.0.w)
    m[4] = Double(transform.columns.1.x); m[5] = Double(transform.columns.1.y)
    m[6] = Double(transform.columns.1.z); m[7] = Double(transform.columns.1.w)
    m[8] = Double(transform.columns.2.x); m[9] = Double(transform.columns.2.y)
    m[10] = Double(transform.columns.2.z); m[11] = Double(transform.columns.2.w)
    m[12] = Double(transform.columns.3.x); m[13] = Double(transform.columns.3.y)
    m[14] = Double(transform.columns.3.z); m[15] = Double(transform.columns.3.w)

    var bytes = Data()
    for v in m {
      var le = v.bitPattern.littleEndian
      withUnsafeBytes(of: &le) { bytes.append(contentsOf: $0) }
    }

    let payload = PoseSample(
      transform4x4: m,
      authority: "GUIDANCE_ESTIMATE",
      bytes: bytes,
      trackingState: trackingState,
      trackingReason: reason,
      timestampNanoseconds: ts,
      clockDomain: .arkitFrame,
      sourceFrameID: "FRAME_AR_SESSION_WORLD",
      destinationFrameID: "FRAME_CAPTURE_SESSION_ROOT",
      frameEpochID: frameEpochID,
      sessionRunID: sessionRunID,
      worldOriginRevision: worldOriginRevision
    )
    let env = SpatialSampleEnvelope(
      sampleID: "pose-\(sequence)",
      sequenceIndex: sequence,
      acquisitionTimestampNs: ts,
      clockDomain: .arkitFrame,
      coordinateFrameID: "FRAME_AR_SESSION_WORLD",
      payload: payload,
      mediaType: "application/octet-stream",
      schemaID: "PoseSample",
      schemaVersion: "1.0.0-phase3-device"
    )
    sequence &+= 1
    capability.recordSample()
    continuation?.yield(env)
  }

  public func sessionWasInterrupted(_ session: ARSession) {
    continuation?.finish(throwing: ProductionSensorError.interrupted("ARSessionWasInterrupted"))
  }

  public func sessionInterruptionEnded(_ session: ARSession) {
    // Relocalization may be required after interruption — bump epoch when tracking recovers.
  }

  public func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
    let (trackingState, _) = mapTrackingState(camera.trackingState)
    // World-origin revision bumps on recovery to .normal in didUpdate (after sequence > 0).
    if case .limited(.relocalizing) = camera.trackingState {
      // Surface relocalization without inventing a shared timebase with camera/motion.
      _ = trackingState
    }
  }
}

#else

/// Linux / non-ARKit host stub — Apple pose candidate remains uncompiled until Sprint 3.6.
public final class AppleARKitPoseSensorAdapter: PoseSensorAdapter, @unchecked Sendable {
  public let adapterID = "apple.arkit.pose"
  public private(set) var capability: SpatialStreamCapability = SpatialStreamCapability(
    streamID: SpatialStreamID.pose,
    adapterID: "apple.arkit.pose",
    sensorKind: "pose"
  )

  public init() {}

  public func start() async throws {
    throw ProductionSensorError.unavailable("APPLE_POSE_SOURCE_CANDIDATE_UNCOMPILED")
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<PoseSample>, Error> {
    AsyncThrowingStream {
      $0.finish(throwing: ProductionSensorError.unavailable("APPLE_POSE_SOURCE_CANDIDATE_UNCOMPILED"))
    }
  }

  public func stop() async {}
}

#endif
