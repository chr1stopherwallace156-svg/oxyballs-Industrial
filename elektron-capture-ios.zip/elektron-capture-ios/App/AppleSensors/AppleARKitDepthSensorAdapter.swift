import Foundation

#if canImport(ARKit)
import ARKit

/// Apple ARKit depth source **candidate** — structure only until Sprint 3.6 device validation.
/// Isolates Apple APIs from Foundation-portable depth contracts.
public final class AppleARKitDepthSensorAdapter: NSObject, DepthSensorAdapter, @unchecked Sendable {
  public let adapterID = "apple.arkit.depth"
  public private(set) var capability: SpatialStreamCapability

  private var session: ARSession?
  private var started = false
  private var stopped = false
  private var continuation: AsyncThrowingStream<SpatialSampleEnvelope<DepthSample>, Error>.Continuation?
  private var sessionRunID: String = ""
  private var worldOriginRevision: UInt64 = 1
  private var frameEpochID: String = ""

  public override init() {
    self.capability = SpatialStreamCapability(
      streamID: SpatialStreamID.depth,
      adapterID: "apple.arkit.depth",
      sensorKind: "depth"
    )
    super.init()
  }

  public func start() async throws {
    if started && !stopped { throw ProductionSensorError.alreadyStarted }
    guard ARWorldTrackingConfiguration.isSupported else {
      throw ProductionSensorError.depthUnavailableDevice("ARKit_world_tracking_unsupported")
    }
    let config = ARWorldTrackingConfiguration()
    // Prefer scene depth when the active SDK/configuration supports it.
    if ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) {
      config.frameSemantics.insert(.sceneDepth)
    } else if ARWorldTrackingConfiguration.supportsFrameSemantics(.smoothedSceneDepth) {
      config.frameSemantics.insert(.smoothedSceneDepth)
    } else {
      throw ProductionSensorError.depthUnavailableConfiguration("scene_depth_semantics_unsupported")
    }
    sessionRunID = UUID().uuidString
    worldOriginRevision = 1
    frameEpochID = "\(sessionRunID)#\(worldOriginRevision)"
    let arSession = ARSession()
    arSession.delegate = self
    arSession.run(config)
    self.session = arSession
    started = true
    stopped = false
    capability.activate()
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<DepthSample>, Error> {
    AsyncThrowingStream { continuation in
      self.continuation = continuation
    }
  }

  public func stop() async {
    if stopped { return }
    stopped = true
    started = false
    session?.pause()
    session?.delegate = nil
    session = nil
    continuation?.finish()
    continuation = nil
  }
}

extension AppleARKitDepthSensorAdapter: ARSessionDelegate {
  public func session(_ session: ARSession, didUpdate frame: ARFrame) {
    // Candidate path only — physical mapping/validation deferred to Sprint 3.6.
    _ = frame.camera.transform
    _ = frame.timestamp
    _ = frameEpochID
    _ = worldOriginRevision
  }

  public func sessionWasInterrupted(_ session: ARSession) {
    continuation?.finish(throwing: ProductionSensorError.interrupted("ARSessionWasInterrupted"))
  }

  public func sessionInterruptionEnded(_ session: ARSession) {}
}

#else

/// Linux / non-ARKit host stub — Apple depth candidate remains uncompiled until Sprint 3.6.
public final class AppleARKitDepthSensorAdapter: DepthSensorAdapter, @unchecked Sendable {
  public let adapterID = "apple.arkit.depth"
  public private(set) var capability: SpatialStreamCapability = SpatialStreamCapability(
    streamID: SpatialStreamID.depth,
    adapterID: "apple.arkit.depth",
    sensorKind: "depth"
  )

  public init() {}

  public func start() async throws {
    throw ProductionSensorError.unavailable("APPLE_DEPTH_SOURCE_CANDIDATE_UNCOMPILED")
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<DepthSample>, Error> {
    AsyncThrowingStream {
      $0.finish(throwing: ProductionSensorError.unavailable("APPLE_DEPTH_SOURCE_CANDIDATE_UNCOMPILED"))
    }
  }

  public func stop() async {}
}

#endif
