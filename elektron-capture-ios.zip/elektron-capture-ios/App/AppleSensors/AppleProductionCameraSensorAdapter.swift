import Foundation

#if canImport(AVFoundation)
import AVFoundation
#if canImport(UIKit)
import UIKit
#endif

/// Production AVFoundation RGB camera adapter (Apple-only).
/// Domain types remain Foundation-portable; this file is the sole AVFoundation boundary.
public final class AppleProductionCameraSensorAdapter: NSObject, CameraSensorAdapter, @unchecked Sendable {
  public let adapterID = "apple.avfoundation.camera"
  public private(set) var capability: SpatialStreamCapability

  private let session = AVCaptureSession()
  private let output = AVCaptureVideoDataOutput()
  private let queue = DispatchQueue(label: "elektron.camera.adapter")
  private var continuation: AsyncThrowingStream<SpatialSampleEnvelope<CameraSample>, Error>.Continuation?
  private var started = false
  private var stopped = false
  private var sequence: UInt64 = 0
  private var lastTs: UInt64 = 0
  private var deviceID: String = "unknown"
  private var formatDescription: String = "unknown"

  public override init() {
    self.capability = SpatialStreamCapability(
      streamID: SpatialStreamID.camera,
      adapterID: "apple.avfoundation.camera",
      sensorKind: "camera"
    )
    super.init()
  }

  public func start() async throws {
    if started && !stopped { throw ProductionSensorError.alreadyStarted }
#if canImport(UIKit)
    let status = AVCaptureDevice.authorizationStatus(for: .video)
    if status == .notDetermined {
      let granted = await AVCaptureDevice.requestAccess(for: .video)
      if !granted { throw ProductionSensorError.permissionDenied("camera") }
    } else if status != .authorized {
      throw ProductionSensorError.permissionDenied("camera")
    }
#endif
    guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
            ?? AVCaptureDevice.default(for: .video) else {
      throw ProductionSensorError.unavailable("camera_device")
    }
    deviceID = device.uniqueID
    formatDescription = String(describing: device.activeFormat.formatDescription)

    session.beginConfiguration()
    session.inputs.forEach { session.removeInput($0) }
    session.outputs.forEach { session.removeOutput($0) }
    let input = try AVCaptureDeviceInput(device: device)
    guard session.canAddInput(input) else {
      throw ProductionSensorError.unavailable("camera_input")
    }
    session.addInput(input)
    output.alwaysDiscardsLateVideoFrames = true
    output.videoSettings = [
      kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
    ]
    output.setSampleBufferDelegate(self, queue: queue)
    guard session.canAddOutput(output) else {
      throw ProductionSensorError.unavailable("camera_output")
    }
    session.addOutput(output)
    session.commitConfiguration()

    NotificationCenter.default.addObserver(
      self,
      selector: #selector(sessionInterrupted(_:)),
      name: .AVCaptureSessionWasInterrupted,
      object: session
    )

    started = true
    stopped = false
    capability.activate()
    session.startRunning()
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<CameraSample>, Error> {
    AsyncThrowingStream { continuation in
      self.continuation = continuation
    }
  }

  public func stop() async {
    if stopped { return }
    stopped = true
    started = false
    session.stopRunning()
    output.setSampleBufferDelegate(nil, queue: nil)
    NotificationCenter.default.removeObserver(self)
    continuation?.finish()
    continuation = nil
    // Release inputs/outputs
    session.beginConfiguration()
    session.inputs.forEach { session.removeInput($0) }
    session.outputs.forEach { session.removeOutput($0) }
    session.commitConfiguration()
  }

  @objc private func sessionInterrupted(_ note: Notification) {
    continuation?.finish(throwing: ProductionSensorError.interrupted("AVCaptureSessionWasInterrupted"))
  }
}

extension AppleProductionCameraSensorAdapter: AVCaptureVideoDataOutputSampleBufferDelegate {
  public func captureOutput(
    _ output: AVCaptureOutput,
    didOutput sampleBuffer: CMSampleBuffer,
    from connection: AVCaptureConnection
  ) {
    if stopped {
      continuation?.finish(throwing: ProductionSensorError.postStopSample)
      return
    }
    guard let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
    let w = CVPixelBufferGetWidth(pb)
    let h = CVPixelBufferGetHeight(pb)
    let tsHost = CMClockGetTime(CMClockGetHostTimeClock()).seconds
    let ts = UInt64(max(0, tsHost) * 1_000_000_000)
    if lastTs > 0 && ts < lastTs {
      continuation?.finish(
        throwing: ProductionSensorError.timestampRegression(previous: lastTs, next: ts)
      )
      return
    }
    lastTs = ts
    CVPixelBufferLockBaseAddress(pb, .readOnly)
    defer { CVPixelBufferUnlockBaseAddress(pb, .readOnly) }
    let src = CVPixelBufferGetBaseAddress(pb)
    let bytesPerRow = CVPixelBufferGetBytesPerRow(pb)
    var data = Data()
    if let src {
      // Bound evidence sample: first row only for package compactness in foundation sprint;
      // full-frame capture remains available via bytesPerRow * height when packaging policy expands.
      data = Data(bytes: src, count: min(bytesPerRow, w * 4))
    }
    let payload = CameraSample(
      width: w,
      height: h,
      pixelFormat: "BGRA8",
      bytes: data,
      orientation: "up",
      cameraIdentity: deviceID,
      intrinsicsAvailable: false
    )
    let env = SpatialSampleEnvelope(
      sampleID: "cam-\(sequence)",
      sequenceIndex: sequence,
      acquisitionTimestampNs: ts,
      clockDomain: .avfoundationCapture,
      coordinateFrameID: "FRAME_CAMERA_OPTICAL",
      payload: payload,
      mediaType: "application/octet-stream",
      schemaID: "CameraSample",
      schemaVersion: "1.0.0-phase3-device"
    )
    sequence &+= 1
    capability.recordSample()
    continuation?.yield(env)
  }
}

#else

/// Linux / non-Apple stub — production camera requires AVFoundation host.
public final class AppleProductionCameraSensorAdapter: CameraSensorAdapter, @unchecked Sendable {
  public let adapterID = "apple.avfoundation.camera"
  public private(set) var capability: SpatialStreamCapability = SpatialStreamCapability(
    streamID: SpatialStreamID.camera,
    adapterID: "apple.avfoundation.camera",
    sensorKind: "camera"
  )
  public init() {}
  public func start() async throws {
    throw ProductionSensorError.unavailable("AVFoundation_BLOCKED_HOST_CAPABILITY")
  }
  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<CameraSample>, Error> {
    AsyncThrowingStream { $0.finish(throwing: ProductionSensorError.unavailable("AVFoundation_BLOCKED_HOST_CAPABILITY")) }
  }
  public func stop() async {}
}

#endif
