import Foundation

/// Deterministic synthetic RGB camera adapter (Foundation-only).
public struct SyntheticCameraSensorAdapter: SpatialSensorAdapter {
  public let streamID: String
  public let adapterID: String
  public let sensorKind = "camera"
  public let requiredClockDomain: ClockDomain
  public let requiredCoordinateFrameID: String
  private let seed: UInt64
  private let frameCount: Int

  public init(
    streamID: String = SpatialStreamID.camera,
    adapterID: String = "synth.camera",
    frameCount: Int = 2,
    seed: UInt64 = 42,
    clockDomain: ClockDomain = .syntheticDeterministic,
    frameID: String = CoordinateFrameDescriptor.syntheticWorld.frameID
  ) {
    self.streamID = streamID
    self.adapterID = adapterID
    self.frameCount = frameCount
    self.seed = seed
    self.requiredClockDomain = clockDomain
    self.requiredCoordinateFrameID = frameID
  }

  public func activate() async throws {}

  public func nextSamples(count: Int) async throws -> [SpatialSampleEnvelope<CameraSample>] {
    let n = min(count, frameCount)
    var out: [SpatialSampleEnvelope<CameraSample>] = []
    out.reserveCapacity(n)
    for i in 0..<n {
      var bytes = Data(count: 16)
      for b in 0..<16 {
        bytes[b] = UInt8((seed &+ UInt64(i * 17) &+ UInt64(b)) & 0xff)
      }
      let payload = CameraSample(width: 4, height: 4, pixelFormat: "RGB8_SYNTH", bytes: bytes)
      let envelope = SpatialSampleEnvelope<CameraSample>(
        sampleID: "cam-\(i)",
        sequenceIndex: UInt64(i),
        acquisitionTimestampNs: UInt64(i) * 33_333_333,
        clockDomain: requiredClockDomain,
        coordinateFrameID: requiredCoordinateFrameID,
        payload: payload,
        mediaType: "application/octet-stream",
        schemaID: "CameraSample",
        schemaVersion: "1.0.0-phase3-synthetic"
      )
      out.append(envelope)
    }
    return out
  }

  public func deactivate() async {}
}

public struct SyntheticDepthSensorAdapter: SpatialSensorAdapter {
  public let streamID: String
  public let adapterID: String
  public let sensorKind = "depth"
  public let requiredClockDomain: ClockDomain
  public let requiredCoordinateFrameID: String
  public let emitSamples: Bool
  private let seed: UInt64

  public init(
    streamID: String = SpatialStreamID.depth,
    adapterID: String = "synth.depth",
    emitSamples: Bool = true,
    seed: UInt64 = 7,
    clockDomain: ClockDomain = .syntheticDeterministic,
    frameID: String = CoordinateFrameDescriptor.syntheticWorld.frameID
  ) {
    self.streamID = streamID
    self.adapterID = adapterID
    self.emitSamples = emitSamples
    self.seed = seed
    self.requiredClockDomain = clockDomain
    self.requiredCoordinateFrameID = frameID
  }

  public func activate() async throws {}

  public func nextSamples(count: Int) async throws -> [SpatialSampleEnvelope<DepthSample>] {
    guard emitSamples else { return [] }
    var out: [SpatialSampleEnvelope<DepthSample>] = []
    out.reserveCapacity(count)
    for i in 0..<count {
      var bytes = Data(count: 8)
      for b in 0..<8 {
        bytes[b] = UInt8((seed &+ UInt64(i * 3) &+ UInt64(b)) & 0xff)
      }
      let payload = DepthSample(
        width: 2,
        height: 2,
        depthUnit: "meters",
        bytes: bytes,
        confidencePresent: false
      )
      let envelope = SpatialSampleEnvelope<DepthSample>(
        sampleID: "depth-\(i)",
        sequenceIndex: UInt64(i),
        acquisitionTimestampNs: UInt64(i) * 33_333_333,
        clockDomain: requiredClockDomain,
        coordinateFrameID: requiredCoordinateFrameID,
        payload: payload,
        mediaType: "application/octet-stream",
        schemaID: "DepthSample",
        schemaVersion: "1.0.0-phase3-synthetic"
      )
      out.append(envelope)
    }
    return out
  }

  public func deactivate() async {}
}

public struct SyntheticMotionSensorAdapter: SpatialSensorAdapter {
  public let streamID: String
  public let adapterID: String
  public let sensorKind = "motion"
  public let requiredClockDomain: ClockDomain
  public let requiredCoordinateFrameID: String
  private let seed: UInt64

  public init(
    streamID: String = SpatialStreamID.motion,
    adapterID: String = "synth.motion",
    seed: UInt64 = 99,
    clockDomain: ClockDomain = .syntheticDeterministic,
    frameID: String = CoordinateFrameDescriptor.syntheticWorld.frameID
  ) {
    self.streamID = streamID
    self.adapterID = adapterID
    self.seed = seed
    self.requiredClockDomain = clockDomain
    self.requiredCoordinateFrameID = frameID
  }

  public func activate() async throws {}

  public func nextSamples(count: Int) async throws -> [SpatialSampleEnvelope<MotionSample>] {
    var out: [SpatialSampleEnvelope<MotionSample>] = []
    out.reserveCapacity(count)
    for i in 0..<count {
      let accel = [Double(i), 0.0, 9.81]
      let gyro = [0.01 * Double(i), 0.0, 0.0]
      let quat = [0.0, 0.0, 0.0, 1.0]
      var bytes = Data()
      for v in accel + gyro + quat {
        var le = v.bitPattern.littleEndian
        withUnsafeBytes(of: &le) { bytes.append(contentsOf: $0) }
      }
      let payload = MotionSample(
        accelerationXYZ: accel,
        rotationRateXYZ: gyro,
        attitudeQuaternion: quat,
        bytes: bytes
      )
      let envelope = SpatialSampleEnvelope<MotionSample>(
        sampleID: "motion-\(i)",
        sequenceIndex: UInt64(i),
        acquisitionTimestampNs: UInt64(i) * 10_000_000,
        clockDomain: requiredClockDomain,
        coordinateFrameID: requiredCoordinateFrameID,
        payload: payload,
        mediaType: "application/octet-stream",
        schemaID: "MotionSample",
        schemaVersion: "1.0.0-phase3-synthetic"
      )
      out.append(envelope)
    }
    return out
  }

  public func deactivate() async {}
}

public struct SyntheticPoseSensorAdapter: SpatialSensorAdapter {
  public let streamID: String
  public let adapterID: String
  public let sensorKind = "pose"
  public let requiredClockDomain: ClockDomain
  public let requiredCoordinateFrameID: String

  public init(
    streamID: String = SpatialStreamID.pose,
    adapterID: String = "synth.pose",
    clockDomain: ClockDomain = .syntheticDeterministic,
    frameID: String = CoordinateFrameDescriptor.syntheticWorld.frameID
  ) {
    self.streamID = streamID
    self.adapterID = adapterID
    self.requiredClockDomain = clockDomain
    self.requiredCoordinateFrameID = frameID
  }

  public func activate() async throws {}

  public func nextSamples(count: Int) async throws -> [SpatialSampleEnvelope<PoseSample>] {
    var out: [SpatialSampleEnvelope<PoseSample>] = []
    out.reserveCapacity(count)
    for i in 0..<count {
      var m = [Double](repeating: 0, count: 16)
      m[0] = 1; m[5] = 1; m[10] = 1; m[15] = 1
      m[12] = Double(i) * 0.1
      var bytes = Data()
      for v in m {
        var le = v.bitPattern.littleEndian
        withUnsafeBytes(of: &le) { bytes.append(contentsOf: $0) }
      }
      let ts = UInt64(i) * 33_333_333
      let payload = PoseSample(
        transform4x4: m,
        authority: "GUIDANCE_ESTIMATE",
        bytes: bytes,
        trackingState: .normal,
        trackingReason: nil,
        timestampNanoseconds: ts,
        clockDomain: requiredClockDomain,
        sourceFrameID: requiredCoordinateFrameID,
        destinationFrameID: requiredCoordinateFrameID,
        frameEpochID: "epoch-fixture-1",
        sessionRunID: "run-fixture-1",
        worldOriginRevision: 1
      )
      let envelope = SpatialSampleEnvelope<PoseSample>(
        sampleID: "pose-\(i)",
        sequenceIndex: UInt64(i),
        acquisitionTimestampNs: ts,
        clockDomain: requiredClockDomain,
        coordinateFrameID: requiredCoordinateFrameID,
        payload: payload,
        mediaType: "application/octet-stream",
        schemaID: "PoseSample",
        schemaVersion: "1.0.0-phase3-synthetic"
      )
      out.append(envelope)
    }
    return out
  }

  public func deactivate() async {}
}

/// Coordinates synthetic adapters and capability stage transitions.
public final class SyntheticSpatialSensorCoordinator: @unchecked Sendable, SpatialSensorCoordinator {
  public private(set) var capabilitySnapshot: SpatialCapabilitySnapshot
  private let camera: SyntheticCameraSensorAdapter
  private let depth: SyntheticDepthSensorAdapter
  private let motion: SyntheticMotionSensorAdapter
  private let pose: SyntheticPoseSensorAdapter
  private let samplesPerStream: Int
  private let correlations: [ClockCorrelation]
  private let frames: [CoordinateFrameDescriptor]

  public init(
    includeDepth: Bool = true,
    depthEmitsSamples: Bool = true,
    samplesPerStream: Int = 2,
    clockDomain: ClockDomain = .syntheticDeterministic,
    frame: CoordinateFrameDescriptor = .syntheticWorld
  ) {
    self.samplesPerStream = samplesPerStream
    self.camera = SyntheticCameraSensorAdapter(clockDomain: clockDomain, frameID: frame.frameID)
    self.depth = SyntheticDepthSensorAdapter(
      emitSamples: includeDepth && depthEmitsSamples,
      clockDomain: clockDomain,
      frameID: frame.frameID
    )
    self.motion = SyntheticMotionSensorAdapter(clockDomain: clockDomain, frameID: frame.frameID)
    self.pose = SyntheticPoseSensorAdapter(clockDomain: clockDomain, frameID: frame.frameID)
    self.frames = [frame]
    self.correlations = [
      ClockCorrelation(
        correlationID: "synth-identity-\(clockDomain.rawValue)",
        sourceDomain: clockDomain,
        destinationDomain: clockDomain,
        offsetNanoseconds: 0,
        authority: "SYNTHETIC_IDENTITY"
      )
    ]
    self.capabilitySnapshot = SpatialCapabilitySnapshot(
      snapshotID: "cap-synth-1",
      capturedAtUTC: "2026-08-03T00:00:00Z",
      streams: [
        SpatialStreamCapability(streamID: camera.streamID, adapterID: camera.adapterID, sensorKind: camera.sensorKind),
        SpatialStreamCapability(streamID: depth.streamID, adapterID: depth.adapterID, sensorKind: depth.sensorKind),
        SpatialStreamCapability(streamID: motion.streamID, adapterID: motion.adapterID, sensorKind: motion.sensorKind),
        SpatialStreamCapability(streamID: pose.streamID, adapterID: pose.adapterID, sensorKind: pose.sensorKind),
      ]
    )
  }

  public func activateAll() async throws {
    try await camera.activate()
    try await depth.activate()
    try await motion.activate()
    try await pose.activate()
    for i in capabilitySnapshot.streams.indices {
      capabilitySnapshot.streams[i].activate()
    }
  }

  public func collectDeterministicBundle() async throws -> SpatialSampleBundle {
    let cam = try await camera.nextSamples(count: samplesPerStream)
    let dep = try await depth.nextSamples(count: samplesPerStream)
    let mot = try await motion.nextSamples(count: samplesPerStream)
    let pos = try await pose.nextSamples(count: samplesPerStream)

    func bump(_ streamID: String, count: Int) {
      guard let idx = capabilitySnapshot.streams.firstIndex(where: { $0.streamID == streamID }) else { return }
      for _ in 0..<count {
        capabilitySnapshot.streams[idx].recordSample()
      }
    }
    bump(camera.streamID, count: cam.count)
    bump(depth.streamID, count: dep.count)
    bump(motion.streamID, count: mot.count)
    bump(pose.streamID, count: pos.count)

    return SpatialSampleBundle(
      camera: cam,
      depth: dep,
      motion: mot,
      pose: pos,
      capability: capabilitySnapshot,
      clockCorrelations: correlations,
      frames: frames
    )
  }
}
