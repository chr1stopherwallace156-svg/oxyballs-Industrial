import Foundation

/// Builds SPKG-FIXTURE-SURFACE-RECONSTRUCTION-000001 for Phase 4D surface reconstruction.
/// Layout remains Phase-4C-compatible so Phase4CPipeline can run as an intermediate step.
public struct FixtureSurfaceReconstructionPackageBuilder: Sendable {
  public static let primaryPackageID = Phase4DFixtureIDs.inputPackageID
  public static let primarySessionID = Phase4DFixtureIDs.sessionID
  public static let surfaceOutputID = Phase4DFixtureIDs.surfaceOutputID
  public static let fixtureGeometryID = Phase4DFixtureIDs.fixtureGeometryID

  public init() {}

  public struct SealResult: Sendable {
    public var package: SpatialEvidencePackage
    public var geometry: FixtureSurfaceTargetGeometry
    public var multiviewGeometry: FixtureMultiviewSurfaceGeometry
    public var sourcePackageBytesSHA256: String
    public var trueTranslations: [[Double]]
    public var sourceTranslations: [[Double]]
  }

  public func sealPrimary(outputDirectory: URL) throws -> SealResult {
    let surfaceGeometry = FixtureSurfaceTargetGeometry.surfaceTarget()
    let multiview = surfaceGeometry.asMultiviewSurfaceGeometry()
    let sealed = try FixtureDenseFusionPackageBuilder().seal(
      outputDirectory: outputDirectory,
      allowReconstruction: true,
      packageID: Self.primaryPackageID,
      sessionID: Self.primarySessionID,
      vehicleID: Phase4DFixtureIDs.vehicleID,
      geometryOverride: multiview,
      privacyPolicyID: Phase4DFixtureIDs.privacyPolicyID
    )
    // Rewrite fixture_geometry.json with surface-target schema (planar landmarks preserved).
    try CanonicalJSON.data(surfaceGeometry.dictionary())
      .write(to: outputDirectory.appendingPathComponent("fixture_geometry.json"), options: .atomic)

    // Recompute package inventory + closure after geometry rewrite.
    let inventoryEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputDirectory)
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(packageRoot: outputDirectory, entries: inventoryEntries)
    let packageClosureHash = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: inventoryEntries)
    try CanonicalJSON.data([
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": Self.primaryPackageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": packageClosureHash,
      "entries": inventoryEntries,
    ]).write(to: outputDirectory.appendingPathComponent("package_inventory.json"), options: .atomic)

    let packageHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outputDirectory)
    let pkg = SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: sealed.package.manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: sealed.package.manifestSHA256,
      packageClosureSHA256: packageClosureHash
    )
    return SealResult(
      package: pkg,
      geometry: surfaceGeometry,
      multiviewGeometry: multiview,
      sourcePackageBytesSHA256: packageHash,
      trueTranslations: sealed.trueTranslations,
      sourceTranslations: sealed.sourceTranslations
    )
  }
}
