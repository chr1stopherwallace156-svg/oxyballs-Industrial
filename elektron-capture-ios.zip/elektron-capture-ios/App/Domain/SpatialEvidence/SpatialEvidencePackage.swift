import Foundation

public struct SpatialArtifactDescriptor: Sendable, Equatable {
  public let relativePath: String
  public let byteLength: Int
  public let sha256: String
  public let mediaType: String
  public let schemaID: String
  public let schemaVersion: String
  public let sampleID: String
  public let streamID: String
  public let adapterID: String

  public init(
    relativePath: String,
    byteLength: Int,
    sha256: String,
    mediaType: String,
    schemaID: String,
    schemaVersion: String,
    sampleID: String,
    streamID: String,
    adapterID: String
  ) {
    self.relativePath = relativePath
    self.byteLength = byteLength
    self.sha256 = sha256
    self.mediaType = mediaType
    self.schemaID = schemaID
    self.schemaVersion = schemaVersion
    self.sampleID = sampleID
    self.streamID = streamID
    self.adapterID = adapterID
  }

  public func asDictionary() -> [String: Any] {
    [
      "relative_path": relativePath,
      "byte_length": byteLength,
      "sha256": sha256,
      "media_type": mediaType,
      "schema_id": schemaID,
      "schema_version": schemaVersion,
      "sample_id": sampleID,
      "stream_id": streamID,
      "adapter_id": adapterID,
    ]
  }
}

/// Canonical manifest — MUST NOT contain mutable custody status.
public struct SpatialEvidenceManifest: Sendable {
  public static let schemaID = "SpatialEvidenceManifest"
  public static let schemaVersion = "1.0.0-phase3-synthetic"
  public static let supportedSchemas: Set<String> = [
    "\(schemaID)@\(schemaVersion)",
    "SpatialEvidencePackage@1.0.0-phase3-synthetic",
    "SpatialCapabilitySnapshot@1.0.0-phase3-synthetic",
    "SpatialCapabilitySnapshot@1.0.0-phase3-device",
    "SpatialCapabilitySnapshot@1.0.0-phase3-fixture",
    "CameraSample@1.0.0-phase3-synthetic",
    "CameraSample@1.0.0-phase3-device",
    "CameraSample@1.0.0-phase3-fixture",
    "DepthSample@1.0.0-phase3-synthetic",
    "DepthSample@1.0.0-phase3-fixture",
    "DepthSample@1.0.0-phase3-device",
    "DepthCalibration@1.0.0-phase3-fixture",
    "MotionSample@1.0.0-phase3-synthetic",
    "MotionSample@1.0.0-phase3-device",
    "MotionSample@1.0.0-phase3-fixture",
    "PoseSample@1.0.0-phase3-synthetic",
    "PoseSample@1.0.0-phase3-fixture",
    "PoseSample@1.0.0-phase3-device",
    "SpatialEvidenceManifest@1.0.0-phase3-device",
    "SpatialEvidenceManifest@1.0.0-phase3-fixture",
    "SpatialEvidencePackage@1.0.0-phase3-device",
    "SpatialEvidencePackage@1.0.0-phase3-fixture",
  ]

  public let packageID: String
  public let vehicleID: String
  public let captureSessionID: String
  public let pilotID: String?
  public let createdAtUTC: String
  public let hashAlgorithmID: String
  public let capability: SpatialCapabilitySnapshot
  public let frames: [CoordinateFrameDescriptor]
  public let clockCorrelations: [ClockCorrelation]
  public let artifacts: [SpatialArtifactDescriptor]
  public let sampleIndex: [[String: Any]]

  public init(
    packageID: String,
    vehicleID: String,
    captureSessionID: String,
    pilotID: String?,
    createdAtUTC: String,
    hashAlgorithmID: String = "sha256-content-v1",
    capability: SpatialCapabilitySnapshot,
    frames: [CoordinateFrameDescriptor],
    clockCorrelations: [ClockCorrelation],
    artifacts: [SpatialArtifactDescriptor],
    sampleIndex: [[String: Any]]
  ) {
    self.packageID = packageID
    self.vehicleID = vehicleID
    self.captureSessionID = captureSessionID
    self.pilotID = pilotID
    self.createdAtUTC = createdAtUTC
    self.hashAlgorithmID = hashAlgorithmID
    self.capability = capability
    self.frames = frames
    self.clockCorrelations = clockCorrelations
    self.artifacts = artifacts
    self.sampleIndex = sampleIndex
  }

  public func asDictionary() -> [String: Any] {
    var d: [String: Any] = [
      "schema_id": Self.schemaID,
      "schema_version": Self.schemaVersion,
      "package_id": packageID,
      "vehicle_id": vehicleID,
      "capture_session_id": captureSessionID,
      "created_at_utc": createdAtUTC,
      "hash_algorithm_id": hashAlgorithmID,
      "capability": capability.asDictionary(),
      "frames": frames.sorted { $0.frameID < $1.frameID }.map { $0.asDictionary() },
      "clock_correlations": clockCorrelations
        .sorted { $0.sourceDomain.rawValue < $1.sourceDomain.rawValue }
        .map { $0.asDictionary() },
      "artifacts": artifacts.sorted { $0.relativePath < $1.relativePath }.map { $0.asDictionary() },
      "sample_index": sampleIndex,
    ]
    if let pilotID {
      d["pilot_id"] = pilotID
    }
    // Explicitly never include custody_* keys.
    return d
  }
}

public struct SpatialEvidencePackage: Sendable {
  public static let schemaID = "SpatialEvidencePackage"
  public static let schemaVersion = "1.0.0-phase3-synthetic"

  public let rootURL: URL
  public let manifest: SpatialEvidenceManifest
  /// Payload/artifact content digest from `rehashPackageBytes` / `packageContentHash`
  /// (manifest identity + artifact descriptors only — not sidecar metadata bytes).
  public let packageContentSHA256: String
  public let manifestSHA256: String
  /// Full package inventory closure digest (`sha256-canonical-inventory-v1`), when issued.
  public let packageClosureSHA256: String?

  public init(
    rootURL: URL,
    manifest: SpatialEvidenceManifest,
    packageContentSHA256: String,
    manifestSHA256: String,
    packageClosureSHA256: String? = nil
  ) {
    self.rootURL = rootURL
    self.manifest = manifest
    self.packageContentSHA256 = packageContentSHA256
    self.manifestSHA256 = manifestSHA256
    self.packageClosureSHA256 = packageClosureSHA256
  }
}

public struct SpatialEvidencePackageBuilder: Sendable {
  public init() {}

  public func seal(
    sessionID: String,
    vehicleID: String,
    pilotID: String?,
    bundle: inout SpatialSampleBundle,
    outputDirectory: URL,
    packageID: String = "SPKG-SYNTH-0001",
    createdAtUTC: String = "2026-08-03T00:00:00Z"
  ) throws -> SpatialEvidencePackage {
    try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
    let artifactsDir = outputDirectory.appendingPathComponent("artifacts", isDirectory: true)
    try FileManager.default.createDirectory(at: artifactsDir, withIntermediateDirectories: true)

    // Freeze capability outcomes honestly.
    for i in bundle.capability.streams.indices {
      let kind = bundle.capability.streams[i].sensorKind
      let acquired = bundle.capability.streams[i].samplesAcquired
      if kind == "depth" && acquired == 0 {
        try bundle.capability.streams[i].freeze(outcome: .unavailable)
      } else if acquired > 0 {
        try bundle.capability.streams[i].freeze(outcome: .acquired)
      } else if kind == "depth" {
        try bundle.capability.streams[i].freeze(outcome: .degradedOptionalDrop)
      } else {
        try bundle.capability.streams[i].freeze(outcome: .failed)
      }
    }

    var artifacts: [SpatialArtifactDescriptor] = []
    var sampleIndex: [[String: Any]] = []

    func adapter(for stream: String) -> String {
      bundle.capability.streams.first(where: { $0.streamID == stream })?.adapterID
        ?? "unknown.\(stream)"
    }
    try writeStream(
      name: SpatialStreamID.camera,
      adapterID: adapter(for: SpatialStreamID.camera),
      samples: bundle.camera,
      root: artifactsDir,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }
    try writeStream(
      name: SpatialStreamID.depth,
      adapterID: adapter(for: SpatialStreamID.depth),
      samples: bundle.depth,
      root: artifactsDir,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }
    try writeStream(
      name: SpatialStreamID.motion,
      adapterID: adapter(for: SpatialStreamID.motion),
      samples: bundle.motion,
      root: artifactsDir,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }
    try writeStream(
      name: SpatialStreamID.pose,
      adapterID: adapter(for: SpatialStreamID.pose),
      samples: bundle.pose,
      root: artifactsDir,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }

    sampleIndex.sort { lhs, rhs in
      let a = (lhs["relative_path"] as? String) ?? ""
      let b = (rhs["relative_path"] as? String) ?? ""
      return a < b
    }

    let manifest = SpatialEvidenceManifest(
      packageID: packageID,
      vehicleID: vehicleID,
      captureSessionID: sessionID,
      pilotID: pilotID,
      createdAtUTC: createdAtUTC,
      capability: bundle.capability,
      frames: bundle.frames,
      clockCorrelations: bundle.clockCorrelations,
      artifacts: artifacts,
      sampleIndex: sampleIndex
    )

    let schemaKey = "\(SpatialEvidenceManifest.schemaID)@\(SpatialEvidenceManifest.schemaVersion)"
    guard SpatialEvidenceManifest.supportedSchemas.contains(schemaKey) else {
      throw SpatialEvidenceError.unsupportedSchema(
        id: SpatialEvidenceManifest.schemaID,
        version: SpatialEvidenceManifest.schemaVersion
      )
    }

    let manifestData = try CanonicalJSON.data(manifest.asDictionary())
    let manifestURL = outputDirectory.appendingPathComponent("manifest.json")
    try manifestData.write(to: manifestURL, options: .atomic)
    let manifestSHA = ContentHasher.sha256Hex(manifestData)

    try SpatialPackageClosureVerifier.verify(packageRoot: outputDirectory, manifest: manifest)

    let packageHash = try SpatialPackageClosureVerifier.packageContentHash(
      packageRoot: outputDirectory,
      manifest: manifest
    )

    return SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: manifestSHA
    )
  }

  private func writeStream<Payload>(
    name: String,
    adapterID: String,
    samples: [SpatialSampleEnvelope<Payload>],
    root: URL,
    artifacts: inout [SpatialArtifactDescriptor],
    sampleIndex: inout [[String: Any]],
    bytesOf: (Payload) -> Data
  ) throws {
    try SpatialStreamID.validate(name)
    let dir = root.appendingPathComponent(name, isDirectory: true)
    if !samples.isEmpty {
      try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    }
    for (idx, sample) in samples.enumerated() {
      let schemaKey = "\(sample.schemaID)@\(sample.schemaVersion)"
      guard SpatialEvidenceManifest.supportedSchemas.contains(schemaKey) else {
        throw SpatialEvidenceError.unsupportedSchema(id: sample.schemaID, version: sample.schemaVersion)
      }
      let fileName = String(format: "%04d.bin", idx)
      let rel = "artifacts/\(name)/\(fileName)"
      if rel.contains(".tmp") || rel.contains("/tmp/") {
        throw SpatialEvidenceError.temporaryArtifactRejected(path: rel)
      }
      if artifacts.contains(where: { $0.relativePath == rel }) {
        throw SpatialEvidenceError.duplicateArtifact(path: rel)
      }
      let data = bytesOf(sample.payload)
      let url = dir.appendingPathComponent(fileName)
      try data.write(to: url, options: .atomic)
      let sha = ContentHasher.sha256Hex(data)
      let desc = SpatialArtifactDescriptor(
        relativePath: rel,
        byteLength: data.count,
        sha256: sha,
        mediaType: sample.mediaType,
        schemaID: sample.schemaID,
        schemaVersion: sample.schemaVersion,
        sampleID: sample.sampleID,
        streamID: name,
        adapterID: adapterID
      )
      artifacts.append(desc)
      sampleIndex.append([
        "sample_id": sample.sampleID,
        "sequence_index": sample.sequenceIndex,
        "acquisition_timestamp_ns": sample.acquisitionTimestampNs,
        "clock_domain": sample.clockDomain.rawValue,
        "coordinate_frame_id": sample.coordinateFrameID,
        "relative_path": rel,
        "stream_id": name,
        "adapter_id": adapterID,
      ])
    }
  }
}

public enum SpatialPackageClosureVerifier {
  public static func verify(packageRoot: URL, manifest: SpatialEvidenceManifest) throws {
    let fm = FileManager.default
    var seen = Set<String>()
    for art in manifest.artifacts {
      if art.relativePath.contains(".tmp") || art.relativePath.hasSuffix("~") {
        throw SpatialEvidenceError.temporaryArtifactRejected(path: art.relativePath)
      }
      if !seen.insert(art.relativePath).inserted {
        throw SpatialEvidenceError.duplicateArtifact(path: art.relativePath)
      }
      let url = packageRoot.appendingPathComponent(art.relativePath)
      guard fm.fileExists(atPath: url.path) else {
        throw SpatialEvidenceError.missingArtifact(path: art.relativePath)
      }
      let data = try Data(contentsOf: url)
      if data.count != art.byteLength {
        throw SpatialEvidenceError.byteLengthMismatch(
          path: art.relativePath,
          expected: art.byteLength,
          actual: data.count
        )
      }
      let sha = ContentHasher.sha256Hex(data)
      if sha != art.sha256 {
        throw SpatialEvidenceError.sha256Mismatch(
          path: art.relativePath,
          expected: art.sha256,
          actual: sha
        )
      }
    }

    // Orphan / unreferenced under artifacts/
    let artifactsRoot = packageRoot.appendingPathComponent("artifacts", isDirectory: true)
    if fm.fileExists(atPath: artifactsRoot.path) {
      let enumerator = fm.enumerator(at: artifactsRoot, includingPropertiesForKeys: [.isRegularFileKey])
      while let item = enumerator?.nextObject() as? URL {
        var isDir: ObjCBool = false
        if fm.fileExists(atPath: item.path, isDirectory: &isDir), isDir.boolValue { continue }
        let rel = "artifacts/" + item.path.replacingOccurrences(of: artifactsRoot.path + "/", with: "")
        if item.lastPathComponent.hasPrefix(".") { continue }
        if !seen.contains(rel) {
          throw SpatialEvidenceError.orphanArtifact(path: rel)
        }
      }
    }
  }

  /// Content hash over ordered artifact digests + manifest digest (custody-free).
  public static func packageContentHash(
    packageRoot: URL,
    manifest: SpatialEvidenceManifest
  ) throws -> String {
    _ = packageRoot
    var material = [[String: Any]]()
    material.append([
      "manifest_schema": "\(SpatialEvidenceManifest.schemaID)@\(SpatialEvidenceManifest.schemaVersion)",
      "package_id": manifest.packageID,
      "vehicle_id": manifest.vehicleID,
      "capture_session_id": manifest.captureSessionID,
    ])
    for art in manifest.artifacts.sorted(by: { $0.relativePath < $1.relativePath }) {
      material.append([
        "path": art.relativePath,
        "sha256": art.sha256,
        "byte_length": art.byteLength,
      ])
    }
    let data = try CanonicalJSON.data(["closure": material])
    return ContentHasher.sha256Hex(data)
  }

  public static func rehashPackageBytes(packageRoot: URL) throws -> String {
    let manifestURL = packageRoot.appendingPathComponent("manifest.json")
    let manifestData = try Data(contentsOf: manifestURL)
    // Parse minimal fields via JSONSerialization for re-verify after custody changes.
    guard let obj = try JSONSerialization.jsonObject(with: manifestData) as? [String: Any] else {
      throw SpatialEvidenceError.packageClosureFailed("manifest not object")
    }
    // Reconstruct artifact list for hash stability check of on-disk bytes.
    let arts = (obj["artifacts"] as? [[String: Any]]) ?? []
    var material = [[String: Any]]()
    material.append([
      "manifest_schema": "\(obj["schema_id"] as? String ?? "")@\(obj["schema_version"] as? String ?? "")",
      "package_id": obj["package_id"] as? String ?? "",
      "vehicle_id": obj["vehicle_id"] as? String ?? "",
      "capture_session_id": obj["capture_session_id"] as? String ?? "",
    ])
    let sorted = arts.sorted { ($0["relative_path"] as? String ?? "") < ($1["relative_path"] as? String ?? "") }
    for art in sorted {
      material.append([
        "path": art["relative_path"] as? String ?? "",
        "sha256": art["sha256"] as? String ?? "",
        "byte_length": art["byte_length"] as? Int ?? 0,
      ])
    }
    let data = try CanonicalJSON.data(["closure": material])
    return ContentHasher.sha256Hex(data)
  }

  /// Algorithm id for `fixture_package_closure_sha256` / inventory closure digests.
  public static let inventoryClosureDigestAlgorithm = "sha256-canonical-inventory-v1"

  /// Collect package inventory entries (relative_path, byte_length, sha256),
  /// excluding `package_inventory.json` itself. Paths are package-relative only.
  public static func collectPackageInventoryEntries(packageRoot: URL) throws -> [[String: Any]] {
    let fm = FileManager.default
    var entries: [[String: Any]] = []
    let enumerator = fm.enumerator(at: packageRoot, includingPropertiesForKeys: [.isRegularFileKey])
    while let url = enumerator?.nextObject() as? URL {
      var isDir: ObjCBool = false
      guard fm.fileExists(atPath: url.path, isDirectory: &isDir), !isDir.boolValue else { continue }
      if url.lastPathComponent == "package_inventory.json" { continue }
      if url.lastPathComponent.hasPrefix(".") { continue }
      let rel = url.path.replacingOccurrences(of: packageRoot.path + "/", with: "")
      if rel.hasPrefix("/") || rel.contains("://") {
        throw SpatialEvidenceError.packageClosureFailed(
          "absolute or host path entered inventory collection: \(rel)"
        )
      }
      let data = try Data(contentsOf: url)
      entries.append([
        "relative_path": rel,
        "byte_length": data.count,
        "sha256": ContentHasher.sha256Hex(data),
      ])
    }
    entries.sort { ($0["relative_path"] as? String ?? "") < ($1["relative_path"] as? String ?? "") }
    return entries
  }

  /// Completeness gate: every on-disk regular file except `package_inventory.json`
  /// must appear in entries; every entry must exist with matching size and digest.
  public static func verifyInventoryCompleteness(
    packageRoot: URL,
    entries: [[String: Any]]
  ) throws {
    let fm = FileManager.default
    var declared = Set<String>()
    for entry in entries {
      guard let rel = entry["relative_path"] as? String else {
        throw SpatialEvidenceError.packageClosureFailed("inventory entry missing relative_path")
      }
      if rel == "package_inventory.json" {
        throw SpatialEvidenceError.packageClosureFailed(
          "inventory self-reference forbidden before closure digest issuance"
        )
      }
      if rel.hasPrefix("/") || rel.contains("://") {
        throw SpatialEvidenceError.packageClosureFailed(
          "absolute path in inventory entry: \(rel)"
        )
      }
      if !declared.insert(rel).inserted {
        throw SpatialEvidenceError.duplicateArtifact(path: rel)
      }
      let url = packageRoot.appendingPathComponent(rel)
      guard fm.fileExists(atPath: url.path) else {
        throw SpatialEvidenceError.missingArtifact(path: rel)
      }
      let data = try Data(contentsOf: url)
      let expectedLen: Int
      if let i = entry["byte_length"] as? Int {
        expectedLen = i
      } else if let n = entry["byte_length"] as? NSNumber {
        expectedLen = n.intValue
      } else {
        throw SpatialEvidenceError.packageClosureFailed("inventory entry missing byte_length: \(rel)")
      }
      if data.count != expectedLen {
        throw SpatialEvidenceError.byteLengthMismatch(
          path: rel,
          expected: expectedLen,
          actual: data.count
        )
      }
      guard let expectedSHA = entry["sha256"] as? String else {
        throw SpatialEvidenceError.packageClosureFailed("inventory entry missing sha256: \(rel)")
      }
      let actualSHA = ContentHasher.sha256Hex(data)
      if actualSHA != expectedSHA {
        throw SpatialEvidenceError.sha256Mismatch(
          path: rel,
          expected: expectedSHA,
          actual: actualSHA
        )
      }
    }

    let enumerator = fm.enumerator(at: packageRoot, includingPropertiesForKeys: [.isRegularFileKey])
    while let url = enumerator?.nextObject() as? URL {
      var isDir: ObjCBool = false
      guard fm.fileExists(atPath: url.path, isDirectory: &isDir), !isDir.boolValue else { continue }
      if url.lastPathComponent == "package_inventory.json" { continue }
      if url.lastPathComponent.hasPrefix(".") { continue }
      let rel = url.path.replacingOccurrences(of: packageRoot.path + "/", with: "")
      if !declared.contains(rel) {
        throw SpatialEvidenceError.orphanArtifact(path: rel)
      }
    }
  }

  /// SHA-256 over a CanonicalJSON array of inventory entries sorted by relative_path.
  /// Each entry contains only relative_path, byte_length, and sha256.
  /// No timestamps, host paths, or nondeterministic ordering.
  public static func inventoryClosureHash(entries: [[String: Any]]) throws -> String {
    var normalized: [[String: Any]] = []
    for entry in entries {
      guard let rel = entry["relative_path"] as? String else {
        throw SpatialEvidenceError.packageClosureFailed("inventory entry missing relative_path")
      }
      if rel == "package_inventory.json" {
        throw SpatialEvidenceError.packageClosureFailed(
          "inventory self-reference forbidden in closure input"
        )
      }
      if rel.hasPrefix("/") || rel.contains("://") || rel.hasPrefix("~") {
        throw SpatialEvidenceError.packageClosureFailed(
          "absolute or host path in closure input: \(rel)"
        )
      }
      let byteLength: Int
      if let i = entry["byte_length"] as? Int {
        byteLength = i
      } else if let n = entry["byte_length"] as? NSNumber {
        byteLength = n.intValue
      } else {
        throw SpatialEvidenceError.packageClosureFailed("inventory entry missing byte_length: \(rel)")
      }
      guard let sha = entry["sha256"] as? String else {
        throw SpatialEvidenceError.packageClosureFailed("inventory entry missing sha256: \(rel)")
      }
      normalized.append([
        "byte_length": byteLength,
        "relative_path": rel,
        "sha256": sha,
      ])
    }
    normalized.sort { ($0["relative_path"] as? String ?? "") < ($1["relative_path"] as? String ?? "") }
    let data = try CanonicalJSON.data(normalized)
    return ContentHasher.sha256Hex(data)
  }

  /// Completeness-gated issuance of `fixture_package_closure_sha256`.
  /// Uses declared `package_inventory.json` entries (not a fresh disk walk) so
  /// missing and orphan files fail before a digest is issued.
  public static func issueInventoryClosureDigest(packageRoot: URL) throws -> String {
    let invURL = packageRoot.appendingPathComponent("package_inventory.json")
    guard FileManager.default.fileExists(atPath: invURL.path) else {
      throw SpatialEvidenceError.packageClosureFailed(
        "package_inventory.json required before closure digest issuance"
      )
    }
    let invData = try Data(contentsOf: invURL)
    guard let invObj = try JSONSerialization.jsonObject(with: invData) as? [String: Any] else {
      throw SpatialEvidenceError.packageClosureFailed("package_inventory.json not object")
    }
    guard let entries = invObj["entries"] as? [[String: Any]] else {
      throw SpatialEvidenceError.packageClosureFailed("package_inventory.json missing entries")
    }
    try verifyInventoryCompleteness(packageRoot: packageRoot, entries: entries)
    return try inventoryClosureHash(entries: entries)
  }
}
