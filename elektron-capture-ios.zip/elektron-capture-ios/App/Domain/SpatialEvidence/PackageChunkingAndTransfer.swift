import Foundation

// MARK: - Content-addressed chunking (fixed-size fixture)

public enum ChunkingAlgorithm: String, Codable, Sendable, Equatable {
  case fixedSizeV1 = "FIXED_SIZE_V1"
}

public enum ChunkCompressionClassification: String, Codable, Sendable, Equatable {
  case none = "NONE"
  case fixtureGzip = "FIXTURE_GZIP"
}

public enum ChunkEncryptionClassification: String, Codable, Sendable, Equatable {
  case none = "NONE"
  case fixtureTransport = "FIXTURE_TRANSPORT"
}

public struct ChunkingPolicy: Codable, Sendable, Equatable {
  public var policyID: String
  public var algorithm: ChunkingAlgorithm
  public var fixedChunkBytes: Int
  public var tenantID: String
  public var securityDomainID: String

  public static let fixture = ChunkingPolicy(
    policyID: "CHUNK-POL-FIXTURE-000001",
    algorithm: .fixedSizeV1,
    fixedChunkBytes: 64,
    tenantID: "TENANT-FIXTURE-000001",
    securityDomainID: "SECDOM-FIXTURE-000001"
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "algorithm": algorithm.rawValue,
      "fixed_chunk_bytes": fixedChunkBytes,
      "tenant_id": tenantID,
      "security_domain_id": securityDomainID,
    ]
  }
}

public struct ContentChunkDescriptor: Codable, Sendable, Equatable {
  public var chunkID: String
  public var packageID: String
  public var sourcePackageClosureSHA256: String
  public var sequence: UInt64
  public var byteOffset: UInt64
  public var byteLength: Int
  public var chunkSHA256: String
  public var compression: ChunkCompressionClassification
  public var encryption: ChunkEncryptionClassification
  public var tenantID: String
  public var securityDomainID: String

  public func dictionary() -> [String: Any] {
    [
      "chunk_id": chunkID,
      "package_id": packageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "sequence": sequence,
      "byte_offset": byteOffset,
      "byte_length": byteLength,
      "chunk_sha256": chunkSHA256,
      "compression_classification": compression.rawValue,
      "encryption_classification": encryption.rawValue,
      "tenant_id": tenantID,
      "security_domain_id": securityDomainID,
    ]
  }
}

public struct PackageChunkManifest: Codable, Sendable, Equatable {
  public var packageID: String
  public var sourcePackageClosureSHA256: String
  public var algorithm: ChunkingAlgorithm
  public var totalByteLength: Int
  public var chunks: [ContentChunkDescriptor]
  public var tenantID: String
  public var securityDomainID: String

  public func manifestSHA256() throws -> String {
    ContentHasher.sha256Hex(try CanonicalJSON.data(dictionary()))
  }

  public func dictionary() -> [String: Any] {
    [
      "package_id": packageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "algorithm": algorithm.rawValue,
      "total_byte_length": totalByteLength,
      "chunks": chunks.map { $0.dictionary() },
      "tenant_id": tenantID,
      "security_domain_id": securityDomainID,
      "schema_id": "PackageChunkManifest",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}

public struct ChunkVerificationResult: Codable, Sendable, Equatable {
  public var ok: Bool
  public var reason: String?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = ["ok": ok]
    if let reason { d["reason"] = reason }
    return d
  }
}

public struct ChunkSequence: Sendable {
  public var policy: ChunkingPolicy

  public init(policy: ChunkingPolicy = .fixture) {
    self.policy = policy
  }

  public func chunk(
    packageBytes: Data,
    packageID: String,
    sourcePackageClosureSHA256: String
  ) throws -> (PackageChunkManifest, [Data]) {
    if packageBytes.isEmpty {
      throw SpatialEvidenceError.chunkingFailed("empty_package")
    }
    var chunks: [ContentChunkDescriptor] = []
    var payloads: [Data] = []
    var offset = 0
    var seq: UInt64 = 0
    let size = policy.fixedChunkBytes
    while offset < packageBytes.count {
      let end = min(offset + size, packageBytes.count)
      let slice = packageBytes.subdata(in: offset..<end)
      let sha = ContentHasher.sha256Hex(slice)
      let desc = ContentChunkDescriptor(
        chunkID: "CHK-\(packageID)-\(String(format: "%04d", seq))",
        packageID: packageID,
        sourcePackageClosureSHA256: sourcePackageClosureSHA256,
        sequence: seq,
        byteOffset: UInt64(offset),
        byteLength: slice.count,
        chunkSHA256: sha,
        compression: .none,
        encryption: .none,
        tenantID: policy.tenantID,
        securityDomainID: policy.securityDomainID
      )
      chunks.append(desc)
      payloads.append(slice)
      offset = end
      seq += 1
    }
    let manifest = PackageChunkManifest(
      packageID: packageID,
      sourcePackageClosureSHA256: sourcePackageClosureSHA256,
      algorithm: policy.algorithm,
      totalByteLength: packageBytes.count,
      chunks: chunks,
      tenantID: policy.tenantID,
      securityDomainID: policy.securityDomainID
    )
    return (manifest, payloads)
  }

  public func verifyChunk(_ desc: ContentChunkDescriptor, bytes: Data) -> ChunkVerificationResult {
    if bytes.count != desc.byteLength {
      return ChunkVerificationResult(ok: false, reason: "truncated_or_length_mismatch")
    }
    if ContentHasher.sha256Hex(bytes) != desc.chunkSHA256 {
      return ChunkVerificationResult(ok: false, reason: "modified_chunk_hash")
    }
    return ChunkVerificationResult(ok: true, reason: nil)
  }

  public func validateManifestLayout(_ manifest: PackageChunkManifest) throws {
    var seenSeq = Set<UInt64>()
    var expectedOffset: UInt64 = 0
    let ordered = manifest.chunks.sorted { $0.sequence < $1.sequence }
    for c in ordered {
      if c.chunkID.hasPrefix("/") || c.chunkID.contains("://") {
        throw SpatialEvidenceError.chunkingFailed("absolute_path_rejected")
      }
      if !seenSeq.insert(c.sequence).inserted {
        throw SpatialEvidenceError.chunkingFailed("duplicate_sequence")
      }
      if c.byteOffset > expectedOffset {
        throw SpatialEvidenceError.chunkingFailed("gap_in_offsets")
      }
      if c.byteOffset < expectedOffset {
        throw SpatialEvidenceError.chunkingFailed("overlapping_offsets")
      }
      if c.sourcePackageClosureSHA256 != manifest.sourcePackageClosureSHA256 {
        throw SpatialEvidenceError.chunkingFailed("wrong_source_package_closure")
      }
      expectedOffset += UInt64(c.byteLength)
    }
    for i in 0..<manifest.chunks.count {
      if !seenSeq.contains(UInt64(i)) {
        throw SpatialEvidenceError.chunkingFailed("missing_sequence")
      }
    }
    if Int(expectedOffset) != manifest.totalByteLength {
      throw SpatialEvidenceError.chunkingFailed("total_length_mismatch")
    }
  }
}

// MARK: - Resumable transfer

public enum UploadSessionState: String, Codable, Sendable, Equatable {
  case created = "CREATED"
  case uploading = "UPLOADING"
  case paused = "PAUSED"
  case interrupted = "INTERRUPTED"
  case resuming = "RESUMING"
  case verifying = "VERIFYING"
  case complete = "COMPLETE"
  case failed = "FAILED"
  case cancelled = "CANCELLED"
  case expired = "EXPIRED"
}

public enum ChunkUploadState: String, Codable, Sendable, Equatable {
  case pending = "PENDING"
  case uploading = "UPLOADING"
  case accepted = "ACCEPTED"
  case rejected = "REJECTED"
  case missing = "MISSING"
}

public enum TransferFailureReason: String, Codable, Sendable, Equatable {
  case networkInterrupted = "NETWORK_INTERRUPTED"
  case retryLimitExceeded = "RETRY_LIMIT_EXCEEDED"
  case expired = "EXPIRED"
  case cancelled = "CANCELLED"
  case receiptMismatch = "RECEIPT_MISMATCH"
  case missingReceipt = "MISSING_RECEIPT"
  case serverError = "SERVER_ERROR"
}

public struct ChunkUploadAttempt: Codable, Sendable, Equatable {
  public var attemptID: String
  public var chunkID: String
  public var attemptedAtUTC: String
  public var success: Bool
  public var reason: String?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "attempt_id": attemptID,
      "chunk_id": chunkID,
      "attempted_at_utc": attemptedAtUTC,
      "success": success,
    ]
    if let reason { d["reason"] = reason }
    return d
  }
}

public struct ChunkReceipt: Codable, Sendable, Equatable {
  public var receiptID: String
  public var chunkID: String
  public var chunkSHA256: String
  public var tenantID: String
  public var securityDomainID: String
  public var acceptedAtUTC: String
  public var serverNonce: String

  public func dictionary() -> [String: Any] {
    [
      "receipt_id": receiptID,
      "chunk_id": chunkID,
      "chunk_sha256": chunkSHA256,
      "tenant_id": tenantID,
      "security_domain_id": securityDomainID,
      "accepted_at_utc": acceptedAtUTC,
      "server_nonce": serverNonce,
    ]
  }
}

public struct TransferCheckpoint: Codable, Sendable, Equatable {
  public var checkpointID: String
  public var sessionID: String
  public var acceptedChunkIDs: [String]
  public var missingChunkIDs: [String]
  public var state: UploadSessionState
  public var createdAtUTC: String

  public func dictionary() -> [String: Any] {
    [
      "checkpoint_id": checkpointID,
      "session_id": sessionID,
      "accepted_chunk_ids": acceptedChunkIDs.sorted(),
      "missing_chunk_ids": missingChunkIDs.sorted(),
      "state": state.rawValue,
      "created_at_utc": createdAtUTC,
    ]
  }
}

public struct TransferRecoveryPlan: Codable, Sendable, Equatable {
  public var planID: String
  public var chunksToUpload: [String]
  public var note: String

  public func dictionary() -> [String: Any] {
    [
      "plan_id": planID,
      "chunks_to_upload": chunksToUpload.sorted(),
      "note": note,
    ]
  }
}

public struct ResumableUploadSession: Sendable {
  public let sessionID: String
  public let packageID: String
  public let tenantID: String
  public let securityDomainID: String
  public var state: UploadSessionState
  public var chunkStates: [String: ChunkUploadState]
  public var receipts: [String: ChunkReceipt]
  public var attempts: [ChunkUploadAttempt]
  public var expiresAtUTC: String
  public var maxRetries: Int
  public var completionCount: Int
  public private(set) var resentAcceptedChunkIDs: [String]

  public init(
    sessionID: String,
    packageID: String,
    manifest: PackageChunkManifest,
    expiresAtUTC: String = "2026-08-04T00:00:00Z",
    maxRetries: Int = 3
  ) {
    self.sessionID = sessionID
    self.packageID = packageID
    self.tenantID = manifest.tenantID
    self.securityDomainID = manifest.securityDomainID
    self.state = .created
    var states: [String: ChunkUploadState] = [:]
    for c in manifest.chunks { states[c.chunkID] = .pending }
    self.chunkStates = states
    self.receipts = [:]
    self.attempts = []
    self.expiresAtUTC = expiresAtUTC
    self.maxRetries = maxRetries
    self.completionCount = 0
    self.resentAcceptedChunkIDs = []
  }

  public mutating func beginUpload(nowUTC: String = "2026-08-03T01:00:00Z") throws {
    try assertNotTerminal(nowUTC: nowUTC)
    state = .uploading
  }

  public mutating func pause() throws {
    guard state == .uploading || state == .resuming else {
      throw SpatialEvidenceError.transferFailed("pause_invalid_state_\(state.rawValue)")
    }
    state = .paused
  }

  public mutating func interrupt(reason: TransferFailureReason = .networkInterrupted) {
    state = .interrupted
    _ = reason
  }

  public mutating func cancel() {
    state = .cancelled
  }

  public mutating func expire(nowUTC: String) throws {
    if nowUTC > expiresAtUTC {
      state = .expired
      throw SpatialEvidenceError.transferFailed(TransferFailureReason.expired.rawValue)
    }
  }

  public func missingChunkIDs() -> [String] {
    chunkStates.filter { $0.value != .accepted }.map(\.key).sorted()
  }

  public func acceptedChunkIDs() -> [String] {
    chunkStates.filter { $0.value == .accepted }.map(\.key).sorted()
  }

  public mutating func checkpoint(nowUTC: String = "2026-08-03T01:00:00Z") -> TransferCheckpoint {
    TransferCheckpoint(
      checkpointID: "CP-\(sessionID)-\(attempts.count)",
      sessionID: sessionID,
      acceptedChunkIDs: acceptedChunkIDs(),
      missingChunkIDs: missingChunkIDs(),
      state: state,
      createdAtUTC: nowUTC
    )
  }

  public mutating func resume() throws -> TransferRecoveryPlan {
    guard state == .interrupted || state == .paused else {
      throw SpatialEvidenceError.transferFailed("resume_invalid_state_\(state.rawValue)")
    }
    state = .resuming
    let missing = missingChunkIDs()
    return TransferRecoveryPlan(
      planID: "RP-\(sessionID)",
      chunksToUpload: missing,
      note: "Do not resend accepted chunks unless server explicitly requests"
    )
  }

  /// Submit a chunk. Accepted chunks are not resent unless `serverRequestsResend`.
  public mutating func submitChunk(
    descriptor: ContentChunkDescriptor,
    bytes: Data,
    server: inout FixtureTransferServer,
    nowUTC: String = "2026-08-03T01:00:00Z",
    serverRequestsResend: Bool = false
  ) throws -> ChunkReceipt? {
    try assertNotTerminal(nowUTC: nowUTC)
    if state == .created { state = .uploading }
    if state == .resuming { state = .uploading }

    if chunkStates[descriptor.chunkID] == .accepted, !serverRequestsResend {
      // Already accepted — do not resend.
      return receipts[descriptor.chunkID]
    }
    if chunkStates[descriptor.chunkID] == .accepted, serverRequestsResend {
      resentAcceptedChunkIDs.append(descriptor.chunkID)
    }

    let priorFails = attempts.filter { $0.chunkID == descriptor.chunkID && !$0.success }.count
    if priorFails >= maxRetries {
      state = .failed
      throw SpatialEvidenceError.transferFailed(TransferFailureReason.retryLimitExceeded.rawValue)
    }

    chunkStates[descriptor.chunkID] = .uploading
    let verify = ChunkSequence().verifyChunk(descriptor, bytes: bytes)
    guard verify.ok else {
      attempts.append(
        ChunkUploadAttempt(
          attemptID: "ATT-\(attempts.count + 1)",
          chunkID: descriptor.chunkID,
          attemptedAtUTC: nowUTC,
          success: false,
          reason: verify.reason
        )
      )
      chunkStates[descriptor.chunkID] = .rejected
      throw SpatialEvidenceError.transferFailed(verify.reason ?? "chunk_verify_failed")
    }

    let receipt = try server.accept(
      descriptor: descriptor,
      bytes: bytes,
      tenantID: tenantID,
      securityDomainID: securityDomainID,
      nowUTC: nowUTC
    )
    attempts.append(
      ChunkUploadAttempt(
        attemptID: "ATT-\(attempts.count + 1)",
        chunkID: descriptor.chunkID,
        attemptedAtUTC: nowUTC,
        success: true,
        reason: nil
      )
    )
    chunkStates[descriptor.chunkID] = .accepted
    receipts[descriptor.chunkID] = receipt
    return receipt
  }

  public mutating func finalize(manifest: PackageChunkManifest) throws -> TransferReceipt {
    if state == .cancelled || state == .expired || state == .failed {
      throw SpatialEvidenceError.transferFailed("finalize_terminal_\(state.rawValue)")
    }
    if completionCount > 0 {
      throw SpatialEvidenceError.transferFailed("duplicate_completion")
    }
    state = .verifying
    for c in manifest.chunks {
      guard let receipt = receipts[c.chunkID] else {
        state = .failed
        throw SpatialEvidenceError.transferFailed(TransferFailureReason.missingReceipt.rawValue)
      }
      if receipt.chunkSHA256 != c.chunkSHA256 {
        state = .failed
        throw SpatialEvidenceError.transferFailed(TransferFailureReason.receiptMismatch.rawValue)
      }
    }
    if !missingChunkIDs().isEmpty {
      state = .failed
      throw SpatialEvidenceError.transferFailed("missing_chunks")
    }
    state = .complete
    completionCount = 1
    return TransferReceipt(
      receiptID: "XFER-\(sessionID)",
      sessionID: sessionID,
      packageID: packageID,
      acceptedChunkIDs: acceptedChunkIDs(),
      state: state
    )
  }

  private func assertNotTerminal(nowUTC: String) throws {
    if state == .cancelled {
      throw SpatialEvidenceError.transferFailed(TransferFailureReason.cancelled.rawValue)
    }
    if state == .expired || nowUTC > expiresAtUTC {
      throw SpatialEvidenceError.transferFailed(TransferFailureReason.expired.rawValue)
    }
    if state == .failed {
      throw SpatialEvidenceError.transferFailed("session_failed")
    }
    if state == .complete {
      throw SpatialEvidenceError.transferFailed("duplicate_completion")
    }
  }
}

public struct TransferReceipt: Codable, Sendable, Equatable {
  public var receiptID: String
  public var sessionID: String
  public var packageID: String
  public var acceptedChunkIDs: [String]
  public var state: UploadSessionState

  public func dictionary() -> [String: Any] {
    [
      "receipt_id": receiptID,
      "session_id": sessionID,
      "package_id": packageID,
      "accepted_chunk_ids": acceptedChunkIDs.sorted(),
      "state": state.rawValue,
    ]
  }
}

/// Fixture server store — tenant/security-domain scoped deduplication.
public struct FixtureTransferServer: Sendable {
  public struct StoredChunk: Sendable {
    public var bytes: Data
    public var sha256: String
    public var tenantID: String
    public var securityDomainID: String
  }

  public var store: [String: StoredChunk] = [:]
  public var nonceCounter: Int = 0

  public init() {}

  public mutating func accept(
    descriptor: ContentChunkDescriptor,
    bytes: Data,
    tenantID: String,
    securityDomainID: String,
    nowUTC: String
  ) throws -> ChunkReceipt {
    if descriptor.tenantID != tenantID || tenantID != securityDomainBoundCheck(tenantID) {
      // keep simple: require exact match
    }
    if descriptor.tenantID != tenantID || descriptor.securityDomainID != securityDomainID {
      throw SpatialEvidenceError.crossTenantDedupRejected("descriptor_scope_mismatch")
    }
    let key = storageKey(tenantID: tenantID, securityDomainID: securityDomainID, sha256: descriptor.chunkSHA256)
    if let existing = store[key] {
      if existing.sha256 != descriptor.chunkSHA256 {
        throw SpatialEvidenceError.transferFailed("store_hash_mismatch")
      }
      // reuse within tenant+domain
    } else {
      store[key] = StoredChunk(
        bytes: bytes,
        sha256: descriptor.chunkSHA256,
        tenantID: tenantID,
        securityDomainID: securityDomainID
      )
    }
    nonceCounter += 1
    return ChunkReceipt(
      receiptID: "RCPT-\(descriptor.chunkID)-\(nonceCounter)",
      chunkID: descriptor.chunkID,
      chunkSHA256: descriptor.chunkSHA256,
      tenantID: tenantID,
      securityDomainID: securityDomainID,
      acceptedAtUTC: nowUTC,
      serverNonce: "nonce-\(nonceCounter)"
    )
  }

  public func lookup(
    sha256: String,
    tenantID: String,
    securityDomainID: String
  ) -> StoredChunk? {
    store[storageKey(tenantID: tenantID, securityDomainID: securityDomainID, sha256: sha256)]
  }

  public func rejectCrossTenantReuse(
    sha256: String,
    fromTenant: String,
    toTenant: String,
    securityDomainID: String
  ) throws {
    if fromTenant != toTenant {
      throw SpatialEvidenceError.crossTenantDedupRejected("cross_tenant_\(fromTenant)->\(toTenant)")
    }
    _ = sha256
    _ = securityDomainID
  }

  public func rejectCrossSecurityDomainReuse(
    sha256: String,
    tenantID: String,
    fromDomain: String,
    toDomain: String
  ) throws {
    if fromDomain != toDomain {
      throw SpatialEvidenceError.crossTenantDedupRejected("cross_security_domain_\(fromDomain)->\(toDomain)")
    }
    _ = sha256
    _ = tenantID
  }

  private func storageKey(tenantID: String, securityDomainID: String, sha256: String) -> String {
    "\(tenantID)|\(securityDomainID)|\(sha256)"
  }

  private func securityDomainBoundCheck(_ tenantID: String) -> String { tenantID }
}

public struct TenantDeduplicationRecord: Codable, Sendable, Equatable {
  public var tenantID: String
  public var securityDomainID: String
  public var deduplicationPolicyID: String
  public var reusedChunkIDs: [String]
  public var newlyUploadedChunkIDs: [String]
  public var bytesSaved: Int
  public var deduplicationAuthority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    [
      "tenant_id": tenantID,
      "security_domain_id": securityDomainID,
      "deduplication_policy_id": deduplicationPolicyID,
      "reused_chunk_ids": reusedChunkIDs.sorted(),
      "newly_uploaded_chunk_ids": newlyUploadedChunkIDs.sorted(),
      "bytes_saved": bytesSaved,
      "deduplication_authority": deduplicationAuthority.rawValue,
      "note": "No cross-customer global deduplication",
    ]
  }
}

// MARK: - Reassembly

public struct PackageReassemblyPlan: Codable, Sendable, Equatable {
  public var planID: String
  public var packageID: String
  public var expectedByteLength: Int
  public var expectedClosureSHA256: String
  public var expectedZIPSHA256: String?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "plan_id": planID,
      "package_id": packageID,
      "expected_byte_length": expectedByteLength,
      "expected_closure_sha256": expectedClosureSHA256,
    ]
    if let expectedZIPSHA256 { d["expected_zip_sha256"] = expectedZIPSHA256 }
    return d
  }
}

public struct ReassemblyVerificationResult: Codable, Sendable, Equatable {
  public var ok: Bool
  public var reassembledByteLength: Int
  public var reassembledZIPSHA256: String
  public var packageClosureMatch: Bool
  public var signaturePreserved: Bool
  public var journalRootPreserved: Bool
  public var privacyViolations: [String]
  public var note: String

  public func dictionary() -> [String: Any] {
    [
      "ok": ok,
      "reassembled_byte_length": reassembledByteLength,
      "reassembled_zip_sha256": reassembledZIPSHA256,
      "package_closure_match": packageClosureMatch,
      "signature_preserved": signaturePreserved,
      "journal_root_preserved": journalRootPreserved,
      "privacy_violations": privacyViolations,
      "note": note,
    ]
  }
}

public struct FinalPackageReceipt: Codable, Sendable, Equatable {
  public var receiptID: String
  public var packageID: String
  public var reassembledZIPSHA256: String
  public var packageClosureSHA256: String
  public var verifiedAtUTC: String

  public func dictionary() -> [String: Any] {
    [
      "receipt_id": receiptID,
      "package_id": packageID,
      "reassembled_zip_sha256": reassembledZIPSHA256,
      "package_closure_sha256": packageClosureSHA256,
      "verified_at_utc": verifiedAtUTC,
    ]
  }
}

public struct PackageReassembler: Sendable {
  public init() {}

  public func reassemble(
    manifest: PackageChunkManifest,
    payloadsByChunkID: [String: Data]
  ) throws -> Data {
    try ChunkSequence().validateManifestLayout(manifest)
    var out = Data()
    for c in manifest.chunks.sorted(by: { $0.sequence < $1.sequence }) {
      guard let bytes = payloadsByChunkID[c.chunkID] else {
        throw SpatialEvidenceError.reassemblyFailed("missing_chunk_\(c.chunkID)")
      }
      let v = ChunkSequence().verifyChunk(c, bytes: bytes)
      guard v.ok else {
        throw SpatialEvidenceError.reassemblyFailed(v.reason ?? "chunk_hash")
      }
      out.append(bytes)
    }
    if out.count != manifest.totalByteLength {
      throw SpatialEvidenceError.reassemblyFailed("byte_length_mismatch")
    }
    return out
  }

  public func verify(
    reassembled: Data,
    expectedZIPSHA256: String,
    expectedClosureSHA256: String,
    observedClosureSHA256: String,
    signaturePreserved: Bool,
    journalRootPreserved: Bool,
    privacyViolations: [String] = []
  ) throws -> ReassemblyVerificationResult {
    let zipSHA = ContentHasher.sha256Hex(reassembled)
    let closureMatch = observedClosureSHA256 == expectedClosureSHA256
    let ok = zipSHA == expectedZIPSHA256
      && closureMatch
      && signaturePreserved
      && journalRootPreserved
      && privacyViolations.isEmpty
    if !ok {
      throw SpatialEvidenceError.reassemblyFailed("verification_failed")
    }
    return ReassemblyVerificationResult(
      ok: true,
      reassembledByteLength: reassembled.count,
      reassembledZIPSHA256: zipSHA,
      packageClosureMatch: closureMatch,
      signaturePreserved: signaturePreserved,
      journalRootPreserved: journalRootPreserved,
      privacyViolations: privacyViolations,
      note: "byte_identity_and_closure_verified"
    )
  }
}
