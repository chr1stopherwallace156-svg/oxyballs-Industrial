import Foundation

/// Fixture HMAC signer / verifier. Separates hash identity, signature, enrollment, attestation.
/// Embedded public keys are never trusted alone — enrollment registry lookup is required.
public struct PackageSignatureVerifier: Sendable {
  public var registry: DeviceKeyTrustRegistry

  public init(registry: DeviceKeyTrustRegistry = DeviceKeyTrustRegistry(records: [.fixtureEnrolled()])) {
    self.registry = registry
  }

  public func verify(
    envelope: PackageSignatureEnvelope,
    expectedClosure: String,
    expectedManifest: String
  ) throws -> (SignatureVerificationResult, SignatureFailureReason?) {
    guard envelope.packageClosureSHA256 == expectedClosure,
          envelope.manifestSHA256 == expectedManifest
    else {
      return (.invalid, .packageBindingMismatch)
    }

    guard let enrollment = registry.lookup(deviceKeyID: envelope.signingKeyID) else {
      // Signature bytes may still verify mathematically against embedded material,
      // but without enrollment the origin is untrusted.
      let mathOK = try FixturePackageSigner.verifyMath(envelope: envelope)
      if mathOK {
        return (.validButUntrustedOrigin, .unknownKey)
      }
      return (.invalid, .unknownKey)
    }

    guard enrollment.enrollmentRecordID == envelope.enrollmentRecordID,
          enrollment.publicKeyFingerprint == envelope.publicKeyFingerprint
    else {
      return (.invalid, .enrollmentMismatch)
    }

    switch enrollment.trustStatus {
    case .revoked:
      return (.validButUntrustedOrigin, .revokedKey)
    case .unknown, .expired, .suspended:
      return (.validButUntrustedOrigin, .unknownKey)
    case .enrolled, .verified:
      break
    }

    let mathOK = try FixturePackageSigner.verifyMath(envelope: envelope)
    guard mathOK else {
      return (.invalid, .signatureByteMutation)
    }
    return (.validEnrolled, nil)
  }
}

public struct FixturePackageSigner: Sendable {
  public static let fixtureSecretMaterial = "ELEKTRON-FIXTURE-HMAC-SECRET-NOT-HARDWARE-v1"

  public init() {}

  public func sign(
    packageID: String,
    captureSessionID: String,
    packageClosureSHA256: String,
    manifestSHA256: String,
    enrollment: DeviceKeyEnrollmentRecord = .fixtureEnrolled(),
    signedAtUTC: String = "2026-08-03T00:00:00Z"
  ) throws -> PackageSignatureEnvelope {
    precondition(enrollment.trustStatus == .enrolled || enrollment.trustStatus == .verified)
    var env = PackageSignatureEnvelope(
      packageID: packageID,
      captureSessionID: captureSessionID,
      packageClosureSHA256: packageClosureSHA256,
      manifestSHA256: manifestSHA256,
      signingKeyID: enrollment.deviceKeyID,
      publicKeyFingerprint: enrollment.publicKeyFingerprint,
      signatureAlgorithm: .fixtureHmacSha256V1,
      signatureBytesHex: "",
      signedAtUTC: signedAtUTC,
      enrollmentRecordID: enrollment.enrollmentRecordID,
      signerStatus: enrollment.trustStatus,
      evidenceOriginAuthority: .testFixture
    )
    env.signatureBytesHex = try Self.computeSignatureHex(envelope: env)
    return env
  }

  public static func computeSignatureHex(envelope: PackageSignatureEnvelope) throws -> String {
    let material = try envelope.bindingDigestMaterial()
    let key = Data(fixtureSecretMaterial.utf8)
    // Deterministic keyed digest: sha256(key || 0x00 || material)
    var combined = Data()
    combined.append(key)
    combined.append(0)
    combined.append(material)
    return ContentHasher.sha256Hex(combined)
  }

  public static func verifyMath(envelope: PackageSignatureEnvelope) throws -> Bool {
    guard envelope.signatureAlgorithm == .fixtureHmacSha256V1 else {
      return false
    }
    let expected = try computeSignatureHex(envelope: envelope)
    return expected == envelope.signatureBytesHex
  }
}

/// Portable server-side App Attest verification (fixture deterministic).
public struct AppAttestServerVerifier: Sendable {
  public var seenAssertionIDs: Set<String>
  public var nowUTC: String

  public init(seenAssertionIDs: Set<String> = [], nowUTC: String = "2026-08-03T00:00:00Z") {
    self.seenAssertionIDs = seenAssertionIDs
    self.nowUTC = nowUTC
  }

  public mutating func verify(
    challenge: AppAttestChallenge,
    assertion: AppAttestAssertionEnvelope,
    expectedClosure: String,
    expectedSessionID: String,
    enrollment: DeviceKeyEnrollmentRecord
  ) -> AppAttestVerificationResult {
    if assertion.challengeID != challenge.challengeID || assertion.serverNonce != challenge.serverNonce {
      return AppAttestVerificationResult(disposition: .attestationFailed, challengeID: challenge.challengeID, reason: "challenge_binding_mismatch")
    }
    if nowUTC > challenge.expiresAtUTC {
      return AppAttestVerificationResult(disposition: .challengeExpired, challengeID: challenge.challengeID, reason: "challenge_expired")
    }
    if seenAssertionIDs.contains(assertion.assertionID) {
      return AppAttestVerificationResult(disposition: .assertionReplayed, challengeID: challenge.challengeID, reason: "assertion_replayed")
    }
    if assertion.packageClosureSHA256 != expectedClosure || assertion.captureSessionID != expectedSessionID {
      return AppAttestVerificationResult(disposition: .attestationFailed, challengeID: challenge.challengeID, reason: "package_binding_mismatch")
    }
    if assertion.enrollmentRecordID != enrollment.enrollmentRecordID {
      return AppAttestVerificationResult(disposition: .riskReviewRequired, challengeID: challenge.challengeID, reason: "enrollment_mismatch")
    }
    if assertion.appIdentifier != challenge.appIdentifier {
      return AppAttestVerificationResult(disposition: .attestationFailed, challengeID: challenge.challengeID, reason: "app_identifier_mismatch")
    }
    seenAssertionIDs.insert(assertion.assertionID)
    return AppAttestVerificationResult(disposition: .appInstanceAttested, challengeID: challenge.challengeID, reason: nil)
  }
}

/// Fixture client assertion generator (NOT Apple App Attest hardware).
public struct FixtureAppAttestClient: Sendable {
  public init() {}

  public func makeAssertion(
    challenge: AppAttestChallenge,
    packageClosureSHA256: String,
    captureSessionID: String,
    enrollment: DeviceKeyEnrollmentRecord,
    createdAtUTC: String = "2026-08-03T00:00:00Z"
  ) throws -> AppAttestAssertionEnvelope {
    let material = try CanonicalJSON.data([
      "challenge_id": challenge.challengeID,
      "server_nonce": challenge.serverNonce,
      "package_closure_sha256": packageClosureSHA256,
      "capture_session_id": captureSessionID,
      "enrollment_record_id": enrollment.enrollmentRecordID,
    ] as [String: Any])
    let hex = ContentHasher.sha256Hex(material)
    return AppAttestAssertionEnvelope(
      assertionID: "ASSERT-FIXTURE-\(challenge.challengeID)",
      challengeID: challenge.challengeID,
      serverNonce: challenge.serverNonce,
      packageClosureSHA256: packageClosureSHA256,
      captureSessionID: captureSessionID,
      appIdentifier: challenge.appIdentifier,
      enrollmentRecordID: enrollment.enrollmentRecordID,
      assertionBytesHex: hex,
      createdAtUTC: createdAtUTC
    )
  }
}
