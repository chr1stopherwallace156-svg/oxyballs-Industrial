import Foundation

/// Builds fixture packages with camera + pose streams (motion optional).
/// Primary dual-stream layout: camera + pose. Motion empty ⇒ NOT_REQUESTED (no motion payload).
/// Identities are always `SPKG-FIXTURE-*` / `SESS-FIXTURE-*`; never `SPKG-DEVICE-*`.
public struct FixturePosePackageBuilder: Sendable {
  public static let primaryPackageID = "SPKG-FIXTURE-CAMERA-POSE-000001"
  public static let primarySessionID = "SESS-FIXTURE-CAMERA-POSE-000001"
  public static let monotonicToArkitCorrelationID = "fixture-monotonic-to-arkit-000001"

  public init() {}

  public func seal(
    camera: [SpatialSampleEnvelope<CameraSample>],
    motion: [SpatialSampleEnvelope<MotionSample>],
    pose: [SpatialSampleEnvelope<PoseSample>],
    cameraCapability: SpatialStreamCapability,
    motionCapability: SpatialStreamCapability,
    poseCapability: SpatialStreamCapability,
    frames: [CoordinateFrameDescriptor],
    transformEdges: [TransformEdge],
    clockCorrelations: [ClockCorrelation],
    associations: [PoseAssociationRecord],
    outputDirectory: URL,
    vehicleID: String = "VEH-000001",
    pilotID: String = "PILOT-000001",
    captureSessionID: String = FixturePosePackageBuilder.primarySessionID,
    packageID: String = FixturePosePackageBuilder.primaryPackageID,
    createdAtUTC: String = "2026-08-03T00:00:00Z"
  ) throws -> SpatialEvidencePackage {
    precondition(!camera.isEmpty, "fixture pose package requires camera samples")
    precondition(!pose.isEmpty, "fixture pose package requires pose samples")
    precondition(
      !packageID.hasPrefix("SPKG-DEVICE-"),
      "SPKG-DEVICE-* reserved for Sprint 3.6 physical packages; use SPKG-FIXTURE-*"
    )
    precondition(
      !captureSessionID.hasPrefix("SESS-DEVICE-"),
      "SESS-DEVICE-* reserved for Sprint 3.6; use SESS-FIXTURE-*"
    )

    // Fail-closed spatiotemporal validation before writing bytes.
    let graph = CoordinateFrameGraph(frames: frames, edges: transformEdges)
    try graph.validateRegistry()
    try graph.validateEdgesReferenceKnownFrames()
    try graph.validateTransformGraph()
    for sample in pose {
      try PoseMathValidator.validatePoseSample(sample.payload)
      try graph.requireKnownFrame(sample.payload.sourceFrameID)
      try graph.requireKnownFrame(sample.payload.destinationFrameID)
      try graph.requirePath(from: sample.payload.sourceFrameID, to: sample.payload.destinationFrameID)
    }
    try PoseWorldEpochValidator.requireHomogeneousPackageEpoch(pose.map(\.payload))
    guard let epochPose = pose.first?.payload else {
      throw SpatialEvidenceError.validationFailed("missing_pose_epoch")
    }
    try TransformEdgeValidator.validateAll(
      edges: transformEdges,
      frames: frames,
      poseSampleIDs: Set(pose.map(\.sampleID)),
      packageSessionRunID: epochPose.sessionRunID,
      packageFrameEpochID: epochPose.frameEpochID,
      packageWorldOriginRevision: epochPose.worldOriginRevision
    )
    try PoseAssociationValidator.validateAll(
      cameraSamples: camera,
      poseSamples: pose,
      associations: associations,
      correlations: clockCorrelations
    )
    let clockValidator = ClockCorrelationValidator(correlations: clockCorrelations)
    // Ensure cross-domain camera↔pose correlations exist when domains differ.
    for cam in camera {
      for p in pose where cam.clockDomain != p.clockDomain {
        _ = try clockValidator.requireComparable(
          source: cam.clockDomain,
          destination: p.clockDomain,
          atSourceTimestampNs: cam.acquisitionTimestampNs
        )
      }
    }

    try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
    let payloadRoot = outputDirectory.appendingPathComponent("payload", isDirectory: true)
    try FileManager.default.createDirectory(at: payloadRoot, withIntermediateDirectories: true)

    var camCap = cameraCapability
    var motCap = motionCapability
    var poseCap = poseCapability
    try camCap.freeze(outcome: .acquired)
    try poseCap.freeze(outcome: .acquired)
    if motion.isEmpty {
      // Motion optional for dual-stream camera+pose primary.
      motCap = SpatialStreamCapability(
        streamID: SpatialStreamID.motion,
        adapterID: "none",
        sensorKind: "motion",
        declared: false
      )
      try motCap.freeze(outcome: .notRequested)
    } else {
      try motCap.freeze(outcome: .acquired)
    }

    var depthCap = SpatialStreamCapability(
      streamID: SpatialStreamID.depth,
      adapterID: "none",
      sensorKind: "depth",
      declared: false
    )
    try depthCap.freeze(outcome: .notRequested)

    let capability = SpatialCapabilitySnapshot(
      snapshotID: "cap-fixture-camera-pose-1",
      capturedAtUTC: createdAtUTC,
      streams: [camCap, motCap, poseCap, depthCap],
      schemaVersion: SpatialCapabilitySnapshot.fixtureSchemaVersion
    )

    var artifacts: [SpatialArtifactDescriptor] = []
    var sampleIndex: [[String: Any]] = []

    try writePayload(
      stream: SpatialStreamID.camera,
      adapterID: camCap.adapterID,
      samples: camera,
      root: payloadRoot,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }
    if !motion.isEmpty {
      try writePayload(
        stream: SpatialStreamID.motion,
        adapterID: motCap.adapterID,
        samples: motion,
        root: payloadRoot,
        artifacts: &artifacts,
        sampleIndex: &sampleIndex
      ) { $0.bytes }
    }
    try writePayload(
      stream: SpatialStreamID.pose,
      adapterID: poseCap.adapterID,
      samples: pose,
      root: payloadRoot,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }

    if motion.isEmpty {
      try NotRequestedStreamEvidenceValidator.validateMotionNotRequested(
        capability: motCap,
        artifacts: artifacts,
        frames: frames,
        clockCorrelations: clockCorrelations
      )
    }

    sampleIndex.sort {
      (($0["relative_path"] as? String) ?? "") < (($1["relative_path"] as? String) ?? "")
    }

    try writeJSON(capability.asDictionary(), to: outputDirectory.appendingPathComponent("capability_snapshot.json"))
    try writeJSON(
      ["frames": frames.sorted { $0.frameID < $1.frameID }.map { $0.asDictionary() }],
      to: outputDirectory.appendingPathComponent("coordinate_frames.json")
    )
    try writeJSON(
      [
        "edges": transformEdges.map { $0.asDictionary() },
        "note": "Transform edges are explicit; no silent shared world frame.",
        "characterization_status": "PENDING_CHARACTERIZATION",
        "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED",
      ],
      to: outputDirectory.appendingPathComponent("transform_graph.json")
    )
    try writeJSON(
      [
        "correlations": clockCorrelations
          .sorted { $0.sourceDomain.rawValue < $1.sourceDomain.rawValue }
          .map { $0.asDictionary() },
        "note": "Camera and pose clocks are NOT assumed identical without explicit ClockCorrelation records.",
      ],
      to: outputDirectory.appendingPathComponent("clock_correlation.json")
    )
    try writeJSON(
      ["associations": associations.map { $0.asDictionary() }],
      to: outputDirectory.appendingPathComponent("pose_associations.json")
    )
    try writeJSON(["samples": sampleIndex], to: outputDirectory.appendingPathComponent("sample_index.json"))

    let manifest = SpatialEvidenceManifest(
      packageID: packageID,
      vehicleID: vehicleID,
      captureSessionID: captureSessionID,
      pilotID: pilotID,
      createdAtUTC: createdAtUTC,
      capability: capability,
      frames: frames,
      clockCorrelations: clockCorrelations,
      artifacts: artifacts,
      sampleIndex: sampleIndex
    )
    var manifestDict = manifest.asDictionary()
    manifestDict["schema_id"] = "SpatialEvidenceManifest"
    manifestDict["schema_version"] = "1.0.0-phase3-fixture"
    manifestDict["package_layout"] = "fixture_camera_pose_v1"
    manifestDict["host_claim"] = "NO_PHYSICAL_DEVICE_EXECUTION"
    manifestDict["implementation_state"] = "SOURCE_IMPLEMENTED"
    manifestDict["validation_state"] = "LINUX_FIXTURE_VALIDATED"
    // Authority split: evidence origin vs pose estimate (no ambiguous bare authority).
    manifestDict["evidence_origin_authority"] = "TEST_FIXTURE"
    manifestDict["pose_estimate_authority"] = "GUIDANCE_ESTIMATE"
    manifestDict["pose_adapter_id"] = poseCap.adapterID
    manifestDict["pose_associations"] = associations.map { $0.asDictionary() }
    manifestDict["transform_edges"] = transformEdges.map { $0.asDictionary() }
    manifestDict["frame_epoch_id"] = epochPose.frameEpochID
    manifestDict["session_run_id"] = epochPose.sessionRunID
    manifestDict["world_origin_revision"] = epochPose.worldOriginRevision

    let manifestData = try CanonicalJSON.data(manifestDict)
    try manifestData.write(to: outputDirectory.appendingPathComponent("manifest.json"), options: .atomic)
    let manifestSHA = ContentHasher.sha256Hex(manifestData)

    let inventoryEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: outputDirectory
    )
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(
      packageRoot: outputDirectory,
      entries: inventoryEntries
    )
    let packageClosureHash = try SpatialPackageClosureVerifier.inventoryClosureHash(
      entries: inventoryEntries
    )
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": packageClosureHash,
      "entries": inventoryEntries,
    ]
    try writeJSON(inventory, to: outputDirectory.appendingPathComponent("package_inventory.json"))

    try SpatialPackageClosureVerifier.verifyDevicePayload(packageRoot: outputDirectory, manifestArtifacts: artifacts)
    // Payload-content digest: manifest identity + artifact descriptors only
    // (sidecar/metadata file bytes are intentionally out of scope).
    let packageHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outputDirectory)

    return SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: manifestSHA,
      packageClosureSHA256: packageClosureHash
    )
  }

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    try CanonicalJSON.data(object).write(to: url, options: .atomic)
  }

  private func writePayload<Payload>(
    stream: String,
    adapterID: String,
    samples: [SpatialSampleEnvelope<Payload>],
    root: URL,
    artifacts: inout [SpatialArtifactDescriptor],
    sampleIndex: inout [[String: Any]],
    bytesOf: (Payload) -> Data
  ) throws {
    try SpatialStreamID.validate(stream)
    let dir = root.appendingPathComponent(stream, isDirectory: true)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    for (idx, sample) in samples.enumerated() {
      let schemaKey = "\(sample.schemaID)@\(sample.schemaVersion)"
      guard SpatialEvidenceManifest.supportedSchemas.contains(schemaKey) else {
        throw SpatialEvidenceError.unsupportedSchema(id: sample.schemaID, version: sample.schemaVersion)
      }
      let fileName = String(format: "%04d.bin", idx)
      let rel = "payload/\(stream)/\(fileName)"
      let data = bytesOf(sample.payload)
      try data.write(to: dir.appendingPathComponent(fileName), options: .atomic)
      let sha = ContentHasher.sha256Hex(data)
      artifacts.append(
        SpatialArtifactDescriptor(
          relativePath: rel,
          byteLength: data.count,
          sha256: sha,
          mediaType: sample.mediaType,
          schemaID: sample.schemaID,
          schemaVersion: sample.schemaVersion,
          sampleID: sample.sampleID,
          streamID: stream,
          adapterID: adapterID
        )
      )
      sampleIndex.append([
        "sample_id": sample.sampleID,
        "sequence_index": sample.sequenceIndex,
        "acquisition_timestamp_ns": sample.acquisitionTimestampNs,
        "clock_domain": sample.clockDomain.rawValue,
        "coordinate_frame_id": sample.coordinateFrameID,
        "relative_path": rel,
        "stream_id": stream,
        "adapter_id": adapterID,
      ])
    }
  }
}

extension FixturePosePackageBuilder {
  /// Canonical Sprint 3.2 primary fixture frames (camera + pose only — no IMU).
  public static func defaultFrames(authority: String = "TEST_FIXTURE") -> [CoordinateFrameDescriptor] {
    [
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAMERA_OPTICAL",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "opencv",
        clockDomain: .monotonicUptime,
        authority: authority
      ),
      CoordinateFrameDescriptor(
        frameID: "FRAME_AR_SESSION_WORLD",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "arkit",
        clockDomain: .arkitFrame,
        authority: authority
      ),
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAPTURE_SESSION_ROOT",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "n/a",
        clockDomain: .monotonicUptime,
        authority: authority
      ),
    ]
  }

  /// Graph-only negative-test frames that include IMU (not used by primary package seal defaults).
  public static func graphTestFramesIncludingIMU(authority: String = "TEST_FIXTURE") -> [CoordinateFrameDescriptor] {
    defaultFrames(authority: authority) + [
      CoordinateFrameDescriptor(
        frameID: "FRAME_DEVICE_IMU",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "n/a",
        clockDomain: .coreMotion,
        authority: authority
      ),
    ]
  }

  public static func defaultIdentityMatrix() -> [Double] {
    HomogeneousMatrix4x4.identity()
  }

  public static func defaultTransformEdges(authority: String = "TEST_FIXTURE") -> [TransformEdge] {
    let m = defaultIdentityMatrix()
    return [
      TransformEdge(
        transformID: "xform-ar-to-root-000001",
        fromFrameID: "FRAME_AR_SESSION_WORLD",
        toFrameID: "FRAME_CAPTURE_SESSION_ROOT",
        frameEpochID: "epoch-fixture-1",
        sessionRunID: "run-fixture-1",
        worldOriginRevision: 1,
        timestampNanoseconds: 0,
        clockDomain: .arkitFrame,
        matrix: m,
        authority: authority,
        sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
      ),
      TransformEdge(
        transformID: "xform-camera-to-ar-000001",
        fromFrameID: "FRAME_CAMERA_OPTICAL",
        toFrameID: "FRAME_AR_SESSION_WORLD",
        frameEpochID: "epoch-fixture-1",
        sessionRunID: "run-fixture-1",
        worldOriginRevision: 1,
        timestampNanoseconds: 0,
        clockDomain: .arkitFrame,
        matrix: m,
        authority: authority,
        sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
      ),
    ]
  }

  public static func defaultClockCorrelations(authority: String = "TEST_FIXTURE") -> [ClockCorrelation] {
    [
      ClockCorrelation(
        correlationID: "fixture-identity-monotonic-uptime",
        sourceDomain: .monotonicUptime,
        destinationDomain: .monotonicUptime,
        offsetNanoseconds: 0,
        authority: authority,
        method: "domain_identity"
      ),
      ClockCorrelation(
        correlationID: "fixture-identity-arkit-frame",
        sourceDomain: .arkitFrame,
        destinationDomain: .arkitFrame,
        offsetNanoseconds: 0,
        authority: authority,
        method: "domain_identity"
      ),
      ClockCorrelation(
        correlationID: monotonicToArkitCorrelationID,
        sourceDomain: .monotonicUptime,
        destinationDomain: .arkitFrame,
        offsetNanoseconds: 0,
        authority: authority,
        method: "fixture_explicit_cross_domain",
        validFromNanoseconds: 0,
        validUntilNanoseconds: 10_000_000_000
      ),
    ]
  }

  /// Builds 1:1 camera↔pose associations bound to `fixture-monotonic-to-arkit-000001`.
  public static func defaultAssociations(
    camera: [SpatialSampleEnvelope<CameraSample>],
    pose: [SpatialSampleEnvelope<PoseSample>],
    correlations: [ClockCorrelation] = defaultClockCorrelations()
  ) throws -> [PoseAssociationRecord] {
    let clockValidator = ClockCorrelationValidator(correlations: correlations)
    let corr = try clockValidator.requireByID(monotonicToArkitCorrelationID)
    let n = min(camera.count, pose.count)
    return try (0..<n).map { i in
      try PoseAssociationValidator.makeAssociation(
        associationID: "assoc-\(i)",
        camera: camera[i],
        pose: pose[i],
        correlation: corr
      )
    }
  }
}
