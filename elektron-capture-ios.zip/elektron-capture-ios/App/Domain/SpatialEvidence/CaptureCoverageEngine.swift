import Foundation

/// Deterministic coverage engine. Policy satisfaction ≠ geometric completeness.
public struct CaptureCoverageEngine: Sendable {
  public static let algorithmIdentifier = "capture-coverage-engine-v1"
  public static let algorithmVersion = "1.0.0-phase3-fixture"

  public var policy: CoveragePolicy
  public var expectedSessionID: String
  public var expectedFrameEpochID: String
  public var expectedSessionRunID: String
  public var knownEvidenceIDs: Set<String>

  public init(
    policy: CoveragePolicy = .fixtureDefault(),
    expectedSessionID: String,
    expectedFrameEpochID: String,
    expectedSessionRunID: String,
    knownEvidenceIDs: Set<String> = []
  ) {
    self.policy = policy
    self.expectedSessionID = expectedSessionID
    self.expectedFrameEpochID = expectedFrameEpochID
    self.expectedSessionRunID = expectedSessionRunID
    self.knownEvidenceIDs = knownEvidenceIDs
  }

  public mutating func ingest(
    _ observations: [CoverageObservation]
  ) throws -> (map: CoverageMap, summary: CoverageSummary, accepted: [CoverageObservation]) {
    var accepted: [CoverageObservation] = []
    var seenIDs = Set<String>()
    var byRegion: [CoverageRegionID: [CoverageObservation]] = [:]

    for obs in observations.sorted(by: { lhs, rhs in
      if lhs.observationTimestampNanoseconds != rhs.observationTimestampNanoseconds {
        return lhs.observationTimestampNanoseconds < rhs.observationTimestampNanoseconds
      }
      return lhs.coverageObservationID < rhs.coverageObservationID
    }) {
      guard CoverageRegionID(rawValue: obs.regionID.rawValue) != nil else {
        throw SpatialEvidenceError.unknownCoverageRegion(obs.regionID.rawValue)
      }
      guard obs.captureSessionID == expectedSessionID else {
        throw SpatialEvidenceError.coverageCrossSessionRejected(obs.coverageObservationID)
      }
      if obs.frameEpochID != expectedFrameEpochID {
        throw SpatialEvidenceError.coverageCrossEpochRejected(obs.coverageObservationID)
      }
      if obs.sessionRunID != expectedSessionRunID {
        throw SpatialEvidenceError.coverageCrossEpochRejected(obs.coverageObservationID)
      }
      let refs = obs.cameraSampleIDs + obs.poseSampleIDs + obs.depthSampleIDs
      guard !refs.isEmpty else {
        throw SpatialEvidenceError.coverageMissingEvidenceReference(obs.coverageObservationID)
      }
      if !knownEvidenceIDs.isEmpty {
        for id in refs where !knownEvidenceIDs.contains(id) {
          throw SpatialEvidenceError.coverageUnknownEvidenceReference(id)
        }
      }
      // Duplicate observation IDs or identical camera-set for same region/viewpoint are ignored.
      let fingerprint = [
        obs.regionID.rawValue,
        obs.viewpointClass.rawValue,
        obs.cameraSampleIDs.sorted().joined(separator: ","),
      ].joined(separator: "|")
      if seenIDs.contains(obs.coverageObservationID) || seenIDs.contains(fingerprint) {
        continue
      }
      seenIDs.insert(obs.coverageObservationID)
      seenIDs.insert(fingerprint)
      accepted.append(obs)
      byRegion[obs.regionID, default: []].append(obs)
    }

    var cells: [CoverageCell] = []
    var gaps: [CoverageGap] = []
    var requiredSatisfied: [String] = []
    var requiredMissing: [String] = []
    var optionalObserved: [String] = []
    var optionalMissing: [String] = []

    let allRegions = Set(policy.requiredRegions + policy.optionalRegions)
    for region in allRegions.sorted(by: { $0.rawValue < $1.rawValue }) {
      let obsList = byRegion[region] ?? []
      let viewpoints = Array(Set(obsList.map(\.viewpointClass))).sorted { $0.rawValue < $1.rawValue }
      let maxOverlap = obsList.map(\.overlapRatio).max() ?? 0
      let required = policy.requiredRegions.contains(region)
      let classification = classify(
        count: obsList.count,
        viewpoints: viewpoints.count,
        overlap: maxOverlap,
        required: required
      )
      cells.append(
        CoverageCell(
          cellID: "CELL-\(region.rawValue)",
          regionID: region,
          observationCount: obsList.count,
          viewpointClasses: viewpoints,
          classification: classification
        )
      )
      let satisfied = classification == .policyRequirementSatisfied || classification == .observed
      if required {
        if satisfied {
          requiredSatisfied.append(region.rawValue)
        } else {
          requiredMissing.append(region.rawValue)
          gaps.append(
            CoverageGap(
              gapID: "GAP-\(region.rawValue)",
              regionID: region,
              reason: classification == .unobserved ? "unobserved" : "insufficient_observations_or_viewpoint_diversity",
              required: true
            )
          )
        }
      } else {
        if obsList.isEmpty {
          optionalMissing.append(region.rawValue)
        } else {
          optionalObserved.append(region.rawValue)
        }
      }
    }

    let policySatisfied: Bool
    if policy.missingRequiredRegionBlocksCompletion {
      policySatisfied = requiredMissing.isEmpty
    } else {
      policySatisfied = true
    }
    if policy.optionalRegionMissingBlocksCompletion && !optionalMissing.isEmpty {
      // explicit optional-block mode (default false)
    }

    let map = CoverageMap(
      mapID: "CMAP-\(expectedSessionID)",
      captureSessionID: expectedSessionID,
      cells: cells.sorted { $0.cellID < $1.cellID },
      gaps: gaps.sorted { $0.gapID < $1.gapID }
    )
    let summary = CoverageSummary(
      summaryID: "CSUM-\(expectedSessionID)",
      captureSessionID: expectedSessionID,
      coveragePolicyID: policy.coveragePolicyID,
      requiredSatisfied: requiredSatisfied,
      requiredMissing: requiredMissing,
      optionalObserved: optionalObserved,
      optionalMissing: optionalMissing,
      policySatisfied: policySatisfied && (policy.optionalRegionMissingBlocksCompletion ? optionalMissing.isEmpty : true),
      evidenceOriginAuthority: .testFixture,
      guidanceAuthority: .guidanceEstimate
    )
    return (map, summary, accepted)
  }

  private func classify(
    count: Int,
    viewpoints: Int,
    overlap: Double,
    required: Bool
  ) -> CoverageClassification {
    if count == 0 { return .unobserved }
    if count < policy.minimumObservationsPerRequiredRegion {
      return .partiallyObserved
    }
    if viewpoints < policy.minimumViewpointDiversity {
      return .additionalCaptureRecommended
    }
    if overlap < policy.minimumOverlapRatio {
      return .additionalCaptureRecommended
    }
    return required ? .policyRequirementSatisfied : .observed
  }
}
