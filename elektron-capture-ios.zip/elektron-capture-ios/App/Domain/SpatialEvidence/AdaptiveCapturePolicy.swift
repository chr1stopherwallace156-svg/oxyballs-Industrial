import Foundation

// MARK: - Thermal / resource adaptive policy (Sprint 3.7)

public enum ThermalState: String, Codable, Sendable, Equatable {
  case nominal = "NOMINAL"
  case fair = "FAIR"
  case serious = "SERIOUS"
  case critical = "CRITICAL"
}

public enum MemoryPressureState: String, Codable, Sendable, Equatable {
  case normal = "NORMAL"
  case warning = "WARNING"
  case critical = "CRITICAL"
}

public enum StoragePressureState: String, Codable, Sendable, Equatable {
  case normal = "NORMAL"
  case warning = "WARNING"
  case critical = "CRITICAL"
}

public struct RuntimeResourceState: Codable, Sendable, Equatable {
  public var thermal: ThermalState
  public var memory: MemoryPressureState
  public var storage: StoragePressureState
  public var optionalDepthLoad: Double
  public var timestampNanoseconds: UInt64

  public func dictionary() -> [String: Any] {
    [
      "thermal": thermal.rawValue,
      "memory": memory.rawValue,
      "storage": storage.rawValue,
      "optional_depth_load": optionalDepthLoad,
      "timestamp_nanoseconds": timestampNanoseconds,
    ]
  }
}

public enum StreamPriority: Int, Codable, Sendable, Equatable, Comparable {
  case packageAndJournalIntegrity = 1
  case requiredCamera = 2
  case requiredClockAndPose = 3
  case requiredMotion = 4
  case optionalDepth = 5
  case derivedQualityAnalysis = 6
  case previewRendering = 7

  public static func < (lhs: StreamPriority, rhs: StreamPriority) -> Bool {
    lhs.rawValue < rhs.rawValue
  }
}

public enum AdaptivePolicyDecisionCode: String, Codable, Sendable, Equatable {
  case reduceOptionalDepthRate = "REDUCE_OPTIONAL_DEPTH_RATE"
  case reduceQualityAnalysisRate = "REDUCE_QUALITY_ANALYSIS_RATE"
  case reducePreviewRate = "REDUCE_PREVIEW_RATE"
  case suspendOptionalStream = "SUSPEND_OPTIONAL_STREAM"
  case pauseCapture = "PAUSE_CAPTURE"
  case requireOperatorIntervention = "REQUIRE_OPERATOR_INTERVENTION"
  case failRequiredPolicy = "FAIL_REQUIRED_POLICY"
  case noChange = "NO_CHANGE"
}

public struct StreamRateAdjustment: Codable, Sendable, Equatable {
  public var streamOrSubsystem: String
  public var priority: StreamPriority
  public var previousRateHz: Double
  public var newRateHz: Double
  public var decision: AdaptivePolicyDecisionCode

  public func dictionary() -> [String: Any] {
    [
      "stream_or_subsystem": streamOrSubsystem,
      "priority": priority.rawValue,
      "previous_rate_hz": previousRateHz,
      "new_rate_hz": newRateHz,
      "decision": decision.rawValue,
    ]
  }
}

public struct AdaptivePolicyDecision: Codable, Sendable, Equatable {
  public var decisionID: String
  public var timestampNanoseconds: UInt64
  public var resourceState: RuntimeResourceState
  public var adjustments: [StreamRateAdjustment]
  public var requiredStreamsProtected: Bool
  public var declaredSessionPolicyUnchanged: Bool
  public var note: String

  public func dictionary() -> [String: Any] {
    [
      "decision_id": decisionID,
      "timestamp_nanoseconds": timestampNanoseconds,
      "resource_state": resourceState.dictionary(),
      "adjustments": adjustments.map { $0.dictionary() },
      "required_streams_protected": requiredStreamsProtected,
      "declared_session_policy_unchanged": declaredSessionPolicyUnchanged,
      "note": note,
    ]
  }
}

public struct RuntimeDegradationRecord: Codable, Sendable, Equatable {
  public var recordID: String
  public var decisions: [AdaptivePolicyDecision]

  public func dictionary() -> [String: Any] {
    [
      "record_id": recordID,
      "decisions": decisions.map { $0.dictionary() },
      "schema_id": "RuntimeDegradationRecord",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}

public struct AdaptiveCapturePolicy: Sendable {
  public var depthRateHz: Double
  public var qualityAnalysisRateHz: Double
  public var previewRateHz: Double
  public var cameraRateHz: Double
  public var motionRateHz: Double
  public private(set) var decisions: [AdaptivePolicyDecision] = []

  public init(
    depthRateHz: Double = 15,
    qualityAnalysisRateHz: Double = 5,
    previewRateHz: Double = 30,
    cameraRateHz: Double = 30,
    motionRateHz: Double = 50
  ) {
    self.depthRateHz = depthRateHz
    self.qualityAnalysisRateHz = qualityAnalysisRateHz
    self.previewRateHz = previewRateHz
    self.cameraRateHz = cameraRateHz
    self.motionRateHz = motionRateHz
  }

  /// Priority-ordered adaptation. Never silently changes required stream rates.
  public mutating func evaluate(_ state: RuntimeResourceState) throws -> AdaptivePolicyDecision {
    var adjustments: [StreamRateAdjustment] = []
    let beforeDepth = depthRateHz
    let beforeQuality = qualityAnalysisRateHz
    let beforePreview = previewRateHz
    let beforeCamera = cameraRateHz
    let beforeMotion = motionRateHz

    // Lower priority subsystems first when pressure rises.
    if state.thermal == .fair || state.optionalDepthLoad > 0.7 {
      if qualityAnalysisRateHz > 1 {
        qualityAnalysisRateHz = max(1, qualityAnalysisRateHz * 0.5)
        adjustments.append(
          StreamRateAdjustment(
            streamOrSubsystem: "quality_analysis",
            priority: .derivedQualityAnalysis,
            previousRateHz: beforeQuality,
            newRateHz: qualityAnalysisRateHz,
            decision: .reduceQualityAnalysisRate
          )
        )
      }
    }
    if state.thermal == .serious || state.thermal == .critical || state.optionalDepthLoad > 0.85 {
      if depthRateHz > 0 {
        let newDepth = state.thermal == .critical ? 0 : max(1, depthRateHz * 0.5)
        depthRateHz = newDepth
        adjustments.append(
          StreamRateAdjustment(
            streamOrSubsystem: "depth",
            priority: .optionalDepth,
            previousRateHz: beforeDepth,
            newRateHz: depthRateHz,
            decision: newDepth == 0 ? .suspendOptionalStream : .reduceOptionalDepthRate
          )
        )
      }
      if previewRateHz > 5 {
        previewRateHz = max(5, previewRateHz * 0.5)
        adjustments.append(
          StreamRateAdjustment(
            streamOrSubsystem: "preview",
            priority: .previewRendering,
            previousRateHz: beforePreview,
            newRateHz: previewRateHz,
            decision: .reducePreviewRate
          )
        )
      }
    }

    // Required streams must remain protected.
    if cameraRateHz != beforeCamera || motionRateHz != beforeMotion {
      throw SpatialEvidenceError.silentStreamDegradationRejected("required_stream_rate_mutated")
    }

    var decisionCodeNote = "adaptive_change_recorded"
    if state.thermal == .critical && state.storage == .critical {
      adjustments.append(
        StreamRateAdjustment(
          streamOrSubsystem: "capture",
          priority: .packageAndJournalIntegrity,
          previousRateHz: 1,
          newRateHz: 0,
          decision: .requireOperatorIntervention
        )
      )
      decisionCodeNote = "operator_intervention_required"
    }

    if adjustments.isEmpty {
      adjustments.append(
        StreamRateAdjustment(
          streamOrSubsystem: "none",
          priority: .packageAndJournalIntegrity,
          previousRateHz: 0,
          newRateHz: 0,
          decision: .noChange
        )
      )
    }

    // Deterministic ordering by priority then subsystem name
    adjustments.sort {
      if $0.priority != $1.priority { return $0.priority < $1.priority }
      return $0.streamOrSubsystem < $1.streamOrSubsystem
    }

    let decision = AdaptivePolicyDecision(
      decisionID: "ADP-\(String(format: "%04d", decisions.count + 1))",
      timestampNanoseconds: state.timestampNanoseconds,
      resourceState: state,
      adjustments: adjustments,
      requiredStreamsProtected: true,
      declaredSessionPolicyUnchanged: true,
      note: decisionCodeNote
    )
    decisions.append(decision)
    return decision
  }
}

// MARK: - Performance telemetry

public struct BufferLifecycleRecord: Codable, Sendable, Equatable {
  public var recordID: String
  public var sampleID: String
  public var bufferOrigin: String
  public var pixelFormat: String
  public var queuedBytes: Int
  public var queueDepth: Int

  public func dictionary() -> [String: Any] {
    [
      "record_id": recordID,
      "sample_id": sampleID,
      "buffer_origin": bufferOrigin,
      "pixel_format": pixelFormat,
      "queued_bytes": queuedBytes,
      "queue_depth": queueDepth,
    ]
  }
}

public struct CopyAndConversionRecord: Codable, Sendable, Equatable {
  public var recordID: String
  public var sampleID: String
  public var conversionOperations: [String]
  public var estimatedCopyCount: Int
  public var note: String

  public func dictionary() -> [String: Any] {
    [
      "record_id": recordID,
      "sample_id": sampleID,
      "conversion_operations": conversionOperations,
      "estimated_copy_count": estimatedCopyCount,
      "note": note,
    ]
  }
}

public struct EncoderPathRecord: Codable, Sendable, Equatable {
  public var recordID: String
  public var sampleID: String
  public var encodingPath: String

  public func dictionary() -> [String: Any] {
    ["record_id": recordID, "sample_id": sampleID, "encoding_path": encodingPath]
  }
}

public struct FrameDropRecord: Codable, Sendable, Equatable {
  public var recordID: String
  public var streamID: String
  public var droppedCount: UInt64
  public var reason: String

  public func dictionary() -> [String: Any] {
    [
      "record_id": recordID,
      "stream_id": streamID,
      "dropped_count": droppedCount,
      "reason": reason,
    ]
  }
}

public struct SensorPerformanceTelemetry: Codable, Sendable, Equatable {
  public var incomingSampleRate: Double
  public var acceptedSampleRate: Double
  public var droppedSampleCount: UInt64
  public var queueDepth: Int
  public var queuedBytes: Int
  public var memoryPressure: MemoryPressureState
  public var storagePressure: StoragePressureState
  public var thermalState: ThermalState
  public var analysisLatencyMs: Double
  public var packageWriteLatencyMs: Double
  public var bufferRecords: [BufferLifecycleRecord]
  public var copyRecords: [CopyAndConversionRecord]
  public var encoderRecords: [EncoderPathRecord]
  public var dropRecords: [FrameDropRecord]

  public func dictionary() -> [String: Any] {
    [
      "incoming_sample_rate": incomingSampleRate,
      "accepted_sample_rate": acceptedSampleRate,
      "dropped_sample_count": droppedSampleCount,
      "queue_depth": queueDepth,
      "queued_bytes": queuedBytes,
      "memory_pressure": memoryPressure.rawValue,
      "storage_pressure": storagePressure.rawValue,
      "thermal_state": thermalState.rawValue,
      "analysis_latency_ms": analysisLatencyMs,
      "package_write_latency_ms": packageWriteLatencyMs,
      "buffer_lifecycle_records": bufferRecords.map { $0.dictionary() },
      "copy_and_conversion_records": copyRecords.map { $0.dictionary() },
      "encoder_path_records": encoderRecords.map { $0.dictionary() },
      "frame_drop_records": dropRecords.map { $0.dictionary() },
      "schema_id": "SensorPerformanceTelemetry",
      "schema_version": "1.0.0-phase3-fixture",
      "note": "copy_minimization terminology; not absolute zero-copy claim",
    ]
  }
}

public struct RuntimePerformanceSummary: Codable, Sendable, Equatable {
  public var summaryID: String
  public var telemetry: SensorPerformanceTelemetry
  public var degradation: RuntimeDegradationRecord

  public func dictionary() -> [String: Any] {
    [
      "summary_id": summaryID,
      "telemetry": telemetry.dictionary(),
      "degradation": degradation.dictionary(),
      "schema_id": "RuntimePerformanceSummary",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}
