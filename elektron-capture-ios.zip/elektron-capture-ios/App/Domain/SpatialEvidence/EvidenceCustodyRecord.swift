import Foundation

/// Capture-side custody plane — never emits EDTS `PACKAGE_QUARANTINED` (ADR-P3-001).
public enum EvidenceCustodyStatus: String, Codable, Sendable, Equatable {
  case unverified = "UNVERIFIED"
  case verified = "VERIFIED"
  case verificationFailed = "VERIFICATION_FAILED"
  case quarantined = "EVIDENCE_CUSTODY_QUARANTINED"
  case archived = "ARCHIVED"
}

/// Mutable repository state keyed by sealed package content hash.
/// Package bytes MUST remain unchanged across custody transitions (ADR-P3-004).
public struct EvidenceCustodyRecord: Sendable, Equatable {
  public let packageContentSHA256: String
  public let packageID: String
  public let vehicleID: String
  public let captureSessionID: String
  public var status: EvidenceCustodyStatus
  public var revision: Int
  public var reason: String?
  public var decidingAuthority: String

  public init(
    packageContentSHA256: String,
    packageID: String,
    vehicleID: String,
    captureSessionID: String,
    status: EvidenceCustodyStatus = .unverified,
    revision: Int = 0,
    reason: String? = nil,
    decidingAuthority: String = "CAPTURE_CUSTODY_STORE"
  ) {
    self.packageContentSHA256 = packageContentSHA256
    self.packageID = packageID
    self.vehicleID = vehicleID
    self.captureSessionID = captureSessionID
    self.status = status
    self.revision = revision
    self.reason = reason
    self.decidingAuthority = decidingAuthority
  }

  public func asDictionary() -> [String: Any] {
    var d: [String: Any] = [
      "schema_id": "EvidenceCustodyRecord",
      "schema_version": "1.0.0-phase3-synthetic",
      "package_content_sha256": packageContentSHA256,
      "package_id": packageID,
      "vehicle_id": vehicleID,
      "capture_session_id": captureSessionID,
      "status": status.rawValue,
      "revision": revision,
      "deciding_authority": decidingAuthority,
    ]
    if let reason { d["reason"] = reason }
    return d
  }
}

/// Typed Phase 4+ entry handle. Issuance authority: Capture custody store after VERIFIED (ADR-P3-005).
public struct VerifiedSpatialEvidencePackage: Sendable, Equatable {
  public let packageContentSHA256: String
  public let packageID: String
  public let vehicleID: String
  public let captureSessionID: String
  public let custodyRevision: Int
  public let packageRootURL: URL

  public init(
    packageContentSHA256: String,
    packageID: String,
    vehicleID: String,
    captureSessionID: String,
    custodyRevision: Int,
    packageRootURL: URL
  ) {
    self.packageContentSHA256 = packageContentSHA256
    self.packageID = packageID
    self.vehicleID = vehicleID
    self.captureSessionID = captureSessionID
    self.custodyRevision = custodyRevision
    self.packageRootURL = packageRootURL
  }
}

public protocol VerifiedSpatialEvidenceProviding: Sendable {
  func verifiedPackage(packageContentSHA256: String) throws -> VerifiedSpatialEvidencePackage
}

/// In-memory custody repository with S2-004-style OCC (separate revision plane).
public final class EvidenceCustodyStore: @unchecked Sendable, VerifiedSpatialEvidenceProviding {
  private var records: [String: EvidenceCustodyRecord] = [:]
  private var packageRoots: [String: URL] = [:]
  private let lock = NSLock()

  public init() {}

  public func registerSealedPackage(_ package: SpatialEvidencePackage) throws -> EvidenceCustodyRecord {
    lock.lock()
    defer { lock.unlock() }
    let key = package.packageContentSHA256
    if records[key] != nil {
      throw SpatialEvidenceError.packageClosureFailed("custody already registered for \(key)")
    }
    let manifestData = try Data(contentsOf: package.rootURL.appendingPathComponent("manifest.json"))
    if let text = String(data: manifestData, encoding: .utf8),
       text.contains("custody_status") || text.contains("EVIDENCE_CUSTODY") || text.contains("\"custody\"") {
      throw SpatialEvidenceError.packageClosureFailed("manifest must not contain custody fields")
    }
    var record = EvidenceCustodyRecord(
      packageContentSHA256: key,
      packageID: package.manifest.packageID,
      vehicleID: package.manifest.vehicleID,
      captureSessionID: package.manifest.captureSessionID,
      status: .unverified,
      revision: 1
    )
    records[key] = record
    packageRoots[key] = package.rootURL
    _ = record
    return records[key]!
  }

  public func commit(
    packageContentSHA256: String,
    expectedRevision: Int,
    mutate: (inout EvidenceCustodyRecord) throws -> Void
  ) throws -> EvidenceCustodyRecord {
    lock.lock()
    defer { lock.unlock() }
    guard var current = records[packageContentSHA256] else {
      throw SpatialEvidenceError.verifiedHandleUnavailable("no custody record")
    }
    if current.revision != expectedRevision {
      throw SpatialEvidenceError.custodyStaleRevision(current: current.revision, attempted: expectedRevision)
    }
    // Snapshot for side-effect-free reject: mutate a copy first; only assign on success.
    var next = current
    try mutate(&next)
    next.revision = current.revision + 1
    // Forbid EDTS wire code.
    if next.status.rawValue == "PACKAGE_QUARANTINED" {
      throw CaptureError.forbiddenAuthorityClaim("EDTS-owned status: PACKAGE_QUARANTINED")
    }
    records[packageContentSHA256] = next
    return next
  }

  public func verifyClosure(
    packageContentSHA256: String,
    expectedRevision: Int
  ) throws -> EvidenceCustodyRecord {
    let root = try lockedRoot(packageContentSHA256)
    let beforeHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: root)
    guard beforeHash == packageContentSHA256 else {
      return try commit(packageContentSHA256: packageContentSHA256, expectedRevision: expectedRevision) { rec in
        rec.status = .verificationFailed
        rec.reason = "package_hash_drift"
      }
    }
    // Re-load manifest & verify artifacts.
    let manifestData = try Data(contentsOf: root.appendingPathComponent("manifest.json"))
    guard let obj = try JSONSerialization.jsonObject(with: manifestData) as? [String: Any],
          let arts = obj["artifacts"] as? [[String: Any]] else {
      return try commit(packageContentSHA256: packageContentSHA256, expectedRevision: expectedRevision) { rec in
        rec.status = .verificationFailed
        rec.reason = "manifest_unreadable"
      }
    }
    var descriptors: [SpatialArtifactDescriptor] = []
    for a in arts {
      descriptors.append(
        SpatialArtifactDescriptor(
          relativePath: a["relative_path"] as? String ?? "",
          byteLength: a["byte_length"] as? Int ?? -1,
          sha256: a["sha256"] as? String ?? "",
          mediaType: a["media_type"] as? String ?? "",
          schemaID: a["schema_id"] as? String ?? "",
          schemaVersion: a["schema_version"] as? String ?? "",
          sampleID: a["sample_id"] as? String ?? "",
          streamID: a["stream_id"] as? String ?? "",
          adapterID: a["adapter_id"] as? String ?? ""
        )
      )
    }
    let schemaID = obj["schema_id"] as? String ?? ""
    let schemaVersion = obj["schema_version"] as? String ?? ""
    let schemaKey = "\(schemaID)@\(schemaVersion)"
    guard SpatialEvidenceManifest.supportedSchemas.contains(schemaKey) else {
      return try commit(packageContentSHA256: packageContentSHA256, expectedRevision: expectedRevision) { rec in
        rec.status = .verificationFailed
        rec.reason = "unsupported_schema"
      }
    }
    // Build a stub manifest for closure verify.
    let stub = SpatialEvidenceManifest(
      packageID: obj["package_id"] as? String ?? "",
      vehicleID: obj["vehicle_id"] as? String ?? "",
      captureSessionID: obj["capture_session_id"] as? String ?? "",
      pilotID: obj["pilot_id"] as? String,
      createdAtUTC: obj["created_at_utc"] as? String ?? "",
      capability: SpatialCapabilitySnapshot(snapshotID: "reverify", capturedAtUTC: "", streams: []),
      frames: [],
      clockCorrelations: [],
      artifacts: descriptors,
      sampleIndex: []
    )
    do {
      try SpatialPackageClosureVerifier.verify(packageRoot: root, manifest: stub)
    } catch {
      return try commit(packageContentSHA256: packageContentSHA256, expectedRevision: expectedRevision) { rec in
        rec.status = .verificationFailed
        rec.reason = String(describing: error)
      }
    }
    let afterHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: root)
    guard afterHash == packageContentSHA256 else {
      throw SpatialEvidenceError.packageClosureFailed("custody verify mutated package bytes")
    }
    return try commit(packageContentSHA256: packageContentSHA256, expectedRevision: expectedRevision) { rec in
      rec.status = .verified
      rec.reason = nil
    }
  }

  public func archive(packageContentSHA256: String, expectedRevision: Int) throws -> EvidenceCustodyRecord {
    try commit(packageContentSHA256: packageContentSHA256, expectedRevision: expectedRevision) { rec in
      guard rec.status == .verified else {
        throw SpatialEvidenceError.invalidLifecycleTransition(from: rec.status.rawValue, to: EvidenceCustodyStatus.archived.rawValue)
      }
      rec.status = .archived
    }
  }

  public func verifiedPackage(packageContentSHA256: String) throws -> VerifiedSpatialEvidencePackage {
    lock.lock()
    defer { lock.unlock() }
    guard let rec = records[packageContentSHA256], let root = packageRoots[packageContentSHA256] else {
      throw SpatialEvidenceError.verifiedHandleUnavailable("unknown package")
    }
    guard rec.status == .verified || rec.status == .archived else {
      throw SpatialEvidenceError.verifiedHandleUnavailable("custody status \(rec.status.rawValue)")
    }
    return VerifiedSpatialEvidencePackage(
      packageContentSHA256: rec.packageContentSHA256,
      packageID: rec.packageID,
      vehicleID: rec.vehicleID,
      captureSessionID: rec.captureSessionID,
      custodyRevision: rec.revision,
      packageRootURL: root
    )
  }

  public func record(packageContentSHA256: String) -> EvidenceCustodyRecord? {
    lock.lock()
    defer { lock.unlock() }
    return records[packageContentSHA256]
  }

  private func lockedRoot(_ key: String) throws -> URL {
    lock.lock()
    defer { lock.unlock() }
    guard let root = packageRoots[key] else {
      throw SpatialEvidenceError.verifiedHandleUnavailable("no package root")
    }
    return root
  }
}
