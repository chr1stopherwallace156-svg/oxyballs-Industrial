import Foundation

/// Builds RGB+motion-only **fixture** packages (no synthetic pose/depth).
/// Defaults use `SPKG-FIXTURE-*` identities and `TEST_FIXTURE` authority.
/// Physical `SPKG-DEVICE-*` packages are reserved for Sprint 3.6 hardware validation.
/// Layout:
/// ```
/// SPKG-FIXTURE-RGBMOTION-…/
///   manifest.json
///   payload/camera|motion/
///   sample_index.json
///   capability_snapshot.json
///   coordinate_frames.json
///   clock_correlation.json
///   package_inventory.json
/// ```
public struct DeviceRGBMotionPackageBuilder: Sendable {
  public init() {}

  public func seal(
    camera: [SpatialSampleEnvelope<CameraSample>],
    motion: [SpatialSampleEnvelope<MotionSample>],
    cameraCapability: SpatialStreamCapability,
    motionCapability: SpatialStreamCapability,
    frames: [CoordinateFrameDescriptor],
    clockCorrelations: [ClockCorrelation],
    outputDirectory: URL,
    vehicleID: String = "VEH-000001",
    pilotID: String = "PILOT-000001",
    captureSessionID: String = "SESS-FIXTURE-RGBMOTION-000001",
    packageID: String = "SPKG-FIXTURE-RGBMOTION-000001",
    createdAtUTC: String = "2026-08-03T00:00:00Z"
  ) throws -> SpatialEvidencePackage {
    precondition(!camera.isEmpty, "fixture RGB package requires observed camera samples")
    precondition(!motion.isEmpty, "fixture RGB/motion package requires observed motion samples")
    precondition(
      !packageID.hasPrefix("SPKG-DEVICE-"),
      "SPKG-DEVICE-* reserved for Sprint 3.6 physical packages; use SPKG-FIXTURE-*"
    )

    try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
    let payloadRoot = outputDirectory.appendingPathComponent("payload", isDirectory: true)
    try FileManager.default.createDirectory(at: payloadRoot, withIntermediateDirectories: true)

    var camCap = cameraCapability
    var motCap = motionCapability
    try camCap.freeze(outcome: .acquired)
    try motCap.freeze(outcome: .acquired)

    // Explicitly NOT_REQUESTED pose/depth — never synthesize.
    var poseCap = SpatialStreamCapability(
      streamID: SpatialStreamID.pose,
      adapterID: "none",
      sensorKind: "pose",
      declared: false
    )
    var depthCap = SpatialStreamCapability(
      streamID: SpatialStreamID.depth,
      adapterID: "none",
      sensorKind: "depth",
      declared: false
    )
    try poseCap.freeze(outcome: .notRequested)
    try depthCap.freeze(outcome: .notRequested)

    let capability = SpatialCapabilitySnapshot(
      snapshotID: "cap-fixture-rgbmotion-1",
      capturedAtUTC: createdAtUTC,
      streams: [camCap, motCap, poseCap, depthCap],
      schemaVersion: SpatialCapabilitySnapshot.fixtureSchemaVersion
    )

    var artifacts: [SpatialArtifactDescriptor] = []
    var sampleIndex: [[String: Any]] = []

    try writePayload(
      stream: SpatialStreamID.camera,
      adapterID: camCap.adapterID,
      samples: camera,
      root: payloadRoot,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }
    try writePayload(
      stream: SpatialStreamID.motion,
      adapterID: motCap.adapterID,
      samples: motion,
      root: payloadRoot,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }

    sampleIndex.sort {
      (($0["relative_path"] as? String) ?? "") < (($1["relative_path"] as? String) ?? "")
    }

    // Split sidecars (hash-bound; no custody).
    try writeJSON(capability.asDictionary(), to: outputDirectory.appendingPathComponent("capability_snapshot.json"))
    try writeJSON(
      ["frames": frames.sorted { $0.frameID < $1.frameID }.map { $0.asDictionary() }],
      to: outputDirectory.appendingPathComponent("coordinate_frames.json")
    )
    try writeJSON(
      [
        "correlations": clockCorrelations
          .sorted { $0.sourceDomain.rawValue < $1.sourceDomain.rawValue }
          .map { $0.asDictionary() },
        "note": "Camera (avfoundation_capture) and motion (core_motion) clocks are NOT assumed identical without an explicit correlation record.",
      ],
      to: outputDirectory.appendingPathComponent("clock_correlation.json")
    )
    try writeJSON(["samples": sampleIndex], to: outputDirectory.appendingPathComponent("sample_index.json"))

    let manifest = SpatialEvidenceManifest(
      packageID: packageID,
      vehicleID: vehicleID,
      captureSessionID: captureSessionID,
      pilotID: pilotID,
      createdAtUTC: createdAtUTC,
      capability: capability,
      frames: frames,
      clockCorrelations: clockCorrelations,
      artifacts: artifacts,
      sampleIndex: sampleIndex
    )
    // Device schema identity in top-level manifest fields via asDictionary uses synthetic schema id;
    // overlay device schema version for this builder.
    var manifestDict = manifest.asDictionary()
    manifestDict["schema_id"] = "SpatialEvidenceManifest"
    manifestDict["schema_version"] = "1.0.0-phase3-fixture"
    manifestDict["package_layout"] = "fixture_rgb_motion_v1"
    manifestDict["host_claim"] = "NO_PHYSICAL_DEVICE_EXECUTION"
    manifestDict["implementation_state"] = "SOURCE_IMPLEMENTED"
    manifestDict["validation_state"] = "LINUX_FIXTURE_VALIDATED"
    // Forbid depth/pose artifact paths.
    if artifacts.contains(where: { $0.streamID == "depth" || $0.streamID == "pose" }) {
      throw SpatialEvidenceError.packageClosureFailed("fixture RGB/motion package must not include depth/pose artifacts")
    }

    let manifestData = try CanonicalJSON.data(manifestDict)
    try manifestData.write(to: outputDirectory.appendingPathComponent("manifest.json"), options: .atomic)
    let manifestSHA = ContentHasher.sha256Hex(manifestData)

    // Inventory of all package files except inventory itself.
    let inventoryEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: outputDirectory
    )
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(
      packageRoot: outputDirectory,
      entries: inventoryEntries
    )
    let packageClosureHash = try SpatialPackageClosureVerifier.inventoryClosureHash(
      entries: inventoryEntries
    )
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": packageClosureHash,
      "entries": inventoryEntries,
    ]
    try writeJSON(inventory, to: outputDirectory.appendingPathComponent("package_inventory.json"))

    // Closure over payload artifacts declared in manifest.
    try SpatialPackageClosureVerifier.verifyDevicePayload(packageRoot: outputDirectory, manifestArtifacts: artifacts)

    // Hash from on-disk manifest so custody verify matches device schema overlay.
    // This is the payload-content digest (artifact descriptors + identity), not full inventory.
    let packageHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outputDirectory)

    return SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: manifestSHA,
      packageClosureSHA256: packageClosureHash
    )
  }

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    try CanonicalJSON.data(object).write(to: url, options: .atomic)
  }

  private func writePayload<Payload>(
    stream: String,
    adapterID: String,
    samples: [SpatialSampleEnvelope<Payload>],
    root: URL,
    artifacts: inout [SpatialArtifactDescriptor],
    sampleIndex: inout [[String: Any]],
    bytesOf: (Payload) -> Data
  ) throws {
    try SpatialStreamID.validate(stream)
    let dir = root.appendingPathComponent(stream, isDirectory: true)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    for (idx, sample) in samples.enumerated() {
      let schemaKey = "\(sample.schemaID)@\(sample.schemaVersion)"
      guard SpatialEvidenceManifest.supportedSchemas.contains(schemaKey) else {
        throw SpatialEvidenceError.unsupportedSchema(id: sample.schemaID, version: sample.schemaVersion)
      }
      let fileName = String(format: "%04d.bin", idx)
      let rel = "payload/\(stream)/\(fileName)"
      let data = bytesOf(sample.payload)
      try data.write(to: dir.appendingPathComponent(fileName), options: .atomic)
      let sha = ContentHasher.sha256Hex(data)
      artifacts.append(
        SpatialArtifactDescriptor(
          relativePath: rel,
          byteLength: data.count,
          sha256: sha,
          mediaType: sample.mediaType,
          schemaID: sample.schemaID,
          schemaVersion: sample.schemaVersion,
          sampleID: sample.sampleID,
          streamID: stream,
          adapterID: adapterID
        )
      )
      sampleIndex.append([
        "sample_id": sample.sampleID,
        "sequence_index": sample.sequenceIndex,
        "acquisition_timestamp_ns": sample.acquisitionTimestampNs,
        "clock_domain": sample.clockDomain.rawValue,
        "coordinate_frame_id": sample.coordinateFrameID,
        "relative_path": rel,
        "stream_id": stream,
        "adapter_id": adapterID,
      ])
    }
  }
}

extension SpatialPackageClosureVerifier {
  /// Device layout uses payload/ instead of artifacts/.
  public static func verifyDevicePayload(
    packageRoot: URL,
    manifestArtifacts: [SpatialArtifactDescriptor]
  ) throws {
    let fm = FileManager.default
    var seen = Set<String>()
    for art in manifestArtifacts {
      if !seen.insert(art.relativePath).inserted {
        throw SpatialEvidenceError.duplicateArtifact(path: art.relativePath)
      }
      let url = packageRoot.appendingPathComponent(art.relativePath)
      guard fm.fileExists(atPath: url.path) else {
        throw SpatialEvidenceError.missingArtifact(path: art.relativePath)
      }
      let data = try Data(contentsOf: url)
      if data.count != art.byteLength {
        throw SpatialEvidenceError.byteLengthMismatch(
          path: art.relativePath,
          expected: art.byteLength,
          actual: data.count
        )
      }
      let sha = ContentHasher.sha256Hex(data)
      if sha != art.sha256 {
        throw SpatialEvidenceError.sha256Mismatch(
          path: art.relativePath,
          expected: art.sha256,
          actual: sha
        )
      }
    }
    let payloadRoot = packageRoot.appendingPathComponent("payload", isDirectory: true)
    if fm.fileExists(atPath: payloadRoot.path) {
      let enumerator = fm.enumerator(at: payloadRoot, includingPropertiesForKeys: [.isRegularFileKey])
      while let item = enumerator?.nextObject() as? URL {
        var isDir: ObjCBool = false
        if fm.fileExists(atPath: item.path, isDirectory: &isDir), isDir.boolValue { continue }
        let rel = "payload/" + item.path.replacingOccurrences(of: payloadRoot.path + "/", with: "")
        if !seen.contains(rel) {
          throw SpatialEvidenceError.orphanArtifact(path: rel)
        }
      }
    }
  }
}
