import Foundation

// MARK: - Raw / derived evidence separation + redaction contracts

public enum RedactionDetectionKind: String, Codable, Sendable, Equatable {
  case face = "FACE"
  case licensePlate = "LICENSE_PLATE"
  case person = "PERSON"
  case sensitiveBackgroundRegion = "SENSITIVE_BACKGROUND_REGION"
  case operatorDefinedRegion = "OPERATOR_DEFINED_REGION"
  case customPolicyRegion = "CUSTOM_POLICY_REGION"
}

public enum RedactionOperationKind: String, Codable, Sendable, Equatable {
  case blur = "BLUR"
  case pixelate = "PIXELATE"
  case solidMask = "SOLID_MASK"
  case cropExclusion = "CROP_EXCLUSION"
  case omitArtifact = "OMIT_ARTIFACT"
}

public struct RedactionConfidence: Codable, Sendable, Equatable {
  public var score: Double
  public var authority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    ["score": score, "authority": authority.rawValue]
  }
}

public struct RedactionRegion: Codable, Sendable, Equatable {
  public var regionID: String
  public var x: Double
  public var y: Double
  public var width: Double
  public var height: Double
  public var coordinateSpace: String

  public func dictionary() -> [String: Any] {
    [
      "region_id": regionID,
      "x": x,
      "y": y,
      "width": width,
      "height": height,
      "coordinate_space": coordinateSpace,
    ]
  }
}

public struct RedactionDetection: Codable, Sendable, Equatable {
  public var detectionID: String
  public var kind: RedactionDetectionKind
  public var region: RedactionRegion
  public var confidence: RedactionConfidence

  public func dictionary() -> [String: Any] {
    [
      "detection_id": detectionID,
      "kind": kind.rawValue,
      "region": region.dictionary(),
      "confidence": confidence.dictionary(),
    ]
  }
}

public struct RedactionOperation: Codable, Sendable, Equatable {
  public var operationID: String
  public var kind: RedactionOperationKind
  public var detectionID: String
  public var algorithmID: String
  public var algorithmVersion: String

  public func dictionary() -> [String: Any] {
    [
      "operation_id": operationID,
      "kind": kind.rawValue,
      "detection_id": detectionID,
      "algorithm_id": algorithmID,
      "algorithm_version": algorithmVersion,
    ]
  }
}

public struct RedactionVerificationResult: Codable, Sendable, Equatable {
  public var ok: Bool
  public var missingRequiredKinds: [RedactionDetectionKind]
  public var note: String

  public func dictionary() -> [String: Any] {
    [
      "ok": ok,
      "missing_required_kinds": missingRequiredKinds.map(\.rawValue),
      "note": note,
    ]
  }
}

public struct RestrictedRawEvidenceRecord: Codable, Sendable, Equatable {
  public var artifactID: String
  public var relativePath: String
  public var sha256: String
  public var byteLength: Int
  public var retentionClass: EvidenceRetentionClass
  public var accessClass: EvidenceAccessClass
  public var evidenceOriginAuthority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    [
      "artifact_id": artifactID,
      "relative_path": relativePath,
      "sha256": sha256,
      "byte_length": byteLength,
      "retention_class": retentionClass.rawValue,
      "access_class": accessClass.rawValue,
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
    ]
  }
}

public struct RedactedEvidenceRecord: Codable, Sendable, Equatable {
  public var artifactID: String
  public var relativePath: String
  public var sha256: String
  public var byteLength: Int
  public var retentionClass: EvidenceRetentionClass
  public var accessClass: EvidenceAccessClass
  public var evidenceOriginAuthority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    [
      "artifact_id": artifactID,
      "relative_path": relativePath,
      "sha256": sha256,
      "byte_length": byteLength,
      "retention_class": retentionClass.rawValue,
      "access_class": accessClass.rawValue,
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
    ]
  }
}

public struct EvidenceDerivativeRelationship: Codable, Sendable, Equatable {
  public var relationshipID: String
  public var sourceArtifactID: String
  public var derivedArtifactID: String
  public var relationshipKind: String

  public func dictionary() -> [String: Any] {
    [
      "relationship_id": relationshipID,
      "source_artifact_id": sourceArtifactID,
      "derived_artifact_id": derivedArtifactID,
      "relationship_kind": relationshipKind,
    ]
  }
}

public struct RedactionDerivationRecord: Codable, Sendable, Equatable {
  public var sourceArtifactID: String
  public var sourceArtifactSHA256: String
  public var redactedArtifactID: String
  public var redactedArtifactSHA256: String
  public var policyID: String
  public var redactionAlgorithmID: String
  public var algorithmVersion: String
  public var regionsModified: [RedactionRegion]
  public var operations: [RedactionOperation]
  public var actor: String
  public var derivationTimestampUTC: String
  public var evidenceOriginAuthority: EvidenceAuthority
  public var derivationAuthority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    [
      "source_artifact_id": sourceArtifactID,
      "source_artifact_sha256": sourceArtifactSHA256,
      "redacted_artifact_id": redactedArtifactID,
      "redacted_artifact_sha256": redactedArtifactSHA256,
      "policy_id": policyID,
      "redaction_algorithm_id": redactionAlgorithmID,
      "algorithm_version": algorithmVersion,
      "regions_modified": regionsModified.map { $0.dictionary() },
      "operations": operations.map { $0.dictionary() },
      "actor": actor,
      "derivation_timestamp_utc": derivationTimestampUTC,
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
      "derivation_authority": derivationAuthority.rawValue,
      "schema_id": "RedactionDerivationRecord",
      "schema_version": "1.0.0-phase3-fixture",
      "note": "Redaction never silently overwrites the raw artifact",
    ]
  }
}

public struct SourceEvidenceAccessReference: Codable, Sendable, Equatable {
  public var referenceID: String
  public var artifactID: String
  public var accessClass: EvidenceAccessClass
  public var storageDomain: String

  public func dictionary() -> [String: Any] {
    [
      "reference_id": referenceID,
      "artifact_id": artifactID,
      "access_class": accessClass.rawValue,
      "storage_domain": storageDomain,
    ]
  }
}

public struct PrivacyTransformationResult: Codable, Sendable, Equatable {
  public var raw: RestrictedRawEvidenceRecord?
  public var redacted: RedactedEvidenceRecord
  public var derivation: RedactionDerivationRecord
  public var relationship: EvidenceDerivativeRelationship
  public var verification: RedactionVerificationResult

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "redacted": redacted.dictionary(),
      "derivation": derivation.dictionary(),
      "relationship": relationship.dictionary(),
      "verification": verification.dictionary(),
    ]
    if let raw { d["restricted_raw"] = raw.dictionary() }
    return d
  }
}

public struct FixtureRedactionEngine: Sendable {
  public static let algorithmID = "fixture.redaction.deterministic.v1"
  public static let algorithmVersion = "1.0.0-phase3-fixture"

  public init() {}

  /// Deterministic fixture detections — NOT Apple Vision / Core ML claims.
  public func detectFixtureRegions(sourceArtifactID: String) -> [RedactionDetection] {
    [
      RedactionDetection(
        detectionID: "DET-FACE-\(sourceArtifactID)",
        kind: .face,
        region: RedactionRegion(regionID: "REG-FACE-1", x: 0.1, y: 0.1, width: 0.2, height: 0.2, coordinateSpace: "normalized_image"),
        confidence: RedactionConfidence(score: 0.91, authority: .testFixture)
      ),
      RedactionDetection(
        detectionID: "DET-PLATE-\(sourceArtifactID)",
        kind: .licensePlate,
        region: RedactionRegion(regionID: "REG-PLATE-1", x: 0.4, y: 0.7, width: 0.25, height: 0.1, coordinateSpace: "normalized_image"),
        confidence: RedactionConfidence(score: 0.88, authority: .testFixture)
      ),
    ]
  }

  public func apply(
    sourceBytes: Data,
    sourceArtifactID: String,
    policy: EvidencePrivacyPolicy,
    actor: String = "fixture.automated.redactor"
  ) throws -> PrivacyTransformationResult {
    let sourceSHA = ContentHasher.sha256Hex(sourceBytes)
    let detections = detectFixtureRegions(sourceArtifactID: sourceArtifactID)
    var missing: [RedactionDetectionKind] = []
    for req in policy.redactionRequirements where req.required {
      let kind = RedactionDetectionKind(rawValue: req.detectionKind)
      if let kind, !detections.contains(where: { $0.kind == kind && $0.confidence.score >= req.minimumConfidence }) {
        missing.append(kind)
      }
    }
    if !missing.isEmpty {
      throw SpatialEvidenceError.requiredRedactionMissing(missing.map(\.rawValue).joined(separator: ","))
    }

    var ops: [RedactionOperation] = []
    for d in detections {
      let kind: RedactionOperationKind = d.kind == .face ? .blur : .pixelate
      ops.append(
        RedactionOperation(
          operationID: "OP-\(d.detectionID)",
          kind: kind,
          detectionID: d.detectionID,
          algorithmID: Self.algorithmID,
          algorithmVersion: Self.algorithmVersion
        )
      )
    }

    // Separate derivative bytes — never overwrite source.
    var redactedBytes = Data("REDACTED-DERIVATIVE\n".utf8)
    redactedBytes.append(sourceBytes)
    redactedBytes.append(Data(ops.map(\.operationID).joined(separator: ",").utf8))
    let redactedSHA = ContentHasher.sha256Hex(redactedBytes)
    let redactedID = "ART-REDACTED-\(sourceArtifactID)"

    let raw: RestrictedRawEvidenceRecord?
    switch policy.captureMode {
    case .privacyFirstCapture:
      raw = nil
    case .rawRestrictedCapture, .noRedactionRequired:
      raw = RestrictedRawEvidenceRecord(
        artifactID: sourceArtifactID,
        relativePath: "restricted_raw/\(sourceArtifactID).bin",
        sha256: sourceSHA,
        byteLength: sourceBytes.count,
        retentionClass: .restrictedRaw,
        accessClass: .engineeringRestricted,
        evidenceOriginAuthority: .testFixture
      )
    }

    let redacted = RedactedEvidenceRecord(
      artifactID: redactedID,
      relativePath: "client_safe/\(redactedID).bin",
      sha256: redactedSHA,
      byteLength: redactedBytes.count,
      retentionClass: .clientSafeDerivative,
      accessClass: .publicClient,
      evidenceOriginAuthority: .testFixture
    )

    let derivation = RedactionDerivationRecord(
      sourceArtifactID: sourceArtifactID,
      sourceArtifactSHA256: sourceSHA,
      redactedArtifactID: redactedID,
      redactedArtifactSHA256: redactedSHA,
      policyID: policy.policyID,
      redactionAlgorithmID: Self.algorithmID,
      algorithmVersion: Self.algorithmVersion,
      regionsModified: detections.map(\.region),
      operations: ops,
      actor: actor,
      derivationTimestampUTC: "2026-08-03T00:30:00Z",
      evidenceOriginAuthority: .testFixture,
      derivationAuthority: .guidanceEstimate
    )

    // Bind redacted bytes into transformation by storing them via side channel is handled by caller.
    _ = redactedBytes

    return PrivacyTransformationResult(
      raw: raw,
      redacted: redacted,
      derivation: derivation,
      relationship: EvidenceDerivativeRelationship(
        relationshipID: "REL-\(sourceArtifactID)",
        sourceArtifactID: sourceArtifactID,
        derivedArtifactID: redactedID,
        relationshipKind: "REDACTION_DERIVATIVE"
      ),
      verification: RedactionVerificationResult(ok: true, missingRequiredKinds: [], note: "fixture_redaction_ok")
    )
  }

  public func materializeRedactedBytes(sourceBytes: Data, operations: [RedactionOperation]) -> Data {
    var redactedBytes = Data("REDACTED-DERIVATIVE\n".utf8)
    redactedBytes.append(sourceBytes)
    redactedBytes.append(Data(operations.map(\.operationID).joined(separator: ",").utf8))
    return redactedBytes
  }

  public func verifyDerivation(
    derivation: RedactionDerivationRecord,
    expectedSourceSHA: String
  ) throws {
    guard !derivation.sourceArtifactID.isEmpty, !derivation.redactedArtifactID.isEmpty else {
      throw SpatialEvidenceError.redactionDerivationFailed("missing_derivation_reference")
    }
    guard derivation.sourceArtifactSHA256 == expectedSourceSHA else {
      throw SpatialEvidenceError.redactionDerivationFailed("incorrect_source_digest")
    }
  }
}
