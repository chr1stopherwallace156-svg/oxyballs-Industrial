import Foundation

/// Coordinate frame identity and transform conventions (COORDINATE_FRAME_STANDARD.md).
public struct CoordinateFrameDescriptor: Sendable, Equatable {
  public let frameID: String
  public let units: String
  public let handedness: String
  public let matrixStorageOrder: String
  public let opticalAxisConvention: String
  public let clockDomain: ClockDomain
  public let authority: String

  public init(
    frameID: String,
    units: String,
    handedness: String,
    matrixStorageOrder: String,
    opticalAxisConvention: String,
    clockDomain: ClockDomain,
    authority: String
  ) {
    self.frameID = frameID
    self.units = units
    self.handedness = handedness
    self.matrixStorageOrder = matrixStorageOrder
    self.opticalAxisConvention = opticalAxisConvention
    self.clockDomain = clockDomain
    self.authority = authority
  }

  public func asDictionary() -> [String: Any] {
    [
      "frame_id": frameID,
      "units": units,
      "handedness": handedness,
      "matrix_storage_order": matrixStorageOrder,
      "optical_axis_convention": opticalAxisConvention,
      "clock_domain": clockDomain.rawValue,
      "authority": authority,
    ]
  }

  /// Default synthetic vehicle/world frame used by deterministic adapters.
  public static let syntheticWorld = CoordinateFrameDescriptor(
    frameID: "FRAME_SYNTHETIC_WORLD",
    units: "meters",
    handedness: "right",
    matrixStorageOrder: "column_major",
    opticalAxisConvention: "opengl",
    clockDomain: ClockDomain.syntheticDeterministic,
    authority: "GUIDANCE_ESTIMATE"
  )
}
