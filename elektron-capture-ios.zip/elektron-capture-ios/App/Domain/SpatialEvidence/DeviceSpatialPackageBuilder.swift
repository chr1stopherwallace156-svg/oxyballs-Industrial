import Foundation

/// Seals the first real physical Spatial Evidence Package (Sprint 3.6).
///
/// HARD RULES:
/// - Only `SESS-DEVICE-*` / `SPKG-DEVICE-*` identities are allowed.
/// - `evidence_origin_authority` must be device-reported / raw observation — never TEST_FIXTURE.
/// - Never invent synthetic stream payloads for unavailable capabilities.
/// - On Linux hosts this builder remains available for structural validation only;
///   physical sealing requires Apple runtime evidence collected on device.
public struct DeviceSpatialPackageBuilder: Sendable {
  public static let reservedPackageID = "SPKG-DEVICE-000001"
  public static let reservedSessionID = "SESS-DEVICE-000001"
  public static let vehicleID = "VEH-000001"
  public static let pilotID = "PILOT-000001"

  public init() {}

  public struct DeviceSealInputs: Sendable {
    public var camera: [SpatialSampleEnvelope<CameraSample>]
    public var motion: [SpatialSampleEnvelope<MotionSample>]
    public var pose: [SpatialSampleEnvelope<PoseSample>]
    public var depth: [SpatialSampleEnvelope<DepthSample>]
    public var cameraCapability: SpatialStreamCapability
    public var motionCapability: SpatialStreamCapability
    public var poseCapability: SpatialStreamCapability
    public var depthCapability: SpatialStreamCapability
    public var activationPlan: SensorActivationPlan
    public var activationResults: [SensorActivationResult]
    public var sessionPolicy: SpatialCaptureSessionPolicy
    public var timeline: CaptureSessionTimeline
    public var interruptions: [CaptureInterruption]
    public var bufferState: CaptureBufferState
    public var packageID: String
    public var captureSessionID: String
    public var evidenceOriginAuthority: EvidenceAuthority
    public var createdAtUTC: String
    public var hostClaim: String

    public init(
      camera: [SpatialSampleEnvelope<CameraSample>],
      motion: [SpatialSampleEnvelope<MotionSample>],
      pose: [SpatialSampleEnvelope<PoseSample>],
      depth: [SpatialSampleEnvelope<DepthSample>],
      cameraCapability: SpatialStreamCapability,
      motionCapability: SpatialStreamCapability,
      poseCapability: SpatialStreamCapability,
      depthCapability: SpatialStreamCapability,
      activationPlan: SensorActivationPlan,
      activationResults: [SensorActivationResult],
      sessionPolicy: SpatialCaptureSessionPolicy,
      timeline: CaptureSessionTimeline,
      interruptions: [CaptureInterruption],
      bufferState: CaptureBufferState,
      packageID: String = DeviceSpatialPackageBuilder.reservedPackageID,
      captureSessionID: String = DeviceSpatialPackageBuilder.reservedSessionID,
      evidenceOriginAuthority: EvidenceAuthority,
      createdAtUTC: String,
      hostClaim: String
    ) {
      self.camera = camera
      self.motion = motion
      self.pose = pose
      self.depth = depth
      self.cameraCapability = cameraCapability
      self.motionCapability = motionCapability
      self.poseCapability = poseCapability
      self.depthCapability = depthCapability
      self.activationPlan = activationPlan
      self.activationResults = activationResults
      self.sessionPolicy = sessionPolicy
      self.timeline = timeline
      self.interruptions = interruptions
      self.bufferState = bufferState
      self.packageID = packageID
      self.captureSessionID = captureSessionID
      self.evidenceOriginAuthority = evidenceOriginAuthority
      self.createdAtUTC = createdAtUTC
      self.hostClaim = hostClaim
    }
  }

  public func validateIdentity(_ inputs: DeviceSealInputs) throws {
    guard inputs.packageID.hasPrefix("SPKG-DEVICE-") else {
      throw SpatialEvidenceError.deviceIdentityRequired("package_id must be SPKG-DEVICE-*")
    }
    guard inputs.captureSessionID.hasPrefix("SESS-DEVICE-") else {
      throw SpatialEvidenceError.deviceIdentityRequired("capture_session_id must be SESS-DEVICE-*")
    }
    guard inputs.packageID.hasPrefix("SPKG-FIXTURE-") == false else {
      throw SpatialEvidenceError.fixtureIdentityForbiddenInDevicePackage(inputs.packageID)
    }
    switch inputs.evidenceOriginAuthority {
    case .testFixture, .guidanceEstimate, .algorithmEstimate, .unknown, .rejected:
      throw SpatialEvidenceError.deviceEvidenceAuthorityRequired(inputs.evidenceOriginAuthority.rawValue)
    case .rawObservation, .deviceReported, .physicalReference, .fieldValidated, .engineeringVerified:
      break
    }
    if inputs.hostClaim.contains("NO_PHYSICAL_DEVICE_EXECUTION") {
      throw SpatialEvidenceError.deviceHostClaimRequired(inputs.hostClaim)
    }
    // Adapter IDs must be Apple production identities when streams are acquired.
    let expected: [(SpatialStreamCapability, String)] = [
      (inputs.cameraCapability, "apple.avfoundation.camera"),
      (inputs.motionCapability, "apple.coremotion.motion"),
      (inputs.poseCapability, "apple.arkit.pose"),
      (inputs.depthCapability, "apple.arkit.depth"),
    ]
    for (cap, expectedID) in expected {
      if cap.finalOutcome == .acquired, cap.adapterID != expectedID {
        throw SpatialEvidenceError.deviceAdapterIdentityMismatch(
          "\(cap.streamID) expected \(expectedID) got \(cap.adapterID)"
        )
      }
    }
  }

  /// Physical seal is Apple-host only. Linux agents must not emit SPKG-DEVICE packages.
  public func seal(_ inputs: DeviceSealInputs, outputDirectory: URL) throws -> SpatialEvidencePackage {
    try validateIdentity(inputs)
    if inputs.cameraCapability.finalOutcome == .acquired && inputs.camera.isEmpty {
      throw SpatialEvidenceError.requiredStreamFailed(streamID: "camera", reason: "acquired_without_samples")
    }
    if inputs.motionCapability.finalOutcome == .acquired && inputs.motion.isEmpty {
      throw SpatialEvidenceError.requiredStreamFailed(streamID: "motion", reason: "acquired_without_samples")
    }
    #if os(iOS)
    // Physical sealing is performed by the Mac/device validation runbook using observed samples only.
    // This source path remains available for Apple hosts; it still refuses fixture authority via validateIdentity.
    return try FixtureCoordinatedPackageBuilder().seal(
      camera: inputs.camera,
      motion: inputs.motion,
      pose: inputs.pose,
      depth: inputs.depth,
      cameraCapability: inputs.cameraCapability,
      motionCapability: inputs.motionCapability,
      poseCapability: inputs.poseCapability,
      depthCapability: inputs.depthCapability,
      activationPlan: inputs.activationPlan,
      activationResults: inputs.activationResults,
      policy: inputs.sessionPolicy,
      timeline: inputs.timeline,
      interruptions: inputs.interruptions,
      bufferState: inputs.bufferState,
      degradedSummary: nil,
      outputDirectory: outputDirectory,
      vehicleID: Self.vehicleID,
      pilotID: Self.pilotID,
      captureSessionID: inputs.captureSessionID,
      packageID: inputs.packageID,
      createdAtUTC: inputs.createdAtUTC
    )
    #else
    throw SpatialEvidenceError.appleHostUnavailable(
      "SPKG-DEVICE seal requires physical iOS host; Linux cloud agent must not emit device packages"
    )
    #endif
  }
}
