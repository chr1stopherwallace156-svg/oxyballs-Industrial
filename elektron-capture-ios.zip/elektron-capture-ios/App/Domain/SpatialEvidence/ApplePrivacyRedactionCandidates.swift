import Foundation

/// Apple Vision redaction detector **source candidate** — unvalidated on Linux.
#if canImport(Vision) && (os(iOS) || os(macOS))
import Vision

public struct AppleVisionRedactionDetector: Sendable {
  public let availabilityStatus: String = "APPLE_VISION_SOURCE_CANDIDATE_UNVALIDATED"

  public init() {}

  public func detect(in _: Data) throws -> [RedactionDetection] {
    throw SpatialEvidenceError.redactionDerivationFailed(
      "AppleVisionRedactionDetector requires physical Apple Vision validation (PENDING)"
    )
  }
}
#else
public struct AppleVisionRedactionDetector: Sendable {
  public let availabilityStatus: String = "UNAVAILABLE_ON_THIS_PLATFORM"

  public init() {}

  public func detect(in _: Data) throws -> [RedactionDetection] {
    throw SpatialEvidenceError.redactionDerivationFailed(
      "AppleVisionRedactionDetector unavailable on this platform (Linux/source-candidate stub)"
    )
  }
}
#endif

/// Apple Core ML privacy filter **source candidate** — unvalidated on Linux.
/// Does not claim ARKit person segmentation handles license plates.
#if canImport(CoreML) && (os(iOS) || os(macOS))
import CoreML

public struct AppleCoreMLPrivacyFilter: Sendable {
  public let availabilityStatus: String = "APPLE_COREML_SOURCE_CANDIDATE_UNVALIDATED"

  public init() {}

  public func filter(detections _: [RedactionDetection]) throws -> [RedactionOperation] {
    throw SpatialEvidenceError.redactionDerivationFailed(
      "AppleCoreMLPrivacyFilter requires physical Core ML validation (PENDING)"
    )
  }
}
#else
public struct AppleCoreMLPrivacyFilter: Sendable {
  public let availabilityStatus: String = "UNAVAILABLE_ON_THIS_PLATFORM"

  public init() {}

  public func filter(detections _: [RedactionDetection]) throws -> [RedactionOperation] {
    throw SpatialEvidenceError.redactionDerivationFailed(
      "AppleCoreMLPrivacyFilter unavailable on this platform (Linux/source-candidate stub)"
    )
  }
}
#endif
