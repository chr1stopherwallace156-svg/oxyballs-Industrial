import Foundation

/// Hardware-neutral typed sensor adapter (no Apple frameworks in this module).
///
/// Referential integrity (Sprint 3.0 hardening):
/// - `streamID` ∈ { camera, depth, motion, pose }
/// - `adapterID` identifies the concrete adapter (e.g. synth.camera)
public protocol SpatialSensorAdapter: Sendable {
  associatedtype Payload: Sendable
  var streamID: String { get }
  var adapterID: String { get }
  var sensorKind: String { get }
  var requiredClockDomain: ClockDomain { get }
  var requiredCoordinateFrameID: String { get }
  func activate() async throws
  func nextSamples(count: Int) async throws -> [SpatialSampleEnvelope<Payload>]
  func deactivate() async
}

public enum SpatialStreamID {
  public static let camera = "camera"
  public static let depth = "depth"
  public static let motion = "motion"
  public static let pose = "pose"
  public static let all: Set<String> = [camera, depth, motion, pose]

  public static func validate(_ streamID: String) throws {
    guard all.contains(streamID) else {
      throw SpatialEvidenceError.packageClosureFailed("invalid stream_id: \(streamID)")
    }
  }
}

public protocol SpatialSensorCoordinator: Sendable {
  var capabilitySnapshot: SpatialCapabilitySnapshot { get }
  func activateAll() async throws
  func collectDeterministicBundle() async throws -> SpatialSampleBundle
}

/// Collected typed sample sets prior to packaging.
public struct SpatialSampleBundle: Sendable {
  public var camera: [SpatialSampleEnvelope<CameraSample>]
  public var depth: [SpatialSampleEnvelope<DepthSample>]
  public var motion: [SpatialSampleEnvelope<MotionSample>]
  public var pose: [SpatialSampleEnvelope<PoseSample>]
  public var capability: SpatialCapabilitySnapshot
  public var clockCorrelations: [ClockCorrelation]
  public var frames: [CoordinateFrameDescriptor]

  public init(
    camera: [SpatialSampleEnvelope<CameraSample>] = [],
    depth: [SpatialSampleEnvelope<DepthSample>] = [],
    motion: [SpatialSampleEnvelope<MotionSample>] = [],
    pose: [SpatialSampleEnvelope<PoseSample>] = [],
    capability: SpatialCapabilitySnapshot,
    clockCorrelations: [ClockCorrelation],
    frames: [CoordinateFrameDescriptor]
  ) {
    self.camera = camera
    self.depth = depth
    self.motion = motion
    self.pose = pose
    self.capability = capability
    self.clockCorrelations = clockCorrelations
    self.frames = frames
  }
}
