import Foundation

/// Portable SHA-256 sidecar helpers for Industrial / Capture handoff digests.
///
/// Sidecar lines must use **basename-only** filenames — never absolute paths,
/// never `/workspace`, never directory separators. Format:
/// `\<64-hex\>  \<basename\>` (two spaces, GNU `sha256sum` style).
public enum PortableSHA256Sidecar {
  public static func basenameOnly(_ pathOrName: String) throws -> String {
    let trimmed = pathOrName.trimmingCharacters(in: .whitespacesAndNewlines)
    if trimmed.isEmpty {
      throw SpatialEvidenceError.packageClosureFailed("empty sidecar filename")
    }
    if trimmed.hasPrefix("/") || trimmed.contains("\\") || trimmed.contains("/") {
      throw SpatialEvidenceError.packageClosureFailed(
        "sidecar filename must be basename-only (no path separators): \(trimmed)"
      )
    }
    if trimmed.contains("..") {
      throw SpatialEvidenceError.packageClosureFailed("sidecar filename must not contain '..'")
    }
    return trimmed
  }

  public static func formatLine(sha256: String, filename: String) throws -> String {
    let base = try basenameOnly(filename)
    let hex = sha256.lowercased()
    guard hex.count == 64, hex.allSatisfy({ $0.isHexDigit }) else {
      throw SpatialEvidenceError.packageClosureFailed("invalid sha256 hex for sidecar")
    }
    return "\(hex)  \(base)\n"
  }

  /// Parse a sidecar file body; rejects absolute/relative paths in the filename field.
  public static func parse(_ text: String) throws -> [(sha256: String, filename: String)] {
    var out: [(String, String)] = []
    for (idx, rawLine) in text.split(whereSeparator: \.isNewline).enumerated() {
      let line = String(rawLine).trimmingCharacters(in: .whitespaces)
      if line.isEmpty || line.hasPrefix("#") { continue }
      // GNU coreutils: "HASH  NAME" (two spaces) or "HASH *NAME"
      let parts: [String]
      if let r = line.range(of: "  ") {
        parts = [String(line[..<r.lowerBound]), String(line[r.upperBound...])]
      } else if let r = line.range(of: " *") {
        parts = [String(line[..<r.lowerBound]), String(line[r.upperBound...])]
      } else {
        let tokens = line.split(separator: " ", maxSplits: 1, omittingEmptySubsequences: true)
        guard tokens.count == 2 else {
          throw SpatialEvidenceError.packageClosureFailed("sidecar line \(idx + 1): expected HASH NAME")
        }
        parts = [String(tokens[0]), String(tokens[1])]
      }
      let hex = parts[0].lowercased()
      let name = try basenameOnly(parts[1])
      guard hex.count == 64, hex.allSatisfy({ $0.isHexDigit }) else {
        throw SpatialEvidenceError.packageClosureFailed("sidecar line \(idx + 1): bad hash")
      }
      out.append((hex, name))
    }
    return out
  }

  public static func write(sha256: String, filename: String, to url: URL) throws {
    let body = try formatLine(sha256: sha256, filename: filename)
    try body.data(using: .utf8)!.write(to: url, options: .atomic)
  }
}
