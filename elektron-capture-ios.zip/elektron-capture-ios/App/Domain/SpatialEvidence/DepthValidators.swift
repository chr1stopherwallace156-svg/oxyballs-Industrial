import Foundation

public enum DepthSampleValidator {
  public static func validate(_ sample: DepthSample, expectedArtifactSHA: String? = nil) throws {
    if sample.width <= 0 {
      throw SpatialEvidenceError.invalidDepthSample("zero_width")
    }
    if sample.height <= 0 {
      throw SpatialEvidenceError.invalidDepthSample("zero_height")
    }
    if sample.rowStrideBytes <= 0 {
      throw SpatialEvidenceError.invalidDepthSample("invalid_row_stride")
    }
    if sample.pixelFormat == .float32Meters {
      let expected = sample.height * sample.rowStrideBytes
      if sample.bytes.count != expected {
        throw SpatialEvidenceError.invalidDepthSample(
          "byte_length_mismatch:expected_\(expected)_actual_\(sample.bytes.count)"
        )
      }
      if sample.rowStrideBytes < sample.width * 4 {
        throw SpatialEvidenceError.invalidDepthSample("row_stride_too_small")
      }
      if sample.depthUnitEnum != .meters && sample.depthUnitEnum != .millimeters {
        throw SpatialEvidenceError.invalidDepthSample("missing_or_unsupported_unit")
      }
      if !(sample.minimumValidDepth.isFinite && sample.maximumValidDepth.isFinite) {
        throw SpatialEvidenceError.invalidDepthSample("non_finite_depth_range")
      }
      if sample.minimumValidDepth > sample.maximumValidDepth {
        throw SpatialEvidenceError.invalidDepthSample("invalid_depth_range")
      }
      try validateFloat32Payload(sample)
    } else if sample.pixelFormat == .opaqueBytes {
      if sample.bytes.isEmpty {
        throw SpatialEvidenceError.invalidDepthSample("empty_opaque_payload")
      }
    } else {
      throw SpatialEvidenceError.invalidDepthSample("unsupported_pixel_format:\(sample.pixelFormat.rawValue)")
    }

    if let expectedArtifactSHA {
      let actual = ContentHasher.sha256Hex(sample.bytes)
      if actual != expectedArtifactSHA {
        throw SpatialEvidenceError.sha256Mismatch(
          path: sample.depthArtifactID,
          expected: expectedArtifactSHA,
          actual: actual
        )
      }
    }

    if sample.confidenceArtifactID == nil && (sample.confidenceAbsenceReason == nil || sample.confidenceAbsenceReason!.isEmpty) {
      throw SpatialEvidenceError.depthArtifactAbsenceRequired("confidence_absence_reason")
    }
    if sample.validityArtifactID == nil && (sample.validityAbsenceReason == nil || sample.validityAbsenceReason!.isEmpty) {
      throw SpatialEvidenceError.depthArtifactAbsenceRequired("validity_absence_reason")
    }
  }

  private static func validateFloat32Payload(_ sample: DepthSample) throws {
    let pixelCount = sample.width * sample.height
    guard sample.bytes.count >= pixelCount * 4 else {
      throw SpatialEvidenceError.invalidDepthSample("truncated_artifact")
    }
    sample.bytes.withUnsafeBytes { raw in
      _ = raw
    }
    for y in 0..<sample.height {
      let rowStart = y * sample.rowStrideBytes
      for x in 0..<sample.width {
        let offset = rowStart + x * 4
        guard offset + 4 <= sample.bytes.count else {
          throw SpatialEvidenceError.invalidDepthSample("truncated_artifact")
        }
        let bits = sample.bytes.subdata(in: offset..<(offset + 4)).withUnsafeBytes {
          UInt32(littleEndian: $0.load(as: UInt32.self))
        }
        let value = Float(bitPattern: bits)
        if value.isNaN {
          if sample.invalidValueEncoding != .nanSentinel {
            throw SpatialEvidenceError.invalidDepthSample("nan_rejected")
          }
          continue
        }
        if value.isInfinite {
          throw SpatialEvidenceError.invalidDepthSample("infinity_rejected")
        }
        if value < 0 {
          if sample.invalidValueEncoding == .negativeSentinel {
            continue
          }
          throw SpatialEvidenceError.invalidDepthSample("negative_depth_rejected")
        }
        let d = Double(value)
        if d < sample.minimumValidDepth || d > sample.maximumValidDepth {
          // Allow only when encoded as invalid sentinel path already handled.
          throw SpatialEvidenceError.invalidDepthSample("depth_out_of_declared_range")
        }
      }
    }
  }
}

public enum DepthCalibrationValidator {
  public static func validate(
    _ calibration: DepthCalibration,
    depthSample: DepthSample? = nil,
    frames: [CoordinateFrameDescriptor]? = nil,
    transformIDs: Set<String>? = nil,
    packageFrameEpochID: String? = nil,
    packageSessionRunID: String? = nil,
    packageWorldOriginRevision: UInt64? = nil
  ) throws {
    if calibration.depthWidth <= 0 || calibration.depthHeight <= 0 {
      throw SpatialEvidenceError.invalidDepthCalibration("non_positive_depth_dimensions")
    }
    if calibration.cameraReferenceWidth <= 0 || calibration.cameraReferenceHeight <= 0 {
      throw SpatialEvidenceError.invalidDepthCalibration("non_positive_camera_dimensions")
    }
    if calibration.intrinsicsMatrix.count != 9 {
      throw SpatialEvidenceError.invalidDepthCalibration("intrinsics_must_be_3x3")
    }
    for (i, v) in calibration.intrinsicsMatrix.enumerated() {
      guard v.isFinite else {
        throw SpatialEvidenceError.invalidDepthCalibration("non_finite_intrinsics_\(i)")
      }
    }
    let scalars = [
      calibration.focalLengthX, calibration.focalLengthY,
      calibration.principalPointX, calibration.principalPointY,
      calibration.depthScale,
    ]
    for v in scalars {
      guard v.isFinite else {
        throw SpatialEvidenceError.invalidDepthCalibration("non_finite_scalar")
      }
    }
    if calibration.focalLengthX <= 0 || calibration.focalLengthY <= 0 {
      throw SpatialEvidenceError.invalidDepthCalibration("invalid_intrinsics_focal")
    }
    if !calibration.depthScale.isFinite || calibration.depthScale == 0 {
      throw SpatialEvidenceError.invalidDepthCalibration("invalid_depth_scale")
    }
    for v in calibration.distortionParameters {
      guard v.isFinite else {
        throw SpatialEvidenceError.invalidDepthCalibration("non_finite_distortion")
      }
    }

    if let depthSample {
      if calibration.depthWidth != depthSample.width || calibration.depthHeight != depthSample.height {
        throw SpatialEvidenceError.depthCalibrationDimensionMismatch(
          "cal_\(calibration.depthWidth)x\(calibration.depthHeight)_sample_\(depthSample.width)x\(depthSample.height)"
        )
      }
      if let cid = depthSample.calibrationID, cid != calibration.calibrationID {
        throw SpatialEvidenceError.depthCalibrationMissing("sample_calibration_id_mismatch")
      }
    }

    if let frames {
      let ids = Set(frames.map(\.frameID))
      if !ids.contains(calibration.depthFrameID) {
        throw SpatialEvidenceError.unknownCoordinateFrame(calibration.depthFrameID)
      }
      if !ids.contains(calibration.cameraFrameID) {
        throw SpatialEvidenceError.unknownCoordinateFrame(calibration.cameraFrameID)
      }
    }
    if let transformIDs, !transformIDs.contains(calibration.depthToCameraTransformID) {
      throw SpatialEvidenceError.invalidDepthCalibration(
        "missing_transform:\(calibration.depthToCameraTransformID)"
      )
    }
    if let packageFrameEpochID,
       let packageSessionRunID,
       let packageWorldOriginRevision
    {
      if calibration.frameEpochID != packageFrameEpochID
        || calibration.sessionRunID != packageSessionRunID
        || calibration.worldOriginRevision != packageWorldOriginRevision
      {
        throw SpatialEvidenceError.invalidDepthCalibration("cross_epoch_calibration")
      }
    }
  }
}

public enum RGBDepthAssociationValidator {
  public static func validate(
    associations: [RGBDepthAssociationRecord],
    cameraSamples: [SpatialSampleEnvelope<CameraSample>],
    depthSamples: [SpatialSampleEnvelope<DepthSample>],
    correlations: [ClockCorrelation],
    calibrations: [DepthCalibration],
    frames: [CoordinateFrameDescriptor],
    transformEdges: [TransformEdge],
    packageFrameEpochID: String,
    packageSessionRunID: String,
    packageWorldOriginRevision: UInt64
  ) throws {
    var seen = Set<String>()
    let cameras = Dictionary(uniqueKeysWithValues: cameraSamples.map { ($0.sampleID, $0) })
    let depths = Dictionary(uniqueKeysWithValues: depthSamples.map { ($0.sampleID, $0) })
    let corrs = Dictionary(uniqueKeysWithValues: correlations.map { ($0.correlationID, $0) })
    let cals = Dictionary(uniqueKeysWithValues: calibrations.map { ($0.calibrationID, $0) })
    let frameIDs = Set(frames.map(\.frameID))
    let transformIDs = Set(transformEdges.map(\.transformID))

    for assoc in associations {
      if !seen.insert(assoc.associationID).inserted {
        throw SpatialEvidenceError.rgbDepthAssociationFailed("duplicate_association:\(assoc.associationID)")
      }
      guard let cam = cameras[assoc.cameraSampleID] else {
        throw SpatialEvidenceError.rgbDepthAssociationFailed("missing_camera_sample:\(assoc.cameraSampleID)")
      }
      guard let depthEnv = depths[assoc.depthSampleID] else {
        throw SpatialEvidenceError.rgbDepthAssociationFailed("missing_depth_sample:\(assoc.depthSampleID)")
      }
      let depth = depthEnv.payload
      guard let corr = corrs[assoc.correlationID] else {
        throw SpatialEvidenceError.unknownClockCorrelationID(assoc.correlationID)
      }
      guard let cal = cals[assoc.calibrationID] else {
        throw SpatialEvidenceError.depthCalibrationMissing(assoc.calibrationID)
      }
      if assoc.cameraClockDomain != cam.clockDomain {
        throw SpatialEvidenceError.clockDomainMismatch(
          expected: cam.clockDomain.rawValue,
          actual: assoc.cameraClockDomain.rawValue
        )
      }
      if assoc.depthClockDomain != depthEnv.clockDomain {
        throw SpatialEvidenceError.clockDomainMismatch(
          expected: depthEnv.clockDomain.rawValue,
          actual: assoc.depthClockDomain.rawValue
        )
      }
      if corr.sourceDomain != assoc.cameraClockDomain
        || corr.destinationDomain != assoc.depthClockDomain
      {
        throw SpatialEvidenceError.clockCorrelationDomainMismatch(assoc.correlationID)
      }
      // Correlation validity window (source domain = camera).
      if let from = corr.validFromNanoseconds, cam.acquisitionTimestampNs < from {
        throw SpatialEvidenceError.staleClockCorrelation(assoc.correlationID)
      }
      if let until = corr.validUntilNanoseconds, cam.acquisitionTimestampNs > until {
        throw SpatialEvidenceError.staleClockCorrelation(assoc.correlationID)
      }

      let converted = corr.convertSourceToDestination(sourceTimestampNs: cam.acquisitionTimestampNs)
      let diff = Int64(depthEnv.acquisitionTimestampNs) - converted
      if diff != assoc.timestampDifferenceNanoseconds {
        throw SpatialEvidenceError.rgbDepthAssociationFailed(
          "timestamp_difference_mismatch:\(assoc.associationID)"
        )
      }
      // Association timestamp must equal camera acquisition for fixture explicit binding.
      if assoc.associationTimestampNanoseconds != cam.acquisitionTimestampNs {
        throw SpatialEvidenceError.associationTimestampMismatch(assoc.associationID)
      }

      try DepthCalibrationValidator.validate(
        cal,
        depthSample: depth,
        frames: frames,
        transformIDs: transformIDs,
        packageFrameEpochID: packageFrameEpochID,
        packageSessionRunID: packageSessionRunID,
        packageWorldOriginRevision: packageWorldOriginRevision
      )

      if !frameIDs.contains(assoc.cameraFrameID) {
        throw SpatialEvidenceError.unknownCoordinateFrame(assoc.cameraFrameID)
      }
      if !frameIDs.contains(assoc.depthFrameID) {
        throw SpatialEvidenceError.unknownCoordinateFrame(assoc.depthFrameID)
      }
      if !transformIDs.contains(assoc.transformID) {
        throw SpatialEvidenceError.rgbDepthAssociationFailed("missing_transform:\(assoc.transformID)")
      }
      if assoc.frameEpochID != packageFrameEpochID
        || depth.frameEpochID != packageFrameEpochID
      {
        throw SpatialEvidenceError.rgbDepthAssociationFailed("cross_epoch:\(assoc.associationID)")
      }
      if assoc.sessionRunID != packageSessionRunID
        || depth.sessionRunID != packageSessionRunID
      {
        throw SpatialEvidenceError.rgbDepthAssociationFailed("cross_session:\(assoc.associationID)")
      }
      if assoc.worldOriginRevision != packageWorldOriginRevision
        || depth.worldOriginRevision != packageWorldOriginRevision
      {
        throw SpatialEvidenceError.rgbDepthAssociationFailed(
          "world_origin_revision_mismatch:\(assoc.associationID)"
        )
      }
      try DepthSampleValidator.validate(depth)
    }
  }
}

public enum DepthCapabilityTruthValidator {
  /// Ensures unavailable / not-requested depth never contributes package evidence.
  public static func validateNoDepthEvidence(
    outcome: SpatialCapabilityFinalOutcome?,
    declared: Bool,
    artifacts: [SpatialArtifactDescriptor],
    depthSamples: [SpatialSampleEnvelope<DepthSample>],
    calibrations: [DepthCalibration],
    associations: [RGBDepthAssociationRecord],
    frames: [CoordinateFrameDescriptor],
    transformEdges: [TransformEdge],
    depthSpecificFrameIDs: Set<String> = ["FRAME_DEPTH_SENSOR"]
  ) throws {
    let blocked: Set<SpatialCapabilityFinalOutcome> = [
      .notRequested,
      .unavailable,
      .unavailableDevice,
      .unavailableConfiguration,
      .activationFailed,
      .interruptedAfterActivation,
      .failed,
      .permissionDenied,
    ]
    let isBlocked: Bool
    if !declared {
      isBlocked = true
    } else if let outcome {
      isBlocked = blocked.contains(outcome) && outcome != .acquired
    } else {
      isBlocked = false
    }
    guard isBlocked else { return }

    if artifacts.contains(where: { $0.streamID == SpatialStreamID.depth }) {
      throw SpatialEvidenceError.depthEvidenceSynthesizedWhenUnavailable("payload")
    }
    if !depthSamples.isEmpty {
      throw SpatialEvidenceError.depthEvidenceSynthesizedWhenUnavailable("depth_samples")
    }
    if !calibrations.isEmpty {
      throw SpatialEvidenceError.depthEvidenceSynthesizedWhenUnavailable("calibration")
    }
    if !associations.isEmpty {
      throw SpatialEvidenceError.depthEvidenceSynthesizedWhenUnavailable("associations")
    }
    for frame in frames where depthSpecificFrameIDs.contains(frame.frameID) {
      throw SpatialEvidenceError.depthEvidenceSynthesizedWhenUnavailable("frame:\(frame.frameID)")
    }
    for edge in transformEdges {
      if depthSpecificFrameIDs.contains(edge.fromFrameID)
        || depthSpecificFrameIDs.contains(edge.toFrameID)
      {
        throw SpatialEvidenceError.depthEvidenceSynthesizedWhenUnavailable(
          "transform:\(edge.transformID)"
        )
      }
    }
  }

  public static func assertNotRequestedDistinctFromUnavailableDevice(
    notRequested: SpatialCapabilityFinalOutcome,
    unavailableDevice: SpatialCapabilityFinalOutcome
  ) throws {
    if notRequested != .notRequested {
      throw SpatialEvidenceError.validationFailed("expected_NOT_REQUESTED")
    }
    if unavailableDevice != .unavailableDevice {
      throw SpatialEvidenceError.validationFailed("expected_UNAVAILABLE_DEVICE")
    }
    if notRequested == unavailableDevice {
      throw SpatialEvidenceError.validationFailed("NOT_REQUESTED_collapsed_with_UNAVAILABLE_DEVICE")
    }
  }
}
