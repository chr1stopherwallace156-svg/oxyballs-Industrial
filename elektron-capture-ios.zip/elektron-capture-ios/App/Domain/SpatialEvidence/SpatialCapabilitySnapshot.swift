import Foundation

/// Capability lifecycle for a single sensor stream (Phase 3 charter §4.2).
public enum SpatialCapabilityStage: String, Codable, Sendable, Equatable, CaseIterable {
  case declared = "DECLARED"
  case activated = "ACTIVATED"
  case observed = "OBSERVED"
  case finalOutcome = "FINAL_OUTCOME"
}

public enum SpatialCapabilityFinalOutcome: String, Codable, Sendable, Equatable {
  case acquired = "ACQUIRED"
  case unavailable = "UNAVAILABLE"
  /// Depth/sensor requested or evaluated but device lacks the capability.
  case unavailableDevice = "UNAVAILABLE_DEVICE"
  /// Hardware may support the stream, but the active capture configuration does not.
  case unavailableConfiguration = "UNAVAILABLE_CONFIGURATION"
  case degradedOptionalDrop = "DEGRADED_OPTIONAL_DROP"
  case permissionDenied = "PERMISSION_DENIED"
  case notRequested = "NOT_REQUESTED"
  case failed = "FAILED"
  /// Activation was attempted and failed before observation.
  case activationFailed = "ACTIVATION_FAILED"
  /// Stream activated then interrupted before a durable acquisition claim.
  case interruptedAfterActivation = "INTERRUPTED_AFTER_ACTIVATION"
}

public struct SpatialStreamCapability: Sendable, Equatable {
  public let streamID: String
  public let adapterID: String
  public let sensorKind: String
  /// Whether this stream was requested for the session (false ⇒ NOT_REQUESTED).
  public var declared: Bool
  public var stage: SpatialCapabilityStage
  public var samplesAcquired: UInt64
  public var finalOutcome: SpatialCapabilityFinalOutcome?

  public init(
    streamID: String,
    adapterID: String,
    sensorKind: String,
    declared: Bool = true,
    stage: SpatialCapabilityStage = .declared,
    samplesAcquired: UInt64 = 0,
    finalOutcome: SpatialCapabilityFinalOutcome? = nil
  ) {
    self.streamID = streamID
    self.adapterID = adapterID
    self.sensorKind = sensorKind
    self.declared = declared
    self.stage = stage
    self.samplesAcquired = samplesAcquired
    self.finalOutcome = finalOutcome
  }

  public var activated: Bool {
    switch stage {
    case .activated, .observed, .finalOutcome: return declared
    case .declared: return false
    }
  }

  public var observed: Bool { samplesAcquired > 0 && declared }

  /// Hardware/synthetic capability may be reported OBSERVED only after samples acquired.
  public mutating func recordSample() {
    guard declared else { return }
    samplesAcquired &+= 1
    if stage == .activated || stage == .declared {
      stage = .observed
    }
  }

  public mutating func activate() {
    guard declared else { return }
    if stage == .declared {
      stage = .activated
    }
  }

  public mutating func freeze(outcome: SpatialCapabilityFinalOutcome) throws {
    if !declared {
      stage = .finalOutcome
      finalOutcome = .notRequested
      return
    }
    if outcome == .acquired && samplesAcquired == 0 {
      throw SpatialEvidenceError.capabilityNotObserved(streamID)
    }
    stage = .finalOutcome
    finalOutcome = outcome
  }

  public func asDictionary() -> [String: Any] {
    var d: [String: Any] = [
      "stream_id": streamID,
      "adapter_id": adapterID,
      "sensor_kind": sensorKind,
      "declared": declared,
      "activated": activated,
      "observed": observed,
      "stage": stage.rawValue,
      "samples_acquired": samplesAcquired,
    ]
    if let finalOutcome {
      d["final_outcome"] = finalOutcome.rawValue
      d["outcome"] = finalOutcome.rawValue
    }
    return d
  }
}

/// Spatial capability snapshot — distinct from DeviceCapabilitySnapshot 1.0.0 (ADR-P3-006).
public struct SpatialCapabilitySnapshot: Sendable, Equatable {
  public static let schemaID = "SpatialCapabilitySnapshot"
  /// Default remains synthetic for Sprint 3.0 paths; fixture builders pass `1.0.0-phase3-fixture`.
  public static let schemaVersion = "1.0.0-phase3-synthetic"
  public static let fixtureSchemaVersion = "1.0.0-phase3-fixture"

  public let snapshotID: String
  public let capturedAtUTC: String
  public let schemaVersion: String
  public var streams: [SpatialStreamCapability]

  public init(
    snapshotID: String,
    capturedAtUTC: String,
    streams: [SpatialStreamCapability],
    schemaVersion: String = Self.schemaVersion
  ) {
    self.snapshotID = snapshotID
    self.capturedAtUTC = capturedAtUTC
    self.schemaVersion = schemaVersion
    self.streams = streams
  }

  public func asDictionary() -> [String: Any] {
    [
      "schema_id": Self.schemaID,
      "schema_version": schemaVersion,
      "snapshot_id": snapshotID,
      "captured_at_utc": capturedAtUTC,
      "streams": streams.map { $0.asDictionary() },
    ]
  }
}
