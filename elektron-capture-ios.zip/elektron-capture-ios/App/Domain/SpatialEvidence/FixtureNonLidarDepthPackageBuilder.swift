import Foundation

/// Non-LiDAR / depth-unavailable fixture: camera may be present; depth is UNAVAILABLE_DEVICE.
public struct FixtureNonLidarDepthPackageBuilder: Sendable {
  public static let packageID = "SPKG-FIXTURE-NONLIDAR-DEPTH-000001"
  public static let sessionID = "SESS-FIXTURE-NONLIDAR-DEPTH-000001"
  public static let frameEpochID = "epoch-fixture-1"
  public static let sessionRunID = "run-fixture-1"
  public static let worldOriginRevision: UInt64 = 1

  public init() {}

  public func seal(
    camera: [SpatialSampleEnvelope<CameraSample>],
    cameraCapability: SpatialStreamCapability,
    depthCapability: SpatialStreamCapability,
    frames: [CoordinateFrameDescriptor],
    clockCorrelations: [ClockCorrelation],
    outputDirectory: URL,
    vehicleID: String = "VEH-000001",
    pilotID: String = "PILOT-000001",
    captureSessionID: String = FixtureNonLidarDepthPackageBuilder.sessionID,
    packageID: String = FixtureNonLidarDepthPackageBuilder.packageID,
    createdAtUTC: String = "2026-08-03T00:00:00Z"
  ) throws -> SpatialEvidencePackage {
    precondition(!camera.isEmpty)
    var camCap = cameraCapability
    try camCap.freeze(outcome: .acquired)

    var depthCap = depthCapability
    // Force honest unavailable-device outcome; never synthesize depth.
    if depthCap.adapterID != "none" {
      // Allow fixture.depth.unavailable style adapter id for clarity, but freeze as UNAVAILABLE_DEVICE.
    }
    depthCap.declared = true
    try depthCap.freeze(outcome: .unavailableDevice)
    if depthCap.samplesAcquired != 0 {
      throw SpatialEvidenceError.depthEvidenceSynthesizedWhenUnavailable("samples_acquired")
    }

    var motionCap = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "none",
      sensorKind: "motion",
      declared: false
    )
    try motionCap.freeze(outcome: .notRequested)

    var poseCap = SpatialStreamCapability(
      streamID: SpatialStreamID.pose,
      adapterID: "none",
      sensorKind: "pose",
      declared: false
    )
    try poseCap.freeze(outcome: .notRequested)

    try DepthCapabilityTruthValidator.assertNotRequestedDistinctFromUnavailableDevice(
      notRequested: .notRequested,
      unavailableDevice: .unavailableDevice
    )

    let capability = SpatialCapabilitySnapshot(
      snapshotID: "CAP-\(packageID)",
      capturedAtUTC: createdAtUTC,
      streams: [camCap, depthCap, motionCap, poseCap],
      schemaVersion: SpatialCapabilitySnapshot.fixtureSchemaVersion
    )

    try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
    let payloadRoot = outputDirectory.appendingPathComponent("payload", isDirectory: true)
    try FileManager.default.createDirectory(at: payloadRoot, withIntermediateDirectories: true)

    var artifacts: [SpatialArtifactDescriptor] = []
    var sampleIndex: [[String: Any]] = []

    try writePayload(
      stream: SpatialStreamID.camera,
      adapterID: camCap.adapterID,
      samples: camera,
      root: payloadRoot,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }

    try DepthCapabilityTruthValidator.validateNoDepthEvidence(
      outcome: depthCap.finalOutcome,
      declared: depthCap.declared,
      artifacts: artifacts,
      depthSamples: [],
      calibrations: [],
      associations: [],
      frames: frames,
      transformEdges: []
    )

    try writeJSON(capability.asDictionary(), to: outputDirectory.appendingPathComponent("capability_snapshot.json"))
    try writeJSON(
      ["correlations": clockCorrelations.map { $0.asDictionary() }],
      to: outputDirectory.appendingPathComponent("clock_correlation.json")
    )
    try writeJSON(
      ["frames": frames.map { $0.asDictionary() }],
      to: outputDirectory.appendingPathComponent("coordinate_frames.json")
    )
    // Explicit empty containers prove absence — not silent omission of required files.
    try writeJSON(
      [
        "calibrations": [] as [Any],
        "note": "UNAVAILABLE_DEVICE — no depth calibration emitted",
      ],
      to: outputDirectory.appendingPathComponent("depth_calibration.json")
    )
    try writeJSON(
      [
        "associations": [] as [Any],
        "note": "UNAVAILABLE_DEVICE — no RGB/depth associations emitted",
      ],
      to: outputDirectory.appendingPathComponent("rgb_depth_associations.json")
    )
    try writeJSON(
      [
        "edges": [] as [Any],
        "characterization_status": "PENDING_CHARACTERIZATION",
        "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED",
        "note": "UNAVAILABLE_DEVICE — no depth transforms emitted",
      ],
      to: outputDirectory.appendingPathComponent("transform_graph.json")
    )
    sampleIndex.sort {
      (($0["relative_path"] as? String) ?? "") < (($1["relative_path"] as? String) ?? "")
    }
    try writeJSON(["samples": sampleIndex], to: outputDirectory.appendingPathComponent("sample_index.json"))

    let manifest = SpatialEvidenceManifest(
      packageID: packageID,
      vehicleID: vehicleID,
      captureSessionID: captureSessionID,
      pilotID: pilotID,
      createdAtUTC: createdAtUTC,
      capability: capability,
      frames: frames,
      clockCorrelations: clockCorrelations,
      artifacts: artifacts,
      sampleIndex: sampleIndex
    )
    var manifestDict = manifest.asDictionary()
    manifestDict["schema_id"] = "SpatialEvidenceManifest"
    manifestDict["schema_version"] = "1.0.0-phase3-fixture"
    manifestDict["package_layout"] = "fixture_nonlidar_depth_v1"
    manifestDict["host_claim"] = "NO_PHYSICAL_DEVICE_EXECUTION"
    manifestDict["implementation_state"] = "SOURCE_IMPLEMENTED"
    manifestDict["validation_state"] = "LINUX_FIXTURE_VALIDATED"
    manifestDict["evidence_origin_authority"] = "TEST_FIXTURE"
    manifestDict["depth_estimate_authority"] = "GUIDANCE_ESTIMATE"
    manifestDict["depth_outcome"] = SpatialCapabilityFinalOutcome.unavailableDevice.rawValue
    manifestDict["frame_epoch_id"] = Self.frameEpochID
    manifestDict["session_run_id"] = Self.sessionRunID
    manifestDict["world_origin_revision"] = Self.worldOriginRevision

    let manifestData = try CanonicalJSON.data(manifestDict)
    try manifestData.write(to: outputDirectory.appendingPathComponent("manifest.json"), options: .atomic)
    let manifestSHA = ContentHasher.sha256Hex(manifestData)

    let inventoryEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: outputDirectory
    )
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(
      packageRoot: outputDirectory,
      entries: inventoryEntries
    )
    let packageClosureHash = try SpatialPackageClosureVerifier.inventoryClosureHash(
      entries: inventoryEntries
    )
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": packageClosureHash,
      "entries": inventoryEntries,
    ]
    try writeJSON(inventory, to: outputDirectory.appendingPathComponent("package_inventory.json"))

    try SpatialPackageClosureVerifier.verifyDevicePayload(
      packageRoot: outputDirectory,
      manifestArtifacts: artifacts
    )
    let packageHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outputDirectory)

    return SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: manifestSHA,
      packageClosureSHA256: packageClosureHash
    )
  }

  public static func defaultFrames() -> [CoordinateFrameDescriptor] {
    [
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAPTURE_SESSION_ROOT",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "opencv",
        clockDomain: .fixtureCamera,
        authority: "TEST_FIXTURE"
      ),
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAMERA_OPTICAL",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "opencv",
        clockDomain: .fixtureCamera,
        authority: "TEST_FIXTURE"
      ),
    ]
  }

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    try CanonicalJSON.data(object).write(to: url, options: .atomic)
  }

  private func writePayload<Payload>(
    stream: String,
    adapterID: String,
    samples: [SpatialSampleEnvelope<Payload>],
    root: URL,
    artifacts: inout [SpatialArtifactDescriptor],
    sampleIndex: inout [[String: Any]],
    bytesOf: (Payload) -> Data
  ) throws {
    try SpatialStreamID.validate(stream)
    let dir = root.appendingPathComponent(stream, isDirectory: true)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    for (idx, sample) in samples.enumerated() {
      let schemaKey = "\(sample.schemaID)@\(sample.schemaVersion)"
      guard SpatialEvidenceManifest.supportedSchemas.contains(schemaKey) else {
        throw SpatialEvidenceError.unsupportedSchema(id: sample.schemaID, version: sample.schemaVersion)
      }
      let fileName = String(format: "%04d.bin", idx)
      let rel = "payload/\(stream)/\(fileName)"
      let data = bytesOf(sample.payload)
      try data.write(to: dir.appendingPathComponent(fileName), options: .atomic)
      let sha = ContentHasher.sha256Hex(data)
      artifacts.append(
        SpatialArtifactDescriptor(
          relativePath: rel,
          byteLength: data.count,
          sha256: sha,
          mediaType: sample.mediaType,
          schemaID: sample.schemaID,
          schemaVersion: sample.schemaVersion,
          sampleID: sample.sampleID,
          streamID: stream,
          adapterID: adapterID
        )
      )
      sampleIndex.append([
        "sample_id": sample.sampleID,
        "sequence_index": sample.sequenceIndex,
        "acquisition_timestamp_ns": sample.acquisitionTimestampNs,
        "clock_domain": sample.clockDomain.rawValue,
        "coordinate_frame_id": sample.coordinateFrameID,
        "relative_path": rel,
        "stream_id": stream,
        "adapter_id": adapterID,
      ])
    }
  }
}
