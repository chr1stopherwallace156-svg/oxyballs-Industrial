import Foundation

/// Deterministic technician guidance + completion recommendation engine.
public struct CaptureGuidanceEngine: Sendable {
  public static let algorithmIdentifier = "capture-guidance-engine-v1"
  public static let algorithmVersion = "1.0.0-phase3-fixture"

  public init() {}

  public func generate(
    captureSessionID: String,
    signals: [CaptureQualitySignal],
    coverageSummary: CoverageSummary,
    coverageGaps: [CoverageGap],
    depthOutcomeAcquired: Bool,
    activeInterruption: Bool,
    requiredStreamFailed: Bool,
    cancelled: Bool,
    nowNanoseconds: UInt64 = 50_000_000
  ) throws -> (
    history: [CaptureGuidanceRecord],
    completion: CaptureCompletionRecord,
    readiness: CaptureReadinessSummary
  ) {
    var history: [CaptureGuidanceRecord] = []
    var activeKeys = Set<String>()

    func emit(
      code: CaptureGuidanceCode,
      severity: CaptureQualitySeverity,
      priority: GuidancePriority,
      stream: String? = nil,
      region: String? = nil,
      evidence: [String],
      signals signalIDs: [String],
      instruction: String,
      createdAt: UInt64,
      lifecycle: GuidanceLifecycle = .active,
      resolvedAt: UInt64? = nil
    ) throws {
      guard !evidence.isEmpty || !signalIDs.isEmpty || code == .capturePolicySatisfied || code == .regionRequirementSatisfied else {
        throw SpatialEvidenceError.guidanceMissingSupportingEvidence(code.rawValue)
      }
      let key = "\(code.rawValue)|\(stream ?? "")|\(region ?? "")"
      if lifecycle == .active {
        if activeKeys.contains(key) { return } // no duplicate active guidance
        activeKeys.insert(key)
      }
      let id = "GUD-\(String(format: "%04d", history.count + 1))-\(code.rawValue)"
      history.append(
        CaptureGuidanceRecord(
          guidanceID: id,
          guidanceCode: code,
          severity: severity,
          priority: priority,
          createdAtNanoseconds: createdAt,
          resolvedAtNanoseconds: resolvedAt,
          lifecycle: lifecycle,
          affectedStreamID: stream,
          affectedRegionID: region,
          supportingEvidenceIDs: evidence.sorted(),
          qualitySignalIDs: signalIDs.sorted(),
          humanReadableInstruction: instruction,
          evidenceOriginAuthority: .testFixture,
          guidanceAuthority: .guidanceEstimate
        )
      )
    }

    // Priority-ordered evaluation.
    if cancelled {
      let completion = CaptureCompletionRecord(
        recommendation: .cancelled,
        reasons: [.sessionCancelled],
        captureSessionID: captureSessionID,
        generatedAtNanoseconds: nowNanoseconds,
        note: "Capture cancelled; no sealed package. Not an engineering-completeness determination."
      )
      let readiness = CaptureReadinessSummary(
        summaryID: "READY-\(captureSessionID)",
        captureSessionID: captureSessionID,
        recommendation: .cancelled,
        reasons: [.sessionCancelled],
        activeGuidanceCodes: [],
        note: completion.note,
        evidenceOriginAuthority: .testFixture,
        guidanceAuthority: .guidanceEstimate
      )
      return (history, completion, readiness)
    }

    if requiredStreamFailed {
      try emit(
        code: .requiredStreamInterrupted,
        severity: .blocking,
        priority: .requiredStreamOrSafety,
        stream: "camera",
        evidence: ["session:\(captureSessionID)"],
        signals: signals.filter { $0.signalType == .requiredStreamStarvation }.map(\.signalID),
        instruction: "Required camera/motion stream failed. Pause and recover before continuing.",
        createdAt: nowNanoseconds
      )
      let completion = CaptureCompletionRecord(
        recommendation: .failedRequiredPolicy,
        reasons: [.requiredStreamFailure],
        captureSessionID: captureSessionID,
        generatedAtNanoseconds: nowNanoseconds,
        note: "Required stream policy failed. SUFFICIENT_FOR_PACKAGE_FINALIZATION is not applicable."
      )
      return (
        sortHistory(history),
        completion,
        CaptureReadinessSummary(
          summaryID: "READY-\(captureSessionID)",
          captureSessionID: captureSessionID,
          recommendation: .failedRequiredPolicy,
          reasons: [.requiredStreamFailure],
          activeGuidanceCodes: history.filter { $0.lifecycle == .active }.map(\.guidanceCode.rawValue),
          note: completion.note,
          evidenceOriginAuthority: .testFixture,
          guidanceAuthority: .guidanceEstimate
        )
      )
    }

    if activeInterruption {
      try emit(
        code: .waitForRecovery,
        severity: .blocking,
        priority: .requiredStreamOrSafety,
        evidence: ["session:\(captureSessionID)"],
        signals: signals.filter { $0.signalType == .interruptionFrequency }.map(\.signalID),
        instruction: "Capture interrupted. Wait for recovery before accepting new evidence.",
        createdAt: nowNanoseconds
      )
      let completion = CaptureCompletionRecord(
        recommendation: .pauseAndRecover,
        reasons: [.activeInterruption],
        captureSessionID: captureSessionID,
        generatedAtNanoseconds: nowNanoseconds,
        note: "Active interruption prevents package finalization."
      )
      return (
        sortHistory(history),
        completion,
        CaptureReadinessSummary(
          summaryID: "READY-\(captureSessionID)",
          captureSessionID: captureSessionID,
          recommendation: .pauseAndRecover,
          reasons: [.activeInterruption],
          activeGuidanceCodes: history.filter { $0.lifecycle == .active }.map(\.guidanceCode.rawValue),
          note: completion.note,
          evidenceOriginAuthority: .testFixture,
          guidanceAuthority: .guidanceEstimate
        )
      )
    }

    // Storage pressure (priority 2)
    for s in signals where !s.resolved && s.signalType == .storagePressure {
      try emit(
        code: .storagePressure,
        severity: s.severity,
        priority: .storageOrPackageIntegrity,
        stream: s.streamID,
        evidence: s.supportingEvidenceIDs,
        signals: [s.signalID],
        instruction: "Storage pressure is high. Free space or reduce capture rate.",
        createdAt: s.timestampNanoseconds
      )
    }

    // Tracking / sync (priority 3)
    for s in signals where !s.resolved && (s.signalType == .trackingQuality || s.signalType == .timestampSynchronizationHealth || s.signalType == .frameEpochInstability || s.signalType == .clockCorrelationValidity) {
      try emit(
        code: .trackingDegraded,
        severity: .severe,
        priority: .severeTrackingOrSync,
        stream: s.streamID ?? "pose",
        evidence: s.supportingEvidenceIDs,
        signals: [s.signalID],
        instruction: "Tracking or synchronization is degraded. Stabilize device and avoid combining cross-epoch evidence.",
        createdAt: s.timestampNanoseconds
      )
    }

    // Motion / blur / exposure (priority 4) — MOVE_SLOWER before viewpoint guidance
    for s in signals where !s.resolved && (s.signalType == .excessiveAngularMotion || s.signalType == .excessiveTranslationRate || s.signalType == .deviceMotionMagnitude) {
      try emit(
        code: .moveSlower,
        severity: s.severity == .informational ? .warning : s.severity,
        priority: .severeBlurMotionExposure,
        stream: s.streamID ?? "motion",
        evidence: s.supportingEvidenceIDs,
        signals: [s.signalID],
        instruction: "Move slower to reduce motion artifacts.",
        createdAt: s.timestampNanoseconds
      )
    }
    for s in signals where !s.resolved && s.signalType == .imageBlurEstimate {
      try emit(
        code: .holdSteadier,
        severity: s.severity == .informational ? .warning : s.severity,
        priority: .severeBlurMotionExposure,
        stream: s.streamID ?? "camera",
        evidence: s.supportingEvidenceIDs,
        signals: [s.signalID],
        instruction: "Hold steadier; image blur estimate exceeds fixture threshold.",
        createdAt: s.timestampNanoseconds
      )
    }
    for s in signals where !s.resolved && (s.signalType == .underexposure || s.signalType == .overexposure) {
      try emit(
        code: .improveLighting,
        severity: .warning,
        priority: .severeBlurMotionExposure,
        stream: s.streamID ?? "camera",
        evidence: s.supportingEvidenceIDs,
        signals: [s.signalID],
        instruction: s.signalType == .underexposure
          ? "Improve lighting; underexposure detected."
          : "Reduce glare or exposure; overexposure detected.",
        createdAt: s.timestampNanoseconds
      )
    }
    for s in signals where !s.resolved && s.signalType == .droppedSampleRate {
      try emit(
        code: .sampleDropRateHigh,
        severity: .warning,
        priority: .severeBlurMotionExposure,
        stream: s.streamID,
        evidence: s.supportingEvidenceIDs,
        signals: [s.signalID],
        instruction: "Sample drop rate is high. Slow capture or reduce load.",
        createdAt: s.timestampNanoseconds
      )
    }

    // Missing required coverage (priority 5)
    for gap in coverageGaps.filter(\.required).sorted(by: { $0.gapID < $1.gapID }) {
      try emit(
        code: .returnToRegion,
        severity: .warning,
        priority: .missingRequiredCoverage,
        region: gap.regionID.rawValue,
        evidence: ["coverage_gap:\(gap.gapID)"],
        signals: [],
        instruction: "Return to region \(gap.regionID.rawValue) to satisfy coverage policy.",
        createdAt: nowNanoseconds
      )
    }
    // Viewpoint diversity / overlap optimization only when motion is not actively severe
    let motionActive = history.contains { $0.lifecycle == .active && ($0.guidanceCode == .moveSlower || $0.guidanceCode == .holdSteadier) }
    if !motionActive {
      for cellReason in coverageGaps where !cellReason.required && cellReason.reason.contains("viewpoint") {
        try emit(
          code: .captureDifferentViewpoint,
          severity: .informational,
          priority: .optimization,
          region: cellReason.regionID.rawValue,
          evidence: ["coverage_gap:\(cellReason.gapID)"],
          signals: [],
          instruction: "Capture a different viewpoint for \(cellReason.regionID.rawValue).",
          createdAt: nowNanoseconds
        )
      }
    }

    // Optional depth (priority 6)
    if !depthOutcomeAcquired {
      let depthSignals = signals.filter { $0.signalType == .depthAvailability || $0.signalType == .optionalStreamDegradation }
      try emit(
        code: .depthUnavailable,
        severity: .warning,
        priority: .optionalDepthOrPoseDegradation,
        stream: "depth",
        evidence: depthSignals.first?.supportingEvidenceIDs ?? ["capability:depth"],
        signals: depthSignals.map(\.signalID),
        instruction: "Depth is unavailable on this device/configuration. Continue if policy allows optional depth degradation.",
        createdAt: nowNanoseconds
      )
    }
    for s in signals where !s.resolved && (s.signalType == .depthValidityPercentage || s.signalType == .confidenceMapQuality) {
      try emit(
        code: .depthQualityLow,
        severity: .warning,
        priority: .optionalDepthOrPoseDegradation,
        stream: "depth",
        evidence: s.supportingEvidenceIDs,
        signals: [s.signalID],
        instruction: "Depth quality is low. Reposition or continue without relying on depth.",
        createdAt: s.timestampNanoseconds
      )
    }

    // Resolved counterparts for resolved signals (MOVE_SLOWER resolved example)
    for s in signals where s.resolved && (s.signalType == .excessiveAngularMotion || s.signalType == .deviceMotionMagnitude || s.signalType == .excessiveTranslationRate) {
      let key = "\(CaptureGuidanceCode.moveSlower.rawValue)|motion|"
      if activeKeys.contains(key) {
        // supersede prior active if present — mark resolved records
        if let idx = history.firstIndex(where: { $0.guidanceCode == .moveSlower && $0.lifecycle == .active }) {
          let old = history[idx]
          history[idx] = CaptureGuidanceRecord(
            guidanceID: old.guidanceID,
            guidanceCode: old.guidanceCode,
            severity: old.severity,
            priority: old.priority,
            createdAtNanoseconds: old.createdAtNanoseconds,
            resolvedAtNanoseconds: s.timestampNanoseconds,
            lifecycle: .resolved,
            affectedStreamID: old.affectedStreamID,
            affectedRegionID: old.affectedRegionID,
            supportingEvidenceIDs: old.supportingEvidenceIDs,
            qualitySignalIDs: old.qualitySignalIDs,
            humanReadableInstruction: old.humanReadableInstruction,
            evidenceOriginAuthority: old.evidenceOriginAuthority,
            guidanceAuthority: old.guidanceAuthority
          )
          activeKeys.remove(key)
        }
      }
    }

    // Region satisfied informational
    for region in coverageSummary.requiredSatisfied.sorted() {
      try emit(
        code: .regionRequirementSatisfied,
        severity: .informational,
        priority: .informationalCompletion,
        region: region,
        evidence: ["coverage_summary:\(coverageSummary.summaryID)"],
        signals: [],
        instruction: "Region \(region) meets the configured coverage policy.",
        createdAt: nowNanoseconds,
        lifecycle: .resolved,
        resolvedAt: nowNanoseconds
      )
    }

    history = sortHistory(history)

    // Completion
    let unresolvedSevereBlur = signals.contains {
      !$0.resolved && $0.signalType == .imageBlurEstimate
        && ($0.severity == .severe || $0.severity == .blocking)
    }
    let unresolvedStorage = signals.contains { !$0.resolved && $0.signalType == .storagePressure && ($0.severity == .severe || $0.severity == .blocking) }

    let recommendation: CaptureCompletionRecommendation
    let reasons: [CaptureCompletionReason]
    if unresolvedStorage {
      recommendation = .pauseAndRecover
      reasons = [.packageIntegrityRisk]
    } else if unresolvedSevereBlur {
      recommendation = .recaptureRequired
      reasons = [.unresolvedSevereQuality]
    } else if !coverageSummary.requiredMissing.isEmpty {
      recommendation = .continueCapture
      reasons = [.missingRequiredRegion]
    } else if coverageSummary.policySatisfied {
      recommendation = .sufficientForPackageFinalization
      reasons = depthOutcomeAcquired ? [.policySatisfied] : [.policySatisfied, .optionalDegradedAllowed]
      try emit(
        code: .capturePolicySatisfied,
        severity: .informational,
        priority: .informationalCompletion,
        evidence: ["coverage_summary:\(coverageSummary.summaryID)", "quality_summary:session"],
        signals: [],
        instruction: "Configured evidence-capture policy is satisfied. This is not engineering completeness, reconstruction, or digital-twin completion.",
        createdAt: nowNanoseconds,
        lifecycle: .resolved,
        resolvedAt: nowNanoseconds
      )
      history = sortHistory(history)
    } else {
      recommendation = .continueCapture
      reasons = [.missingRequiredRegion]
    }

    let note: String
    switch recommendation {
    case .sufficientForPackageFinalization:
      note = "Configured evidence-capture policy satisfied only. Not complete vehicle geometry, verified reconstruction, engineering measurement, digital twin, or manufacturing-ready evidence."
    case .recaptureRequired:
      note = "Severe unresolved quality signals require recapture before policy satisfaction."
    case .continueCapture:
      note = "Continue capture to satisfy remaining coverage or quality policy conditions."
    default:
      note = "Completion recommendation derived from session policy; not an engineering-completeness claim."
    }

    let completion = CaptureCompletionRecord(
      recommendation: recommendation,
      reasons: reasons,
      captureSessionID: captureSessionID,
      generatedAtNanoseconds: nowNanoseconds,
      note: note
    )
    let readiness = CaptureReadinessSummary(
      summaryID: "READY-\(captureSessionID)",
      captureSessionID: captureSessionID,
      recommendation: recommendation,
      reasons: reasons,
      activeGuidanceCodes: history.filter { $0.lifecycle == .active }.map(\.guidanceCode.rawValue).sorted(),
      note: note,
      evidenceOriginAuthority: .testFixture,
      guidanceAuthority: .guidanceEstimate
    )
    return (history, completion, readiness)
  }

  private func sortHistory(_ history: [CaptureGuidanceRecord]) -> [CaptureGuidanceRecord] {
    history.sorted { lhs, rhs in
      if lhs.priority != rhs.priority { return lhs.priority < rhs.priority }
      if lhs.createdAtNanoseconds != rhs.createdAtNanoseconds {
        return lhs.createdAtNanoseconds < rhs.createdAtNanoseconds
      }
      return lhs.guidanceID < rhs.guidanceID
    }
  }
}
