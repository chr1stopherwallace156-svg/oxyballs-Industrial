import Foundation

/// Explicit correlation between two clock domains. Cross-domain compares without this are forbidden.
/// Uses the Phase 0–2.3 `ClockDomain` enum (extended with `syntheticDeterministic` via ADR-P3-006).
public struct ClockCorrelation: Sendable, Equatable {
  public let correlationID: String
  public let sourceDomain: ClockDomain
  public let destinationDomain: ClockDomain
  public let offsetNanoseconds: Int64
  public let scaleNumerator: Int64
  public let scaleDenominator: Int64
  public let authority: String
  public let method: String
  /// Inclusive validity start in source-domain nanoseconds (nil = unbounded).
  public let validFromNanoseconds: UInt64?
  /// Inclusive validity end in source-domain nanoseconds (nil = unbounded).
  public let validUntilNanoseconds: UInt64?

  public init(
    correlationID: String,
    sourceDomain: ClockDomain,
    destinationDomain: ClockDomain,
    offsetNanoseconds: Int64,
    scaleNumerator: Int64 = 1,
    scaleDenominator: Int64 = 1,
    authority: String,
    method: String = "unspecified",
    validFromNanoseconds: UInt64? = nil,
    validUntilNanoseconds: UInt64? = nil
  ) {
    precondition(scaleDenominator != 0, "scaleDenominator must be non-zero")
    self.correlationID = correlationID
    self.sourceDomain = sourceDomain
    self.destinationDomain = destinationDomain
    self.offsetNanoseconds = offsetNanoseconds
    self.scaleNumerator = scaleNumerator
    self.scaleDenominator = scaleDenominator
    self.authority = authority
    self.method = method
    self.validFromNanoseconds = validFromNanoseconds
    self.validUntilNanoseconds = validUntilNanoseconds
  }

  /// Deterministic conversion: `dest = source * numerator / denominator + offset`.
  public func convertSourceToDestination(sourceTimestampNs: UInt64) -> Int64 {
    let scaled = (Int64(sourceTimestampNs) * scaleNumerator) / scaleDenominator
    return scaled + offsetNanoseconds
  }

  public func asDictionary() -> [String: Any] {
    var d: [String: Any] = [
      "correlation_id": correlationID,
      "source_domain": sourceDomain.rawValue,
      "destination_domain": destinationDomain.rawValue,
      "offset_nanoseconds": offsetNanoseconds,
      "scale_numerator": scaleNumerator,
      "scale_denominator": scaleDenominator,
      "authority": authority,
      "method": method,
    ]
    if let validFromNanoseconds {
      d["valid_from_nanoseconds"] = validFromNanoseconds
    }
    if let validUntilNanoseconds {
      d["valid_until_nanoseconds"] = validUntilNanoseconds
    }
    return d
  }
}
