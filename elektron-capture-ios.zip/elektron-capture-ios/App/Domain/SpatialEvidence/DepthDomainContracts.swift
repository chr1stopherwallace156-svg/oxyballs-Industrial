import Foundation

// MARK: - Depth domain enumerations (Sprint 3.3)

public enum DepthSourceKind: String, Codable, Sendable, Equatable, CaseIterable {
  case fixture = "FIXTURE"
  case synthetic = "SYNTHETIC"
  case appleSceneDepth = "APPLE_SCENE_DEPTH"
  case appleSmoothedSceneDepth = "APPLE_SMOOTHED_SCENE_DEPTH"
  case appleCapturedDepthData = "APPLE_CAPTURED_DEPTH_DATA"
  case unknown = "UNKNOWN"
}

public enum DepthPixelFormat: String, Codable, Sendable, Equatable, CaseIterable {
  case float32Meters = "FLOAT32_METERS"
  case opaqueBytes = "OPAQUE_BYTES"
}

public enum DepthUnit: String, Codable, Sendable, Equatable, CaseIterable {
  case meters = "meters"
  case millimeters = "millimeters"
}

public enum DepthInvalidValueEncoding: String, Codable, Sendable, Equatable, CaseIterable {
  case noneDeclared = "NONE_DECLARED"
  case negativeSentinel = "NEGATIVE_SENTINEL"
  case nanSentinel = "NAN_SENTINEL"
}

public enum DepthFailureReason: String, Codable, Sendable, Equatable, CaseIterable {
  case none = "NONE"
  case unavailableDevice = "UNAVAILABLE_DEVICE"
  case unavailableConfiguration = "UNAVAILABLE_CONFIGURATION"
  case activationFailed = "ACTIVATION_FAILED"
  case interruptedAfterActivation = "INTERRUPTED_AFTER_ACTIVATION"
  case permissionDenied = "PERMISSION_DENIED"
  case invalidPayload = "INVALID_PAYLOAD"
  case unknown = "UNKNOWN"
}

/// Semantic depth capability outcomes — aliases onto `SpatialCapabilityFinalOutcome` raw values.
public enum DepthCapabilityOutcome: String, Codable, Sendable, Equatable, CaseIterable {
  case acquired = "ACQUIRED"
  case notRequested = "NOT_REQUESTED"
  case unavailableDevice = "UNAVAILABLE_DEVICE"
  case unavailableConfiguration = "UNAVAILABLE_CONFIGURATION"
  case activationFailed = "ACTIVATION_FAILED"
  case interruptedAfterActivation = "INTERRUPTED_AFTER_ACTIVATION"

  public var asSpatialOutcome: SpatialCapabilityFinalOutcome {
    SpatialCapabilityFinalOutcome(rawValue: rawValue) ?? .failed
  }

  public static func from(spatial: SpatialCapabilityFinalOutcome) -> DepthCapabilityOutcome? {
    DepthCapabilityOutcome(rawValue: spatial.rawValue)
  }

  public var mayProduceDepthEvidence: Bool {
    self == .acquired
  }
}

public struct DepthConfidenceMapDescriptor: Sendable, Equatable {
  public let artifactID: String
  public let relativePath: String
  public let width: Int
  public let height: Int
  public let pixelFormat: String
  public let byteLength: Int
  public let sha256: String

  public init(
    artifactID: String,
    relativePath: String,
    width: Int,
    height: Int,
    pixelFormat: String,
    byteLength: Int,
    sha256: String
  ) {
    self.artifactID = artifactID
    self.relativePath = relativePath
    self.width = width
    self.height = height
    self.pixelFormat = pixelFormat
    self.byteLength = byteLength
    self.sha256 = sha256
  }

  public func asDictionary() -> [String: Any] {
    [
      "artifact_id": artifactID,
      "relative_path": relativePath,
      "width": width,
      "height": height,
      "pixel_format": pixelFormat,
      "byte_length": byteLength,
      "sha256": sha256,
    ]
  }
}

public struct DepthValidityMapDescriptor: Sendable, Equatable {
  public let artifactID: String
  public let relativePath: String
  public let width: Int
  public let height: Int
  public let pixelFormat: String
  public let byteLength: Int
  public let sha256: String

  public init(
    artifactID: String,
    relativePath: String,
    width: Int,
    height: Int,
    pixelFormat: String,
    byteLength: Int,
    sha256: String
  ) {
    self.artifactID = artifactID
    self.relativePath = relativePath
    self.width = width
    self.height = height
    self.pixelFormat = pixelFormat
    self.byteLength = byteLength
    self.sha256 = sha256
  }

  public func asDictionary() -> [String: Any] {
    [
      "artifact_id": artifactID,
      "relative_path": relativePath,
      "width": width,
      "height": height,
      "pixel_format": pixelFormat,
      "byte_length": byteLength,
      "sha256": sha256,
    ]
  }
}

public struct DepthArtifactDescriptor: Sendable, Equatable {
  public let artifactID: String
  public let relativePath: String
  public let width: Int
  public let height: Int
  public let rowStrideBytes: Int
  public let pixelFormat: DepthPixelFormat
  public let byteOrder: String
  public let depthUnit: DepthUnit
  public let byteLength: Int
  public let sha256: String

  public init(
    artifactID: String,
    relativePath: String,
    width: Int,
    height: Int,
    rowStrideBytes: Int,
    pixelFormat: DepthPixelFormat,
    byteOrder: String,
    depthUnit: DepthUnit,
    byteLength: Int,
    sha256: String
  ) {
    self.artifactID = artifactID
    self.relativePath = relativePath
    self.width = width
    self.height = height
    self.rowStrideBytes = rowStrideBytes
    self.pixelFormat = pixelFormat
    self.byteOrder = byteOrder
    self.depthUnit = depthUnit
    self.byteLength = byteLength
    self.sha256 = sha256
  }

  public func asDictionary() -> [String: Any] {
    [
      "artifact_id": artifactID,
      "relative_path": relativePath,
      "width": width,
      "height": height,
      "row_stride_bytes": rowStrideBytes,
      "pixel_format": pixelFormat.rawValue,
      "byte_order": byteOrder,
      "depth_unit": depthUnit.rawValue,
      "byte_length": byteLength,
      "sha256": sha256,
    ]
  }
}

public struct DepthCalibration: Sendable, Equatable {
  public static let schemaID = "DepthCalibration"
  public static let schemaVersion = "1.0.0-phase3-fixture"

  public let calibrationID: String
  public let depthWidth: Int
  public let depthHeight: Int
  public let cameraReferenceWidth: Int
  public let cameraReferenceHeight: Int
  /// Row-major 3×3 intrinsics.
  public let intrinsicsMatrix: [Double]
  public let focalLengthX: Double
  public let focalLengthY: Double
  public let principalPointX: Double
  public let principalPointY: Double
  public let depthScale: Double
  public let distortionModel: String
  public let distortionParameters: [Double]
  public let depthFrameID: String
  public let cameraFrameID: String
  public let depthToCameraTransformID: String
  public let units: String
  public let frameEpochID: String
  public let sessionRunID: String
  public let worldOriginRevision: UInt64
  public let evidenceOriginAuthority: String
  public let characterizationStatus: String
  public let systemTolerance: String

  public init(
    calibrationID: String,
    depthWidth: Int,
    depthHeight: Int,
    cameraReferenceWidth: Int,
    cameraReferenceHeight: Int,
    intrinsicsMatrix: [Double],
    focalLengthX: Double,
    focalLengthY: Double,
    principalPointX: Double,
    principalPointY: Double,
    depthScale: Double = 1.0,
    distortionModel: String = "NONE",
    distortionParameters: [Double] = [],
    depthFrameID: String,
    cameraFrameID: String,
    depthToCameraTransformID: String,
    units: String = "meters",
    frameEpochID: String,
    sessionRunID: String,
    worldOriginRevision: UInt64,
    evidenceOriginAuthority: String = "TEST_FIXTURE",
    characterizationStatus: String = "PENDING_CHARACTERIZATION",
    systemTolerance: String = "NO_SYSTEM_TOLERANCE_ASSIGNED"
  ) {
    self.calibrationID = calibrationID
    self.depthWidth = depthWidth
    self.depthHeight = depthHeight
    self.cameraReferenceWidth = cameraReferenceWidth
    self.cameraReferenceHeight = cameraReferenceHeight
    self.intrinsicsMatrix = intrinsicsMatrix
    self.focalLengthX = focalLengthX
    self.focalLengthY = focalLengthY
    self.principalPointX = principalPointX
    self.principalPointY = principalPointY
    self.depthScale = depthScale
    self.distortionModel = distortionModel
    self.distortionParameters = distortionParameters
    self.depthFrameID = depthFrameID
    self.cameraFrameID = cameraFrameID
    self.depthToCameraTransformID = depthToCameraTransformID
    self.units = units
    self.frameEpochID = frameEpochID
    self.sessionRunID = sessionRunID
    self.worldOriginRevision = worldOriginRevision
    self.evidenceOriginAuthority = evidenceOriginAuthority
    self.characterizationStatus = characterizationStatus
    self.systemTolerance = systemTolerance
  }

  public func asDictionary() -> [String: Any] {
    [
      "calibration_id": calibrationID,
      "schema_id": Self.schemaID,
      "schema_version": Self.schemaVersion,
      "depth_width": depthWidth,
      "depth_height": depthHeight,
      "camera_reference_width": cameraReferenceWidth,
      "camera_reference_height": cameraReferenceHeight,
      "intrinsics_matrix": intrinsicsMatrix,
      "focal_length_x": focalLengthX,
      "focal_length_y": focalLengthY,
      "principal_point_x": principalPointX,
      "principal_point_y": principalPointY,
      "depth_scale": depthScale,
      "distortion_model": distortionModel,
      "distortion_parameters": distortionParameters,
      "depth_frame_id": depthFrameID,
      "camera_frame_id": cameraFrameID,
      "depth_to_camera_transform_id": depthToCameraTransformID,
      "units": units,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "evidence_origin_authority": evidenceOriginAuthority,
      "characterization_status": characterizationStatus,
      "system_tolerance": systemTolerance,
    ]
  }
}

public struct RGBDepthAssociationRecord: Sendable, Equatable {
  public let associationID: String
  public let cameraSampleID: String
  public let depthSampleID: String
  public let cameraClockDomain: ClockDomain
  public let depthClockDomain: ClockDomain
  public let correlationID: String
  public let associationTimestampNanoseconds: UInt64
  public let timestampDifferenceNanoseconds: Int64
  public let calibrationID: String
  public let cameraFrameID: String
  public let depthFrameID: String
  public let transformID: String
  public let frameEpochID: String
  public let sessionRunID: String
  public let worldOriginRevision: UInt64
  public let associationMethod: String
  public let evidenceOriginAuthority: String

  public init(
    associationID: String,
    cameraSampleID: String,
    depthSampleID: String,
    cameraClockDomain: ClockDomain,
    depthClockDomain: ClockDomain,
    correlationID: String,
    associationTimestampNanoseconds: UInt64,
    timestampDifferenceNanoseconds: Int64,
    calibrationID: String,
    cameraFrameID: String,
    depthFrameID: String,
    transformID: String,
    frameEpochID: String,
    sessionRunID: String,
    worldOriginRevision: UInt64,
    associationMethod: String = "explicit_fixture_binding",
    evidenceOriginAuthority: String = "TEST_FIXTURE"
  ) {
    self.associationID = associationID
    self.cameraSampleID = cameraSampleID
    self.depthSampleID = depthSampleID
    self.cameraClockDomain = cameraClockDomain
    self.depthClockDomain = depthClockDomain
    self.correlationID = correlationID
    self.associationTimestampNanoseconds = associationTimestampNanoseconds
    self.timestampDifferenceNanoseconds = timestampDifferenceNanoseconds
    self.calibrationID = calibrationID
    self.cameraFrameID = cameraFrameID
    self.depthFrameID = depthFrameID
    self.transformID = transformID
    self.frameEpochID = frameEpochID
    self.sessionRunID = sessionRunID
    self.worldOriginRevision = worldOriginRevision
    self.associationMethod = associationMethod
    self.evidenceOriginAuthority = evidenceOriginAuthority
  }

  public func asDictionary() -> [String: Any] {
    [
      "association_id": associationID,
      "camera_sample_id": cameraSampleID,
      "depth_sample_id": depthSampleID,
      "camera_clock_domain": cameraClockDomain.rawValue,
      "depth_clock_domain": depthClockDomain.rawValue,
      "correlation_id": correlationID,
      "association_timestamp_nanoseconds": associationTimestampNanoseconds,
      "timestamp_difference_nanoseconds": timestampDifferenceNanoseconds,
      "calibration_id": calibrationID,
      "camera_frame_id": cameraFrameID,
      "depth_frame_id": depthFrameID,
      "transform_id": transformID,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "association_method": associationMethod,
      "evidence_origin_authority": evidenceOriginAuthority,
    ]
  }
}

/// Foundation-portable depth sensor adapter contract.
public protocol DepthSensorAdapter: Sendable {
  var capability: SpatialStreamCapability { get }
  var adapterID: String { get }
  func start() async throws
  func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<DepthSample>, Error>
  func stop() async
}

/// Deterministic Float32-meters depth payload helpers for fixtures.
public enum FixtureDepthPayload {
  public static let width = 4
  public static let height = 4
  public static let bytesPerPixel = 4
  public static let rowStrideBytes = width * bytesPerPixel
  public static let byteOrder = "little_endian"
  public static let invalidSentinel: Float = -1.0

  /// 4×4 Float32 LE meters: ramp 0.5…2.0 with one negative sentinel at [3,3].
  public static func deterministicBytes() -> Data {
    var data = Data()
    data.reserveCapacity(width * height * bytesPerPixel)
    for y in 0..<height {
      for x in 0..<width {
        let value: Float
        if x == width - 1 && y == height - 1 {
          value = invalidSentinel
        } else {
          value = 0.5 + Float(x) * 0.25 + Float(y) * 0.25
        }
        var le = value.bitPattern.littleEndian
        withUnsafeBytes(of: &le) { data.append(contentsOf: $0) }
      }
    }
    return data
  }

  public static func expectedByteLength() -> Int {
    height * rowStrideBytes
  }
}
