import Foundation

/// Deterministic reconstruction fixture depth: planar Z=2.0m, one invalid sentinel.
public enum ReconstructionFixtureDepthPayload {
  public static let width = 4
  public static let height = 4
  public static let bytesPerPixel = 4
  public static let rowStrideBytes = width * bytesPerPixel
  public static let byteOrder = "little_endian"
  public static let planeZ: Float = 2.0
  public static let invalidSentinel: Float = -1.0
  public static let fx = 100.0
  public static let fy = 100.0
  public static let cx = 1.5
  public static let cy = 1.5

  public static func deterministicBytes() -> Data {
    var data = Data()
    data.reserveCapacity(width * height * bytesPerPixel)
    for y in 0..<height {
      for x in 0..<width {
        let value: Float = (x == width - 1 && y == height - 1) ? invalidSentinel : planeZ
        var le = value.bitPattern.littleEndian
        withUnsafeBytes(of: &le) { data.append(contentsOf: $0) }
      }
    }
    return data
  }
}

/// Builds SPKG-FIXTURE-RECONSTRUCTION-000001 — camera + depth + pose with known planar geometry.
public struct FixtureReconstructionPackageBuilder: Sendable {
  public static let primaryPackageID = "SPKG-FIXTURE-RECONSTRUCTION-000001"
  public static let primarySessionID = "SESS-FIXTURE-RECONSTRUCTION-000001"
  public static let frameEpochID = "epoch-fixture-reconstruction-1"
  public static let sessionRunID = "run-fixture-reconstruction-1"
  public static let worldOriginRevision: UInt64 = 1
  public static let cameraToDepthCorrelationID = "fixture-recon-camera-to-depth-000001"
  public static let cameraToPoseCorrelationID = "fixture-recon-camera-to-arkit-000001"
  public static let cameraToMotionCorrelationID = "fixture-recon-camera-to-motion-000001"
  public static let depthToCameraTransformID = "XF-DEPTH-TO-CAMERA-RECON-000001"
  public static let cameraToRootTransformID = "XF-CAMERA-TO-ROOT-RECON-000001"
  public static let calibrationID = "CAL-FIXTURE-RECONSTRUCTION-000001"
  public static let reconstructionOutputID = "RECON-OUT-FIXTURE-000001"

  public init() {}

  public struct SealResult: Sendable {
    public var package: SpatialEvidencePackage
    public var geometry: FixtureReconstructionGeometry
    public var sourcePackageBytesSHA256: String
  }

  public func sealPrimary(outputDirectory: URL) throws -> SealResult {
    try seal(outputDirectory: outputDirectory, frameCount: 2, allowReconstruction: true)
  }

  public func seal(
    outputDirectory: URL,
    frameCount: Int = 2,
    allowReconstruction: Bool = true,
    packageID: String = FixtureReconstructionPackageBuilder.primaryPackageID,
    captureSessionID: String = FixtureReconstructionPackageBuilder.primarySessionID,
    createdAtUTC: String = "2026-08-04T04:00:00Z"
  ) throws -> SealResult {
    precondition(!packageID.hasPrefix("SPKG-DEVICE-"))
    precondition(frameCount >= 1)

    let camera = makeCameraSamples(count: frameCount)
    let motion = makeMotionSamples(count: frameCount)
    let pose = makePoseSamples(count: frameCount)
    let depth = makeDepthSamples(count: frameCount)
    let frames = Self.defaultFrames()
    let edges = Self.defaultTransformEdges()
    let correlations = Self.defaultClockCorrelations()
    let calibration = Self.defaultCalibration()
    let geometry = FixtureReconstructionGeometry.planarTarget()

    var camCap = SpatialStreamCapability(
      streamID: SpatialStreamID.camera,
      adapterID: "fixture.camera.reconstruction",
      sensorKind: "camera",
      declared: true
    )
    camCap.activate()
    for _ in camera { camCap.recordSample() }
    try camCap.freeze(outcome: .acquired)
    var motionCap = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "fixture.motion.reconstruction",
      sensorKind: "motion",
      declared: true
    )
    motionCap.activate()
    for _ in motion { motionCap.recordSample() }
    try motionCap.freeze(outcome: .acquired)
    var poseCap = SpatialStreamCapability(
      streamID: SpatialStreamID.pose,
      adapterID: "fixture.pose.reconstruction",
      sensorKind: "pose",
      declared: true
    )
    poseCap.activate()
    for _ in pose { poseCap.recordSample() }
    try poseCap.freeze(outcome: .acquired)
    var depthCap = SpatialStreamCapability(
      streamID: SpatialStreamID.depth,
      adapterID: "fixture.depth.reconstruction",
      sensorKind: "depth",
      declared: true
    )
    depthCap.activate()
    for _ in depth { depthCap.recordSample() }
    try depthCap.freeze(outcome: .acquired)

    let capability = SpatialCapabilitySnapshot(
      snapshotID: "CAP-\(packageID)",
      capturedAtUTC: createdAtUTC,
      streams: [camCap, motionCap, poseCap, depthCap].sorted { $0.streamID < $1.streamID },
      schemaVersion: SpatialCapabilitySnapshot.fixtureSchemaVersion
    )

    try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
    let payloadRoot = outputDirectory.appendingPathComponent("payload", isDirectory: true)
    try FileManager.default.createDirectory(at: payloadRoot, withIntermediateDirectories: true)

    var artifacts: [SpatialArtifactDescriptor] = []
    var sampleIndex: [[String: Any]] = []

    try writePayload(stream: SpatialStreamID.camera, adapterID: camCap.adapterID, samples: camera, root: payloadRoot, artifacts: &artifacts, sampleIndex: &sampleIndex) { $0.bytes }
    try writePayload(stream: SpatialStreamID.motion, adapterID: motionCap.adapterID, samples: motion, root: payloadRoot, artifacts: &artifacts, sampleIndex: &sampleIndex) { $0.bytes }
    try writePayload(stream: SpatialStreamID.pose, adapterID: poseCap.adapterID, samples: pose, root: payloadRoot, artifacts: &artifacts, sampleIndex: &sampleIndex) { $0.bytes }
    try writePayload(stream: SpatialStreamID.depth, adapterID: depthCap.adapterID, samples: depth, root: payloadRoot, artifacts: &artifacts, sampleIndex: &sampleIndex) { $0.bytes }

    for sample in depth { try DepthSampleValidator.validate(sample.payload) }
    for sample in pose { try PoseMathValidator.validatePoseSample(sample.payload) }
    try PoseWorldEpochValidator.requireHomogeneousPackageEpoch(pose.map(\.payload))

    let graph = CoordinateFrameGraph(frames: frames, edges: edges)
    try graph.validateRegistry()
    try graph.validateEdgesReferenceKnownFrames()
    try graph.validateTransformGraph()
    try TransformEdgeValidator.validateAll(
      edges: edges,
      frames: frames,
      poseSampleIDs: Set(pose.map(\.sampleID)),
      packageSessionRunID: Self.sessionRunID,
      packageFrameEpochID: Self.frameEpochID,
      packageWorldOriginRevision: Self.worldOriginRevision
    )

    try DepthCalibrationValidator.validate(
      calibration,
      depthSample: depth.first?.payload,
      frames: frames,
      transformIDs: Set(edges.map(\.transformID)),
      packageFrameEpochID: Self.frameEpochID,
      packageSessionRunID: Self.sessionRunID,
      packageWorldOriginRevision: Self.worldOriginRevision
    )

    let depthAssociations = try Self.defaultDepthAssociations(camera: camera, depth: depth, correlations: correlations)
    try RGBDepthAssociationValidator.validate(
      associations: depthAssociations,
      cameraSamples: camera,
      depthSamples: depth,
      correlations: correlations,
      calibrations: [calibration],
      frames: frames,
      transformEdges: edges,
      packageFrameEpochID: Self.frameEpochID,
      packageSessionRunID: Self.sessionRunID,
      packageWorldOriginRevision: Self.worldOriginRevision
    )

    let poseAssociations = try Self.defaultPoseAssociations(camera: camera, pose: pose, correlations: correlations)
    try PoseAssociationValidator.validateAll(
      cameraSamples: camera,
      poseSamples: pose,
      associations: poseAssociations,
      correlations: correlations
    )

    try writeJSON(capability.asDictionary(), to: outputDirectory.appendingPathComponent("capability_snapshot.json"))
    try writeJSON(["correlations": correlations.map { $0.asDictionary() }], to: outputDirectory.appendingPathComponent("clock_correlation.json"))
    try writeJSON(["frames": frames.map { $0.asDictionary() }], to: outputDirectory.appendingPathComponent("coordinate_frames.json"))
    try writeJSON(
      [
        "calibrations": [calibration.asDictionary()],
        "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
        "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED",
      ],
      to: outputDirectory.appendingPathComponent("depth_calibration.json")
    )
    try writeJSON(["associations": depthAssociations.map { $0.asDictionary() }], to: outputDirectory.appendingPathComponent("rgb_depth_associations.json"))
    try writeJSON(["associations": poseAssociations.map { $0.asDictionary() }], to: outputDirectory.appendingPathComponent("pose_associations.json"))
    try writeJSON(
      [
        "edges": edges.map { $0.asDictionary() },
        "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
        "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED",
      ],
      to: outputDirectory.appendingPathComponent("transform_graph.json")
    )
    try writeJSON(geometry.dictionary(), to: outputDirectory.appendingPathComponent("fixture_geometry.json"))

    var privacy = EvidencePrivacyPolicy.fixtureRawRestricted()
    privacy.policyID = "POL-FIXTURE-RECONSTRUCTION-000001"
    if allowReconstruction {
      privacy.exportRestrictions = ["NO_RESTRICTED_RAW_IN_INSPECTION_PROFILE"]
      privacy.applicabilityConditions.append("reconstruction_input_allowed")
    } else {
      privacy.exportRestrictions = ["NO_RECONSTRUCTION_INPUT"]
      privacy.applicabilityConditions.append("reconstruction_input_forbidden")
    }
    try writeJSON(privacy.dictionary(), to: outputDirectory.appendingPathComponent("privacy_policy.json"))

    sampleIndex.sort {
      (($0["relative_path"] as? String) ?? "") < (($1["relative_path"] as? String) ?? "")
    }
    try writeJSON(["samples": sampleIndex], to: outputDirectory.appendingPathComponent("sample_index.json"))

    let manifest = SpatialEvidenceManifest(
      packageID: packageID,
      vehicleID: "VEH-FIXTURE-RECONSTRUCTION-000001",
      captureSessionID: captureSessionID,
      pilotID: "PILOT-FIXTURE-000001",
      createdAtUTC: createdAtUTC,
      capability: capability,
      frames: frames,
      clockCorrelations: correlations,
      artifacts: artifacts,
      sampleIndex: sampleIndex
    )
    var manifestDict = manifest.asDictionary()
    manifestDict["schema_id"] = "SpatialEvidenceManifest"
    manifestDict["schema_version"] = "1.0.0-phase4a-fixture"
    manifestDict["package_layout"] = "fixture_reconstruction_v1"
    manifestDict["host_claim"] = "NO_PHYSICAL_DEVICE_EXECUTION"
    manifestDict["implementation_state"] = "SOURCE_IMPLEMENTED"
    manifestDict["validation_state"] = "LINUX_FIXTURE_VALIDATED"
    manifestDict["evidence_origin_authority"] = "TEST_FIXTURE"
    manifestDict["geometry_reference_authority"] = "TEST_FIXTURE_GROUND_TRUTH"
    manifestDict["depth_estimate_authority"] = "GUIDANCE_ESTIMATE"
    manifestDict["rgb_depth_associations"] = depthAssociations.map { $0.asDictionary() }
    manifestDict["pose_associations"] = poseAssociations.map { $0.asDictionary() }
    manifestDict["depth_calibrations"] = [calibration.asDictionary()]
    manifestDict["transform_edges"] = edges.map { $0.asDictionary() }
    manifestDict["frame_epoch_id"] = Self.frameEpochID
    manifestDict["session_run_id"] = Self.sessionRunID
    manifestDict["world_origin_revision"] = Self.worldOriginRevision
    manifestDict["privacy_policy_id"] = privacy.policyID
    manifestDict["reconstruction_input_allowed"] = allowReconstruction

    let manifestData = try CanonicalJSON.data(manifestDict)
    try manifestData.write(to: outputDirectory.appendingPathComponent("manifest.json"), options: .atomic)
    let manifestSHA = ContentHasher.sha256Hex(manifestData)

    let inventoryEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputDirectory)
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(packageRoot: outputDirectory, entries: inventoryEntries)
    let packageClosureHash = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: inventoryEntries)
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": packageClosureHash,
      "entries": inventoryEntries,
    ]
    try writeJSON(inventory, to: outputDirectory.appendingPathComponent("package_inventory.json"))

    try SpatialPackageClosureVerifier.verifyDevicePayload(packageRoot: outputDirectory, manifestArtifacts: artifacts)
    let packageHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outputDirectory)

    let pkg = SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: manifestSHA,
      packageClosureSHA256: packageClosureHash
    )
    return SealResult(package: pkg, geometry: geometry, sourcePackageBytesSHA256: packageHash)
  }

  // MARK: - Samples

  private func makeCameraSamples(count: Int) -> [SpatialSampleEnvelope<CameraSample>] {
    (0..<count).map { i in
      var bytes = Data(count: 16)
      for b in 0..<16 { bytes[b] = UInt8((i * 5 + b) & 0xff) }
      let payload = CameraSample(
        width: 4, height: 4, pixelFormat: "BGRA8", bytes: bytes,
        orientation: "up", cameraIdentity: "recon-fixture-camera", intrinsicsAvailable: true
      )
      return SpatialSampleEnvelope(
        sampleID: "recon-cam-\(i)",
        sequenceIndex: UInt64(i),
        acquisitionTimestampNs: UInt64(i + 1) * 33_333_333,
        clockDomain: .fixtureCamera,
        coordinateFrameID: "FRAME_CAMERA_OPTICAL",
        payload: payload,
        mediaType: "application/octet-stream",
        schemaID: "CameraSample",
        schemaVersion: "1.0.0-phase3-fixture"
      )
    }
  }

  private func makeMotionSamples(count: Int) -> [SpatialSampleEnvelope<MotionSample>] {
    (0..<count).map { i in
      let accel = [Double(i), 0.0, 9.81]
      let gyro = [0.01 * Double(i), 0.0, 0.0]
      let grav = [0.0, 0.0, -1.0]
      let user = [0.0, 0.0, 0.0]
      let quat = [0.0, 0.0, 0.0, 1.0]
      var bytes = Data()
      for v in accel + gyro + grav + user + quat {
        var le = v.bitPattern.littleEndian
        withUnsafeBytes(of: &le) { bytes.append(contentsOf: $0) }
      }
      let payload = MotionSample(
        accelerationXYZ: accel, rotationRateXYZ: gyro, attitudeQuaternion: quat, bytes: bytes,
        gravityXYZ: grav, userAccelerationXYZ: user, samplingIntervalNs: 10_000_000
      )
      return SpatialSampleEnvelope(
        sampleID: "recon-motion-\(i)",
        sequenceIndex: UInt64(i),
        acquisitionTimestampNs: UInt64(i + 1) * 33_333_333,
        clockDomain: .fixtureMotion,
        coordinateFrameID: "FRAME_DEVICE_IMU",
        payload: payload,
        mediaType: "application/octet-stream",
        schemaID: "MotionSample",
        schemaVersion: "1.0.0-phase3-fixture"
      )
    }
  }

  private func makePoseSamples(count: Int) -> [SpatialSampleEnvelope<PoseSample>] {
    (0..<count).map { i in
      let translation = Vector3D(x: 0, y: 0, z: 0)
      let rotation = QuaternionD.identity
      let matrix = PoseSample.matrix4x4(translation: translation, rotation: rotation)
      var bytes = Data()
      for v in matrix {
        var le = v.bitPattern.littleEndian
        withUnsafeBytes(of: &le) { bytes.append(contentsOf: $0) }
      }
      let payload = PoseSample(
        translationMeters: translation,
        rotationQuaternion: rotation,
        trackingState: .normal,
        trackingReason: nil,
        timestampNanoseconds: UInt64(i + 1) * 33_333_333,
        clockDomain: .arkitFrame,
        sourceFrameID: "FRAME_AR_SESSION_WORLD",
        destinationFrameID: "FRAME_CAPTURE_SESSION_ROOT",
        authority: "GUIDANCE_ESTIMATE",
        frameEpochID: Self.frameEpochID,
        sessionRunID: Self.sessionRunID,
        worldOriginRevision: Self.worldOriginRevision,
        bytes: bytes
      )
      return SpatialSampleEnvelope(
        sampleID: "recon-pose-\(i)",
        sequenceIndex: UInt64(i),
        acquisitionTimestampNs: UInt64(i + 1) * 33_333_333,
        clockDomain: .arkitFrame,
        coordinateFrameID: "FRAME_AR_SESSION_WORLD",
        payload: payload,
        mediaType: "application/octet-stream",
        schemaID: "PoseSample",
        schemaVersion: "1.0.0-phase3-fixture"
      )
    }
  }

  private func makeDepthSamples(count: Int) -> [SpatialSampleEnvelope<DepthSample>] {
    (0..<count).map { i in
      let bytes = ReconstructionFixtureDepthPayload.deterministicBytes()
      let artifactID = "recon-depth-artifact-\(i)"
      let payload = DepthSample(
        width: ReconstructionFixtureDepthPayload.width,
        height: ReconstructionFixtureDepthPayload.height,
        bytes: bytes,
        sourceKind: .fixture,
        pixelFormat: .float32Meters,
        byteOrder: ReconstructionFixtureDepthPayload.byteOrder,
        rowStrideBytes: ReconstructionFixtureDepthPayload.rowStrideBytes,
        depthUnit: .meters,
        minimumValidDepth: 0.1,
        maximumValidDepth: 10.0,
        invalidValueEncoding: .negativeSentinel,
        depthArtifactID: artifactID,
        calibrationID: Self.calibrationID,
        confidenceArtifactID: nil,
        validityArtifactID: nil,
        confidenceAbsenceReason: "OPTIONAL_CONFIDENCE_NOT_EMITTED_BY_FIXTURE",
        validityAbsenceReason: "OPTIONAL_VALIDITY_NOT_EMITTED_BY_FIXTURE",
        timestampNanoseconds: UInt64(i + 1) * 33_333_333,
        clockDomain: .fixtureDepth,
        coordinateFrameID: "FRAME_DEPTH_SENSOR",
        frameEpochID: Self.frameEpochID,
        sessionRunID: Self.sessionRunID,
        worldOriginRevision: Self.worldOriginRevision,
        evidenceOriginAuthority: "TEST_FIXTURE",
        depthEstimateAuthority: "GUIDANCE_ESTIMATE",
        adapterID: "fixture.depth.reconstruction"
      )
      return SpatialSampleEnvelope(
        sampleID: "recon-depth-\(i)",
        sequenceIndex: UInt64(i),
        acquisitionTimestampNs: UInt64(i + 1) * 33_333_333,
        clockDomain: .fixtureDepth,
        coordinateFrameID: "FRAME_DEPTH_SENSOR",
        payload: payload,
        mediaType: "application/octet-stream",
        schemaID: "DepthSample",
        schemaVersion: "1.0.0-phase3-fixture"
      )
    }
  }

  // MARK: - Defaults

  public static func defaultFrames() -> [CoordinateFrameDescriptor] {
    let auth = "TEST_FIXTURE"
    return [
      CoordinateFrameDescriptor(frameID: "FRAME_CAPTURE_SESSION_ROOT", units: "meters", handedness: "right", matrixStorageOrder: "column_major", opticalAxisConvention: "opencv", clockDomain: .fixtureCamera, authority: auth),
      CoordinateFrameDescriptor(frameID: "FRAME_CAMERA_OPTICAL", units: "meters", handedness: "right", matrixStorageOrder: "column_major", opticalAxisConvention: "opencv", clockDomain: .fixtureCamera, authority: auth),
      CoordinateFrameDescriptor(frameID: "FRAME_DEVICE_IMU", units: "meters", handedness: "right", matrixStorageOrder: "column_major", opticalAxisConvention: "none", clockDomain: .fixtureMotion, authority: auth),
      CoordinateFrameDescriptor(frameID: "FRAME_AR_SESSION_WORLD", units: "meters", handedness: "right", matrixStorageOrder: "column_major", opticalAxisConvention: "arkit", clockDomain: .arkitFrame, authority: auth),
      CoordinateFrameDescriptor(frameID: "FRAME_DEPTH_SENSOR", units: "meters", handedness: "right", matrixStorageOrder: "column_major", opticalAxisConvention: "opencv", clockDomain: .fixtureDepth, authority: auth),
    ]
  }

  public static func defaultTransformEdges() -> [TransformEdge] {
    let m = HomogeneousMatrix4x4.identity()
    return [
      TransformEdge(transformID: cameraToRootTransformID, fromFrameID: "FRAME_CAMERA_OPTICAL", toFrameID: "FRAME_CAPTURE_SESSION_ROOT", frameEpochID: frameEpochID, sessionRunID: sessionRunID, worldOriginRevision: worldOriginRevision, timestampNanoseconds: 0, clockDomain: .fixtureCamera, matrix: m, authority: "TEST_FIXTURE", sourceSampleID: TransformEdge.fixtureStaticSourceSampleID),
      TransformEdge(transformID: "XF-IMU-TO-ROOT-RECON-000001", fromFrameID: "FRAME_DEVICE_IMU", toFrameID: "FRAME_CAPTURE_SESSION_ROOT", frameEpochID: frameEpochID, sessionRunID: sessionRunID, worldOriginRevision: worldOriginRevision, timestampNanoseconds: 0, clockDomain: .fixtureMotion, matrix: m, authority: "TEST_FIXTURE", sourceSampleID: TransformEdge.fixtureStaticSourceSampleID),
      TransformEdge(transformID: "XF-AR-TO-ROOT-RECON-000001", fromFrameID: "FRAME_AR_SESSION_WORLD", toFrameID: "FRAME_CAPTURE_SESSION_ROOT", frameEpochID: frameEpochID, sessionRunID: sessionRunID, worldOriginRevision: worldOriginRevision, timestampNanoseconds: 0, clockDomain: .arkitFrame, matrix: m, authority: "TEST_FIXTURE", sourceSampleID: TransformEdge.fixtureStaticSourceSampleID),
      TransformEdge(transformID: "XF-CAMERA-TO-AR-RECON-000001", fromFrameID: "FRAME_CAMERA_OPTICAL", toFrameID: "FRAME_AR_SESSION_WORLD", frameEpochID: frameEpochID, sessionRunID: sessionRunID, worldOriginRevision: worldOriginRevision, timestampNanoseconds: 0, clockDomain: .arkitFrame, matrix: m, authority: "TEST_FIXTURE", sourceSampleID: TransformEdge.fixtureStaticSourceSampleID),
      TransformEdge(transformID: depthToCameraTransformID, fromFrameID: "FRAME_DEPTH_SENSOR", toFrameID: "FRAME_CAMERA_OPTICAL", frameEpochID: frameEpochID, sessionRunID: sessionRunID, worldOriginRevision: worldOriginRevision, timestampNanoseconds: 0, clockDomain: .fixtureDepth, matrix: m, authority: "TEST_FIXTURE", sourceSampleID: TransformEdge.fixtureStaticSourceSampleID),
      TransformEdge(transformID: "XF-CAMERA-TO-DEPTH-RECON-000001", fromFrameID: "FRAME_CAMERA_OPTICAL", toFrameID: "FRAME_DEPTH_SENSOR", frameEpochID: frameEpochID, sessionRunID: sessionRunID, worldOriginRevision: worldOriginRevision, timestampNanoseconds: 0, clockDomain: .fixtureCamera, matrix: m, authority: "TEST_FIXTURE", sourceSampleID: TransformEdge.fixtureStaticSourceSampleID),
    ]
  }

  public static func defaultClockCorrelations() -> [ClockCorrelation] {
    [
      ClockCorrelation(correlationID: cameraToMotionCorrelationID, sourceDomain: .fixtureCamera, destinationDomain: .fixtureMotion, offsetNanoseconds: 0, authority: "TEST_FIXTURE", method: "explicit_fixture_identity", validFromNanoseconds: 0, validUntilNanoseconds: 10_000_000_000),
      ClockCorrelation(correlationID: cameraToPoseCorrelationID, sourceDomain: .fixtureCamera, destinationDomain: .arkitFrame, offsetNanoseconds: 0, authority: "TEST_FIXTURE", method: "explicit_fixture_cross_domain", validFromNanoseconds: 0, validUntilNanoseconds: 10_000_000_000),
      ClockCorrelation(correlationID: cameraToDepthCorrelationID, sourceDomain: .fixtureCamera, destinationDomain: .fixtureDepth, offsetNanoseconds: 0, authority: "TEST_FIXTURE", method: "explicit_fixture_identity", validFromNanoseconds: 0, validUntilNanoseconds: 10_000_000_000),
    ]
  }

  public static func defaultCalibration() -> DepthCalibration {
    let fx = ReconstructionFixtureDepthPayload.fx
    let fy = ReconstructionFixtureDepthPayload.fy
    let cx = ReconstructionFixtureDepthPayload.cx
    let cy = ReconstructionFixtureDepthPayload.cy
    return DepthCalibration(
      calibrationID: calibrationID,
      depthWidth: ReconstructionFixtureDepthPayload.width,
      depthHeight: ReconstructionFixtureDepthPayload.height,
      cameraReferenceWidth: 4,
      cameraReferenceHeight: 4,
      intrinsicsMatrix: [fx, 0, cx, 0, fy, cy, 0, 0, 1],
      focalLengthX: fx,
      focalLengthY: fy,
      principalPointX: cx,
      principalPointY: cy,
      depthScale: 1.0,
      distortionModel: "NONE",
      distortionParameters: [],
      depthFrameID: "FRAME_DEPTH_SENSOR",
      cameraFrameID: "FRAME_CAMERA_OPTICAL",
      depthToCameraTransformID: depthToCameraTransformID,
      units: "meters",
      frameEpochID: frameEpochID,
      sessionRunID: sessionRunID,
      worldOriginRevision: worldOriginRevision,
      evidenceOriginAuthority: "TEST_FIXTURE"
    )
  }

  public static func defaultDepthAssociations(
    camera: [SpatialSampleEnvelope<CameraSample>],
    depth: [SpatialSampleEnvelope<DepthSample>],
    correlations: [ClockCorrelation]
  ) throws -> [RGBDepthAssociationRecord] {
    guard let corr = correlations.first(where: { $0.correlationID == cameraToDepthCorrelationID }) else {
      throw SpatialEvidenceError.unknownClockCorrelationID(cameraToDepthCorrelationID)
    }
    return (0..<min(camera.count, depth.count)).map { i in
      let cam = camera[i]
      let dep = depth[i]
      let converted = corr.convertSourceToDestination(sourceTimestampNs: cam.acquisitionTimestampNs)
      let diff = Int64(dep.acquisitionTimestampNs) - converted
      return RGBDepthAssociationRecord(
        associationID: "recon-rgb-depth-assoc-\(i)",
        cameraSampleID: cam.sampleID,
        depthSampleID: dep.sampleID,
        cameraClockDomain: cam.clockDomain,
        depthClockDomain: dep.clockDomain,
        correlationID: corr.correlationID,
        associationTimestampNanoseconds: cam.acquisitionTimestampNs,
        timestampDifferenceNanoseconds: diff,
        calibrationID: calibrationID,
        cameraFrameID: "FRAME_CAMERA_OPTICAL",
        depthFrameID: "FRAME_DEPTH_SENSOR",
        transformID: depthToCameraTransformID,
        frameEpochID: frameEpochID,
        sessionRunID: sessionRunID,
        worldOriginRevision: worldOriginRevision,
        associationMethod: "explicit_fixture_binding",
        evidenceOriginAuthority: "TEST_FIXTURE"
      )
    }
  }

  public static func defaultPoseAssociations(
    camera: [SpatialSampleEnvelope<CameraSample>],
    pose: [SpatialSampleEnvelope<PoseSample>],
    correlations: [ClockCorrelation]
  ) throws -> [PoseAssociationRecord] {
    let clockValidator = ClockCorrelationValidator(correlations: correlations)
    let corr = try clockValidator.requireByID(cameraToPoseCorrelationID)
    return try (0..<min(camera.count, pose.count)).map { i in
      try PoseAssociationValidator.makeAssociation(
        associationID: "recon-pose-assoc-\(i)",
        camera: camera[i],
        pose: pose[i],
        correlation: corr
      )
    }
  }

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    try CanonicalJSON.data(object).write(to: url, options: .atomic)
  }

  private func writePayload<Payload>(
    stream: String,
    adapterID: String,
    samples: [SpatialSampleEnvelope<Payload>],
    root: URL,
    artifacts: inout [SpatialArtifactDescriptor],
    sampleIndex: inout [[String: Any]],
    bytesOf: (Payload) -> Data
  ) throws {
    try SpatialStreamID.validate(stream)
    let dir = root.appendingPathComponent(stream, isDirectory: true)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    for (idx, sample) in samples.enumerated() {
      let schemaKey = "\(sample.schemaID)@\(sample.schemaVersion)"
      guard SpatialEvidenceManifest.supportedSchemas.contains(schemaKey) else {
        throw SpatialEvidenceError.unsupportedSchema(id: sample.schemaID, version: sample.schemaVersion)
      }
      let fileName = String(format: "%04d.bin", idx)
      let rel = "payload/\(stream)/\(fileName)"
      let data = bytesOf(sample.payload)
      try data.write(to: dir.appendingPathComponent(fileName), options: .atomic)
      let sha = ContentHasher.sha256Hex(data)
      artifacts.append(
        SpatialArtifactDescriptor(
          relativePath: rel,
          byteLength: data.count,
          sha256: sha,
          mediaType: sample.mediaType,
          schemaID: sample.schemaID,
          schemaVersion: sample.schemaVersion,
          sampleID: sample.sampleID,
          streamID: stream,
          adapterID: adapterID
        )
      )
      sampleIndex.append([
        "sample_id": sample.sampleID,
        "sequence_index": sample.sequenceIndex,
        "acquisition_timestamp_ns": sample.acquisitionTimestampNs,
        "clock_domain": sample.clockDomain.rawValue,
        "coordinate_frame_id": sample.coordinateFrameID,
        "relative_path": rel,
        "stream_id": stream,
        "adapter_id": adapterID,
      ])
    }
  }
}
