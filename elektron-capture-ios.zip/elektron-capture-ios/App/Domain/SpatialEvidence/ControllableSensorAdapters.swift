import Foundation

/// Controllable camera adapter for Linux/Foundation failure-path proofs (not AVFoundation).
public final class ControllableCameraSensorAdapter: @unchecked Sendable, CameraSensorAdapter {
  public let adapterID: String
  public private(set) var capability: SpatialStreamCapability
  public var permissionDenied = false
  public var failOnStart = false
  public var interruptAfterStart = false
  public var backgroundAfterStart = false
  public var cancelAfterStart = false
  public var unknownPixelFormat = false
  public var regressTimestamps = false
  public var emitCount: Int = 2
  /// Override for Sprint 3.3 camera+depth fixtures (default preserves Sprint 3.1/3.2 behavior).
  public var clockDomain: ClockDomain = .monotonicUptime
  public var coordinateFrameID: String = "FRAME_CAMERA_OPTICAL"

  private var started = false
  private var stopped = false
  private var lastTs: UInt64 = 0
  private var continuation: AsyncThrowingStream<SpatialSampleEnvelope<CameraSample>, Error>.Continuation?

  public init(adapterID: String = "fixture.camera") {
    self.adapterID = adapterID
    self.capability = SpatialStreamCapability(
      streamID: SpatialStreamID.camera,
      adapterID: adapterID,
      sensorKind: "camera"
    )
  }

  public func start() async throws {
    if started && !stopped { throw ProductionSensorError.alreadyStarted }
    if permissionDenied { throw ProductionSensorError.permissionDenied("camera") }
    if failOnStart { throw ProductionSensorError.unavailable("camera") }
    started = true
    stopped = false
    capability.activate()
    if interruptAfterStart {
      throw ProductionSensorError.interrupted("capture_session_interrupted")
    }
    if backgroundAfterStart {
      throw ProductionSensorError.backgrounded
    }
    if cancelAfterStart {
      throw ProductionSensorError.cancelled
    }
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<CameraSample>, Error> {
    AsyncThrowingStream { continuation in
      self.continuation = continuation
      Task {
        do {
          guard self.started, !self.stopped else {
            continuation.finish(throwing: ProductionSensorError.notStarted)
            return
          }
          for i in 0..<self.emitCount {
            if self.stopped {
              continuation.finish(throwing: ProductionSensorError.postStopSample)
              return
            }
            let pixelFormat = self.unknownPixelFormat ? "UNKNOWN_PIXEL_FMT" : "BGRA8"
            if self.unknownPixelFormat {
              continuation.finish(throwing: ProductionSensorError.unknownPixelFormat(pixelFormat))
              return
            }
            var ts = UInt64(i + 1) * 33_333_333
            if self.regressTimestamps && i == 1 {
              ts = self.lastTs &- 1
              continuation.finish(
                throwing: ProductionSensorError.timestampRegression(previous: self.lastTs, next: ts)
              )
              return
            }
            if ts <= self.lastTs && i > 0 {
              continuation.finish(
                throwing: ProductionSensorError.timestampRegression(previous: self.lastTs, next: ts)
              )
              return
            }
            self.lastTs = ts
            var bytes = Data(count: 16)
            for b in 0..<16 { bytes[b] = UInt8((i * 3 + b) & 0xff) }
            let payload = CameraSample(
              width: 4,
              height: 4,
              pixelFormat: pixelFormat,
              bytes: bytes,
              orientation: "up",
              cameraIdentity: "test-camera-0",
              intrinsicsAvailable: false
            )
            let env = SpatialSampleEnvelope<CameraSample>(
              sampleID: "cam-\(i)",
              sequenceIndex: UInt64(i),
              acquisitionTimestampNs: ts,
              clockDomain: self.clockDomain,
              coordinateFrameID: self.coordinateFrameID,
              payload: payload,
              mediaType: "application/octet-stream",
              schemaID: "CameraSample",
              schemaVersion: "1.0.0-phase3-fixture"
            )
            self.capability.recordSample()
            continuation.yield(env)
          }
          continuation.finish()
        }
      }
    }
  }

  public func stop() async {
    if stopped { return } // idempotent second stop
    stopped = true
    started = false
    continuation?.finish()
    continuation = nil
  }

  public func injectPostStopSampleAttempt() throws {
    if stopped { throw ProductionSensorError.postStopSample }
  }
}

/// Controllable motion adapter for Linux/Foundation failure-path proofs (not CoreMotion).
public final class ControllableMotionSensorAdapter: @unchecked Sendable, MotionSensorAdapter {
  public let adapterID: String
  public private(set) var capability: SpatialStreamCapability
  public var unavailable = false
  public var failOnStart = false
  public var emitCount: Int = 2
  /// Override for Sprint 3.4 coordinated fixtures (default preserves Sprint 3.1/3.2 behavior).
  public var clockDomain: ClockDomain = .coreMotion
  public var coordinateFrameID: String = "FRAME_DEVICE_IMU"
  public var interruptAfterStart = false

  private var started = false
  private var stopped = false

  public init(adapterID: String = "fixture.motion") {
    self.adapterID = adapterID
    self.capability = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: adapterID,
      sensorKind: "motion"
    )
  }

  public func start() async throws {
    if started && !stopped { throw ProductionSensorError.alreadyStarted }
    if unavailable { throw ProductionSensorError.unavailable("motion") }
    if failOnStart { throw ProductionSensorError.unavailable("motion") }
    started = true
    stopped = false
    capability.activate()
    if interruptAfterStart {
      throw ProductionSensorError.interrupted("motion_session_interrupted")
    }
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<MotionSample>, Error> {
    AsyncThrowingStream { continuation in
      Task {
        guard self.started, !self.stopped else {
          continuation.finish(throwing: ProductionSensorError.notStarted)
          return
        }
        for i in 0..<self.emitCount {
          if self.stopped {
            continuation.finish(throwing: ProductionSensorError.postStopSample)
            return
          }
          let accel = [Double(i), 0.0, 9.81]
          let gyro = [0.01 * Double(i), 0.0, 0.0]
          let grav = [0.0, 0.0, -1.0]
          let user = [Double(i) * 0.01, 0.0, 0.0]
          let quat = [0.0, 0.0, 0.0, 1.0]
          var bytes = Data()
          for v in accel + gyro + grav + user + quat {
            var le = v.bitPattern.littleEndian
            withUnsafeBytes(of: &le) { bytes.append(contentsOf: $0) }
          }
          let payload = MotionSample(
            accelerationXYZ: accel,
            rotationRateXYZ: gyro,
            attitudeQuaternion: quat,
            bytes: bytes,
            gravityXYZ: grav,
            userAccelerationXYZ: user,
            samplingIntervalNs: 10_000_000
          )
          let env = SpatialSampleEnvelope<MotionSample>(
            sampleID: "motion-\(i)",
            sequenceIndex: UInt64(i),
            acquisitionTimestampNs: UInt64(i) * 10_000_000,
            clockDomain: self.clockDomain,
            coordinateFrameID: self.coordinateFrameID,
            payload: payload,
            mediaType: "application/octet-stream",
            schemaID: "MotionSample",
            schemaVersion: "1.0.0-phase3-fixture"
          )
          self.capability.recordSample()
          continuation.yield(env)
        }
        continuation.finish()
      }
    }
  }

  public func stop() async {
    if stopped { return }
    stopped = true
    started = false
  }
}

/// Controllable pose adapter for Linux/Foundation failure-path proofs (not ARKit).
public final class ControllablePoseSensorAdapter: @unchecked Sendable, PoseSensorAdapter {
  public let adapterID: String
  public private(set) var capability: SpatialStreamCapability
  public var failOnStart = false
  public var interruptAfterStart = false
  public var requestRelocalization = false
  public var regressTimestamps = false
  public var emitInvalidQuaternion = false
  public var emitNonNormalizedQuaternion = false
  public var emitNanTransform = false
  public var trackingFailure = false
  /// When set, emits these tracking states in order (padded/truncated to emitCount).
  public var trackingStateSequence: [PoseTrackingState] = []
  public var emitCount: Int = 3
  public var sourceFrameID: String = "FRAME_AR_SESSION_WORLD"
  public var destinationFrameID: String = "FRAME_CAPTURE_SESSION_ROOT"
  public var clockDomain: ClockDomain = .arkitFrame
  /// Pose estimate authority — always GUIDANCE_ESTIMATE (not TEST_FIXTURE).
  public var poseEstimateAuthority: String = "GUIDANCE_ESTIMATE"
  public var frameEpochID: String = "epoch-fixture-1"
  public var sessionRunID: String = "run-fixture-1"
  public var worldOriginRevision: UInt64 = 1

  private var started = false
  private var stopped = false
  private var lastTs: UInt64 = 0
  private var continuation: AsyncThrowingStream<SpatialSampleEnvelope<PoseSample>, Error>.Continuation?

  public init(adapterID: String = "fixture.pose") {
    self.adapterID = adapterID
    self.capability = SpatialStreamCapability(
      streamID: SpatialStreamID.pose,
      adapterID: adapterID,
      sensorKind: "pose"
    )
  }

  public func start() async throws {
    if started && !stopped { throw ProductionSensorError.alreadyStarted }
    if failOnStart { throw ProductionSensorError.unavailable("pose") }
    started = true
    stopped = false
    capability.activate()
    if interruptAfterStart {
      throw ProductionSensorError.interrupted("pose_session_interrupted")
    }
    if requestRelocalization {
      throw ProductionSensorError.poseRelocalizationRequired
    }
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<PoseSample>, Error> {
    AsyncThrowingStream { continuation in
      self.continuation = continuation
      Task {
        guard self.started, !self.stopped else {
          continuation.finish(throwing: ProductionSensorError.notStarted)
          return
        }
        for i in 0..<self.emitCount {
          if self.stopped {
            continuation.finish(throwing: ProductionSensorError.postStopSample)
            return
          }
          if self.trackingFailure && i == 0 {
            continuation.finish(throwing: ProductionSensorError.poseTrackingFailed("TRACKING_LOST"))
            return
          }
          var ts = UInt64(i + 1) * 33_333_333
          if self.regressTimestamps && i == 1 {
            ts = self.lastTs &- 1
            continuation.finish(
              throwing: ProductionSensorError.timestampRegression(previous: self.lastTs, next: ts)
            )
            return
          }
          if ts <= self.lastTs && i > 0 {
            continuation.finish(
              throwing: ProductionSensorError.timestampRegression(previous: self.lastTs, next: ts)
            )
            return
          }
          self.lastTs = ts

          let state: PoseTrackingState
          if !self.trackingStateSequence.isEmpty {
            state = self.trackingStateSequence[min(i, self.trackingStateSequence.count - 1)]
          } else {
            state = .normal
          }
          let reason: PoseFailureReason? = {
            switch state {
            case .normal: return nil
            case .limited: return .insufficientFeatures
            case .notAvailable: return .trackingLost
            case .relocalizing: return .relocalizationRequired
            }
          }()

          var translation = Vector3D(x: Double(i) * 0.1, y: 0, z: 0)
          var rotation = QuaternionD.identity
          if self.emitInvalidQuaternion {
            rotation = QuaternionD(x: 0, y: 0, z: 0, w: 0)
          } else if self.emitNonNormalizedQuaternion {
            rotation = QuaternionD(x: 1, y: 1, z: 1, w: 1)
          }
          if self.emitNanTransform {
            translation = Vector3D(x: .nan, y: 0, z: 0)
          }

          var bytes = Data()
          let matrix = PoseSample.matrix4x4(translation: translation, rotation: rotation)
          for v in matrix {
            var le = v.bitPattern.littleEndian
            withUnsafeBytes(of: &le) { bytes.append(contentsOf: $0) }
          }

          let payload = PoseSample(
            translationMeters: translation,
            rotationQuaternion: rotation,
            trackingState: state,
            trackingReason: reason,
            timestampNanoseconds: ts,
            clockDomain: self.clockDomain,
            sourceFrameID: self.sourceFrameID,
            destinationFrameID: self.destinationFrameID,
            authority: self.poseEstimateAuthority,
            frameEpochID: self.frameEpochID,
            sessionRunID: self.sessionRunID,
            worldOriginRevision: self.worldOriginRevision,
            bytes: bytes
          )
          let env = SpatialSampleEnvelope<PoseSample>(
            sampleID: "pose-\(i)",
            sequenceIndex: UInt64(i),
            acquisitionTimestampNs: ts,
            clockDomain: self.clockDomain,
            coordinateFrameID: self.sourceFrameID,
            payload: payload,
            mediaType: "application/octet-stream",
            schemaID: "PoseSample",
            schemaVersion: "1.0.0-phase3-fixture"
          )
          self.capability.recordSample()
          continuation.yield(env)
        }
        continuation.finish()
      }
    }
  }

  public func stop() async {
    if stopped { return }
    stopped = true
    started = false
    continuation?.finish()
    continuation = nil
  }
}

/// Controllable depth adapter for Linux/Foundation failure-path proofs (not ARKit/LiDAR).
public final class ControllableDepthSensorAdapter: @unchecked Sendable, DepthSensorAdapter {
  public let adapterID: String
  public private(set) var capability: SpatialStreamCapability
  public var failOnStart = false
  public var unavailableDevice = false
  public var unavailableConfiguration = false
  public var interruptAfterStart = false
  public var emitCount: Int = 2
  public var clockDomain: ClockDomain = .fixtureDepth
  public var coordinateFrameID: String = "FRAME_DEPTH_SENSOR"
  public var frameEpochID: String = "epoch-fixture-1"
  public var sessionRunID: String = "run-fixture-1"
  public var worldOriginRevision: UInt64 = 1
  public var calibrationID: String = "CAL-FIXTURE-DEPTH-000001"
  public var evidenceOriginAuthority: String = "TEST_FIXTURE"
  public var depthEstimateAuthority: String = "GUIDANCE_ESTIMATE"

  private var started = false
  private var stopped = false
  private var continuation: AsyncThrowingStream<SpatialSampleEnvelope<DepthSample>, Error>.Continuation?

  public init(adapterID: String = "fixture.depth") {
    self.adapterID = adapterID
    self.capability = SpatialStreamCapability(
      streamID: SpatialStreamID.depth,
      adapterID: adapterID,
      sensorKind: "depth"
    )
  }

  public func start() async throws {
    if started && !stopped { throw ProductionSensorError.alreadyStarted }
    if unavailableDevice {
      throw ProductionSensorError.depthUnavailableDevice("NO_LIDAR_CAPABILITY")
    }
    if unavailableConfiguration {
      throw ProductionSensorError.depthUnavailableConfiguration("DEPTH_NOT_IN_ACTIVE_CONFIG")
    }
    if failOnStart {
      throw ProductionSensorError.depthActivationFailed("depth_activation_failed")
    }
    started = true
    stopped = false
    capability.activate()
    if interruptAfterStart {
      throw ProductionSensorError.interrupted("depth_interrupted_after_activation")
    }
  }

  public func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<DepthSample>, Error> {
    AsyncThrowingStream { continuation in
      self.continuation = continuation
      Task {
        guard self.started, !self.stopped else {
          continuation.finish(throwing: ProductionSensorError.notStarted)
          return
        }
        for i in 0..<self.emitCount {
          if self.stopped {
            continuation.finish(throwing: ProductionSensorError.postStopSample)
            return
          }
          let ts = UInt64(i + 1) * 33_333_333
          let bytes = FixtureDepthPayload.deterministicBytes()
          let artifactID = "depth-artifact-\(i)"
          let payload = DepthSample(
            width: FixtureDepthPayload.width,
            height: FixtureDepthPayload.height,
            bytes: bytes,
            sourceKind: .fixture,
            pixelFormat: .float32Meters,
            byteOrder: FixtureDepthPayload.byteOrder,
            rowStrideBytes: FixtureDepthPayload.rowStrideBytes,
            depthUnit: .meters,
            minimumValidDepth: 0.1,
            maximumValidDepth: 10.0,
            invalidValueEncoding: .negativeSentinel,
            depthArtifactID: artifactID,
            calibrationID: self.calibrationID,
            confidenceArtifactID: nil,
            validityArtifactID: nil,
            confidenceAbsenceReason: "OPTIONAL_CONFIDENCE_NOT_EMITTED_BY_FIXTURE",
            validityAbsenceReason: "OPTIONAL_VALIDITY_NOT_EMITTED_BY_FIXTURE",
            timestampNanoseconds: ts,
            clockDomain: self.clockDomain,
            coordinateFrameID: self.coordinateFrameID,
            frameEpochID: self.frameEpochID,
            sessionRunID: self.sessionRunID,
            worldOriginRevision: self.worldOriginRevision,
            evidenceOriginAuthority: self.evidenceOriginAuthority,
            depthEstimateAuthority: self.depthEstimateAuthority,
            adapterID: self.adapterID
          )
          let env = SpatialSampleEnvelope<DepthSample>(
            sampleID: "depth-\(i)",
            sequenceIndex: UInt64(i),
            acquisitionTimestampNs: ts,
            clockDomain: self.clockDomain,
            coordinateFrameID: self.coordinateFrameID,
            payload: payload,
            mediaType: "application/octet-stream",
            schemaID: "DepthSample",
            schemaVersion: "1.0.0-phase3-fixture"
          )
          self.capability.recordSample()
          continuation.yield(env)
        }
        continuation.finish()
      }
    }
  }

  public func stop() async {
    if stopped { return }
    stopped = true
    started = false
    continuation?.finish()
    continuation = nil
  }
}
