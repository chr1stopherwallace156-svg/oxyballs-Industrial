import Foundation

// MARK: - Sprint 3.8 privacy policy contracts

public enum EvidenceRetentionClass: String, Codable, Sendable, Equatable {
  case unrestrictedOperational = "UNRESTRICTED_OPERATIONAL"
  case restrictedRaw = "RESTRICTED_RAW"
  case clientSafeDerivative = "CLIENT_SAFE_DERIVATIVE"
  case ephemeralSessionOnly = "EPHEMERAL_SESSION_ONLY"
  case prohibited = "PROHIBITED"
}

public enum EvidenceAccessClass: String, Codable, Sendable, Equatable {
  case publicClient = "PUBLIC_CLIENT"
  case fieldTechnician = "FIELD_TECHNICIAN"
  case engineeringRestricted = "ENGINEERING_RESTRICTED"
  case privacyOfficer = "PRIVACY_OFFICER"
  case systemInternal = "SYSTEM_INTERNAL"
}

public enum MetadataFieldAction: String, Codable, Sendable, Equatable {
  case retain = "RETAIN"
  case encryptedRestricted = "ENCRYPTED_RESTRICTED"
  case coarsen = "COARSEN"
  case omitByPolicy = "OMIT_BY_POLICY"
  case notAvailable = "NOT_AVAILABLE"
}

public enum PrivacyCaptureMode: String, Codable, Sendable, Equatable {
  case rawRestrictedCapture = "RAW_RESTRICTED_CAPTURE"
  case privacyFirstCapture = "PRIVACY_FIRST_CAPTURE"
  case noRedactionRequired = "NO_REDACTION_REQUIRED"
}

public struct MetadataRetentionRule: Codable, Sendable, Equatable {
  public var fieldName: String
  public var action: MetadataFieldAction
  public var reason: String
  public var resultingValueClass: String

  public init(fieldName: String, action: MetadataFieldAction, reason: String, resultingValueClass: String) {
    self.fieldName = fieldName
    self.action = action
    self.reason = reason
    self.resultingValueClass = resultingValueClass
  }

  public func dictionary() -> [String: Any] {
    [
      "metadata_field": fieldName,
      "action": action.rawValue,
      "reason": reason,
      "resulting_value_class": resultingValueClass,
    ]
  }
}

public struct RedactionRequirement: Codable, Sendable, Equatable {
  public var detectionKind: String
  public var required: Bool
  public var minimumConfidence: Double
  public var preferredOperations: [String]

  public init(detectionKind: String, required: Bool, minimumConfidence: Double, preferredOperations: [String]) {
    self.detectionKind = detectionKind
    self.required = required
    self.minimumConfidence = minimumConfidence
    self.preferredOperations = preferredOperations
  }

  public func dictionary() -> [String: Any] {
    [
      "detection_kind": detectionKind,
      "required": required,
      "minimum_confidence": minimumConfidence,
      "preferred_operations": preferredOperations,
    ]
  }
}

public struct RedactionPolicy: Codable, Sendable, Equatable {
  public var policyID: String
  public var requirements: [RedactionRequirement]
  public var note: String

  public init(policyID: String, requirements: [RedactionRequirement], note: String) {
    self.policyID = policyID
    self.requirements = requirements
    self.note = note
  }

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "requirements": requirements.map { $0.dictionary() },
      "note": note,
    ]
  }
}

public struct EvidencePrivacyPolicy: Codable, Sendable, Equatable {
  public var policyID: String
  public var schemaVersion: String
  public var revision: UInt64
  public var organizationID: String
  public var applicabilityConditions: [String]
  public var retentionClasses: [EvidenceRetentionClass]
  public var accessClasses: [EvidenceAccessClass]
  public var metadataRules: [MetadataRetentionRule]
  public var redactionRequirements: [RedactionRequirement]
  public var captureMode: PrivacyCaptureMode
  public var rawRetentionBehavior: String
  public var exportRestrictions: [String]
  public var authority: EvidenceAuthority
  public var activationTimestampUTC: String
  public var expirationTimestampUTC: String?

  public static let fixturePolicyID = "POL-FIXTURE-PRIVACY-000001"
  public static let fixtureSchemaVersion = "1.0.0-phase3-fixture"

  public static func fixtureRawRestricted() -> EvidencePrivacyPolicy {
    EvidencePrivacyPolicy(
      policyID: fixturePolicyID,
      schemaVersion: fixtureSchemaVersion,
      revision: 1,
      organizationID: "ORG-FIXTURE-000001",
      applicabilityConditions: ["field_capture", "linux_fixture"],
      retentionClasses: [.restrictedRaw, .clientSafeDerivative],
      accessClasses: [.engineeringRestricted, .fieldTechnician, .publicClient],
      metadataRules: [
        MetadataRetentionRule(
          fieldName: "precise_latitude_longitude",
          action: .omitByPolicy,
          reason: "field_privacy_default",
          resultingValueClass: "OMITTED"
        ),
        MetadataRetentionRule(
          fieldName: "coarse_location",
          action: .coarsen,
          reason: "retain_region_only",
          resultingValueClass: "COARSE_REGION"
        ),
        MetadataRetentionRule(
          fieldName: "device_local_timezone",
          action: .retain,
          reason: "operational_scheduling",
          resultingValueClass: "RETAINED"
        ),
        MetadataRetentionRule(
          fieldName: "wifi_or_network_identifiers",
          action: .notAvailable,
          reason: "not_collected_no_system_requirement",
          resultingValueClass: "NOT_AVAILABLE"
        ),
        MetadataRetentionRule(
          fieldName: "operator_identity",
          action: .encryptedRestricted,
          reason: "restricted_access",
          resultingValueClass: "ENCRYPTED_RESTRICTED"
        ),
        MetadataRetentionRule(
          fieldName: "organization_identity",
          action: .retain,
          reason: "tenant_scope",
          resultingValueClass: "RETAINED"
        ),
        MetadataRetentionRule(
          fieldName: "facility_identifier",
          action: .retain,
          reason: "site_context",
          resultingValueClass: "RETAINED"
        ),
        MetadataRetentionRule(
          fieldName: "vehicle_vin_visibility",
          action: .omitByPolicy,
          reason: "client_safe_default",
          resultingValueClass: "OMITTED"
        ),
        MetadataRetentionRule(
          fieldName: "client_identifiers",
          action: .encryptedRestricted,
          reason: "restricted_access",
          resultingValueClass: "ENCRYPTED_RESTRICTED"
        ),
      ],
      redactionRequirements: [
        RedactionRequirement(
          detectionKind: "FACE",
          required: true,
          minimumConfidence: 0.5,
          preferredOperations: ["BLUR", "PIXELATE"]
        ),
        RedactionRequirement(
          detectionKind: "LICENSE_PLATE",
          required: true,
          minimumConfidence: 0.5,
          preferredOperations: ["PIXELATE", "SOLID_MASK"]
        ),
      ],
      captureMode: .rawRestrictedCapture,
      rawRetentionBehavior: "PRESERVE_RAW_IN_RESTRICTED_STORAGE",
      exportRestrictions: ["NO_RESTRICTED_RAW_IN_INSPECTION_PROFILE"],
      authority: .testFixture,
      activationTimestampUTC: "2026-08-03T00:00:00Z",
      expirationTimestampUTC: "2099-01-01T00:00:00Z"
    )
  }

  public static func fixturePrivacyFirst() -> EvidencePrivacyPolicy {
    var p = fixtureRawRestricted()
    p.policyID = "POL-FIXTURE-PRIVACY-FIRST-000001"
    p.captureMode = .privacyFirstCapture
    p.rawRetentionBehavior = "PROHIBIT_RAW_PERSISTENCE"
    p.retentionClasses = [.clientSafeDerivative, .prohibited]
    return p
  }

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "policy_id": policyID,
      "schema_version": schemaVersion,
      "revision": revision,
      "organization_id": organizationID,
      "applicability_conditions": applicabilityConditions,
      "retention_classes": retentionClasses.map(\.rawValue),
      "access_classes": accessClasses.map(\.rawValue),
      "metadata_rules": metadataRules.map { $0.dictionary() },
      "redaction_requirements": redactionRequirements.map { $0.dictionary() },
      "privacy_capture_mode": captureMode.rawValue,
      "raw_retention_behavior": rawRetentionBehavior,
      "export_restrictions": exportRestrictions,
      "authority": authority.rawValue,
      "activation_timestamp_utc": activationTimestampUTC,
      "schema_id": "EvidencePrivacyPolicy",
      "note": "No field may be silently stripped or modified",
    ]
    if let expirationTimestampUTC { d["expiration_timestamp_utc"] = expirationTimestampUTC }
    return d
  }
}

public enum PrivacyPolicyViolationCode: String, Codable, Sendable, Equatable {
  case silentMetadataStrip = "SILENT_METADATA_STRIP"
  case forbiddenRawExport = "FORBIDDEN_RAW_EXPORT"
  case missingRequiredRedaction = "MISSING_REQUIRED_REDACTION"
  case unknownPolicy = "UNKNOWN_POLICY"
  case expiredPolicy = "EXPIRED_POLICY"
  case privacyFirstRawPersisted = "PRIVACY_FIRST_RAW_PERSISTED"
  case missingDerivationReference = "MISSING_DERIVATION_REFERENCE"
  case incorrectSourceDigest = "INCORRECT_SOURCE_DIGEST"
}

public struct PrivacyPolicyViolation: Codable, Sendable, Equatable {
  public var code: PrivacyPolicyViolationCode
  public var detail: String
  public var policyID: String?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = ["code": code.rawValue, "detail": detail]
    if let policyID { d["policy_id"] = policyID }
    return d
  }
}

public struct PrivacyPolicyDecision: Codable, Sendable, Equatable {
  public var decisionID: String
  public var policyID: String
  public var captureMode: PrivacyCaptureMode
  public var accepted: Bool
  public var violations: [PrivacyPolicyViolation]
  public var decidedAtUTC: String

  public func dictionary() -> [String: Any] {
    [
      "decision_id": decisionID,
      "policy_id": policyID,
      "privacy_capture_mode": captureMode.rawValue,
      "accepted": accepted,
      "violations": violations.map { $0.dictionary() },
      "decided_at_utc": decidedAtUTC,
    ]
  }
}

public struct PrivacyPolicyEvaluator: Sendable {
  public var nowUTC: String

  public init(nowUTC: String = "2026-08-03T00:30:00Z") {
    self.nowUTC = nowUTC
  }

  public func activate(_ policy: EvidencePrivacyPolicy?) throws -> PrivacyPolicyDecision {
    guard let policy else {
      throw SpatialEvidenceError.privacyPolicyUnknown("nil_policy")
    }
    if let exp = policy.expirationTimestampUTC, nowUTC > exp {
      throw SpatialEvidenceError.privacyPolicyExpired(policy.policyID)
    }
    return PrivacyPolicyDecision(
      decisionID: "PPD-\(policy.policyID)",
      policyID: policy.policyID,
      captureMode: policy.captureMode,
      accepted: true,
      violations: [],
      decidedAtUTC: nowUTC
    )
  }

  public func rejectSilentMetadataStrip(field: String, policyID: String) throws {
    throw SpatialEvidenceError.silentMetadataStrippingRejected("\(field)@\(policyID)")
  }
}

// MARK: - Metadata privacy ledger

public struct MetadataPrivacyLedgerEntry: Codable, Sendable, Equatable {
  public var metadataField: String
  public var originalAvailability: String
  public var action: MetadataFieldAction
  public var resultingValueClass: String
  public var policyID: String
  public var reason: String
  public var authority: EvidenceAuthority
  public var timestampUTC: String

  public func dictionary() -> [String: Any] {
    [
      "metadata_field": metadataField,
      "original_availability": originalAvailability,
      "action": action.rawValue,
      "resulting_value_class": resultingValueClass,
      "policy_id": policyID,
      "reason": reason,
      "authority": authority.rawValue,
      "timestamp_utc": timestampUTC,
    ]
  }
}

public struct MetadataPrivacyLedger: Sendable {
  public private(set) var entries: [MetadataPrivacyLedgerEntry] = []

  public init() {}

  public mutating func record(from policy: EvidencePrivacyPolicy, timestampUTC: String = "2026-08-03T00:30:00Z") {
    for rule in policy.metadataRules {
      entries.append(
        MetadataPrivacyLedgerEntry(
          metadataField: rule.fieldName,
          originalAvailability: rule.action == .notAvailable ? "NOT_PRESENT" : "AVAILABLE",
          action: rule.action,
          resultingValueClass: rule.resultingValueClass,
          policyID: policy.policyID,
          reason: rule.reason,
          authority: policy.authority,
          timestampUTC: timestampUTC
        )
      )
    }
  }

  public func dictionary() -> [String: Any] {
    [
      "entries": entries.map { $0.dictionary() },
      "schema_id": "MetadataPrivacyLedger",
      "schema_version": "1.0.0-phase3-fixture",
      "note": "Every sensitive metadata decision is ledgered; silent stripping forbidden",
    ]
  }

  public func assertFieldLedgered(_ field: String) throws {
    guard entries.contains(where: { $0.metadataField == field }) else {
      throw SpatialEvidenceError.silentMetadataStrippingRejected(field)
    }
  }
}
