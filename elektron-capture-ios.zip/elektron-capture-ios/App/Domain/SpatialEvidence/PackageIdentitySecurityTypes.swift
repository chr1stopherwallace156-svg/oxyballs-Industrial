import Foundation

// MARK: - Package signature contracts (Sprint 3.7)

public enum PackageSignatureAlgorithm: String, Codable, Sendable, Equatable {
  /// Deterministic Linux/fixture signer — NOT a hardware signature.
  case fixtureHmacSha256V1 = "FIXTURE_HMAC_SHA256_V1"
  /// Apple Secure Enclave candidate algorithm identity (unvalidated on Linux).
  case ecdsaP256Sha256 = "ECDSA_P256_SHA256"
}

public enum DeviceKeyTrustState: String, Codable, Sendable, Equatable, CaseIterable {
  case enrolled = "ENROLLED"
  case verified = "VERIFIED"
  case suspended = "SUSPENDED"
  case revoked = "REVOKED"
  case unknown = "UNKNOWN"
  case expired = "EXPIRED"
}

public enum SignatureFailureReason: String, Codable, Sendable, Equatable {
  case digestMismatch = "DIGEST_MISMATCH"
  case signatureByteMutation = "SIGNATURE_BYTE_MUTATION"
  case unknownKey = "UNKNOWN_KEY"
  case revokedKey = "REVOKED_KEY"
  case enrollmentMismatch = "ENROLLMENT_MISMATCH"
  case algorithmUnsupported = "ALGORITHM_UNSUPPORTED"
  case packageBindingMismatch = "PACKAGE_BINDING_MISMATCH"
  case embeddedKeyUntrustedAlone = "EMBEDDED_KEY_UNTRUSTED_ALONE"
}

public enum SignatureVerificationResult: String, Codable, Sendable, Equatable {
  case validEnrolled = "VALID_ENROLLED"
  case validButUntrustedOrigin = "VALID_BUT_UNTRUSTED_ORIGIN"
  case invalid = "INVALID"
}

public struct DeviceSigningKeyReference: Codable, Sendable, Equatable {
  public var deviceKeyID: String
  public var publicKeyFingerprint: String
  public var algorithm: PackageSignatureAlgorithm

  public init(deviceKeyID: String, publicKeyFingerprint: String, algorithm: PackageSignatureAlgorithm) {
    self.deviceKeyID = deviceKeyID
    self.publicKeyFingerprint = publicKeyFingerprint
    self.algorithm = algorithm
  }

  public func dictionary() -> [String: Any] {
    [
      "device_key_id": deviceKeyID,
      "public_key_fingerprint": publicKeyFingerprint,
      "algorithm": algorithm.rawValue,
    ]
  }
}

public struct DeviceKeyEnrollmentRecord: Codable, Sendable, Equatable {
  public var enrollmentRecordID: String
  public var deviceKeyID: String
  public var publicKey: String
  public var publicKeyFingerprint: String
  public var appIdentifier: String
  public var environment: String
  public var enrollmentTimestampUTC: String
  public var operatorOrOrganizationID: String
  public var trustStatus: DeviceKeyTrustState
  public var revocationStatus: String
  public var revocationReason: String?
  public var attestationReference: String?
  public var policyID: String

  public static let fixtureEnrollmentID = "ENR-FIXTURE-KEY-000001"
  public static let fixtureKeyID = "KEY-FIXTURE-HMAC-000001"
  public static let fixtureFingerprint = "fp-fixture-hmac-sha256-000001"

  public static func fixtureEnrolled() -> DeviceKeyEnrollmentRecord {
    DeviceKeyEnrollmentRecord(
      enrollmentRecordID: fixtureEnrollmentID,
      deviceKeyID: fixtureKeyID,
      publicKey: "FIXTURE_PUBLIC_KEY_MATERIAL_NOT_HARDWARE",
      publicKeyFingerprint: fixtureFingerprint,
      appIdentifier: "com.elektronindustrial.capture.fixture",
      environment: "linux_fixture",
      enrollmentTimestampUTC: "2026-08-03T00:00:00Z",
      operatorOrOrganizationID: "ORG-FIXTURE-000001",
      trustStatus: .enrolled,
      revocationStatus: "NOT_REVOKED",
      revocationReason: nil,
      attestationReference: "ATT-FIXTURE-REF-NONE",
      policyID: "POL-FIXTURE-TRUST-000001"
    )
  }

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "enrollment_record_id": enrollmentRecordID,
      "device_key_id": deviceKeyID,
      "public_key": publicKey,
      "public_key_fingerprint": publicKeyFingerprint,
      "app_identifier": appIdentifier,
      "environment": environment,
      "enrollment_timestamp_utc": enrollmentTimestampUTC,
      "operator_or_organization_id": operatorOrOrganizationID,
      "trust_status": trustStatus.rawValue,
      "revocation_status": revocationStatus,
      "policy_id": policyID,
      "schema_id": "DeviceKeyEnrollmentRecord",
      "schema_version": "1.0.0-phase3-fixture",
    ]
    if let revocationReason { d["revocation_reason"] = revocationReason }
    if let attestationReference { d["attestation_reference"] = attestationReference }
    return d
  }
}

public struct PackageSignatureEnvelope: Codable, Sendable, Equatable {
  public var packageID: String
  public var captureSessionID: String
  public var packageClosureSHA256: String
  public var manifestSHA256: String
  public var signingKeyID: String
  public var publicKeyFingerprint: String
  public var signatureAlgorithm: PackageSignatureAlgorithm
  public var signatureBytesHex: String
  public var signedAtUTC: String
  public var enrollmentRecordID: String
  public var signerStatus: DeviceKeyTrustState
  public var evidenceOriginAuthority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    [
      "package_id": packageID,
      "capture_session_id": captureSessionID,
      "package_closure_sha256": packageClosureSHA256,
      "manifest_sha256": manifestSHA256,
      "signing_key_id": signingKeyID,
      "public_key_fingerprint": publicKeyFingerprint,
      "signature_algorithm": signatureAlgorithm.rawValue,
      "signature_bytes": signatureBytesHex,
      "signed_at": signedAtUTC,
      "enrollment_record_id": enrollmentRecordID,
      "signer_status": signerStatus.rawValue,
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
      "schema_id": "PackageSignatureEnvelope",
      "schema_version": "1.0.0-phase3-fixture",
      "note": "Fixture signatures are not hardware Secure Enclave signatures",
    ]
  }

  public func bindingDigestMaterial() throws -> Data {
    try CanonicalJSON.data([
      "package_id": packageID,
      "capture_session_id": captureSessionID,
      "package_closure_sha256": packageClosureSHA256,
      "manifest_sha256": manifestSHA256,
      "signing_key_id": signingKeyID,
      "enrollment_record_id": enrollmentRecordID,
      "signature_algorithm": signatureAlgorithm.rawValue,
    ] as [String: Any])
  }
}

public struct SignedPackageIdentity: Codable, Sendable, Equatable {
  public var packageID: String
  public var packageClosureSHA256: String
  public var manifestSHA256: String
  public var signatureEnvelope: PackageSignatureEnvelope
  public var enrollmentRecord: DeviceKeyEnrollmentRecord
  public var verificationResult: SignatureVerificationResult

  public func dictionary() -> [String: Any] {
    [
      "package_id": packageID,
      "package_closure_sha256": packageClosureSHA256,
      "manifest_sha256": manifestSHA256,
      "signature_envelope": signatureEnvelope.dictionary(),
      "enrollment_record": enrollmentRecord.dictionary(),
      "verification_result": verificationResult.rawValue,
      "schema_id": "SignedPackageIdentity",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}

public struct DeviceKeyTrustRegistry: Sendable {
  public private(set) var records: [String: DeviceKeyEnrollmentRecord]

  public init(records: [DeviceKeyEnrollmentRecord] = []) {
    var map: [String: DeviceKeyEnrollmentRecord] = [:]
    for r in records { map[r.deviceKeyID] = r }
    self.records = map
  }

  public mutating func enroll(_ record: DeviceKeyEnrollmentRecord) {
    records[record.deviceKeyID] = record
  }

  public func lookup(deviceKeyID: String) -> DeviceKeyEnrollmentRecord? {
    records[deviceKeyID]
  }
}

// MARK: - App Attest portable envelopes

public enum AppInstanceRiskDisposition: String, Codable, Sendable, Equatable {
  case appInstanceAttested = "APP_INSTANCE_ATTESTED"
  case attestationUnavailable = "ATTESTATION_UNAVAILABLE"
  case attestationFailed = "ATTESTATION_FAILED"
  case assertionReplayed = "ASSERTION_REPLAYED"
  case challengeExpired = "CHALLENGE_EXPIRED"
  case riskReviewRequired = "RISK_REVIEW_REQUIRED"
}

public struct AppAttestChallenge: Codable, Sendable, Equatable {
  public var challengeID: String
  public var serverNonce: String
  public var issuedAtUTC: String
  public var expiresAtUTC: String
  public var appIdentifier: String

  public func dictionary() -> [String: Any] {
    [
      "challenge_id": challengeID,
      "server_nonce": serverNonce,
      "issued_at_utc": issuedAtUTC,
      "expires_at_utc": expiresAtUTC,
      "app_identifier": appIdentifier,
    ]
  }
}

public struct AppAttestKeyRegistration: Codable, Sendable, Equatable {
  public var registrationID: String
  public var appAttestKeyID: String
  public var enrollmentRecordID: String
  public var appIdentifier: String
  public var registeredAtUTC: String

  public func dictionary() -> [String: Any] {
    [
      "registration_id": registrationID,
      "app_attest_key_id": appAttestKeyID,
      "enrollment_record_id": enrollmentRecordID,
      "app_identifier": appIdentifier,
      "registered_at_utc": registeredAtUTC,
    ]
  }
}

public struct AppAttestAssertionEnvelope: Codable, Sendable, Equatable {
  public var assertionID: String
  public var challengeID: String
  public var serverNonce: String
  public var packageClosureSHA256: String
  public var captureSessionID: String
  public var appIdentifier: String
  public var enrollmentRecordID: String
  public var assertionBytesHex: String
  public var createdAtUTC: String

  public func dictionary() -> [String: Any] {
    [
      "assertion_id": assertionID,
      "challenge_id": challengeID,
      "server_nonce": serverNonce,
      "package_closure_sha256": packageClosureSHA256,
      "capture_session_id": captureSessionID,
      "app_identifier": appIdentifier,
      "enrollment_record_id": enrollmentRecordID,
      "assertion_bytes": assertionBytesHex,
      "created_at_utc": createdAtUTC,
      "schema_id": "AppAttestAssertionEnvelope",
      "schema_version": "1.0.0-phase3-fixture",
      "note": "Does not claim DEVICE_PROVEN_UNCOMPROMISED",
    ]
  }
}

public struct AppAttestVerificationResult: Codable, Sendable, Equatable {
  public var disposition: AppInstanceRiskDisposition
  public var challengeID: String
  public var reason: String?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "disposition": disposition.rawValue,
      "challenge_id": challengeID,
    ]
    if let reason { d["reason"] = reason }
    return d
  }
}
