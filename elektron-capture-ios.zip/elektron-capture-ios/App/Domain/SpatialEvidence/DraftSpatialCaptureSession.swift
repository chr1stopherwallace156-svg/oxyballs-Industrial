import Foundation

public enum DraftAcquisitionStatus: String, Codable, Sendable, Equatable {
  case capturing = "CAPTURING"
  case captureComplete = "CAPTURE_COMPLETE"
  case validating = "VALIDATING"
  case interrupted = "INTERRUPTED"
  case cancelled = "CANCELLED"
  case validationFailed = "VALIDATION_FAILED"
  case quarantined = "DRAFT_ACQUISITION_QUARANTINED"
  /// Boundary reached — immutable package bytes exist. Not a custody status.
  case packagedBoundary = "PACKAGED_BOUNDARY_REACHED"
}

/// Draft spatial capture session FSM (Phase 3 charter §3.1).
public final class DraftSpatialCaptureSession: @unchecked Sendable {
  public let sessionID: String
  public let vehicleID: String
  public let pilotID: String?
  public private(set) var status: DraftAcquisitionStatus
  public private(set) var package: SpatialEvidencePackage?
  public private(set) var failureReason: String?

  private let coordinator: any SpatialSensorCoordinator
  private let allowedFrameIDs: Set<String>
  private let expectedClockDomain: ClockDomain
  private let builder: SpatialEvidencePackageBuilder

  public init(
    sessionID: String,
    vehicleID: String,
    pilotID: String? = nil,
    coordinator: any SpatialSensorCoordinator,
    allowedFrameIDs: Set<String>,
    expectedClockDomain: ClockDomain = .syntheticDeterministic,
    builder: SpatialEvidencePackageBuilder = SpatialEvidencePackageBuilder()
  ) {
    self.sessionID = sessionID
    self.vehicleID = vehicleID
    self.pilotID = pilotID
    self.coordinator = coordinator
    self.allowedFrameIDs = allowedFrameIDs
    self.expectedClockDomain = expectedClockDomain
    self.builder = builder
    self.status = .capturing
  }

  public func cancel() throws {
    guard status == .capturing || status == .captureComplete || status == .validating else {
      throw SpatialEvidenceError.invalidLifecycleTransition(from: status.rawValue, to: DraftAcquisitionStatus.cancelled.rawValue)
    }
    status = .cancelled
    failureReason = "user_cancelled"
    throw SpatialEvidenceError.cancelled
  }

  public func interrupt(_ reason: String) throws {
    guard status == .capturing else {
      throw SpatialEvidenceError.invalidLifecycleTransition(from: status.rawValue, to: DraftAcquisitionStatus.interrupted.rawValue)
    }
    status = .interrupted
    failureReason = reason
    throw SpatialEvidenceError.interrupted(reason)
  }

  /// CAPTURING → CAPTURE_COMPLETE → VALIDATING → PACKAGED boundary event.
  public func runToPackaged(outputDirectory: URL) async throws -> SpatialEvidencePackage {
    guard status == .capturing else {
      throw SpatialEvidenceError.invalidLifecycleTransition(from: status.rawValue, to: DraftAcquisitionStatus.captureComplete.rawValue)
    }
    try await coordinator.activateAll()
    var bundle = try await coordinator.collectDeterministicBundle()
    try validateBundleClocksAndFrames(bundle)
    status = .captureComplete

    status = .validating
    do {
      let pkg = try builder.seal(
        sessionID: sessionID,
        vehicleID: vehicleID,
        pilotID: pilotID,
        bundle: &bundle,
        outputDirectory: outputDirectory
      )
      self.package = pkg
      status = .packagedBoundary
      return pkg
    } catch {
      status = .validationFailed
      failureReason = String(describing: error)
      throw error
    }
  }

  private func validateBundleClocksAndFrames(_ bundle: SpatialSampleBundle) throws {
    func check<T>(_ samples: [SpatialSampleEnvelope<T>]) throws {
      for s in samples {
        if s.clockDomain != expectedClockDomain {
          throw SpatialEvidenceError.clockDomainMismatch(
            expected: expectedClockDomain.rawValue,
            actual: s.clockDomain.rawValue
          )
        }
        if !allowedFrameIDs.contains(s.coordinateFrameID) {
          throw SpatialEvidenceError.coordinateFrameRejected(s.coordinateFrameID)
        }
      }
    }
    try check(bundle.camera)
    try check(bundle.depth)
    try check(bundle.motion)
    try check(bundle.pose)
  }
}
