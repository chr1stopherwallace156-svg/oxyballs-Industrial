import Foundation

/// Builds primary Sprint 3.3 fixture packages: camera + depth (motion/pose NOT_REQUESTED).
public struct FixtureCameraDepthPackageBuilder: Sendable {
  public static let primaryPackageID = "SPKG-FIXTURE-CAMERA-DEPTH-000001"
  public static let primarySessionID = "SESS-FIXTURE-CAMERA-DEPTH-000001"
  public static let cameraToDepthCorrelationID = "fixture-camera-to-depth-000001"
  public static let calibrationID = "CAL-FIXTURE-DEPTH-000001"
  public static let depthToCameraTransformID = "XF-DEPTH-TO-CAMERA-000001"
  public static let frameEpochID = "epoch-fixture-1"
  public static let sessionRunID = "run-fixture-1"
  public static let worldOriginRevision: UInt64 = 1

  public init() {}

  public func seal(
    camera: [SpatialSampleEnvelope<CameraSample>],
    depth: [SpatialSampleEnvelope<DepthSample>],
    cameraCapability: SpatialStreamCapability,
    depthCapability: SpatialStreamCapability,
    frames: [CoordinateFrameDescriptor],
    transformEdges: [TransformEdge],
    clockCorrelations: [ClockCorrelation],
    calibrations: [DepthCalibration],
    associations: [RGBDepthAssociationRecord],
    outputDirectory: URL,
    vehicleID: String = "VEH-000001",
    pilotID: String = "PILOT-000001",
    captureSessionID: String = FixtureCameraDepthPackageBuilder.primarySessionID,
    packageID: String = FixtureCameraDepthPackageBuilder.primaryPackageID,
    createdAtUTC: String = "2026-08-03T00:00:00Z"
  ) throws -> SpatialEvidencePackage {
    precondition(!camera.isEmpty, "camera+depth fixture requires camera samples")
    precondition(!depth.isEmpty, "camera+depth fixture requires depth samples")
    precondition(!packageID.hasPrefix("SPKG-DEVICE-"))
    precondition(!captureSessionID.hasPrefix("SESS-DEVICE-"))

    var camCap = cameraCapability
    var depthCap = depthCapability
    try camCap.freeze(outcome: .acquired)
    try depthCap.freeze(outcome: .acquired)

    let motionCap = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "none",
      sensorKind: "motion",
      declared: false
    )
    var motionFrozen = motionCap
    try motionFrozen.freeze(outcome: .notRequested)

    let poseCap = SpatialStreamCapability(
      streamID: SpatialStreamID.pose,
      adapterID: "none",
      sensorKind: "pose",
      declared: false
    )
    var poseFrozen = poseCap
    try poseFrozen.freeze(outcome: .notRequested)

    let capability = SpatialCapabilitySnapshot(
      snapshotID: "CAP-\(packageID)",
      capturedAtUTC: createdAtUTC,
      streams: [camCap, depthCap, motionFrozen, poseFrozen],
      schemaVersion: SpatialCapabilitySnapshot.fixtureSchemaVersion
    )

    try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
    let payloadRoot = outputDirectory.appendingPathComponent("payload", isDirectory: true)
    try FileManager.default.createDirectory(at: payloadRoot, withIntermediateDirectories: true)

    var artifacts: [SpatialArtifactDescriptor] = []
    var sampleIndex: [[String: Any]] = []

    try writePayload(
      stream: SpatialStreamID.camera,
      adapterID: camCap.adapterID,
      samples: camera,
      root: payloadRoot,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }

    try writePayload(
      stream: SpatialStreamID.depth,
      adapterID: depthCap.adapterID,
      samples: depth,
      root: payloadRoot,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }

    for sample in depth {
      try DepthSampleValidator.validate(sample.payload)
    }
    for cal in calibrations {
      try DepthCalibrationValidator.validate(
        cal,
        depthSample: depth.first?.payload,
        frames: frames,
        transformIDs: Set(transformEdges.map(\.transformID)),
        packageFrameEpochID: Self.frameEpochID,
        packageSessionRunID: Self.sessionRunID,
        packageWorldOriginRevision: Self.worldOriginRevision
      )
    }
    try RGBDepthAssociationValidator.validate(
      associations: associations,
      cameraSamples: camera,
      depthSamples: depth,
      correlations: clockCorrelations,
      calibrations: calibrations,
      frames: frames,
      transformEdges: transformEdges,
      packageFrameEpochID: Self.frameEpochID,
      packageSessionRunID: Self.sessionRunID,
      packageWorldOriginRevision: Self.worldOriginRevision
    )

    try NotRequestedStreamEvidenceValidator.validate(
      streamID: SpatialStreamID.motion,
      capability: motionFrozen,
      artifacts: artifacts,
      frames: frames,
      clockCorrelations: clockCorrelations,
      streamSpecificFrameIDs: ["FRAME_DEVICE_IMU"],
      streamSpecificClockDomains: [.coreMotion]
    )
    try NotRequestedStreamEvidenceValidator.validate(
      streamID: SpatialStreamID.pose,
      capability: poseFrozen,
      artifacts: artifacts,
      frames: frames,
      clockCorrelations: clockCorrelations,
      streamSpecificFrameIDs: ["FRAME_AR_SESSION_WORLD"],
      streamSpecificClockDomains: [.arkitFrame]
    )

    let graph = CoordinateFrameGraph(frames: frames, edges: transformEdges)
    try graph.validateRegistry()
    try graph.validateEdgesReferenceKnownFrames()
    try graph.validateTransformGraph()

    try writeJSON(capability.asDictionary(), to: outputDirectory.appendingPathComponent("capability_snapshot.json"))
    try writeJSON(
      ["correlations": clockCorrelations.map { $0.asDictionary() }],
      to: outputDirectory.appendingPathComponent("clock_correlation.json")
    )
    try writeJSON(
      ["frames": frames.map { $0.asDictionary() }],
      to: outputDirectory.appendingPathComponent("coordinate_frames.json")
    )
    try writeJSON(
      [
        "calibrations": calibrations.map { $0.asDictionary() },
        "characterization_status": "PENDING_CHARACTERIZATION",
        "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED",
      ],
      to: outputDirectory.appendingPathComponent("depth_calibration.json")
    )
    try writeJSON(
      ["associations": associations.map { $0.asDictionary() }],
      to: outputDirectory.appendingPathComponent("rgb_depth_associations.json")
    )
    try writeJSON(
      [
        "edges": transformEdges.map { $0.asDictionary() },
        "characterization_status": "PENDING_CHARACTERIZATION",
        "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED",
      ],
      to: outputDirectory.appendingPathComponent("transform_graph.json")
    )
    sampleIndex.sort {
      (($0["relative_path"] as? String) ?? "") < (($1["relative_path"] as? String) ?? "")
    }
    try writeJSON(["samples": sampleIndex], to: outputDirectory.appendingPathComponent("sample_index.json"))

    let manifest = SpatialEvidenceManifest(
      packageID: packageID,
      vehicleID: vehicleID,
      captureSessionID: captureSessionID,
      pilotID: pilotID,
      createdAtUTC: createdAtUTC,
      capability: capability,
      frames: frames,
      clockCorrelations: clockCorrelations,
      artifacts: artifacts,
      sampleIndex: sampleIndex
    )
    var manifestDict = manifest.asDictionary()
    manifestDict["schema_id"] = "SpatialEvidenceManifest"
    manifestDict["schema_version"] = "1.0.0-phase3-fixture"
    manifestDict["package_layout"] = "fixture_camera_depth_v1"
    manifestDict["host_claim"] = "NO_PHYSICAL_DEVICE_EXECUTION"
    manifestDict["implementation_state"] = "SOURCE_IMPLEMENTED"
    manifestDict["validation_state"] = "LINUX_FIXTURE_VALIDATED"
    manifestDict["evidence_origin_authority"] = "TEST_FIXTURE"
    manifestDict["depth_estimate_authority"] = "GUIDANCE_ESTIMATE"
    manifestDict["depth_adapter_id"] = depthCap.adapterID
    manifestDict["rgb_depth_associations"] = associations.map { $0.asDictionary() }
    manifestDict["depth_calibrations"] = calibrations.map { $0.asDictionary() }
    manifestDict["transform_edges"] = transformEdges.map { $0.asDictionary() }
    manifestDict["frame_epoch_id"] = Self.frameEpochID
    manifestDict["session_run_id"] = Self.sessionRunID
    manifestDict["world_origin_revision"] = Self.worldOriginRevision

    let manifestData = try CanonicalJSON.data(manifestDict)
    try manifestData.write(to: outputDirectory.appendingPathComponent("manifest.json"), options: .atomic)
    let manifestSHA = ContentHasher.sha256Hex(manifestData)

    let inventoryEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: outputDirectory
    )
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(
      packageRoot: outputDirectory,
      entries: inventoryEntries
    )
    let packageClosureHash = try SpatialPackageClosureVerifier.inventoryClosureHash(
      entries: inventoryEntries
    )
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": packageClosureHash,
      "entries": inventoryEntries,
    ]
    try writeJSON(inventory, to: outputDirectory.appendingPathComponent("package_inventory.json"))

    try SpatialPackageClosureVerifier.verifyDevicePayload(
      packageRoot: outputDirectory,
      manifestArtifacts: artifacts
    )
    let packageHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outputDirectory)

    return SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: manifestSHA,
      packageClosureSHA256: packageClosureHash
    )
  }

  public static func defaultFrames() -> [CoordinateFrameDescriptor] {
    [
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAPTURE_SESSION_ROOT",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "opencv",
        clockDomain: .fixtureCamera,
        authority: "TEST_FIXTURE"
      ),
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAMERA_OPTICAL",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "opencv",
        clockDomain: .fixtureCamera,
        authority: "TEST_FIXTURE"
      ),
      CoordinateFrameDescriptor(
        frameID: "FRAME_DEPTH_SENSOR",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "opencv",
        clockDomain: .fixtureDepth,
        authority: "TEST_FIXTURE"
      ),
    ]
  }

  public static func defaultTransformEdges() -> [TransformEdge] {
    [
      TransformEdge(
        transformID: depthToCameraTransformID,
        fromFrameID: "FRAME_DEPTH_SENSOR",
        toFrameID: "FRAME_CAMERA_OPTICAL",
        frameEpochID: frameEpochID,
        sessionRunID: sessionRunID,
        worldOriginRevision: worldOriginRevision,
        timestampNanoseconds: 0,
        clockDomain: .fixtureDepth,
        matrix: HomogeneousMatrix4x4.identity(),
        authority: "TEST_FIXTURE",
        sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
      ),
      TransformEdge(
        transformID: "XF-CAMERA-TO-DEPTH-000001",
        fromFrameID: "FRAME_CAMERA_OPTICAL",
        toFrameID: "FRAME_DEPTH_SENSOR",
        frameEpochID: frameEpochID,
        sessionRunID: sessionRunID,
        worldOriginRevision: worldOriginRevision,
        timestampNanoseconds: 0,
        clockDomain: .fixtureCamera,
        matrix: HomogeneousMatrix4x4.identity(),
        authority: "TEST_FIXTURE",
        sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
      ),
    ]
  }

  public static func defaultClockCorrelations() -> [ClockCorrelation] {
    [
      ClockCorrelation(
        correlationID: cameraToDepthCorrelationID,
        sourceDomain: .fixtureCamera,
        destinationDomain: .fixtureDepth,
        offsetNanoseconds: 0,
        authority: "TEST_FIXTURE",
        method: "explicit_fixture_identity",
        validFromNanoseconds: 0,
        validUntilNanoseconds: 10_000_000_000
      ),
    ]
  }

  public static func defaultCalibration() -> DepthCalibration {
    let fx = 200.0, fy = 200.0, cx = 1.5, cy = 1.5
    return DepthCalibration(
      calibrationID: calibrationID,
      depthWidth: FixtureDepthPayload.width,
      depthHeight: FixtureDepthPayload.height,
      cameraReferenceWidth: 4,
      cameraReferenceHeight: 4,
      intrinsicsMatrix: [fx, 0, cx, 0, fy, cy, 0, 0, 1],
      focalLengthX: fx,
      focalLengthY: fy,
      principalPointX: cx,
      principalPointY: cy,
      depthScale: 1.0,
      distortionModel: "NONE",
      distortionParameters: [],
      depthFrameID: "FRAME_DEPTH_SENSOR",
      cameraFrameID: "FRAME_CAMERA_OPTICAL",
      depthToCameraTransformID: depthToCameraTransformID,
      units: "meters",
      frameEpochID: frameEpochID,
      sessionRunID: sessionRunID,
      worldOriginRevision: worldOriginRevision,
      evidenceOriginAuthority: "TEST_FIXTURE"
    )
  }

  public static func defaultAssociations(
    camera: [SpatialSampleEnvelope<CameraSample>],
    depth: [SpatialSampleEnvelope<DepthSample>],
    correlations: [ClockCorrelation] = defaultClockCorrelations()
  ) throws -> [RGBDepthAssociationRecord] {
    guard let corr = correlations.first(where: { $0.correlationID == cameraToDepthCorrelationID })
    else {
      throw SpatialEvidenceError.unknownClockCorrelationID(cameraToDepthCorrelationID)
    }
    var out: [RGBDepthAssociationRecord] = []
    let n = min(camera.count, depth.count)
    for i in 0..<n {
      let cam = camera[i]
      let dep = depth[i]
      let converted = corr.convertSourceToDestination(sourceTimestampNs: cam.acquisitionTimestampNs)
      let diff = Int64(dep.acquisitionTimestampNs) - converted
      out.append(
        RGBDepthAssociationRecord(
          associationID: "rgb-depth-assoc-\(i)",
          cameraSampleID: cam.sampleID,
          depthSampleID: dep.sampleID,
          cameraClockDomain: cam.clockDomain,
          depthClockDomain: dep.clockDomain,
          correlationID: corr.correlationID,
          associationTimestampNanoseconds: cam.acquisitionTimestampNs,
          timestampDifferenceNanoseconds: diff,
          calibrationID: calibrationID,
          cameraFrameID: "FRAME_CAMERA_OPTICAL",
          depthFrameID: "FRAME_DEPTH_SENSOR",
          transformID: depthToCameraTransformID,
          frameEpochID: frameEpochID,
          sessionRunID: sessionRunID,
          worldOriginRevision: worldOriginRevision,
          associationMethod: "explicit_fixture_binding",
          evidenceOriginAuthority: "TEST_FIXTURE"
        )
      )
    }
    return out
  }

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    try CanonicalJSON.data(object).write(to: url, options: .atomic)
  }

  private func writePayload<Payload>(
    stream: String,
    adapterID: String,
    samples: [SpatialSampleEnvelope<Payload>],
    root: URL,
    artifacts: inout [SpatialArtifactDescriptor],
    sampleIndex: inout [[String: Any]],
    bytesOf: (Payload) -> Data
  ) throws {
    try SpatialStreamID.validate(stream)
    let dir = root.appendingPathComponent(stream, isDirectory: true)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    for (idx, sample) in samples.enumerated() {
      let schemaKey = "\(sample.schemaID)@\(sample.schemaVersion)"
      guard SpatialEvidenceManifest.supportedSchemas.contains(schemaKey) else {
        throw SpatialEvidenceError.unsupportedSchema(id: sample.schemaID, version: sample.schemaVersion)
      }
      let fileName = String(format: "%04d.bin", idx)
      let rel = "payload/\(stream)/\(fileName)"
      let data = bytesOf(sample.payload)
      try data.write(to: dir.appendingPathComponent(fileName), options: .atomic)
      let sha = ContentHasher.sha256Hex(data)
      artifacts.append(
        SpatialArtifactDescriptor(
          relativePath: rel,
          byteLength: data.count,
          sha256: sha,
          mediaType: sample.mediaType,
          schemaID: sample.schemaID,
          schemaVersion: sample.schemaVersion,
          sampleID: sample.sampleID,
          streamID: stream,
          adapterID: adapterID
        )
      )
      sampleIndex.append([
        "sample_id": sample.sampleID,
        "sequence_index": sample.sequenceIndex,
        "acquisition_timestamp_ns": sample.acquisitionTimestampNs,
        "clock_domain": sample.clockDomain.rawValue,
        "coordinate_frame_id": sample.coordinateFrameID,
        "relative_path": rel,
        "stream_id": stream,
        "adapter_id": adapterID,
      ])
    }
  }
}
