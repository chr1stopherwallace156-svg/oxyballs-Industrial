import Foundation

/// Apple App Attest **client source candidate**.
///
/// Server verification remains in `AppAttestServerVerifier` (portable).
/// Physical App Attest generation remains PENDING_APPLE_HARDWARE_VALIDATION.
/// Do not claim DEVICE_PROVEN_UNCOMPROMISED.
#if canImport(DeviceCheck) && os(iOS)
import DeviceCheck

@available(iOS 14.0, *)
public struct AppleAppAttestClient: Sendable {
    public let keyID: String
    public let appIdentifier: String

    public init(keyID: String, appIdentifier: String) {
        self.keyID = keyID
        self.appIdentifier = appIdentifier
    }

    public func generateAssertion(
        challenge: AppAttestChallenge,
        packageClosureSHA256: String,
        captureSessionID: String,
        enrollmentRecordID: String
    ) throws -> AppAttestAssertionEnvelope {
        throw SpatialEvidenceError.packageAttestationFailed(
            "AppleAppAttestClient requires physical App Attest runtime validation (PENDING)"
        )
    }
}
#else
public struct AppleAppAttestClient: Sendable {
    public let keyID: String
    public let appIdentifier: String
    public let availabilityStatus: String = "UNAVAILABLE_ON_THIS_PLATFORM"

    public init(keyID: String = "ATTEST-KEY-UNAVAILABLE", appIdentifier: String = "com.elektron.capture") {
        self.keyID = keyID
        self.appIdentifier = appIdentifier
    }

    public func generateAssertion(
        challenge: AppAttestChallenge,
        packageClosureSHA256: String,
        captureSessionID: String,
        enrollmentRecordID: String
    ) throws -> AppAttestAssertionEnvelope {
        throw SpatialEvidenceError.packageAttestationFailed(
            "AppleAppAttestClient unavailable on this platform (Linux/source-candidate stub)"
        )
    }
}
#endif
