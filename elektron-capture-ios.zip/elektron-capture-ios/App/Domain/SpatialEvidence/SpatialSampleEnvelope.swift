import Foundation

/// Typed sample envelope — prefer this over optional-heavy mega-samples.
public struct SpatialSampleEnvelope<Payload: Sendable>: Sendable {
  public let sampleID: String
  public let sequenceIndex: UInt64
  public let acquisitionTimestampNs: UInt64
  public let clockDomain: ClockDomain
  public let coordinateFrameID: String
  public let payload: Payload
  public let mediaType: String
  public let schemaID: String
  public let schemaVersion: String

  public init(
    sampleID: String,
    sequenceIndex: UInt64,
    acquisitionTimestampNs: UInt64,
    clockDomain: ClockDomain,
    coordinateFrameID: String,
    payload: Payload,
    mediaType: String,
    schemaID: String,
    schemaVersion: String
  ) {
    self.sampleID = sampleID
    self.sequenceIndex = sequenceIndex
    self.acquisitionTimestampNs = acquisitionTimestampNs
    self.clockDomain = clockDomain
    self.coordinateFrameID = coordinateFrameID
    self.payload = payload
    self.mediaType = mediaType
    self.schemaID = schemaID
    self.schemaVersion = schemaVersion
  }
}

public struct CameraSample: Sendable, Equatable {
  public let width: Int
  public let height: Int
  public let pixelFormat: String
  public let bytes: Data
  public let orientation: String
  public let cameraIdentity: String
  public let intrinsicsAvailable: Bool

  public init(
    width: Int,
    height: Int,
    pixelFormat: String,
    bytes: Data,
    orientation: String = "up",
    cameraIdentity: String = "unknown",
    intrinsicsAvailable: Bool = false
  ) {
    self.width = width
    self.height = height
    self.pixelFormat = pixelFormat
    self.bytes = bytes
    self.orientation = orientation
    self.cameraIdentity = cameraIdentity
    self.intrinsicsAvailable = intrinsicsAvailable
  }
}

/// Legacy/synthetic-compatible depth buffer fields live on `DepthSample` (Sprint 3.3 expands).
/// Prefer constructing via the full initializer; the short form remains for Sprint 3.0 synthetic.
public struct DepthSample: Sendable, Equatable {
  public let width: Int
  public let height: Int
  public let depthUnit: String
  public let bytes: Data
  public let confidencePresent: Bool

  // Sprint 3.3 domain fields (defaults preserve synthetic compatibility).
  public let sourceKind: DepthSourceKind
  public let pixelFormat: DepthPixelFormat
  public let byteOrder: String
  public let rowStrideBytes: Int
  public let depthUnitEnum: DepthUnit
  public let minimumValidDepth: Double
  public let maximumValidDepth: Double
  public let invalidValueEncoding: DepthInvalidValueEncoding
  public let depthArtifactID: String
  public let calibrationID: String?
  public let confidenceArtifactID: String?
  public let validityArtifactID: String?
  public let confidenceAbsenceReason: String?
  public let validityAbsenceReason: String?
  public let timestampNanoseconds: UInt64
  public let clockDomain: ClockDomain
  public let coordinateFrameID: String
  public let frameEpochID: String
  public let sessionRunID: String
  public let worldOriginRevision: UInt64
  public let evidenceOriginAuthority: String
  public let depthEstimateAuthority: String
  public let streamID: String
  public let adapterID: String

  /// Sprint 3.0 synthetic convenience — maps to Float32-ish opaque bytes without claiming fixture schema.
  public init(width: Int, height: Int, depthUnit: String, bytes: Data, confidencePresent: Bool) {
    self.width = width
    self.height = height
    self.depthUnit = depthUnit
    self.bytes = bytes
    self.confidencePresent = confidencePresent
    self.sourceKind = .synthetic
    self.pixelFormat = .opaqueBytes
    self.byteOrder = "unspecified"
    self.rowStrideBytes = max(width, 1)
    self.depthUnitEnum = DepthUnit(rawValue: depthUnit) ?? .meters
    self.minimumValidDepth = 0
    self.maximumValidDepth = Double.greatestFiniteMagnitude
    self.invalidValueEncoding = .noneDeclared
    self.depthArtifactID = "synthetic-depth-artifact"
    self.calibrationID = nil
    self.confidenceArtifactID = confidencePresent ? "synthetic-confidence" : nil
    self.validityArtifactID = nil
    self.confidenceAbsenceReason = confidencePresent ? nil : "NOT_PROVIDED_BY_SYNTHETIC_ADAPTER"
    self.validityAbsenceReason = "NOT_PROVIDED_BY_SYNTHETIC_ADAPTER"
    self.timestampNanoseconds = 0
    self.clockDomain = .syntheticDeterministic
    self.coordinateFrameID = "FRAME_SYNTHETIC_WORLD"
    self.frameEpochID = "epoch-synthetic-1"
    self.sessionRunID = "run-synthetic-1"
    self.worldOriginRevision = 1
    self.evidenceOriginAuthority = "SYNTHETIC"
    self.depthEstimateAuthority = "GUIDANCE_ESTIMATE"
    self.streamID = SpatialStreamID.depth
    self.adapterID = "synth.depth"
  }

  public init(
    width: Int,
    height: Int,
    bytes: Data,
    sourceKind: DepthSourceKind,
    pixelFormat: DepthPixelFormat,
    byteOrder: String,
    rowStrideBytes: Int,
    depthUnit: DepthUnit,
    minimumValidDepth: Double,
    maximumValidDepth: Double,
    invalidValueEncoding: DepthInvalidValueEncoding,
    depthArtifactID: String,
    calibrationID: String?,
    confidenceArtifactID: String?,
    validityArtifactID: String?,
    confidenceAbsenceReason: String?,
    validityAbsenceReason: String?,
    timestampNanoseconds: UInt64,
    clockDomain: ClockDomain,
    coordinateFrameID: String,
    frameEpochID: String,
    sessionRunID: String,
    worldOriginRevision: UInt64,
    evidenceOriginAuthority: String,
    depthEstimateAuthority: String,
    streamID: String = SpatialStreamID.depth,
    adapterID: String
  ) {
    self.width = width
    self.height = height
    self.depthUnit = depthUnit.rawValue
    self.bytes = bytes
    self.confidencePresent = confidenceArtifactID != nil
    self.sourceKind = sourceKind
    self.pixelFormat = pixelFormat
    self.byteOrder = byteOrder
    self.rowStrideBytes = rowStrideBytes
    self.depthUnitEnum = depthUnit
    self.minimumValidDepth = minimumValidDepth
    self.maximumValidDepth = maximumValidDepth
    self.invalidValueEncoding = invalidValueEncoding
    self.depthArtifactID = depthArtifactID
    self.calibrationID = calibrationID
    self.confidenceArtifactID = confidenceArtifactID
    self.validityArtifactID = validityArtifactID
    self.confidenceAbsenceReason = confidenceAbsenceReason
    self.validityAbsenceReason = validityAbsenceReason
    self.timestampNanoseconds = timestampNanoseconds
    self.clockDomain = clockDomain
    self.coordinateFrameID = coordinateFrameID
    self.frameEpochID = frameEpochID
    self.sessionRunID = sessionRunID
    self.worldOriginRevision = worldOriginRevision
    self.evidenceOriginAuthority = evidenceOriginAuthority
    self.depthEstimateAuthority = depthEstimateAuthority
    self.streamID = streamID
    self.adapterID = adapterID
  }

  public func asDictionary() -> [String: Any] {
    var d: [String: Any] = [
      "width": width,
      "height": height,
      "depth_unit": depthUnitEnum.rawValue,
      "source_kind": sourceKind.rawValue,
      "pixel_format": pixelFormat.rawValue,
      "byte_order": byteOrder,
      "row_stride_bytes": rowStrideBytes,
      "minimum_valid_depth": minimumValidDepth,
      "maximum_valid_depth": maximumValidDepth,
      "invalid_value_encoding": invalidValueEncoding.rawValue,
      "depth_artifact_id": depthArtifactID,
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain.rawValue,
      "coordinate_frame_id": coordinateFrameID,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "evidence_origin_authority": evidenceOriginAuthority,
      "depth_estimate_authority": depthEstimateAuthority,
      "stream_id": streamID,
      "adapter_id": adapterID,
      "confidence_present": confidencePresent,
      "byte_length": bytes.count,
    ]
    if let calibrationID { d["calibration_id"] = calibrationID }
    if let confidenceArtifactID {
      d["confidence_artifact_id"] = confidenceArtifactID
    } else if let confidenceAbsenceReason {
      d["confidence_absence_reason"] = confidenceAbsenceReason
    }
    if let validityArtifactID {
      d["validity_artifact_id"] = validityArtifactID
    } else if let validityAbsenceReason {
      d["validity_absence_reason"] = validityAbsenceReason
    }
    return d
  }
}

public struct MotionSample: Sendable, Equatable {
  public let accelerationXYZ: [Double]
  public let rotationRateXYZ: [Double]
  public let gravityXYZ: [Double]
  public let userAccelerationXYZ: [Double]
  public let attitudeQuaternion: [Double]
  public let samplingIntervalNs: UInt64
  public let bytes: Data

  public init(
    accelerationXYZ: [Double],
    rotationRateXYZ: [Double],
    attitudeQuaternion: [Double],
    bytes: Data,
    gravityXYZ: [Double] = [0, 0, -1],
    userAccelerationXYZ: [Double] = [0, 0, 0],
    samplingIntervalNs: UInt64 = 10_000_000
  ) {
    self.accelerationXYZ = accelerationXYZ
    self.rotationRateXYZ = rotationRateXYZ
    self.gravityXYZ = gravityXYZ
    self.userAccelerationXYZ = userAccelerationXYZ
    self.attitudeQuaternion = attitudeQuaternion
    self.samplingIntervalNs = samplingIntervalNs
    self.bytes = bytes
  }
}

// MARK: - Pose math helpers (Foundation-portable)

public struct Vector3D: Sendable, Equatable {
  public let x: Double
  public let y: Double
  public let z: Double

  public init(x: Double, y: Double, z: Double) {
    self.x = x
    self.y = y
    self.z = z
  }

  public var asArray: [Double] { [x, y, z] }

  public var isFinite: Bool {
    x.isFinite && y.isFinite && z.isFinite
  }
}

public struct QuaternionD: Sendable, Equatable {
  public let x: Double
  public let y: Double
  public let z: Double
  public let w: Double

  public static let identity = QuaternionD(x: 0, y: 0, z: 0, w: 1)

  public init(x: Double, y: Double, z: Double, w: Double) {
    self.x = x
    self.y = y
    self.z = z
    self.w = w
  }

  public var asArray: [Double] { [x, y, z, w] }

  public var magnitude: Double {
    (x * x + y * y + z * z + w * w).squareRoot()
  }

  public var isFinite: Bool {
    x.isFinite && y.isFinite && z.isFinite && w.isFinite
  }

  public var isZero: Bool {
    x == 0 && y == 0 && z == 0 && w == 0
  }

  public var isNormalized: Bool {
    guard isFinite, !isZero else { return false }
    return abs(magnitude - 1.0) <= 1e-6
  }

  /// Rejects NaN/Inf/zero; returns self if already unit-length within tolerance.
  public func validated(tolerance: Double = 1e-6) throws -> QuaternionD {
    guard isFinite else {
      throw SpatialEvidenceError.invalidQuaternion("NaN_or_infinite_component")
    }
    guard !isZero else {
      throw SpatialEvidenceError.invalidQuaternion("zero_quaternion")
    }
    let mag = magnitude
    guard abs(mag - 1.0) <= tolerance else {
      throw SpatialEvidenceError.nonNormalizedQuaternion(magnitude: mag)
    }
    return self
  }

  public func normalized() throws -> QuaternionD {
    guard isFinite else {
      throw SpatialEvidenceError.invalidQuaternion("NaN_or_infinite_component")
    }
    guard !isZero else {
      throw SpatialEvidenceError.invalidQuaternion("zero_quaternion")
    }
    let mag = magnitude
    return QuaternionD(x: x / mag, y: y / mag, z: z / mag, w: w / mag)
  }
}

public enum PoseTrackingState: String, Codable, Sendable, Equatable, CaseIterable {
  case normal = "NORMAL"
  case limited = "LIMITED"
  case notAvailable = "NOT_AVAILABLE"
  case relocalizing = "RELOCALIZING"
}

public enum PoseFailureReason: String, Codable, Sendable, Equatable, CaseIterable {
  case none = "NONE"
  case insufficientFeatures = "INSUFFICIENT_FEATURES"
  case excessiveMotion = "EXCESSIVE_MOTION"
  case insufficientLight = "INSUFFICIENT_LIGHT"
  case relocalizationRequired = "RELOCALIZATION_REQUIRED"
  case sessionInterrupted = "SESSION_INTERRUPTED"
  case trackingLost = "TRACKING_LOST"
  case invalidQuaternion = "INVALID_QUATERNION"
  case nanOrInfiniteTransform = "NAN_OR_INFINITE_TRANSFORM"
  case unknown = "UNKNOWN"
}

/// Optional pose-specific frame metadata (source→destination transform convention).
public struct PoseFrameDescriptor: Sendable, Equatable {
  public let sourceFrameID: String
  public let destinationFrameID: String
  public let units: String
  public let handedness: String
  public let authority: String

  public init(
    sourceFrameID: String,
    destinationFrameID: String,
    units: String = "meters",
    handedness: String = "right",
    authority: String = "GUIDANCE_ESTIMATE"
  ) {
    self.sourceFrameID = sourceFrameID
    self.destinationFrameID = destinationFrameID
    self.units = units
    self.handedness = handedness
    self.authority = authority
  }

  public func asDictionary() -> [String: Any] {
    [
      "source_frame_id": sourceFrameID,
      "destination_frame_id": destinationFrameID,
      "units": units,
      "handedness": handedness,
      "authority": authority,
    ]
  }
}

/// Pose estimate sample — `authority` is the **pose estimate** authority and defaults to
/// `GUIDANCE_ESTIMATE` (never ENGINEERING_VERIFIED). Package/fixture evidence origin is a
/// separate field (`evidence_origin_authority` on manifests / associations).
/// Schema fixture path: `PoseSample@1.0.0-phase3-fixture`.
public struct PoseSample: Sendable, Equatable {
  public let translationMeters: Vector3D
  public let rotationQuaternion: QuaternionD
  public let trackingState: PoseTrackingState
  public let trackingReason: PoseFailureReason?
  public let timestampNanoseconds: UInt64
  public let clockDomain: ClockDomain
  public let sourceFrameID: String
  public let destinationFrameID: String
  /// Pose estimate authority — defaults to GUIDANCE_ESTIMATE.
  public let authority: String
  /// ARKit / world-tracking epoch identity (stable per world-origin revision).
  public let frameEpochID: String
  /// Pose session run identity (new UUID string per `start()`).
  public let sessionRunID: String
  /// Monotonic world-origin revision within a session run (starts at 1).
  public let worldOriginRevision: UInt64
  public let bytes: Data

  /// Column-major 4×4 homogeneous transform derived from translation + quaternion.
  public var transform4x4: [Double] {
    Self.matrix4x4(translation: translationMeters, rotation: rotationQuaternion)
  }

  public init(
    translationMeters: Vector3D,
    rotationQuaternion: QuaternionD,
    trackingState: PoseTrackingState = .normal,
    trackingReason: PoseFailureReason? = nil,
    timestampNanoseconds: UInt64,
    clockDomain: ClockDomain,
    sourceFrameID: String,
    destinationFrameID: String,
    authority: String = "GUIDANCE_ESTIMATE",
    frameEpochID: String = "epoch-fixture-1",
    sessionRunID: String = "run-fixture-1",
    worldOriginRevision: UInt64 = 1,
    bytes: Data
  ) {
    self.translationMeters = translationMeters
    self.rotationQuaternion = rotationQuaternion
    self.trackingState = trackingState
    self.trackingReason = trackingReason
    self.timestampNanoseconds = timestampNanoseconds
    self.clockDomain = clockDomain
    self.sourceFrameID = sourceFrameID
    self.destinationFrameID = destinationFrameID
    self.authority = authority
    self.frameEpochID = frameEpochID
    self.sessionRunID = sessionRunID
    self.worldOriginRevision = worldOriginRevision
    self.bytes = bytes
  }

  /// Convenience for synthetic/fixture adapters that author a column-major 4×4.
  public init(
    transform4x4: [Double],
    authority: String = "GUIDANCE_ESTIMATE",
    bytes: Data,
    trackingState: PoseTrackingState = .normal,
    trackingReason: PoseFailureReason? = nil,
    timestampNanoseconds: UInt64 = 0,
    clockDomain: ClockDomain = .syntheticDeterministic,
    sourceFrameID: String = "FRAME_AR_SESSION_WORLD",
    destinationFrameID: String = "FRAME_CAPTURE_SESSION_ROOT",
    frameEpochID: String = "epoch-fixture-1",
    sessionRunID: String = "run-fixture-1",
    worldOriginRevision: UInt64 = 1
  ) {
    precondition(transform4x4.count == 16, "transform4x4 must have 16 elements")
    let (t, q) = Self.decompose(transform4x4)
    self.translationMeters = t
    self.rotationQuaternion = q
    self.trackingState = trackingState
    self.trackingReason = trackingReason
    self.timestampNanoseconds = timestampNanoseconds
    self.clockDomain = clockDomain
    self.sourceFrameID = sourceFrameID
    self.destinationFrameID = destinationFrameID
    self.authority = authority
    self.frameEpochID = frameEpochID
    self.sessionRunID = sessionRunID
    self.worldOriginRevision = worldOriginRevision
    self.bytes = bytes
  }

  public static func matrix4x4(translation: Vector3D, rotation: QuaternionD) -> [Double] {
    let x = rotation.x, y = rotation.y, z = rotation.z, w = rotation.w
    let xx = x * x, yy = y * y, zz = z * z
    let xy = x * y, xz = x * z, yz = y * z
    let wx = w * x, wy = w * y, wz = w * z
    // Column-major 4×4
    return [
      1 - 2 * (yy + zz), 2 * (xy + wz), 2 * (xz - wy), 0,
      2 * (xy - wz), 1 - 2 * (xx + zz), 2 * (yz + wx), 0,
      2 * (xz + wy), 2 * (yz - wx), 1 - 2 * (xx + yy), 0,
      translation.x, translation.y, translation.z, 1,
    ]
  }

  public static func decompose(_ m: [Double]) -> (Vector3D, QuaternionD) {
    let t = Vector3D(x: m[12], y: m[13], z: m[14])
    // Extract rotation from upper-left 3×3 (column-major).
    let m00 = m[0], m10 = m[1], m20 = m[2]
    let m01 = m[4], m11 = m[5], m21 = m[6]
    let m02 = m[8], m12 = m[9], m22 = m[10]
    let trace = m00 + m11 + m22
    let q: QuaternionD
    if trace > 0 {
      let s = (trace + 1).squareRoot() * 2
      q = QuaternionD(
        x: (m21 - m12) / s,
        y: (m02 - m20) / s,
        z: (m10 - m01) / s,
        w: 0.25 * s
      )
    } else if m00 > m11 && m00 > m22 {
      let s = (1 + m00 - m11 - m22).squareRoot() * 2
      q = QuaternionD(
        x: 0.25 * s,
        y: (m01 + m10) / s,
        z: (m02 + m20) / s,
        w: (m21 - m12) / s
      )
    } else if m11 > m22 {
      let s = (1 + m11 - m00 - m22).squareRoot() * 2
      q = QuaternionD(
        x: (m01 + m10) / s,
        y: 0.25 * s,
        z: (m12 + m21) / s,
        w: (m02 - m20) / s
      )
    } else {
      let s = (1 + m22 - m00 - m11).squareRoot() * 2
      q = QuaternionD(
        x: (m02 + m20) / s,
        y: (m12 + m21) / s,
        z: 0.25 * s,
        w: (m10 - m01) / s
      )
    }
    return (t, (try? q.normalized()) ?? q)
  }

  public func asDictionary() -> [String: Any] {
    var d: [String: Any] = [
      "translation_meters": translationMeters.asArray,
      "rotation_quaternion": rotationQuaternion.asArray,
      "tracking_state": trackingState.rawValue,
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain.rawValue,
      "source_frame_id": sourceFrameID,
      "destination_frame_id": destinationFrameID,
      // Pose estimate authority (GUIDANCE_ESTIMATE by default) — not evidence origin.
      "authority": authority,
      "pose_estimate_authority": authority,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "transform_4x4": transform4x4,
    ]
    if let trackingReason {
      d["tracking_reason"] = trackingReason.rawValue
    }
    return d
  }
}

/// Column-major 4×4 homogeneous matrix helpers (rotation + translation).
public enum HomogeneousMatrix4x4 {
  public static func identity() -> [Double] {
    var m = [Double](repeating: 0, count: 16)
    m[0] = 1; m[5] = 1; m[10] = 1; m[15] = 1
    return m
  }

  public static func approximatelyEqual(
    _ a: [Double],
    _ b: [Double],
    tolerance: Double = 1e-6
  ) -> Bool {
    guard a.count == 16, b.count == 16 else { return false }
    for i in 0..<16 {
      if abs(a[i] - b[i]) > tolerance { return false }
    }
    return true
  }

  /// Determinant of the upper-left 3×3 rotation block (equals full 4×4 det when bottom row is [0,0,0,1]).
  public static func rotationDeterminant(_ m: [Double]) -> Double {
    let a = m[0], b = m[4], c = m[8]
    let d = m[1], e = m[5], f = m[9]
    let g = m[2], h = m[6], i = m[10]
    return a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
  }

  public static func isAllZeros(_ m: [Double], tolerance: Double = 1e-6) -> Bool {
    guard m.count == 16 else { return true }
    return m.allSatisfy { abs($0) <= tolerance }
  }

  public static func isDegenerate(_ m: [Double], tolerance: Double = 1e-6) -> Bool {
    guard m.count == 16 else { return true }
    if isAllZeros(m, tolerance: tolerance) { return true }
    return abs(rotationDeterminant(m)) < tolerance
  }

  /// Analytic inverse for rigid (rotation + translation) homogeneous transforms.
  /// Identity inverts to identity. Degenerate / singular matrices throw.
  public static func invert(_ m: [Double], tolerance: Double = 1e-6) throws -> [Double] {
    guard m.count == 16 else {
      throw SpatialEvidenceError.nanOrInfiniteTransform("matrix_length_\(m.count)")
    }
    if approximatelyEqual(m, identity(), tolerance: tolerance) {
      return identity()
    }
    if isDegenerate(m, tolerance: tolerance) {
      throw SpatialEvidenceError.nanOrInfiniteTransform("singular_or_degenerate")
    }
    // Rᵀ
    var out = [Double](repeating: 0, count: 16)
    out[0] = m[0]; out[1] = m[4]; out[2] = m[8]
    out[4] = m[1]; out[5] = m[5]; out[6] = m[9]
    out[8] = m[2]; out[9] = m[6]; out[10] = m[10]
    out[3] = 0; out[7] = 0; out[11] = 0; out[15] = 1
    let tx = m[12], ty = m[13], tz = m[14]
    out[12] = -(out[0] * tx + out[4] * ty + out[8] * tz)
    out[13] = -(out[1] * tx + out[5] * ty + out[9] * tz)
    out[14] = -(out[2] * tx + out[6] * ty + out[10] * tz)
    return out
  }

  public static func multiply(_ a: [Double], _ b: [Double]) -> [Double] {
    precondition(a.count == 16 && b.count == 16)
    var out = [Double](repeating: 0, count: 16)
    for col in 0..<4 {
      for row in 0..<4 {
        var sum = 0.0
        for k in 0..<4 {
          sum += a[row + k * 4] * b[k + col * 4]
        }
        out[row + col * 4] = sum
      }
    }
    return out
  }
}
