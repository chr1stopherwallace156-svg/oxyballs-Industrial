import Foundation

// MARK: - Delivery profiles (inspection vs engineering)

public enum DeliveryCompressionPolicy: String, Codable, Sendable, Equatable {
  case none = "NONE"
  case fixtureGzipLight = "FIXTURE_GZIP_LIGHT"
  case fixtureUncompressed = "FIXTURE_UNCOMPRESSED"
}

public struct DeliveryPrivacyPolicy: Codable, Sendable, Equatable {
  public var privacyPolicyID: String
  public var allowRestrictedRaw: Bool
  public var requireClientSafeDerivatives: Bool

  public func dictionary() -> [String: Any] {
    [
      "privacy_policy_id": privacyPolicyID,
      "allow_restricted_raw": allowRestrictedRaw,
      "require_client_safe_derivatives": requireClientSafeDerivatives,
    ]
  }
}

public struct DeliveryArtifactSelection: Codable, Sendable, Equatable {
  public var includeRestrictedRaw: Bool
  public var includeClientSafeDerivatives: Bool
  public var includeQualitySummaries: Bool
  public var includeSpatialStreams: Bool
  public var includeCalibration: Bool
  public var includeTransforms: Bool
  public var includePackageClosure: Bool

  public func dictionary() -> [String: Any] {
    [
      "include_restricted_raw": includeRestrictedRaw,
      "include_client_safe_derivatives": includeClientSafeDerivatives,
      "include_quality_summaries": includeQualitySummaries,
      "include_spatial_streams": includeSpatialStreams,
      "include_calibration": includeCalibration,
      "include_transforms": includeTransforms,
      "include_package_closure": includePackageClosure,
    ]
  }
}

public struct EvidenceDeliveryProfile: Codable, Sendable, Equatable {
  public var profileID: String
  public var profileKind: String
  public var selection: DeliveryArtifactSelection
  public var compression: DeliveryCompressionPolicy
  public var privacy: DeliveryPrivacyPolicy
  public var accessClass: EvidenceAccessClass
  public var note: String

  public static let inspectionProfileID = "PROFILE-INSPECTION-000001"
  public static let engineeringProfileID = "PROFILE-ENGINEERING-000001"

  public static func inspection(privacyPolicyID: String) -> EvidenceDeliveryProfile {
    EvidenceDeliveryProfile(
      profileID: inspectionProfileID,
      profileKind: "INSPECTION_PACKAGE",
      selection: DeliveryArtifactSelection(
        includeRestrictedRaw: false,
        includeClientSafeDerivatives: true,
        includeQualitySummaries: true,
        includeSpatialStreams: false,
        includeCalibration: false,
        includeTransforms: false,
        includePackageClosure: true
      ),
      compression: .fixtureGzipLight,
      privacy: DeliveryPrivacyPolicy(
        privacyPolicyID: privacyPolicyID,
        allowRestrictedRaw: false,
        requireClientSafeDerivatives: true
      ),
      accessClass: .publicClient,
      note: "Client-safe rapid field transfer; no restricted raw unless policy permits"
    )
  }

  public static func engineering(privacyPolicyID: String) -> EvidenceDeliveryProfile {
    EvidenceDeliveryProfile(
      profileID: engineeringProfileID,
      profileKind: "ENGINEERING_PACKAGE",
      selection: DeliveryArtifactSelection(
        includeRestrictedRaw: true,
        includeClientSafeDerivatives: true,
        includeQualitySummaries: true,
        includeSpatialStreams: true,
        includeCalibration: true,
        includeTransforms: true,
        includePackageClosure: true
      ),
      compression: .fixtureUncompressed,
      privacy: DeliveryPrivacyPolicy(
        privacyPolicyID: privacyPolicyID,
        allowRestrictedRaw: true,
        requireClientSafeDerivatives: true
      ),
      accessClass: .engineeringRestricted,
      note: "Controlled full-resolution transfer; restricted access classification"
    )
  }

  public func dictionary() -> [String: Any] {
    [
      "profile_id": profileID,
      "profile_kind": profileKind,
      "selection": selection.dictionary(),
      "compression": compression.rawValue,
      "privacy": privacy.dictionary(),
      "access_class": accessClass.rawValue,
      "note": note,
      "schema_id": "EvidenceDeliveryProfile",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}

public struct DeliveryProfileResult: Codable, Sendable, Equatable {
  public var profileID: String
  public var packageID: String
  public var packageClosureSHA256: String
  public var manifestSHA256: String
  public var includedRelativePaths: [String]
  public var excludedRelativePaths: [String]
  public var sourcePackageID: String
  public var sourcePackageClosureSHA256: String

  public func dictionary() -> [String: Any] {
    [
      "profile_id": profileID,
      "package_id": packageID,
      "package_closure_sha256": packageClosureSHA256,
      "manifest_sha256": manifestSHA256,
      "included_relative_paths": includedRelativePaths.sorted(),
      "excluded_relative_paths": excludedRelativePaths.sorted(),
      "source_package_id": sourcePackageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "schema_id": "DeliveryProfileResult",
      "schema_version": "1.0.0-phase3-fixture",
      "note": "Derived package with its own manifest/closure — not an undocumented mutation",
    ]
  }
}
