import Foundation

// MARK: - Quality signal taxonomy (Sprint 3.5)

public enum CaptureQualitySignalType: String, Codable, Sendable, Equatable, CaseIterable {
  case imageBlurEstimate = "IMAGE_BLUR_ESTIMATE"
  case underexposure = "UNDEREXPOSURE"
  case overexposure = "OVEREXPOSURE"
  case cameraFrameCadence = "CAMERA_FRAME_CADENCE"
  case cameraFrameDuplication = "CAMERA_FRAME_DUPLICATION"
  case deviceMotionMagnitude = "DEVICE_MOTION_MAGNITUDE"
  case excessiveAngularMotion = "EXCESSIVE_ANGULAR_MOTION"
  case excessiveTranslationRate = "EXCESSIVE_TRANSLATION_RATE"
  case timestampSynchronizationHealth = "TIMESTAMP_SYNCHRONIZATION_HEALTH"
  case trackingQuality = "TRACKING_QUALITY"
  case depthAvailability = "DEPTH_AVAILABILITY"
  case depthValidityPercentage = "DEPTH_VALIDITY_PERCENTAGE"
  case confidenceMapQuality = "CONFIDENCE_MAP_QUALITY"
  case droppedSampleRate = "DROPPED_SAMPLE_RATE"
  case requiredStreamStarvation = "REQUIRED_STREAM_STARVATION"
  case optionalStreamDegradation = "OPTIONAL_STREAM_DEGRADATION"
  case storagePressure = "STORAGE_PRESSURE"
  case interruptionFrequency = "INTERRUPTION_FREQUENCY"
  case recoverySuccess = "RECOVERY_SUCCESS"
  case frameEpochInstability = "FRAME_EPOCH_INSTABILITY"
  case clockCorrelationValidity = "CLOCK_CORRELATION_VALIDITY"
}

public enum CaptureQualitySeverity: String, Codable, Sendable, Equatable, CaseIterable {
  case informational = "INFORMATIONAL"
  case warning = "WARNING"
  case severe = "SEVERE"
  case blocking = "BLOCKING"
}

public enum ThresholdComparison: String, Codable, Sendable, Equatable {
  case belowMinimum = "BELOW_MINIMUM"
  case withinRange = "WITHIN_RANGE"
  case aboveMaximum = "ABOVE_MAXIMUM"
  case equalsExact = "EQUALS_EXACT"
  case unavailable = "UNAVAILABLE"
}

public enum CharacterizationStatus: String, Codable, Sendable, Equatable {
  case pendingPhysicalCharacterization = "PENDING_PHYSICAL_CHARACTERIZATION"
  case fixtureOnly = "FIXTURE_ONLY"
  case physicallyCharacterized = "PHYSICALLY_CHARACTERIZED"
}

public enum SourceClassification: String, Codable, Sendable, Equatable {
  case deterministicTestFixture = "DETERMINISTIC_TEST_FIXTURE"
  case provisionalFieldHeuristic = "PROVISIONAL_FIELD_HEURISTIC"
  case physicallyCharacterized = "PHYSICALLY_CHARACTERIZED"
}

public enum SystemTolerance: String, Codable, Sendable, Equatable {
  case noSystemToleranceAssigned = "NO_SYSTEM_TOLERANCE_ASSIGNED"
  case provisional = "PROVISIONAL"
  case assigned = "ASSIGNED"
}

/// Versioned threshold profile. Fixture defaults are NOT proven physical optima.
public struct CaptureQualityThresholdProfile: Codable, Sendable, Equatable {
  public var thresholdProfileID: String
  public var schemaVersion: String
  public var sourceClassification: SourceClassification
  public var characterizationStatus: CharacterizationStatus
  public var systemTolerance: SystemTolerance
  /// signal_type → absolute max (or min depending on signal semantics).
  public var maximumLimits: [String: Double]
  public var minimumLimits: [String: Double]
  public var applicability: String

  public static let fixtureSchemaVersion = "1.0.0-phase3-fixture"
  public static let fixtureProfileID = "QTP-FIXTURE-GUIDED-000001"

  public init(
    thresholdProfileID: String = Self.fixtureProfileID,
    schemaVersion: String = Self.fixtureSchemaVersion,
    sourceClassification: SourceClassification = .deterministicTestFixture,
    characterizationStatus: CharacterizationStatus = .pendingPhysicalCharacterization,
    systemTolerance: SystemTolerance = .noSystemToleranceAssigned,
    maximumLimits: [String: Double] = Self.defaultMaximums,
    minimumLimits: [String: Double] = Self.defaultMinimums,
    applicability: String = "linux_fixture_guided_capture_only"
  ) {
    self.thresholdProfileID = thresholdProfileID
    self.schemaVersion = schemaVersion
    self.sourceClassification = sourceClassification
    self.characterizationStatus = characterizationStatus
    self.systemTolerance = systemTolerance
    self.maximumLimits = maximumLimits
    self.minimumLimits = minimumLimits
    self.applicability = applicability
  }

  public static let defaultMaximums: [String: Double] = [
    CaptureQualitySignalType.imageBlurEstimate.rawValue: 0.35,
    CaptureQualitySignalType.overexposure.rawValue: 0.20,
    CaptureQualitySignalType.underexposure.rawValue: 0.20,
    CaptureQualitySignalType.deviceMotionMagnitude.rawValue: 1.5,
    CaptureQualitySignalType.excessiveAngularMotion.rawValue: 1.2,
    CaptureQualitySignalType.excessiveTranslationRate.rawValue: 2.0,
    CaptureQualitySignalType.droppedSampleRate.rawValue: 0.10,
    CaptureQualitySignalType.storagePressure.rawValue: 0.85,
    CaptureQualitySignalType.interruptionFrequency.rawValue: 2.0,
    CaptureQualitySignalType.cameraFrameDuplication.rawValue: 0.05,
  ]

  public static let defaultMinimums: [String: Double] = [
    CaptureQualitySignalType.trackingQuality.rawValue: 0.60,
    CaptureQualitySignalType.depthValidityPercentage.rawValue: 0.70,
    CaptureQualitySignalType.confidenceMapQuality.rawValue: 0.50,
    CaptureQualitySignalType.timestampSynchronizationHealth.rawValue: 0.80,
    CaptureQualitySignalType.clockCorrelationValidity.rawValue: 0.90,
    CaptureQualitySignalType.recoverySuccess.rawValue: 1.0,
    CaptureQualitySignalType.cameraFrameCadence.rawValue: 8.0,
  ]

  public func dictionary() -> [String: Any] {
    [
      "threshold_profile_id": thresholdProfileID,
      "schema_id": "CaptureQualityThresholdProfile",
      "schema_version": schemaVersion,
      "source_classification": sourceClassification.rawValue,
      "characterization_status": characterizationStatus.rawValue,
      "system_tolerance": systemTolerance.rawValue,
      "maximum_limits": maximumLimits.sorted { $0.key < $1.key }.reduce(into: [String: Double]()) { $0[$1.key] = $1.value },
      "minimum_limits": minimumLimits.sorted { $0.key < $1.key }.reduce(into: [String: Double]()) { $0[$1.key] = $1.value },
      "applicability": applicability,
    ]
  }
}

/// Operator/session-supplied or fixture-declared quality observation (immutable input).
public struct CaptureQualityObservation: Codable, Sendable, Equatable {
  public var observationID: String
  public var signalType: CaptureQualitySignalType
  public var observedValue: Double
  public var unit: String
  public var timestampNanoseconds: UInt64
  public var clockDomain: String
  public var captureSessionID: String
  public var streamID: String?
  public var regionID: String?
  public var supportingEvidenceIDs: [String]
  public var evidenceOriginAuthority: EvidenceAuthority

  public init(
    observationID: String,
    signalType: CaptureQualitySignalType,
    observedValue: Double,
    unit: String,
    timestampNanoseconds: UInt64,
    clockDomain: String,
    captureSessionID: String,
    streamID: String? = nil,
    regionID: String? = nil,
    supportingEvidenceIDs: [String],
    evidenceOriginAuthority: EvidenceAuthority = .testFixture
  ) {
    self.observationID = observationID
    self.signalType = signalType
    self.observedValue = observedValue
    self.unit = unit
    self.timestampNanoseconds = timestampNanoseconds
    self.clockDomain = clockDomain
    self.captureSessionID = captureSessionID
    self.streamID = streamID
    self.regionID = regionID
    self.supportingEvidenceIDs = supportingEvidenceIDs
    self.evidenceOriginAuthority = evidenceOriginAuthority
  }
}

public struct CaptureQualitySignal: Codable, Sendable, Equatable {
  public var signalID: String
  public var signalType: CaptureQualitySignalType
  public var severity: CaptureQualitySeverity
  public var timestampNanoseconds: UInt64
  public var clockDomain: String
  public var captureSessionID: String
  public var streamID: String?
  public var regionID: String?
  public var supportingEvidenceIDs: [String]
  public var observedValue: Double
  public var thresholdProfileID: String
  public var thresholdComparison: ThresholdComparison
  public var evidenceOriginAuthority: EvidenceAuthority
  public var guidanceAuthority: EvidenceAuthority
  public var characterizationStatus: CharacterizationStatus
  public var resolved: Bool

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "signal_id": signalID,
      "signal_type": signalType.rawValue,
      "severity": severity.rawValue,
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain,
      "capture_session_id": captureSessionID,
      "supporting_evidence_ids": supportingEvidenceIDs.sorted(),
      "observed_value": observedValue,
      "threshold_profile_id": thresholdProfileID,
      "threshold_comparison": thresholdComparison.rawValue,
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
      "guidance_authority": guidanceAuthority.rawValue,
      "characterization_status": characterizationStatus.rawValue,
      "resolved": resolved,
    ]
    if let streamID { d["stream_id"] = streamID }
    if let regionID { d["region_id"] = regionID }
    return d
  }
}

public struct CaptureQualitySummary: Codable, Sendable, Equatable {
  public var summaryID: String
  public var captureSessionID: String
  public var thresholdProfileID: String
  public var signalCountsBySeverity: [String: Int]
  public var activeSevereCount: Int
  public var activeBlockingCount: Int
  public var unresolvedSignalIDs: [String]
  public var evidenceOriginAuthority: EvidenceAuthority
  public var guidanceAuthority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    [
      "summary_id": summaryID,
      "capture_session_id": captureSessionID,
      "threshold_profile_id": thresholdProfileID,
      "signal_counts_by_severity": signalCountsBySeverity,
      "active_severe_count": activeSevereCount,
      "active_blocking_count": activeBlockingCount,
      "unresolved_signal_ids": unresolvedSignalIDs.sorted(),
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
      "guidance_authority": guidanceAuthority.rawValue,
      "schema_id": "CaptureQualitySummary",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}

public struct CaptureQualityCheckpoint: Codable, Sendable, Equatable {
  public var checkpointID: String
  public var captureSessionID: String
  public var signalCount: Int
  public var coverageObservedRegions: [String]
  public var activeGuidanceIDs: [String]
  public var completionRecommendation: CaptureCompletionRecommendation
  public var inputDigest: String
}

// MARK: - Coverage

public enum CoverageRegionID: String, Codable, Sendable, Equatable, CaseIterable {
  case frontExterior = "FRONT_EXTERIOR"
  case rearExterior = "REAR_EXTERIOR"
  case driverSide = "DRIVER_SIDE"
  case passengerSide = "PASSENGER_SIDE"
  case roof = "ROOF"
  case underbody = "UNDERBODY"
  case engineBay = "ENGINE_BAY"
  case cabInterior = "CAB_INTERIOR"
  case cargoOrBodyInterior = "CARGO_OR_BODY_INTERIOR"
  case componentCloseup = "COMPONENT_CLOSEUP"
}

public enum CoverageClassification: String, Codable, Sendable, Equatable, CaseIterable {
  case unobserved = "UNOBSERVED"
  case partiallyObserved = "PARTIALLY_OBSERVED"
  case observed = "OBSERVED"
  case additionalCaptureRecommended = "ADDITIONAL_CAPTURE_RECOMMENDED"
  case policyRequirementSatisfied = "POLICY_REQUIREMENT_SATISFIED"
}

public enum ViewpointClass: String, Codable, Sendable, Equatable, CaseIterable {
  case frontal = "FRONTAL"
  case oblique = "OBLIQUE"
  case lateral = "LATERAL"
  case overhead = "OVERHEAD"
  case detail = "DETAIL"
  case unknown = "UNKNOWN"
}

public struct CoveragePolicy: Codable, Sendable, Equatable {
  public var coveragePolicyID: String
  public var schemaVersion: String
  public var requiredRegions: [CoverageRegionID]
  public var optionalRegions: [CoverageRegionID]
  public var minimumObservationsPerRequiredRegion: Int
  public var minimumViewpointDiversity: Int
  public var minimumOverlapRatio: Double
  public var acceptedStreamTypes: [String]
  public var missingRequiredRegionBlocksCompletion: Bool
  public var optionalRegionMissingBlocksCompletion: Bool

  public static let fixturePolicyID = "COV-POLICY-FIXTURE-GUIDED-000001"
  public static let fixtureSchemaVersion = "1.0.0-phase3-fixture"

  public static func fixtureDefault() -> CoveragePolicy {
    CoveragePolicy(
      coveragePolicyID: fixturePolicyID,
      schemaVersion: fixtureSchemaVersion,
      requiredRegions: [.frontExterior, .rearExterior, .driverSide, .passengerSide],
      optionalRegions: [.roof, .engineBay, .cabInterior, .componentCloseup],
      minimumObservationsPerRequiredRegion: 2,
      minimumViewpointDiversity: 2,
      minimumOverlapRatio: 0.25,
      acceptedStreamTypes: ["camera", "pose", "depth"],
      missingRequiredRegionBlocksCompletion: true,
      optionalRegionMissingBlocksCompletion: false
    )
  }

  public init(
    coveragePolicyID: String,
    schemaVersion: String,
    requiredRegions: [CoverageRegionID],
    optionalRegions: [CoverageRegionID],
    minimumObservationsPerRequiredRegion: Int,
    minimumViewpointDiversity: Int,
    minimumOverlapRatio: Double,
    acceptedStreamTypes: [String],
    missingRequiredRegionBlocksCompletion: Bool,
    optionalRegionMissingBlocksCompletion: Bool
  ) {
    self.coveragePolicyID = coveragePolicyID
    self.schemaVersion = schemaVersion
    self.requiredRegions = requiredRegions
    self.optionalRegions = optionalRegions
    self.minimumObservationsPerRequiredRegion = minimumObservationsPerRequiredRegion
    self.minimumViewpointDiversity = minimumViewpointDiversity
    self.minimumOverlapRatio = minimumOverlapRatio
    self.acceptedStreamTypes = acceptedStreamTypes
    self.missingRequiredRegionBlocksCompletion = missingRequiredRegionBlocksCompletion
    self.optionalRegionMissingBlocksCompletion = optionalRegionMissingBlocksCompletion
  }

  public func dictionary() -> [String: Any] {
    [
      "coverage_policy_id": coveragePolicyID,
      "schema_id": "CoveragePolicy",
      "schema_version": schemaVersion,
      "required_regions": requiredRegions.map(\.rawValue),
      "optional_regions": optionalRegions.map(\.rawValue),
      "minimum_observations_per_required_region": minimumObservationsPerRequiredRegion,
      "minimum_viewpoint_diversity": minimumViewpointDiversity,
      "minimum_overlap_ratio": minimumOverlapRatio,
      "accepted_stream_types": acceptedStreamTypes.sorted(),
      "missing_required_region_blocks_completion": missingRequiredRegionBlocksCompletion,
      "optional_region_missing_blocks_completion": optionalRegionMissingBlocksCompletion,
    ]
  }
}

public struct CoverageObservation: Codable, Sendable, Equatable {
  public var coverageObservationID: String
  public var regionID: CoverageRegionID
  public var cameraSampleIDs: [String]
  public var poseSampleIDs: [String]
  public var depthSampleIDs: [String]
  public var frameEpochID: String
  public var sessionRunID: String
  public var captureSessionID: String
  public var observationTimestampNanoseconds: UInt64
  public var viewpointClass: ViewpointClass
  public var overlapRatio: Double
  public var evidenceOriginAuthority: EvidenceAuthority
  public var coverageClassification: CoverageClassification

  public func dictionary() -> [String: Any] {
    [
      "coverage_observation_id": coverageObservationID,
      "region_id": regionID.rawValue,
      "camera_sample_ids": cameraSampleIDs.sorted(),
      "pose_sample_ids": poseSampleIDs.sorted(),
      "depth_sample_ids": depthSampleIDs.sorted(),
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "capture_session_id": captureSessionID,
      "observation_timestamp_nanoseconds": observationTimestampNanoseconds,
      "viewpoint_class": viewpointClass.rawValue,
      "overlap_ratio": overlapRatio,
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
      "coverage_classification": coverageClassification.rawValue,
    ]
  }
}

public struct CoverageCell: Codable, Sendable, Equatable {
  public var cellID: String
  public var regionID: CoverageRegionID
  public var observationCount: Int
  public var viewpointClasses: [ViewpointClass]
  public var classification: CoverageClassification

  public func dictionary() -> [String: Any] {
    [
      "cell_id": cellID,
      "region_id": regionID.rawValue,
      "observation_count": observationCount,
      "viewpoint_classes": viewpointClasses.map(\.rawValue).sorted(),
      "classification": classification.rawValue,
    ]
  }
}

public struct CoverageGap: Codable, Sendable, Equatable {
  public var gapID: String
  public var regionID: CoverageRegionID
  public var reason: String
  public var required: Bool

  public func dictionary() -> [String: Any] {
    [
      "gap_id": gapID,
      "region_id": regionID.rawValue,
      "reason": reason,
      "required": required,
    ]
  }
}

public struct CoverageMap: Codable, Sendable, Equatable {
  public var mapID: String
  public var captureSessionID: String
  public var cells: [CoverageCell]
  public var gaps: [CoverageGap]

  public func dictionary() -> [String: Any] {
    [
      "map_id": mapID,
      "capture_session_id": captureSessionID,
      "cells": cells.sorted { $0.cellID < $1.cellID }.map { $0.dictionary() },
      "gaps": gaps.sorted { $0.gapID < $1.gapID }.map { $0.dictionary() },
      "schema_id": "CoverageMap",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}

public struct CoverageSummary: Codable, Sendable, Equatable {
  public var summaryID: String
  public var captureSessionID: String
  public var coveragePolicyID: String
  public var requiredSatisfied: [String]
  public var requiredMissing: [String]
  public var optionalObserved: [String]
  public var optionalMissing: [String]
  public var policySatisfied: Bool
  public var evidenceOriginAuthority: EvidenceAuthority
  public var guidanceAuthority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    [
      "summary_id": summaryID,
      "capture_session_id": captureSessionID,
      "coverage_policy_id": coveragePolicyID,
      "required_satisfied": requiredSatisfied.sorted(),
      "required_missing": requiredMissing.sorted(),
      "optional_observed": optionalObserved.sorted(),
      "optional_missing": optionalMissing.sorted(),
      "policy_satisfied": policySatisfied,
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
      "guidance_authority": guidanceAuthority.rawValue,
      "schema_id": "CoverageSummary",
      "schema_version": "1.0.0-phase3-fixture",
      "note": "policy_satisfied means configured evidence-capture policy only; not engineering completeness",
    ]
  }
}

// MARK: - Guidance

public enum CaptureGuidanceCode: String, Codable, Sendable, Equatable, CaseIterable {
  case moveSlower = "MOVE_SLOWER"
  case holdSteadier = "HOLD_STEADIER"
  case improveLighting = "IMPROVE_LIGHTING"
  case reduceGlare = "REDUCE_GLARE"
  case increaseImageOverlap = "INCREASE_IMAGE_OVERLAP"
  case returnToRegion = "RETURN_TO_REGION"
  case captureDifferentViewpoint = "CAPTURE_DIFFERENT_VIEWPOINT"
  case trackingDegraded = "TRACKING_DEGRADED"
  case depthUnavailable = "DEPTH_UNAVAILABLE"
  case depthQualityLow = "DEPTH_QUALITY_LOW"
  case requiredStreamInterrupted = "REQUIRED_STREAM_INTERRUPTED"
  case storagePressure = "STORAGE_PRESSURE"
  case sampleDropRateHigh = "SAMPLE_DROP_RATE_HIGH"
  case waitForRecovery = "WAIT_FOR_RECOVERY"
  case resumeCapture = "RESUME_CAPTURE"
  case regionRequirementSatisfied = "REGION_REQUIREMENT_SATISFIED"
  case capturePolicySatisfied = "CAPTURE_POLICY_SATISFIED"
}

public enum GuidancePriority: Int, Codable, Sendable, Equatable, Comparable {
  case requiredStreamOrSafety = 1
  case storageOrPackageIntegrity = 2
  case severeTrackingOrSync = 3
  case severeBlurMotionExposure = 4
  case missingRequiredCoverage = 5
  case optionalDepthOrPoseDegradation = 6
  case optimization = 7
  case informationalCompletion = 8

  public static func < (lhs: GuidancePriority, rhs: GuidancePriority) -> Bool {
    lhs.rawValue < rhs.rawValue
  }
}

public enum GuidanceLifecycle: String, Codable, Sendable, Equatable {
  case active = "ACTIVE"
  case acknowledged = "ACKNOWLEDGED"
  case resolved = "RESOLVED"
  case superseded = "SUPERSEDED"
  case expired = "EXPIRED"
}

public struct CaptureGuidanceRecord: Codable, Sendable, Equatable {
  public var guidanceID: String
  public var guidanceCode: CaptureGuidanceCode
  public var severity: CaptureQualitySeverity
  public var priority: GuidancePriority
  public var createdAtNanoseconds: UInt64
  public var resolvedAtNanoseconds: UInt64?
  public var lifecycle: GuidanceLifecycle
  public var affectedStreamID: String?
  public var affectedRegionID: String?
  public var supportingEvidenceIDs: [String]
  public var qualitySignalIDs: [String]
  public var humanReadableInstruction: String
  public var evidenceOriginAuthority: EvidenceAuthority
  public var guidanceAuthority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "guidance_id": guidanceID,
      "guidance_code": guidanceCode.rawValue,
      "severity": severity.rawValue,
      "priority": priority.rawValue,
      "created_at_nanoseconds": createdAtNanoseconds,
      "lifecycle": lifecycle.rawValue,
      "supporting_evidence_ids": supportingEvidenceIDs.sorted(),
      "quality_signal_ids": qualitySignalIDs.sorted(),
      "human_readable_instruction": humanReadableInstruction,
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
      "guidance_authority": guidanceAuthority.rawValue,
    ]
    if let resolvedAtNanoseconds { d["resolved_at_nanoseconds"] = resolvedAtNanoseconds }
    if let affectedStreamID { d["affected_stream"] = affectedStreamID }
    if let affectedRegionID { d["affected_coverage_region"] = affectedRegionID }
    return d
  }
}

public enum CaptureCompletionRecommendation: String, Codable, Sendable, Equatable {
  case continueCapture = "CONTINUE_CAPTURE"
  case pauseAndRecover = "PAUSE_AND_RECOVER"
  case recaptureRequired = "RECAPTURE_REQUIRED"
  case sufficientForPackageFinalization = "SUFFICIENT_FOR_PACKAGE_FINALIZATION"
  case failedRequiredPolicy = "FAILED_REQUIRED_POLICY"
  case cancelled = "CANCELLED"
}

public enum CaptureCompletionReason: String, Codable, Sendable, Equatable {
  case policySatisfied = "POLICY_SATISFIED"
  case missingRequiredRegion = "MISSING_REQUIRED_REGION"
  case unresolvedSevereQuality = "UNRESOLVED_SEVERE_QUALITY"
  case requiredStreamFailure = "REQUIRED_STREAM_FAILURE"
  case activeInterruption = "ACTIVE_INTERRUPTION"
  case sessionCancelled = "SESSION_CANCELLED"
  case packageIntegrityRisk = "PACKAGE_INTEGRITY_RISK"
  case optionalDegradedAllowed = "OPTIONAL_DEGRADED_ALLOWED"
}

public struct CaptureReadinessSummary: Codable, Sendable, Equatable {
  public var summaryID: String
  public var captureSessionID: String
  public var recommendation: CaptureCompletionRecommendation
  public var reasons: [CaptureCompletionReason]
  public var activeGuidanceCodes: [String]
  public var note: String
  public var evidenceOriginAuthority: EvidenceAuthority
  public var guidanceAuthority: EvidenceAuthority

  public func dictionary() -> [String: Any] {
    [
      "summary_id": summaryID,
      "capture_session_id": captureSessionID,
      "recommendation": recommendation.rawValue,
      "reasons": reasons.map(\.rawValue).sorted(),
      "active_guidance_codes": activeGuidanceCodes.sorted(),
      "note": note,
      "evidence_origin_authority": evidenceOriginAuthority.rawValue,
      "guidance_authority": guidanceAuthority.rawValue,
      "schema_id": "CaptureReadinessSummary",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}

public struct CaptureCompletionRecord: Codable, Sendable, Equatable {
  public var recommendation: CaptureCompletionRecommendation
  public var reasons: [CaptureCompletionReason]
  public var captureSessionID: String
  public var generatedAtNanoseconds: UInt64
  public var note: String

  public func dictionary() -> [String: Any] {
    [
      "recommendation": recommendation.rawValue,
      "reasons": reasons.map(\.rawValue).sorted(),
      "capture_session_id": captureSessionID,
      "generated_at_nanoseconds": generatedAtNanoseconds,
      "note": note,
      "schema_id": "CaptureCompletionRecommendation",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}

// MARK: - Derivation

public enum ReproducibilityStatus: String, Codable, Sendable, Equatable {
  case deterministicReplay = "DETERMINISTIC_REPLAY"
  case nonDeterministic = "NON_DETERMINISTIC"
}

public struct CaptureDerivationRecord: Codable, Sendable, Equatable {
  public var derivationID: String
  public var sourceEvidenceIDs: [String]
  public var inputDigest: String
  public var algorithmIdentifier: String
  public var algorithmVersion: String
  public var thresholdProfileID: String
  public var outputEvidenceIDs: [String]
  public var generationTimestampUTC: String
  public var evidenceAuthority: EvidenceAuthority
  public var reproducibilityStatus: ReproducibilityStatus

  public func dictionary() -> [String: Any] {
    [
      "derivation_id": derivationID,
      "source_evidence_ids": sourceEvidenceIDs.sorted(),
      "input_digest": inputDigest,
      "algorithm_identifier": algorithmIdentifier,
      "algorithm_version": algorithmVersion,
      "threshold_profile_id": thresholdProfileID,
      "output_evidence_ids": outputEvidenceIDs.sorted(),
      "generation_timestamp_utc": generationTimestampUTC,
      "evidence_authority": evidenceAuthority.rawValue,
      "reproducibility_status": reproducibilityStatus.rawValue,
      "schema_id": "CaptureDerivationRecord",
      "schema_version": "1.0.0-phase3-fixture",
    ]
  }
}
