import Foundation

/// Apple Secure Enclave package-signer **source candidate**.
///
/// Linux / non-Apple builds expose an unavailable stub only.
/// Physical Secure Enclave signing remains PENDING_APPLE_HARDWARE_VALIDATION.
/// Do not claim DEVICE_PROVEN_UNCOMPROMISED or production hardware identity.
#if canImport(CryptoKit) && canImport(Security) && (os(iOS) || os(macOS))
import CryptoKit
import Security

public struct SecureEnclavePackageSigner: Sendable {
    public let deviceKeyID: String
    public let enrollmentRecordID: String

    public init(deviceKeyID: String, enrollmentRecordID: String) {
        self.deviceKeyID = deviceKeyID
        self.enrollmentRecordID = enrollmentRecordID
    }

    /// Candidate API — physical Secure Enclave signing is not claimed validated.
    public func sign(
        packageID: String,
        captureSessionID: String,
        packageClosureSHA256: String,
        manifestSHA256: String
    ) throws -> PackageSignatureEnvelope {
        // Source candidate placeholder: real SE key access requires Apple runtime + entitlement.
        // Returning a structured failure keeps the contract compilable without fake DEVICE evidence.
        throw SpatialEvidenceError.packageSignatureFailed(
            "SecureEnclavePackageSigner requires Apple Secure Enclave runtime validation (PENDING)"
        )
    }
}
#else
public struct SecureEnclavePackageSigner: Sendable {
    public let deviceKeyID: String
    public let enrollmentRecordID: String
    public let availabilityStatus: String = "UNAVAILABLE_ON_THIS_PLATFORM"

    public init(deviceKeyID: String = "KEY-SE-UNAVAILABLE", enrollmentRecordID: String = "ENR-SE-UNAVAILABLE") {
        self.deviceKeyID = deviceKeyID
        self.enrollmentRecordID = enrollmentRecordID
    }

    public func sign(
        packageID: String,
        captureSessionID: String,
        packageClosureSHA256: String,
        manifestSHA256: String
    ) throws -> PackageSignatureEnvelope {
        throw SpatialEvidenceError.packageSignatureFailed(
            "SecureEnclavePackageSigner unavailable on this platform (Linux/source-candidate stub)"
        )
    }
}
#endif
