import Foundation

/// Deterministic quality analyzer. Consumes immutable observations; never mutates sensor evidence.
public struct CaptureQualityAnalyzer: Sendable {
  public static let algorithmIdentifier = "capture-quality-analyzer-v1"
  public static let algorithmVersion = "1.0.0-phase3-fixture"

  public var thresholdProfile: CaptureQualityThresholdProfile

  public init(thresholdProfile: CaptureQualityThresholdProfile = CaptureQualityThresholdProfile()) {
    self.thresholdProfile = thresholdProfile
  }

  public func evaluate(
    observations: [CaptureQualityObservation],
    captureSessionID: String
  ) throws -> (signals: [CaptureQualitySignal], summary: CaptureQualitySummary) {
    guard thresholdProfile.thresholdProfileID == CaptureQualityThresholdProfile.fixtureProfileID
      || thresholdProfile.sourceClassification == .deterministicTestFixture
      || thresholdProfile.sourceClassification == .provisionalFieldHeuristic
      || thresholdProfile.sourceClassification == .physicallyCharacterized
    else {
      throw SpatialEvidenceError.qualityThresholdProfileMismatch(thresholdProfile.thresholdProfileID)
    }

    var signals: [CaptureQualitySignal] = []
    for (idx, obs) in observations.enumerated() {
      guard CaptureQualitySignalType(rawValue: obs.signalType.rawValue) != nil else {
        throw SpatialEvidenceError.unknownQualitySignalType(obs.signalType.rawValue)
      }
      guard obs.observedValue.isFinite else {
        throw SpatialEvidenceError.nonFiniteQualityValue(obs.observationID)
      }
      guard obs.captureSessionID == captureSessionID else {
        throw SpatialEvidenceError.qualityCrossSessionRejected(obs.observationID)
      }
      guard !obs.supportingEvidenceIDs.isEmpty else {
        throw SpatialEvidenceError.guidanceMissingSupportingEvidence(obs.observationID)
      }

      let (comparison, severity, resolved) = classify(obs)
      let signal = CaptureQualitySignal(
        signalID: "QS-\(String(format: "%04d", idx + 1))-\(obs.signalType.rawValue)",
        signalType: obs.signalType,
        severity: severity,
        timestampNanoseconds: obs.timestampNanoseconds,
        clockDomain: obs.clockDomain,
        captureSessionID: captureSessionID,
        streamID: obs.streamID,
        regionID: obs.regionID,
        supportingEvidenceIDs: obs.supportingEvidenceIDs.sorted(),
        observedValue: obs.observedValue,
        thresholdProfileID: thresholdProfile.thresholdProfileID,
        thresholdComparison: comparison,
        evidenceOriginAuthority: .testFixture,
        guidanceAuthority: .guidanceEstimate,
        characterizationStatus: thresholdProfile.characterizationStatus,
        resolved: resolved
      )
      signals.append(signal)
    }

    signals.sort { lhs, rhs in
      if lhs.timestampNanoseconds != rhs.timestampNanoseconds {
        return lhs.timestampNanoseconds < rhs.timestampNanoseconds
      }
      return lhs.signalID < rhs.signalID
    }

    var counts: [String: Int] = [:]
    for s in signals {
      counts[s.severity.rawValue, default: 0] += 1
    }
    let unresolved = signals.filter { !$0.resolved }.map(\.signalID)
    let summary = CaptureQualitySummary(
      summaryID: "QSUM-\(captureSessionID)",
      captureSessionID: captureSessionID,
      thresholdProfileID: thresholdProfile.thresholdProfileID,
      signalCountsBySeverity: counts,
      activeSevereCount: signals.filter { !$0.resolved && $0.severity == .severe }.count,
      activeBlockingCount: signals.filter { !$0.resolved && $0.severity == .blocking }.count,
      unresolvedSignalIDs: unresolved,
      evidenceOriginAuthority: .testFixture,
      guidanceAuthority: .guidanceEstimate
    )
    return (signals, summary)
  }

  private func classify(
    _ obs: CaptureQualityObservation
  ) -> (ThresholdComparison, CaptureQualitySeverity, Bool) {
    let key = obs.signalType.rawValue
    if let max = thresholdProfile.maximumLimits[key] {
      if obs.observedValue > max {
        let severity: CaptureQualitySeverity =
          (obs.signalType == .storagePressure || obs.signalType == .requiredStreamStarvation)
          ? .blocking
          : (obs.observedValue > max * 1.5 ? .severe : .warning)
        return (.aboveMaximum, severity, false)
      }
      return (.withinRange, .informational, true)
    }
    if let min = thresholdProfile.minimumLimits[key] {
      if obs.observedValue < min {
        let severity: CaptureQualitySeverity =
          (obs.signalType == .trackingQuality || obs.signalType == .timestampSynchronizationHealth)
          ? .severe
          : .warning
        return (.belowMinimum, severity, false)
      }
      return (.withinRange, .informational, true)
    }
    // Depth availability: 0 = unavailable, 1 = available
    if obs.signalType == .depthAvailability {
      if obs.observedValue < 0.5 {
        return (.belowMinimum, .warning, false)
      }
      return (.withinRange, .informational, true)
    }
    if obs.signalType == .optionalStreamDegradation {
      if obs.observedValue > 0.5 {
        return (.aboveMaximum, .warning, false)
      }
      return (.withinRange, .informational, true)
    }
    if obs.signalType == .frameEpochInstability {
      if obs.observedValue > 0.0 {
        return (.aboveMaximum, .severe, false)
      }
      return (.withinRange, .informational, true)
    }
    if obs.signalType == .requiredStreamStarvation {
      if obs.observedValue > 0.0 {
        return (.aboveMaximum, .blocking, false)
      }
      return (.withinRange, .informational, true)
    }
    return (.unavailable, .informational, true)
  }

  public func inputDigest(observations: [CaptureQualityObservation], profile: CaptureQualityThresholdProfile) throws -> String {
    let payload: [String: Any] = [
      "observations": observations
        .sorted { $0.observationID < $1.observationID }
        .map { obs -> [String: Any] in
          [
            "observation_id": obs.observationID,
            "signal_type": obs.signalType.rawValue,
            "observed_value": obs.observedValue,
            "supporting_evidence_ids": obs.supportingEvidenceIDs.sorted(),
            "capture_session_id": obs.captureSessionID,
            "timestamp_nanoseconds": obs.timestampNanoseconds,
          ]
        },
      "threshold_profile_id": profile.thresholdProfileID,
      "maximum_limits": profile.maximumLimits.sorted { $0.key < $1.key }.map { ["k": $0.key, "v": $0.value] },
      "minimum_limits": profile.minimumLimits.sorted { $0.key < $1.key }.map { ["k": $0.key, "v": $0.value] },
    ]
    return ContentHasher.sha256Hex(try CanonicalJSON.data(payload))
  }
}
