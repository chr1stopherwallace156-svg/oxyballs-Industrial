import Foundation

/// Seals Sprint 3.4 coordinated multi-stream fixture packages.
///
/// Writes orchestration sidecars plus stream payloads. Never invents evidence for
/// unavailable / not-requested / interrupted optional streams.
public struct FixtureCoordinatedPackageBuilder: Sendable {
  public static let primaryPackageID = "SPKG-FIXTURE-COORDINATED-000001"
  public static let primarySessionID = "SESS-FIXTURE-COORDINATED-000001"
  public static let noDepthPackageID = "SPKG-FIXTURE-COORDINATED-NODEPTH-000001"
  public static let noDepthSessionID = "SESS-FIXTURE-COORDINATED-NODEPTH-000001"
  public static let poseInterruptedPackageID = "SPKG-FIXTURE-COORDINATED-POSEINT-000001"
  public static let poseInterruptedSessionID = "SESS-FIXTURE-COORDINATED-POSEINT-000001"

  public static let frameEpochID = "epoch-fixture-1"
  public static let sessionRunID = "run-fixture-1"
  public static let worldOriginRevision: UInt64 = 1
  public static let cameraToDepthCorrelationID = "fixture-camera-to-depth-coord-000001"
  public static let cameraToPoseCorrelationID = "fixture-camera-to-arkit-coord-000001"
  public static let cameraToMotionCorrelationID = "fixture-camera-to-motion-coord-000001"
  public static let depthToCameraTransformID = "XF-DEPTH-TO-CAMERA-COORD-000001"
  public static let calibrationID = "CAL-FIXTURE-DEPTH-000001"

  public init() {}

  public func seal(
    camera: [SpatialSampleEnvelope<CameraSample>],
    motion: [SpatialSampleEnvelope<MotionSample>],
    pose: [SpatialSampleEnvelope<PoseSample>],
    depth: [SpatialSampleEnvelope<DepthSample>],
    cameraCapability: SpatialStreamCapability,
    motionCapability: SpatialStreamCapability,
    poseCapability: SpatialStreamCapability,
    depthCapability: SpatialStreamCapability,
    activationPlan: SensorActivationPlan,
    activationResults: [SensorActivationResult],
    policy: SpatialCaptureSessionPolicy,
    timeline: CaptureSessionTimeline,
    interruptions: [CaptureInterruption],
    bufferState: CaptureBufferState,
    degradedSummary: DegradedCaptureSummary?,
    outputDirectory: URL,
    vehicleID: String = "VEH-000001",
    pilotID: String = "PILOT-000001",
    captureSessionID: String = FixtureCoordinatedPackageBuilder.primarySessionID,
    packageID: String = FixtureCoordinatedPackageBuilder.primaryPackageID,
    createdAtUTC: String = "2026-08-03T00:00:00Z",
    frames: [CoordinateFrameDescriptor]? = nil,
    transformEdges: [TransformEdge]? = nil,
    clockCorrelations: [ClockCorrelation]? = nil
  ) throws -> SpatialEvidencePackage {
    precondition(!camera.isEmpty, "coordinated fixture requires camera samples")
    precondition(!motion.isEmpty, "coordinated fixture requires motion samples")
    #if !os(iOS)
    // DEVICE packages may only be sealed on physical iOS hosts via DeviceSpatialPackageBuilder.
    precondition(!packageID.hasPrefix("SPKG-DEVICE-"), "DEVICE package sealing is Apple-host only")
    precondition(!captureSessionID.hasPrefix("SESS-DEVICE-"), "DEVICE session sealing is Apple-host only")
    #endif

    let includePose = !pose.isEmpty && poseCapability.finalOutcome == .acquired
    let includeDepth = !depth.isEmpty && depthCapability.finalOutcome == .acquired

    // Never invent pose/depth evidence when capability says otherwise.
    if poseCapability.finalOutcome != .acquired && !pose.isEmpty {
      throw SpatialEvidenceError.notRequestedStreamContributesEvidence("pose_samples_with_non_acquired_outcome")
    }
    if depthCapability.finalOutcome != .acquired && !depth.isEmpty {
      throw SpatialEvidenceError.depthEvidenceSynthesizedWhenUnavailable(
        "depth_samples_with_outcome:\(depthCapability.finalOutcome?.rawValue ?? "nil")"
      )
    }

    let resolvedFrames = frames ?? Self.defaultFrames(includePose: includePose, includeDepth: includeDepth)
    let resolvedEdges = transformEdges
      ?? Self.defaultTransformEdges(includePose: includePose, includeDepth: includeDepth)
    let resolvedCorrelations = clockCorrelations
      ?? Self.defaultClockCorrelations(includePose: includePose, includeDepth: includeDepth)

    let capability = SpatialCapabilitySnapshot(
      snapshotID: "CAP-\(packageID)",
      capturedAtUTC: createdAtUTC,
      streams: [cameraCapability, motionCapability, poseCapability, depthCapability]
        .sorted { $0.streamID < $1.streamID },
      schemaVersion: SpatialCapabilitySnapshot.fixtureSchemaVersion
    )

    try FileManager.default.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
    let payloadRoot = outputDirectory.appendingPathComponent("payload", isDirectory: true)
    try FileManager.default.createDirectory(at: payloadRoot, withIntermediateDirectories: true)

    var artifacts: [SpatialArtifactDescriptor] = []
    var sampleIndex: [[String: Any]] = []

    try writePayload(
      stream: SpatialStreamID.camera,
      adapterID: cameraCapability.adapterID,
      samples: camera,
      root: payloadRoot,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }

    try writePayload(
      stream: SpatialStreamID.motion,
      adapterID: motionCapability.adapterID,
      samples: motion,
      root: payloadRoot,
      artifacts: &artifacts,
      sampleIndex: &sampleIndex
    ) { $0.bytes }

    var poseAssociations: [PoseAssociationRecord] = []
    if includePose {
      try writePayload(
        stream: SpatialStreamID.pose,
        adapterID: poseCapability.adapterID,
        samples: pose,
        root: payloadRoot,
        artifacts: &artifacts,
        sampleIndex: &sampleIndex
      ) { $0.bytes }

      let graph = CoordinateFrameGraph(frames: resolvedFrames, edges: resolvedEdges)
      try graph.validateRegistry()
      try graph.validateEdgesReferenceKnownFrames()
      try graph.validateTransformGraph()
      for sample in pose {
        try PoseMathValidator.validatePoseSample(sample.payload)
      }
      try PoseWorldEpochValidator.requireHomogeneousPackageEpoch(pose.map(\.payload))
      guard let epochPose = pose.first?.payload else {
        throw SpatialEvidenceError.validationFailed("missing_pose_epoch")
      }
      try TransformEdgeValidator.validateAll(
        edges: resolvedEdges,
        frames: resolvedFrames,
        poseSampleIDs: Set(pose.map(\.sampleID)),
        packageSessionRunID: epochPose.sessionRunID,
        packageFrameEpochID: epochPose.frameEpochID,
        packageWorldOriginRevision: epochPose.worldOriginRevision
      )
      poseAssociations = try Self.defaultPoseAssociations(
        camera: camera,
        pose: pose,
        correlations: resolvedCorrelations
      )
      try PoseAssociationValidator.validateAll(
        cameraSamples: camera,
        poseSamples: pose,
        associations: poseAssociations,
        correlations: resolvedCorrelations
      )
    }

    var depthAssociations: [RGBDepthAssociationRecord] = []
    var calibrations: [DepthCalibration] = []
    if includeDepth {
      try writePayload(
        stream: SpatialStreamID.depth,
        adapterID: depthCapability.adapterID,
        samples: depth,
        root: payloadRoot,
        artifacts: &artifacts,
        sampleIndex: &sampleIndex
      ) { $0.bytes }

      for sample in depth {
        try DepthSampleValidator.validate(sample.payload)
      }
      let cal = Self.defaultCalibration()
      calibrations = [cal]
      try DepthCalibrationValidator.validate(
        cal,
        depthSample: depth.first?.payload,
        frames: resolvedFrames,
        transformIDs: Set(resolvedEdges.map(\.transformID)),
        packageFrameEpochID: Self.frameEpochID,
        packageSessionRunID: Self.sessionRunID,
        packageWorldOriginRevision: Self.worldOriginRevision
      )
      depthAssociations = try Self.defaultDepthAssociations(
        camera: camera,
        depth: depth,
        correlations: resolvedCorrelations
      )
      try RGBDepthAssociationValidator.validate(
        associations: depthAssociations,
        cameraSamples: camera,
        depthSamples: depth,
        correlations: resolvedCorrelations,
        calibrations: calibrations,
        frames: resolvedFrames,
        transformEdges: resolvedEdges,
        packageFrameEpochID: Self.frameEpochID,
        packageSessionRunID: Self.sessionRunID,
        packageWorldOriginRevision: Self.worldOriginRevision
      )
    }

    // Transform graph always present (at least session root + camera + IMU).
    let graph = CoordinateFrameGraph(frames: resolvedFrames, edges: resolvedEdges)
    try graph.validateRegistry()
    try graph.validateEdgesReferenceKnownFrames()
    try graph.validateTransformGraph()

    sampleIndex.sort {
      (($0["relative_path"] as? String) ?? "") < (($1["relative_path"] as? String) ?? "")
    }

    try writeJSON(capability.asDictionary(), to: outputDirectory.appendingPathComponent("capability_snapshot.json"))
    try writeJSON(policy.asDictionary(), to: outputDirectory.appendingPathComponent("session_policy.json"))
    try writeJSON(timeline.asDictionary(), to: outputDirectory.appendingPathComponent("session_timeline.json"))
    try writeJSON(activationPlan.asDictionary(), to: outputDirectory.appendingPathComponent("activation_plan.json"))
    try writeJSON(
      [
        "schema_id": "StreamOutcomes",
        "schema_version": "1.0.0-phase3-fixture",
        "outcomes": activationResults.sorted { $0.streamID < $1.streamID }.map { $0.asDictionary() },
      ],
      to: outputDirectory.appendingPathComponent("stream_outcomes.json")
    )
    try writeJSON(
      [
        "schema_id": "InterruptionHistory",
        "schema_version": "1.0.0-phase3-fixture",
        "interruptions": interruptions.map { $0.asDictionary() },
      ],
      to: outputDirectory.appendingPathComponent("interruption_history.json")
    )
    var bufferDoc: [String: Any] = [
      "schema_id": "BufferSummary",
      "schema_version": "1.0.0-phase3-fixture",
      "buffer_state": bufferState.asDictionary(),
    ]
    if let degradedSummary {
      bufferDoc["degraded_summary"] = degradedSummary.asDictionary()
    }
    try writeJSON(bufferDoc, to: outputDirectory.appendingPathComponent("buffer_summary.json"))

    try writeJSON(
      [
        "correlations": resolvedCorrelations
          .sorted { $0.correlationID < $1.correlationID }
          .map { $0.asDictionary() },
      ],
      to: outputDirectory.appendingPathComponent("clock_correlation.json")
    )
    try writeJSON(
      ["frames": resolvedFrames.sorted { $0.frameID < $1.frameID }.map { $0.asDictionary() }],
      to: outputDirectory.appendingPathComponent("coordinate_frames.json")
    )
    try writeJSON(["samples": sampleIndex], to: outputDirectory.appendingPathComponent("sample_index.json"))

    if includePose {
      try writeJSON(
        ["associations": poseAssociations.map { $0.asDictionary() }],
        to: outputDirectory.appendingPathComponent("pose_associations.json")
      )
    }
    if includeDepth {
      try writeJSON(
        ["associations": depthAssociations.map { $0.asDictionary() }],
        to: outputDirectory.appendingPathComponent("rgb_depth_associations.json")
      )
      try writeJSON(
        [
          "calibrations": calibrations.map { $0.asDictionary() },
          "characterization_status": "PENDING_CHARACTERIZATION",
          "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED",
        ],
        to: outputDirectory.appendingPathComponent("depth_calibration.json")
      )
    }

    try writeJSON(
      [
        "edges": resolvedEdges.map { $0.asDictionary() },
        "characterization_status": "PENDING_CHARACTERIZATION",
        "system_tolerance": "NO_SYSTEM_TOLERANCE_ASSIGNED",
      ],
      to: outputDirectory.appendingPathComponent("transform_graph.json")
    )

    let manifest = SpatialEvidenceManifest(
      packageID: packageID,
      vehicleID: vehicleID,
      captureSessionID: captureSessionID,
      pilotID: pilotID,
      createdAtUTC: createdAtUTC,
      capability: capability,
      frames: resolvedFrames,
      clockCorrelations: resolvedCorrelations,
      artifacts: artifacts,
      sampleIndex: sampleIndex
    )
    var manifestDict = manifest.asDictionary()
    manifestDict["schema_id"] = "SpatialEvidenceManifest"
    manifestDict["schema_version"] = "1.0.0-phase3-fixture"
    manifestDict["package_layout"] = "fixture_coordinated_v1"
    manifestDict["host_claim"] = "NO_PHYSICAL_DEVICE_EXECUTION"
    manifestDict["implementation_state"] = "SOURCE_IMPLEMENTED"
    manifestDict["validation_state"] = "LINUX_FIXTURE_VALIDATED"
    manifestDict["evidence_origin_authority"] = "TEST_FIXTURE"
    manifestDict["frame_epoch_id"] = Self.frameEpochID
    manifestDict["session_run_id"] = Self.sessionRunID
    manifestDict["world_origin_revision"] = Self.worldOriginRevision
    manifestDict["transform_edges"] = resolvedEdges.map { $0.asDictionary() }
    if includePose {
      manifestDict["pose_estimate_authority"] = "GUIDANCE_ESTIMATE"
      manifestDict["pose_adapter_id"] = poseCapability.adapterID
      manifestDict["pose_associations"] = poseAssociations.map { $0.asDictionary() }
    }
    if includeDepth {
      manifestDict["depth_estimate_authority"] = "GUIDANCE_ESTIMATE"
      manifestDict["depth_adapter_id"] = depthCapability.adapterID
      manifestDict["rgb_depth_associations"] = depthAssociations.map { $0.asDictionary() }
      manifestDict["depth_calibrations"] = calibrations.map { $0.asDictionary() }
    }
    if let degradedSummary {
      manifestDict["degraded_summary"] = degradedSummary.asDictionary()
    }

    let manifestData = try CanonicalJSON.data(manifestDict)
    try manifestData.write(to: outputDirectory.appendingPathComponent("manifest.json"), options: .atomic)
    let manifestSHA = ContentHasher.sha256Hex(manifestData)

    let inventoryEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: outputDirectory
    )
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(
      packageRoot: outputDirectory,
      entries: inventoryEntries
    )
    let packageClosureHash = try SpatialPackageClosureVerifier.inventoryClosureHash(
      entries: inventoryEntries
    )
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": packageClosureHash,
      "entries": inventoryEntries,
    ]
    try writeJSON(inventory, to: outputDirectory.appendingPathComponent("package_inventory.json"))

    try SpatialPackageClosureVerifier.verifyDevicePayload(
      packageRoot: outputDirectory,
      manifestArtifacts: artifacts
    )
    let packageHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outputDirectory)

    return SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: manifestSHA,
      packageClosureSHA256: packageClosureHash
    )
  }

  // MARK: - Defaults

  public static func defaultFrames(
    includePose: Bool,
    includeDepth: Bool,
    authority: String = "TEST_FIXTURE"
  ) -> [CoordinateFrameDescriptor] {
    var frames: [CoordinateFrameDescriptor] = [
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAPTURE_SESSION_ROOT",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "n/a",
        clockDomain: .fixtureCamera,
        authority: authority
      ),
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAMERA_OPTICAL",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "opencv",
        clockDomain: .fixtureCamera,
        authority: authority
      ),
      CoordinateFrameDescriptor(
        frameID: "FRAME_DEVICE_IMU",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "n/a",
        clockDomain: .fixtureMotion,
        authority: authority
      ),
    ]
    if includePose {
      frames.append(
        CoordinateFrameDescriptor(
          frameID: "FRAME_AR_SESSION_WORLD",
          units: "meters",
          handedness: "right",
          matrixStorageOrder: "column_major",
          opticalAxisConvention: "arkit",
          clockDomain: .arkitFrame,
          authority: authority
        )
      )
    }
    if includeDepth {
      frames.append(
        CoordinateFrameDescriptor(
          frameID: "FRAME_DEPTH_SENSOR",
          units: "meters",
          handedness: "right",
          matrixStorageOrder: "column_major",
          opticalAxisConvention: "opencv",
          clockDomain: .fixtureDepth,
          authority: authority
        )
      )
    }
    return frames
  }

  public static func defaultTransformEdges(
    includePose: Bool,
    includeDepth: Bool,
    authority: String = "TEST_FIXTURE"
  ) -> [TransformEdge] {
    let m = HomogeneousMatrix4x4.identity()
    var edges: [TransformEdge] = [
      TransformEdge(
        transformID: "XF-CAMERA-TO-ROOT-COORD-000001",
        fromFrameID: "FRAME_CAMERA_OPTICAL",
        toFrameID: "FRAME_CAPTURE_SESSION_ROOT",
        frameEpochID: frameEpochID,
        sessionRunID: sessionRunID,
        worldOriginRevision: worldOriginRevision,
        timestampNanoseconds: 0,
        clockDomain: .fixtureCamera,
        matrix: m,
        authority: authority,
        sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
      ),
      TransformEdge(
        transformID: "XF-IMU-TO-ROOT-COORD-000001",
        fromFrameID: "FRAME_DEVICE_IMU",
        toFrameID: "FRAME_CAPTURE_SESSION_ROOT",
        frameEpochID: frameEpochID,
        sessionRunID: sessionRunID,
        worldOriginRevision: worldOriginRevision,
        timestampNanoseconds: 0,
        clockDomain: .fixtureMotion,
        matrix: m,
        authority: authority,
        sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
      ),
    ]
    if includePose {
      edges.append(contentsOf: [
        TransformEdge(
          transformID: "XF-AR-TO-ROOT-COORD-000001",
          fromFrameID: "FRAME_AR_SESSION_WORLD",
          toFrameID: "FRAME_CAPTURE_SESSION_ROOT",
          frameEpochID: frameEpochID,
          sessionRunID: sessionRunID,
          worldOriginRevision: worldOriginRevision,
          timestampNanoseconds: 0,
          clockDomain: .arkitFrame,
          matrix: m,
          authority: authority,
          sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
        ),
        TransformEdge(
          transformID: "XF-CAMERA-TO-AR-COORD-000001",
          fromFrameID: "FRAME_CAMERA_OPTICAL",
          toFrameID: "FRAME_AR_SESSION_WORLD",
          frameEpochID: frameEpochID,
          sessionRunID: sessionRunID,
          worldOriginRevision: worldOriginRevision,
          timestampNanoseconds: 0,
          clockDomain: .arkitFrame,
          matrix: m,
          authority: authority,
          sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
        ),
      ])
    }
    if includeDepth {
      edges.append(contentsOf: [
        TransformEdge(
          transformID: depthToCameraTransformID,
          fromFrameID: "FRAME_DEPTH_SENSOR",
          toFrameID: "FRAME_CAMERA_OPTICAL",
          frameEpochID: frameEpochID,
          sessionRunID: sessionRunID,
          worldOriginRevision: worldOriginRevision,
          timestampNanoseconds: 0,
          clockDomain: .fixtureDepth,
          matrix: m,
          authority: authority,
          sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
        ),
        TransformEdge(
          transformID: "XF-CAMERA-TO-DEPTH-COORD-000001",
          fromFrameID: "FRAME_CAMERA_OPTICAL",
          toFrameID: "FRAME_DEPTH_SENSOR",
          frameEpochID: frameEpochID,
          sessionRunID: sessionRunID,
          worldOriginRevision: worldOriginRevision,
          timestampNanoseconds: 0,
          clockDomain: .fixtureCamera,
          matrix: m,
          authority: authority,
          sourceSampleID: TransformEdge.fixtureStaticSourceSampleID
        ),
      ])
    }
    return edges
  }

  public static func defaultClockCorrelations(
    includePose: Bool,
    includeDepth: Bool,
    authority: String = "TEST_FIXTURE"
  ) -> [ClockCorrelation] {
    var correlations: [ClockCorrelation] = [
      ClockCorrelation(
        correlationID: cameraToMotionCorrelationID,
        sourceDomain: .fixtureCamera,
        destinationDomain: .fixtureMotion,
        offsetNanoseconds: 0,
        authority: authority,
        method: "explicit_fixture_identity",
        validFromNanoseconds: 0,
        validUntilNanoseconds: 10_000_000_000
      ),
    ]
    if includePose {
      correlations.append(
        ClockCorrelation(
          correlationID: cameraToPoseCorrelationID,
          sourceDomain: .fixtureCamera,
          destinationDomain: .arkitFrame,
          offsetNanoseconds: 0,
          authority: authority,
          method: "explicit_fixture_cross_domain",
          validFromNanoseconds: 0,
          validUntilNanoseconds: 10_000_000_000
        )
      )
    }
    if includeDepth {
      correlations.append(
        ClockCorrelation(
          correlationID: cameraToDepthCorrelationID,
          sourceDomain: .fixtureCamera,
          destinationDomain: .fixtureDepth,
          offsetNanoseconds: 0,
          authority: authority,
          method: "explicit_fixture_identity",
          validFromNanoseconds: 0,
          validUntilNanoseconds: 10_000_000_000
        )
      )
    }
    return correlations
  }

  public static func defaultCalibration() -> DepthCalibration {
    let fx = 200.0, fy = 200.0, cx = 1.5, cy = 1.5
    return DepthCalibration(
      calibrationID: calibrationID,
      depthWidth: FixtureDepthPayload.width,
      depthHeight: FixtureDepthPayload.height,
      cameraReferenceWidth: 4,
      cameraReferenceHeight: 4,
      intrinsicsMatrix: [fx, 0, cx, 0, fy, cy, 0, 0, 1],
      focalLengthX: fx,
      focalLengthY: fy,
      principalPointX: cx,
      principalPointY: cy,
      depthScale: 1.0,
      distortionModel: "NONE",
      distortionParameters: [],
      depthFrameID: "FRAME_DEPTH_SENSOR",
      cameraFrameID: "FRAME_CAMERA_OPTICAL",
      depthToCameraTransformID: depthToCameraTransformID,
      units: "meters",
      frameEpochID: frameEpochID,
      sessionRunID: sessionRunID,
      worldOriginRevision: worldOriginRevision,
      evidenceOriginAuthority: "TEST_FIXTURE"
    )
  }

  public static func defaultPoseAssociations(
    camera: [SpatialSampleEnvelope<CameraSample>],
    pose: [SpatialSampleEnvelope<PoseSample>],
    correlations: [ClockCorrelation]
  ) throws -> [PoseAssociationRecord] {
    let clockValidator = ClockCorrelationValidator(correlations: correlations)
    let corr = try clockValidator.requireByID(cameraToPoseCorrelationID)
    let n = min(camera.count, pose.count)
    return try (0..<n).map { i in
      try PoseAssociationValidator.makeAssociation(
        associationID: "coord-pose-assoc-\(i)",
        camera: camera[i],
        pose: pose[i],
        correlation: corr
      )
    }
  }

  public static func defaultDepthAssociations(
    camera: [SpatialSampleEnvelope<CameraSample>],
    depth: [SpatialSampleEnvelope<DepthSample>],
    correlations: [ClockCorrelation]
  ) throws -> [RGBDepthAssociationRecord] {
    guard let corr = correlations.first(where: { $0.correlationID == cameraToDepthCorrelationID })
    else {
      throw SpatialEvidenceError.unknownClockCorrelationID(cameraToDepthCorrelationID)
    }
    var out: [RGBDepthAssociationRecord] = []
    let n = min(camera.count, depth.count)
    for i in 0..<n {
      let cam = camera[i]
      let dep = depth[i]
      let converted = corr.convertSourceToDestination(sourceTimestampNs: cam.acquisitionTimestampNs)
      let diff = Int64(dep.acquisitionTimestampNs) - converted
      out.append(
        RGBDepthAssociationRecord(
          associationID: "coord-rgb-depth-assoc-\(i)",
          cameraSampleID: cam.sampleID,
          depthSampleID: dep.sampleID,
          cameraClockDomain: cam.clockDomain,
          depthClockDomain: dep.clockDomain,
          correlationID: corr.correlationID,
          associationTimestampNanoseconds: cam.acquisitionTimestampNs,
          timestampDifferenceNanoseconds: diff,
          calibrationID: calibrationID,
          cameraFrameID: "FRAME_CAMERA_OPTICAL",
          depthFrameID: "FRAME_DEPTH_SENSOR",
          transformID: depthToCameraTransformID,
          frameEpochID: frameEpochID,
          sessionRunID: sessionRunID,
          worldOriginRevision: worldOriginRevision,
          associationMethod: "explicit_fixture_binding",
          evidenceOriginAuthority: "TEST_FIXTURE"
        )
      )
    }
    return out
  }

  // MARK: - IO

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    try CanonicalJSON.data(object).write(to: url, options: .atomic)
  }

  private func writePayload<Payload>(
    stream: String,
    adapterID: String,
    samples: [SpatialSampleEnvelope<Payload>],
    root: URL,
    artifacts: inout [SpatialArtifactDescriptor],
    sampleIndex: inout [[String: Any]],
    bytesOf: (Payload) -> Data
  ) throws {
    try SpatialStreamID.validate(stream)
    let dir = root.appendingPathComponent(stream, isDirectory: true)
    try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    for (idx, sample) in samples.enumerated() {
      let schemaKey = "\(sample.schemaID)@\(sample.schemaVersion)"
      guard SpatialEvidenceManifest.supportedSchemas.contains(schemaKey) else {
        throw SpatialEvidenceError.unsupportedSchema(id: sample.schemaID, version: sample.schemaVersion)
      }
      let fileName = String(format: "%04d.bin", idx)
      let rel = "payload/\(stream)/\(fileName)"
      let data = bytesOf(sample.payload)
      try data.write(to: dir.appendingPathComponent(fileName), options: .atomic)
      let sha = ContentHasher.sha256Hex(data)
      artifacts.append(
        SpatialArtifactDescriptor(
          relativePath: rel,
          byteLength: data.count,
          sha256: sha,
          mediaType: sample.mediaType,
          schemaID: sample.schemaID,
          schemaVersion: sample.schemaVersion,
          sampleID: sample.sampleID,
          streamID: stream,
          adapterID: adapterID
        )
      )
      sampleIndex.append([
        "sample_id": sample.sampleID,
        "sequence_index": sample.sequenceIndex,
        "acquisition_timestamp_ns": sample.acquisitionTimestampNs,
        "clock_domain": sample.clockDomain.rawValue,
        "coordinate_frame_id": sample.coordinateFrameID,
        "relative_path": rel,
        "stream_id": stream,
        "adapter_id": adapterID,
      ])
    }
  }
}
