import Foundation

/// Foundation-portable multi-stream orchestration coordinator (Sprint 3.4).
///
/// Combines camera / motion / pose / depth Controllable* adapters under one
/// fail-closed state machine with policy, buffering, sample acceptance,
/// checkpoints, and package finalization. No Apple runtime claims.
public final class SpatialCaptureSessionCoordinator: @unchecked Sendable {
  public let sessionID: String
  public let policy: SpatialCaptureSessionPolicy

  public private(set) var state: SpatialCaptureSessionState = .idle
  public private(set) var timeline = CaptureSessionTimeline()
  public private(set) var activationPlan: SensorActivationPlan?
  public private(set) var activationResults: [SensorActivationResult] = []
  public private(set) var interruptions: [CaptureInterruption] = []
  public private(set) var bufferState = CaptureBufferState()
  public private(set) var lastCheckpoint: CaptureSessionCheckpoint?
  public private(set) var sealedPackage: SpatialEvidencePackage?
  public private(set) var failureReason: String?
  public private(set) var degradedSummary: DegradedCaptureSummary?

  public private(set) var cameraSamples: [SpatialSampleEnvelope<CameraSample>] = []
  public private(set) var motionSamples: [SpatialSampleEnvelope<MotionSample>] = []
  public private(set) var poseSamples: [SpatialSampleEnvelope<PoseSample>] = []
  public private(set) var depthSamples: [SpatialSampleEnvelope<DepthSample>] = []

  private let camera: (any CameraSensorAdapter)?
  private let motion: (any MotionSensorAdapter)?
  private let pose: (any PoseSensorAdapter)?
  private let depth: (any DepthSensorAdapter)?

  private var acceptedSampleIDs = Set<String>()
  private var lastTimestampByStream: [String: UInt64] = [:]
  private var runtimeByStream: [String: StreamRuntimeState] = [:]
  private var startedFlag = false
  private var adaptersActive = false
  private var transitionClockNs: UInt64 = 0
  private let transitionClockDomain: ClockDomain = .fixtureCamera

  public init(
    sessionID: String = FixtureCoordinatedPackageBuilder.primarySessionID,
    policy: SpatialCaptureSessionPolicy = .primaryFixture(),
    camera: (any CameraSensorAdapter)? = ControllableCameraSensorAdapter(),
    motion: (any MotionSensorAdapter)? = ControllableMotionSensorAdapter(),
    pose: (any PoseSensorAdapter)? = ControllablePoseSensorAdapter(),
    depth: (any DepthSensorAdapter)? = ControllableDepthSensorAdapter()
  ) {
    self.sessionID = sessionID
    self.policy = policy
    self.camera = camera
    self.motion = motion
    self.pose = pose
    self.depth = depth
    configureFixtureClocks()
  }

  /// Apple production adapter wiring for Sprint 3.6 physical validation hosts.
  /// On Linux/non-Apple hosts the Apple stubs throw UNAVAILABLE / UNCOMPILED — never invent DEVICE evidence.
  public static func appleProductionSession(
    sessionID: String,
    policy: SpatialCaptureSessionPolicy = .primaryFixture()
  ) -> SpatialCaptureSessionCoordinator {
    SpatialCaptureSessionCoordinator(
      sessionID: sessionID,
      policy: policy,
      camera: AppleProductionCameraSensorAdapter(),
      motion: AppleProductionMotionSensorAdapter(),
      pose: AppleARKitPoseSensorAdapter(),
      depth: AppleARKitDepthSensorAdapter()
    )
  }

  // MARK: - Public lifecycle

  /// IDLE → CAPABILITY_DISCOVERY → PLANNING (builds activation plan).
  public func discoverAndPlan() throws {
    try transition(to: .capabilityDiscovery, event: .beginDiscovery)
    _ = discoveredAdapterIDs()
    try transition(to: .planning, event: .discoveryComplete)
    activationPlan = try buildActivationPlan()
    try transition(to: .preparing, event: .planAccepted)
  }

  /// PREPARING → STARTING_STREAMS → CAPTURING (or FAILED / degraded optional).
  public func startStreams() async throws {
    guard !startedFlag else {
      throw SpatialEvidenceError.duplicateStart
    }
    if state == .idle {
      try discoverAndPlan()
    }
    guard state == .preparing else {
      throw SpatialEvidenceError.invalidTransition(
        from: state.rawValue,
        to: SpatialCaptureSessionState.startingStreams.rawValue,
        event: SpatialCaptureSessionEvent.startStreams.rawValue
      )
    }
    startedFlag = true
    try transition(to: .startingStreams, event: .startStreams)

    var started: [String] = []
    var results: [SensorActivationResult] = []
    let plan = try requirePlan()

    for entry in plan.entries where entry.requirement != .notRequested {
      let result = await activate(entry: entry)
      results.append(result)
      runtimeByStream[entry.streamID] = result.runtimeState

      if result.runtimeState == .acquired {
        started.append(entry.streamID)
        continue
      }

      if entry.requirement == .required {
        await rollbackStarted(started)
        activationResults = results
        failureReason = result.reason ?? "required_stream_failed:\(entry.streamID)"
        try transition(
          to: .failed,
          event: .fail,
          note: failureReason
        )
        throw SpatialEvidenceError.requiredStreamFailed(
          streamID: entry.streamID,
          reason: failureReason ?? "activation_failed"
        )
      }
      // Optional: degrade and continue.
    }

    // Mark NOT_REQUESTED streams explicitly.
    for stream in SpatialStreamID.all.sorted() {
      if policy.requirement(for: stream) == .notRequested {
        results.append(
          SensorActivationResult(
            streamID: stream,
            adapterID: "none",
            runtimeState: .notRequested
          )
        )
        runtimeByStream[stream] = .notRequested
      }
    }

    activationResults = results.sorted { $0.streamID < $1.streamID }
    adaptersActive = !started.isEmpty
    updateDegradedSummary()
    try transition(to: .capturing, event: .streamsStarted)
  }

  /// Collect samples from acquired adapters into bounded buffers with acceptance checks.
  public func collectSamples() async throws {
    guard state == .capturing || state == .recovering else {
      throw SpatialEvidenceError.sampleRejected("state_does_not_permit_capture:\(state.rawValue)")
    }

    if runtimeByStream[SpatialStreamID.camera] == .acquired, let camera {
      for try await sample in camera.samples() {
        _ = try acceptCameraSample(sample)
      }
    }
    if runtimeByStream[SpatialStreamID.motion] == .acquired, let motion {
      for try await sample in motion.samples() {
        _ = try acceptMotionSample(sample)
      }
    }
    if runtimeByStream[SpatialStreamID.pose] == .acquired, let pose {
      for try await sample in pose.samples() {
        _ = try acceptPoseSample(sample)
      }
    }
    if runtimeByStream[SpatialStreamID.depth] == .acquired, let depth {
      for try await sample in depth.samples() {
        _ = try acceptDepthSample(sample)
      }
    }
  }

  /// Idempotent stop: CAPTURING/INTERRUPTED/RECOVERING → STOPPING → FINALIZING readiness.
  /// Stop before start / duplicate stop are safe no-ops returning without sealing.
  @discardableResult
  public func stopStreams() async throws -> Bool {
    if state == .idle || state == .capabilityDiscovery || state == .planning || state == .preparing {
      // Stop before start — cancel without package.
      if !state.isTerminal {
        try? transition(to: .cancelled, event: .cancel, note: "stop_before_start")
      }
      return false
    }
    if state == .stopping || state == .finalizing || state == .verifyingPackage
      || state == .packaged || state == .failed || state == .cancelled
    {
      // Duplicate / already terminal stop — idempotent.
      if adaptersActive {
        await deactivateAll()
      }
      return state == .packaged
    }
    if state == .startingStreams {
      await deactivateAll()
      try transition(to: .cancelled, event: .cancel, note: "stop_during_startup")
      return false
    }

    try transition(to: .stopping, event: .stop)
    await deactivateAll()
    try transition(to: .finalizing, event: .streamsStopped)
    return true
  }

  public func interrupt(streamID: String, reason: String, recoverable: Bool = true) throws {
    guard state == .capturing else {
      throw SpatialEvidenceError.invalidTransition(
        from: state.rawValue,
        to: SpatialCaptureSessionState.interrupted.rawValue,
        event: SpatialCaptureSessionEvent.interrupt.rawValue
      )
    }
    let interruption = CaptureInterruption(
      interruptionID: "int-\(interruptions.count + 1)",
      streamID: streamID,
      reason: reason,
      timestampNanoseconds: nextTransitionTs(),
      clockDomain: transitionClockDomain,
      recoverable: recoverable
    )
    interruptions.append(interruption)
    if let req = optionalOrRequired(streamID), req == .optional {
      runtimeByStream[streamID] = .interrupted
      // Drop optional stream samples already queued? Keep accepted; mark degraded.
      updateDegradedSummary()
    }
    try transition(to: .interrupted, event: .interrupt, note: reason)
  }

  @discardableResult
  public func recover(decision: CaptureRecoveryDecision) throws -> CaptureRecoveryDecision {
    guard state == .interrupted else {
      throw SpatialEvidenceError.invalidTransition(
        from: state.rawValue,
        to: SpatialCaptureSessionState.recovering.rawValue,
        event: SpatialCaptureSessionEvent.beginRecovery.rawValue
      )
    }
    try transition(to: .recovering, event: .beginRecovery, note: decision.rawValue)
    switch decision {
    case .resumeCapturing:
      try transition(to: .capturing, event: .recoverySucceeded)
      return decision
    case .degradeAndContinue:
      if let last = interruptions.last {
        runtimeByStream[last.streamID] = .interrupted
        // Clear samples for interrupted optional stream to avoid inventing evidence.
        clearSamples(for: last.streamID)
      }
      updateDegradedSummary()
      try transition(to: .capturing, event: .recoverySucceeded, note: "degraded")
      return decision
    case .failSession:
      failureReason = interruptions.last?.reason ?? "recovery_failed"
      try transition(to: .failed, event: .recoveryFailed, note: failureReason)
      return decision
    case .cancel:
      try transition(to: .cancelled, event: .cancel)
      return decision
    }
  }

  public func cancel() throws {
    if state.isTerminal {
      if state == .cancelled { return }
      throw SpatialEvidenceError.invalidTransition(
        from: state.rawValue,
        to: SpatialCaptureSessionState.cancelled.rawValue,
        event: SpatialCaptureSessionEvent.cancel.rawValue
      )
    }
    try transition(to: .cancelled, event: .cancel)
    failureReason = "user_cancelled"
  }

  /// Create a checkpoint of accepted sample IDs / buffer state (no duplicates on restore).
  @discardableResult
  public func checkpoint() throws -> CaptureSessionCheckpoint {
    guard state == .capturing || state == .recovering || state == .interrupted else {
      throw SpatialEvidenceError.checkpointFailed("invalid_state:\(state.rawValue)")
    }
    let cp = CaptureSessionCheckpoint(
      checkpointID: "ckpt-\((lastCheckpoint.map { _ in 1 } ?? 0) + (timeline.records.count))",
      state: state,
      acceptedSampleIDs: acceptedSampleIDs,
      lastTimestampByStream: lastTimestampByStream,
      bufferState: bufferState,
      activationResults: activationResults,
      timestampNanoseconds: nextTransitionTs(),
      clockDomain: transitionClockDomain
    )
    lastCheckpoint = cp
    return cp
  }

  /// Restore acceptance bookkeeping from a checkpoint (does not re-emit samples).
  public func restoreCheckpoint(_ checkpoint: CaptureSessionCheckpoint) throws {
    guard state == .recovering || state == .interrupted || state == .capturing else {
      throw SpatialEvidenceError.checkpointFailed("restore_invalid_state:\(state.rawValue)")
    }
    // Union — never drop already-accepted IDs; never allow re-acceptance of checkpointed IDs.
    acceptedSampleIDs.formUnion(checkpoint.acceptedSampleIDs)
    for (stream, ts) in checkpoint.lastTimestampByStream {
      if let current = lastTimestampByStream[stream] {
        lastTimestampByStream[stream] = max(current, ts)
      } else {
        lastTimestampByStream[stream] = ts
      }
    }
    lastCheckpoint = checkpoint
  }

  /// Seal package only when streams are stopped and state permits finalization.
  public func finalizePackage(
    outputDirectory: URL,
    packageID: String = FixtureCoordinatedPackageBuilder.primaryPackageID,
    captureSessionID: String? = nil
  ) throws -> SessionFinalizationResult {
    if state == .cancelled || state == .failed {
      return SessionFinalizationResult(
        sealed: false,
        reason: failureReason ?? state.rawValue
      )
    }
    if adaptersActive {
      throw SpatialEvidenceError.finalizationRejected("active_adapters_must_stop_before_finalize")
    }
    guard state == .finalizing else {
      throw SpatialEvidenceError.finalizationRejected("invalid_state:\(state.rawValue)")
    }

    // Required streams must have been acquired (runtime may be .stopped after clean shutdown).
    for stream in [SpatialStreamID.camera, SpatialStreamID.motion] {
      if policy.requirement(for: stream) == .required {
        let rt = runtimeByStream[stream] ?? .idle
        let ok = (rt == .acquired || rt == .stopped)
        if !ok {
          throw SpatialEvidenceError.finalizationRejected("required_stream_not_acquired:\(stream)")
        }
      }
    }
    if cameraSamples.isEmpty {
      throw SpatialEvidenceError.finalizationRejected("camera_samples_missing")
    }
    if motionSamples.isEmpty && policy.requirement(for: SpatialStreamID.motion) == .required {
      throw SpatialEvidenceError.finalizationRejected("motion_samples_missing")
    }

    try transition(to: .verifyingPackage, event: .beginVerification)
    updateDegradedSummary()

    let pkg = try FixtureCoordinatedPackageBuilder().seal(
      camera: cameraSamples,
      motion: motionSamples,
      pose: poseSamples,
      depth: depthSamples,
      cameraCapability: frozenCapability(stream: SpatialStreamID.camera),
      motionCapability: frozenCapability(stream: SpatialStreamID.motion),
      poseCapability: frozenCapability(stream: SpatialStreamID.pose),
      depthCapability: frozenCapability(stream: SpatialStreamID.depth),
      activationPlan: try requirePlan(),
      activationResults: activationResults,
      policy: policy,
      timeline: timeline,
      interruptions: interruptions,
      bufferState: bufferState,
      degradedSummary: degradedSummary,
      outputDirectory: outputDirectory,
      captureSessionID: captureSessionID ?? sessionID,
      packageID: packageID
    )
    sealedPackage = pkg
    try transition(to: .packaged, event: .packageSealed)
    return SessionFinalizationResult(
      sealed: true,
      package: pkg,
      degradedSummary: degradedSummary
    )
  }

  /// Convenience: discover → start → collect → stop → finalize.
  public func runCoordinatedSession(
    outputDirectory: URL,
    packageID: String = FixtureCoordinatedPackageBuilder.primaryPackageID
  ) async throws -> SessionFinalizationResult {
    try discoverAndPlan()
    try await startStreams()
    try await collectSamples()
    _ = try await stopStreams()
    return try finalizePackage(outputDirectory: outputDirectory, packageID: packageID)
  }

  // MARK: - Sample acceptance (public for unit tests)

  @discardableResult
  public func acceptCameraSample(_ sample: SpatialSampleEnvelope<CameraSample>) throws -> SampleAcceptanceResult {
    let ctx = SampleAcceptanceContext(
      sampleID: sample.sampleID,
      streamID: SpatialStreamID.camera,
      acquisitionTimestampNs: sample.acquisitionTimestampNs,
      clockDomain: sample.clockDomain,
      byteLength: sample.payload.bytes.count
    )
    let result = evaluateAcceptance(ctx)
    guard result.isAccepted else {
      if case .rejected(let reason) = result {
        throw SpatialEvidenceError.sampleRejected(reason)
      }
      return result
    }
    let afterPolicy = enqueueOrDrop(
      streamID: SpatialStreamID.camera,
      byteLength: ctx.byteLength,
      currentCount: cameraSamples.count
    ) {
      if let removed = cameraSamples.first {
        acceptedSampleIDs.remove(removed.sampleID)
        cameraSamples.removeFirst()
      }
    }
    if case .droppedByPolicy(let reason) = afterPolicy, policy.bufferPolicy.dropPolicy == .dropNewest {
      bufferState.droppedNewestCount &+= 1
      bufferState.overflowEvents &+= 1
      return .droppedByPolicy(reason: reason)
    }
    cameraSamples.append(sample)
    commitAccepted(ctx)
    return .accepted
  }

  @discardableResult
  public func acceptMotionSample(_ sample: SpatialSampleEnvelope<MotionSample>) throws -> SampleAcceptanceResult {
    let ctx = SampleAcceptanceContext(
      sampleID: sample.sampleID,
      streamID: SpatialStreamID.motion,
      acquisitionTimestampNs: sample.acquisitionTimestampNs,
      clockDomain: sample.clockDomain,
      byteLength: sample.payload.bytes.count
    )
    let result = evaluateAcceptance(ctx)
    guard result.isAccepted else {
      if case .rejected(let reason) = result {
        throw SpatialEvidenceError.sampleRejected(reason)
      }
      return result
    }
    let dropNewest = enqueueOrDrop(
      streamID: SpatialStreamID.motion,
      byteLength: ctx.byteLength,
      currentCount: motionSamples.count
    ) {
      motionSamples.removeFirst()
    }
    if case .droppedByPolicy(let reason) = dropNewest, policy.bufferPolicy.dropPolicy == .dropNewest {
      bufferState.droppedNewestCount &+= 1
      bufferState.overflowEvents &+= 1
      return .droppedByPolicy(reason: reason)
    }
    motionSamples.append(sample)
    commitAccepted(ctx)
    return .accepted
  }

  @discardableResult
  public func acceptPoseSample(_ sample: SpatialSampleEnvelope<PoseSample>) throws -> SampleAcceptanceResult {
    let ctx = SampleAcceptanceContext(
      sampleID: sample.sampleID,
      streamID: SpatialStreamID.pose,
      acquisitionTimestampNs: sample.acquisitionTimestampNs,
      clockDomain: sample.clockDomain,
      frameEpochID: sample.payload.frameEpochID,
      sessionRunID: sample.payload.sessionRunID,
      worldOriginRevision: sample.payload.worldOriginRevision,
      byteLength: sample.payload.bytes.count
    )
    let result = evaluateAcceptance(ctx)
    guard result.isAccepted else {
      if case .rejected(let reason) = result {
        throw SpatialEvidenceError.sampleRejected(reason)
      }
      return result
    }
    let dropNewest = enqueueOrDrop(
      streamID: SpatialStreamID.pose,
      byteLength: ctx.byteLength,
      currentCount: poseSamples.count
    ) {
      poseSamples.removeFirst()
    }
    if case .droppedByPolicy(let reason) = dropNewest, policy.bufferPolicy.dropPolicy == .dropNewest {
      bufferState.droppedNewestCount &+= 1
      bufferState.overflowEvents &+= 1
      return .droppedByPolicy(reason: reason)
    }
    poseSamples.append(sample)
    commitAccepted(ctx)
    return .accepted
  }

  @discardableResult
  public func acceptDepthSample(_ sample: SpatialSampleEnvelope<DepthSample>) throws -> SampleAcceptanceResult {
    let ctx = SampleAcceptanceContext(
      sampleID: sample.sampleID,
      streamID: SpatialStreamID.depth,
      acquisitionTimestampNs: sample.acquisitionTimestampNs,
      clockDomain: sample.clockDomain,
      frameEpochID: sample.payload.frameEpochID,
      sessionRunID: sample.payload.sessionRunID,
      worldOriginRevision: sample.payload.worldOriginRevision,
      byteLength: sample.payload.bytes.count
    )
    let result = evaluateAcceptance(ctx)
    guard result.isAccepted else {
      if case .rejected(let reason) = result {
        throw SpatialEvidenceError.sampleRejected(reason)
      }
      return result
    }
    let dropNewest = enqueueOrDrop(
      streamID: SpatialStreamID.depth,
      byteLength: ctx.byteLength,
      currentCount: depthSamples.count
    ) {
      depthSamples.removeFirst()
    }
    if case .droppedByPolicy(let reason) = dropNewest, policy.bufferPolicy.dropPolicy == .dropNewest {
      bufferState.droppedNewestCount &+= 1
      bufferState.overflowEvents &+= 1
      return .droppedByPolicy(reason: reason)
    }
    depthSamples.append(sample)
    commitAccepted(ctx)
    return .accepted
  }

  /// Evaluate acceptance without mutating buffers (used by tests).
  public func evaluateAcceptance(_ ctx: SampleAcceptanceContext) -> SampleAcceptanceResult {
    if !state.permitsSampleAcceptance {
      return .rejected(reason: "state_does_not_permit_capture:\(state.rawValue)")
    }
    let req = policy.requirement(for: ctx.streamID)
    if req == .notRequested {
      return .rejected(reason: "stream_not_requested:\(ctx.streamID)")
    }
    guard SpatialStreamID.all.contains(ctx.streamID) else {
      return .rejected(reason: "unknown_stream:\(ctx.streamID)")
    }
    let runtime = runtimeByStream[ctx.streamID] ?? .idle
    if runtime != .acquired {
      return .rejected(reason: "stream_not_active:\(ctx.streamID):\(runtime.rawValue)")
    }
    if acceptedSampleIDs.contains(ctx.sampleID) {
      return .rejected(reason: "duplicate_sample_id:\(ctx.sampleID)")
    }
    if let last = lastTimestampByStream[ctx.streamID], ctx.acquisitionTimestampNs <= last {
      return .rejected(
        reason: "timestamp_regression:\(ctx.streamID):\(last)->\(ctx.acquisitionTimestampNs)"
      )
    }
    if let expected = policy.expectedClockDomains[ctx.streamID], expected != ctx.clockDomain {
      return .rejected(
        reason: "clock_domain_mismatch:\(ctx.streamID):expected=\(expected.rawValue):actual=\(ctx.clockDomain.rawValue)"
      )
    }
    if let epoch = ctx.frameEpochID, epoch != policy.expectedFrameEpochID {
      return .rejected(reason: "frame_epoch_mismatch:\(epoch)")
    }
    if let run = ctx.sessionRunID, run != policy.expectedSessionRunID {
      return .rejected(reason: "session_run_mismatch:\(run)")
    }
    if let rev = ctx.worldOriginRevision, rev != policy.expectedWorldOriginRevision {
      return .rejected(reason: "world_origin_revision_mismatch:\(rev)")
    }
    return .accepted
  }

  /// Test hook: force `adaptersActive` after stop to prove finalization fail-closed.
  public func markAdaptersActiveForTesting(_ active: Bool) {
    adaptersActive = active
  }

  // MARK: - Internals

  private func configureFixtureClocks() {
    if let camera = camera as? ControllableCameraSensorAdapter {
      camera.clockDomain = policy.expectedClockDomains[SpatialStreamID.camera] ?? .fixtureCamera
      camera.coordinateFrameID = "FRAME_CAMERA_OPTICAL"
      camera.emitCount = 2
    }
    if let motion = motion as? ControllableMotionSensorAdapter {
      motion.clockDomain = policy.expectedClockDomains[SpatialStreamID.motion] ?? .fixtureMotion
      motion.coordinateFrameID = "FRAME_DEVICE_IMU"
      motion.emitCount = 2
    }
    if let pose = pose as? ControllablePoseSensorAdapter {
      pose.clockDomain = policy.expectedClockDomains[SpatialStreamID.pose] ?? .arkitFrame
      pose.emitCount = 2
    }
    if let depth = depth as? ControllableDepthSensorAdapter {
      depth.clockDomain = policy.expectedClockDomains[SpatialStreamID.depth] ?? .fixtureDepth
      depth.emitCount = 2
    }
  }

  private func discoveredAdapterIDs() -> [String: String] {
    var map: [String: String] = [:]
    if let camera { map[SpatialStreamID.camera] = camera.adapterID }
    if let motion { map[SpatialStreamID.motion] = motion.adapterID }
    if let pose { map[SpatialStreamID.pose] = pose.adapterID }
    if let depth { map[SpatialStreamID.depth] = depth.adapterID }
    return map
  }

  private func buildActivationPlan() throws -> SensorActivationPlan {
    let adapters = discoveredAdapterIDs()
    var entries: [SensorActivationPlanEntry] = []
    var order = 0
    for stream in policy.orderedStartup {
      let req = policy.requirement(for: stream)
      if req == .notRequested {
        entries.append(
          SensorActivationPlanEntry(
            streamID: stream,
            adapterID: "none",
            requirement: .notRequested,
            startupOrder: order
          )
        )
        order += 1
        continue
      }
      guard let adapterID = adapters[stream] else {
        if req == .required {
          throw SpatialEvidenceError.activationPlanRejected("missing_required_adapter:\(stream)")
        }
        entries.append(
          SensorActivationPlanEntry(
            streamID: stream,
            adapterID: "none",
            requirement: req,
            startupOrder: order
          )
        )
        order += 1
        continue
      }
      entries.append(
        SensorActivationPlanEntry(
          streamID: stream,
          adapterID: adapterID,
          requirement: req,
          startupOrder: order
        )
      )
      order += 1
    }
    return SensorActivationPlan(planID: "PLAN-\(sessionID)", entries: entries)
  }

  private func activate(entry: SensorActivationPlanEntry) async -> SensorActivationResult {
    runtimeByStream[entry.streamID] = .activating
    do {
      switch entry.streamID {
      case SpatialStreamID.camera:
        guard let camera else {
          return unavailableResult(entry, .unavailableDevice, "no_camera_adapter")
        }
        try await camera.start()
        return SensorActivationResult(
          streamID: entry.streamID,
          adapterID: entry.adapterID,
          runtimeState: .acquired
        )
      case SpatialStreamID.motion:
        guard let motion else {
          return unavailableResult(entry, .unavailableDevice, "no_motion_adapter")
        }
        try await motion.start()
        return SensorActivationResult(
          streamID: entry.streamID,
          adapterID: entry.adapterID,
          runtimeState: .acquired
        )
      case SpatialStreamID.pose:
        guard let pose else {
          return unavailableResult(entry, .unavailableDevice, "no_pose_adapter")
        }
        try await pose.start()
        return SensorActivationResult(
          streamID: entry.streamID,
          adapterID: entry.adapterID,
          runtimeState: .acquired
        )
      case SpatialStreamID.depth:
        guard let depth else {
          return unavailableResult(entry, .unavailableDevice, "no_depth_adapter")
        }
        try await depth.start()
        return SensorActivationResult(
          streamID: entry.streamID,
          adapterID: entry.adapterID,
          runtimeState: .acquired
        )
      default:
        return SensorActivationResult(
          streamID: entry.streamID,
          adapterID: entry.adapterID,
          runtimeState: .activationFailed,
          disposition: disposition(for: entry.requirement),
          reason: "unknown_stream"
        )
      }
    } catch let ProductionSensorError.depthUnavailableDevice(reason) {
      return unavailableResult(entry, .unavailableDevice, reason)
    } catch let ProductionSensorError.depthUnavailableConfiguration(reason) {
      return unavailableResult(entry, .unavailableConfiguration, reason)
    } catch let ProductionSensorError.depthActivationFailed(reason) {
      return failResult(entry, reason)
    } catch let ProductionSensorError.interrupted(reason) {
      await stopAdapter(streamID: entry.streamID)
      return SensorActivationResult(
        streamID: entry.streamID,
        adapterID: entry.adapterID,
        runtimeState: .interrupted,
        disposition: disposition(for: entry.requirement),
        reason: reason
      )
    } catch let ProductionSensorError.unavailable(reason) {
      await stopAdapter(streamID: entry.streamID)
      return failResult(entry, reason)
    } catch {
      await stopAdapter(streamID: entry.streamID)
      return failResult(entry, String(describing: error))
    }
  }

  private func unavailableResult(
    _ entry: SensorActivationPlanEntry,
    _ state: StreamRuntimeState,
    _ reason: String
  ) -> SensorActivationResult {
    SensorActivationResult(
      streamID: entry.streamID,
      adapterID: entry.adapterID,
      runtimeState: state,
      disposition: disposition(for: entry.requirement),
      reason: reason
    )
  }

  private func failResult(_ entry: SensorActivationPlanEntry, _ reason: String) -> SensorActivationResult {
    SensorActivationResult(
      streamID: entry.streamID,
      adapterID: entry.adapterID,
      runtimeState: .activationFailed,
      disposition: disposition(for: entry.requirement),
      reason: reason
    )
  }

  private func disposition(for requirement: StreamRequirement) -> StreamFailureDisposition {
    switch requirement {
    case .required: return .failSession
    case .optional: return .degradeOptional
    case .notRequested: return .degradeOptional
    }
  }

  private func rollbackStarted(_ streams: [String]) async {
    for stream in streams.reversed() {
      await stopAdapter(streamID: stream)
      runtimeByStream[stream] = .stopped
    }
    adaptersActive = false
  }

  private func deactivateAll() async {
    for stream in [
      SpatialStreamID.depth,
      SpatialStreamID.pose,
      SpatialStreamID.motion,
      SpatialStreamID.camera,
    ] {
      let rt = runtimeByStream[stream]
      if rt == .acquired || rt == .activating || rt == .interrupted {
        await stopAdapter(streamID: stream)
        if rt == .acquired {
          runtimeByStream[stream] = .stopped
        }
      }
    }
    adaptersActive = false
  }

  private func stopAdapter(streamID: String) async {
    switch streamID {
    case SpatialStreamID.camera: await camera?.stop()
    case SpatialStreamID.motion: await motion?.stop()
    case SpatialStreamID.pose: await pose?.stop()
    case SpatialStreamID.depth: await depth?.stop()
    default: break
    }
  }

  private func clearSamples(for streamID: String) {
    switch streamID {
    case SpatialStreamID.camera:
      for s in cameraSamples { acceptedSampleIDs.remove(s.sampleID) }
      cameraSamples.removeAll()
    case SpatialStreamID.motion:
      for s in motionSamples { acceptedSampleIDs.remove(s.sampleID) }
      motionSamples.removeAll()
    case SpatialStreamID.pose:
      for s in poseSamples { acceptedSampleIDs.remove(s.sampleID) }
      poseSamples.removeAll()
    case SpatialStreamID.depth:
      for s in depthSamples { acceptedSampleIDs.remove(s.sampleID) }
      depthSamples.removeAll()
    default: break
    }
    bufferState.queuedSamplesByStream[streamID] = 0
    bufferState.queuedBytesByStream[streamID] = 0
  }

  private func updateDegradedSummary() {
    var degraded: [String] = []
    var reasons: [String: String] = [:]
    for result in activationResults {
      let req = policy.requirement(for: result.streamID)
      guard req == .optional else { continue }
      switch result.runtimeState {
      case .acquired, .notRequested, .idle, .activating, .stopped:
        break
      default:
        degraded.append(result.streamID)
        reasons[result.streamID] = result.reason ?? result.runtimeState.rawValue
      }
    }
    // Interrupted optional streams recorded after activation.
    for (stream, rt) in runtimeByStream {
      if policy.requirement(for: stream) == .optional, rt == .interrupted,
        !degraded.contains(stream)
      {
        degraded.append(stream)
        reasons[stream] = interruptions.last(where: { $0.streamID == stream })?.reason
          ?? "INTERRUPTED"
      }
    }
    if degraded.isEmpty {
      degradedSummary = nil
    } else {
      degradedSummary = DegradedCaptureSummary(
        degradedStreams: degraded,
        reasons: reasons,
        stillValid: true
      )
    }
  }

  private func frozenCapability(stream: String) -> SpatialStreamCapability {
    let runtime = runtimeByStream[stream] ?? .notRequested
    let req = policy.requirement(for: stream)
    if req == .notRequested {
      var cap = SpatialStreamCapability(
        streamID: stream,
        adapterID: "none",
        sensorKind: stream,
        declared: false
      )
      try? cap.freeze(outcome: .notRequested)
      return cap
    }

    var cap: SpatialStreamCapability
    switch stream {
    case SpatialStreamID.camera:
      cap = camera?.capability
        ?? SpatialStreamCapability(streamID: stream, adapterID: "none", sensorKind: stream)
    case SpatialStreamID.motion:
      cap = motion?.capability
        ?? SpatialStreamCapability(streamID: stream, adapterID: "none", sensorKind: stream)
    case SpatialStreamID.pose:
      cap = pose?.capability
        ?? SpatialStreamCapability(streamID: stream, adapterID: "none", sensorKind: stream)
    case SpatialStreamID.depth:
      cap = depth?.capability
        ?? SpatialStreamCapability(streamID: stream, adapterID: "none", sensorKind: stream)
    default:
      cap = SpatialStreamCapability(streamID: stream, adapterID: "none", sensorKind: stream)
    }

    let outcome: SpatialCapabilityFinalOutcome
    switch runtime {
    case .acquired, .stopped:
      if sampleCount(for: stream) > 0 {
        outcome = .acquired
      } else if let result = activationResults.first(where: { $0.streamID == stream }) {
        outcome = result.capabilityOutcome
      } else {
        outcome = .failed
      }
    case .unavailableDevice:
      outcome = .unavailableDevice
    case .unavailableConfiguration:
      outcome = .unavailableConfiguration
    case .activationFailed:
      outcome = .activationFailed
    case .interrupted:
      outcome = .degradedOptionalDrop
    case .notRequested:
      outcome = .notRequested
    case .idle, .activating:
      outcome = .failed
    }
    if outcome == .acquired {
      let count = UInt64(sampleCount(for: stream))
      while cap.samplesAcquired < count { cap.recordSample() }
      if cap.stage == .declared { cap.activate() }
    }
    do {
      try cap.freeze(outcome: outcome)
      return cap
    } catch {
      let fallback: SpatialCapabilityFinalOutcome =
        (req == .optional) ? .degradedOptionalDrop : .failed
      var copy = SpatialStreamCapability(
        streamID: cap.streamID,
        adapterID: cap.adapterID,
        sensorKind: cap.sensorKind,
        declared: true,
        stage: .activated,
        samplesAcquired: 0
      )
      try? copy.freeze(outcome: fallback)
      return copy
    }
  }

  private func sampleCount(for stream: String) -> Int {
    switch stream {
    case SpatialStreamID.camera: return cameraSamples.count
    case SpatialStreamID.motion: return motionSamples.count
    case SpatialStreamID.pose: return poseSamples.count
    case SpatialStreamID.depth: return depthSamples.count
    default: return 0
    }
  }

  private func commitAccepted(_ ctx: SampleAcceptanceContext) {
    acceptedSampleIDs.insert(ctx.sampleID)
    lastTimestampByStream[ctx.streamID] = ctx.acquisitionTimestampNs
    let q = (bufferState.queuedSamplesByStream[ctx.streamID] ?? 0) + 1
    let b = (bufferState.queuedBytesByStream[ctx.streamID] ?? 0) + ctx.byteLength
    bufferState.queuedSamplesByStream[ctx.streamID] = q
    bufferState.queuedBytesByStream[ctx.streamID] = b
  }

  /// Returns `.droppedByPolicy` when dropNewest rejects the incoming sample; otherwise
  /// mutates buffer (dropOldest) and returns `.accepted` so caller may append.
  private func enqueueOrDrop(
    streamID: String,
    byteLength: Int,
    currentCount: Int,
    dropOldest: () -> Void
  ) -> SampleAcceptanceResult {
    let maxN = policy.bufferPolicy.maxQueuedSamplesPerStream
    let maxB = policy.bufferPolicy.maxQueuedBytes
    let curBytes = bufferState.queuedBytesByStream[streamID] ?? 0
    let wouldExceed = currentCount >= maxN || (curBytes + byteLength) > maxB
    guard wouldExceed else { return .accepted }

    switch policy.bufferPolicy.dropPolicy {
    case .dropNewest:
      return .droppedByPolicy(reason: "buffer_overflow_drop_newest:\(streamID)")
    case .dropOldest:
      if currentCount > 0 {
        dropOldest()
        bufferState.droppedOldestCount &+= 1
        bufferState.overflowEvents &+= 1
        let prevBytes = bufferState.queuedBytesByStream[streamID] ?? 0
        // Approximate byte accounting: subtract average if unknown; prefer leave count correct.
        bufferState.queuedSamplesByStream[streamID] = max(0, currentCount - 1)
        bufferState.queuedBytesByStream[streamID] = max(0, prevBytes - byteLength)
      }
      return .accepted
    }
  }

  private func optionalOrRequired(_ streamID: String) -> StreamRequirement? {
    let r = policy.requirement(for: streamID)
    return r == .notRequested ? nil : r
  }

  private func requirePlan() throws -> SensorActivationPlan {
    guard let activationPlan else {
      throw SpatialEvidenceError.activationPlanRejected("plan_missing")
    }
    return activationPlan
  }

  private func nextTransitionTs() -> UInt64 {
    transitionClockNs &+= 1_000_000
    return transitionClockNs
  }

  private func transition(
    to next: SpatialCaptureSessionState,
    event: SpatialCaptureSessionEvent,
    note: String? = nil
  ) throws {
    let prev = state
    guard Self.isAllowed(from: prev, to: next, event: event) else {
      throw SpatialEvidenceError.invalidTransition(
        from: prev.rawValue,
        to: next.rawValue,
        event: event.rawValue
      )
    }
    state = next
    timeline.append(
      CaptureSessionTransitionRecord(
        timestampNanoseconds: nextTransitionTs(),
        clockDomain: transitionClockDomain,
        previousState: prev,
        nextState: next,
        event: event,
        note: note
      )
    )
  }

  /// Fail-closed allowed transition table.
  private static func isAllowed(
    from: SpatialCaptureSessionState,
    to: SpatialCaptureSessionState,
    event: SpatialCaptureSessionEvent
  ) -> Bool {
    switch (from, to, event) {
    case (.idle, .capabilityDiscovery, .beginDiscovery): return true
    case (.capabilityDiscovery, .planning, .discoveryComplete): return true
    case (.planning, .preparing, .planAccepted): return true
    case (.preparing, .startingStreams, .startStreams): return true
    case (.startingStreams, .capturing, .streamsStarted): return true
    case (.startingStreams, .failed, .fail): return true
    case (.startingStreams, .cancelled, .cancel): return true
    case (.capturing, .interrupted, .interrupt): return true
    case (.capturing, .stopping, .stop): return true
    case (.capturing, .cancelled, .cancel): return true
    case (.capturing, .failed, .fail): return true
    case (.interrupted, .recovering, .beginRecovery): return true
    case (.interrupted, .cancelled, .cancel): return true
    case (.interrupted, .failed, .fail): return true
    case (.interrupted, .stopping, .stop): return true
    case (.recovering, .capturing, .recoverySucceeded): return true
    case (.recovering, .failed, .recoveryFailed): return true
    case (.recovering, .cancelled, .cancel): return true
    case (.recovering, .stopping, .stop): return true
    case (.stopping, .finalizing, .streamsStopped): return true
    case (.stopping, .cancelled, .cancel): return true
    case (.stopping, .failed, .fail): return true
    case (.finalizing, .verifyingPackage, .beginVerification): return true
    case (.finalizing, .failed, .fail): return true
    case (.finalizing, .cancelled, .cancel): return true
    case (.verifyingPackage, .packaged, .packageSealed): return true
    case (.verifyingPackage, .failed, .fail): return true
    case (.idle, .cancelled, .cancel): return true
    case (.capabilityDiscovery, .cancelled, .cancel): return true
    case (.planning, .cancelled, .cancel): return true
    case (.preparing, .cancelled, .cancel): return true
    default: return false
    }
  }
}
