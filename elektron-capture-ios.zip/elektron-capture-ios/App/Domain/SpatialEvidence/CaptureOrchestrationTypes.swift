import Foundation

// MARK: - Session state machine (Sprint 3.4)

/// Multi-stream spatial capture session states. Fail-closed; invalid transitions throw.
public enum SpatialCaptureSessionState: String, Codable, Sendable, Equatable, CaseIterable {
  case idle = "IDLE"
  case capabilityDiscovery = "CAPABILITY_DISCOVERY"
  case planning = "PLANNING"
  case preparing = "PREPARING"
  case startingStreams = "STARTING_STREAMS"
  case capturing = "CAPTURING"
  case interrupted = "INTERRUPTED"
  case recovering = "RECOVERING"
  case stopping = "STOPPING"
  case finalizing = "FINALIZING"
  case verifyingPackage = "VERIFYING_PACKAGE"
  case packaged = "PACKAGED"
  case failed = "FAILED"
  case cancelled = "CANCELLED"

  public var isTerminal: Bool {
    switch self {
    case .packaged, .failed, .cancelled: return true
    default: return false
    }
  }

  public var permitsSampleAcceptance: Bool {
    switch self {
    case .capturing, .recovering: return true
    default: return false
    }
  }
}

/// Explicit session events driving the state machine.
public enum SpatialCaptureSessionEvent: String, Codable, Sendable, Equatable, CaseIterable {
  case beginDiscovery = "BEGIN_DISCOVERY"
  case discoveryComplete = "DISCOVERY_COMPLETE"
  case planAccepted = "PLAN_ACCEPTED"
  case prepare = "PREPARE"
  case startStreams = "START_STREAMS"
  case streamsStarted = "STREAMS_STARTED"
  case interrupt = "INTERRUPT"
  case beginRecovery = "BEGIN_RECOVERY"
  case recoverySucceeded = "RECOVERY_SUCCEEDED"
  case recoveryFailed = "RECOVERY_FAILED"
  case stop = "STOP"
  case streamsStopped = "STREAMS_STOPPED"
  case beginFinalization = "BEGIN_FINALIZATION"
  case beginVerification = "BEGIN_VERIFICATION"
  case packageSealed = "PACKAGE_SEALED"
  case fail = "FAIL"
  case cancel = "CANCEL"
}

/// Whether a stream is required, optional, or excluded from the session.
public enum StreamRequirement: String, Codable, Sendable, Equatable {
  case required = "REQUIRED"
  case optional = "OPTIONAL"
  case notRequested = "NOT_REQUESTED"
}

/// Runtime activation outcome for one stream (distinct from SpatialCapabilityFinalOutcome labels).
public enum StreamRuntimeState: String, Codable, Sendable, Equatable {
  case idle = "IDLE"
  case activating = "ACTIVATING"
  case acquired = "ACQUIRED"
  case unavailableDevice = "UNAVAILABLE_DEVICE"
  case unavailableConfiguration = "UNAVAILABLE_CONFIGURATION"
  case activationFailed = "ACTIVATION_FAILED"
  case interrupted = "INTERRUPTED"
  case stopped = "STOPPED"
  case notRequested = "NOT_REQUESTED"
}

/// How a stream failure should affect the session.
public enum StreamFailureDisposition: String, Codable, Sendable, Equatable {
  case failSession = "FAIL_SESSION"
  case degradeOptional = "DEGRADE_OPTIONAL"
  case interruptAndRecover = "INTERRUPT_AND_RECOVER"
}

/// Session policy: required/optional streams, buffer limits, ordered startup.
public struct SpatialCaptureSessionPolicy: Sendable, Equatable {
  public var streamRequirements: [String: StreamRequirement]
  public var orderedStartup: [String]
  public var bufferPolicy: CaptureBufferPolicy
  public var expectedFrameEpochID: String
  public var expectedSessionRunID: String
  public var expectedWorldOriginRevision: UInt64
  public var expectedClockDomains: [String: ClockDomain]
  public var allowPartialOptionalStartup: Bool

  public init(
    streamRequirements: [String: StreamRequirement],
    orderedStartup: [String] = [
      SpatialStreamID.camera,
      SpatialStreamID.motion,
      SpatialStreamID.pose,
      SpatialStreamID.depth,
    ],
    bufferPolicy: CaptureBufferPolicy = .fixtureDefault,
    expectedFrameEpochID: String = "epoch-fixture-1",
    expectedSessionRunID: String = "run-fixture-1",
    expectedWorldOriginRevision: UInt64 = 1,
    expectedClockDomains: [String: ClockDomain] = [:],
    allowPartialOptionalStartup: Bool = true
  ) {
    self.streamRequirements = streamRequirements
    self.orderedStartup = orderedStartup
    self.bufferPolicy = bufferPolicy
    self.expectedFrameEpochID = expectedFrameEpochID
    self.expectedSessionRunID = expectedSessionRunID
    self.expectedWorldOriginRevision = expectedWorldOriginRevision
    self.expectedClockDomains = expectedClockDomains
    self.allowPartialOptionalStartup = allowPartialOptionalStartup
  }

  /// Primary Sprint 3.4 fixture policy: camera+motion required; pose+depth optional.
  public static func primaryFixture() -> SpatialCaptureSessionPolicy {
    SpatialCaptureSessionPolicy(
      streamRequirements: [
        SpatialStreamID.camera: .required,
        SpatialStreamID.motion: .required,
        SpatialStreamID.pose: .optional,
        SpatialStreamID.depth: .optional,
      ],
      expectedClockDomains: [
        SpatialStreamID.camera: .fixtureCamera,
        SpatialStreamID.motion: .fixtureMotion,
        SpatialStreamID.pose: .arkitFrame,
        SpatialStreamID.depth: .fixtureDepth,
      ]
    )
  }

  public func requirement(for streamID: String) -> StreamRequirement {
    streamRequirements[streamID] ?? .notRequested
  }

  public func asDictionary() -> [String: Any] {
    var req: [String: String] = [:]
    for (k, v) in streamRequirements.sorted(by: { $0.key < $1.key }) {
      req[k] = v.rawValue
    }
    var clocks: [String: String] = [:]
    for (k, v) in expectedClockDomains.sorted(by: { $0.key < $1.key }) {
      clocks[k] = v.rawValue
    }
    return [
      "schema_id": "SpatialCaptureSessionPolicy",
      "schema_version": "1.0.0-phase3-fixture",
      "stream_requirements": req,
      "ordered_startup": orderedStartup,
      "buffer_policy": bufferPolicy.asDictionary(),
      "expected_frame_epoch_id": expectedFrameEpochID,
      "expected_session_run_id": expectedSessionRunID,
      "expected_world_origin_revision": expectedWorldOriginRevision,
      "expected_clock_domains": clocks,
      "allow_partial_optional_startup": allowPartialOptionalStartup,
    ]
  }
}

/// One planned stream activation step.
public struct SensorActivationPlanEntry: Sendable, Equatable {
  public let streamID: String
  public let adapterID: String
  public let requirement: StreamRequirement
  public let startupOrder: Int

  public init(streamID: String, adapterID: String, requirement: StreamRequirement, startupOrder: Int) {
    self.streamID = streamID
    self.adapterID = adapterID
    self.requirement = requirement
    self.startupOrder = startupOrder
  }

  public func asDictionary() -> [String: Any] {
    [
      "stream_id": streamID,
      "adapter_id": adapterID,
      "requirement": requirement.rawValue,
      "startup_order": startupOrder,
    ]
  }
}

/// Deterministic activation plan derived from policy + discovered adapters.
public struct SensorActivationPlan: Sendable, Equatable {
  public let planID: String
  public let entries: [SensorActivationPlanEntry]

  public init(planID: String, entries: [SensorActivationPlanEntry]) {
    self.planID = planID
    self.entries = entries
  }

  public func asDictionary() -> [String: Any] {
    [
      "schema_id": "SensorActivationPlan",
      "schema_version": "1.0.0-phase3-fixture",
      "plan_id": planID,
      "entries": entries.map { $0.asDictionary() },
    ]
  }
}

/// Result of attempting to activate one stream.
public struct SensorActivationResult: Sendable, Equatable {
  public let streamID: String
  public let adapterID: String
  public let runtimeState: StreamRuntimeState
  public let disposition: StreamFailureDisposition?
  public let reason: String?

  public init(
    streamID: String,
    adapterID: String,
    runtimeState: StreamRuntimeState,
    disposition: StreamFailureDisposition? = nil,
    reason: String? = nil
  ) {
    self.streamID = streamID
    self.adapterID = adapterID
    self.runtimeState = runtimeState
    self.disposition = disposition
    self.reason = reason
  }

  public var capabilityOutcome: SpatialCapabilityFinalOutcome {
    switch runtimeState {
    case .acquired: return .acquired
    case .notRequested: return .notRequested
    case .unavailableDevice: return .unavailableDevice
    case .unavailableConfiguration: return .unavailableConfiguration
    case .activationFailed: return .activationFailed
    case .interrupted: return .interruptedAfterActivation
    case .idle, .activating, .stopped: return .failed
    }
  }

  public func asDictionary() -> [String: Any] {
    var d: [String: Any] = [
      "stream_id": streamID,
      "adapter_id": adapterID,
      "runtime_state": runtimeState.rawValue,
      "capability_outcome": capabilityOutcome.rawValue,
    ]
    if let disposition { d["disposition"] = disposition.rawValue }
    if let reason { d["reason"] = reason }
    return d
  }
}

/// Recorded interruption during capture.
public struct CaptureInterruption: Sendable, Equatable {
  public let interruptionID: String
  public let streamID: String
  public let reason: String
  public let timestampNanoseconds: UInt64
  public let clockDomain: ClockDomain
  public let recoverable: Bool

  public init(
    interruptionID: String,
    streamID: String,
    reason: String,
    timestampNanoseconds: UInt64,
    clockDomain: ClockDomain,
    recoverable: Bool
  ) {
    self.interruptionID = interruptionID
    self.streamID = streamID
    self.reason = reason
    self.timestampNanoseconds = timestampNanoseconds
    self.clockDomain = clockDomain
    self.recoverable = recoverable
  }

  public func asDictionary() -> [String: Any] {
    [
      "interruption_id": interruptionID,
      "stream_id": streamID,
      "reason": reason,
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain.rawValue,
      "recoverable": recoverable,
    ]
  }
}

/// Decision taken after interruption recovery attempt.
public enum CaptureRecoveryDecision: String, Codable, Sendable, Equatable {
  case resumeCapturing = "RESUME_CAPTURING"
  case degradeAndContinue = "DEGRADE_AND_CONTINUE"
  case failSession = "FAIL_SESSION"
  case cancel = "CANCEL"
}

/// Bounded buffer policy for accepted samples awaiting packaging.
public struct CaptureBufferPolicy: Sendable, Equatable {
  public enum DropPolicy: String, Codable, Sendable, Equatable {
    case dropOldest = "DROP_OLDEST"
    case dropNewest = "DROP_NEWEST"
  }

  public var maxQueuedSamplesPerStream: Int
  public var maxQueuedBytes: Int
  public var dropPolicy: DropPolicy

  public init(
    maxQueuedSamplesPerStream: Int = 64,
    maxQueuedBytes: Int = 1_048_576,
    dropPolicy: DropPolicy = .dropOldest
  ) {
    self.maxQueuedSamplesPerStream = maxQueuedSamplesPerStream
    self.maxQueuedBytes = maxQueuedBytes
    self.dropPolicy = dropPolicy
  }

  public static let fixtureDefault = CaptureBufferPolicy(
    maxQueuedSamplesPerStream: 32,
    maxQueuedBytes: 256_000,
    dropPolicy: .dropOldest
  )

  public func asDictionary() -> [String: Any] {
    [
      "max_queued_samples_per_stream": maxQueuedSamplesPerStream,
      "max_queued_bytes": maxQueuedBytes,
      "drop_policy": dropPolicy.rawValue,
    ]
  }
}

/// Per-stream / aggregate buffer counters.
public struct CaptureBufferState: Sendable, Equatable {
  public var queuedSamplesByStream: [String: Int]
  public var queuedBytesByStream: [String: Int]
  public var droppedOldestCount: UInt64
  public var droppedNewestCount: UInt64
  public var overflowEvents: UInt64

  public init(
    queuedSamplesByStream: [String: Int] = [:],
    queuedBytesByStream: [String: Int] = [:],
    droppedOldestCount: UInt64 = 0,
    droppedNewestCount: UInt64 = 0,
    overflowEvents: UInt64 = 0
  ) {
    self.queuedSamplesByStream = queuedSamplesByStream
    self.queuedBytesByStream = queuedBytesByStream
    self.droppedOldestCount = droppedOldestCount
    self.droppedNewestCount = droppedNewestCount
    self.overflowEvents = overflowEvents
  }

  public func asDictionary() -> [String: Any] {
    [
      "queued_samples_by_stream": queuedSamplesByStream,
      "queued_bytes_by_stream": queuedBytesByStream,
      "dropped_oldest_count": droppedOldestCount,
      "dropped_newest_count": droppedNewestCount,
      "overflow_events": overflowEvents,
    ]
  }
}

/// Result of evaluating a candidate sample for acceptance.
public enum SampleAcceptanceResult: Sendable, Equatable {
  case accepted
  case rejected(reason: String)
  case droppedByPolicy(reason: String)

  public var isAccepted: Bool {
    if case .accepted = self { return true }
    return false
  }

  public func asDictionary() -> [String: Any] {
    switch self {
    case .accepted:
      return ["status": "ACCEPTED"]
    case .rejected(let reason):
      return ["status": "REJECTED", "reason": reason]
    case .droppedByPolicy(let reason):
      return ["status": "DROPPED_BY_POLICY", "reason": reason]
    }
  }
}

/// Outcome of package finalization.
public struct SessionFinalizationResult: Sendable {
  public let sealed: Bool
  public let package: SpatialEvidencePackage?
  public let degradedSummary: DegradedCaptureSummary?
  public let reason: String?

  public init(
    sealed: Bool,
    package: SpatialEvidencePackage? = nil,
    degradedSummary: DegradedCaptureSummary? = nil,
    reason: String? = nil
  ) {
    self.sealed = sealed
    self.package = package
    self.degradedSummary = degradedSummary
    self.reason = reason
  }
}

/// Summary of optional-stream degradation retained in a valid sealed package.
public struct DegradedCaptureSummary: Sendable, Equatable {
  public let degradedStreams: [String]
  public let reasons: [String: String]
  public let stillValid: Bool

  public init(degradedStreams: [String], reasons: [String: String], stillValid: Bool) {
    self.degradedStreams = degradedStreams.sorted()
    self.reasons = reasons
    self.stillValid = stillValid
  }

  public func asDictionary() -> [String: Any] {
    [
      "degraded_streams": degradedStreams,
      "reasons": reasons,
      "still_valid": stillValid,
    ]
  }
}

/// One state-machine transition record.
public struct CaptureSessionTransitionRecord: Sendable, Equatable {
  public let timestampNanoseconds: UInt64
  public let clockDomain: ClockDomain
  public let previousState: SpatialCaptureSessionState
  public let nextState: SpatialCaptureSessionState
  public let event: SpatialCaptureSessionEvent
  public let note: String?

  public init(
    timestampNanoseconds: UInt64,
    clockDomain: ClockDomain,
    previousState: SpatialCaptureSessionState,
    nextState: SpatialCaptureSessionState,
    event: SpatialCaptureSessionEvent,
    note: String? = nil
  ) {
    self.timestampNanoseconds = timestampNanoseconds
    self.clockDomain = clockDomain
    self.previousState = previousState
    self.nextState = nextState
    self.event = event
    self.note = note
  }

  public func asDictionary() -> [String: Any] {
    var d: [String: Any] = [
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain.rawValue,
      "previous_state": previousState.rawValue,
      "next_state": nextState.rawValue,
      "event": event.rawValue,
    ]
    if let note { d["note"] = note }
    return d
  }
}

/// Append-only session timeline.
public struct CaptureSessionTimeline: Sendable, Equatable {
  public private(set) var records: [CaptureSessionTransitionRecord]

  public init(records: [CaptureSessionTransitionRecord] = []) {
    self.records = records
  }

  public mutating func append(_ record: CaptureSessionTransitionRecord) {
    records.append(record)
  }

  public func asDictionary() -> [String: Any] {
    [
      "schema_id": "CaptureSessionTimeline",
      "schema_version": "1.0.0-phase3-fixture",
      "records": records.map { $0.asDictionary() },
    ]
  }
}

/// Checkpoint snapshot for recovery without sample-ID duplication.
public struct CaptureSessionCheckpoint: Sendable, Equatable {
  public let checkpointID: String
  public let state: SpatialCaptureSessionState
  public let acceptedSampleIDs: Set<String>
  public let lastTimestampByStream: [String: UInt64]
  public let bufferState: CaptureBufferState
  public let activationResults: [SensorActivationResult]
  public let timestampNanoseconds: UInt64
  public let clockDomain: ClockDomain

  public init(
    checkpointID: String,
    state: SpatialCaptureSessionState,
    acceptedSampleIDs: Set<String>,
    lastTimestampByStream: [String: UInt64],
    bufferState: CaptureBufferState,
    activationResults: [SensorActivationResult],
    timestampNanoseconds: UInt64,
    clockDomain: ClockDomain
  ) {
    self.checkpointID = checkpointID
    self.state = state
    self.acceptedSampleIDs = acceptedSampleIDs
    self.lastTimestampByStream = lastTimestampByStream
    self.bufferState = bufferState
    self.activationResults = activationResults
    self.timestampNanoseconds = timestampNanoseconds
    self.clockDomain = clockDomain
  }

  public func asDictionary() -> [String: Any] {
    [
      "checkpoint_id": checkpointID,
      "state": state.rawValue,
      "accepted_sample_ids": acceptedSampleIDs.sorted(),
      "last_timestamp_by_stream": lastTimestampByStream,
      "buffer_state": bufferState.asDictionary(),
      "activation_results": activationResults.map { $0.asDictionary() },
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain.rawValue,
    ]
  }
}

/// Metadata carried with every candidate sample for acceptance checks.
public struct SampleAcceptanceContext: Sendable, Equatable {
  public let sampleID: String
  public let streamID: String
  public let acquisitionTimestampNs: UInt64
  public let clockDomain: ClockDomain
  public let frameEpochID: String?
  public let sessionRunID: String?
  public let worldOriginRevision: UInt64?
  public let byteLength: Int

  public init(
    sampleID: String,
    streamID: String,
    acquisitionTimestampNs: UInt64,
    clockDomain: ClockDomain,
    frameEpochID: String? = nil,
    sessionRunID: String? = nil,
    worldOriginRevision: UInt64? = nil,
    byteLength: Int
  ) {
    self.sampleID = sampleID
    self.streamID = streamID
    self.acquisitionTimestampNs = acquisitionTimestampNs
    self.clockDomain = clockDomain
    self.frameEpochID = frameEpochID
    self.sessionRunID = sessionRunID
    self.worldOriginRevision = worldOriginRevision
    self.byteLength = byteLength
  }
}
