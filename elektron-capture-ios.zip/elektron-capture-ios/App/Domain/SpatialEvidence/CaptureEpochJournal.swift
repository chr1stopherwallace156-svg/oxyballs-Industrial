import Foundation

// MARK: - Capture epoch journal (tamper-evident hash chain — NOT a blockchain)

public enum JournalBlockState: String, Codable, Sendable, Equatable {
  case open = "OPEN"
  case flushed = "FLUSHED"
  case committed = "COMMITTED"
  case quarantined = "QUARANTINED"
  case corrupt = "CORRUPT"
}

public struct CaptureEpochBlock: Codable, Sendable, Equatable {
  public var blockID: String
  public var blockSequence: UInt64
  public var captureSessionID: String
  public var previousBlockSHA256: String
  public var payloadEntryDigests: [String]
  public var blockMetadataDigest: String
  public var blockSHA256: String
  public var firstTimestampNanoseconds: UInt64
  public var lastTimestampNanoseconds: UInt64
  public var streamSampleCounts: [String: UInt64]
  public var frameEpochID: String
  public var sessionRunID: String
  public var journalState: JournalBlockState
  public var commitMarker: Bool
  public var byteLength: Int
  public var acceptedSampleIDs: [String]

  public func dictionary() -> [String: Any] {
    [
      "block_id": blockID,
      "block_sequence": blockSequence,
      "capture_session_id": captureSessionID,
      "previous_block_sha256": previousBlockSHA256,
      "payload_entry_digests": payloadEntryDigests,
      "block_metadata_digest": blockMetadataDigest,
      "block_sha256": blockSHA256,
      "first_timestamp": firstTimestampNanoseconds,
      "last_timestamp": lastTimestampNanoseconds,
      "stream_sample_counts": streamSampleCounts,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "journal_state": journalState.rawValue,
      "commit_marker": commitMarker,
      "byte_length": byteLength,
      "accepted_sample_ids": acceptedSampleIDs.sorted(),
    ]
  }

  public static func genesisPreviousHash() -> String {
    String(repeating: "0", count: 64)
  }
}

public struct CaptureEpochJournal: Sendable {
  public let captureSessionID: String
  public private(set) var blocks: [CaptureEpochBlock] = []
  public private(set) var openBlock: CaptureEpochBlock?
  public private(set) var acceptedSampleIDs = Set<String>()
  public var frameEpochID: String
  public var sessionRunID: String

  public init(captureSessionID: String, frameEpochID: String = "epoch-fixture-1", sessionRunID: String = "run-fixture-1") {
    self.captureSessionID = captureSessionID
    self.frameEpochID = frameEpochID
    self.sessionRunID = sessionRunID
  }

  public mutating func append(
    sampleID: String,
    payloadDigest: String,
    streamID: String,
    timestampNanoseconds: UInt64
  ) throws {
    guard !acceptedSampleIDs.contains(sampleID) else {
      throw SpatialEvidenceError.journalDuplicateSampleID(sampleID)
    }
    if openBlock == nil {
      let seq = UInt64(blocks.count)
      if let last = blocks.last, last.blockSequence + 1 != seq {
        throw SpatialEvidenceError.journalSequenceGap(expected: last.blockSequence + 1, actual: seq)
      }
      let prev = blocks.last?.blockSHA256 ?? CaptureEpochBlock.genesisPreviousHash()
      openBlock = CaptureEpochBlock(
        blockID: "BLK-\(captureSessionID)-\(seq)",
        blockSequence: seq,
        captureSessionID: captureSessionID,
        previousBlockSHA256: prev,
        payloadEntryDigests: [],
        blockMetadataDigest: "",
        blockSHA256: "",
        firstTimestampNanoseconds: timestampNanoseconds,
        lastTimestampNanoseconds: timestampNanoseconds,
        streamSampleCounts: [:],
        frameEpochID: frameEpochID,
        sessionRunID: sessionRunID,
        journalState: .open,
        commitMarker: false,
        byteLength: 0,
        acceptedSampleIDs: []
      )
    }
    guard var block = openBlock else { return }
    if block.journalState != .open {
      throw SpatialEvidenceError.journalInvalidState("append_requires_open_block")
    }
    block.payloadEntryDigests.append(payloadDigest)
    block.acceptedSampleIDs.append(sampleID)
    block.streamSampleCounts[streamID, default: 0] += 1
    block.lastTimestampNanoseconds = max(block.lastTimestampNanoseconds, timestampNanoseconds)
    block.firstTimestampNanoseconds = min(block.firstTimestampNanoseconds, timestampNanoseconds)
    block.byteLength += payloadDigest.count
    openBlock = block
    acceptedSampleIDs.insert(sampleID)
  }

  public mutating func flush() throws {
    guard var block = openBlock else { return }
    block.journalState = .flushed
    block.blockMetadataDigest = try Self.metadataDigest(block)
    block.blockSHA256 = try Self.blockDigest(block)
    openBlock = block
  }

  public mutating func commit() throws -> CaptureEpochBlock {
    if openBlock?.journalState == .open {
      try flush()
    }
    guard var block = openBlock else {
      throw SpatialEvidenceError.journalInvalidState("commit_requires_open_or_flushed_block")
    }
    // Validate chain link
    let expectedPrev = blocks.last?.blockSHA256 ?? CaptureEpochBlock.genesisPreviousHash()
    guard block.previousBlockSHA256 == expectedPrev else {
      throw SpatialEvidenceError.journalBrokenChain(block.blockID)
    }
    if let last = blocks.last, block.blockSequence != last.blockSequence + 1 {
      throw SpatialEvidenceError.journalDuplicateOrMissingSequence(block.blockSequence)
    }
    if blocks.contains(where: { $0.blockSequence == block.blockSequence }) {
      throw SpatialEvidenceError.journalDuplicateOrMissingSequence(block.blockSequence)
    }
    block.commitMarker = true
    block.journalState = .committed
    block.blockMetadataDigest = try Self.metadataDigest(block)
    block.blockSHA256 = try Self.blockDigest(block)
    blocks.append(block)
    openBlock = nil
    return block
  }

  public func journalRootSHA256() throws -> String {
    let committed = blocks.filter { $0.journalState == .committed }
    let material = committed.map { $0.blockSHA256 }
    return ContentHasher.sha256Hex(try CanonicalJSON.data(["committed_block_digests": material] as [String: Any]))
  }

  /// Quarantine an incomplete open/flushed tail; remove its sample IDs from the accepted set.
  public mutating func quarantineOpenTail() -> String? {
    guard var open = openBlock else { return nil }
    open.journalState = .quarantined
    for id in open.acceptedSampleIDs {
      acceptedSampleIDs.remove(id)
    }
    let id = open.blockID
    openBlock = open
    return id
  }

  /// Drop quarantined open tail after recovery scan (committed blocks untouched).
  public mutating func clearOpenBlock() {
    openBlock = nil
  }

  /// Replace accepted sample IDs with the recovered committed set (no duplicates on resume).
  public mutating func restoreAcceptedSampleIDs(_ ids: [String]) {
    acceptedSampleIDs = Set(ids)
  }

  /// Test/fixture helper: load previously committed blocks (e.g. truncated/corrupt scenarios).
  public mutating func replaceCommittedBlocks(_ newBlocks: [CaptureEpochBlock]) {
    blocks = newBlocks
    openBlock = nil
    acceptedSampleIDs = Set(newBlocks.flatMap(\.acceptedSampleIDs))
  }

  public mutating func setOpenBlockForRecoverySimulation(_ block: CaptureEpochBlock?) {
    openBlock = block
    if let block {
      for id in block.acceptedSampleIDs {
        acceptedSampleIDs.insert(id)
      }
    }
  }

  public func dictionary() throws -> [String: Any] {
    var d: [String: Any] = [
      "capture_session_id": captureSessionID,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "committed_blocks": blocks.map { $0.dictionary() },
      "journal_root_sha256": try journalRootSHA256(),
      "schema_id": "CaptureEpochJournal",
      "schema_version": "1.0.0-phase3-fixture",
      "note": "Tamper-evident hash chain; not a blockchain",
    ]
    if let openBlock {
      d["open_block"] = openBlock.dictionary()
    }
    return d
  }

  public static func metadataDigest(_ block: CaptureEpochBlock) throws -> String {
    ContentHasher.sha256Hex(try CanonicalJSON.data([
      "block_id": block.blockID,
      "block_sequence": block.blockSequence,
      "capture_session_id": block.captureSessionID,
      "previous_block_sha256": block.previousBlockSHA256,
      "payload_entry_digests": block.payloadEntryDigests,
      "first_timestamp": block.firstTimestampNanoseconds,
      "last_timestamp": block.lastTimestampNanoseconds,
      "stream_sample_counts": block.streamSampleCounts,
      "frame_epoch_id": block.frameEpochID,
      "session_run_id": block.sessionRunID,
      "commit_marker": block.commitMarker,
      "accepted_sample_ids": block.acceptedSampleIDs.sorted(),
    ] as [String: Any]))
  }

  public static func blockDigest(_ block: CaptureEpochBlock) throws -> String {
    ContentHasher.sha256Hex(try CanonicalJSON.data([
      "previous_block_sha256": block.previousBlockSHA256,
      "block_metadata_digest": block.blockMetadataDigest,
      "payload_entry_digests": block.payloadEntryDigests,
      "block_sequence": block.blockSequence,
    ] as [String: Any]))
  }
}

// MARK: - Recovery

public enum RecoveryDisposition: String, Codable, Sendable, Equatable {
  case cleanRecovery = "CLEAN_RECOVERY"
  case recoveredToLastCommittedBlock = "RECOVERED_TO_LAST_COMMITTED_BLOCK"
  case incompleteTailQuarantined = "INCOMPLETE_TAIL_QUARANTINED"
  case hashChainBroken = "HASH_CHAIN_BROKEN"
  case journalCorrupt = "JOURNAL_CORRUPT"
  case nonResumable = "NON_RESUMABLE"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public enum IncompleteEpochDisposition: String, Codable, Sendable, Equatable {
  case quarantined = "QUARANTINED"
  case discarded = "DISCARDED"
  case none = "NONE"
}

public struct JournalCorruptionRecord: Codable, Sendable, Equatable {
  public var corruptionID: String
  public var reason: String
  public var blockID: String?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = ["corruption_id": corruptionID, "reason": reason]
    if let blockID { d["block_id"] = blockID }
    return d
  }
}

public struct JournalCommitRecord: Codable, Sendable, Equatable {
  public var commitID: String
  public var blockID: String
  public var blockSHA256: String
  public var committedAtNanoseconds: UInt64

  public func dictionary() -> [String: Any] {
    [
      "commit_id": commitID,
      "block_id": blockID,
      "block_sha256": blockSHA256,
      "committed_at_nanoseconds": committedAtNanoseconds,
    ]
  }
}

public struct RecoveredSessionState: Codable, Sendable, Equatable {
  public var captureSessionID: String
  public var disposition: RecoveryDisposition
  public var lastCommittedSequence: UInt64?
  public var acceptedSampleIDs: [String]
  public var quarantinedBlockIDs: [String]
  public var journalRootSHA256: String
  public var incompleteEpochDisposition: IncompleteEpochDisposition
  public var corruptionRecords: [JournalCorruptionRecord]

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "capture_session_id": captureSessionID,
      "disposition": disposition.rawValue,
      "accepted_sample_ids": acceptedSampleIDs.sorted(),
      "quarantined_block_ids": quarantinedBlockIDs.sorted(),
      "journal_root_sha256": journalRootSHA256,
      "incomplete_epoch_disposition": incompleteEpochDisposition.rawValue,
      "corruption_records": corruptionRecords.map { $0.dictionary() },
      "schema_id": "RecoveredSessionState",
      "schema_version": "1.0.0-phase3-fixture",
    ]
    if let lastCommittedSequence {
      d["last_committed_sequence"] = lastCommittedSequence
    }
    return d
  }
}

public struct JournalRecoveryScanner: Sendable {
  public init() {}

  public func scan(journal: CaptureEpochJournal) throws -> RecoveredSessionState {
    var working = journal
    var corruptions: [JournalCorruptionRecord] = []
    var quarantined: [String] = []

    // Validate committed chain
    var prev = CaptureEpochBlock.genesisPreviousHash()
    var expectedSeq: UInt64 = 0
    var seenSeq = Set<UInt64>()
    for block in working.blocks {
      if seenSeq.contains(block.blockSequence) {
        return RecoveredSessionState(
          captureSessionID: journal.captureSessionID,
          disposition: .journalCorrupt,
          lastCommittedSequence: nil,
          acceptedSampleIDs: [],
          quarantinedBlockIDs: [],
          journalRootSHA256: "",
          incompleteEpochDisposition: .none,
          corruptionRecords: [
            JournalCorruptionRecord(corruptionID: "CORR-DUP-SEQ", reason: "duplicate_sequence", blockID: block.blockID),
          ]
        )
      }
      seenSeq.insert(block.blockSequence)
      if block.blockSequence != expectedSeq {
        return RecoveredSessionState(
          captureSessionID: journal.captureSessionID,
          disposition: .journalCorrupt,
          lastCommittedSequence: nil,
          acceptedSampleIDs: [],
          quarantinedBlockIDs: [],
          journalRootSHA256: "",
          incompleteEpochDisposition: .none,
          corruptionRecords: [
            JournalCorruptionRecord(corruptionID: "CORR-GAP", reason: "missing_sequence", blockID: block.blockID),
          ]
        )
      }
      if block.previousBlockSHA256 != prev {
        return RecoveredSessionState(
          captureSessionID: journal.captureSessionID,
          disposition: .hashChainBroken,
          lastCommittedSequence: expectedSeq == 0 ? nil : expectedSeq - 1,
          acceptedSampleIDs: [],
          quarantinedBlockIDs: [],
          journalRootSHA256: "",
          incompleteEpochDisposition: .none,
          corruptionRecords: [
            JournalCorruptionRecord(corruptionID: "CORR-CHAIN", reason: "incorrect_previous_block_hash", blockID: block.blockID),
          ]
        )
      }
      let recomputedMeta = try CaptureEpochJournal.metadataDigest(block)
      let recomputed = try CaptureEpochJournal.blockDigest(
        CaptureEpochBlock(
          blockID: block.blockID,
          blockSequence: block.blockSequence,
          captureSessionID: block.captureSessionID,
          previousBlockSHA256: block.previousBlockSHA256,
          payloadEntryDigests: block.payloadEntryDigests,
          blockMetadataDigest: recomputedMeta,
          blockSHA256: "",
          firstTimestampNanoseconds: block.firstTimestampNanoseconds,
          lastTimestampNanoseconds: block.lastTimestampNanoseconds,
          streamSampleCounts: block.streamSampleCounts,
          frameEpochID: block.frameEpochID,
          sessionRunID: block.sessionRunID,
          journalState: block.journalState,
          commitMarker: block.commitMarker,
          byteLength: block.byteLength,
          acceptedSampleIDs: block.acceptedSampleIDs
        )
      )
      // Use stored metadata digest for verification of tampering of prior content
      let storedBlockDigest = try CaptureEpochJournal.blockDigest(block)
      if block.blockMetadataDigest != recomputedMeta || block.blockSHA256 != storedBlockDigest {
        return RecoveredSessionState(
          captureSessionID: journal.captureSessionID,
          disposition: .hashChainBroken,
          lastCommittedSequence: expectedSeq == 0 ? nil : expectedSeq - 1,
          acceptedSampleIDs: [],
          quarantinedBlockIDs: [block.blockID],
          journalRootSHA256: "",
          incompleteEpochDisposition: .none,
          corruptionRecords: [
            JournalCorruptionRecord(corruptionID: "CORR-MUTATED", reason: "modified_prior_block", blockID: block.blockID),
          ]
        )
      }
      _ = recomputed
      prev = block.blockSHA256
      expectedSeq += 1
    }

    var incomplete: IncompleteEpochDisposition = .none
    var disposition: RecoveryDisposition = .cleanRecovery

    if working.openBlock != nil {
      // Incomplete tail: open or flushed without commit — quarantine, never accept as evidence.
      if let qid = working.quarantineOpenTail() {
        quarantined.append(qid)
        corruptions.append(
          JournalCorruptionRecord(corruptionID: "CORR-TAIL", reason: "uncommitted_tail_quarantined", blockID: qid)
        )
      }
      incomplete = .quarantined
      disposition = .incompleteTailQuarantined
    }

    if disposition == .cleanRecovery, !working.blocks.isEmpty {
      disposition = .recoveredToLastCommittedBlock
    }

    let root = try working.journalRootSHA256()
    let ids = working.blocks.flatMap(\.acceptedSampleIDs)
    return RecoveredSessionState(
      captureSessionID: journal.captureSessionID,
      disposition: disposition == .incompleteTailQuarantined
        ? .incompleteTailQuarantined
        : (working.blocks.isEmpty ? .cleanRecovery : .recoveredToLastCommittedBlock),
      lastCommittedSequence: working.blocks.last?.blockSequence,
      acceptedSampleIDs: ids,
      quarantinedBlockIDs: quarantined,
      journalRootSHA256: root,
      incompleteEpochDisposition: incomplete,
      corruptionRecords: corruptions
    )
  }

  /// Resume journal after recovery — only committed samples remain accepted.
  public func resumeJournal(from journal: CaptureEpochJournal, recovered: RecoveredSessionState) throws -> CaptureEpochJournal {
    guard recovered.disposition != .hashChainBroken,
          recovered.disposition != .journalCorrupt,
          recovered.disposition != .nonResumable
    else {
      throw SpatialEvidenceError.journalNonResumable(recovered.disposition.rawValue)
    }
    var resumed = journal
    if let open = resumed.openBlock, recovered.quarantinedBlockIDs.contains(open.blockID) {
      resumed.clearOpenBlock()
    } else if resumed.openBlock != nil {
      resumed.clearOpenBlock()
    }
    resumed.restoreAcceptedSampleIDs(recovered.acceptedSampleIDs)
    return resumed
  }
}

/// Simple WAL marker store for commit records.
public struct CaptureWriteAheadLog: Sendable {
  public private(set) var commits: [JournalCommitRecord] = []

  public init() {}

  public mutating func recordCommit(block: CaptureEpochBlock, at timestamp: UInt64) {
    commits.append(
      JournalCommitRecord(
        commitID: "COMMIT-\(block.blockID)",
        blockID: block.blockID,
        blockSHA256: block.blockSHA256,
        committedAtNanoseconds: timestamp
      )
    )
  }
}
