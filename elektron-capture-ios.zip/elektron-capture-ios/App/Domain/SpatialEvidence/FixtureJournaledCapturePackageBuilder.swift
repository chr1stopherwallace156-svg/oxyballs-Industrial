import Foundation

/// Sprint 3.7 journaled + resilient fixture packages.
///
/// Authority remains TEST_FIXTURE. Fixture signatures are NOT hardware Secure Enclave signatures.
/// No SPKG-DEVICE-* / DEVICE_REPORTED / physical attestation claims.
public struct FixtureJournaledCapturePackageBuilder: Sendable {
  public static let journaledPackageID = "SPKG-FIXTURE-JOURNALED-CAPTURE-000001"
  public static let journaledSessionID = "SESS-FIXTURE-JOURNALED-CAPTURE-000001"
  public static let resilientPackageID = "SPKG-FIXTURE-RESILIENT-CAPTURE-000001"
  public static let resilientSessionID = "SESS-FIXTURE-RESILIENT-CAPTURE-000001"
  public static let frameEpochID = "epoch-fixture-1"
  public static let sessionRunID = "run-fixture-1"

  public init() {}

  public struct SealResult: Sendable {
    public var package: SpatialEvidencePackage
    public var journal: CaptureEpochJournal
    public var journalRootSHA256: String
    public var recovery: RecoveredSessionState?
    public var signature: PackageSignatureEnvelope
    public var enrollment: DeviceKeyEnrollmentRecord
    public var verification: SignatureVerificationResult
    public var attestation: AppAttestVerificationResult?
    public var degradation: RuntimeDegradationRecord?
    public var telemetry: SensorPerformanceTelemetry?
    public var wal: CaptureWriteAheadLog
  }

  // MARK: - Scenario helpers

  public enum JournalScenario: String, Sendable {
    case complete
    case powerLossBeforePayload
    case powerLossAfterPayloadBeforeCommit
    case powerLossAfterCommit
    case truncatedFinalBlock
    case modifiedPriorBlock
    case incorrectPreviousHash
    case duplicateSequence
    case missingSequence
    case recoveredContinuation
    case cancellationUnsealed
  }

  public func buildJournal(
    scenario: JournalScenario,
    sessionID: String = FixtureJournaledCapturePackageBuilder.journaledSessionID
  ) throws -> (CaptureEpochJournal, CaptureWriteAheadLog, RecoveredSessionState?) {
    var journal = CaptureEpochJournal(
      captureSessionID: sessionID,
      frameEpochID: Self.frameEpochID,
      sessionRunID: Self.sessionRunID
    )
    var wal = CaptureWriteAheadLog()
    let scanner = JournalRecoveryScanner()

    switch scenario {
    case .complete:
      try appendAndCommit(&journal, &wal, samples: [
        ("cam-0001", "cam", 1_000),
        ("mot-0001", "mot", 1_100),
      ])
      try appendAndCommit(&journal, &wal, samples: [
        ("cam-0002", "cam", 2_000),
        ("mot-0002", "mot", 2_100),
      ])
      return (journal, wal, try scanner.scan(journal: journal))

    case .powerLossBeforePayload:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      // Abrupt stop with no open payload — clean committed state.
      return (journal, wal, try scanner.scan(journal: journal))

    case .powerLossAfterPayloadBeforeCommit:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      try journal.append(sampleID: "cam-0002", payloadDigest: digest("cam-0002"), streamID: "cam", timestampNanoseconds: 2_000)
      try journal.flush()
      let recovered = try scanner.scan(journal: journal)
      return (journal, wal, recovered)

    case .powerLossAfterCommit:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      try appendAndCommit(&journal, &wal, samples: [("cam-0002", "cam", 2_000)])
      return (journal, wal, try scanner.scan(journal: journal))

    case .truncatedFinalBlock:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      try journal.append(sampleID: "cam-trunc", payloadDigest: digest("cam-trunc"), streamID: "cam", timestampNanoseconds: 3_000)
      // Simulate truncation: leave open without flush/commit.
      let recovered = try scanner.scan(journal: journal)
      return (journal, wal, recovered)

    case .modifiedPriorBlock:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      try appendAndCommit(&journal, &wal, samples: [("cam-0002", "cam", 2_000)])
      var blocks = journal.blocks
      blocks[0].payloadEntryDigests.append("mutated-digest")
      journal.replaceCommittedBlocks(blocks)
      return (journal, wal, try scanner.scan(journal: journal))

    case .incorrectPreviousHash:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      try appendAndCommit(&journal, &wal, samples: [("cam-0002", "cam", 2_000)])
      var blocks = journal.blocks
      blocks[1].previousBlockSHA256 = String(repeating: "a", count: 64)
      journal.replaceCommittedBlocks(blocks)
      return (journal, wal, try scanner.scan(journal: journal))

    case .duplicateSequence:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      try appendAndCommit(&journal, &wal, samples: [("cam-0002", "cam", 2_000)])
      var blocks = journal.blocks
      var dup = blocks[1]
      dup.blockID = "BLK-DUP"
      dup.blockSequence = 0
      blocks.append(dup)
      journal.replaceCommittedBlocks(blocks)
      return (journal, wal, try scanner.scan(journal: journal))

    case .missingSequence:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      try appendAndCommit(&journal, &wal, samples: [("cam-0002", "cam", 2_000)])
      var blocks = journal.blocks
      blocks[1].blockSequence = 5
      journal.replaceCommittedBlocks(blocks)
      return (journal, wal, try scanner.scan(journal: journal))

    case .recoveredContinuation:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      try journal.append(sampleID: "cam-open", payloadDigest: digest("cam-open"), streamID: "cam", timestampNanoseconds: 1_500)
      let recovered = try scanner.scan(journal: journal)
      var resumed = try scanner.resumeJournal(from: journal, recovered: recovered)
      // Resume must not accept duplicate committed IDs.
      try resumed.append(sampleID: "cam-0002", payloadDigest: digest("cam-0002"), streamID: "cam", timestampNanoseconds: 2_000)
      let block = try resumed.commit()
      wal.recordCommit(block: block, at: 2_000)
      journal = resumed
      return (journal, wal, try scanner.scan(journal: journal))

    case .cancellationUnsealed:
      try appendAndCommit(&journal, &wal, samples: [("cam-0001", "cam", 1_000)])
      try journal.append(sampleID: "cam-cancel", payloadDigest: digest("cam-cancel"), streamID: "cam", timestampNanoseconds: 2_000)
      // Caller must not seal — recovery still quarantines.
      return (journal, wal, try scanner.scan(journal: journal))
    }
  }

  /// Primary journaled package: interrupted then recovered; only committed evidence sealed.
  public func sealJournaledPrimary(outputDirectory: URL) throws -> SealResult {
    let (pre, walPre, recoveredPre) = try buildJournal(scenario: .powerLossAfterPayloadBeforeCommit)
    let recovered = try XCTUnwrapCompat(recoveredPre)
    let scanner = JournalRecoveryScanner()
    var journal = try scanner.resumeJournal(from: pre, recovered: recovered)
    var wal = walPre
    try journal.append(sampleID: "cam-resume-0001", payloadDigest: digest("cam-resume-0001"), streamID: "cam", timestampNanoseconds: 3_000)
    try journal.append(sampleID: "mot-resume-0001", payloadDigest: digest("mot-resume-0001"), streamID: "mot", timestampNanoseconds: 3_100)
    let committed = try journal.commit()
    wal.recordCommit(block: committed, at: 3_100)
    let finalRecovery = try scanner.scan(journal: journal)
    return try sealPackage(
      packageID: Self.journaledPackageID,
      sessionID: Self.journaledSessionID,
      journal: journal,
      wal: wal,
      recovery: finalRecovery,
      outputDirectory: outputDirectory,
      layout: "fixture_journaled_capture_v1",
      includeThermal: false
    )
  }

  /// Resilient package: thermal throttle → crash → recover → sign → seal.
  public func sealResilientPrimary(outputDirectory: URL) throws -> SealResult {
    var journal = CaptureEpochJournal(
      captureSessionID: Self.resilientSessionID,
      frameEpochID: Self.frameEpochID,
      sessionRunID: Self.sessionRunID
    )
    var wal = CaptureWriteAheadLog()
    var policy = AdaptiveCapturePolicy()
    var decisions: [AdaptivePolicyDecision] = []

    // 1–2 begin + commit
    try appendAndCommit(&journal, &wal, samples: [
      ("cam-r-0001", "cam", 1_000),
      ("mot-r-0001", "mot", 1_050),
    ])

    // 3–6 depth load + thermal rise → quality then depth throttle
    let d1 = try policy.evaluate(
      RuntimeResourceState(
        thermal: .fair,
        memory: .normal,
        storage: .normal,
        optionalDepthLoad: 0.8,
        timestampNanoseconds: 1_200
      )
    )
    decisions.append(d1)
    let d2 = try policy.evaluate(
      RuntimeResourceState(
        thermal: .serious,
        memory: .warning,
        storage: .normal,
        optionalDepthLoad: 0.9,
        timestampNanoseconds: 1_400
      )
    )
    decisions.append(d2)

    // 7 required camera/motion continue
    try appendAndCommit(&journal, &wal, samples: [
      ("cam-r-0002", "cam", 2_000),
      ("mot-r-0002", "mot", 2_050),
    ])

    // 8 terminate after committed block during incomplete block
    try journal.append(sampleID: "cam-r-incomplete", payloadDigest: digest("cam-r-incomplete"), streamID: "cam", timestampNanoseconds: 2_500)
    try journal.flush()

    // 9 recover / quarantine
    let scanner = JournalRecoveryScanner()
    let recovered = try scanner.scan(journal: journal)
    journal = try scanner.resumeJournal(from: journal, recovered: recovered)

    // 10 resume without duplicate sample IDs
    try journal.append(sampleID: "cam-r-0003", payloadDigest: digest("cam-r-0003"), streamID: "cam", timestampNanoseconds: 3_000)
    try journal.append(sampleID: "mot-r-0003", payloadDigest: digest("mot-r-0003"), streamID: "mot", timestampNanoseconds: 3_050)
    let block = try journal.commit()
    wal.recordCommit(block: block, at: 3_050)

    let telemetry = SensorPerformanceTelemetry(
      incomingSampleRate: 60,
      acceptedSampleRate: 55,
      droppedSampleCount: 2,
      queueDepth: 3,
      queuedBytes: 4096,
      memoryPressure: .warning,
      storagePressure: .normal,
      thermalState: .serious,
      analysisLatencyMs: 12.5,
      packageWriteLatencyMs: 40,
      bufferRecords: [
        BufferLifecycleRecord(
          recordID: "BUF-0001",
          sampleID: "cam-r-0001",
          bufferOrigin: "fixture_camera_pool",
          pixelFormat: "fixture_rgb8",
          queuedBytes: 1024,
          queueDepth: 1
        ),
      ],
      copyRecords: [
        CopyAndConversionRecord(
          recordID: "COPY-0001",
          sampleID: "cam-r-0001",
          conversionOperations: ["fixture_rgb8_to_canonical"],
          estimatedCopyCount: 1,
          note: "copy_minimization; not zero-copy claim"
        ),
      ],
      encoderRecords: [
        EncoderPathRecord(recordID: "ENC-0001", sampleID: "cam-r-0001", encodingPath: "fixture_passthrough"),
      ],
      dropRecords: [
        FrameDropRecord(recordID: "DROP-0001", streamID: "depth", droppedCount: 2, reason: "thermal_throttle"),
      ]
    )

    let degradation = RuntimeDegradationRecord(recordID: "DEG-\(Self.resilientPackageID)", decisions: decisions)
    let finalRecovery = try scanner.scan(journal: journal)

    return try sealPackage(
      packageID: Self.resilientPackageID,
      sessionID: Self.resilientSessionID,
      journal: journal,
      wal: wal,
      recovery: finalRecovery,
      outputDirectory: outputDirectory,
      layout: "fixture_resilient_capture_v1",
      includeThermal: true,
      degradation: degradation,
      telemetry: telemetry,
      policy: policy
    )
  }

  // MARK: - Seal

  private func sealPackage(
    packageID: String,
    sessionID: String,
    journal: CaptureEpochJournal,
    wal: CaptureWriteAheadLog,
    recovery: RecoveredSessionState,
    outputDirectory: URL,
    layout: String,
    includeThermal: Bool,
    degradation: RuntimeDegradationRecord? = nil,
    telemetry: SensorPerformanceTelemetry? = nil,
    policy: AdaptiveCapturePolicy? = nil
  ) throws -> SealResult {
    let fm = FileManager.default
    try fm.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
    try fm.createDirectory(at: outputDirectory.appendingPathComponent("artifacts", isDirectory: true), withIntermediateDirectories: true)

    let journalRoot = try journal.journalRootSHA256()
    let enrollment = DeviceKeyEnrollmentRecord.fixtureEnrolled()

    // Minimal evidence payload — deterministic bytes bound into inventory.
    let payload = try CanonicalJSON.data([
      "accepted_sample_ids": Array(journal.acceptedSampleIDs).sorted(),
      "note": "Sprint 3.7 fixture evidence payload; TEST_FIXTURE authority",
    ] as [String: Any])
    let payloadRel = "artifacts/evidence/payload.json"
    let payloadURL = outputDirectory.appendingPathComponent(payloadRel)
    try fm.createDirectory(at: payloadURL.deletingLastPathComponent(), withIntermediateDirectories: true)
    try payload.write(to: payloadURL, options: .atomic)

    try writeJSON(try journal.dictionary(), to: outputDirectory.appendingPathComponent("capture_epoch_journal.json"))
    try writeJSON(
      [
        "journal_root_sha256": journalRoot,
        "binding": "package_closure",
        "note": "Committed journal root bound into package identity",
      ],
      to: outputDirectory.appendingPathComponent("journal_root_binding.json")
    )
    try writeJSON(recovery.dictionary(), to: outputDirectory.appendingPathComponent("recovery_state.json"))
    try writeJSON(
      ["commits": wal.commits.map { $0.dictionary() }],
      to: outputDirectory.appendingPathComponent("write_ahead_log.json")
    )
    try writeJSON(enrollment.dictionary(), to: outputDirectory.appendingPathComponent("enrollment_record.json"))

    if includeThermal, let degradation, let telemetry, let policy {
      try writeJSON(degradation.dictionary(), to: outputDirectory.appendingPathComponent("runtime_degradation.json"))
      try writeJSON(telemetry.dictionary(), to: outputDirectory.appendingPathComponent("performance_telemetry.json"))
      try writeJSON(
        [
          "camera_rate_hz": policy.cameraRateHz,
          "motion_rate_hz": policy.motionRateHz,
          "depth_rate_hz": policy.depthRateHz,
          "quality_analysis_rate_hz": policy.qualityAnalysisRateHz,
          "preview_rate_hz": policy.previewRateHz,
          "required_streams_protected": true,
        ],
        to: outputDirectory.appendingPathComponent("adaptive_policy_snapshot.json")
      )
    }

    // App attest fixture (portable server verification — not hardware).
    let challenge = AppAttestChallenge(
      challengeID: "CHAL-\(packageID)",
      serverNonce: "nonce-fixture-\(packageID)",
      issuedAtUTC: "2026-08-03T00:00:00Z",
      expiresAtUTC: "2026-08-03T01:00:00Z",
      appIdentifier: enrollment.appIdentifier
    )
    // Placeholder closure for assertion binding; replaced after inventory hash.
    var provisionalClosure = String(repeating: "0", count: 64)

    let frames = [
      CoordinateFrameDescriptor(
        frameID: "FRAME_CAPTURE_SESSION_ROOT",
        units: "meters",
        handedness: "right",
        matrixStorageOrder: "column_major",
        opticalAxisConvention: "opencv",
        clockDomain: .fixtureCamera,
        authority: "TEST_FIXTURE"
      ),
    ]
    var camCap = SpatialStreamCapability(
      streamID: SpatialStreamID.camera,
      adapterID: "fixture.camera.journaled",
      sensorKind: "camera",
      declared: true
    )
    camCap.activate()
    camCap.recordSample()
    try camCap.freeze(outcome: .acquired)
    var motCap = SpatialStreamCapability(
      streamID: SpatialStreamID.motion,
      adapterID: "fixture.motion.journaled",
      sensorKind: "motion",
      declared: true
    )
    motCap.activate()
    motCap.recordSample()
    try motCap.freeze(outcome: .acquired)
    var poseCap = SpatialStreamCapability(
      streamID: SpatialStreamID.pose,
      adapterID: "none",
      sensorKind: "pose",
      declared: false
    )
    try poseCap.freeze(outcome: .notRequested)
    var depthCap = SpatialStreamCapability(
      streamID: SpatialStreamID.depth,
      adapterID: includeThermal ? "fixture.depth.optional" : "none",
      sensorKind: "depth",
      declared: includeThermal
    )
    if includeThermal {
      depthCap.activate()
      depthCap.recordSample()
      try depthCap.freeze(outcome: .acquired)
    } else {
      try depthCap.freeze(outcome: .notRequested)
    }

    let capability = SpatialCapabilitySnapshot(
      snapshotID: "CAP-\(packageID)",
      capturedAtUTC: "2026-08-03T00:00:00Z",
      streams: [camCap, motCap, poseCap, depthCap],
      schemaVersion: SpatialCapabilitySnapshot.fixtureSchemaVersion
    )

    let artifact = SpatialArtifactDescriptor(
      relativePath: payloadRel,
      byteLength: payload.count,
      sha256: ContentHasher.sha256Hex(payload),
      mediaType: "application/json",
      schemaID: "FixtureEvidencePayload",
      schemaVersion: "1.0.0-phase3-fixture",
      sampleID: Array(journal.acceptedSampleIDs).sorted().first ?? "none",
      streamID: SpatialStreamID.camera,
      adapterID: camCap.adapterID
    )

    let manifest = SpatialEvidenceManifest(
      packageID: packageID,
      vehicleID: "VEH-000001",
      captureSessionID: sessionID,
      pilotID: "PILOT-000001",
      createdAtUTC: "2026-08-03T00:00:00Z",
      capability: capability,
      frames: frames,
      clockCorrelations: [],
      artifacts: [artifact],
      sampleIndex: [
        [
          "sample_id": artifact.sampleID,
          "relative_path": payloadRel,
          "stream_id": SpatialStreamID.camera,
          "adapter_id": camCap.adapterID,
        ],
      ]
    )
    var manifestDict = manifest.asDictionary()
    manifestDict["schema_id"] = "SpatialEvidenceManifest"
    manifestDict["schema_version"] = "1.0.0-phase3-fixture"
    manifestDict["package_layout"] = layout
    manifestDict["host_claim"] = "NO_PHYSICAL_DEVICE_EXECUTION"
    manifestDict["implementation_state"] = "SOURCE_IMPLEMENTED"
    manifestDict["validation_state"] = "LINUX_FIXTURE_VALIDATED"
    manifestDict["evidence_origin_authority"] = EvidenceAuthority.testFixture.rawValue
    manifestDict["journal_root_sha256"] = journalRoot
    manifestDict["frame_epoch_id"] = Self.frameEpochID
    manifestDict["session_run_id"] = Self.sessionRunID
    manifestDict["security_claim"] = "NO_HARDWARE_ATTESTATION_CLAIM_UNTIL_PHYSICAL_EXECUTION"
    manifestDict["note"] = "Fixture signatures and App Attest envelopes are not hardware claims"

    let manifestData = try CanonicalJSON.data(manifestDict)
    try manifestData.write(to: outputDirectory.appendingPathComponent("manifest.json"), options: .atomic)
    let manifestSHA = ContentHasher.sha256Hex(manifestData)

    // Inventory + closure (signature written after hash so signature is outside closure, or include after?)
    // Spec: package receives fixture signature; closure passes. Signature file is part of package but
    // binding uses package_closure_sha256 of inventory WITHOUT the signature file first, then signature
    // references that digest. Signature file is added AFTER inventory closure of evidence files,
    // then a second inventory includes signature — OR signature binds pre-signature closure.
    // Follow: compute closure over all files except signature/attestation envelopes, sign that,
    // then write signature + final inventory including signature (with fixture_package_closure_sha256
    // still the evidence closure digest).
    let preSigEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputDirectory)
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(packageRoot: outputDirectory, entries: preSigEntries)
    let packageClosureHash = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: preSigEntries)
    provisionalClosure = packageClosureHash

    let signer = FixturePackageSigner()
    let signature = try signer.sign(
      packageID: packageID,
      captureSessionID: sessionID,
      packageClosureSHA256: packageClosureHash,
      manifestSHA256: manifestSHA,
      enrollment: enrollment
    )
    try writeJSON(signature.dictionary(), to: outputDirectory.appendingPathComponent("package_signature.json"))

    let assertion = try FixtureAppAttestClient().makeAssertion(
      challenge: challenge,
      packageClosureSHA256: provisionalClosure,
      captureSessionID: sessionID,
      enrollment: enrollment
    )
    var verifier = AppAttestServerVerifier(nowUTC: "2026-08-03T00:30:00Z")
    let attestResult = verifier.verify(
      challenge: challenge,
      assertion: assertion,
      expectedClosure: packageClosureHash,
      expectedSessionID: sessionID,
      enrollment: enrollment
    )
    try writeJSON(challenge.dictionary(), to: outputDirectory.appendingPathComponent("app_attest_challenge.json"))
    try writeJSON(assertion.dictionary(), to: outputDirectory.appendingPathComponent("app_attest_assertion.json"))
    try writeJSON(attestResult.dictionary(), to: outputDirectory.appendingPathComponent("app_attest_verification.json"))

    let (sigResult, _) = try PackageSignatureVerifier().verify(
      envelope: signature,
      expectedClosure: packageClosureHash,
      expectedManifest: manifestSHA
    )

    let finalEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputDirectory)
    // Final inventory records evidence closure digest (pre-signature) as fixture_package_closure_sha256
    // and lists all files including signature artifacts.
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0",
      "package_id": packageID,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
      "fixture_package_closure_sha256": packageClosureHash,
      "journal_root_sha256": journalRoot,
      "signature_verification_result": sigResult.rawValue,
      "enrollment_record_id": enrollment.enrollmentRecordID,
      "attestation_disposition": attestResult.disposition.rawValue,
      "entries": finalEntries,
      "note": "fixture_package_closure_sha256 covers pre-signature evidence inventory; signature binds that digest",
    ]
    try writeJSON(inventory, to: outputDirectory.appendingPathComponent("package_inventory.json"))

    // Completeness for final disk (inventory file excluded from entries check of itself).
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(packageRoot: outputDirectory, entries: finalEntries)

    let packageHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outputDirectory)

    let package = SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: manifestSHA,
      packageClosureSHA256: packageClosureHash
    )

    return SealResult(
      package: package,
      journal: journal,
      journalRootSHA256: journalRoot,
      recovery: recovery,
      signature: signature,
      enrollment: enrollment,
      verification: sigResult,
      attestation: attestResult,
      degradation: degradation,
      telemetry: telemetry,
      wal: wal
    )
  }

  private func appendAndCommit(
    _ journal: inout CaptureEpochJournal,
    _ wal: inout CaptureWriteAheadLog,
    samples: [(String, String, UInt64)]
  ) throws {
    for s in samples {
      try journal.append(sampleID: s.0, payloadDigest: digest(s.0), streamID: s.1, timestampNanoseconds: s.2)
    }
    let block = try journal.commit()
    wal.recordCommit(block: block, at: samples.last?.2 ?? 0)
  }

  private func digest(_ id: String) -> String {
    ContentHasher.sha256Hex(Data(id.utf8))
  }

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    let data = try CanonicalJSON.data(object)
    try data.write(to: url, options: .atomic)
  }
}

/// Local unwrap without XCTest dependency in production code.
private func XCTUnwrapCompat<T>(_ value: T?) throws -> T {
  guard let value else {
    throw SpatialEvidenceError.validationFailed("expected non-nil recovery state")
  }
  return value
}
