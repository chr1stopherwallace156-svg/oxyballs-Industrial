import Foundation

/// Production camera adapter contract (Foundation-portable).
/// AVFoundation imports belong only in Apple implementation files.
public protocol CameraSensorAdapter: Sendable {
  var capability: SpatialStreamCapability { get }
  var adapterID: String { get }
  func start() async throws
  func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<CameraSample>, Error>
  func stop() async
}

/// Production motion adapter contract (Foundation-portable).
/// CoreMotion imports belong only in Apple implementation files.
public protocol MotionSensorAdapter: Sendable {
  var capability: SpatialStreamCapability { get }
  var adapterID: String { get }
  func start() async throws
  func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<MotionSample>, Error>
  func stop() async
}

/// Production pose adapter contract (Foundation-portable).
/// ARKit imports belong only in Apple implementation files.
public protocol PoseSensorAdapter: Sendable {
  var capability: SpatialStreamCapability { get }
  var adapterID: String { get }
  func start() async throws
  func samples() -> AsyncThrowingStream<SpatialSampleEnvelope<PoseSample>, Error>
  func stop() async
}

// DepthSensorAdapter is declared in DepthDomainContracts.swift (Sprint 3.3).

public enum ProductionSensorError: Error, Equatable, Sendable {
  case permissionDenied(String)
  case unavailable(String)
  case alreadyStarted
  case notStarted
  case stopped
  case interrupted(String)
  case cancelled
  case backgrounded
  case timestampRegression(previous: UInt64, next: UInt64)
  case unknownPixelFormat(String)
  case postStopSample
  case partialStartup(failed: String)
  case poseTrackingFailed(String)
  case poseRelocalizationRequired
  case depthUnavailableDevice(String)
  case depthUnavailableConfiguration(String)
  case depthActivationFailed(String)
}
