import Foundation

/// Directed transform edge between coordinate frames (COORDINATE_FRAME_STANDARD).
/// Canonical Sprint 3.2 fields bind epoch identity and source sample provenance.
public struct TransformEdge: Sendable, Equatable {
  public let transformID: String
  public let fromFrameID: String
  public let toFrameID: String
  public let frameEpochID: String
  public let sessionRunID: String
  public let worldOriginRevision: UInt64
  public let timestampNanoseconds: UInt64
  public let clockDomain: ClockDomain
  public let matrix: [Double]
  public let units: String
  public let handedness: String
  public let authority: String
  public let sourceSampleID: String

  public static let fixtureStaticSourceSampleID = "FIXTURE_STATIC_TRANSFORM"

  public init(
    transformID: String,
    fromFrameID: String,
    toFrameID: String,
    frameEpochID: String = "epoch-fixture-1",
    sessionRunID: String = "run-fixture-1",
    worldOriginRevision: UInt64 = 1,
    timestampNanoseconds: UInt64,
    clockDomain: ClockDomain,
    matrix: [Double],
    units: String = "meters",
    handedness: String = "right",
    authority: String = "GUIDANCE_ESTIMATE",
    sourceSampleID: String = TransformEdge.fixtureStaticSourceSampleID
  ) {
    precondition(matrix.count == 16, "transform matrix must have 16 elements")
    self.transformID = transformID
    self.fromFrameID = fromFrameID
    self.toFrameID = toFrameID
    self.frameEpochID = frameEpochID
    self.sessionRunID = sessionRunID
    self.worldOriginRevision = worldOriginRevision
    self.timestampNanoseconds = timestampNanoseconds
    self.clockDomain = clockDomain
    self.matrix = matrix
    self.units = units
    self.handedness = handedness
    self.authority = authority
    self.sourceSampleID = sourceSampleID
  }

  public func asDictionary() -> [String: Any] {
    [
      "transform_id": transformID,
      "from_frame_id": fromFrameID,
      "to_frame_id": toFrameID,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain.rawValue,
      "matrix": matrix,
      "units": units,
      "handedness": handedness,
      "authority": authority,
      "source_sample_id": sourceSampleID,
    ]
  }
}

/// Validates quaternion magnitude / finiteness and 4×4 transform finiteness.
public enum PoseMathValidator {
  public static func validateQuaternion(_ q: QuaternionD) throws {
    _ = try q.validated()
  }

  public static func validateTransformMatrix(_ matrix: [Double]) throws {
    guard matrix.count == 16 else {
      throw SpatialEvidenceError.nanOrInfiniteTransform("matrix_length_\(matrix.count)")
    }
    for (i, v) in matrix.enumerated() {
      guard v.isFinite else {
        throw SpatialEvidenceError.nanOrInfiniteTransform("index_\(i)")
      }
    }
  }

  public static func validatePoseSample(_ sample: PoseSample) throws {
    try validateQuaternion(sample.rotationQuaternion)
    try validateTransformMatrix(sample.transform4x4)
    guard sample.translationMeters.isFinite else {
      throw SpatialEvidenceError.nanOrInfiniteTransform("translation")
    }
  }
}

/// Epoch / source binding for transform edges against package pose context.
public enum TransformEdgeValidator {
  public static func validateAll(
    edges: [TransformEdge],
    frames: [CoordinateFrameDescriptor],
    poseSampleIDs: Set<String>,
    packageSessionRunID: String,
    packageFrameEpochID: String,
    packageWorldOriginRevision: UInt64
  ) throws {
    let frameIDs = Set(frames.map(\.frameID))
    var seenTransformIDs = Set<String>()
    for edge in edges {
      if !seenTransformIDs.insert(edge.transformID).inserted {
        throw SpatialEvidenceError.transformEdgeBindingFailed("duplicate_transform_id:\(edge.transformID)")
      }
      if !frameIDs.contains(edge.fromFrameID) {
        throw SpatialEvidenceError.unknownCoordinateFrame(edge.fromFrameID)
      }
      if !frameIDs.contains(edge.toFrameID) {
        throw SpatialEvidenceError.unknownCoordinateFrame(edge.toFrameID)
      }
      try PoseMathValidator.validateTransformMatrix(edge.matrix)
      if edge.frameEpochID != packageFrameEpochID
        || edge.sessionRunID != packageSessionRunID
        || edge.worldOriginRevision != packageWorldOriginRevision
      {
        throw SpatialEvidenceError.transformEdgeBindingFailed(
          "epoch_mismatch:\(edge.transformID)"
        )
      }
      if edge.sourceSampleID == TransformEdge.fixtureStaticSourceSampleID {
        continue
      }
      if !poseSampleIDs.contains(edge.sourceSampleID) {
        throw SpatialEvidenceError.transformEdgeBindingFailed(
          "unknown_source_sample:\(edge.sourceSampleID)"
        )
      }
    }
  }
}

/// Rejects NOT_REQUESTED streams that still contribute payload / adapter / frame / clock evidence.
public enum NotRequestedStreamEvidenceValidator {
  public static func validateMotionNotRequested(
    capability: SpatialStreamCapability,
    artifacts: [SpatialArtifactDescriptor],
    frames: [CoordinateFrameDescriptor],
    clockCorrelations: [ClockCorrelation]
  ) throws {
    try validate(
      streamID: SpatialStreamID.motion,
      capability: capability,
      artifacts: artifacts,
      frames: frames,
      clockCorrelations: clockCorrelations,
      streamSpecificFrameIDs: ["FRAME_DEVICE_IMU"],
      streamSpecificClockDomains: [.coreMotion]
    )
  }

  public static func validate(
    streamID: String,
    capability: SpatialStreamCapability,
    artifacts: [SpatialArtifactDescriptor],
    frames: [CoordinateFrameDescriptor],
    clockCorrelations: [ClockCorrelation],
    streamSpecificFrameIDs: Set<String>,
    streamSpecificClockDomains: Set<ClockDomain>
  ) throws {
    let isNotRequested =
      capability.finalOutcome == .notRequested || !capability.declared
    guard isNotRequested else { return }

    if artifacts.contains(where: { $0.streamID == streamID }) {
      throw SpatialEvidenceError.notRequestedStreamContributesEvidence(
        "payload:\(streamID)"
      )
    }
    if capability.adapterID != "none" {
      throw SpatialEvidenceError.notRequestedStreamContributesEvidence(
        "adapter:\(capability.adapterID)"
      )
    }
    for frame in frames where streamSpecificFrameIDs.contains(frame.frameID) {
      throw SpatialEvidenceError.notRequestedStreamContributesEvidence(
        "frame:\(frame.frameID)"
      )
    }
    for corr in clockCorrelations {
      if streamSpecificClockDomains.contains(corr.sourceDomain)
        || streamSpecificClockDomains.contains(corr.destinationDomain)
      {
        throw SpatialEvidenceError.notRequestedStreamContributesEvidence(
          "clock:\(corr.correlationID)"
        )
      }
    }
  }
}

/// Frame registry + transform graph with reciprocal-safe cycle classification.
public struct CoordinateFrameGraph: Sendable {
  public let frames: [CoordinateFrameDescriptor]
  public let edges: [TransformEdge]

  public init(frames: [CoordinateFrameDescriptor], edges: [TransformEdge] = []) {
    self.frames = frames
    self.edges = edges
  }

  public func validateRegistry() throws {
    var seen = Set<String>()
    for frame in frames {
      if !seen.insert(frame.frameID).inserted {
        throw SpatialEvidenceError.duplicateCoordinateFrameID(frame.frameID)
      }
    }
  }

  public func requireKnownFrame(_ frameID: String) throws {
    try validateRegistry()
    guard frames.contains(where: { $0.frameID == frameID }) else {
      throw SpatialEvidenceError.unknownCoordinateFrame(frameID)
    }
  }

  public func validateEdgesReferenceKnownFrames() throws {
    try validateRegistry()
    let ids = Set(frames.map(\.frameID))
    for edge in edges {
      if !ids.contains(edge.fromFrameID) {
        throw SpatialEvidenceError.unknownCoordinateFrame(edge.fromFrameID)
      }
      if !ids.contains(edge.toFrameID) {
        throw SpatialEvidenceError.unknownCoordinateFrame(edge.toFrameID)
      }
      try PoseMathValidator.validateTransformMatrix(edge.matrix)
    }
  }

  /// Detects directed cycles among transform edges.
  /// Deprecated wrapper — prefers `validateTransformGraph` (permits consistent reciprocal pairs).
  @available(*, deprecated, message: "Use validateTransformGraph(reciprocalTolerance:) instead")
  public func detectCycles() throws {
    _ = try validateTransformGraph()
  }

  /// Classifies / validates the transform graph:
  /// 1. Permits reciprocal pairs A↔B when matrices are approximate inverses → CONSISTENT_RECIPROCAL_TRANSFORM.
  /// 2. Rejects longer directed cycles (length ≥ 3) → UNSUPPORTED_COMPLEX_CYCLE.
  /// 3. Rejects inconsistent reciprocal pairs → INCONSISTENT_RECIPROCAL_TRANSFORM.
  /// 4. Rejects ambiguous (from,to) edges with conflicting matrices → AMBIGUOUS_TRANSFORM_PATH.
  /// 5. Rejects zero / degenerate transforms → DEGENERATE_TRANSFORM.
  @discardableResult
  public func validateTransformGraph(reciprocalTolerance: Double = 1e-6) throws -> TransformGraphClassification? {
    try validateEdgesReferenceKnownFrames()

    var byPair: [String: [[Double]]] = [:]
    for edge in edges {
      if HomogeneousMatrix4x4.isDegenerate(edge.matrix, tolerance: reciprocalTolerance) {
        throw SpatialEvidenceError.degenerateTransform(from: edge.fromFrameID, to: edge.toFrameID)
      }
      let key = "\(edge.fromFrameID)->\(edge.toFrameID)"
      var list = byPair[key] ?? []
      let isDup = list.contains {
        HomogeneousMatrix4x4.approximatelyEqual($0, edge.matrix, tolerance: reciprocalTolerance)
      }
      if !isDup {
        list.append(edge.matrix)
      }
      byPair[key] = list
      if list.count > 1 {
        throw SpatialEvidenceError.ambiguousTransformPath(from: edge.fromFrameID, to: edge.toFrameID)
      }
    }

    var sawConsistentReciprocal = false
    var checkedReciprocal = Set<String>()
    for edge in edges {
      let pairKey = [edge.fromFrameID, edge.toFrameID].sorted().joined(separator: "|")
      if checkedReciprocal.contains(pairKey) { continue }
      guard let reverse = edges.first(where: {
        $0.fromFrameID == edge.toFrameID && $0.toFrameID == edge.fromFrameID
      }) else { continue }
      checkedReciprocal.insert(pairKey)
      let expectedReverse = try HomogeneousMatrix4x4.invert(
        edge.matrix,
        tolerance: reciprocalTolerance
      )
      if !HomogeneousMatrix4x4.approximatelyEqual(
        reverse.matrix,
        expectedReverse,
        tolerance: reciprocalTolerance
      ) {
        throw SpatialEvidenceError.inconsistentReciprocalTransform(
          from: edge.fromFrameID,
          to: edge.toFrameID
        )
      }
      sawConsistentReciprocal = true
    }

    // Directed cycles of length ≥ 3 (length-2 reciprocal pairs are permitted after checks above).
    var adjacency: [String: [String]] = [:]
    for edge in edges {
      adjacency[edge.fromFrameID, default: []].append(edge.toFrameID)
    }
    var visiting = Set<String>()
    var visited = Set<String>()
    var stack: [String] = []

    func dfs(_ node: String) throws {
      if visited.contains(node) { return }
      visiting.insert(node)
      stack.append(node)
      for next in adjacency[node] ?? [] {
        if visiting.contains(next) {
          let cycleStart = stack.firstIndex(of: next).map { Array(stack[$0...]) + [next] } ?? [next]
          // Unique hop count = cycle.count - 1 (closing node repeated).
          if cycleStart.count - 1 >= 3 {
            throw SpatialEvidenceError.unsupportedComplexCycle(cycleStart)
          }
          // Length-2 reciprocal: allowed.
          continue
        }
        if !visited.contains(next) {
          try dfs(next)
        }
      }
      _ = stack.popLast()
      visiting.remove(node)
      visited.insert(node)
    }

    for frame in frames.map(\.frameID) {
      try dfs(frame)
    }

    return sawConsistentReciprocal ? .consistentReciprocalTransform : nil
  }

  /// Static classification helper for reciprocal pairs (throws on reject paths).
  public static func classify(
    frames: [CoordinateFrameDescriptor],
    edges: [TransformEdge],
    reciprocalTolerance: Double = 1e-6
  ) throws -> TransformGraphClassification? {
    try CoordinateFrameGraph(frames: frames, edges: edges)
      .validateTransformGraph(reciprocalTolerance: reciprocalTolerance)
  }

  /// BFS path existence from → to (directed).
  public func requirePath(from: String, to: String) throws {
    try requireKnownFrame(from)
    try requireKnownFrame(to)
    if from == to { return }
    var adjacency: [String: [String]] = [:]
    for edge in edges {
      adjacency[edge.fromFrameID, default: []].append(edge.toFrameID)
    }
    var queue = [from]
    var seen: Set<String> = [from]
    while let cur = queue.first {
      queue.removeFirst()
      for next in adjacency[cur] ?? [] {
        if next == to { return }
        if seen.insert(next).inserted {
          queue.append(next)
        }
      }
    }
    throw SpatialEvidenceError.missingTransformPath(from: from, to: to)
  }
}

/// Explicit camera↔pose binding — never implied by timestamps alone.
/// `evidenceOriginAuthority` describes package/fixture provenance; it is **not** pose-estimate authority.
public struct PoseAssociationRecord: Sendable, Equatable {
  public let associationID: String
  public let cameraSampleID: String
  public let poseSampleID: String
  public let cameraClockDomain: ClockDomain
  public let poseClockDomain: ClockDomain
  public let correlationID: String
  public let associationTimestampNs: UInt64
  public let timestampDifferenceNs: Int64
  public let frameEpochID: String
  public let sessionRunID: String
  public let worldOriginRevision: UInt64
  public let associationMethod: String
  public let evidenceOriginAuthority: String

  public init(
    associationID: String,
    cameraSampleID: String,
    poseSampleID: String,
    cameraClockDomain: ClockDomain,
    poseClockDomain: ClockDomain,
    correlationID: String,
    associationTimestampNs: UInt64,
    timestampDifferenceNs: Int64,
    frameEpochID: String,
    sessionRunID: String,
    worldOriginRevision: UInt64,
    associationMethod: String = "explicit_fixture_binding",
    evidenceOriginAuthority: String = "TEST_FIXTURE"
  ) {
    self.associationID = associationID
    self.cameraSampleID = cameraSampleID
    self.poseSampleID = poseSampleID
    self.cameraClockDomain = cameraClockDomain
    self.poseClockDomain = poseClockDomain
    self.correlationID = correlationID
    self.associationTimestampNs = associationTimestampNs
    self.timestampDifferenceNs = timestampDifferenceNs
    self.frameEpochID = frameEpochID
    self.sessionRunID = sessionRunID
    self.worldOriginRevision = worldOriginRevision
    self.associationMethod = associationMethod
    self.evidenceOriginAuthority = evidenceOriginAuthority
  }

  public func asDictionary() -> [String: Any] {
    [
      "association_id": associationID,
      "camera_sample_id": cameraSampleID,
      "pose_sample_id": poseSampleID,
      "camera_clock_domain": cameraClockDomain.rawValue,
      "pose_clock_domain": poseClockDomain.rawValue,
      "correlation_id": correlationID,
      "association_timestamp_ns": associationTimestampNs,
      "timestamp_difference_ns": timestampDifferenceNs,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "association_method": associationMethod,
      "evidence_origin_authority": evidenceOriginAuthority,
    ]
  }
}

public enum PoseAssociationValidator {
  public static func requireCameraHasPose(
    cameraSampleID: String,
    associations: [PoseAssociationRecord]
  ) throws {
    guard associations.contains(where: { $0.cameraSampleID == cameraSampleID }) else {
      throw SpatialEvidenceError.poseAssociationMissing(cameraSampleID: cameraSampleID, poseSampleID: nil)
    }
  }

  public static func requirePoseHasCamera(
    poseSampleID: String,
    associations: [PoseAssociationRecord]
  ) throws {
    guard associations.contains(where: { $0.poseSampleID == poseSampleID }) else {
      throw SpatialEvidenceError.poseAssociationMissing(cameraSampleID: nil, poseSampleID: poseSampleID)
    }
  }

  /// Builds a fixture association using an explicit correlation (camera→pose domains).
  public static func makeAssociation(
    associationID: String,
    camera: SpatialSampleEnvelope<CameraSample>,
    pose: SpatialSampleEnvelope<PoseSample>,
    correlation: ClockCorrelation,
    associationMethod: String = "explicit_fixture_binding",
    evidenceOriginAuthority: String = "TEST_FIXTURE"
  ) throws -> PoseAssociationRecord {
    guard correlation.sourceDomain == camera.clockDomain,
          correlation.destinationDomain == pose.clockDomain
    else {
      throw SpatialEvidenceError.clockCorrelationDomainMismatch(correlation.correlationID)
    }
    let converted = correlation.convertSourceToDestination(
      sourceTimestampNs: camera.acquisitionTimestampNs
    )
    guard converted >= 0 else {
      throw SpatialEvidenceError.associationTimestampMismatch("negative_converted_timestamp")
    }
    let associationTimestampNs = UInt64(converted)
    let timestampDifferenceNs = converted - Int64(pose.acquisitionTimestampNs)
    return PoseAssociationRecord(
      associationID: associationID,
      cameraSampleID: camera.sampleID,
      poseSampleID: pose.sampleID,
      cameraClockDomain: camera.clockDomain,
      poseClockDomain: pose.clockDomain,
      correlationID: correlation.correlationID,
      associationTimestampNs: associationTimestampNs,
      timestampDifferenceNs: timestampDifferenceNs,
      frameEpochID: pose.payload.frameEpochID,
      sessionRunID: pose.payload.sessionRunID,
      worldOriginRevision: pose.payload.worldOriginRevision,
      associationMethod: associationMethod,
      evidenceOriginAuthority: evidenceOriginAuthority
    )
  }

  public static func validateAll(
    cameraSamples: [SpatialSampleEnvelope<CameraSample>],
    poseSamples: [SpatialSampleEnvelope<PoseSample>],
    associations: [PoseAssociationRecord],
    correlations: [ClockCorrelation]
  ) throws {
    let cameraIDs = cameraSamples.map(\.sampleID)
    let poseIDs = poseSamples.map(\.sampleID)
    for cam in cameraIDs {
      try requireCameraHasPose(cameraSampleID: cam, associations: associations)
    }
    for pose in poseIDs {
      try requirePoseHasCamera(poseSampleID: pose, associations: associations)
    }

    let camByID = Dictionary(uniqueKeysWithValues: cameraSamples.map { ($0.sampleID, $0) })
    let poseByID = Dictionary(uniqueKeysWithValues: poseSamples.map { ($0.sampleID, $0) })
    let clockValidator = ClockCorrelationValidator(correlations: correlations)

    var seenAssocIDs = Set<String>()
    for assoc in associations {
      if !seenAssocIDs.insert(assoc.associationID).inserted {
        throw SpatialEvidenceError.duplicateAssociationID(assoc.associationID)
      }
      guard let cam = camByID[assoc.cameraSampleID] else {
        throw SpatialEvidenceError.poseAssociationMissing(
          cameraSampleID: assoc.cameraSampleID,
          poseSampleID: nil
        )
      }
      guard let pose = poseByID[assoc.poseSampleID] else {
        throw SpatialEvidenceError.poseAssociationMissing(
          cameraSampleID: nil,
          poseSampleID: assoc.poseSampleID
        )
      }
      if assoc.cameraClockDomain != cam.clockDomain {
        throw SpatialEvidenceError.clockDomainMismatch(
          expected: cam.clockDomain.rawValue,
          actual: assoc.cameraClockDomain.rawValue
        )
      }
      if assoc.poseClockDomain != pose.clockDomain {
        throw SpatialEvidenceError.clockDomainMismatch(
          expected: pose.clockDomain.rawValue,
          actual: assoc.poseClockDomain.rawValue
        )
      }

      let corr = try clockValidator.requireByID(assoc.correlationID)
      if corr.sourceDomain != assoc.cameraClockDomain
        || corr.destinationDomain != assoc.poseClockDomain
      {
        throw SpatialEvidenceError.clockCorrelationDomainMismatch(assoc.correlationID)
      }
      try clockValidator.requireFresh(corr, atSourceTimestampNs: cam.acquisitionTimestampNs)

      let converted = corr.convertSourceToDestination(
        sourceTimestampNs: cam.acquisitionTimestampNs
      )
      guard converted >= 0 else {
        throw SpatialEvidenceError.associationTimestampMismatch("negative_converted_timestamp")
      }
      if assoc.associationTimestampNs != UInt64(converted) {
        throw SpatialEvidenceError.associationTimestampMismatch(
          "association_timestamp:\(assoc.associationID)"
        )
      }
      let expectedDiff = converted - Int64(pose.acquisitionTimestampNs)
      if assoc.timestampDifferenceNs != expectedDiff {
        throw SpatialEvidenceError.associationTimestampMismatch(
          "timestamp_difference:\(assoc.associationID)"
        )
      }

      if assoc.frameEpochID != pose.payload.frameEpochID
        || assoc.sessionRunID != pose.payload.sessionRunID
        || assoc.worldOriginRevision != pose.payload.worldOriginRevision
      {
        throw SpatialEvidenceError.associationEpochMismatch(assoc.associationID)
      }
    }
  }
}

/// Rejects joins across distinct ARKit / world-tracking epochs.
public enum PoseWorldEpochValidator {
  public static func requireSameEpoch(_ a: PoseSample, _ b: PoseSample) throws {
    if a.frameEpochID != b.frameEpochID
      || a.sessionRunID != b.sessionRunID
      || a.worldOriginRevision != b.worldOriginRevision
    {
      throw SpatialEvidenceError.crossEpochPoseJoin
    }
  }

  public static func requireHomogeneousPackageEpoch(_ poses: [PoseSample]) throws {
    guard let first = poses.first else { return }
    for pose in poses.dropFirst() {
      try requireSameEpoch(first, pose)
    }
  }
}

/// Cross-domain time comparison requires an explicit ClockCorrelation (never silent shared clocks).
public struct ClockCorrelationValidator: Sendable {
  public let correlations: [ClockCorrelation]

  public init(correlations: [ClockCorrelation]) {
    self.correlations = correlations
  }

  public func requireByID(_ id: String) throws -> ClockCorrelation {
    guard let match = correlations.first(where: { $0.correlationID == id }) else {
      throw SpatialEvidenceError.unknownClockCorrelationID(id)
    }
    return match
  }

  public func requireComparable(
    source: ClockDomain,
    destination: ClockDomain,
    atSourceTimestampNs: UInt64
  ) throws -> ClockCorrelation {
    if source == destination {
      // Same-domain identity still prefers an explicit record when present; allow without.
      if let identity = correlations.first(where: {
        $0.sourceDomain == source && $0.destinationDomain == destination
      }) {
        try requireFresh(identity, atSourceTimestampNs: atSourceTimestampNs)
        return identity
      }
      return ClockCorrelation(
        correlationID: "same-domain-identity-\(source.rawValue)",
        sourceDomain: source,
        destinationDomain: destination,
        offsetNanoseconds: 0,
        authority: "SAME_DOMAIN_IDENTITY",
        method: "domain_identity"
      )
    }

    let direct = correlations.filter {
      $0.sourceDomain == source && $0.destinationDomain == destination
    }
    let reverse = correlations.filter {
      $0.sourceDomain == destination && $0.destinationDomain == source
    }

    if direct.isEmpty && reverse.isEmpty {
      throw SpatialEvidenceError.crossDomainCompareWithoutCorrelation(
        source: source.rawValue,
        destination: destination.rawValue
      )
    }

    // Ambiguous: more than one distinct direct path (different offsets/methods).
    if direct.count > 1 {
      let distinct = Set(direct.map { "\($0.offsetNanoseconds)/\($0.method)/\($0.authority)" })
      if distinct.count > 1 {
        throw SpatialEvidenceError.ambiguousClockCorrelationPath(
          source: source.rawValue,
          destination: destination.rawValue
        )
      }
    }
    if reverse.count > 1 && direct.isEmpty {
      let distinct = Set(reverse.map { "\($0.offsetNanoseconds)/\($0.method)/\($0.authority)" })
      if distinct.count > 1 {
        throw SpatialEvidenceError.ambiguousClockCorrelationPath(
          source: source.rawValue,
          destination: destination.rawValue
        )
      }
    }
    // Prefer direct; if both direct and reverse exist with conflicting offsets, fail closed.
    if let d = direct.first, let r = reverse.first, d.offsetNanoseconds != -r.offsetNanoseconds {
      throw SpatialEvidenceError.ambiguousClockCorrelationPath(
        source: source.rawValue,
        destination: destination.rawValue
      )
    }

    let chosen = direct.first ?? reverse.first!
    try requireFresh(chosen, atSourceTimestampNs: atSourceTimestampNs)
    return chosen
  }

  public func requireFresh(_ correlation: ClockCorrelation, atSourceTimestampNs: UInt64) throws {
    if let from = correlation.validFromNanoseconds, atSourceTimestampNs < from {
      throw SpatialEvidenceError.staleClockCorrelation(
        "before_valid_from:\(correlation.sourceDomain.rawValue)->\(correlation.destinationDomain.rawValue)"
      )
    }
    if let until = correlation.validUntilNanoseconds, atSourceTimestampNs > until {
      throw SpatialEvidenceError.staleClockCorrelation(
        "after_valid_until:\(correlation.sourceDomain.rawValue)->\(correlation.destinationDomain.rawValue)"
      )
    }
  }
}
