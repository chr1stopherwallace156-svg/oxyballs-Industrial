import Foundation

/// Seals Sprint 3.5 guided-capture packages: coordinated streams + derived quality/coverage/guidance.
///
/// Derived evidence references source sample IDs. Original sensor payloads are never mutated.
public struct FixtureGuidedCapturePackageBuilder: Sendable {
  public static let primaryPackageID = "SPKG-FIXTURE-GUIDED-CAPTURE-000001"
  public static let primarySessionID = "SESS-FIXTURE-GUIDED-CAPTURE-000001"
  public static let missingRegionPackageID = "SPKG-FIXTURE-GUIDED-MISSING-REGION-000001"
  public static let missingRegionSessionID = "SESS-FIXTURE-GUIDED-MISSING-REGION-000001"
  public static let blurPackageID = "SPKG-FIXTURE-GUIDED-BLUR-000001"
  public static let blurSessionID = "SESS-FIXTURE-GUIDED-BLUR-000001"
  public static let noDepthPackageID = "SPKG-FIXTURE-GUIDED-NODEPTH-000001"
  public static let noDepthSessionID = "SESS-FIXTURE-GUIDED-NODEPTH-000001"
  public static let trackingPackageID = "SPKG-FIXTURE-GUIDED-TRACKING-000001"
  public static let trackingSessionID = "SESS-FIXTURE-GUIDED-TRACKING-000001"
  public static let storagePackageID = "SPKG-FIXTURE-GUIDED-STORAGE-000001"
  public static let storageSessionID = "SESS-FIXTURE-GUIDED-STORAGE-000001"

  public static let frameEpochID = FixtureCoordinatedPackageBuilder.frameEpochID
  public static let sessionRunID = FixtureCoordinatedPackageBuilder.sessionRunID

  public init() {}

  public struct GuidedSealInputs: Sendable {
    public var camera: [SpatialSampleEnvelope<CameraSample>]
    public var motion: [SpatialSampleEnvelope<MotionSample>]
    public var pose: [SpatialSampleEnvelope<PoseSample>]
    public var depth: [SpatialSampleEnvelope<DepthSample>]
    public var cameraCapability: SpatialStreamCapability
    public var motionCapability: SpatialStreamCapability
    public var poseCapability: SpatialStreamCapability
    public var depthCapability: SpatialStreamCapability
    public var activationPlan: SensorActivationPlan
    public var activationResults: [SensorActivationResult]
    public var sessionPolicy: SpatialCaptureSessionPolicy
    public var timeline: CaptureSessionTimeline
    public var interruptions: [CaptureInterruption]
    public var bufferState: CaptureBufferState
    public var qualityObservations: [CaptureQualityObservation]
    public var coverageObservations: [CoverageObservation]
    public var thresholdProfile: CaptureQualityThresholdProfile
    public var coveragePolicy: CoveragePolicy
    public var cancelled: Bool
    public var requiredStreamFailed: Bool
    public var activeInterruption: Bool
    public var packageID: String
    public var captureSessionID: String
    public var createdAtUTC: String

    public init(
      camera: [SpatialSampleEnvelope<CameraSample>],
      motion: [SpatialSampleEnvelope<MotionSample>],
      pose: [SpatialSampleEnvelope<PoseSample>],
      depth: [SpatialSampleEnvelope<DepthSample>],
      cameraCapability: SpatialStreamCapability,
      motionCapability: SpatialStreamCapability,
      poseCapability: SpatialStreamCapability,
      depthCapability: SpatialStreamCapability,
      activationPlan: SensorActivationPlan,
      activationResults: [SensorActivationResult],
      sessionPolicy: SpatialCaptureSessionPolicy,
      timeline: CaptureSessionTimeline,
      interruptions: [CaptureInterruption],
      bufferState: CaptureBufferState,
      qualityObservations: [CaptureQualityObservation],
      coverageObservations: [CoverageObservation],
      thresholdProfile: CaptureQualityThresholdProfile = CaptureQualityThresholdProfile(),
      coveragePolicy: CoveragePolicy = .fixtureDefault(),
      cancelled: Bool = false,
      requiredStreamFailed: Bool = false,
      activeInterruption: Bool = false,
      packageID: String = FixtureGuidedCapturePackageBuilder.primaryPackageID,
      captureSessionID: String = FixtureGuidedCapturePackageBuilder.primarySessionID,
      createdAtUTC: String = "2026-08-03T00:00:00Z"
    ) {
      self.camera = camera
      self.motion = motion
      self.pose = pose
      self.depth = depth
      self.cameraCapability = cameraCapability
      self.motionCapability = motionCapability
      self.poseCapability = poseCapability
      self.depthCapability = depthCapability
      self.activationPlan = activationPlan
      self.activationResults = activationResults
      self.sessionPolicy = sessionPolicy
      self.timeline = timeline
      self.interruptions = interruptions
      self.bufferState = bufferState
      self.qualityObservations = qualityObservations
      self.coverageObservations = coverageObservations
      self.thresholdProfile = thresholdProfile
      self.coveragePolicy = coveragePolicy
      self.cancelled = cancelled
      self.requiredStreamFailed = requiredStreamFailed
      self.activeInterruption = activeInterruption
      self.packageID = packageID
      self.captureSessionID = captureSessionID
      self.createdAtUTC = createdAtUTC
    }
  }

  public struct GuidedSealResult: Sendable {
    public var package: SpatialEvidencePackage
    public var signals: [CaptureQualitySignal]
    public var qualitySummary: CaptureQualitySummary
    public var coverageMap: CoverageMap
    public var coverageSummary: CoverageSummary
    public var guidanceHistory: [CaptureGuidanceRecord]
    public var completion: CaptureCompletionRecord
    public var derivation: CaptureDerivationRecord
    public var derivedEvidenceSHA256: String
  }

  public func seal(_ inputs: GuidedSealInputs, outputDirectory: URL) throws -> GuidedSealResult {
    if inputs.cancelled {
      throw SpatialEvidenceError.sessionCancelled
    }

    // 1) Seal base coordinated package (immutable sensor evidence).
    let base = try FixtureCoordinatedPackageBuilder().seal(
      camera: inputs.camera,
      motion: inputs.motion,
      pose: inputs.pose,
      depth: inputs.depth,
      cameraCapability: inputs.cameraCapability,
      motionCapability: inputs.motionCapability,
      poseCapability: inputs.poseCapability,
      depthCapability: inputs.depthCapability,
      activationPlan: inputs.activationPlan,
      activationResults: inputs.activationResults,
      policy: inputs.sessionPolicy,
      timeline: inputs.timeline,
      interruptions: inputs.interruptions,
      bufferState: inputs.bufferState,
      degradedSummary: nil,
      outputDirectory: outputDirectory,
      captureSessionID: inputs.captureSessionID,
      packageID: inputs.packageID,
      createdAtUTC: inputs.createdAtUTC
    )

    let knownIDs = Set(
      inputs.camera.map(\.sampleID)
        + inputs.motion.map(\.sampleID)
        + inputs.pose.map(\.sampleID)
        + inputs.depth.map(\.sampleID)
    )

    // 2) Derive quality / coverage / guidance without mutating payloads.
    let analyzer = CaptureQualityAnalyzer(thresholdProfile: inputs.thresholdProfile)
    let (signals, qualitySummary) = try analyzer.evaluate(
      observations: inputs.qualityObservations,
      captureSessionID: inputs.captureSessionID
    )
    var coverageEngine = CaptureCoverageEngine(
      policy: inputs.coveragePolicy,
      expectedSessionID: inputs.captureSessionID,
      expectedFrameEpochID: Self.frameEpochID,
      expectedSessionRunID: Self.sessionRunID,
      knownEvidenceIDs: knownIDs
    )
    let (coverageMap, coverageSummary, acceptedCoverage) = try coverageEngine.ingest(inputs.coverageObservations)
    let guidanceEngine = CaptureGuidanceEngine()
    let depthAcquired = inputs.depthCapability.finalOutcome == .acquired && !inputs.depth.isEmpty
    let (guidanceHistory, completion, readiness) = try guidanceEngine.generate(
      captureSessionID: inputs.captureSessionID,
      signals: signals,
      coverageSummary: coverageSummary,
      coverageGaps: coverageMap.gaps,
      depthOutcomeAcquired: depthAcquired,
      activeInterruption: inputs.activeInterruption,
      requiredStreamFailed: inputs.requiredStreamFailed,
      cancelled: false
    )

    // Forbidden engineering-completeness language in completion note.
    let banned = ["GEOMETRY_COMPLETE", "ENGINEERING_COMPLETE", "DIGITAL_TWIN_COMPLETE", "FULLY_SCANNED"]
    for token in banned where completion.note.uppercased().contains(token) {
      throw SpatialEvidenceError.engineeringCompletenessClaimForbidden(token)
    }

    let inputDigest = try analyzer.inputDigest(
      observations: inputs.qualityObservations,
      profile: inputs.thresholdProfile
    )

    let derivedPayload: [String: Any] = [
      "quality_signals": signals.map { $0.dictionary() },
      "quality_summary": qualitySummary.dictionary(),
      "coverage_map": coverageMap.dictionary(),
      "coverage_summary": coverageSummary.dictionary(),
      "guidance_history": guidanceHistory.map { $0.dictionary() },
      "completion_recommendation": completion.dictionary(),
    ]
    let derivedEvidenceSHA = ContentHasher.sha256Hex(try CanonicalJSON.data(derivedPayload))

    let derivation = CaptureDerivationRecord(
      derivationID: "DER-\(inputs.packageID)",
      sourceEvidenceIDs: Array(knownIDs).sorted() + acceptedCoverage.map(\.coverageObservationID).sorted(),
      inputDigest: inputDigest,
      algorithmIdentifier: "\(CaptureQualityAnalyzer.algorithmIdentifier)+\(CaptureCoverageEngine.algorithmIdentifier)+\(CaptureGuidanceEngine.algorithmIdentifier)",
      algorithmVersion: CaptureGuidanceEngine.algorithmVersion,
      thresholdProfileID: inputs.thresholdProfile.thresholdProfileID,
      outputEvidenceIDs: [
        "quality_signals.json",
        "quality_summary.json",
        "coverage_map.json",
        "coverage_summary.json",
        "guidance_history.json",
        "completion_recommendation.json",
        "derivation_record.json",
      ],
      generationTimestampUTC: inputs.createdAtUTC,
      evidenceAuthority: .guidanceEstimate,
      reproducibilityStatus: .deterministicReplay
    )

    // 3) Write derived sidecars and rebuild inventory/closure.
    try writeJSON(inputs.thresholdProfile.dictionary(), to: outputDirectory.appendingPathComponent("quality_threshold_profile.json"))
    try writeJSON(
      [
        "schema_id": "CaptureQualitySignals",
        "schema_version": "1.0.0-phase3-fixture",
        "signals": signals.map { $0.dictionary() },
      ] as [String: Any],
      to: outputDirectory.appendingPathComponent("quality_signals.json")
    )
    try writeJSON(qualitySummary.dictionary(), to: outputDirectory.appendingPathComponent("quality_summary.json"))
    try writeJSON(inputs.coveragePolicy.dictionary(), to: outputDirectory.appendingPathComponent("coverage_policy.json"))
    try writeJSON(
      [
        "schema_id": "CoverageObservations",
        "schema_version": "1.0.0-phase3-fixture",
        "observations": acceptedCoverage.map { $0.dictionary() },
      ] as [String: Any],
      to: outputDirectory.appendingPathComponent("coverage_observations.json")
    )
    try writeJSON(coverageMap.dictionary(), to: outputDirectory.appendingPathComponent("coverage_map.json"))
    try writeJSON(coverageSummary.dictionary(), to: outputDirectory.appendingPathComponent("coverage_summary.json"))
    try writeJSON(
      [
        "schema_id": "CaptureGuidanceHistory",
        "schema_version": "1.0.0-phase3-fixture",
        "records": guidanceHistory.map { $0.dictionary() },
      ] as [String: Any],
      to: outputDirectory.appendingPathComponent("guidance_history.json")
    )
    try writeJSON(completion.dictionary(), to: outputDirectory.appendingPathComponent("completion_recommendation.json"))
    try writeJSON(readiness.dictionary(), to: outputDirectory.appendingPathComponent("capture_readiness_summary.json"))
    try writeJSON(derivation.dictionary(), to: outputDirectory.appendingPathComponent("derivation_record.json"))
    try writeJSON(
      ["derived_evidence_sha256": derivedEvidenceSHA, "schema_id": "DerivedEvidenceDigest", "schema_version": "1.0.0-phase3-fixture"],
      to: outputDirectory.appendingPathComponent("derived_evidence_digest.json")
    )

    // Recompute inventory + closure to include derived files; keep original payload hashes intact.
    let inventoryEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: outputDirectory
    )
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(
      packageRoot: outputDirectory,
      entries: inventoryEntries
    )
    // Ensure no orphan derived requirement: every derived file listed in derivation outputs exists.
    for rel in derivation.outputEvidenceIDs {
      let url = outputDirectory.appendingPathComponent(rel)
      guard FileManager.default.fileExists(atPath: url.path) else {
        throw SpatialEvidenceError.derivedEvidenceOrphan(rel)
      }
    }
    let packageClosureHash = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: inventoryEntries)
    let inventory: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0-phase3-fixture",
      "package_id": inputs.packageID,
      "entries": inventoryEntries,
      "fixture_package_closure_sha256": packageClosureHash,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
    ]
    try writeJSON(inventory, to: outputDirectory.appendingPathComponent("package_inventory.json"))

    // Update manifest artifact list if needed — leave sensor artifacts; add derived descriptors for content hash.
    let manifestURL = outputDirectory.appendingPathComponent("manifest.json")
    let manifestData = try Data(contentsOf: manifestURL)
    var manifestObj = try JSONSerialization.jsonObject(with: manifestData) as? [String: Any] ?? [:]
    var artifacts = manifestObj["artifacts"] as? [[String: Any]] ?? []
    let derivedFiles = [
      "quality_threshold_profile.json",
      "quality_signals.json",
      "quality_summary.json",
      "coverage_policy.json",
      "coverage_observations.json",
      "coverage_map.json",
      "coverage_summary.json",
      "guidance_history.json",
      "completion_recommendation.json",
      "capture_readiness_summary.json",
      "derivation_record.json",
      "derived_evidence_digest.json",
    ]
    for rel in derivedFiles {
      let data = try Data(contentsOf: outputDirectory.appendingPathComponent(rel))
      artifacts.append([
        "relative_path": rel,
        "sha256": ContentHasher.sha256Hex(data),
        "byte_length": data.count,
        "media_type": "application/json",
        "schema_id": "DerivedEvidence",
        "schema_version": "1.0.0-phase3-fixture",
        "stream_id": "derived",
        "adapter_id": "fixture.guidance",
        "sample_id": rel,
      ])
    }
    artifacts.sort {
      (($0["relative_path"] as? String) ?? "") < (($1["relative_path"] as? String) ?? "")
    }
    manifestObj["artifacts"] = artifacts
    let newManifestData = try CanonicalJSON.data(manifestObj)
    try newManifestData.write(to: manifestURL, options: .atomic)
    let manifestSHA = ContentHasher.sha256Hex(newManifestData)

    // Re-collect inventory after manifest rewrite
    let inventoryEntries2 = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(
      packageRoot: outputDirectory
    )
    try SpatialPackageClosureVerifier.verifyInventoryCompleteness(
      packageRoot: outputDirectory,
      entries: inventoryEntries2
    )
    let packageClosureHash2 = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: inventoryEntries2)
    let inventory2: [String: Any] = [
      "schema_id": "PackageInventory",
      "schema_version": "1.0.0-phase3-fixture",
      "package_id": inputs.packageID,
      "entries": inventoryEntries2,
      "fixture_package_closure_sha256": packageClosureHash2,
      "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
    ]
    try writeJSON(inventory2, to: outputDirectory.appendingPathComponent("package_inventory.json"))
    let packageHash = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: outputDirectory)

    let sealed = SpatialEvidencePackage(
      rootURL: outputDirectory,
      manifest: base.manifest,
      packageContentSHA256: packageHash,
      manifestSHA256: manifestSHA,
      packageClosureSHA256: packageClosureHash2
    )

    return GuidedSealResult(
      package: sealed,
      signals: signals,
      qualitySummary: qualitySummary,
      coverageMap: coverageMap,
      coverageSummary: coverageSummary,
      guidanceHistory: guidanceHistory,
      completion: completion,
      derivation: derivation,
      derivedEvidenceSHA256: derivedEvidenceSHA
    )
  }

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    try CanonicalJSON.data(object).write(to: url, options: .atomic)
  }
}
