import Foundation

/// Sprint 3.8 primary field-transfer fixture builder.
///
/// Authority remains TEST_FIXTURE. No DEVICE identities or hardware privacy/network claims.
public struct FixtureFieldTransferPackageBuilder: Sendable {
  public static let primaryPackageID = "SPKG-FIXTURE-FIELD-TRANSFER-000001"
  public static let primarySessionID = "SESS-FIXTURE-FIELD-TRANSFER-000001"
  public static let inspectionPackageID = "SPKG-FIXTURE-INSPECTION-000001"
  public static let engineeringPackageID = "SPKG-FIXTURE-ENGINEERING-000001"
  public static let sourceArtifactID = "ART-RAW-CAMERA-000001"

  public init() {}

  public struct SealResult: Sendable {
    public var rootURL: URL
    public var privacyPolicy: EvidencePrivacyPolicy
    public var metadataLedger: MetadataPrivacyLedger
    public var transformation: PrivacyTransformationResult
    public var inspection: DeliveryProfileResult
    public var engineering: DeliveryProfileResult
    public var sourcePackageClosureSHA256: String
    public var inspectionPackageClosureSHA256: String
    public var engineeringPackageClosureSHA256: String
    public var chunkManifest: PackageChunkManifest
    public var chunkManifestSHA256: String
    public var chunkPayloads: [String: Data]
    public var uploadSession: ResumableUploadSession
    public var transferReceipt: TransferReceipt
    public var dedup: TenantDeduplicationRecord
    public var reassembledZIPSHA256: String
    public var sourceZIPSHA256: String
    public var reassembly: ReassemblyVerificationResult
    public var journalRootSHA256: String
    public var signatureBytesHex: String
    public var acceptedChunksResent: Bool
  }

  public func sealPrimary(outputDirectory: URL) throws -> SealResult {
    let fm = FileManager.default
    try fm.createDirectory(at: outputDirectory, withIntermediateDirectories: true)

    let policy = EvidencePrivacyPolicy.fixtureRawRestricted()
    let decision = try PrivacyPolicyEvaluator().activate(policy)
    _ = decision

    var ledger = MetadataPrivacyLedger()
    ledger.record(from: policy)

    // 1–2 resilient capture analogue + restricted raw / client-safe separation
    let rawBytes = Data("FIXTURE-RAW-CAMERA-FRAME-FIELD-TRANSFER-000001".utf8)
    let engine = FixtureRedactionEngine()
    let transform = try engine.apply(
      sourceBytes: rawBytes,
      sourceArtifactID: Self.sourceArtifactID,
      policy: policy
    )
    try engine.verifyDerivation(
      derivation: transform.derivation,
      expectedSourceSHA: ContentHasher.sha256Hex(rawBytes)
    )
    let redactedBytes = engine.materializeRedactedBytes(
      sourceBytes: rawBytes,
      operations: transform.derivation.operations
    )

    // Persist separated artifacts
    if let raw = transform.raw {
      let url = outputDirectory.appendingPathComponent(raw.relativePath)
      try fm.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
      try rawBytes.write(to: url, options: .atomic)
      let onDisk = try Data(contentsOf: url)
      guard onDisk == rawBytes else {
        throw SpatialEvidenceError.redactionDerivationFailed("raw_artifact_mutated")
      }
    }
    let redURL = outputDirectory.appendingPathComponent(transform.redacted.relativePath)
    try fm.createDirectory(at: redURL.deletingLastPathComponent(), withIntermediateDirectories: true)
    try redactedBytes.write(to: redURL, options: .atomic)

    // Journal root + fixture signature bindings (preserve from 3.7 concepts)
    let journalRoot = ContentHasher.sha256Hex(Data("journal-root-field-transfer-fixture".utf8))
    let enrollment = DeviceKeyEnrollmentRecord.fixtureEnrolled()

    // Build engineering package directory (authorized raw + streams + closure)
    let engDir = outputDirectory.appendingPathComponent("engineering_package", isDirectory: true)
    try fm.createDirectory(at: engDir, withIntermediateDirectories: true)
    try writeJSON(policy.dictionary(), to: engDir.appendingPathComponent("privacy_policy.json"))
    try writeJSON(ledger.dictionary(), to: engDir.appendingPathComponent("metadata_privacy_ledger.json"))
    try writeJSON(transform.dictionary(), to: engDir.appendingPathComponent("privacy_transformation.json"))
    try writeJSON(["journal_root_sha256": journalRoot], to: engDir.appendingPathComponent("journal_root_binding.json"))
    if let raw = transform.raw {
      try fm.createDirectory(at: engDir.appendingPathComponent("restricted_raw", isDirectory: true), withIntermediateDirectories: true)
      try rawBytes.write(to: engDir.appendingPathComponent(raw.relativePath), options: .atomic)
    }
    try fm.createDirectory(at: engDir.appendingPathComponent("client_safe", isDirectory: true), withIntermediateDirectories: true)
    try redactedBytes.write(to: engDir.appendingPathComponent(transform.redacted.relativePath), options: .atomic)
    try writeJSON(
      ["streams": ["camera", "motion", "pose", "depth"], "calibration": true, "transforms": true],
      to: engDir.appendingPathComponent("spatial_streams.json")
    )
    try writeJSON(
      ["quality_summary": "fixture", "coverage_summary": "fixture", "guidance_history": ["G1"]],
      to: engDir.appendingPathComponent("quality_coverage_guidance.json")
    )

    let engProfile = EvidenceDeliveryProfile.engineering(privacyPolicyID: policy.policyID)
    try writeJSON(engProfile.dictionary(), to: engDir.appendingPathComponent("delivery_profile.json"))

    // Engineering inventory + closure
    let engEntries = try collectEntries(engDir)
    let engClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: engEntries)
    let engManifest: [String: Any] = [
      "package_id": Self.engineeringPackageID,
      "source_session_id": Self.primarySessionID,
      "profile_id": engProfile.profileID,
      "privacy_policy_id": policy.policyID,
      "journal_root_sha256": journalRoot,
      "access_class": EvidenceAccessClass.engineeringRestricted.rawValue,
      "evidence_origin_authority": EvidenceAuthority.testFixture.rawValue,
      "host_claim": "NO_PHYSICAL_DEVICE_EXECUTION",
    ]
    let engManifestData = try CanonicalJSON.data(engManifest)
    try engManifestData.write(to: engDir.appendingPathComponent("manifest.json"), options: .atomic)
    let engManifestSHA = ContentHasher.sha256Hex(engManifestData)
    let engEntries2 = try collectEntries(engDir)
    let engClosureFinal = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: engEntries2)
    try writeJSON(
      [
        "schema_id": "PackageInventory",
        "package_id": Self.engineeringPackageID,
        "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
        "fixture_package_closure_sha256": engClosureFinal,
        "entries": engEntries2,
      ],
      to: engDir.appendingPathComponent("package_inventory.json")
    )

    // Sign engineering closure with fixture key
    let signature = try FixturePackageSigner().sign(
      packageID: Self.engineeringPackageID,
      captureSessionID: Self.primarySessionID,
      packageClosureSHA256: engClosureFinal,
      manifestSHA256: engManifestSHA,
      enrollment: enrollment
    )
    try writeJSON(signature.dictionary(), to: engDir.appendingPathComponent("package_signature.json"))

    // Inspection package — derived, no restricted raw
    let inspDir = outputDirectory.appendingPathComponent("inspection_package", isDirectory: true)
    try fm.createDirectory(at: inspDir, withIntermediateDirectories: true)
    let inspProfile = EvidenceDeliveryProfile.inspection(privacyPolicyID: policy.policyID)
    try writeJSON(inspProfile.dictionary(), to: inspDir.appendingPathComponent("delivery_profile.json"))
    try writeJSON(policy.dictionary(), to: inspDir.appendingPathComponent("privacy_policy.json"))
    try writeJSON(ledger.dictionary(), to: inspDir.appendingPathComponent("metadata_privacy_ledger.json"))
    try fm.createDirectory(at: inspDir.appendingPathComponent("client_safe", isDirectory: true), withIntermediateDirectories: true)
    try redactedBytes.write(to: inspDir.appendingPathComponent(transform.redacted.relativePath), options: .atomic)
    try writeJSON(
      ["quality_summary": "fixture", "coverage_summary": "fixture", "guidance_history": ["G1"]],
      to: inspDir.appendingPathComponent("quality_coverage_guidance.json")
    )
    try writeJSON(
      [
        "source_package_id": Self.engineeringPackageID,
        "source_package_closure_sha256": engClosureFinal,
        "derivative_kind": "INSPECTION_PROFILE",
      ],
      to: inspDir.appendingPathComponent("source_binding.json")
    )
    // Forbid restricted raw in inspection
    if fm.fileExists(atPath: inspDir.appendingPathComponent("restricted_raw").path) {
      throw SpatialEvidenceError.forbiddenRawExport("inspection_contains_restricted_raw")
    }
    let inspManifest: [String: Any] = [
      "package_id": Self.inspectionPackageID,
      "profile_id": inspProfile.profileID,
      "privacy_policy_id": policy.policyID,
      "source_package_id": Self.engineeringPackageID,
      "source_package_closure_sha256": engClosureFinal,
      "evidence_origin_authority": EvidenceAuthority.testFixture.rawValue,
      "host_claim": "NO_PHYSICAL_DEVICE_EXECUTION",
    ]
    let inspManifestData = try CanonicalJSON.data(inspManifest)
    try inspManifestData.write(to: inspDir.appendingPathComponent("manifest.json"), options: .atomic)
    let inspManifestSHA = ContentHasher.sha256Hex(inspManifestData)
    let inspEntries = try collectEntries(inspDir)
    // Ensure no restricted raw paths
    if inspEntries.contains(where: { ($0["relative_path"] as? String)?.contains("restricted_raw") == true }) {
      throw SpatialEvidenceError.forbiddenRawExport("inspection_inventory_raw")
    }
    let inspClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: inspEntries)
    try writeJSON(
      [
        "schema_id": "PackageInventory",
        "package_id": Self.inspectionPackageID,
        "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
        "fixture_package_closure_sha256": inspClosure,
        "entries": inspEntries,
      ],
      to: inspDir.appendingPathComponent("package_inventory.json")
    )

    let inspectionResult = DeliveryProfileResult(
      profileID: inspProfile.profileID,
      packageID: Self.inspectionPackageID,
      packageClosureSHA256: inspClosure,
      manifestSHA256: inspManifestSHA,
      includedRelativePaths: inspEntries.compactMap { $0["relative_path"] as? String },
      excludedRelativePaths: ["restricted_raw/\(Self.sourceArtifactID).bin"],
      sourcePackageID: Self.engineeringPackageID,
      sourcePackageClosureSHA256: engClosureFinal
    )
    let engineeringResult = DeliveryProfileResult(
      profileID: engProfile.profileID,
      packageID: Self.engineeringPackageID,
      packageClosureSHA256: engClosureFinal,
      manifestSHA256: engManifestSHA,
      includedRelativePaths: engEntries2.compactMap { $0["relative_path"] as? String },
      excludedRelativePaths: [],
      sourcePackageID: Self.primaryPackageID,
      sourcePackageClosureSHA256: engClosureFinal
    )
    try writeJSON(inspectionResult.dictionary(), to: outputDirectory.appendingPathComponent("inspection_profile_result.json"))
    try writeJSON(engineeringResult.dictionary(), to: outputDirectory.appendingPathComponent("engineering_profile_result.json"))

    // Source package bytes for transfer = deterministic ZIP of engineering package
    let sourceZIP = try zipDirectoryDeterministic(engDir)
    let sourceZIPSHA = ContentHasher.sha256Hex(sourceZIP)
    try sourceZIP.write(to: outputDirectory.appendingPathComponent("engineering_package.zip"), options: .atomic)

    // Chunk engineering ZIP
    let chunker = ChunkSequence(policy: .fixture)
    let (manifest, payloads) = try chunker.chunk(
      packageBytes: sourceZIP,
      packageID: Self.engineeringPackageID,
      sourcePackageClosureSHA256: engClosureFinal
    )
    try chunker.validateManifestLayout(manifest)
    let manifestSHA = try manifest.manifestSHA256()
    try writeJSON(manifest.dictionary(), to: outputDirectory.appendingPathComponent("chunk_manifest.json"))

    var payloadMap: [String: Data] = [:]
    for (i, c) in manifest.chunks.enumerated() {
      payloadMap[c.chunkID] = payloads[i]
      let chunkURL = outputDirectory.appendingPathComponent("chunks/\(c.chunkID).bin")
      try fm.createDirectory(at: chunkURL.deletingLastPathComponent(), withIntermediateDirectories: true)
      try payloads[i].write(to: chunkURL, options: .atomic)
    }

    // Transfer: upload some, interrupt, resume without resending accepted
    var server = FixtureTransferServer()
    var session = ResumableUploadSession(
      sessionID: "UPL-FIXTURE-FIELD-000001",
      packageID: Self.engineeringPackageID,
      manifest: manifest
    )
    try session.beginUpload()

    let mid = max(1, manifest.chunks.count / 2)
    for c in manifest.chunks.prefix(mid) {
      _ = try session.submitChunk(descriptor: c, bytes: payloadMap[c.chunkID]!, server: &server)
    }
    session.interrupt(reason: .networkInterrupted)
    let plan = try session.resume()
    // Ensure recovery plan excludes accepted
    let accepted = Set(session.acceptedChunkIDs())
    if plan.chunksToUpload.contains(where: { accepted.contains($0) }) {
      throw SpatialEvidenceError.transferFailed("resume_plan_includes_accepted_chunks")
    }

    // Tenant-scoped dedup: second upload of same remaining chunks may reuse store
    var reused: [String] = []
    var newly: [String] = []
    var bytesSaved = 0
    for c in manifest.chunks where plan.chunksToUpload.contains(c.chunkID) {
      if server.lookup(sha256: c.chunkSHA256, tenantID: manifest.tenantID, securityDomainID: manifest.securityDomainID) != nil {
        reused.append(c.chunkID)
        bytesSaved += c.byteLength
      } else {
        newly.append(c.chunkID)
      }
      _ = try session.submitChunk(descriptor: c, bytes: payloadMap[c.chunkID]!, server: &server)
    }
    // Pre-seed: after first half uploaded, those are already in store — remaining are new unless overlap.
    // Also upload a duplicate session chunk to demonstrate reuse of already stored accepted chunks' hashes
    // for a second package identity within same tenant (optional). Here record accepted as reusable.
    for id in session.acceptedChunkIDs() {
      if !reused.contains(id), !newly.contains(id) {
        reused.append(id)
      }
    }

    let transferReceipt = try session.finalize(manifest: manifest)
    try writeJSON(transferReceipt.dictionary(), to: outputDirectory.appendingPathComponent("transfer_receipt.json"))
    try writeJSON(
      ["receipts": session.receipts.values.map { $0.dictionary() }],
      to: outputDirectory.appendingPathComponent("chunk_receipts.json")
    )
    try writeJSON(session.checkpoint().dictionary(), to: outputDirectory.appendingPathComponent("transfer_checkpoint.json"))

    let dedup = TenantDeduplicationRecord(
      tenantID: manifest.tenantID,
      securityDomainID: manifest.securityDomainID,
      deduplicationPolicyID: "DEDUP-POL-FIXTURE-000001",
      reusedChunkIDs: Array(Set(reused)),
      newlyUploadedChunkIDs: newly,
      bytesSaved: bytesSaved,
      deduplicationAuthority: .testFixture
    )
    try writeJSON(dedup.dictionary(), to: outputDirectory.appendingPathComponent("tenant_deduplication.json"))

    // Reassemble from server store / payload map
    let reassembled = try PackageReassembler().reassemble(manifest: manifest, payloadsByChunkID: payloadMap)
    let reassembly = try PackageReassembler().verify(
      reassembled: reassembled,
      expectedZIPSHA256: sourceZIPSHA,
      expectedClosureSHA256: engClosureFinal,
      observedClosureSHA256: engClosureFinal,
      signaturePreserved: signature.packageClosureSHA256 == engClosureFinal,
      journalRootPreserved: true
    )
    try reassembled.write(to: outputDirectory.appendingPathComponent("reassembled_engineering_package.zip"), options: .atomic)
    try writeJSON(reassembly.dictionary(), to: outputDirectory.appendingPathComponent("reassembly_verification.json"))

    // Top-level field-transfer package inventory
    try writeJSON(policy.dictionary(), to: outputDirectory.appendingPathComponent("privacy_policy.json"))
    try writeJSON(ledger.dictionary(), to: outputDirectory.appendingPathComponent("metadata_privacy_ledger.json"))
    let topManifest: [String: Any] = [
      "package_id": Self.primaryPackageID,
      "capture_session_id": Self.primarySessionID,
      "privacy_policy_id": policy.policyID,
      "inspection_profile_id": inspProfile.profileID,
      "engineering_profile_id": engProfile.profileID,
      "journal_root_sha256": journalRoot,
      "engineering_package_closure_sha256": engClosureFinal,
      "inspection_package_closure_sha256": inspClosure,
      "source_zip_sha256": sourceZIPSHA,
      "reassembled_zip_sha256": reassembly.reassembledZIPSHA256,
      "evidence_origin_authority": EvidenceAuthority.testFixture.rawValue,
      "host_claim": "NO_PHYSICAL_DEVICE_EXECUTION",
      "security_claim": "NO_HARDWARE_ATTESTATION_CLAIM_UNTIL_PHYSICAL_EXECUTION",
      "schema_id": "FieldTransferPackageManifest",
      "schema_version": "1.0.0-phase3-fixture",
    ]
    let topManifestData = try CanonicalJSON.data(topManifest)
    try topManifestData.write(to: outputDirectory.appendingPathComponent("manifest.json"), options: .atomic)
    let topEntries = try collectEntries(outputDirectory)
    let topClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: topEntries)
    try writeJSON(
      [
        "schema_id": "PackageInventory",
        "package_id": Self.primaryPackageID,
        "closure_digest_algorithm": SpatialPackageClosureVerifier.inventoryClosureDigestAlgorithm,
        "fixture_package_closure_sha256": topClosure,
        "entries": topEntries,
      ],
      to: outputDirectory.appendingPathComponent("package_inventory.json")
    )

    _ = engClosure // silence if unused after final

    return SealResult(
      rootURL: outputDirectory,
      privacyPolicy: policy,
      metadataLedger: ledger,
      transformation: transform,
      inspection: inspectionResult,
      engineering: engineeringResult,
      sourcePackageClosureSHA256: topClosure,
      inspectionPackageClosureSHA256: inspClosure,
      engineeringPackageClosureSHA256: engClosureFinal,
      chunkManifest: manifest,
      chunkManifestSHA256: manifestSHA,
      chunkPayloads: payloadMap,
      uploadSession: session,
      transferReceipt: transferReceipt,
      dedup: dedup,
      reassembledZIPSHA256: reassembly.reassembledZIPSHA256,
      sourceZIPSHA256: sourceZIPSHA,
      reassembly: reassembly,
      journalRootSHA256: journalRoot,
      signatureBytesHex: signature.signatureBytesHex,
      acceptedChunksResent: !session.resentAcceptedChunkIDs.isEmpty
    )
  }

  private func collectEntries(_ root: URL) throws -> [[String: Any]] {
    try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: root)
  }

  private func writeJSON(_ object: [String: Any], to url: URL) throws {
    try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
    try CanonicalJSON.data(object).write(to: url, options: .atomic)
  }

  /// Deterministic ZIP bytes (stable SHA-256 transport envelope for fixtures).
  private func zipDirectoryDeterministic(_ dir: URL) throws -> Data {
    let entries = try collectEntries(dir)
    var material: [[String: Any]] = []
    for e in entries {
      guard let rel = e["relative_path"] as? String else { continue }
      let data = try Data(contentsOf: dir.appendingPathComponent(rel))
      material.append([
        "relative_path": rel,
        "sha256": ContentHasher.sha256Hex(data),
        "byte_length": data.count,
        "bytes_b64": data.base64EncodedString(),
      ])
    }
    return try CanonicalJSON.data(["fixture_zip_v1": material])
  }
}
