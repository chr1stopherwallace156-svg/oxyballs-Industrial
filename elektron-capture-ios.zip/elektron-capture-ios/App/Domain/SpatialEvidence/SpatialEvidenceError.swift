import Foundation

/// Fail-closed spatial evidence errors (Phase 3 synthetic vertical slice).
public enum SpatialEvidenceError: Error, Equatable, Sendable {
  case invalidLifecycleTransition(from: String, to: String)
  case clockDomainMismatch(expected: String, actual: String)
  case coordinateFrameRejected(String)
  case missingArtifact(path: String)
  case orphanArtifact(path: String)
  case duplicateArtifact(path: String)
  case temporaryArtifactRejected(path: String)
  case unreferencedArtifact(path: String)
  case byteLengthMismatch(path: String, expected: Int, actual: Int)
  case sha256Mismatch(path: String, expected: String, actual: String)
  case unsupportedSchema(id: String, version: String)
  case packageClosureFailed(String)
  case custodyStaleRevision(current: Int, attempted: Int)
  case verifiedHandleUnavailable(String)
  case capabilityNotObserved(String)
  case cancelled
  case interrupted(String)
  case validationFailed(String)
  case bindingRequired(String)
  // Sprint 3.2 pose + spatiotemporal
  case invalidQuaternion(String)
  case nonNormalizedQuaternion(magnitude: Double)
  case nanOrInfiniteTransform(String)
  case unknownCoordinateFrame(String)
  case duplicateCoordinateFrameID(String)
  /// Directed cycle length ≥ 3 — not an inconsistent reciprocal pair.
  case unsupportedComplexCycle([String])
  case missingTransformPath(from: String, to: String)
  case inconsistentReciprocalTransform(from: String, to: String)
  case ambiguousTransformPath(from: String, to: String)
  case degenerateTransform(from: String, to: String)
  case poseAssociationMissing(cameraSampleID: String?, poseSampleID: String?)
  case duplicateAssociationID(String)
  case unknownClockCorrelationID(String)
  case clockCorrelationDomainMismatch(String)
  case associationTimestampMismatch(String)
  case associationEpochMismatch(String)
  case notRequestedStreamContributesEvidence(String)
  case transformEdgeBindingFailed(String)
  case crossDomainCompareWithoutCorrelation(source: String, destination: String)
  case staleClockCorrelation(String)
  case ambiguousClockCorrelationPath(source: String, destination: String)
  case crossEpochPoseJoin
  case poseTrackingFailed(PoseFailureReason)
  case poseSessionInterrupted(String)
  case poseRelocalizationRequired
  // Sprint 3.3 depth + RGB/depth association
  case invalidDepthSample(String)
  case invalidDepthCalibration(String)
  case depthCalibrationMissing(String)
  case depthCalibrationDimensionMismatch(String)
  case rgbDepthAssociationFailed(String)
  case depthEvidenceSynthesizedWhenUnavailable(String)
  case depthArtifactAbsenceRequired(String)
  // Sprint 3.4 multi-stream orchestration
  case invalidTransition(from: String, to: String, event: String)
  case sampleRejected(String)
  case bufferOverflow(streamID: String)
  case requiredStreamFailed(streamID: String, reason: String)
  case finalizationRejected(String)
  case checkpointFailed(String)
  case duplicateStart
  case duplicateSampleID(String)
  case timestampRegression(streamID: String, previous: UInt64, next: UInt64)
  case streamNotRequested(String)
  case streamNotActive(String)
  case sessionCancelled
  case activationPlanRejected(String)
  case recoveryRejected(String)
  // Sprint 3.5 quality / coverage / guidance
  case unknownQualitySignalType(String)
  case nonFiniteQualityValue(String)
  case qualityThresholdProfileMismatch(String)
  case qualityCrossSessionRejected(String)
  case unknownCoverageRegion(String)
  case coverageCrossSessionRejected(String)
  case coverageCrossEpochRejected(String)
  case coverageMissingEvidenceReference(String)
  case coverageUnknownEvidenceReference(String)
  case guidanceMissingSupportingEvidence(String)
  case guidanceDuplicateActive(String)
  case derivedEvidenceOrphan(String)
  case engineeringCompletenessClaimForbidden(String)
  // Sprint 3.6 Apple / device package law
  case deviceIdentityRequired(String)
  case fixtureIdentityForbiddenInDevicePackage(String)
  case deviceEvidenceAuthorityRequired(String)
  case deviceHostClaimRequired(String)
  case deviceAdapterIdentityMismatch(String)
  case appleHostUnavailable(String)
  // Sprint 3.7 identity / journal / resilience
  case journalDuplicateSampleID(String)
  case journalSequenceGap(expected: UInt64, actual: UInt64)
  case journalInvalidState(String)
  case journalBrokenChain(String)
  case journalDuplicateOrMissingSequence(UInt64)
  case journalNonResumable(String)
  case silentStreamDegradationRejected(String)
  case packageSignatureFailed(String)
  case packageAttestationFailed(String)
  // Sprint 3.8 privacy / field transfer
  case privacyPolicyViolation(String)
  case privacyPolicyUnknown(String)
  case privacyPolicyExpired(String)
  case silentMetadataStrippingRejected(String)
  case redactionDerivationFailed(String)
  case forbiddenRawExport(String)
  case requiredRedactionMissing(String)
  case chunkingFailed(String)
  case transferFailed(String)
  case reassemblyFailed(String)
  case crossTenantDedupRejected(String)
  case deliveryProfileFailed(String)

  /// Stable string codes for transform-graph classifications (and related failures).
  public var transformGraphCode: String? {
    switch self {
    case .unsupportedComplexCycle:
      return TransformGraphClassification.unsupportedComplexCycle.rawValue
    case .inconsistentReciprocalTransform:
      return TransformGraphClassification.inconsistentReciprocalTransform.rawValue
    case .ambiguousTransformPath:
      return TransformGraphClassification.ambiguousTransformPath.rawValue
    case .degenerateTransform:
      return TransformGraphClassification.degenerateTransform.rawValue
    default:
      return nil
    }
  }
}

/// Typed transform-graph validation classifications (Sprint 3.2 hardening).
public enum TransformGraphClassification: String, Sendable, Equatable, CaseIterable {
  case consistentReciprocalTransform = "CONSISTENT_RECIPROCAL_TRANSFORM"
  case inconsistentReciprocalTransform = "INCONSISTENT_RECIPROCAL_TRANSFORM"
  case ambiguousTransformPath = "AMBIGUOUS_TRANSFORM_PATH"
  case degenerateTransform = "DEGENERATE_TRANSFORM"
  case unsupportedComplexCycle = "UNSUPPORTED_COMPLEX_CYCLE"
}
