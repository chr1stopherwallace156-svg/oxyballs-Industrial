import Foundation

// MARK: - Numeric comparison (fixture test rule — not physical tolerance)

public struct FusionNumericPolicy: Codable, Sendable, Equatable {
  public var floatingPointStorage: String
  public var floatingPointAccumulator: String
  public var absoluteEpsilon: Double
  public var relativeEpsilon: Double
  public var roundingPolicy: String
  public var nonFinitePolicy: String
  public var deterministicOrdering: String
  public var policyID: String

  /// Legacy single-epsilon field retained for digest compatibility with earlier Phase 4C drafts.
  public var comparisonEpsilon: Double { absoluteEpsilon }

  public static let fixture = FusionNumericPolicy(
    floatingPointStorage: "float64",
    floatingPointAccumulator: "float64",
    absoluteEpsilon: 1e-7,
    relativeEpsilon: 1e-5,
    roundingPolicy: "CANONICAL_JSON_EXISTING_LAW",
    nonFinitePolicy: "REJECTED_INVALID_VALUE",
    deterministicOrdering: "POINT_ID_ASC_THEN_VOXEL_KEY_ASC",
    policyID: "DFUSE-NUM-POL-FIXTURE-000001"
  )

  public func approximatelyEqual(_ a: Double, _ b: Double) -> Bool {
    guard a.isFinite, b.isFinite else { return false }
    let scale = max(abs(a), abs(b))
    return abs(a - b) < (absoluteEpsilon + relativeEpsilon * scale)
  }

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "floating_point_storage": floatingPointStorage,
      "floating_point_accumulator": floatingPointAccumulator,
      "absolute_epsilon": absoluteEpsilon,
      "relative_epsilon": relativeEpsilon,
      "comparison_epsilon": comparisonEpsilon,
      "rounding_policy": roundingPolicy,
      "non_finite_policy": nonFinitePolicy,
      "deterministic_ordering": deterministicOrdering,
      "comparison_rule": "|a-b| < (eps_abs + eps_rel * max(|a|,|b|))",
      "note": "Fixture comparison epsilon is a deterministic test rule only — not a physical tolerance",
    ]
  }

  public var digest: String {
    let body = (try? CanonicalJSON.data(dictionary())) ?? Data()
    return ContentHasher.sha256Hex(body)
  }
}

// MARK: - 3×3 PCA (Covariance eigenvalue decomposition)

/// Deterministic Jacobi eigenvalue decomposition for symmetric 3×3 matrices.
public enum FusionMatrix3PCA {
  public struct EigenDecomposition: Sendable {
    /// Ascending eigenvalues λ0 ≤ λ1 ≤ λ2.
    public var eigenvalues: (Double, Double, Double)
    /// Corresponding eigenvectors as columns (nx,ny,nz) triples.
    public var eigenvectors: ((Double, Double, Double), (Double, Double, Double), (Double, Double, Double))
  }

  public static func centroid(_ points: [(Double, Double, Double)]) -> (Double, Double, Double) {
    let n = Double(points.count)
    precondition(n > 0)
    var sx = 0.0, sy = 0.0, sz = 0.0
    for p in points { sx += p.0; sy += p.1; sz += p.2 }
    return (sx / n, sy / n, sz / n)
  }

  public static func covariance(points: [(Double, Double, Double)], centroid: (Double, Double, Double)) -> [Double] {
    // Row-major 3×3 symmetric covariance (1/k) Σ (p-̄p)(p-̄p)^T
    let k = Double(points.count)
    var c = Array(repeating: 0.0, count: 9)
    for p in points {
      let dx = p.0 - centroid.0
      let dy = p.1 - centroid.1
      let dz = p.2 - centroid.2
      c[0] += dx * dx; c[1] += dx * dy; c[2] += dx * dz
      c[3] += dy * dx; c[4] += dy * dy; c[5] += dy * dz
      c[6] += dz * dx; c[7] += dz * dy; c[8] += dz * dz
    }
    for i in 0..<9 { c[i] /= k }
    return c
  }

  public static func decomposeSymmetric(_ m: [Double]) -> EigenDecomposition {
    precondition(m.count == 9)
    // Jacobi rotations on a copy of m (row-major)
    var a = m
    var v = [1.0, 0, 0, 0, 1.0, 0, 0, 0, 1.0] // eigenvector matrix (columns)
    let maxIter = 32
    for _ in 0..<maxIter {
      // Find largest off-diagonal
      var p = 0, q = 1
      var maxAbs = abs(a[1])
      let offs = [(0, 1, 1), (0, 2, 2), (1, 2, 5)]
      for (i, j, idx) in offs {
        let val = abs(a[idx])
        if val > maxAbs { maxAbs = val; p = i; q = j }
      }
      if maxAbs < 1e-15 { break }

      let app = a[p * 3 + p]
      let aqq = a[q * 3 + q]
      let apq = a[p * 3 + q]
      let theta = 0.5 * (aqq - app) / apq
      let t: Double
      if abs(theta) > 1e12 {
        t = 0.5 / theta
      } else {
        t = 1.0 / (abs(theta) + (theta * theta + 1).squareRoot()) * (theta >= 0 ? 1 : -1)
      }
      let c = 1.0 / (1 + t * t).squareRoot()
      let s = t * c
      let tau = s / (1 + c)

      // Rotate a
      a[p * 3 + p] = app - t * apq
      a[q * 3 + q] = aqq + t * apq
      a[p * 3 + q] = 0
      a[q * 3 + p] = 0
      for r in 0..<3 where r != p && r != q {
        let arp = a[r * 3 + p]
        let arq = a[r * 3 + q]
        a[r * 3 + p] = arp - s * (arq + tau * arp)
        a[p * 3 + r] = a[r * 3 + p]
        a[r * 3 + q] = arq + s * (arp - tau * arq)
        a[q * 3 + r] = a[r * 3 + q]
      }

      // Accumulate eigenvectors
      for r in 0..<3 {
        let vrp = v[r * 3 + p]
        let vrq = v[r * 3 + q]
        v[r * 3 + p] = vrp - s * (vrq + tau * vrp)
        v[r * 3 + q] = vrq + s * (vrp - tau * vrq)
      }
    }

    var evals: [(Double, Int)] = [
      (a[0], 0), (a[4], 1), (a[8], 2),
    ]
    evals.sort { $0.0 < $1.0 }
    func col(_ j: Int) -> (Double, Double, Double) {
      (v[0 * 3 + j], v[1 * 3 + j], v[2 * 3 + j])
    }
    return EigenDecomposition(
      eigenvalues: (evals[0].0, evals[1].0, evals[2].0),
      eigenvectors: (col(evals[0].1), col(evals[1].1), col(evals[2].1))
    )
  }

  public static func analyzeNeighborhood(
    points: [(Double, Double, Double)],
    planarRankRatioMin: Double,
    curvatureMax: Double,
    varianceEpsilon: Double
  ) -> (normal: (Double, Double, Double)?, curvature: Double, validityHint: String) {
    guard points.count >= 3 else {
      return (nil, 0, "INSUFFICIENT_NEIGHBORHOOD")
    }
    let bar = centroid(points)
    let c = covariance(points: points, centroid: bar)
    let eig = decomposeSymmetric(c)
    let (l0, l1, l2) = eig.eigenvalues
    let total = l0 + l1 + l2
    if !total.isFinite || total <= varianceEpsilon {
      return (nil, 0, "DEGENERATE_NEIGHBORHOOD")
    }
    let planarRatio = l1 / max(l2, varianceEpsilon)
    if planarRatio < planarRankRatioMin {
      return (nil, l0 / max(total, varianceEpsilon), "DEGENERATE_NEIGHBORHOOD")
    }
    let curvature = l0 / max(total, varianceEpsilon)
    var n = eig.eigenvectors.0 // smallest eigenvalue → normal
    let mag = (n.0 * n.0 + n.1 * n.1 + n.2 * n.2).squareRoot()
    if mag < varianceEpsilon {
      return (nil, curvature, "DEGENERATE_NEIGHBORHOOD")
    }
    n = (n.0 / mag, n.1 / mag, n.2 / mag)
    if curvature > curvatureMax {
      return (n, curvature, "HIGH_CURVATURE_EDGE")
    }
    return (n, curvature, "VALID")
  }
}

// MARK: - Voxel key alias

public typealias VoxelKey = VoxelCoordinate
