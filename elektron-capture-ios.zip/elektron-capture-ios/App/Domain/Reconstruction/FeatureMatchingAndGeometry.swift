import Foundation

// MARK: - Feature matching

public enum MatchDistanceMetric: String, Codable, Sendable, Equatable {
  case l2 = "L2"
}

public enum MatchRejectionReason: String, Codable, Sendable, Equatable {
  case ambiguousMatch = "AMBIGUOUS_MATCH"
  case duplicateFeatureReuse = "DUPLICATE_FEATURE_REUSE"
  case weakDescriptorAgreement = "WEAK_DESCRIPTOR_AGREEMENT"
  case ratioTestFailed = "RATIO_TEST_FAILED"
  case mutualMatchFailed = "MUTUAL_MATCH_FAILED"
  case geometricOutlier = "GEOMETRIC_OUTLIER"
  case crossEpoch = "CROSS_EPOCH_MATCH"
  case crossSession = "CROSS_SESSION_MATCH"
  case incompatibleDimensions = "INCOMPATIBLE_IMAGE_DIMENSIONS"
  case missingDescriptor = "MISSING_DESCRIPTOR"
  case nonFiniteDescriptor = "NON_FINITE_DESCRIPTOR"
  case unsupportedFormat = "UNSUPPORTED_DESCRIPTOR_FORMAT"
}

public struct FeatureMatchPolicy: Equatable, Sendable {
  public var policyID: String
  public var policyVersion: String
  public var maxDescriptorDistance: Double
  public var ratioTestThreshold: Double
  public var requireMutual: Bool
  public var metric: MatchDistanceMetric

  public static let fixture = FeatureMatchPolicy(
    policyID: "FEAT-MATCH-POL-FIXTURE-000001",
    policyVersion: "1.0.0-phase4b-fixture",
    maxDescriptorDistance: 0.05,
    ratioTestThreshold: 0.8,
    requireMutual: true,
    metric: .l2
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "policy_version": policyVersion,
      "max_descriptor_distance": maxDescriptorDistance,
      "ratio_test_threshold": ratioTestThreshold,
      "require_mutual": requireMutual,
      "metric": metric.rawValue,
      "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
    ]
  }
}

public struct FeatureMatchCandidate: Equatable, Sendable {
  public var sourceFeatureID: String
  public var destinationFeatureID: String
  public var distance: Double
}

public struct FeatureMatch: Equatable, Sendable {
  public var matchID: String
  public var sourceFeatureID: String
  public var destinationFeatureID: String
  public var descriptorDistance: Double
  public var ratioTestPassed: Bool
  public var mutualConsistent: Bool
  public var geometricValidated: Bool
  public var confidence: String
  public var policyID: String
  public var derivationID: String

  public func dictionary() -> [String: Any] {
    [
      "match_id": matchID,
      "source_feature_id": sourceFeatureID,
      "destination_feature_id": destinationFeatureID,
      "descriptor_distance": descriptorDistance,
      "ratio_test_result": ratioTestPassed,
      "mutual_consistency_result": mutualConsistent,
      "spatial_geometric_validation_result": geometricValidated,
      "confidence_classification": confidence,
      "policy_id": policyID,
      "derivation_id": derivationID,
    ]
  }
}

public struct MatchRejectionRecord: Equatable, Sendable {
  public var matchID: String
  public var reason: MatchRejectionReason
  public var detail: String

  public func dictionary() -> [String: Any] {
    ["match_id": matchID, "reason": reason.rawValue, "detail": detail]
  }
}

public struct FramePairCorrespondenceSet: Equatable, Sendable {
  public var sourceCameraSampleID: String
  public var destinationCameraSampleID: String
  public var accepted: [FeatureMatch]
  public var rejected: [MatchRejectionRecord]

  public func dictionary() -> [String: Any] {
    [
      "source_camera_sample_id": sourceCameraSampleID,
      "destination_camera_sample_id": destinationCameraSampleID,
      "accepted": accepted.sorted { $0.matchID < $1.matchID }.map { $0.dictionary() },
      "rejected": rejected.sorted { $0.matchID < $1.matchID }.map { $0.dictionary() },
      "accepted_match_count": accepted.count,
      "rejected_match_count": rejected.count,
    ]
  }
}

public struct FeatureMatchResult: Equatable, Sendable {
  public var pairs: [FramePairCorrespondenceSet]
  public var policy: FeatureMatchPolicy

  public var acceptedCount: Int { pairs.reduce(0) { $0 + $1.accepted.count } }
  public var rejectedCount: Int { pairs.reduce(0) { $0 + $1.rejected.count } }

  public func dictionary() -> [String: Any] {
    [
      "pairs": pairs.sorted {
        ($0.sourceCameraSampleID, $0.destinationCameraSampleID) < ($1.sourceCameraSampleID, $1.destinationCameraSampleID)
      }.map { $0.dictionary() },
      "policy": policy.dictionary(),
      "accepted_match_count": acceptedCount,
      "rejected_match_count": rejectedCount,
      "schema_id": "FeatureMatchResult",
      "schema_version": "1.0.0-phase4b-fixture",
    ]
  }
}

public struct FeatureMatcher: Sendable {
  public var policy: FeatureMatchPolicy

  public init(policy: FeatureMatchPolicy = .fixture) {
    self.policy = policy
  }

  public func match(
    source: FrameFeatureSet,
    destination: FrameFeatureSet,
    geometricValidatedIDs: Set<String> = []
  ) throws -> FramePairCorrespondenceSet {
    var rejected: [MatchRejectionRecord] = []
    var accepted: [FeatureMatch] = []

    // Dimension / epoch / session checks
    for s in source.observations {
      if s.frameEpochID != destination.observations.first?.frameEpochID {
        rejected.append(MatchRejectionRecord(matchID: "PAIR-EPOCH", reason: .crossEpoch, detail: "\(s.frameEpochID)"))
        return FramePairCorrespondenceSet(
          sourceCameraSampleID: source.cameraSampleID,
          destinationCameraSampleID: destination.cameraSampleID,
          accepted: [],
          rejected: rejected
        )
      }
      if s.sessionRunID != destination.observations.first?.sessionRunID {
        rejected.append(MatchRejectionRecord(matchID: "PAIR-SESSION", reason: .crossSession, detail: "\(s.sessionRunID)"))
        return FramePairCorrespondenceSet(
          sourceCameraSampleID: source.cameraSampleID,
          destinationCameraSampleID: destination.cameraSampleID,
          accepted: [],
          rejected: rejected
        )
      }
    }

    // Build forward nearest/second-nearest
    var forward: [(FeatureObservation, FeatureObservation, Double, Double)] = []
    for s in source.observations.sorted(by: { $0.featureObservationID < $1.featureObservationID }) {
      if s.descriptor.values.isEmpty {
        rejected.append(MatchRejectionRecord(matchID: s.featureObservationID, reason: .missingDescriptor, detail: "source"))
        continue
      }
      if !s.descriptor.isFinite {
        rejected.append(MatchRejectionRecord(matchID: s.featureObservationID, reason: .nonFiniteDescriptor, detail: "source"))
        continue
      }
      if s.descriptor.format != FeatureDetectionPolicy.fixture.descriptorFormat {
        rejected.append(MatchRejectionRecord(matchID: s.featureObservationID, reason: .unsupportedFormat, detail: s.descriptor.format))
        continue
      }

      var dists: [(FeatureObservation, Double)] = []
      for d in destination.observations {
        if !d.descriptor.isFinite {
          rejected.append(MatchRejectionRecord(matchID: d.featureObservationID, reason: .nonFiniteDescriptor, detail: "destination"))
          continue
        }
        let dist = l2(s.descriptor.values, d.descriptor.values)
        dists.append((d, dist))
      }
      dists.sort { $0.1 < $1.1 }
      guard let best = dists.first else { continue }
      let second = dists.count > 1 ? dists[1].1 : Double.greatestFiniteMagnitude
      forward.append((s, best.0, best.1, second))
    }

    // Mutual map destination -> best source
    var reverseBest: [String: (String, Double)] = [:]
    for d in destination.observations {
      var bestSID: String?
      var bestDist = Double.greatestFiniteMagnitude
      for s in source.observations {
        let dist = l2(s.descriptor.values, d.descriptor.values)
        if dist < bestDist {
          bestDist = dist
          bestSID = s.featureObservationID
        }
      }
      if let bestSID {
        reverseBest[d.featureObservationID] = (bestSID, bestDist)
      }
    }

    var usedSource = Set<String>()
    var usedDest = Set<String>()

    for (s, d, dist, second) in forward.sorted(by: { $0.0.featureObservationID < $1.0.featureObservationID }) {
      let mid = "MATCH-\(s.featureObservationID)-\(d.featureObservationID)"
      if dist > policy.maxDescriptorDistance {
        rejected.append(MatchRejectionRecord(matchID: mid, reason: .weakDescriptorAgreement, detail: String(dist)))
        continue
      }
      let ratioOK = second.isInfinite || (dist / second) <= policy.ratioTestThreshold
      if !ratioOK {
        rejected.append(MatchRejectionRecord(matchID: mid, reason: .ratioTestFailed, detail: "\(dist)/\(second)"))
        continue
      }
      let mutual = reverseBest[d.featureObservationID]?.0 == s.featureObservationID
      if policy.requireMutual && !mutual {
        rejected.append(MatchRejectionRecord(matchID: mid, reason: .mutualMatchFailed, detail: d.featureObservationID))
        continue
      }
      if usedSource.contains(s.featureObservationID) || usedDest.contains(d.featureObservationID) {
        rejected.append(MatchRejectionRecord(matchID: mid, reason: .duplicateFeatureReuse, detail: "\(s.featureObservationID)->\(d.featureObservationID)"))
        continue
      }
      // Ambiguous: near-tied second nearest within epsilon of best
      if abs(dist - second) < 1e-12 && second.isFinite {
        rejected.append(MatchRejectionRecord(matchID: mid, reason: .ambiguousMatch, detail: "tied"))
        continue
      }

      let geomOK = geometricValidatedIDs.isEmpty
        || geometricValidatedIDs.contains(mid)
        || (s.fixtureLandmarkID != nil && s.fixtureLandmarkID == d.fixtureLandmarkID)
      if !geomOK {
        rejected.append(MatchRejectionRecord(matchID: mid, reason: .geometricOutlier, detail: mid))
        continue
      }

      usedSource.insert(s.featureObservationID)
      usedDest.insert(d.featureObservationID)
      accepted.append(
        FeatureMatch(
          matchID: mid,
          sourceFeatureID: s.featureObservationID,
          destinationFeatureID: d.featureObservationID,
          descriptorDistance: dist,
          ratioTestPassed: ratioOK,
          mutualConsistent: mutual,
          geometricValidated: geomOK,
          confidence: dist < 1e-9 ? "HIGH" : "MEDIUM",
          policyID: policy.policyID,
          derivationID: "DER-\(mid)"
        )
      )
    }

    return FramePairCorrespondenceSet(
      sourceCameraSampleID: source.cameraSampleID,
      destinationCameraSampleID: destination.cameraSampleID,
      accepted: accepted.sorted { $0.matchID < $1.matchID },
      rejected: rejected
    )
  }

  private func l2(_ a: [Double], _ b: [Double]) -> Double {
    let n = min(a.count, b.count)
    var s = 0.0
    for i in 0..<n {
      let d = a[i] - b[i]
      s += d * d
    }
    return s.squareRoot()
  }
}

// MARK: - Geometric consistency

public enum CorrespondenceGeometryModel: String, Codable, Sendable, Equatable {
  case knownPlanarHomography = "KNOWN_PLANAR_HOMOGRAPHY"
  case knownRigidFixtureTransform = "KNOWN_RIGID_FIXTURE_TRANSFORM"
}

public struct GeometricResidualRecord: Equatable, Sendable {
  public var matchID: String
  public var residualPixels: Double
  public var model: CorrespondenceGeometryModel

  public func dictionary() -> [String: Any] {
    ["match_id": matchID, "residual_pixels": residualPixels, "model": model.rawValue]
  }
}

public struct GeometricInlierSet: Equatable, Sendable {
  public var matchIDs: [String]
  public var residuals: [GeometricResidualRecord]
}

public struct GeometricOutlierSet: Equatable, Sendable {
  public var matchIDs: [String]
  public var residuals: [GeometricResidualRecord]
  public var reasons: [String]
}

public struct GeometricValidationResult: Equatable, Sendable {
  public var model: CorrespondenceGeometryModel
  public var inliers: GeometricInlierSet
  public var outliers: GeometricOutlierSet
  public var policyID: String

  public func dictionary() -> [String: Any] {
    [
      "model": model.rawValue,
      "inlier_match_ids": inliers.matchIDs.sorted(),
      "outlier_match_ids": outliers.matchIDs.sorted(),
      "inlier_residuals": inliers.residuals.map { $0.dictionary() },
      "outlier_residuals": outliers.residuals.map { $0.dictionary() },
      "outlier_reasons": outliers.reasons,
      "geometric_inlier_count": inliers.matchIDs.count,
      "geometric_outlier_count": outliers.matchIDs.count,
      "policy_id": policyID,
      "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
      "note": "Bounded fixture model — not production fundamental/essential matrix claim",
    ]
  }
}

public struct GeometricConsistencyValidator: Sendable {
  public var maxResidualPixels: Double
  public var policyID: String

  public init(maxResidualPixels: Double = 1.0, policyID: String = "GEOM-VAL-POL-FIXTURE-000001") {
    self.maxResidualPixels = maxResidualPixels
    self.policyID = policyID
  }

  /// Fixture planar model: same landmark ID ⇒ inlier with residual 0; otherwise outlier.
  public func validatePlanarLandmarkConsistency(
    matches: [FeatureMatch],
    observationsByID: [String: FeatureObservation]
  ) -> GeometricValidationResult {
    var inlierIDs: [String] = []
    var outlierIDs: [String] = []
    var inlierRes: [GeometricResidualRecord] = []
    var outlierRes: [GeometricResidualRecord] = []
    var reasons: [String] = []

    for m in matches.sorted(by: { $0.matchID < $1.matchID }) {
      let s = observationsByID[m.sourceFeatureID]
      let d = observationsByID[m.destinationFeatureID]
      let same = s?.fixtureLandmarkID != nil && s?.fixtureLandmarkID == d?.fixtureLandmarkID
      let residual = same ? 0.0 : maxResidualPixels + 1.0
      let rec = GeometricResidualRecord(
        matchID: m.matchID,
        residualPixels: residual,
        model: .knownPlanarHomography
      )
      if same && residual <= maxResidualPixels {
        inlierIDs.append(m.matchID)
        inlierRes.append(rec)
      } else {
        outlierIDs.append(m.matchID)
        outlierRes.append(rec)
        reasons.append("\(m.matchID):LANDMARK_MISMATCH_OR_RESIDUAL")
      }
    }
    return GeometricValidationResult(
      model: .knownPlanarHomography,
      inliers: GeometricInlierSet(matchIDs: inlierIDs, residuals: inlierRes),
      outliers: GeometricOutlierSet(matchIDs: outlierIDs, residuals: outlierRes, reasons: reasons),
      policyID: policyID
    )
  }
}
