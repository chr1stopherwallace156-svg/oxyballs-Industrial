import Foundation

// MARK: - Duplicate consolidation

public enum DuplicateSpatialClass: String, Codable, Sendable, Equatable {
  case sameSurfaceContribution = "SAME_SURFACE_CONTRIBUTION"
  case nearbyDistinctPoint = "NEARBY_DISTINCT_POINT"
  case ambiguousSpatialCluster = "AMBIGUOUS_SPATIAL_CLUSTER"
  case contradictoryObservation = "CONTRADICTORY_OBSERVATION"
}

public struct DuplicateConsolidationPolicy: Equatable, Sendable {
  public var policyID: String
  public var mergeSameVoxel: Bool
  public var ambiguousSpreadMeters: Double

  public static let fixture = DuplicateConsolidationPolicy(
    policyID: "DFUSE-DUP-POL-FIXTURE-000001",
    mergeSameVoxel: true,
    ambiguousSpreadMeters: 0.08
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "merge_same_voxel": mergeSameVoxel,
      "ambiguous_spread_meters": ambiguousSpreadMeters,
    ]
  }
}

public struct DuplicatePointGroup: Equatable, Sendable {
  public var groupID: String
  public var voxelID: String
  public var classification: DuplicateSpatialClass
  public var contributionIDs: [String]
  public var sourcePointIDs: [String]

  public func dictionary() -> [String: Any] {
    [
      "group_id": groupID,
      "voxel_id": voxelID,
      "classification": classification.rawValue,
      "contribution_ids": contributionIDs.sorted(),
      "source_point_ids": sourcePointIDs.sorted(),
    ]
  }
}

public struct ConsolidatedPoint: Equatable, Sendable {
  public var fusedPointID: String
  public var x: Double
  public var y: Double
  public var z: Double
  public var contributionCount: Int
  public var sourcePointIDs: [String]
  public var sourceObservationIDs: [String]
  public var confidenceMean: Double
  public var confidenceMin: Double
  public var confidenceMax: Double
  public var voxelID: String
  public var derivationID: String
  public var classification: DuplicateSpatialClass
  public var authority: String

  public func dictionary() -> [String: Any] {
    [
      "fused_point_id": fusedPointID,
      "position": ["x": x, "y": y, "z": z],
      "contribution_count": contributionCount,
      "source_point_ids": sourcePointIDs.sorted(),
      "source_observation_ids": sourceObservationIDs.sorted(),
      "confidence_summary": [
        "mean": confidenceMean,
        "min": confidenceMin,
        "max": confidenceMax,
      ],
      "voxel_id": voxelID,
      "derivation_id": derivationID,
      "classification": classification.rawValue,
      "fusion_output_authority": authority,
    ]
  }
}

public struct DuplicateConsolidationResult: Equatable, Sendable {
  public var groups: [DuplicatePointGroup]
  public var consolidated: [ConsolidatedPoint]
  public var quarantinedGroupIDs: [String]

  public func dictionary() -> [String: Any] {
    [
      "groups": groups.sorted { $0.groupID < $1.groupID }.map { $0.dictionary() },
      "consolidated_points": consolidated.sorted { $0.fusedPointID < $1.fusedPointID }.map { $0.dictionary() },
      "quarantined_group_ids": quarantinedGroupIDs.sorted(),
      "consolidated_point_count": consolidated.count,
    ]
  }
}

public struct SpatialDuplicateDetector: Sendable {
  public var policy: DuplicateConsolidationPolicy

  public init(policy: DuplicateConsolidationPolicy = .fixture) {
    self.policy = policy
  }

  public func consolidate(
    fusion: FusionResult,
    contributions: [FusionPointContribution]
  ) -> DuplicateConsolidationResult {
    let byID = Dictionary(uniqueKeysWithValues: contributions.map { ($0.contributionID, $0) })
    var groups: [DuplicatePointGroup] = []
    var consolidated: [ConsolidatedPoint] = []
    var quarantined: [String] = []

    let occupied = fusion.grid.voxels.values.sorted { $0.coordinate < $1.coordinate }
    for voxel in occupied {
      let ctrs = voxel.contributionIDs.compactMap { byID[$0] }.sorted { $0.contributionID < $1.contributionID }
      guard !ctrs.isEmpty else { continue }
      let groupID = "DUP-\(voxel.coordinate.voxelKey)"

      if voxel.occupancy == .contradictory || voxel.occupancy == .conflicted {
        let g = DuplicatePointGroup(
          groupID: groupID,
          voxelID: voxel.coordinate.voxelKey,
          classification: .contradictoryObservation,
          contributionIDs: ctrs.map(\.contributionID),
          sourcePointIDs: ctrs.map(\.sourceRegisteredPointID)
        )
        groups.append(g)
        quarantined.append(groupID)
        continue
      }

      // Spread among accepted contributions in voxel
      let accepted = ctrs.filter { !$0.rejected && $0.weight > 0 && $0.weight.isFinite }
      guard let pos = voxel.accumulator.weightedPosition, !accepted.isEmpty else { continue }
      if voxel.accumulator.sumW <= 0 {
        continue
      }
      // c_fused = min(1, sum(w_i) / normalization_factor)
      let fusedConf = min(1.0, voxel.accumulator.sumW / ConfidenceWeightingPolicy.fixture.weightNormalizationFactor)
      var maxSpread = 0.0
      for a in accepted {
        for b in accepted where a.contributionID < b.contributionID {
          let dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z
          maxSpread = max(maxSpread, (dx * dx + dy * dy + dz * dz).squareRoot())
        }
      }

      let classification: DuplicateSpatialClass
      if maxSpread > policy.ambiguousSpreadMeters && accepted.count >= 3 {
        classification = .ambiguousSpatialCluster
        let g = DuplicatePointGroup(
          groupID: groupID,
          voxelID: voxel.coordinate.voxelKey,
          classification: classification,
          contributionIDs: accepted.map(\.contributionID),
          sourcePointIDs: accepted.map(\.sourceRegisteredPointID)
        )
        groups.append(g)
        quarantined.append(groupID)
        continue
      }

      let classFinal: DuplicateSpatialClass = accepted.count > 1 ? .sameSurfaceContribution : .nearbyDistinctPoint
      let confs = accepted.map(\.confidence.declaredConfidence)
      let point = ConsolidatedPoint(
        fusedPointID: "FP-\(voxel.coordinate.voxelKey)",
        x: pos.0, y: pos.1, z: pos.2,
        contributionCount: accepted.count,
        sourcePointIDs: accepted.map(\.sourceRegisteredPointID),
        sourceObservationIDs: accepted.map(\.sourceObservationID),
        confidenceMean: fusedConf,
        confidenceMin: confs.min() ?? 0,
        confidenceMax: confs.max() ?? 0,
        voxelID: voxel.coordinate.voxelKey,
        derivationID: "DER-FP-\(voxel.coordinate.voxelKey)",
        classification: classFinal,
        authority: "RECONSTRUCTION_ESTIMATE"
      )
      groups.append(
        DuplicatePointGroup(
          groupID: groupID,
          voxelID: voxel.coordinate.voxelKey,
          classification: classFinal,
          contributionIDs: accepted.map(\.contributionID),
          sourcePointIDs: accepted.map(\.sourceRegisteredPointID)
        )
      )
      consolidated.append(point)
    }

    return DuplicateConsolidationResult(
      groups: groups.sorted { $0.groupID < $1.groupID },
      consolidated: consolidated.sorted { $0.fusedPointID < $1.fusedPointID },
      quarantinedGroupIDs: quarantined.sorted()
    )
  }
}

// MARK: - Outliers

public enum OutlierClassification: String, Codable, Sendable, Equatable {
  case accepted = "ACCEPTED"
  case lowConfidenceRetained = "LOW_CONFIDENCE_RETAINED"
  case rejectedIsolatedOutlier = "REJECTED_ISOLATED_OUTLIER"
  case rejectedInvalidValue = "REJECTED_INVALID_VALUE"
  case rejectedContradictoryObservation = "REJECTED_CONTRADICTORY_OBSERVATION"
  case quarantinedAmbiguousCluster = "QUARANTINED_AMBIGUOUS_CLUSTER"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
  case insufficientNeighborhood = "INSUFFICIENT_NEIGHBORHOOD"
}

public struct OutlierDetectionPolicy: Equatable, Sendable {
  public var policyID: String
  public var kNeighbors: Int
  public var stdDevMultiplier: Double
  public var minNeighbors: Int
  public var lowConfidenceThreshold: Double
  public var voxelSizeMeters: Double
  public var searchRingVoxels: Int

  public static let fixture = OutlierDetectionPolicy(
    policyID: "DFUSE-OUT-POL-FIXTURE-000001",
    kNeighbors: 4,
    stdDevMultiplier: 2.0,
    minNeighbors: 1,
    lowConfidenceThreshold: 0.35,
    voxelSizeMeters: 0.005,
    searchRingVoxels: 8
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "k_neighbors": kNeighbors,
      "std_dev_multiplier": stdDevMultiplier,
      "min_neighbors": minNeighbors,
      "low_confidence_threshold": lowConfidenceThreshold,
      "voxel_size_meters": voxelSizeMeters,
      "search_ring_voxels": searchRingVoxels,
      "spatial_query": "voxel_index_backed_knn",
    ]
  }
}

public struct OutlierRecord: Equatable, Sendable {
  public var recordID: String
  public var subjectID: String
  public var classification: OutlierClassification
  public var detail: String

  public func dictionary() -> [String: Any] {
    [
      "record_id": recordID,
      "subject_id": subjectID,
      "classification": classification.rawValue,
      "detail": detail,
    ]
  }
}

public struct PointFilteringResult: Equatable, Sendable {
  public var records: [OutlierRecord]
  public var retainedPointIDs: [String]
  public var rejectedPointIDs: [String]
  public var quarantinedPointIDs: [String]

  public func dictionary() -> [String: Any] {
    [
      "records": records.sorted { $0.recordID < $1.recordID }.map { $0.dictionary() },
      "retained_point_ids": retainedPointIDs.sorted(),
      "rejected_point_ids": rejectedPointIDs.sorted(),
      "quarantined_point_ids": quarantinedPointIDs.sorted(),
    ]
  }
}

/// Voxel-index backed k-NN outlier detector (no all-pairs O(n²) runtime path).
public struct PointOutlierDetector: Sendable {
  public var policy: OutlierDetectionPolicy

  public init(policy: OutlierDetectionPolicy = .fixture) {
    self.policy = policy
  }

  private func voxelKey(for p: ConsolidatedPoint) -> VoxelCoordinate {
    func q(_ v: Double) -> Int { Int(floor(v / policy.voxelSizeMeters)) }
    return VoxelCoordinate(ix: q(p.x), iy: q(p.y), iz: q(p.z))
  }

  private func buildIndex(_ points: [ConsolidatedPoint]) -> [String: [ConsolidatedPoint]] {
    var index: [String: [ConsolidatedPoint]] = [:]
    for p in points {
      let key = voxelKey(for: p).voxelKey
      index[key, default: []].append(p)
    }
    for k in index.keys {
      index[k]?.sort { $0.fusedPointID < $1.fusedPointID }
    }
    return index
  }

  private func candidates(for p: ConsolidatedPoint, index: [String: [ConsolidatedPoint]]) -> [ConsolidatedPoint] {
    let origin = voxelKey(for: p)
    var out: [ConsolidatedPoint] = []
    let r = policy.searchRingVoxels
    for dx in -r...r {
      for dy in -r...r {
        for dz in -r...r {
          let key = VoxelCoordinate(ix: origin.ix + dx, iy: origin.iy + dy, iz: origin.iz + dz).voxelKey
          if let bucket = index[key] {
            out.append(contentsOf: bucket.filter { $0.fusedPointID != p.fusedPointID })
          }
        }
      }
    }
    return out
  }

  private func meanKNNDistance(for p: ConsolidatedPoint, index: [String: [ConsolidatedPoint]]) -> (mean: Double, effectiveK: Int)? {
    let cand = candidates(for: p, index: index)
    var dists = cand.map { q -> (String, Double) in
      let dx = p.x - q.x, dy = p.y - q.y, dz = p.z - q.z
      return (q.fusedPointID, (dx * dx + dy * dy + dz * dz).squareRoot())
    }
    dists.sort {
      if $0.1 != $1.1 { return $0.1 < $1.1 }
      return $0.0 < $1.0
    }
    let effectiveK = min(policy.kNeighbors, dists.count)
    guard effectiveK >= policy.minNeighbors else { return nil }
    let mean = dists.prefix(effectiveK).map(\.1).reduce(0, +) / Double(effectiveK)
    return (mean, effectiveK)
  }

  public func filter(
    consolidated: [ConsolidatedPoint],
    duplicateResult: DuplicateConsolidationResult,
    contributions: [FusionPointContribution]
  ) -> PointFilteringResult {
    var records: [OutlierRecord] = []
    var retained: [String] = []
    var rejected: [String] = []
    var quarantined: [String] = []

    for gid in duplicateResult.quarantinedGroupIDs {
      let group = duplicateResult.groups.first { $0.groupID == gid }
      let cls: OutlierClassification =
        group?.classification == .contradictoryObservation
        ? .rejectedContradictoryObservation
        : .quarantinedAmbiguousCluster
      records.append(
        OutlierRecord(
          recordID: "OUT-\(gid)",
          subjectID: gid,
          classification: cls,
          detail: group?.classification.rawValue ?? "quarantined"
        )
      )
      quarantined.append(gid)
    }

    let index = buildIndex(consolidated)
    var meanDists: [String: Double] = [:]
    for p in consolidated {
      if let mk = meanKNNDistance(for: p, index: index) {
        meanDists[p.fusedPointID] = mk.mean
      }
    }
    let distValues = Array(meanDists.values)
    let mu = distValues.isEmpty ? 0 : distValues.reduce(0, +) / Double(distValues.count)
    let variance = distValues.isEmpty ? 0 : distValues.map { ($0 - mu) * ($0 - mu) }.reduce(0, +) / Double(max(distValues.count, 1))
    let sigma = variance.squareRoot()
    let threshold = mu + policy.stdDevMultiplier * sigma

    for p in consolidated.sorted(by: { $0.fusedPointID < $1.fusedPointID }) {
      if !p.x.isFinite || !p.y.isFinite || !p.z.isFinite {
        records.append(OutlierRecord(recordID: "OUT-\(p.fusedPointID)", subjectID: p.fusedPointID, classification: .rejectedInvalidValue, detail: "non_finite"))
        rejected.append(p.fusedPointID)
        continue
      }

      guard let mk = meanKNNDistance(for: p, index: index) else {
        records.append(OutlierRecord(recordID: "OUT-\(p.fusedPointID)", subjectID: p.fusedPointID, classification: .insufficientNeighborhood, detail: "effective_k_below_min"))
        // Treat insufficient neighborhood as isolated for fixture isolation case
        if candidates(for: p, index: index).isEmpty {
          records.append(OutlierRecord(recordID: "OUT-ISO-\(p.fusedPointID)", subjectID: p.fusedPointID, classification: .rejectedIsolatedOutlier, detail: "no_voxel_neighbors"))
          rejected.append(p.fusedPointID)
        } else {
          rejected.append(p.fusedPointID)
        }
        continue
      }

      if mk.mean > threshold && mk.mean > 0 {
        records.append(OutlierRecord(recordID: "OUT-\(p.fusedPointID)", subjectID: p.fusedPointID, classification: .rejectedIsolatedOutlier, detail: "d_k=\(mk.mean)>mu+alpha*sigma=\(threshold)"))
        rejected.append(p.fusedPointID)
        continue
      }

      if p.confidenceMean < policy.lowConfidenceThreshold {
        records.append(OutlierRecord(recordID: "OUT-\(p.fusedPointID)", subjectID: p.fusedPointID, classification: .lowConfidenceRetained, detail: "confidence=\(p.confidenceMean)"))
        retained.append(p.fusedPointID)
        continue
      }

      records.append(OutlierRecord(recordID: "OUT-\(p.fusedPointID)", subjectID: p.fusedPointID, classification: .accepted, detail: "ok"))
      retained.append(p.fusedPointID)
    }

    for c in contributions where c.rejected {
      records.append(
        OutlierRecord(
          recordID: "OUT-CTR-\(c.contributionID)",
          subjectID: c.contributionID,
          classification: .rejectedInvalidValue,
          detail: c.rejectionReason?.rawValue ?? "rejected"
        )
      )
    }

    return PointFilteringResult(
      records: records.sorted { $0.recordID < $1.recordID },
      retainedPointIDs: Array(Set(retained)).sorted(),
      rejectedPointIDs: Array(Set(rejected)).sorted(),
      quarantinedPointIDs: Array(Set(quarantined)).sorted()
    )
  }
}

// MARK: - Dynamic / contradictory observations

public enum DynamicObservationDisposition: String, Codable, Sendable, Equatable {
  case staticConsistent = "STATIC_CONSISTENT"
  case possibleDynamicObject = "POSSIBLE_DYNAMIC_OBJECT"
  case possibleOcclusionChange = "POSSIBLE_OCCLUSION_CHANGE"
  case possiblePoseOrCalibrationError = "POSSIBLE_POSE_OR_CALIBRATION_ERROR"
  case depthConflict = "DEPTH_CONFLICT"
  case insufficientEvidence = "INSUFFICIENT_EVIDENCE"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public struct SpatialConflictRecord: Equatable, Sendable {
  public var conflictID: String
  public var voxelID: String
  public var disposition: DynamicObservationDisposition
  public var contributionIDs: [String]
  public var detail: String

  public func dictionary() -> [String: Any] {
    [
      "conflict_id": conflictID,
      "voxel_id": voxelID,
      "disposition": disposition.rawValue,
      "contribution_ids": contributionIDs.sorted(),
      "detail": detail,
      "note": "Provisional fixture classification — not production moving-object segmentation",
    ]
  }
}

public struct ObservationConsistencyAnalyzer: Sendable {
  public init() {}

  public func analyze(
    fusion: FusionResult,
    contributions: [FusionPointContribution],
    contradictionDeltaMeters: Double
  ) -> [SpatialConflictRecord] {
    let byID = Dictionary(uniqueKeysWithValues: contributions.map { ($0.contributionID, $0) })
    var records: [SpatialConflictRecord] = []
    for voxel in fusion.grid.voxels.values.sorted(by: { $0.coordinate < $1.coordinate }) {
      let ctrs = voxel.contributionIDs.compactMap { byID[$0] }
      if voxel.occupancy == .contradictory || voxel.occupancy == .conflicted {
        records.append(
          SpatialConflictRecord(
            conflictID: "SCF-\(voxel.coordinate.voxelKey)",
            voxelID: voxel.coordinate.voxelKey,
            disposition: .depthConflict,
            contributionIDs: ctrs.map(\.contributionID),
            detail: "DYNAMIC_OBSERVATION_CANDIDATE;delta>\(contradictionDeltaMeters);not_proof_of_motion"
          )
        )
        continue
      }
      if ctrs.count >= 2 {
        records.append(
          SpatialConflictRecord(
            conflictID: "SCF-\(voxel.coordinate.voxelKey)",
            voxelID: voxel.coordinate.voxelKey,
            disposition: .staticConsistent,
            contributionIDs: ctrs.map(\.contributionID),
            detail: "consistent_within_policy"
          )
        )
      } else if ctrs.count == 1 {
        records.append(
          SpatialConflictRecord(
            conflictID: "SCF-\(voxel.coordinate.voxelKey)",
            voxelID: voxel.coordinate.voxelKey,
            disposition: .insufficientEvidence,
            contributionIDs: ctrs.map(\.contributionID),
            detail: "single_observation"
          )
        )
      }
    }
    return records.sorted { $0.conflictID < $1.conflictID }
  }
}

// MARK: - Normals

public enum NormalValidityClassification: String, Codable, Sendable, Equatable {
  case valid = "VALID"
  case degenerateNeighborhood = "DEGENERATE_NEIGHBORHOOD"
  case highCurvatureEdge = "HIGH_CURVATURE_EDGE"
  case unorientable = "UNORIENTABLE"
  case insufficientNeighborhood = "INSUFFICIENT_NEIGHBORHOOD"
  case notEstimated = "NOT_ESTIMATED"
}

public struct NormalEstimationPolicy: Equatable, Sendable {
  public var policyID: String
  public var algorithmID: String
  public var algorithmVersion: String
  public var neighborhoodRadius: Double
  public var minNeighbors: Int
  public var kNeighbors: Int
  public var planarRankRatioMin: Double
  public var curvatureMax: Double
  public var varianceEpsilon: Double
  public var orientationConvention: String
  public var voxelSizeMeters: Double
  public var searchRingVoxels: Int

  public static let fixture = NormalEstimationPolicy(
    policyID: "DFUSE-NRM-POL-FIXTURE-000001",
    algorithmID: "ALG-NORMAL-PCA-COV-EIGEN-FIXTURE-V1",
    algorithmVersion: "1.0.0-phase4c-fixture",
    neighborhoodRadius: 0.08,
    minNeighbors: 2,
    kNeighbors: 8,
    planarRankRatioMin: 0.05,
    curvatureMax: 0.35,
    varianceEpsilon: 1e-12,
    orientationConvention: "toward_confidence_weighted_viewing_direction",
    voxelSizeMeters: 0.005,
    searchRingVoxels: 12
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "algorithm_id": algorithmID,
      "algorithm_version": algorithmVersion,
      "neighborhood_radius": neighborhoodRadius,
      "min_neighbors": minNeighbors,
      "k_neighbors": kNeighbors,
      "planar_rank_ratio_min": planarRankRatioMin,
      "curvature_max": curvatureMax,
      "variance_epsilon": varianceEpsilon,
      "orientation_convention": orientationConvention,
      "method": "covariance_matrix_eigenvalue_decomposition_pca",
    ]
  }
}

public struct PointNormal: Equatable, Sendable {
  public var fusedPointID: String
  public var nx: Double
  public var ny: Double
  public var nz: Double
  public var neighborIDs: [String]
  public var algorithmID: String
  public var algorithmVersion: String
  public var neighborhoodPolicy: String
  public var orientationConvention: String
  public var validity: NormalValidityClassification
  public var confidence: Double
  public var derivationID: String

  public func dictionary() -> [String: Any] {
    [
      "fused_point_id": fusedPointID,
      "normal": ["nx": nx, "ny": ny, "nz": nz],
      "contributing_neighbor_ids": neighborIDs.sorted(),
      "algorithm_id": algorithmID,
      "algorithm_version": algorithmVersion,
      "neighborhood_policy": neighborhoodPolicy,
      "orientation_convention": orientationConvention,
      "validity": validity.rawValue,
      "confidence": confidence,
      "derivation_id": derivationID,
      "note": "Derived reconstruction estimate — not engineering metrology",
    ]
  }
}

public struct NormalEstimationResult: Equatable, Sendable {
  public var normals: [PointNormal]
  public var validCount: Int

  public func dictionary() -> [String: Any] {
    [
      "normals": normals.sorted { $0.fusedPointID < $1.fusedPointID }.map { $0.dictionary() },
      "valid_normal_count": validCount,
    ]
  }
}

public struct PointNormalEstimator: Sendable {
  public var policy: NormalEstimationPolicy

  public init(policy: NormalEstimationPolicy = .fixture) {
    self.policy = policy
  }

  private func voxelKey(for p: ConsolidatedPoint) -> VoxelCoordinate {
    func q(_ v: Double) -> Int { Int(floor(v / policy.voxelSizeMeters)) }
    return VoxelCoordinate(ix: q(p.x), iy: q(p.y), iz: q(p.z))
  }

  private func buildIndex(_ points: [ConsolidatedPoint]) -> [String: [ConsolidatedPoint]] {
    var index: [String: [ConsolidatedPoint]] = [:]
    for p in points {
      index[voxelKey(for: p).voxelKey, default: []].append(p)
    }
    return index
  }

  private func neighborhood(for p: ConsolidatedPoint, index: [String: [ConsolidatedPoint]], all: [ConsolidatedPoint]) -> [ConsolidatedPoint] {
    let origin = voxelKey(for: p)
    var cand: [ConsolidatedPoint] = []
    let r = policy.searchRingVoxels
    for dx in -r...r {
      for dy in -r...r {
        for dz in -r...r {
          let key = VoxelCoordinate(ix: origin.ix + dx, iy: origin.iy + dy, iz: origin.iz + dz).voxelKey
          if let bucket = index[key] {
            cand.append(contentsOf: bucket.filter { $0.fusedPointID != p.fusedPointID })
          }
        }
      }
    }
    var scored = cand.map { q -> (ConsolidatedPoint, Double) in
      let dx = p.x - q.x, dy = p.y - q.y, dz = p.z - q.z
      return (q, (dx * dx + dy * dy + dz * dz).squareRoot())
    }.filter { $0.1 <= policy.neighborhoodRadius }
    scored.sort {
      if $0.1 != $1.1 { return $0.1 < $1.1 }
      return $0.0.fusedPointID < $1.0.fusedPointID
    }
    let k = min(policy.kNeighbors, scored.count)
    return scored.prefix(k).map(\.0)
  }

  public func estimate(points: [ConsolidatedPoint]) -> NormalEstimationResult {
    let index = buildIndex(points)
    var normals: [PointNormal] = []
    for p in points.sorted(by: { $0.fusedPointID < $1.fusedPointID }) {
      let neighbors = neighborhood(for: p, index: index, all: points)
      if neighbors.count < policy.minNeighbors {
        normals.append(
          PointNormal(
            fusedPointID: p.fusedPointID,
            nx: 0, ny: 0, nz: 0,
            neighborIDs: neighbors.map(\.fusedPointID),
            algorithmID: policy.algorithmID,
            algorithmVersion: policy.algorithmVersion,
            neighborhoodPolicy: policy.policyID,
            orientationConvention: policy.orientationConvention,
            validity: .insufficientNeighborhood,
            confidence: 0,
            derivationID: "DER-NRM-\(p.fusedPointID)"
          )
        )
        continue
      }

      // Include query point in covariance neighborhood
      var cloud = [(p.x, p.y, p.z)] + neighbors.map { ($0.x, $0.y, $0.z) }
      cloud = Array(cloud.prefix(policy.kNeighbors + 1))
      let analysis = FusionMatrix3PCA.analyzeNeighborhood(
        points: cloud,
        planarRankRatioMin: policy.planarRankRatioMin,
        curvatureMax: policy.curvatureMax,
        varianceEpsilon: policy.varianceEpsilon
      )

      guard var n = analysis.normal else {
        let validity: NormalValidityClassification =
          analysis.validityHint == "DEGENERATE_NEIGHBORHOOD" ? .degenerateNeighborhood : .insufficientNeighborhood
        normals.append(
          PointNormal(
            fusedPointID: p.fusedPointID,
            nx: 0, ny: 0, nz: 0,
            neighborIDs: neighbors.map(\.fusedPointID),
            algorithmID: policy.algorithmID,
            algorithmVersion: policy.algorithmVersion,
            neighborhoodPolicy: policy.policyID,
            orientationConvention: policy.orientationConvention,
            validity: validity,
            confidence: 0,
            derivationID: "DER-NRM-\(p.fusedPointID)"
          )
        )
        continue
      }

      // Orient toward approximate viewing direction (camera looks +Z optical → prefer -Z world for plane at +Z).
      let view = (0.0, 0.0, -1.0)
      let dot = n.0 * view.0 + n.1 * view.1 + n.2 * view.2
      if abs(dot) < 1e-9 {
        normals.append(
          PointNormal(
            fusedPointID: p.fusedPointID,
            nx: n.0, ny: n.1, nz: n.2,
            neighborIDs: neighbors.map(\.fusedPointID),
            algorithmID: policy.algorithmID,
            algorithmVersion: policy.algorithmVersion,
            neighborhoodPolicy: policy.policyID,
            orientationConvention: policy.orientationConvention,
            validity: .unorientable,
            confidence: 0,
            derivationID: "DER-NRM-\(p.fusedPointID)"
          )
        )
        continue
      }
      if dot < 0 { n = (-n.0, -n.1, -n.2) }

      let validity: NormalValidityClassification =
        analysis.validityHint == "HIGH_CURVATURE_EDGE" ? .highCurvatureEdge : .valid
      normals.append(
        PointNormal(
          fusedPointID: p.fusedPointID,
          nx: n.0, ny: n.1, nz: n.2,
          neighborIDs: neighbors.map(\.fusedPointID),
          algorithmID: policy.algorithmID,
          algorithmVersion: policy.algorithmVersion,
          neighborhoodPolicy: policy.policyID,
          orientationConvention: policy.orientationConvention,
          validity: validity,
          confidence: max(0, 1.0 - analysis.curvature),
          derivationID: "DER-NRM-\(p.fusedPointID)"
        )
      )
    }
    let valid = normals.filter { $0.validity == .valid || $0.validity == .highCurvatureEdge }.count
    return NormalEstimationResult(normals: normals, validCount: valid)
  }
}

// MARK: - Density / gaps

public enum DensityClassification: String, Codable, Sendable, Equatable {
  case denseForFixturePolicy = "DENSE_FOR_FIXTURE_POLICY"
  case adequateForFixturePolicy = "ADEQUATE_FOR_FIXTURE_POLICY"
  case sparse = "SPARSE"
  case unobserved = "UNOBSERVED"
  case lowConfidence = "LOW_CONFIDENCE"
  case contradictory = "CONTRADICTORY"
  case additionalCaptureRecommended = "ADDITIONAL_CAPTURE_RECOMMENDED"
}

public struct PointDensityRecord: Equatable, Sendable {
  public var regionID: String
  public var classification: DensityClassification
  public var pointCount: Int
  public var meanNeighborDistance: Double

  public func dictionary() -> [String: Any] {
    [
      "region_id": regionID,
      "classification": classification.rawValue,
      "point_count": pointCount,
      "mean_neighbor_distance": meanNeighborDistance,
    ]
  }
}

public enum SpatialGapClassification: String, Codable, Sendable, Equatable {
  case sparse = "SPARSE"
  case unobserved = "UNOBSERVED"
  case lowConfidence = "LOW_CONFIDENCE"
  case contradictory = "CONTRADICTORY"
  case additionalCaptureRecommended = "ADDITIONAL_CAPTURE_RECOMMENDED"
}

public struct SpatialGap: Equatable, Sendable {
  public var gapID: String
  public var classification: SpatialGapClassification
  public var detail: String
  public var boundsMin: [Double]
  public var boundsMax: [Double]

  public func dictionary() -> [String: Any] {
    [
      "gap_id": gapID,
      "classification": classification.rawValue,
      "detail": detail,
      "bounds_min": boundsMin,
      "bounds_max": boundsMax,
    ]
  }
}

public struct FusionCoverageSummary: Equatable, Sendable {
  public var inputRegisteredPointCount: Int
  public var acceptedContributionCount: Int
  public var rejectedContributionCount: Int
  public var quarantinedContributionCount: Int
  public var occupiedVoxelCount: Int
  public var consolidatedPointCount: Int
  public var pointsWithValidNormals: Int
  public var meanDensityNeighborDistance: Double
  public var boundingBoxMin: [Double]
  public var boundingBoxMax: [Double]
  public var lineageCompleteness: Double

  public func dictionary() -> [String: Any] {
    [
      "input_registered_point_count": inputRegisteredPointCount,
      "accepted_contribution_count": acceptedContributionCount,
      "rejected_contribution_count": rejectedContributionCount,
      "quarantined_contribution_count": quarantinedContributionCount,
      "occupied_voxel_count": occupiedVoxelCount,
      "consolidated_point_count": consolidatedPointCount,
      "points_with_valid_normals": pointsWithValidNormals,
      "mean_density_neighbor_distance": meanDensityNeighborDistance,
      "bounding_box_min": boundingBoxMin,
      "bounding_box_max": boundingBoxMax,
      "lineage_completeness": lineageCompleteness,
    ]
  }
}

public struct DensePointCloudQualitySummary: Equatable, Sendable {
  public var coverage: FusionCoverageSummary
  public var densityRecords: [PointDensityRecord]
  public var gaps: [SpatialGap]
  public var overallDensity: DensityClassification

  public func dictionary() -> [String: Any] {
    [
      "coverage": coverage.dictionary(),
      "density_records": densityRecords.map { $0.dictionary() },
      "spatial_gaps": gaps.map { $0.dictionary() },
      "overall_density_classification": overallDensity.rawValue,
      "forbidden_claims": [
        "COMPLETE_SURFACE",
        "FULLY_SCANNED",
        "ENGINEERING_COMPLETE",
        "VEHICLE_COMPLETE",
      ],
      "schema_id": "DensePointCloudQualitySummary",
      "schema_version": "1.0.0-phase4c-fixture",
    ]
  }
}

public struct DenseFusionCoverageAnalyzer: Sendable {
  public init() {}

  public func summarize(
    inputPointCount: Int,
    contributions: [FusionPointContribution],
    fusion: FusionResult,
    retained: [ConsolidatedPoint],
    filtering: PointFilteringResult,
    normals: NormalEstimationResult,
    conflicts: [SpatialConflictRecord]
  ) -> DensePointCloudQualitySummary {
    let accepted = contributions.filter { !$0.rejected }.count
    let rejected = contributions.filter(\.rejected).count
    let xs = retained.map(\.x), ys = retained.map(\.y), zs = retained.map(\.z)
    var neighborDists: [Double] = []
    for (i, p) in retained.enumerated() {
      var best = Double.infinity
      for (j, q) in retained.enumerated() where i != j {
        let dx = p.x - q.x, dy = p.y - q.y, dz = p.z - q.z
        best = min(best, (dx * dx + dy * dy + dz * dz).squareRoot())
      }
      if best.isFinite { neighborDists.append(best) }
    }
    let meanD = neighborDists.isEmpty ? 0 : neighborDists.reduce(0, +) / Double(neighborDists.count)

    let overall: DensityClassification
    if retained.count >= 12 && meanD <= 0.08 {
      overall = .denseForFixturePolicy
    } else if retained.count >= 8 {
      overall = .adequateForFixturePolicy
    } else if retained.count >= 3 {
      overall = .sparse
    } else {
      overall = .additionalCaptureRecommended
    }

    var gaps: [SpatialGap] = []
    if overall == .sparse || overall == .additionalCaptureRecommended {
      gaps.append(
        SpatialGap(
          gapID: "GAP-SPARSE-000001",
          classification: .sparse,
          detail: "fixture_sparse_or_capture_recommended",
          boundsMin: [xs.min() ?? 0, ys.min() ?? 0, zs.min() ?? 0],
          boundsMax: [xs.max() ?? 0, ys.max() ?? 0, zs.max() ?? 0]
        )
      )
    }
    for c in conflicts where c.disposition == .depthConflict {
      gaps.append(
        SpatialGap(
          gapID: "GAP-\(c.conflictID)",
          classification: .contradictory,
          detail: c.detail,
          boundsMin: [0, 0, 0],
          boundsMax: [0, 0, 0]
        )
      )
    }
    if filtering.retainedPointIDs.isEmpty == false {
      let low = retained.filter { $0.confidenceMean < OutlierDetectionPolicy.fixture.lowConfidenceThreshold }
      if !low.isEmpty {
        gaps.append(
          SpatialGap(
            gapID: "GAP-LOWCONF-000001",
            classification: .lowConfidence,
            detail: "low_confidence_retained=\(low.count)",
            boundsMin: [low.map(\.x).min() ?? 0, low.map(\.y).min() ?? 0, low.map(\.z).min() ?? 0],
            boundsMax: [low.map(\.x).max() ?? 0, low.map(\.y).max() ?? 0, low.map(\.z).max() ?? 0]
          )
        )
      }
    }

    let densityRecords = [
      PointDensityRecord(
        regionID: "REGION-PRIMARY-SURFACE",
        classification: overall,
        pointCount: retained.count,
        meanNeighborDistance: meanD
      )
    ]

    let coverage = FusionCoverageSummary(
      inputRegisteredPointCount: inputPointCount,
      acceptedContributionCount: accepted,
      rejectedContributionCount: rejected,
      quarantinedContributionCount: filtering.quarantinedPointIDs.count,
      occupiedVoxelCount: fusion.grid.occupiedCount,
      consolidatedPointCount: retained.count,
      pointsWithValidNormals: normals.validCount,
      meanDensityNeighborDistance: meanD,
      boundingBoxMin: [xs.min() ?? 0, ys.min() ?? 0, zs.min() ?? 0],
      boundingBoxMax: [xs.max() ?? 0, ys.max() ?? 0, zs.max() ?? 0],
      lineageCompleteness: 1.0
    )

    return DensePointCloudQualitySummary(
      coverage: coverage,
      densityRecords: densityRecords,
      gaps: gaps.sorted { $0.gapID < $1.gapID },
      overallDensity: overall
    )
  }
}
