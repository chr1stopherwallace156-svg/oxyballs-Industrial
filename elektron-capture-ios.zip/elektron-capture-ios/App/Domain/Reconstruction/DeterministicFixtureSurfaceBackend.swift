import Foundation

/// Deterministic 2.5D projected-XY Delaunay meshing for Phase 4D fixture surfaces (Z≈2).
/// Algorithm: Bowyer–Watson Delaunay on XY projection (not global 3D Delaunay / Poisson).
/// Internal spatial math uses Double; exporters apply Float32 / decimal text at boundaries.
public struct DeterministicFixtureSurfaceBackend: Sendable {
  public let backendID = "DeterministicFixtureSurfaceBackend"
  public var policy: SurfaceMeshingPolicy

  public init(policy: SurfaceMeshingPolicy = .fixture) {
    self.policy = policy
  }

  public func reconstruct(
    fusedCloud: FusedPointCloud,
    normals: [PointNormal],
    gaps: [SpatialGap],
    quarantinedRegions: [String],
    configurationDigest: String
  ) throws -> SurfaceReconstructionResult {
    let quarantine = Set(quarantinedRegions)
    let normalsByID = Dictionary(uniqueKeysWithValues: normals.map { ($0.fusedPointID, $0) })

    var vertices: [SurfaceVertex] = []
    for p in fusedCloud.points.sorted(by: { $0.fusedPointID < $1.fusedPointID }) {
      guard p.x.isFinite, p.y.isFinite, p.z.isFinite else { continue }
      if quarantine.contains(p.fusedPointID) || quarantine.contains(p.voxelID) { continue }
      guard let n = normalsByID[p.fusedPointID] else { continue }
      guard n.validity == .valid || n.validity == .highCurvatureEdge else { continue }
      guard n.nx.isFinite, n.ny.isFinite, n.nz.isFinite else { continue }
      vertices.append(
        SurfaceVertex(
          vertexID: "SV-\(p.fusedPointID)",
          fusedPointID: p.fusedPointID,
          x: p.x, y: p.y, z: p.z,
          nx: n.nx, ny: n.ny, nz: n.nz,
          confidence: p.confidenceMean,
          authority: "RECONSTRUCTION_ESTIMATE"
        )
      )
    }
    vertices.sort { $0.vertexID < $1.vertexID }
    if vertices.count > 10_000 {
      throw SurfaceFailure.resourceBound("max_input_points")
    }

    // Stable sort for Delaunay insertion: (x, y, fused_point_id)
    let sortedForInsert = vertices.sorted {
      if $0.x != $1.x { return $0.x < $1.x }
      if $0.y != $1.y { return $0.y < $1.y }
      return $0.fusedPointID < $1.fusedPointID
    }

    let rawTris = DeterministicDelaunay2D.triangulate(
      points: sortedForInsert.map { ($0.x, $0.y) }
    )

    let vertexByIndex = sortedForInsert
    var valid: [SurfaceTriangle] = []
    var rejected: [RejectedTriangleRecord] = []
    var triCounter = 0
    var rejCounter = 0

    let gapAABBs: [([Double], [Double])] = gaps.map { ($0.boundsMin, $0.boundsMax) }
      + [(policy.intentionalHoleAABBMin, policy.intentionalHoleAABBMax)]

    for (i0, i1, i2) in rawTris {
      let v0 = vertexByIndex[i0]
      let v1 = vertexByIndex[i1]
      let v2 = vertexByIndex[i2]
      let vids = [v0.vertexID, v1.vertexID, v2.vertexID]

      if Set(vids).count < 3 {
        rejCounter += 1
        rejected.append(
          RejectedTriangleRecord(
            recordID: String(format: "REJ-%06d", rejCounter),
            vertexIDs: vids,
            reason: .duplicateVertices,
            detail: "duplicate_vertices",
            centroid: centroid3(v0, v1, v2)
          )
        )
        continue
      }

      // Winding + normal consistency (CCW vs outward mean vertex normal)
      let wind = resolveWinding(v0, v1, v2)
      guard case .oriented(let o0, let o1, let o2) = wind else {
        if case .rejected(let reason, let detail, let rVids, let centroid) = wind {
          rejCounter += 1
          rejected.append(
            RejectedTriangleRecord(
              recordID: String(format: "REJ-%06d", rejCounter),
              vertexIDs: rVids,
              reason: reason,
              detail: detail,
              centroid: centroid
            )
          )
        }
        continue
      }
      let oriented = (o0, o1, o2)
      let area = triangleArea(oriented.0, oriented.1, oriented.2)
      let c = centroid3(oriented.0, oriented.1, oriented.2)

      if area < policy.minTriangleAreaMeters2 {
        rejCounter += 1
        rejected.append(
          RejectedTriangleRecord(
            recordID: String(format: "REJ-%06d", rejCounter),
            vertexIDs: [oriented.0.vertexID, oriented.1.vertexID, oriented.2.vertexID],
            reason: .nearZeroArea,
            detail: "area=\(area)",
            centroid: c
          )
        )
        continue
      }

      if isCollinear(oriented.0, oriented.1, oriented.2) {
        rejCounter += 1
        rejected.append(
          RejectedTriangleRecord(
            recordID: String(format: "REJ-%06d", rejCounter),
            vertexIDs: [oriented.0.vertexID, oriented.1.vertexID, oriented.2.vertexID],
            reason: .degenerateCollinear,
            detail: "collinear",
            centroid: c
          )
        )
        continue
      }

      let e01 = dist(oriented.0, oriented.1)
      let e12 = dist(oriented.1, oriented.2)
      let e20 = dist(oriented.2, oriented.0)
      if max(e01, max(e12, e20)) > policy.maxEdgeLengthMeters {
        rejCounter += 1
        rejected.append(
          RejectedTriangleRecord(
            recordID: String(format: "REJ-%06d", rejCounter),
            vertexIDs: [oriented.0.vertexID, oriented.1.vertexID, oriented.2.vertexID],
            reason: .excessiveEdgeLength,
            detail: "max_edge=\(max(e01, max(e12, e20)))",
            centroid: c
          )
        )
        continue
      }

      if let gapHit = gapAABBs.first(where: { aabbContains($0.0, $0.1, c) }) {
        let isIntentional = gapHit.0 == policy.intentionalHoleAABBMin
        rejCounter += 1
        rejected.append(
          RejectedTriangleRecord(
            recordID: String(format: "REJ-%06d", rejCounter),
            vertexIDs: [oriented.0.vertexID, oriented.1.vertexID, oriented.2.vertexID],
            reason: isIntentional ? .intentionalOpenBoundary : .gapBridging,
            detail: isIntentional ? "intentional_fixture_hole" : "gap_aabb",
            centroid: c
          )
        )
        continue
      }

      triCounter += 1
      let finalN = faceNormal(oriented.0, oriented.1, oriented.2)
      valid.append(
        SurfaceTriangle(
          triangleID: String(format: "ST-%06d", triCounter),
          vertexIDs: [oriented.0.vertexID, oriented.1.vertexID, oriented.2.vertexID],
          areaMeters2: triangleArea(oriented.0, oriented.1, oriented.2),
          faceNormal: finalN,
          centroid: centroid3(oriented.0, oriented.1, oriented.2),
          authority: "RECONSTRUCTION_ESTIMATE"
        )
      )
    }

    // Inject deterministic degenerate evaluation for fixture proof (not added to mesh)
    if let first = vertices.first {
      rejCounter += 1
      rejected.append(
        RejectedTriangleRecord(
          recordID: String(format: "REJ-%06d", rejCounter),
          vertexIDs: [first.vertexID, first.vertexID, first.vertexID],
          reason: .duplicateVertices,
          detail: "injected_degenerate_duplicate_vertices_fixture_proof",
          centroid: [first.x, first.y, first.z]
        )
      )
      if vertices.count >= 3 {
        let a = vertices[0], b = vertices[1]
        // collinear synthetic mid along AB in XY with same Z
        let mid = SurfaceVertex(
          vertexID: "SV-INJECT-COLLINEAR",
          fusedPointID: "INJECT-COLLINEAR",
          x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: a.z,
          nx: a.nx, ny: a.ny, nz: a.nz,
          confidence: 0,
          authority: "RECONSTRUCTION_ESTIMATE"
        )
        // Evaluate only — do not add mid as mesh vertex
        rejCounter += 1
        rejected.append(
          RejectedTriangleRecord(
            recordID: String(format: "REJ-%06d", rejCounter),
            vertexIDs: [a.vertexID, b.vertexID, mid.vertexID],
            reason: .degenerateCollinear,
            detail: "injected_degenerate_collinear_fixture_proof",
            centroid: centroid3(a, b, mid)
          )
        )
      }
    }

    valid.sort { $0.triangleID < $1.triangleID }
    rejected.sort { $0.recordID < $1.recordID }

    return SurfaceReconstructionResult(
      vertices: vertices,
      triangles: valid,
      rejected: rejected,
      algorithmID: backendID,
      configurationDigest: configurationDigest
    )
  }

  // MARK: - Geometry helpers

  private func dist(_ a: SurfaceVertex, _ b: SurfaceVertex) -> Double {
    let dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z
    return sqrt(dx * dx + dy * dy + dz * dz)
  }

  private func centroid3(_ a: SurfaceVertex, _ b: SurfaceVertex, _ c: SurfaceVertex) -> [Double] {
    [(a.x + b.x + c.x) / 3.0, (a.y + b.y + c.y) / 3.0, (a.z + b.z + c.z) / 3.0]
  }

  private func triangleArea(_ a: SurfaceVertex, _ b: SurfaceVertex, _ c: SurfaceVertex) -> Double {
    let ab = (b.x - a.x, b.y - a.y, b.z - a.z)
    let ac = (c.x - a.x, c.y - a.y, c.z - a.z)
    let cx = ab.1 * ac.2 - ab.2 * ac.1
    let cy = ab.2 * ac.0 - ab.0 * ac.2
    let cz = ab.0 * ac.1 - ab.1 * ac.0
    return 0.5 * sqrt(cx * cx + cy * cy + cz * cz)
  }

  private func faceNormal(_ a: SurfaceVertex, _ b: SurfaceVertex, _ c: SurfaceVertex) -> [Double] {
    let ab = (b.x - a.x, b.y - a.y, b.z - a.z)
    let ac = (c.x - a.x, c.y - a.y, c.z - a.z)
    var n = (
      ab.1 * ac.2 - ab.2 * ac.1,
      ab.2 * ac.0 - ab.0 * ac.2,
      ab.0 * ac.1 - ab.1 * ac.0
    )
    let len = sqrt(n.0 * n.0 + n.1 * n.1 + n.2 * n.2)
    if len > 1e-15 {
      n = (n.0 / len, n.1 / len, n.2 / len)
    }
    return [n.0, n.1, n.2]
  }

  private enum WindingResolution {
    case oriented(SurfaceVertex, SurfaceVertex, SurfaceVertex)
    case rejected(TriangleRejectionReason, String, [String], [Double])
  }

  /// Enforce CCW winding relative to outward mean vertex normal.
  /// Ambiguous / non-finite / contradictory normals → reject (no arbitrary swap).
  private func resolveWinding(
    _ a: SurfaceVertex, _ b: SurfaceVertex, _ c: SurfaceVertex
  ) -> WindingResolution {
    let vids = [a.vertexID, b.vertexID, c.vertexID]
    let centroid = centroid3(a, b, c)
    let normals = [(a.nx, a.ny, a.nz), (b.nx, b.ny, b.nz), (c.nx, c.ny, c.nz)]
    for n in normals {
      if !n.0.isFinite || !n.1.isFinite || !n.2.isFinite {
        return .rejected(.quarantinedAmbiguousTopology, "non_finite_vertex_normal", vids, centroid)
      }
    }
    // Contradictory pairwise normals
    for i in 0..<3 {
      for j in (i + 1)..<3 {
        let d = normals[i].0 * normals[j].0 + normals[i].1 * normals[j].1 + normals[i].2 * normals[j].2
        if d < 0 {
          return .rejected(.quarantinedAmbiguousTopology, "contradictory_vertex_normals", vids, centroid)
        }
      }
    }
    let avg = (
      (a.nx + b.nx + c.nx) / 3.0,
      (a.ny + b.ny + c.ny) / 3.0,
      (a.nz + b.nz + c.nz) / 3.0
    )
    let avgLen = sqrt(avg.0 * avg.0 + avg.1 * avg.1 + avg.2 * avg.2)
    if !avgLen.isFinite || avgLen <= 1e-12 {
      return .rejected(.quarantinedAmbiguousTopology, "near_zero_mean_vertex_normal", vids, centroid)
    }
    let mean = (avg.0 / avgLen, avg.1 / avgLen, avg.2 / avgLen)

    func dotFace(_ a: SurfaceVertex, _ b: SurfaceVertex, _ c: SurfaceVertex) -> Double {
      let fn = faceNormal(a, b, c)
      return fn[0] * mean.0 + fn[1] * mean.1 + fn[2] * mean.2
    }

    let d0 = dotFace(a, b, c)
    if d0 > 0 {
      return .oriented(a, b, c)
    }
    // Swap v1/v2 once for CCW correction only when reference normal is valid
    let d1 = dotFace(a, c, b)
    if d1 > 0 {
      return .oriented(a, c, b)
    }
    return .rejected(.normalConflict, "face_normal_dot_nonpositive_after_swap", vids, centroid)
  }

  private func isCollinear(_ a: SurfaceVertex, _ b: SurfaceVertex, _ c: SurfaceVertex) -> Bool {
    // 2D XY cross near zero and area tiny
    let cross = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
    return abs(cross) < 1e-14
  }

  private func aabbContains(_ mn: [Double], _ mx: [Double], _ p: [Double]) -> Bool {
    guard mn.count >= 2, mx.count >= 2, p.count >= 2 else { return false }
    let zOK: Bool = {
      if mn.count >= 3, mx.count >= 3, p.count >= 3 {
        return p[2] >= mn[2] && p[2] <= mx[2]
      }
      return true
    }()
    return p[0] >= mn[0] && p[0] <= mx[0] && p[1] >= mn[1] && p[1] <= mx[1] && zOK
  }
}

// MARK: - Bowyer–Watson 2D Delaunay

enum DeterministicDelaunay2D {
  struct Tri: Hashable {
    var a: Int
    var b: Int
    var c: Int
  }

  static func triangulate(points: [(Double, Double)]) -> [(Int, Int, Int)] {
    guard points.count >= 3 else { return [] }

    var minX = points[0].0, maxX = points[0].0
    var minY = points[0].1, maxY = points[0].1
    for p in points {
      minX = min(minX, p.0); maxX = max(maxX, p.0)
      minY = min(minY, p.1); maxY = max(maxY, p.1)
    }
    let dx = maxX - minX
    let dy = maxY - minY
    let delta = max(dx, dy, 1.0) * 10.0
    let midX = (minX + maxX) / 2
    let midY = (minY + maxY) / 2

    // Super-triangle vertices appended after real points
    let s0 = points.count
    let s1 = points.count + 1
    let s2 = points.count + 2
    var pts = points
    pts.append((midX - 2 * delta, midY - delta))
    pts.append((midX, midY + 2 * delta))
    pts.append((midX + 2 * delta, midY - delta))

    var tris: [Tri] = [Tri(a: s0, b: s1, c: s2)]

    for pi in 0..<points.count {
      let p = pts[pi]
      var bad: [Tri] = []
      for t in tris {
        if circumcircleContains(pts[t.a], pts[t.b], pts[t.c], p) {
          bad.append(t)
        }
      }
      // Polygon hole edges (appear once)
      var edgeCount: [String: (Int, Int, Int)] = [:]
      func edgeKey(_ u: Int, _ v: Int) -> String {
        u < v ? "\(u)|\(v)" : "\(v)|\(u)"
      }
      func addEdge(_ u: Int, _ v: Int) {
        let k = edgeKey(u, v)
        if let e = edgeCount[k] {
          edgeCount[k] = (e.0, e.1, e.2 + 1)
        } else {
          edgeCount[k] = (u, v, 1)
        }
      }
      for t in bad {
        addEdge(t.a, t.b)
        addEdge(t.b, t.c)
        addEdge(t.c, t.a)
      }
      let badSet = Set(bad)
      tris = tris.filter { !badSet.contains($0) }
      let boundary = edgeCount.values.filter { $0.2 == 1 }.sorted {
        if $0.0 != $1.0 { return $0.0 < $1.0 }
        return $0.1 < $1.1
      }
      for e in boundary {
        tris.append(Tri(a: e.0, b: e.1, c: pi))
      }
    }

    // Remove triangles touching super-triangle
    let superSet: Set<Int> = [s0, s1, s2]
    let kept = tris.filter { !superSet.contains($0.a) && !superSet.contains($0.b) && !superSet.contains($0.c) }

    // Deterministic order
    return kept.map { t -> (Int, Int, Int) in
      var ids = [t.a, t.b, t.c]
      // rotate so smallest index first, preserve orientation via area sign
      if ids[1] < ids[0] && ids[1] < ids[2] { ids = [ids[1], ids[2], ids[0]] }
      else if ids[2] < ids[0] && ids[2] < ids[1] { ids = [ids[2], ids[0], ids[1]] }
      return (ids[0], ids[1], ids[2])
    }
    .sorted {
      if $0.0 != $1.0 { return $0.0 < $1.0 }
      if $0.1 != $1.1 { return $0.1 < $1.1 }
      return $0.2 < $1.2
    }
  }

  private static func circumcircleContains(
    _ a: (Double, Double),
    _ b: (Double, Double),
    _ c: (Double, Double),
    _ p: (Double, Double)
  ) -> Bool {
    let ax = a.0 - p.0, ay = a.1 - p.1
    let bx = b.0 - p.0, by = b.1 - p.1
    let cx = c.0 - p.0, cy = c.1 - p.1
    let det = (ax * ax + ay * ay) * (bx * cy - cx * by)
      - (bx * bx + by * by) * (ax * cy - cx * ay)
      + (cx * cx + cy * cy) * (ax * by - bx * ay)
    // Orientation of ABC
    let orient = (b.0 - a.0) * (c.1 - a.1) - (b.1 - a.1) * (c.0 - a.0)
    if orient > 0 {
      return det > 0
    } else {
      return det < 0
    }
  }
}
