import Foundation

// MARK: - Registration + point cloud

public enum PointValidityClassification: String, Codable, Sendable, Equatable {
  case valid = "VALID"
  case invalidDepth = "INVALID_DEPTH"
  case rejected = "REJECTED"
}

public struct PointSourceReference: Codable, Sendable, Equatable {
  public var depthSampleID: String
  public var depthArtifactID: String
  public var pixelU: Int
  public var pixelV: Int
  public var calibrationID: String
  public var transformIDs: [String]
  public var poseSampleID: String
  public var frameEpochID: String
  public var sourcePackageClosureSHA256: String
  public var derivationID: String

  public func dictionary() -> [String: Any] {
    [
      "depth_sample_id": depthSampleID,
      "depth_artifact_id": depthArtifactID,
      "source_pixel_u": pixelU,
      "source_pixel_v": pixelV,
      "calibration_id": calibrationID,
      "transform_ids": transformIDs.sorted(),
      "pose_sample_id": poseSampleID,
      "frame_epoch_id": frameEpochID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "derivation_id": derivationID,
    ]
  }
}

public struct RegisteredPoint: Codable, Sendable, Equatable {
  public var pointID: String
  public var x: Double
  public var y: Double
  public var z: Double
  public var validity: PointValidityClassification
  public var confidence: Double?
  public var sourceFrameID: String
  public var reconstructionFrameID: String
  public var evidenceAuthority: String
  public var source: PointSourceReference

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "point_id": pointID,
      "position": ["x": x, "y": y, "z": z],
      "validity": validity.rawValue,
      "source_frame_id": sourceFrameID,
      "reconstruction_frame_id": reconstructionFrameID,
      "evidence_authority": evidenceAuthority,
      "source": source.dictionary(),
    ]
    if let confidence { d["confidence"] = confidence }
    return d
  }
}

public struct RegistrationTransformRecord: Codable, Sendable, Equatable {
  public var transformID: String
  public var kind: String
  public var matrix4x4: [Double]

  public func dictionary() -> [String: Any] {
    ["transform_id": transformID, "kind": kind, "matrix_4x4": matrix4x4]
  }
}

public struct RegistrationResult: Codable, Sendable, Equatable {
  public var points: [RegisteredPoint]
  public var transformsUsed: [RegistrationTransformRecord]
  public var invalidDepthCount: Int

  public func dictionary() -> [String: Any] {
    [
      "registered_point_count": points.filter { $0.validity == .valid }.count,
      "invalid_depth_count": invalidDepthCount,
      "points": points.map { $0.dictionary() },
      "transforms_used": transformsUsed.map { $0.dictionary() },
    ]
  }
}

public struct RegisteredPointCloudMetadata: Codable, Sendable, Equatable {
  public var cloudID: String
  public var reconstructionOutputID: String
  public var sourcePackageID: String
  public var sourcePackageClosureSHA256: String
  public var frameEpochID: String
  public var units: String
  public var handedness: String
  public var authority: String

  public func dictionary() -> [String: Any] {
    [
      "cloud_id": cloudID,
      "reconstruction_output_id": reconstructionOutputID,
      "source_package_id": sourcePackageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "frame_epoch_id": frameEpochID,
      "units": units,
      "handedness": handedness,
      "authority": authority,
      "note": "Registered fixture point set — not a complete vehicle point cloud",
    ]
  }
}

public struct PointCloudQualitySummary: Codable, Sendable, Equatable {
  public var registeredPointCount: Int
  public var invalidDepthCount: Int
  public var duplicatePointCount: Int
  public var boundingBoxMin: [Double]
  public var boundingBoxMax: [Double]

  public func dictionary() -> [String: Any] {
    [
      "registered_point_count": registeredPointCount,
      "invalid_depth_count": invalidDepthCount,
      "duplicate_point_count": duplicatePointCount,
      "bounding_box_min": boundingBoxMin,
      "bounding_box_max": boundingBoxMax,
    ]
  }
}

public struct RegisteredPointCloud: Codable, Sendable, Equatable {
  public var metadata: RegisteredPointCloudMetadata
  public var points: [RegisteredPoint]
  public var quality: PointCloudQualitySummary

  public func dictionary() -> [String: Any] {
    [
      "metadata": metadata.dictionary(),
      "points": points.sorted { $0.pointID < $1.pointID }.map { $0.dictionary() },
      "quality": quality.dictionary(),
      "schema_id": "RegisteredPointCloud",
      "schema_version": "1.0.0-phase4a-fixture",
    ]
  }

  public func sha256() throws -> String {
    ContentHasher.sha256Hex(try CanonicalJSON.data(dictionary()))
  }
}

public struct DepthPoseRegistrationEngine: Sendable {
  public struct CalibrationIntrinsics: Sendable {
    public var calibrationID: String
    public var fx: Double
    public var fy: Double
    public var cx: Double
    public var cy: Double
    public var width: Int
    public var height: Int
  }

  public init() {}

  public func register(
    depth: NormalizedDepthObservation,
    pose: NormalizedPoseObservation,
    calibration: CalibrationIntrinsics,
    depthToCamera: [Double],
    sourcePackageClosureSHA256: String,
    derivationID: String
  ) throws -> RegistrationResult {
    guard depth.pixelFormat == "FLOAT32_METERS" else {
      throw ReconstructionError.registrationFailed("unsupported_depth_format")
    }
    guard depth.frameEpochID == pose.frameEpochID else {
      throw ReconstructionError.registrationFailed("cross_epoch_join")
    }
    guard depth.width == calibration.width, depth.height == calibration.height else {
      throw ReconstructionError.registrationFailed("calibration_dimension_mismatch")
    }
    guard depthToCamera.count == 16, pose.transform4x4.count == 16 else {
      throw ReconstructionError.registrationFailed("missing_transform")
    }

    let floats = try decodeFloat32LE(depth.depthBytes, count: depth.width * depth.height)
    var points: [RegisteredPoint] = []
    var invalid = 0
    let depthCamTF = RegistrationTransformRecord(
      transformID: "XF-DEPTH-TO-CAMERA",
      kind: "DEPTH_TO_CAMERA",
      matrix4x4: depthToCamera
    )
    let poseTF = RegistrationTransformRecord(
      transformID: "XF-CAMERA-TO-ROOT",
      kind: "CAMERA_POSE_TO_RECONSTRUCTION_ROOT",
      matrix4x4: pose.transform4x4
    )

    for v in 0..<depth.height {
      for u in 0..<depth.width {
        let idx = v * depth.width + u
        let zCam = Double(floats[idx])
        let pointID = String(format: "PT-%@-%02d-%02d", depth.sampleID, u, v)
        let source = PointSourceReference(
          depthSampleID: depth.sampleID,
          depthArtifactID: depth.artifactID,
          pixelU: u,
          pixelV: v,
          calibrationID: calibration.calibrationID,
          transformIDs: [depthCamTF.transformID, poseTF.transformID],
          poseSampleID: pose.sampleID,
          frameEpochID: depth.frameEpochID,
          sourcePackageClosureSHA256: sourcePackageClosureSHA256,
          derivationID: derivationID
        )
        if !zCam.isFinite || zCam <= 0 {
          invalid += 1
          points.append(
            RegisteredPoint(
              pointID: pointID,
              x: 0, y: 0, z: 0,
              validity: .invalidDepth,
              confidence: nil,
              sourceFrameID: depth.observationID,
              reconstructionFrameID: "FRAME_RECONSTRUCTION_ROOT",
              evidenceAuthority: "TEST_FIXTURE",
              source: source
            )
          )
          continue
        }
        // Back-project in depth/camera optical frame (OpenCV-style +Z).
        let xDepth = (Double(u) - calibration.cx) * zCam / calibration.fx
        let yDepth = (Double(v) - calibration.cy) * zCam / calibration.fy
        let pDepth = [xDepth, yDepth, zCam, 1.0]
        let pCam = mul4(depthToCamera, pDepth)
        let pRoot = mul4(pose.transform4x4, pCam)
        points.append(
          RegisteredPoint(
            pointID: pointID,
            x: pRoot[0], y: pRoot[1], z: pRoot[2],
            validity: .valid,
            confidence: 1.0,
            sourceFrameID: depth.observationID,
            reconstructionFrameID: "FRAME_RECONSTRUCTION_ROOT",
            evidenceAuthority: "TEST_FIXTURE",
            source: source
          )
        )
      }
    }

    return RegistrationResult(
      points: points.sorted { $0.pointID < $1.pointID },
      transformsUsed: [depthCamTF, poseTF],
      invalidDepthCount: invalid
    )
  }

  private func decodeFloat32LE(_ data: Data, count: Int) throws -> [Float] {
    guard data.count == count * 4 else {
      throw ReconstructionError.registrationFailed("depth_byte_length_mismatch")
    }
    var out: [Float] = []
    out.reserveCapacity(count)
    for i in 0..<count {
      let o = i * 4
      let bits = UInt32(data[o])
        | (UInt32(data[o + 1]) << 8)
        | (UInt32(data[o + 2]) << 16)
        | (UInt32(data[o + 3]) << 24)
      out.append(Float(bitPattern: bits))
    }
    return out
  }

  private func mul4(_ m: [Double], _ v: [Double]) -> [Double] {
    // Column-major 4×4 × vec4
    [
      m[0] * v[0] + m[4] * v[1] + m[8] * v[2] + m[12] * v[3],
      m[1] * v[0] + m[5] * v[1] + m[9] * v[2] + m[13] * v[3],
      m[2] * v[0] + m[6] * v[1] + m[10] * v[2] + m[14] * v[3],
      m[3] * v[0] + m[7] * v[1] + m[11] * v[2] + m[15] * v[3],
    ]
  }
}
