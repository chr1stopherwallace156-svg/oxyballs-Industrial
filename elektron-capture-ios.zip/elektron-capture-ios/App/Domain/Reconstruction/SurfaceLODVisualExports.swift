import Foundation

public struct SurfaceLODGenerator: Sendable {
  public var policy: SurfaceMeshingPolicy

  public init(policy: SurfaceMeshingPolicy = .fixture) {
    self.policy = policy
  }

  public func generate(
    vertices: [SurfaceVertex],
    triangles: [SurfaceTriangle]
  ) -> [SurfaceLODMesh] {
    let lod0Tris = triangles.sorted { $0.triangleID < $1.triangleID }
    let lod0Verts = vertices.sorted { $0.vertexID < $1.vertexID }
    let lod0 = SurfaceLODMesh(
      lodLevel: 0,
      meshID: "MESH-LOD0-FIXTURE-000001",
      vertices: lod0Verts,
      triangles: lod0Tris,
      collapseRecords: [],
      requestedTargetTriangleFraction: 1.0,
      requestedTargetTriangleCount: lod0Tris.count,
      achievedTriangleCount: lod0Tris.count,
      reductionRatio: 1.0,
      preservationConstraints: ["LOD0_CANONICAL_UNCHANGED"],
      simplificationMethod: "NONE"
    )
    let lod1 = simplify(
      level: 1,
      meshID: "MESH-LOD1-FIXTURE-000001",
      vertices: lod0Verts,
      triangles: lod0Tris,
      targetFraction: policy.lod1TargetTriangleFraction,
      baseVoxel: policy.lodVoxelSizeMeters
    )
    let lod2 = simplify(
      level: 2,
      meshID: "MESH-LOD2-FIXTURE-000001",
      vertices: lod0Verts,
      triangles: lod0Tris,
      targetFraction: policy.lod2TargetTriangleFraction,
      baseVoxel: policy.lodVoxelSizeMeters * 2.0
    )
    return [lod0, lod1, lod2]
  }

  /// Spatial vertex-clustering (voxel centroid survivor by lowest ID) with boundary preservation.
  /// Targets ~targetFraction of LOD0 triangle count; topology/boundary constraints take priority.
  private func simplify(
    level: Int,
    meshID: String,
    vertices: [SurfaceVertex],
    triangles: [SurfaceTriangle],
    targetFraction: Double,
    baseVoxel: Double
  ) -> SurfaceLODMesh {
    let lod0Count = max(triangles.count, 1)
    let requested = max(1, Int((Double(lod0Count) * targetFraction).rounded()))
    let boundary = boundaryVertexIDs(triangles: triangles)
    var constraints: [String] = ["BOUNDARY_VERTICES", "NON_MANIFOLD_PREVENTION", "MINIMUM_VALID_COMPONENT"]
    var collapses: [VertexCollapseRecord] = []
    var currentVerts = vertices
    var currentTris = triangles
    var voxel = max(baseVoxel, 1e-6)
    var pass = 0

    while currentTris.count > requested && pass < 12 {
      pass += 1
      let byID = Dictionary(uniqueKeysWithValues: currentVerts.map { ($0.vertexID, $0) })
      var clusters: [String: [String]] = [:]
      for v in currentVerts where !boundary.contains(v.vertexID) {
        let ix = Int(floor(v.x / voxel))
        let iy = Int(floor(v.y / voxel))
        let iz = Int(floor(v.z / voxel))
        let key = "\(ix):\(iy):\(iz)"
        clusters[key, default: []].append(v.vertexID)
      }

      var remap: [String: String] = [:]
      var removedThisPass = 0
      for key in clusters.keys.sorted() {
        let members = (clusters[key] ?? []).sorted()
        guard members.count > 1 else { continue }
        let survivor = members[0]
        // Centroid for provenance only — survivor keeps source identity/position (no invented vertex)
        var cx = 0.0, cy = 0.0, cz = 0.0
        for id in members {
          guard let v = byID[id] else { continue }
          cx += v.x; cy += v.y; cz += v.z
        }
        let n = Double(members.count)
        _ = (cx / n, cy / n, cz / n)
        for id in members.dropFirst() {
          remap[id] = survivor
          removedThisPass += 1
          collapses.append(
            VertexCollapseRecord(
              recordID: String(format: "VCR-L%d-%06d", level, collapses.count + 1),
              removedVertexID: id,
              lodLevel: level,
              reason: "VOXEL_CENTROID_CLUSTER_COLLAPSE:\(key)->\(survivor)"
            )
          )
        }
      }

      if removedThisPass == 0 {
        constraints.append("NO_FURTHER_INTERIOR_CLUSTER_AT_VOXEL_\(voxel)")
        voxel *= 1.5
        continue
      }

      let remappedTris: [SurfaceTriangle] = currentTris.compactMap { t in
        let ids = t.vertexIDs.map { remap[$0] ?? $0 }
        if Set(ids).count < 3 { return nil }
        return SurfaceTriangle(
          triangleID: t.triangleID,
          vertexIDs: ids,
          areaMeters2: t.areaMeters2,
          faceNormal: t.faceNormal,
          centroid: t.centroid,
          authority: t.authority
        )
      }
      // Drop duplicate faces after remap
      var seenFaces: Set<String> = []
      var uniqueTris: [SurfaceTriangle] = []
      for t in remappedTris.sorted(by: { $0.triangleID < $1.triangleID }) {
        let fk = t.vertexIDs.sorted().joined(separator: "|")
        if seenFaces.contains(fk) { continue }
        seenFaces.insert(fk)
        uniqueTris.append(t)
      }

      // Preserve boundary loops: ensure every boundary vertex still present
      let used = Set(uniqueTris.flatMap(\.vertexIDs))
      if !boundary.isSubset(of: used.union(boundary)) {
        constraints.append("BOUNDARY_PRESERVATION_BLOCKED_PASS_\(pass)")
        voxel *= 1.5
        continue
      }

      let keptIDs = used.union(boundary)
      currentVerts = currentVerts.filter { keptIDs.contains($0.vertexID) }.sorted { $0.vertexID < $1.vertexID }
      currentTris = uniqueTris
      voxel *= 1.5
    }

    if currentTris.count > requested {
      constraints.append("TARGET_NOT_REACHED_PRESERVATION_PRIORITY")
    }

    let achieved = currentTris.count
    let ratio = Double(achieved) / Double(lod0Count)
    return SurfaceLODMesh(
      lodLevel: level,
      meshID: meshID,
      vertices: currentVerts.sorted { $0.vertexID < $1.vertexID },
      triangles: currentTris.sorted { $0.triangleID < $1.triangleID },
      collapseRecords: collapses.sorted { $0.recordID < $1.recordID },
      requestedTargetTriangleFraction: targetFraction,
      requestedTargetTriangleCount: requested,
      achievedTriangleCount: achieved,
      reductionRatio: ratio,
      preservationConstraints: Array(Set(constraints)).sorted(),
      simplificationMethod: "SPATIAL_VOXEL_CENTROID_CLUSTER_COLLAPSE"
    )
  }

  private func boundaryVertexIDs(triangles: [SurfaceTriangle]) -> Set<String> {
    var edgeCount: [String: (String, String, Int)] = [:]
    func key(_ a: String, _ b: String) -> String { a < b ? "\(a)|\(b)" : "\(b)|\(a)" }
    for t in triangles {
      guard t.vertexIDs.count == 3 else { continue }
      let a = t.vertexIDs[0], b = t.vertexIDs[1], c = t.vertexIDs[2]
      for (u, v) in [(a, b), (b, c), (c, a)] {
        let k = key(u, v)
        if let e = edgeCount[k] { edgeCount[k] = (e.0, e.1, e.2 + 1) }
        else { edgeCount[k] = (u, v, 1) }
      }
    }
    var out: Set<String> = []
    for e in edgeCount.values where e.2 == 1 {
      out.insert(e.0); out.insert(e.1)
    }
    return out
  }
}

public enum SurfaceMeshExportWriter {
  public static func writePLY(mesh: SurfaceLODMesh, colors: [String: (Int, Int, Int)]? = nil) -> String {
    let verts = mesh.vertices.sorted { $0.vertexID < $1.vertexID }
    let indexByID = Dictionary(uniqueKeysWithValues: verts.enumerated().map { ($0.element.vertexID, $0.offset) })
    let tris = mesh.triangles.sorted { $0.triangleID < $1.triangleID }
    var lines: [String] = [
      "ply",
      "format ascii 1.0",
      "comment Elektron Phase 4D fixture surface — not production mesh",
      "comment mesh_id \(mesh.meshID)",
      "comment lod \(mesh.lodLevel)",
      "comment authority RECONSTRUCTION_ESTIMATE",
      "comment numeric_law Double_internal_ascii_float_export",
      "element vertex \(verts.count)",
      "property float x",
      "property float y",
      "property float z",
      "property float nx",
      "property float ny",
      "property float nz",
    ]
    if colors != nil {
      lines += ["property uchar red", "property uchar green", "property uchar blue"]
    }
    lines += [
      "element face \(tris.count)",
      "property list uchar int vertex_indices",
      "end_header",
    ]
    for v in verts {
      var row = String(format: "%.9f %.9f %.9f %.9f %.9f %.9f", v.x, v.y, v.z, v.nx, v.ny, v.nz)
      if let colors, let rgb = colors[v.vertexID] {
        row += String(format: " %d %d %d", rgb.0, rgb.1, rgb.2)
      }
      lines.append(row)
    }
    for t in tris {
      let idxs = t.vertexIDs.compactMap { indexByID[$0] }
      guard idxs.count == 3 else { continue }
      lines.append("3 \(idxs[0]) \(idxs[1]) \(idxs[2])")
    }
    return lines.joined(separator: "\n") + "\n"
  }

  public static func writeOBJ(mesh: SurfaceLODMesh, mtlName: String) -> String {
    let verts = mesh.vertices.sorted { $0.vertexID < $1.vertexID }
    let indexByID = Dictionary(uniqueKeysWithValues: verts.enumerated().map { ($0.element.vertexID, $0.offset + 1) })
    var lines: [String] = [
      "# Elektron Phase 4D fixture surface — not production mesh",
      "# numeric_law deterministic_decimal_text_%.9f",
      "mtllib \(mtlName)",
      "usemtl SurfaceFixture",
    ]
    for v in verts {
      lines.append(String(format: "v %.9f %.9f %.9f", v.x, v.y, v.z))
      lines.append(String(format: "vn %.9f %.9f %.9f", v.nx, v.ny, v.nz))
    }
    for t in mesh.triangles.sorted(by: { $0.triangleID < $1.triangleID }) {
      let idxs = t.vertexIDs.compactMap { indexByID[$0] }
      guard idxs.count == 3 else { continue }
      lines.append("f \(idxs[0])//\(idxs[0]) \(idxs[1])//\(idxs[1]) \(idxs[2])//\(idxs[2])")
    }
    return lines.joined(separator: "\n") + "\n"
  }

  public static func writeMTL() -> String {
    """
    newmtl SurfaceFixture
    Ka 0.200000000 0.200000000 0.200000000
    Kd 0.700000000 0.700000000 0.750000000
    Ks 0.100000000 0.100000000 0.100000000
    Ns 10.000000000
    illum 2
    """
  }

  public static func vertexColors(vertices: [SurfaceVertex]) -> [String: (Int, Int, Int)] {
    var out: [String: (Int, Int, Int)] = [:]
    for v in vertices {
      let c = max(0.0, min(1.0, v.confidence))
      let g = Int((c * 200).rounded()) + 40
      out[v.vertexID] = (40, g, 180)
    }
    return out
  }

  public static func visualDerivationManifest(
    colors: [String: (Int, Int, Int)],
    lodHashes: [String: String],
    glbSHA256: String?,
    glbExportStatus: String?
  ) -> [String: Any] {
    let colorRows: [[String: Any]] = colors.keys.sorted().map { id in
      let rgb = colors[id]!
      return ["vertex_id": id, "rgb": [rgb.0, rgb.1, rgb.2]]
    }
    var d: [String: Any] = [
      "schema_id": "SurfaceVisualDerivationManifest",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
      "authority": "RECONSTRUCTION_ESTIMATE",
      "per_vertex_colors": colorRows,
      "lod_artifact_sha256": Dictionary(uniqueKeysWithValues: lodHashes.keys.sorted().map { ($0, lodHashes[$0]!) }),
      "note": "Deterministic visual derivatives — not photoreal texture",
    ]
    if let glbSHA256 {
      d["glb_sha256"] = glbSHA256
    }
    if let glbExportStatus {
      d["glb_export_status"] = glbExportStatus
    }
    return d
  }
}

public enum GLBExportFailure: Error, Equatable {
  case emptyMesh
  case nonFiniteAttribute(String)
  case serializationError(String)
  case alignmentFailure(String)
}

/// Minimal deterministic GLB (binary glTF 2.0) writer with POSITION + NORMAL + indices.
/// Float32 Little-Endian; JSON padded with 0x20; BIN padded with 0x00.
public enum DeterministicGLBWriter {
  public static func write(mesh: SurfaceLODMesh) throws -> Data {
    let verts = mesh.vertices.sorted { $0.vertexID < $1.vertexID }
    guard !verts.isEmpty, !mesh.triangles.isEmpty else {
      throw GLBExportFailure.emptyMesh
    }
    for v in verts {
      if ![v.x, v.y, v.z, v.nx, v.ny, v.nz].allSatisfy(\.isFinite) {
        throw GLBExportFailure.nonFiniteAttribute(v.vertexID)
      }
    }
    let indexByID = Dictionary(uniqueKeysWithValues: verts.enumerated().map { ($0.element.vertexID, UInt32($0.offset)) })
    var positions: [Float] = []
    var normals: [Float] = []
    var minP: [Float] = [Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude]
    var maxP: [Float] = [-Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude]
    for v in verts {
      let p: [Float] = [Float(v.x), Float(v.y), Float(v.z)]
      positions += p
      normals += [Float(v.nx), Float(v.ny), Float(v.nz)]
      for i in 0..<3 {
        minP[i] = min(minP[i], p[i])
        maxP[i] = max(maxP[i], p[i])
      }
    }
    var indices: [UInt32] = []
    for t in mesh.triangles.sorted(by: { $0.triangleID < $1.triangleID }) {
      let idxs = t.vertexIDs.compactMap { indexByID[$0] }
      guard idxs.count == 3 else { continue }
      indices += idxs
    }
    guard !indices.isEmpty else { throw GLBExportFailure.emptyMesh }

    let posData = floatsToData(positions)
    let nrmData = floatsToData(normals)
    let idxData = uint32ToData(indices)

    var bin = Data()
    let posOffset = 0
    bin.append(posData)
    let nrmOffset = bin.count
    bin.append(nrmData)
    align4(&bin)
    let idxOffset = bin.count
    bin.append(idxData)
    align4(&bin)

    let bufferByteLength = bin.count
    let accessors: [[String: Any]] = [
      [
        "bufferView": 0, "componentType": 5126, "count": verts.count, "type": "VEC3",
        "max": maxP.map { Double($0) }, "min": minP.map { Double($0) },
      ],
      [
        "bufferView": 1, "componentType": 5126, "count": verts.count, "type": "VEC3",
      ],
      [
        "bufferView": 2, "componentType": 5125, "count": indices.count, "type": "SCALAR",
      ],
    ]
    let bufferViews: [[String: Any]] = [
      ["buffer": 0, "byteOffset": posOffset, "byteLength": posData.count, "target": 34962],
      ["buffer": 0, "byteOffset": nrmOffset, "byteLength": nrmData.count, "target": 34962],
      ["buffer": 0, "byteOffset": idxOffset, "byteLength": idxData.count, "target": 34963],
    ]
    let gltf: [String: Any] = [
      "asset": ["version": "2.0", "generator": "Elektron-Phase4D-DeterministicGLBWriter"],
      "buffers": [["byteLength": bufferByteLength]],
      "bufferViews": bufferViews,
      "accessors": accessors,
      "meshes": [[
        "name": mesh.meshID,
        "primitives": [[
          "attributes": ["POSITION": 0, "NORMAL": 1],
          "indices": 2,
          "mode": 4,
        ]],
      ]],
      "nodes": [["mesh": 0, "name": "SurfaceFixture"]],
      "scenes": [["nodes": [0]]],
      "scene": 0,
    ]

    guard let jsonData = try? JSONSerialization.data(withJSONObject: gltf, options: [.sortedKeys]) else {
      throw GLBExportFailure.serializationError("json_serialization_failed")
    }
    var jsonPadded = jsonData
    while jsonPadded.count % 4 != 0 { jsonPadded.append(0x20) }
    var binPadded = bin
    while binPadded.count % 4 != 0 { binPadded.append(0x00) }
    if jsonPadded.count % 4 != 0 || binPadded.count % 4 != 0 {
      throw GLBExportFailure.alignmentFailure("chunk_padding")
    }

    var out = Data()
    appendU32(&out, 0x46546C67) // glTF
    appendU32(&out, 2)
    let total = 12 + 8 + jsonPadded.count + 8 + binPadded.count
    appendU32(&out, UInt32(total))
    appendU32(&out, UInt32(jsonPadded.count))
    appendU32(&out, 0x4E4F534A) // JSON
    out.append(jsonPadded)
    appendU32(&out, UInt32(binPadded.count))
    appendU32(&out, 0x004E4942) // BIN\0
    out.append(binPadded)
    return out
  }

  private static func floatsToData(_ values: [Float]) -> Data {
    var d = Data(capacity: values.count * 4)
    for v in values {
      var le = v.bitPattern.littleEndian
      withUnsafeBytes(of: &le) { d.append(contentsOf: $0) }
    }
    return d
  }

  private static func uint32ToData(_ values: [UInt32]) -> Data {
    var d = Data(capacity: values.count * 4)
    for v in values {
      var le = v.littleEndian
      withUnsafeBytes(of: &le) { d.append(contentsOf: $0) }
    }
    return d
  }

  private static func align4(_ data: inout Data) {
    while data.count % 4 != 0 { data.append(0x00) }
  }

  private static func appendU32(_ data: inout Data, _ value: UInt32) {
    var le = value.littleEndian
    withUnsafeBytes(of: &le) { data.append(contentsOf: $0) }
  }
}
