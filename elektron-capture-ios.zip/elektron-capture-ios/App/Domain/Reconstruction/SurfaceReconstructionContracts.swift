import Foundation

// MARK: - Schema / IDs

public enum Phase4DFixtureIDs {
  public static let inputPackageID = "SPKG-FIXTURE-SURFACE-RECONSTRUCTION-000001"
  public static let fixtureGeometryID = "GEOM-FIXTURE-SURFACE-TARGET-000001"
  public static let surfaceOutputID = "SURFACE-OUT-FIXTURE-000001"
  public static let schemaVersion = "1.0.0-phase4d-fixture"
  public static let sessionID = "SESS-FIXTURE-SURFACE-RECONSTRUCTION-000001"
  public static let vehicleID = "VEH-FIXTURE-SURFACE-RECONSTRUCTION-000001"
  public static let privacyPolicyID = "POL-FIXTURE-SURFACE-RECONSTRUCTION-000001"
}

// MARK: - Job runtime

public enum SurfaceReconstructionJobState: String, Codable, Sendable, Equatable {
  case created = "CREATED"
  case validating = "VALIDATING"
  case generatingVertices = "GENERATING_VERTICES"
  case generatingTriangles = "GENERATING_TRIANGLES"
  case validatingTopology = "VALIDATING_TOPOLOGY"
  case classifyingBoundaries = "CLASSIFYING_BOUNDARIES"
  case generatingLODs = "GENERATING_LODS"
  case generatingVisualDerivatives = "GENERATING_VISUAL_DERIVATIVES"
  case finalizing = "FINALIZING"
  case complete = "COMPLETE"
  case failed = "FAILED"
  case cancelled = "CANCELLED"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public struct SurfaceProgressRecord: Equatable, Sendable {
  public var state: SurfaceReconstructionJobState
  public var message: String
  public var atUTC: String

  public func dictionary() -> [String: Any] {
    ["state": state.rawValue, "message": message, "at_utc": atUTC]
  }
}

public struct SurfaceCancellationResult: Equatable, Sendable {
  public var cancelled: Bool
  public var duringState: SurfaceReconstructionJobState
  public var sealedOutputCreated: Bool
  public var temporaryCleaned: Bool

  public func dictionary() -> [String: Any] {
    [
      "cancelled": cancelled,
      "during_state": duringState.rawValue,
      "sealed_output_created": sealedOutputCreated,
      "temporary_cleaned": temporaryCleaned,
    ]
  }
}

public final class SurfaceReconstructionJob: @unchecked Sendable {
  public private(set) var state: SurfaceReconstructionJobState = .created
  public private(set) var progress: [SurfaceProgressRecord] = []
  public private(set) var cancelRequested = false
  public let jobID: String

  public init(jobID: String = "JOB-SURF-FIXTURE-000001") {
    self.jobID = jobID
  }

  public func requestCancel() { cancelRequested = true }
  public var isCancelled: Bool { cancelRequested }

  public func transition(_ to: SurfaceReconstructionJobState, message: String) {
    state = to
    progress.append(
      SurfaceProgressRecord(state: to, message: message, atUTC: "2026-08-04T11:00:00Z")
    )
  }
}

// MARK: - Geometry wrapper

public struct FixtureSurfaceTargetGeometry: Equatable, Sendable {
  public static let geometryID = Phase4DFixtureIDs.fixtureGeometryID

  public var geometryID: String
  public var landmarks: [[String: Double]]
  public var trueCameraTranslations: [[Double]]
  public var injectedPosePerturbations: [[Double]]
  public var authority: String
  public var intentionalHoleAABBMin: [Double]
  public var intentionalHoleAABBMax: [Double]
  public var expectedOccupiedVoxelCount: Int
  public var expectedConsolidatedPointCountMin: Int
  public var voxelSizeMeters: Double

  public static func surfaceTarget() -> FixtureSurfaceTargetGeometry {
    let base = FixtureMultiviewSurfaceGeometry.multiviewSurface()
    return FixtureSurfaceTargetGeometry(
      geometryID: geometryID,
      landmarks: base.landmarks,
      trueCameraTranslations: base.trueCameraTranslations,
      injectedPosePerturbations: base.injectedPosePerturbations,
      authority: "TEST_FIXTURE_GROUND_TRUTH",
      intentionalHoleAABBMin: [0.08, -0.01, 1.99],
      intentionalHoleAABBMax: [0.12, 0.01, 2.01],
      expectedOccupiedVoxelCount: base.expectedOccupiedVoxelCount,
      expectedConsolidatedPointCountMin: base.expectedConsolidatedPointCountMin,
      voxelSizeMeters: base.voxelSizeMeters
    )
  }

  public func asMultiviewSurfaceGeometry() -> FixtureMultiviewSurfaceGeometry {
    FixtureMultiviewSurfaceGeometry(
      geometryID: geometryID,
      landmarks: landmarks,
      trueCameraTranslations: trueCameraTranslations,
      injectedPosePerturbations: injectedPosePerturbations,
      authority: authority,
      expectedOccupiedVoxelCount: expectedOccupiedVoxelCount,
      expectedConsolidatedPointCountMin: expectedConsolidatedPointCountMin,
      voxelSizeMeters: voxelSizeMeters
    )
  }

  public func dictionary() -> [String: Any] {
    [
      "geometry_id": geometryID,
      "kind": "PLANAR_SURFACE_TARGET",
      "landmarks": landmarks,
      "true_camera_translations": trueCameraTranslations,
      "injected_pose_perturbations": injectedPosePerturbations,
      "intentional_hole_aabb_min": intentionalHoleAABBMin,
      "intentional_hole_aabb_max": intentionalHoleAABBMax,
      "voxel_size_meters": voxelSizeMeters,
      "expected_occupied_voxel_count": expectedOccupiedVoxelCount,
      "expected_consolidated_point_count_min": expectedConsolidatedPointCountMin,
      "geometry_reference_authority": authority,
      "schema_id": "FixtureSurfaceTargetGeometry",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
      "note": "Fixture ground truth is not physical metrology or vehicle mesh proof",
    ]
  }
}

// MARK: - Mesh primitives

public struct SurfaceVertex: Equatable, Sendable {
  public var vertexID: String
  public var fusedPointID: String
  public var x: Double
  public var y: Double
  public var z: Double
  public var nx: Double
  public var ny: Double
  public var nz: Double
  public var confidence: Double
  public var authority: String

  public func dictionary() -> [String: Any] {
    [
      "vertex_id": vertexID,
      "fused_point_id": fusedPointID,
      "position": ["x": x, "y": y, "z": z],
      "normal": ["nx": nx, "ny": ny, "nz": nz],
      "confidence": confidence,
      "surface_authority": authority,
    ]
  }
}

public enum TriangleRejectionReason: String, Codable, Sendable, Equatable {
  case duplicateVertices = "REJECTED_DUPLICATE_VERTICES"
  case nearZeroArea = "REJECTED_NEAR_ZERO_AREA"
  case excessiveEdgeLength = "REJECTED_EXCESSIVE_EDGE_LENGTH"
  case normalConflict = "REJECTED_NORMAL_CONFLICT"
  case gapBridging = "REJECTED_GAP_BRIDGING"
  case quarantinedInput = "REJECTED_QUARANTINED_INPUT"
  case degenerateCollinear = "REJECTED_DEGENERATE_COLLINEAR"
  case intentionalOpenBoundary = "REJECTED_INTENTIONAL_OPEN_BOUNDARY"
  case quarantinedAmbiguousTopology = "QUARANTINED_AMBIGUOUS_TOPOLOGY"
}

public struct SurfaceTriangle: Equatable, Sendable {
  public var triangleID: String
  public var vertexIDs: [String]
  public var areaMeters2: Double
  public var faceNormal: [Double]
  public var centroid: [Double]
  public var authority: String

  public func dictionary() -> [String: Any] {
    [
      "triangle_id": triangleID,
      "vertex_ids": vertexIDs,
      "area_meters2": areaMeters2,
      "face_normal": faceNormal,
      "centroid": centroid,
      "surface_authority": authority,
    ]
  }
}

public struct RejectedTriangleRecord: Equatable, Sendable {
  public var recordID: String
  public var vertexIDs: [String]
  public var reason: TriangleRejectionReason
  public var detail: String
  public var centroid: [Double]

  public func dictionary() -> [String: Any] {
    [
      "record_id": recordID,
      "vertex_ids": vertexIDs,
      "reason": reason.rawValue,
      "detail": detail,
      "centroid": centroid,
    ]
  }
}

public struct SurfaceMeshCandidate: Equatable, Sendable {
  public var meshID: String
  public var surfaceOutputID: String
  public var authority: String
  public var vertices: [SurfaceVertex]
  public var triangles: [SurfaceTriangle]
  public var classification: String

  public func dictionary() -> [String: Any] {
    [
      "mesh_id": meshID,
      "surface_output_id": surfaceOutputID,
      "surface_authority": authority,
      "classification": classification,
      "vertex_count": vertices.count,
      "triangle_count": triangles.count,
      "vertices": vertices.sorted { $0.vertexID < $1.vertexID }.map { $0.dictionary() },
      "triangles": triangles.sorted { $0.triangleID < $1.triangleID }.map { $0.dictionary() },
      "production_mesh_claim": "FORBIDDEN",
      "engineering_metrology_claim": "FORBIDDEN",
      "complete_digital_twin_claim": "FORBIDDEN",
      "schema_id": "SurfaceMeshCandidate",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
      "note": "Synthetic fixture surface candidate — not production mesh",
    ]
  }

  public func sha256() throws -> String {
    ContentHasher.sha256Hex(try CanonicalJSON.data(dictionary()))
  }
}

public struct SurfaceReconstructionResult: Equatable, Sendable {
  public var vertices: [SurfaceVertex]
  public var triangles: [SurfaceTriangle]
  public var rejected: [RejectedTriangleRecord]
  public var algorithmID: String
  public var configurationDigest: String

  public func dictionary() -> [String: Any] {
    [
      "algorithm_id": algorithmID,
      "configuration_digest": configurationDigest,
      "vertex_count": vertices.count,
      "valid_triangle_count": triangles.count,
      "rejected_triangle_count": rejected.count,
      "vertices": vertices.sorted { $0.vertexID < $1.vertexID }.map { $0.dictionary() },
      "triangles": triangles.sorted { $0.triangleID < $1.triangleID }.map { $0.dictionary() },
      "rejected_triangles": rejected.sorted { $0.recordID < $1.recordID }.map { $0.dictionary() },
    ]
  }
}

// MARK: - Topology / boundaries / holes

public enum TopologyValidationOutcome: String, Codable, Sendable, Equatable {
  case validManifoldOpen = "VALID_MANIFOLD_OPEN"
  case validWithHoles = "VALID_WITH_HOLES"
  case invalidNonManifold = "INVALID_NON_MANIFOLD"
  case invalidDuplicateFaces = "INVALID_DUPLICATE_FACES"
  case invalidDegenerate = "INVALID_DEGENERATE"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public struct TopologyValidationRecord: Equatable, Sendable {
  public var outcome: TopologyValidationOutcome
  public var componentCount: Int
  public var boundaryEdgeCount: Int
  public var nonManifoldEdgeCount: Int
  public var duplicateFaceCount: Int
  public var detail: String

  public func dictionary() -> [String: Any] {
    [
      "outcome": outcome.rawValue,
      "component_count": componentCount,
      "boundary_edge_count": boundaryEdgeCount,
      "non_manifold_edge_count": nonManifoldEdgeCount,
      "duplicate_face_count": duplicateFaceCount,
      "detail": detail,
    ]
  }
}

public enum BoundaryClassification: String, Codable, Sendable, Equatable {
  case outerBoundary = "OUTER_BOUNDARY"
  case intentionalOpenBoundary = "INTENTIONAL_OPEN_BOUNDARY"
  case unobservedRegion = "UNOBSERVED_REGION"
  case holeBoundary = "HOLE_BOUNDARY"
  case sparseRegionBoundary = "SPARSE_REGION_BOUNDARY"
}

public struct BoundaryLoopRecord: Equatable, Sendable {
  public var boundaryID: String
  public var classification: BoundaryClassification
  public var orderedVertexIDs: [String]
  public var edgeCount: Int
  public var detail: String

  public func dictionary() -> [String: Any] {
    [
      "boundary_id": boundaryID,
      "classification": classification.rawValue,
      "ordered_vertex_ids": orderedVertexIDs,
      "edge_count": edgeCount,
      "detail": detail,
    ]
  }
}

public enum HoleClassification: String, Codable, Sendable, Equatable {
  case unobservedRegion = "UNOBSERVED_REGION"
  case intentionalOpenBoundary = "INTENTIONAL_OPEN_BOUNDARY"
  case gapBridgingAvoided = "GAP_BRIDGING_AVOIDED"
  case sparseCoverage = "SPARSE_COVERAGE"
}

public struct HoleRecord: Equatable, Sendable {
  public var holeID: String
  public var classification: HoleClassification
  public var boundaryID: String?
  public var aabbMin: [Double]
  public var aabbMax: [Double]
  public var automaticFillApplied: Bool
  public var detail: String

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "hole_id": holeID,
      "classification": classification.rawValue,
      "aabb_min": aabbMin,
      "aabb_max": aabbMax,
      "automatic_fill_applied": automaticFillApplied,
      "fill_authority": automaticFillApplied ? "INTERPOLATED_FIXTURE_SURFACE_ESTIMATE" : "NONE",
      "detail": detail,
    ]
    if let boundaryID { d["boundary_id"] = boundaryID }
    return d
  }
}

public enum SurfaceConfidenceClass: String, Codable, Sendable, Equatable {
  case high = "HIGH_CONFIDENCE"
  case medium = "MEDIUM_CONFIDENCE"
  case low = "LOW_CONFIDENCE"
  case interpolated = "INTERPOLATED_FIXTURE_SURFACE_ESTIMATE"
  case quarantinedExcluded = "QUARANTINED_EXCLUDED"
}

public struct SurfaceConfidenceRecord: Equatable, Sendable {
  public var subjectID: String
  public var kind: String
  public var classification: SurfaceConfidenceClass
  public var score: Double
  public var detail: String

  public func dictionary() -> [String: Any] {
    [
      "subject_id": subjectID,
      "kind": kind,
      "classification": classification.rawValue,
      "score": score,
      "detail": detail,
    ]
  }
}

// MARK: - LOD

public struct VertexCollapseRecord: Equatable, Sendable {
  public var recordID: String
  public var removedVertexID: String
  public var lodLevel: Int
  public var reason: String

  public func dictionary() -> [String: Any] {
    [
      "record_id": recordID,
      "removed_vertex_id": removedVertexID,
      "lod_level": lodLevel,
      "reason": reason,
    ]
  }
}

public struct SurfaceLODMesh: Equatable, Sendable {
  public var lodLevel: Int
  public var meshID: String
  public var vertices: [SurfaceVertex]
  public var triangles: [SurfaceTriangle]
  public var collapseRecords: [VertexCollapseRecord]
  public var requestedTargetTriangleFraction: Double
  public var requestedTargetTriangleCount: Int
  public var achievedTriangleCount: Int
  public var reductionRatio: Double
  public var preservationConstraints: [String]
  public var simplificationMethod: String

  public func dictionary() -> [String: Any] {
    [
      "lod_level": lodLevel,
      "mesh_id": meshID,
      "vertex_count": vertices.count,
      "triangle_count": triangles.count,
      "requested_target_triangle_fraction": requestedTargetTriangleFraction,
      "requested_target_triangle_count": requestedTargetTriangleCount,
      "achieved_triangle_count": achievedTriangleCount,
      "reduction_ratio": reductionRatio,
      "preservation_constraints": preservationConstraints.sorted(),
      "simplification_method": simplificationMethod,
      "collapse_records": collapseRecords.sorted { $0.recordID < $1.recordID }.map { $0.dictionary() },
    ]
  }
}

// MARK: - Phase 4E handoff

public enum Phase4EReadinessOutcome: String, Codable, Sendable, Equatable {
  case readyForFixtureScaleAndDatum = "READY_FOR_FIXTURE_SCALE_AND_DATUM_CHARACTERIZATION"
  case readyWithUnresolvedBoundaries = "READY_WITH_UNRESOLVED_BOUNDARIES"
  case additionalCaptureRecommended = "ADDITIONAL_CAPTURE_RECOMMENDED"
  case notReadyInvalidTopology = "NOT_READY_INVALID_TOPOLOGY"
  case notReadyInsufficientMesh = "NOT_READY_INSUFFICIENT_SURFACE_SUPPORT"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public struct Phase4EHandoffContract: Equatable, Sendable {
  public var surfaceOutputID: String
  public var meshArtifactID: String
  public var readiness: Phase4EReadinessOutcome
  public var vertexCount: Int
  public var triangleCount: Int
  public var boundaryCount: Int
  public var holeCount: Int
  public var lodCount: Int
  public var lineageManifestID: String
  public var outputClosureSHA256: String
  public var limitations: [String]

  public func dictionary() -> [String: Any] {
    [
      "surface_output_id": surfaceOutputID,
      "mesh_artifact_id": meshArtifactID,
      "phase4e_readiness": readiness.rawValue,
      "vertex_count": vertexCount,
      "triangle_count": triangleCount,
      "boundary_count": boundaryCount,
      "hole_count": holeCount,
      "lod_count": lodCount,
      "source_lineage_manifest_id": lineageManifestID,
      "output_closure_sha256": outputClosureSHA256,
      "limitations": limitations.sorted(),
      "production_mesh_claim": "FORBIDDEN",
      "engineering_metrology_claim": "FORBIDDEN",
      "complete_digital_twin_claim": "FORBIDDEN",
      "schema_id": "Phase4EHandoffContract",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
      "note": "Handoff only — scale/datum characterization is Phase 4E",
    ]
  }
}

// MARK: - Lineage / quality

public struct SurfaceDerivationRecord: Equatable, Sendable {
  public var derivationID: String
  public var kind: String
  public var subjectID: String
  public var sourceIDs: [String]
  public var algorithmID: String
  public var configurationDigest: String

  public func dictionary() -> [String: Any] {
    [
      "derivation_id": derivationID,
      "kind": kind,
      "subject_id": subjectID,
      "source_ids": sourceIDs.sorted(),
      "algorithm_id": algorithmID,
      "configuration_digest": configurationDigest,
    ]
  }
}

public struct SurfaceLineageManifest: Equatable, Sendable {
  public var lineageManifestID: String
  public var sourcePackageID: String
  public var sourcePackageClosureSHA256: String
  public var phase4COutputClosureSHA256: String
  public var surfacePolicyID: String
  public var configurationDigest: String
  public var algorithmIDs: [String]
  public var outputArtifactHashes: [String: String]
  public var lineageManifestSHA256: String

  public func dictionary() -> [String: Any] {
    [
      "lineage_manifest_id": lineageManifestID,
      "source_package_id": sourcePackageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "phase4c_output_closure_sha256": phase4COutputClosureSHA256,
      "surface_policy_id": surfacePolicyID,
      "configuration_digest": configurationDigest,
      "algorithm_ids": algorithmIDs.sorted(),
      "output_artifact_hashes": Dictionary(
        uniqueKeysWithValues: outputArtifactHashes.keys.sorted().map { ($0, outputArtifactHashes[$0]!) }
      ),
      "lineage_manifest_sha256": lineageManifestSHA256,
      "schema_id": "SurfaceLineageManifest",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
    ]
  }
}

public struct SurfaceQualitySummary: Equatable, Sendable {
  public var summaryID: String
  public var vertexCount: Int
  public var validTriangleCount: Int
  public var rejectedTriangleCount: Int
  public var boundaryCount: Int
  public var holeCount: Int
  public var componentCount: Int
  public var lodCount: Int
  public var topologyOutcome: TopologyValidationOutcome
  public var meanVertexConfidence: Double
  public var automaticHoleFillApplied: Bool
  public var characterizationStatus: String

  public func dictionary() -> [String: Any] {
    [
      "summary_id": summaryID,
      "vertex_count": vertexCount,
      "valid_triangle_count": validTriangleCount,
      "rejected_triangle_count": rejectedTriangleCount,
      "boundary_count": boundaryCount,
      "hole_count": holeCount,
      "component_count": componentCount,
      "lod_count": lodCount,
      "topology_outcome": topologyOutcome.rawValue,
      "mean_vertex_confidence": meanVertexConfidence,
      "automatic_hole_fill_applied": automaticHoleFillApplied,
      "characterization_status": characterizationStatus,
      "production_mesh_claim": "FORBIDDEN",
      "engineering_metrology_claim": "FORBIDDEN",
      "complete_digital_twin_claim": "FORBIDDEN",
      "manufacturing_claim": "FORBIDDEN",
      "schema_id": "SurfaceQualitySummary",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
    ]
  }
}

// MARK: - Failures

public enum SurfaceFailure: Error, Equatable, Sendable {
  case cancelled(String)
  case ineligible(String)
  case invalidInput(String)
  case topologyFailed(String)
  case resourceBound(String)
  case deterministicReplayMismatch(String)
}
