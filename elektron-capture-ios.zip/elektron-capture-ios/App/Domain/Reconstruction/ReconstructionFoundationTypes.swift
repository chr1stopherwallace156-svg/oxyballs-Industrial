import Foundation

// MARK: - Phase 4A reconstruction errors

public enum ReconstructionError: Error, Equatable, Sendable {
  case ineligible(String)
  case invalidPackage(String)
  case missingObservation(String)
  case observationRejected(String)
  case registrationFailed(String)
  case frameSelectionFailed(String)
  case lineageFailed(String)
  case deterministicReplayMismatch(String)
  case privacyPolicyForbidsReconstruction(String)
  case groundTruthMismatch(String)
}

// MARK: - Eligibility

public enum ReconstructionEligibilityOutcome: String, Codable, Sendable, Equatable {
  case eligibleCameraDepthPose = "ELIGIBLE_CAMERA_DEPTH_POSE"
  case eligibleCameraPose = "ELIGIBLE_CAMERA_POSE"
  case eligibleDepthPose = "ELIGIBLE_DEPTH_POSE"
  case eligibleCameraOnlyExperimental = "ELIGIBLE_CAMERA_ONLY_EXPERIMENTAL"
  case ineligibleMissingCalibration = "INELIGIBLE_MISSING_CALIBRATION"
  case ineligibleBrokenAssociation = "INELIGIBLE_BROKEN_ASSOCIATION"
  case ineligibleInvalidPackage = "INELIGIBLE_INVALID_PACKAGE"
  case ineligiblePrivacyPolicy = "INELIGIBLE_PRIVACY_POLICY"
  case ineligibleInsufficientObservations = "INELIGIBLE_INSUFFICIENT_OBSERVATIONS"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public struct ReconstructionEligibilityPolicy: Codable, Sendable, Equatable {
  public var policyID: String
  public var requireCalibration: Bool
  public var requireCameraDepthAssociation: Bool
  public var requireCameraPoseAssociation: Bool
  public var requireClockCorrelation: Bool
  public var minCameraSamples: Int
  public var minDepthSamples: Int
  public var minPoseSamples: Int
  public var allowPrivacyFirstWithoutRaw: Bool

  public static let fixture = ReconstructionEligibilityPolicy(
    policyID: "RECON-ELIG-POL-FIXTURE-000001",
    requireCalibration: true,
    requireCameraDepthAssociation: true,
    requireCameraPoseAssociation: true,
    requireClockCorrelation: true,
    minCameraSamples: 1,
    minDepthSamples: 1,
    minPoseSamples: 1,
    allowPrivacyFirstWithoutRaw: false
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "require_calibration": requireCalibration,
      "require_camera_depth_association": requireCameraDepthAssociation,
      "require_camera_pose_association": requireCameraPoseAssociation,
      "require_clock_correlation": requireClockCorrelation,
      "min_camera_samples": minCameraSamples,
      "min_depth_samples": minDepthSamples,
      "min_pose_samples": minPoseSamples,
      "allow_privacy_first_without_raw": allowPrivacyFirstWithoutRaw,
    ]
  }
}

public struct ReconstructionEligibilityResult: Codable, Sendable, Equatable {
  public var outcome: ReconstructionEligibilityOutcome
  public var reasons: [String]
  public var policyID: String

  public var isEligible: Bool {
    switch outcome {
    case .eligibleCameraDepthPose, .eligibleCameraPose, .eligibleDepthPose, .eligibleCameraOnlyExperimental:
      return true
    default:
      return false
    }
  }

  public func dictionary() -> [String: Any] {
    [
      "outcome": outcome.rawValue,
      "reasons": reasons,
      "policy_id": policyID,
      "eligible": isEligible,
    ]
  }
}

public struct ReconstructionInputDescriptor: Codable, Sendable, Equatable {
  public var packageID: String
  public var captureSessionID: String
  public var packageClosureSHA256: String
  public var manifestSHA256: String
  public var journalRootSHA256: String?
  public var frameEpochID: String
  public var sessionRunID: String
  public var worldOriginRevision: UInt64
  public var evidenceOriginAuthority: String
  public var geometryReferenceAuthority: String

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "package_id": packageID,
      "capture_session_id": captureSessionID,
      "package_closure_sha256": packageClosureSHA256,
      "manifest_sha256": manifestSHA256,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "evidence_origin_authority": evidenceOriginAuthority,
      "geometry_reference_authority": geometryReferenceAuthority,
    ]
    if let journalRootSHA256 { d["journal_root_sha256"] = journalRootSHA256 }
    return d
  }
}

public struct ReconstructionInputInventory: Codable, Sendable, Equatable {
  public var cameraSampleIDs: [String]
  public var depthSampleIDs: [String]
  public var poseSampleIDs: [String]
  public var calibrationIDs: [String]
  public var associationIDs: [String]
  public var artifactRelativePaths: [String]

  public func dictionary() -> [String: Any] {
    [
      "camera_sample_ids": cameraSampleIDs.sorted(),
      "depth_sample_ids": depthSampleIDs.sorted(),
      "pose_sample_ids": poseSampleIDs.sorted(),
      "calibration_ids": calibrationIDs.sorted(),
      "association_ids": associationIDs.sorted(),
      "artifact_relative_paths": artifactRelativePaths.sorted(),
    ]
  }
}

public struct ReconstructionIngestFailure: Codable, Sendable, Equatable {
  public var code: String
  public var detail: String

  public func dictionary() -> [String: Any] {
    ["code": code, "detail": detail]
  }
}

// MARK: - Fixture geometry ground truth

public struct FixtureReconstructionGeometry: Codable, Sendable, Equatable {
  public static let geometryID = "GEOM-FIXTURE-PLANAR-TARGET-000001"

  public var geometryID: String
  public var kind: String
  public var planeZMeters: Double
  public var widthMeters: Double
  public var heightMeters: Double
  public var expectedPointPositions: [[String: Double]]
  public var authority: String

  public static func planarTarget() -> FixtureReconstructionGeometry {
    // 4×4 depth, Z=2.0, fx=fy=100, cx=cy=1.5 → exact back-projections
    let fx = 100.0, fy = 100.0, cx = 1.5, cy = 1.5, z = 2.0
    var pts: [[String: Double]] = []
    for v in 0..<4 {
      for u in 0..<4 {
        if u == 3 && v == 3 { continue } // invalid sentinel pixel
        let x = (Double(u) - cx) * z / fx
        let y = (Double(v) - cy) * z / fy
        pts.append(["u": Double(u), "v": Double(v), "x": x, "y": y, "z": z])
      }
    }
    return FixtureReconstructionGeometry(
      geometryID: geometryID,
      kind: "PLANAR_TARGET",
      planeZMeters: z,
      widthMeters: 0.06,
      heightMeters: 0.06,
      expectedPointPositions: pts,
      authority: "TEST_FIXTURE_GROUND_TRUTH"
    )
  }

  public func dictionary() -> [String: Any] {
    [
      "geometry_id": geometryID,
      "kind": kind,
      "plane_z_meters": planeZMeters,
      "width_meters": widthMeters,
      "height_meters": heightMeters,
      "expected_point_positions": expectedPointPositions,
      "geometry_reference_authority": authority,
      "schema_id": "FixtureReconstructionGeometry",
      "schema_version": "1.0.0-phase4a-fixture",
      "note": "Fixture ground truth is not physical metrology",
    ]
  }
}
