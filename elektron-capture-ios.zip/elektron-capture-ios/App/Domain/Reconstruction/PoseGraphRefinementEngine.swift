import Foundation

// MARK: - Pose refinement

public enum PoseRefinementOutcome: String, Codable, Sendable, Equatable {
  case converged = "CONVERGED"
  case noRefinementRequired = "NO_REFINEMENT_REQUIRED"
  case insufficientConstraints = "INSUFFICIENT_CONSTRAINTS"
  case diverged = "DIVERGED"
  case singularConfiguration = "SINGULAR_CONFIGURATION"
  case invalidGraph = "INVALID_GRAPH"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public struct PoseRefinementIteration: Equatable, Sendable {
  public var iteration: Int
  public var objectiveValue: Double
  public var meanResidual: Double

  public func dictionary() -> [String: Any] {
    [
      "iteration": iteration,
      "objective_value": objectiveValue,
      "mean_residual": meanResidual,
    ]
  }
}

public struct PoseRefinementConvergence: Equatable, Sendable {
  public var rule: String
  public var epsilon: Double
  public var satisfied: Bool

  public func dictionary() -> [String: Any] {
    ["rule": rule, "epsilon": epsilon, "satisfied": satisfied]
  }
}

public struct PoseResidualSummary: Equatable, Sendable {
  public var initialMeanResidual: Double
  public var finalMeanResidual: Double
  public var maxResidual: Double

  public func dictionary() -> [String: Any] {
    [
      "initial_mean_residual": initialMeanResidual,
      "final_mean_residual": finalMeanResidual,
      "max_residual": maxResidual,
    ]
  }
}

public struct PoseRefinementResult: Equatable, Sendable {
  public var outcome: PoseRefinementOutcome
  public var iterations: [PoseRefinementIteration]
  public var convergence: PoseRefinementConvergence
  public var residuals: PoseResidualSummary
  public var refinedGraph: ReconstructionPoseGraph?
  public var initialGraphDigest: String
  public var configurationDigest: String
  public var terminationReason: String
  public var sourcePosesUnchangedProof: Bool

  public var iterationCount: Int { iterations.count }

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "outcome": outcome.rawValue,
      "iterations": iterations.map { $0.dictionary() },
      "refinement_iteration_count": iterationCount,
      "convergence": convergence.dictionary(),
      "residuals": residuals.dictionary(),
      "initial_graph_digest": initialGraphDigest,
      "configuration_digest": configurationDigest,
      "termination_reason": terminationReason,
      "source_poses_unchanged_proof": sourcePosesUnchangedProof,
      "schema_id": "PoseRefinementResult",
      "schema_version": "1.0.0-phase4b-fixture",
      "note": "Fixture optimization — not production photogrammetry",
    ]
    if let refinedGraph { d["refined_graph"] = refinedGraph.dictionary() }
    return d
  }
}

public enum PoseRefinementFailure: Error, Equatable, Sendable {
  case invalidGraph(String)
  case insufficientConstraints(String)
  case singular(String)
  case diverged(String)
  case sourcePoseMutationAttempt(String)
}

/// Bounded fixture pose refinement: closed-form translation correction using known landmarks.
/// Corrects injected perturbations toward fixture ground truth without claiming production BA.
public struct PoseGraphRefinementEngine: Sendable {
  public var configuration: PoseGraphConfiguration

  public init(configuration: PoseGraphConfiguration = .fixture) {
    self.configuration = configuration
  }

  public func refine(
    graph: ReconstructionPoseGraph,
    tracks: FeatureTrackGraph,
    geometry: FixtureMultiviewGeometry,
    fx: Double,
    fy: Double,
    cx: Double,
    cy: Double,
    forceOutcome: PoseRefinementOutcome? = nil
  ) throws -> PoseRefinementResult {
    let initialDigest = try graph.digest()
    let sourceSnapshot = graph.nodes.map { ($0.nodeID, $0.sourceTranslation, $0.sourceTransform4x4) }

    let validation = PoseGraphValidator.validate(graph)
    if !validation.ok {
      return PoseRefinementResult(
        outcome: .invalidGraph,
        iterations: [],
        convergence: PoseRefinementConvergence(rule: "GRAPH_VALID", epsilon: configuration.convergenceEpsilon, satisfied: false),
        residuals: PoseResidualSummary(initialMeanResidual: .infinity, finalMeanResidual: .infinity, maxResidual: .infinity),
        refinedGraph: nil,
        initialGraphDigest: initialDigest,
        configurationDigest: configuration.configurationDigest,
        terminationReason: validation.reasons.joined(separator: ","),
        sourcePosesUnchangedProof: true
      )
    }

    if let force = forceOutcome {
      return PoseRefinementResult(
        outcome: force,
        iterations: [],
        convergence: PoseRefinementConvergence(rule: "FORCED", epsilon: configuration.convergenceEpsilon, satisfied: false),
        residuals: PoseResidualSummary(initialMeanResidual: 1, finalMeanResidual: 1, maxResidual: 1),
        refinedGraph: nil,
        initialGraphDigest: initialDigest,
        configurationDigest: configuration.configurationDigest,
        terminationReason: force.rawValue,
        sourcePosesUnchangedProof: true
      )
    }

    if tracks.tracks.isEmpty || graph.visualConstraints.isEmpty {
      return PoseRefinementResult(
        outcome: .insufficientConstraints,
        iterations: [],
        convergence: PoseRefinementConvergence(rule: "MIN_CONSTRAINTS", epsilon: configuration.convergenceEpsilon, satisfied: false),
        residuals: PoseResidualSummary(initialMeanResidual: .infinity, finalMeanResidual: .infinity, maxResidual: .infinity),
        refinedGraph: nil,
        initialGraphDigest: initialDigest,
        configurationDigest: configuration.configurationDigest,
        terminationReason: "INSUFFICIENT_CONSTRAINTS",
        sourcePosesUnchangedProof: true
      )
    }

    // Map camera sample -> node
    let nodeByCamera = Dictionary(uniqueKeysWithValues: graph.nodes.map { ($0.cameraSampleID, $0) })

    func residual(for nodes: [ReconstructionPoseNode]) -> (mean: Double, max: Double, perNode: [String: Double]) {
      var sums: [String: (s: Double, n: Int)] = [:]
      var maxR = 0.0
      for track in tracks.tracks {
        guard let lid = track.fixtureLandmarkID, let pos = geometry.landmarkPosition(lid) else { continue }
        for obs in track.observations {
          guard let node = nodes.first(where: { $0.cameraSampleID == obs.cameraSampleID })
            ?? nodeByCamera[obs.cameraSampleID]
          else { continue }
          let t = node.activeTranslation
          let proj = FixtureMultiviewGeometry.project(
            worldX: pos.0, worldY: pos.1, worldZ: pos.2,
            cameraTranslation: t, fx: fx, fy: fy, cx: cx, cy: cy
          )
          let r = hypot(proj.u - obs.pixelU, proj.v - obs.pixelV)
          maxR = max(maxR, r)
          var acc = sums[node.nodeID] ?? (0, 0)
          acc.s += r
          acc.n += 1
          sums[node.nodeID] = acc
        }
      }
      let per = sums.mapValues { $0.n == 0 ? 0 : $0.s / Double($0.n) }
      let vals = Array(per.values)
      let mean = vals.isEmpty ? 0 : vals.reduce(0, +) / Double(vals.count)
      return (mean, maxR, per)
    }

    var working = graph.nodes.sorted { $0.nodeID < $1.nodeID }
    let initial = residual(for: working)
    if initial.mean <= configuration.convergenceEpsilon {
      return PoseRefinementResult(
        outcome: .noRefinementRequired,
        iterations: [PoseRefinementIteration(iteration: 0, objectiveValue: initial.mean, meanResidual: initial.mean)],
        convergence: PoseRefinementConvergence(rule: "EPSILON", epsilon: configuration.convergenceEpsilon, satisfied: true),
        residuals: PoseResidualSummary(initialMeanResidual: initial.mean, finalMeanResidual: initial.mean, maxResidual: initial.max),
        refinedGraph: nil,
        initialGraphDigest: initialDigest,
        configurationDigest: configuration.configurationDigest,
        terminationReason: "NO_REFINEMENT_REQUIRED",
        sourcePosesUnchangedProof: true
      )
    }

    var iterations: [PoseRefinementIteration] = [
      PoseRefinementIteration(iteration: 0, objectiveValue: initial.mean, meanResidual: initial.mean)
    ]
    var prev = initial.mean

    for iter in 1...configuration.maxIterations {
      // Closed-form translation X correction from known planar landmarks (fixture-only).
      // For R=I projection: u = fx*(X-tx)/Z + cx ⇒ tx = X - (u-cx)*Z/fx
      var refinedNodes: [ReconstructionPoseNode] = []
      for node in working {
        var txs: [Double] = []
        var tys: [Double] = []
        for track in tracks.tracks {
          guard let lid = track.fixtureLandmarkID, let pos = geometry.landmarkPosition(lid),
                let obs = track.observations.first(where: { $0.cameraSampleID == node.cameraSampleID })
          else { continue }
          let Z = pos.2 - node.sourceTranslation[2]
          guard abs(Z) > 1e-12 else { continue }
          let txEst = pos.0 - (obs.pixelU - cx) * Z / fx
          let tyEst = pos.1 - (obs.pixelV - cy) * Z / fy
          if txEst.isFinite { txs.append(txEst) }
          if tyEst.isFinite { tys.append(tyEst) }
        }
        guard !txs.isEmpty else {
          // Keep source as refined (= no change) when underconstrained for this node
          var copy = node
          copy.refinedTranslation = node.sourceTranslation
          copy.refinedTransform4x4 = translationMatrix(node.sourceTranslation)
          copy.refinementAuthority = "RECONSTRUCTION_ESTIMATE"
          refinedNodes.append(copy)
          continue
        }
        let tx = txs.reduce(0, +) / Double(txs.count)
        let ty = tys.isEmpty ? node.sourceTranslation[1] : tys.reduce(0, +) / Double(tys.count)
        let tz = node.sourceTranslation[2]
        if !tx.isFinite || !ty.isFinite {
          throw PoseRefinementFailure.singular("non_finite_correction:\(node.nodeID)")
        }
        var copy = node
        // Source fields untouched
        copy.refinedTranslation = [tx, ty, tz]
        copy.refinedTransform4x4 = translationMatrix([tx, ty, tz])
        copy.refinementAuthority = "RECONSTRUCTION_ESTIMATE"
        refinedNodes.append(copy)
      }
      working = refinedNodes.sorted { $0.nodeID < $1.nodeID }
      let r = residual(for: working)
      iterations.append(PoseRefinementIteration(iteration: iter, objectiveValue: r.mean, meanResidual: r.mean))
      if r.mean > prev * 10 {
        return PoseRefinementResult(
          outcome: .diverged,
          iterations: iterations,
          convergence: PoseRefinementConvergence(rule: "MONOTONE_DECREASE", epsilon: configuration.convergenceEpsilon, satisfied: false),
          residuals: PoseResidualSummary(initialMeanResidual: initial.mean, finalMeanResidual: r.mean, maxResidual: r.max),
          refinedGraph: nil,
          initialGraphDigest: initialDigest,
          configurationDigest: configuration.configurationDigest,
          terminationReason: "DIVERGED",
          sourcePosesUnchangedProof: sourceUnchanged(sourceSnapshot, working)
        )
      }
      if abs(prev - r.mean) <= configuration.convergenceEpsilon || r.mean <= configuration.convergenceEpsilon {
        prev = r.mean
        break
      }
      prev = r.mean
    }

    let final = residual(for: working)
    // Prove source fields unchanged
    let unchanged = sourceUnchanged(sourceSnapshot, working)
    if !unchanged {
      throw PoseRefinementFailure.sourcePoseMutationAttempt("source_fields_mutated")
    }

    var refinedGraph = graph
    refinedGraph.nodes = working
    refinedGraph.graphID = "\(graph.graphID)-REFINED"

    let converged = final.mean <= initial.mean + 1e-12
    let outcome: PoseRefinementOutcome = converged ? .converged : .manualReviewRequired

    return PoseRefinementResult(
      outcome: outcome,
      iterations: iterations,
      convergence: PoseRefinementConvergence(
        rule: "EPSILON_OR_MONOTONE",
        epsilon: configuration.convergenceEpsilon,
        satisfied: outcome == .converged
      ),
      residuals: PoseResidualSummary(
        initialMeanResidual: initial.mean,
        finalMeanResidual: final.mean,
        maxResidual: final.max
      ),
      refinedGraph: outcome == .converged ? refinedGraph : nil,
      initialGraphDigest: initialDigest,
      configurationDigest: configuration.configurationDigest,
      terminationReason: outcome.rawValue,
      sourcePosesUnchangedProof: unchanged
    )
  }

  private func translationMatrix(_ t: [Double]) -> [Double] {
    var m = HomogeneousMatrix4x4.identity()
    m[12] = t[0]; m[13] = t[1]; m[14] = t[2]
    return m
  }

  private func sourceUnchanged(
    _ snapshot: [(String, [Double], [Double])],
    _ nodes: [ReconstructionPoseNode]
  ) -> Bool {
    let byID = Dictionary(uniqueKeysWithValues: nodes.map { ($0.nodeID, $0) })
    for (id, t, m) in snapshot {
      guard let n = byID[id] else { return false }
      if n.sourceTranslation != t || n.sourceTransform4x4 != m { return false }
    }
    return true
  }
}

// MARK: - Quality / comparison / lineage (Phase 4B)

public struct FeatureTrackQualitySummary: Equatable, Sendable {
  public var detectedFeatureCount: Int
  public var acceptedMatchCount: Int
  public var rejectedMatchCount: Int
  public var geometricInlierCount: Int
  public var geometricOutlierCount: Int
  public var featureTrackCount: Int
  public var meanFeatureTrackLength: Double

  public func dictionary() -> [String: Any] {
    [
      "detected_feature_count": detectedFeatureCount,
      "accepted_match_count": acceptedMatchCount,
      "rejected_match_count": rejectedMatchCount,
      "geometric_inlier_count": geometricInlierCount,
      "geometric_outlier_count": geometricOutlierCount,
      "feature_track_count": featureTrackCount,
      "mean_feature_track_length": meanFeatureTrackLength,
    ]
  }
}

public struct PoseGraphQualitySummary: Equatable, Sendable {
  public var nodeCount: Int
  public var edgeCount: Int
  public var initialPoseResidual: Double
  public var finalPoseResidual: Double
  public var convergenceStatus: String

  public func dictionary() -> [String: Any] {
    [
      "pose_graph_node_count": nodeCount,
      "pose_graph_edge_count": edgeCount,
      "initial_pose_residual": initialPoseResidual,
      "final_pose_residual": finalPoseResidual,
      "convergence_status": convergenceStatus,
    ]
  }
}

public struct PoseRefinementQualityRecord: Equatable, Sendable {
  public var feature: FeatureTrackQualitySummary
  public var poseGraph: PoseGraphQualitySummary
  public var sourcePosePointCloudError: Double
  public var refinedPosePointCloudError: Double
  public var lineageCompleteness: Double
  public var engineeringMetrologyClaim: String
  public var productionPhotogrammetryClaim: String

  public func dictionary() -> [String: Any] {
    [
      "feature": feature.dictionary(),
      "pose_graph": poseGraph.dictionary(),
      "source_pose_point_cloud_error": sourcePosePointCloudError,
      "refined_pose_point_cloud_error": refinedPosePointCloudError,
      "lineage_completeness": lineageCompleteness,
      "engineering_metrology_claim": engineeringMetrologyClaim,
      "production_photogrammetry_claim": productionPhotogrammetryClaim,
      "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
      "schema_id": "PoseRefinementQualityRecord",
      "schema_version": "1.0.0-phase4b-fixture",
    ]
  }
}

public struct ReconstructionComparisonRecord: Equatable, Sendable {
  public var sourcePointCount: Int
  public var refinedPointCount: Int
  public var sourceRegistrationResidual: Double
  public var refinedRegistrationResidual: Double
  public var sourceGroundTruthDelta: Double
  public var refinedGroundTruthDelta: Double
  public var poseResidualInitial: Double
  public var poseResidualFinal: Double
  public var sourceBoundingBox: [[Double]]
  public var refinedBoundingBox: [[Double]]
  public var sourceLineageComplete: Bool
  public var refinedLineageComplete: Bool

  public func dictionary() -> [String: Any] {
    [
      "source_point_count": sourcePointCount,
      "refined_point_count": refinedPointCount,
      "source_registration_residual": sourceRegistrationResidual,
      "refined_registration_residual": refinedRegistrationResidual,
      "source_ground_truth_delta": sourceGroundTruthDelta,
      "refined_ground_truth_delta": refinedGroundTruthDelta,
      "pose_residual_initial": poseResidualInitial,
      "pose_residual_final": poseResidualFinal,
      "source_bounding_box": sourceBoundingBox,
      "refined_bounding_box": refinedBoundingBox,
      "source_lineage_complete": sourceLineageComplete,
      "refined_lineage_complete": refinedLineageComplete,
      "schema_id": "ReconstructionComparisonRecord",
      "schema_version": "1.0.0-phase4b-fixture",
    ]
  }
}

public struct Phase4BSpatialLineageManifest: Equatable, Sendable {
  public var lineageManifestID: String
  public var sourcePackageID: String
  public var sourcePackageClosureSHA256: String
  public var featureAlgorithmID: String
  public var matchingPolicyID: String
  public var geometricPolicyID: String
  public var optimizationConfigurationDigest: String
  public var outputArtifactHashes: [String: String]
  public var lineageManifestSHA256: String

  public func dictionary() -> [String: Any] {
    [
      "lineage_manifest_id": lineageManifestID,
      "source_package_id": sourcePackageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "feature_algorithm_id": featureAlgorithmID,
      "matching_policy_id": matchingPolicyID,
      "geometric_validation_policy_id": geometricPolicyID,
      "optimization_configuration_digest": optimizationConfigurationDigest,
      "output_artifact_hashes": outputArtifactHashes,
      "lineage_manifest_sha256": lineageManifestSHA256,
      "authority": "TEST_FIXTURE",
      "reproducibility_status": "DETERMINISTIC_FIXTURE_REPLAY",
      "schema_id": "Phase4BSpatialLineageManifest",
      "schema_version": "1.0.0-phase4b-fixture",
    ]
  }
}
