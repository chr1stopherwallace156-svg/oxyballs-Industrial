import Foundation

// MARK: - Voxel identity + occupancy

public struct VoxelCoordinate: Hashable, Codable, Sendable, Equatable, Comparable {
  public var ix: Int
  public var iy: Int
  public var iz: Int

  public var voxelKey: String { "VX:\(ix):\(iy):\(iz)" }

  public static func < (lhs: VoxelCoordinate, rhs: VoxelCoordinate) -> Bool {
    if lhs.ix != rhs.ix { return lhs.ix < rhs.ix }
    if lhs.iy != rhs.iy { return lhs.iy < rhs.iy }
    return lhs.iz < rhs.iz
  }

  public func dictionary() -> [String: Any] {
    ["ix": ix, "iy": iy, "iz": iz, "voxel_key": voxelKey]
  }
}

public enum VoxelOccupancyState: String, Codable, Sendable, Equatable {
  case empty = "EMPTY"
  case occupied = "OCCUPIED"
  case conflicted = "CONFLICTED"
  case contradictory = "CONTRADICTORY" // alias retained for prior records
  case quarantined = "QUARANTINED"
}

public struct FusionAccumulator: Equatable, Sendable {
  public var sumWX: Double = 0
  public var sumWY: Double = 0
  public var sumWZ: Double = 0
  public var sumW: Double = 0
  public var observationCount: Int = 0
  public var sourcePointIDs: [String] = []
  public var sourceObservationIDs: [String] = []
  public var maxConfidence: Double = 0
  public var minConfidence: Double = .infinity

  public mutating func add(x: Double, y: Double, z: Double, weight: Double, pointID: String, observationID: String, confidence: Double) {
    sumWX += x * weight
    sumWY += y * weight
    sumWZ += z * weight
    sumW += weight
    observationCount += 1
    sourcePointIDs.append(pointID)
    sourceObservationIDs.append(observationID)
    maxConfidence = max(maxConfidence, confidence)
    minConfidence = min(minConfidence, confidence)
  }

  public var weightedPosition: (Double, Double, Double)? {
    guard sumW > 0 else { return nil }
    return (sumWX / sumW, sumWY / sumW, sumWZ / sumW)
  }
}

public struct FusionVoxel: Equatable, Sendable {
  public var coordinate: VoxelCoordinate
  public var occupancy: VoxelOccupancyState
  public var accumulator: FusionAccumulator
  public var contributionIDs: [String]

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "voxel_coordinate": coordinate.dictionary(),
      "occupancy": occupancy.rawValue,
      "observation_count": accumulator.observationCount,
      "contribution_ids": contributionIDs.sorted(),
      "source_point_ids": accumulator.sourcePointIDs.sorted(),
      "source_observation_ids": accumulator.sourceObservationIDs.sorted(),
      "sum_weight": accumulator.sumW,
    ]
    if let p = accumulator.weightedPosition {
      d["weighted_position"] = ["x": p.0, "y": p.1, "z": p.2]
    }
    return d
  }
}

public struct FusionGrid: Equatable, Sendable {
  public var voxelSizeMeters: Double
  public var voxels: [String: FusionVoxel]

  public var occupiedCount: Int {
    voxels.values.filter {
      $0.occupancy == .occupied || $0.occupancy == .conflicted || $0.occupancy == .contradictory || $0.occupancy == .quarantined
    }.count
  }

  public func dictionary() -> [String: Any] {
    let sorted = voxels.keys.sorted().compactMap { voxels[$0] }
    return [
      "voxel_size_meters": voxelSizeMeters,
      "voxel_count": sorted.count,
      "occupied_voxel_count": occupiedCount,
      "voxels": sorted.map { $0.dictionary() },
      "schema_id": "FusionGrid",
      "schema_version": "1.0.0-phase4c-fixture",
    ]
  }
}

// MARK: - Contributions

public enum ContributionRejectionReason: String, Codable, Sendable, Equatable {
  case nonFinite = "NON_FINITE"
  case invalidConfidence = "INVALID_CONFIDENCE"
  case invalidValidity = "INVALID_VALIDITY"
  case outsideExtent = "OUTSIDE_EXTENT"
  case voxelLimit = "VOXEL_LIMIT"
  case cancelled = "CANCELLED"
  case resourceBound = "RESOURCE_BOUND"
  case angleWeightUnavailable = "ANGLE_WEIGHT_NOT_AVAILABLE"
  case zeroWeight = "ZERO_WEIGHT"
}

public struct PointConfidence: Equatable, Sendable {
  public var depthConfidence: Double
  public var poseRefinementConfidence: Double
  public var featureTrackSupport: Double
  public var observationAngleWeight: Double
  public var declaredConfidence: Double

  public func dictionary() -> [String: Any] {
    [
      "depth_confidence": depthConfidence,
      "pose_refinement_confidence": poseRefinementConfidence,
      "feature_track_support": featureTrackSupport,
      "observation_angle_weight": observationAngleWeight,
      "declared_confidence": declaredConfidence,
    ]
  }
}

public struct ConfidenceWeightingPolicy: Equatable, Sendable {
  public var policyID: String
  public var policyVersion: String
  public var gamma: Double
  public var allowNeutralAngleFactor: Bool
  public var neutralAngleFactor: Double
  public var weightNormalizationFactor: Double

  public static let fixture = ConfidenceWeightingPolicy(
    policyID: "DFUSE-CONF-POL-FIXTURE-000001",
    policyVersion: "1.0.0-phase4c-fixture",
    gamma: 1.5,
    allowNeutralAngleFactor: true,
    neutralAngleFactor: 1.0,
    weightNormalizationFactor: 1.0
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "policy_version": policyVersion,
      "gamma": gamma,
      "weight_formula": "w_i = c_depth * c_pose * max(0, cos(theta_i))^gamma",
      "allow_neutral_angle_factor": allowNeutralAngleFactor,
      "neutral_angle_factor": neutralAngleFactor,
      "weight_normalization_factor": weightNormalizationFactor,
      "note": "Versioned fixture weights — not physical sensor uncertainty",
    ]
  }
}

public struct ConfidenceWeightingResult: Equatable, Sendable {
  public var weight: Double
  public var components: PointConfidence
  public var policyID: String
  public var angleWeightStatus: String

  public func dictionary() -> [String: Any] {
    [
      "weight": weight,
      "components": components.dictionary(),
      "policy_id": policyID,
      "angle_weight_status": angleWeightStatus,
    ]
  }
}

public struct FusionPointContribution: Equatable, Sendable {
  public var contributionID: String
  public var sourceRegisteredPointID: String
  public var sourceObservationID: String
  public var sourceDepthSampleID: String
  public var sourcePixelU: Int
  public var sourcePixelV: Int
  public var sourcePoseID: String
  public var refinedPoseID: String?
  public var sourcePackageClosure: String
  public var sourceReconstructionClosure: String
  public var x: Double
  public var y: Double
  public var z: Double
  public var confidence: PointConfidence
  public var validity: PointValidityClassification
  public var observationAngleDegrees: Double?
  public var depthValidity: String
  public var fusionVoxelID: String?
  public var derivationID: String
  public var weight: Double
  public var rejected: Bool
  public var rejectionReason: ContributionRejectionReason?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "contribution_id": contributionID,
      "source_registered_point_id": sourceRegisteredPointID,
      "source_observation_id": sourceObservationID,
      "source_depth_sample_id": sourceDepthSampleID,
      "source_pixel_coordinate": ["u": sourcePixelU, "v": sourcePixelV],
      "source_pose_id": sourcePoseID,
      "source_package_closure": sourcePackageClosure,
      "source_reconstruction_closure": sourceReconstructionClosure,
      "position": ["x": x, "y": y, "z": z],
      "confidence": confidence.dictionary(),
      "validity": validity.rawValue,
      "depth_validity_classification": depthValidity,
      "derivation_id": derivationID,
      "weight": weight,
      "rejected": rejected,
    ]
    if let fusionVoxelID { d["fusion_voxel_id"] = fusionVoxelID }
    if let refinedPoseID { d["refined_pose_id"] = refinedPoseID }
    if let observationAngleDegrees { d["observation_angle_degrees"] = observationAngleDegrees }
    if let rejectionReason { d["rejection_reason"] = rejectionReason.rawValue }
    return d
  }
}

public struct ConfidenceWeightingEngine: Sendable {
  public var policy: ConfidenceWeightingPolicy

  public init(policy: ConfidenceWeightingPolicy = .fixture) {
    self.policy = policy
  }

  public func clamp01(_ v: Double) -> Double {
    guard v.isFinite else { return .nan }
    return min(1.0, max(0.0, v))
  }

  /// w_i = c_depth * c_pose * max(0, cos(theta))^gamma
  public func weight(_ c: PointConfidence, observationAngleRadians: Double?) -> ConfidenceWeightingResult {
    let cDepth = clamp01(c.depthConfidence)
    let cPose = clamp01(c.poseRefinementConfidence)
    let angleStatus: String
    let angleFactor: Double
    if let theta = observationAngleRadians, theta.isFinite {
      angleFactor = pow(max(0.0, cos(theta)), policy.gamma)
      angleStatus = "ANGLE_WEIGHT_APPLIED"
    } else if policy.allowNeutralAngleFactor {
      angleFactor = policy.neutralAngleFactor
      angleStatus = "ANGLE_WEIGHT_NOT_AVAILABLE"
    } else {
      return ConfidenceWeightingResult(
        weight: .nan,
        components: c,
        policyID: policy.policyID,
        angleWeightStatus: "ANGLE_WEIGHT_NOT_AVAILABLE"
      )
    }
    let w = cDepth * cPose * angleFactor
    return ConfidenceWeightingResult(weight: w, components: c, policyID: policy.policyID, angleWeightStatus: angleStatus)
  }
}

// MARK: - Backend protocol

public protocol FusionBackend: Sendable {
  var backendID: String { get }
  func fuse(
    contributions: [FusionPointContribution],
    configuration: FusionConfigurationDigest,
    contradictionDeltaMeters: Double,
    isCancelled: () -> Bool
  ) throws -> (grid: FusionGrid, updatedContributions: [FusionPointContribution], failure: FusionFailure?)
}

public enum FusionFailure: Error, Equatable, Sendable {
  case cancelled(String)
  case voxelLimitExceeded(Int)
  case extentOverflow(String)
  case insufficientObservations(String)
  case invalidConfiguration(String)
  case allPointsRejected(String)
  case resourceBound(String)
}

public struct FusionResult: Equatable, Sendable {
  public var grid: FusionGrid
  public var contributions: [FusionPointContribution]
  public var backendID: String
  public var configurationDigest: String

  public func dictionary() -> [String: Any] {
    [
      "backend_id": backendID,
      "configuration_digest": configurationDigest,
      "grid": grid.dictionary(),
      "contribution_count": contributions.count,
      "accepted_contribution_count": contributions.filter { !$0.rejected }.count,
      "rejected_contribution_count": contributions.filter(\.rejected).count,
    ]
  }
}

public struct DeterministicVoxelFusionBackend: FusionBackend {
  public let backendID = "DeterministicVoxelFusionBackend"

  public init() {}

  public func voxelCoordinate(x: Double, y: Double, z: Double, voxelSize: Double) -> VoxelCoordinate {
    // Floor division with stable negative handling
    func q(_ v: Double) -> Int {
      Int(floor(v / voxelSize))
    }
    return VoxelCoordinate(ix: q(x), iy: q(y), iz: q(z))
  }

  public func fuse(
    contributions: [FusionPointContribution],
    configuration: FusionConfigurationDigest,
    contradictionDeltaMeters: Double,
    isCancelled: () -> Bool
  ) throws -> (grid: FusionGrid, updatedContributions: [FusionPointContribution], failure: FusionFailure?) {
    guard configuration.voxelSizeMeters > 0 else {
      throw FusionFailure.invalidConfiguration("voxel_size")
    }
    var voxels: [String: FusionVoxel] = [:]
    var updated: [FusionPointContribution] = []
    updated.reserveCapacity(contributions.count)

    let sorted = contributions.sorted { $0.contributionID < $1.contributionID }
    for var c in sorted {
      if isCancelled() {
        return (
          FusionGrid(voxelSizeMeters: configuration.voxelSizeMeters, voxels: voxels),
          updated + [c],
          .cancelled("during_fuse")
        )
      }
      if c.rejected {
        updated.append(c)
        continue
      }
      if c.x < configuration.spatialExtentMin[0] || c.y < configuration.spatialExtentMin[1] || c.z < configuration.spatialExtentMin[2]
        || c.x > configuration.spatialExtentMax[0] || c.y > configuration.spatialExtentMax[1] || c.z > configuration.spatialExtentMax[2]
      {
        c.rejected = true
        c.rejectionReason = .outsideExtent
        updated.append(c)
        continue
      }

      let coord = voxelCoordinate(x: c.x, y: c.y, z: c.z, voxelSize: configuration.voxelSizeMeters)
      let key = coord.voxelKey
      if voxels[key] == nil, voxels.count >= configuration.maxVoxelCount {
        c.rejected = true
        c.rejectionReason = .voxelLimit
        updated.append(c)
        return (
          FusionGrid(voxelSizeMeters: configuration.voxelSizeMeters, voxels: voxels),
          updated,
          .voxelLimitExceeded(configuration.maxVoxelCount)
        )
      }

      var voxel = voxels[key] ?? FusionVoxel(
        coordinate: coord,
        occupancy: .empty,
        accumulator: FusionAccumulator(),
        contributionIDs: []
      )

      if voxel.contributionIDs.count >= configuration.maxContributorsPerVoxel {
        c.rejected = true
        c.rejectionReason = .resourceBound
        updated.append(c)
        continue
      }

      // Contradiction: new sample far from existing consensus in same voxel
      if let pos = voxel.accumulator.weightedPosition, voxel.accumulator.observationCount > 0 {
        let dx = c.x - pos.0, dy = c.y - pos.1, dz = c.z - pos.2
        let dist = (dx * dx + dy * dy + dz * dz).squareRoot()
        // Within a voxel, use a bounded threshold so fixture conflicts are detectable.
        let threshold = min(contradictionDeltaMeters, configuration.voxelSizeMeters * 0.75)
        if dist > threshold {
          voxel.occupancy = .conflicted
          c.fusionVoxelID = key
          voxel.contributionIDs.append(c.contributionID)
          // Do not merge into accumulator — keep auditable conflict path
          voxels[key] = voxel
          updated.append(c)
          continue
        }
      }

      guard c.weight.isFinite, c.weight > 0 else {
        c.rejected = true
        c.rejectionReason = .invalidConfidence
        updated.append(c)
        continue
      }

      voxel.accumulator.add(
        x: c.x, y: c.y, z: c.z,
        weight: c.weight,
        pointID: c.sourceRegisteredPointID,
        observationID: c.sourceObservationID,
        confidence: c.confidence.declaredConfidence
      )
      voxel.occupancy = .occupied
      voxel.contributionIDs.append(c.contributionID)
      c.fusionVoxelID = key
      voxels[key] = voxel
      updated.append(c)
    }

    return (FusionGrid(voxelSizeMeters: configuration.voxelSizeMeters, voxels: voxels), updated, nil)
  }
}

public struct DenseFusionEngine: Sendable {
  public var backend: DeterministicVoxelFusionBackend
  public var weighting: ConfidenceWeightingEngine
  public var contradictionDeltaMeters: Double

  public init(
    backend: DeterministicVoxelFusionBackend = DeterministicVoxelFusionBackend(),
    weighting: ConfidenceWeightingEngine = ConfidenceWeightingEngine(),
    contradictionDeltaMeters: Double = 0.15
  ) {
    self.backend = backend
    self.weighting = weighting
    self.contradictionDeltaMeters = contradictionDeltaMeters
  }

  public func buildContributions(
    from cloud: RegisteredPointCloud,
    inventory: DenseFusionInputInventory,
    trackSupport: [String: Double],
    poseRefinementConfidence: Double,
    useRefinedPoseIDs: Bool,
    maxInputPoints: Int,
    isCancelled: () -> Bool
  ) throws -> [FusionPointContribution] {
    var out: [FusionPointContribution] = []
    let points = cloud.points.sorted { $0.pointID < $1.pointID }
    if points.count > maxInputPoints {
      throw FusionFailure.resourceBound("max_input_points")
    }
    for p in points {
      if isCancelled() { throw FusionFailure.cancelled("during_contributions") }
      let declared = p.confidence ?? 1.0
      let track = trackSupport[p.pointID] ?? 0.5
      let components = PointConfidence(
        depthConfidence: declared,
        poseRefinementConfidence: poseRefinementConfidence,
        featureTrackSupport: track,
        observationAngleWeight: 1.0,
        declaredConfidence: declared
      )
      let wr = weighting.weight(components, observationAngleRadians: nil)
      var rejected = false
      var reason: ContributionRejectionReason?
      if p.validity != .valid {
        rejected = true
        reason = .invalidValidity
      } else if !p.x.isFinite || !p.y.isFinite || !p.z.isFinite || !wr.weight.isFinite {
        rejected = true
        reason = .nonFinite
      } else if !declared.isFinite || declared < 0 {
        rejected = true
        reason = .invalidConfidence
      } else if wr.weight <= 0 {
        rejected = true
        reason = .zeroWeight
      }
      out.append(
        FusionPointContribution(
          contributionID: "CTR-\(p.pointID)",
          sourceRegisteredPointID: p.pointID,
          sourceObservationID: p.sourceFrameID,
          sourceDepthSampleID: p.source.depthSampleID,
          sourcePixelU: p.source.pixelU,
          sourcePixelV: p.source.pixelV,
          sourcePoseID: p.source.poseSampleID,
          refinedPoseID: useRefinedPoseIDs ? "REFINED-\(p.source.poseSampleID)" : nil,
          sourcePackageClosure: inventory.sourcePackageClosureSHA256,
          sourceReconstructionClosure: inventory.phase4BClosureSHA256,
          x: p.x, y: p.y, z: p.z,
          confidence: components,
          validity: p.validity,
          observationAngleDegrees: nil,
          depthValidity: p.validity.rawValue,
          fusionVoxelID: nil,
          derivationID: "DER-CTR-\(p.pointID)",
          weight: wr.weight.isFinite ? wr.weight : 0,
          rejected: rejected,
          rejectionReason: reason
        )
      )
    }
    return out.sorted { $0.contributionID < $1.contributionID }
  }

  public func fuse(
    contributions: [FusionPointContribution],
    configuration: FusionConfigurationDigest,
    isCancelled: () -> Bool = { false }
  ) throws -> FusionResult {
    let (grid, updated, failure) = try backend.fuse(
      contributions: contributions,
      configuration: configuration,
      contradictionDeltaMeters: contradictionDeltaMeters,
      isCancelled: isCancelled
    )
    if let failure { throw failure }
    let accepted = updated.filter { !$0.rejected }
    if accepted.isEmpty {
      throw FusionFailure.allPointsRejected("no_accepted_contributions")
    }
    return FusionResult(
      grid: grid,
      contributions: updated.sorted { $0.contributionID < $1.contributionID },
      backendID: backend.backendID,
      configurationDigest: configuration.digest
    )
  }
}
