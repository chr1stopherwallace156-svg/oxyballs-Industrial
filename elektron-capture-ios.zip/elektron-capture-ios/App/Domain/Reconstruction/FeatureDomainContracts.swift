import Foundation

// MARK: - Feature domain contracts (Phase 4B)

public enum FeatureRejectionReason: String, Codable, Sendable, Equatable {
  case missingDescriptor = "MISSING_DESCRIPTOR"
  case malformedDescriptor = "MALFORMED_DESCRIPTOR"
  case nonFiniteDescriptor = "NON_FINITE_DESCRIPTOR"
  case unsupportedFormat = "UNSUPPORTED_DESCRIPTOR_FORMAT"
  case weakResponse = "WEAK_RESPONSE"
  case duplicateFeatureID = "DUPLICATE_FEATURE_ID"
  case policyRejected = "POLICY_REJECTED"
}

public struct FeatureDescriptorVector: Equatable, Sendable {
  public var descriptorID: String
  public var format: String
  public var values: [Double]

  public func dictionary() -> [String: Any] {
    [
      "descriptor_id": descriptorID,
      "format": format,
      "values": values,
      "values_sha256": ContentHasher.sha256Hex(Data(values.map { String($0) }.joined(separator: ",").utf8)),
    ]
  }

  public var isFinite: Bool { values.allSatisfy(\.isFinite) }
}

public struct FeatureObservation: Equatable, Sendable {
  public var featureObservationID: String
  public var cameraSampleID: String
  public var sourceArtifactID: String
  public var sourceArtifactSHA256: String
  public var pixelU: Double
  public var pixelV: Double
  public var scale: Double
  public var orientation: Double
  public var response: Double
  public var descriptor: FeatureDescriptorVector
  public var frameEpochID: String
  public var sessionRunID: String
  public var worldOriginRevision: UInt64
  public var algorithmID: String
  public var algorithmVersion: String
  public var configurationDigest: String
  public var derivationID: String
  public var evidenceOriginAuthority: String
  public var reconstructionAuthority: String
  /// Fixture landmark binding (TEST_FIXTURE only).
  public var fixtureLandmarkID: String?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "feature_observation_id": featureObservationID,
      "camera_sample_id": cameraSampleID,
      "source_artifact_id": sourceArtifactID,
      "source_artifact_sha256": sourceArtifactSHA256,
      "pixel_coordinate": ["u": pixelU, "v": pixelV],
      "scale": scale,
      "orientation": orientation,
      "response": response,
      "descriptor": descriptor.dictionary(),
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "algorithm_id": algorithmID,
      "algorithm_version": algorithmVersion,
      "configuration_digest": configurationDigest,
      "derivation_id": derivationID,
      "evidence_origin_authority": evidenceOriginAuthority,
      "reconstruction_authority": reconstructionAuthority,
    ]
    if let fixtureLandmarkID { d["fixture_landmark_id"] = fixtureLandmarkID }
    return d
  }
}

public struct FeatureDetectionPolicy: Equatable, Sendable {
  public var policyID: String
  public var policyVersion: String
  public var minResponse: Double
  public var descriptorFormat: String
  public var descriptorLength: Int
  public var characterizationStatus: String
  public var systemTolerance: String

  public static let fixture = FeatureDetectionPolicy(
    policyID: "FEAT-DET-POL-FIXTURE-000001",
    policyVersion: "1.0.0-phase4b-fixture",
    minResponse: 0.1,
    descriptorFormat: "SYNTHETIC_FLOAT64_V1",
    descriptorLength: 8,
    characterizationStatus: "DETERMINISTIC_TEST_FIXTURE",
    systemTolerance: "NO_SYSTEM_TOLERANCE_ASSIGNED"
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "policy_version": policyVersion,
      "min_response": minResponse,
      "descriptor_format": descriptorFormat,
      "descriptor_length": descriptorLength,
      "characterization_status": characterizationStatus,
      "system_tolerance": systemTolerance,
      "note": "Fixture detector — not Apple Vision / OpenCV / Metal parity",
    ]
  }

  public var configurationDigest: String {
    ContentHasher.sha256Hex(Data("\(policyID)|\(policyVersion)|\(minResponse)|\(descriptorFormat)|\(descriptorLength)".utf8))
  }
}

public struct FeatureRejectionRecord: Equatable, Sendable {
  public var id: String
  public var reason: FeatureRejectionReason

  public func dictionary() -> [String: Any] {
    ["feature_observation_id": id, "reason": reason.rawValue]
  }
}

public struct FrameFeatureSet: Equatable, Sendable {
  public var cameraSampleID: String
  public var observations: [FeatureObservation]
  public var rejected: [FeatureRejectionRecord]

  public func dictionary() -> [String: Any] {
    [
      "camera_sample_id": cameraSampleID,
      "observations": observations.sorted { $0.featureObservationID < $1.featureObservationID }.map { $0.dictionary() },
      "rejected": rejected.sorted { $0.id < $1.id }.map { $0.dictionary() },
      "detected_feature_count": observations.count,
    ]
  }
}

public struct FeatureDetectionResult: Equatable, Sendable {
  public var frameSets: [FrameFeatureSet]
  public var policy: FeatureDetectionPolicy
  public var algorithmID: String
  public var algorithmVersion: String

  public var allObservations: [FeatureObservation] {
    frameSets.flatMap(\.observations).sorted { $0.featureObservationID < $1.featureObservationID }
  }

  public func dictionary() -> [String: Any] {
    [
      "frame_sets": frameSets.sorted { $0.cameraSampleID < $1.cameraSampleID }.map { $0.dictionary() },
      "policy": policy.dictionary(),
      "algorithm_id": algorithmID,
      "algorithm_version": algorithmVersion,
      "detected_feature_count": allObservations.count,
      "schema_id": "FeatureDetectionResult",
      "schema_version": "1.0.0-phase4b-fixture",
    ]
  }
}

/// Deterministic synthetic fixture detector — not production Vision/OpenCV.
public struct FixtureSyntheticFeatureDetector: Sendable {
  public static let algorithmID = "ALG-FEATURE-SYNTHETIC-FIXTURE-V1"
  public static let algorithmVersion = "4B.0.0"

  public var policy: FeatureDetectionPolicy

  public init(policy: FeatureDetectionPolicy = .fixture) {
    self.policy = policy
  }

  /// Emit one observation per landmark projection for a camera frame.
  public func detect(
    cameraSampleID: String,
    sourceArtifactID: String,
    sourceArtifactSHA256: String,
    projections: [(landmarkID: String, u: Double, v: Double, response: Double)],
    frameEpochID: String,
    sessionRunID: String,
    worldOriginRevision: UInt64
  ) throws -> FrameFeatureSet {
    var observations: [FeatureObservation] = []
    var rejected: [FeatureRejectionRecord] = []
    var seen = Set<String>()

    for p in projections.sorted(by: { $0.landmarkID < $1.landmarkID }) {
      let fid = "FO-\(cameraSampleID)-\(p.landmarkID)"
      if !seen.insert(fid).inserted {
        rejected.append(FeatureRejectionRecord(id: fid, reason: .duplicateFeatureID))
        continue
      }
      if p.response < policy.minResponse {
        rejected.append(FeatureRejectionRecord(id: fid, reason: .weakResponse))
        continue
      }
      let descriptor = Self.descriptor(forLandmark: p.landmarkID, format: policy.descriptorFormat, length: policy.descriptorLength)
      guard descriptor.isFinite else {
        rejected.append(FeatureRejectionRecord(id: fid, reason: .nonFiniteDescriptor))
        continue
      }
      guard descriptor.format == policy.descriptorFormat, descriptor.values.count == policy.descriptorLength else {
        rejected.append(FeatureRejectionRecord(id: fid, reason: .unsupportedFormat))
        continue
      }
      observations.append(
        FeatureObservation(
          featureObservationID: fid,
          cameraSampleID: cameraSampleID,
          sourceArtifactID: sourceArtifactID,
          sourceArtifactSHA256: sourceArtifactSHA256,
          pixelU: p.u,
          pixelV: p.v,
          scale: 1.0,
          orientation: 0.0,
          response: p.response,
          descriptor: descriptor,
          frameEpochID: frameEpochID,
          sessionRunID: sessionRunID,
          worldOriginRevision: worldOriginRevision,
          algorithmID: Self.algorithmID,
          algorithmVersion: Self.algorithmVersion,
          configurationDigest: policy.configurationDigest,
          derivationID: "DER-FEAT-\(fid)",
          evidenceOriginAuthority: "TEST_FIXTURE",
          reconstructionAuthority: "RECONSTRUCTION_ESTIMATE",
          fixtureLandmarkID: p.landmarkID
        )
      )
    }
    return FrameFeatureSet(cameraSampleID: cameraSampleID, observations: observations, rejected: rejected)
  }

  public static func descriptor(forLandmark landmarkID: String, format: String, length: Int) -> FeatureDescriptorVector {
    // Deterministic 8-float vector from landmark ID bytes — fixture-only.
    var values: [Double] = []
    let bytes = Array(landmarkID.utf8)
    for i in 0..<length {
      let b = bytes.isEmpty ? 0 : Int(bytes[i % bytes.count])
      values.append(Double(b + i * 17) / 255.0)
    }
    return FeatureDescriptorVector(
      descriptorID: "DESC-\(landmarkID)",
      format: format,
      values: values
    )
  }
}

// MARK: - Multiview fixture geometry

public struct FixtureMultiviewGeometry: Equatable, Sendable {
  public static let geometryID = "GEOM-FIXTURE-MULTIVIEW-TARGET-000001"

  public var geometryID: String
  public var landmarks: [[String: Double]]
  public var trueCameraTranslations: [[Double]]
  public var injectedPosePerturbations: [[Double]]
  public var authority: String

  public static func multiviewTarget() -> FixtureMultiviewGeometry {
    // Planar Z=2 landmarks; 3 cameras along +X with 0.05m injected X perturbation on frames 1,2.
    let landmarks: [[String: Double]] = [
      ["landmark_id_hash": 0, "x": -0.02, "y": -0.02, "z": 2.0],
      ["landmark_id_hash": 1, "x": 0.02, "y": -0.02, "z": 2.0],
      ["landmark_id_hash": 2, "x": -0.02, "y": 0.02, "z": 2.0],
      ["landmark_id_hash": 3, "x": 0.02, "y": 0.02, "z": 2.0],
      ["landmark_id_hash": 4, "x": 0.0, "y": 0.0, "z": 2.0],
    ]
    return FixtureMultiviewGeometry(
      geometryID: geometryID,
      landmarks: landmarks,
      trueCameraTranslations: [[0, 0, 0], [0.1, 0, 0], [0.2, 0, 0]],
      injectedPosePerturbations: [[0, 0, 0], [0.05, 0, 0], [0.05, 0, 0]],
      authority: "TEST_FIXTURE_GROUND_TRUTH"
    )
  }

  public var landmarkIDs: [String] {
    (0..<landmarks.count).map { "LM-\($0)" }
  }

  public func landmarkPosition(_ id: String) -> (Double, Double, Double)? {
    guard let idx = Int(id.replacingOccurrences(of: "LM-", with: "")),
          idx >= 0, idx < landmarks.count,
          let x = landmarks[idx]["x"], let y = landmarks[idx]["y"], let z = landmarks[idx]["z"]
    else { return nil }
    return (x, y, z)
  }

  public func dictionary() -> [String: Any] {
    [
      "geometry_id": geometryID,
      "kind": "MULTIVIEW_PLANAR_TARGET",
      "landmarks": landmarks,
      "landmark_ids": landmarkIDs,
      "true_camera_translations": trueCameraTranslations,
      "injected_pose_perturbations": injectedPosePerturbations,
      "geometry_reference_authority": authority,
      "schema_id": "FixtureMultiviewGeometry",
      "schema_version": "1.0.0-phase4b-fixture",
      "note": "Fixture ground truth is not physical metrology",
    ]
  }

  public static func project(
    worldX: Double, worldY: Double, worldZ: Double,
    cameraTranslation: [Double],
    fx: Double, fy: Double, cx: Double, cy: Double
  ) -> (u: Double, v: Double) {
    let tx = cameraTranslation[0], ty = cameraTranslation[1], tz = cameraTranslation[2]
    let X = worldX - tx
    let Y = worldY - ty
    let Z = worldZ - tz
    return (fx * X / Z + cx, fy * Y / Z + cy)
  }
}
