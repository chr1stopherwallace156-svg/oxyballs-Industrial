import Foundation

// MARK: - Observations

public struct ObservationRejectionRecord: Codable, Sendable, Equatable {
  public var observationID: String
  public var reason: String

  public func dictionary() -> [String: Any] {
    ["observation_id": observationID, "reason": reason]
  }
}

public struct NormalizedCameraObservation: Codable, Sendable, Equatable {
  public var observationID: String
  public var sampleID: String
  public var artifactID: String
  public var artifactSHA256: String
  public var timestampNanoseconds: UInt64
  public var clockDomain: String
  public var calibrationID: String
  public var frameEpochID: String
  public var sessionRunID: String
  public var worldOriginRevision: UInt64
  public var blurScore: Double
  public var exposureScore: Double

  public func dictionary() -> [String: Any] {
    [
      "observation_id": observationID,
      "sample_id": sampleID,
      "artifact_id": artifactID,
      "artifact_sha256": artifactSHA256,
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain,
      "calibration_id": calibrationID,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "blur_score": blurScore,
      "exposure_score": exposureScore,
    ]
  }
}

public struct NormalizedDepthObservation: Codable, Sendable, Equatable {
  public var observationID: String
  public var sampleID: String
  public var artifactID: String
  public var artifactSHA256: String
  public var timestampNanoseconds: UInt64
  public var clockDomain: String
  public var calibrationID: String
  public var width: Int
  public var height: Int
  public var pixelFormat: String
  public var depthBytes: Data
  public var frameEpochID: String
  public var sessionRunID: String
  public var worldOriginRevision: UInt64
  public var depthValidityPercent: Double

  public func dictionary() -> [String: Any] {
    [
      "observation_id": observationID,
      "sample_id": sampleID,
      "artifact_id": artifactID,
      "artifact_sha256": artifactSHA256,
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain,
      "calibration_id": calibrationID,
      "width": width,
      "height": height,
      "pixel_format": pixelFormat,
      "depth_bytes_sha256": ContentHasher.sha256Hex(depthBytes),
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "depth_validity_percent": depthValidityPercent,
    ]
  }
}

public struct NormalizedPoseObservation: Codable, Sendable, Equatable {
  public var observationID: String
  public var sampleID: String
  public var timestampNanoseconds: UInt64
  public var clockDomain: String
  public var translation: [Double]
  public var transform4x4: [Double]
  public var trackingState: String
  public var frameEpochID: String
  public var sessionRunID: String
  public var worldOriginRevision: UInt64

  public func dictionary() -> [String: Any] {
    [
      "observation_id": observationID,
      "sample_id": sampleID,
      "timestamp_nanoseconds": timestampNanoseconds,
      "clock_domain": clockDomain,
      "translation": translation,
      "transform_4x4": transform4x4,
      "tracking_state": trackingState,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
    ]
  }
}

public struct ObservationAssociationSet: Codable, Sendable, Equatable {
  public var associationID: String
  public var cameraObservationID: String
  public var depthObservationID: String
  public var poseObservationID: String
  public var clockCorrelationID: String
  public var frameEpochID: String
  public var sessionRunID: String

  public func dictionary() -> [String: Any] {
    [
      "association_id": associationID,
      "camera_observation_id": cameraObservationID,
      "depth_observation_id": depthObservationID,
      "pose_observation_id": poseObservationID,
      "clock_correlation_id": clockCorrelationID,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
    ]
  }
}

public struct ObservationNormalizationResult: Codable, Sendable, Equatable {
  public var cameras: [NormalizedCameraObservation]
  public var depths: [NormalizedDepthObservation]
  public var poses: [NormalizedPoseObservation]
  public var associations: [ObservationAssociationSet]
  public var rejections: [ObservationRejectionRecord]

  public func dictionary() -> [String: Any] {
    [
      "cameras": cameras.map { $0.dictionary() },
      "depths": depths.map { $0.dictionary() },
      "poses": poses.map { $0.dictionary() },
      "associations": associations.map { $0.dictionary() },
      "rejections": rejections.map { $0.dictionary() },
      "normalized_observation_count": cameras.count + depths.count + poses.count,
    ]
  }
}

// MARK: - Frame / keyframe selection

public enum FrameRejectionReason: String, Codable, Sendable, Equatable {
  case blurTooHigh = "BLUR_TOO_HIGH"
  case exposurePoor = "EXPOSURE_POOR"
  case trackingLost = "TRACKING_LOST"
  case depthValidityLow = "DEPTH_VALIDITY_LOW"
  case duplicateFrame = "DUPLICATE_FRAME"
  case insufficientBaseline = "INSUFFICIENT_BASELINE"
  case epochMismatch = "EPOCH_MISMATCH"
  case policyRejected = "POLICY_REJECTED"
}

public struct FrameSelectionMetric: Codable, Sendable, Equatable {
  public var name: String
  public var value: Double

  public func dictionary() -> [String: Any] {
    ["name": name, "value": value]
  }
}

public struct FrameSelectionPolicy: Codable, Sendable, Equatable {
  public var policyID: String
  public var policyVersion: String
  public var minBlurScore: Double
  public var minExposureScore: Double
  public var minDepthValidityPercent: Double
  public var characterizationStatus: String
  public var systemTolerance: String

  public static let fixture = FrameSelectionPolicy(
    policyID: "FRAME-SEL-POL-FIXTURE-000001",
    policyVersion: "1.0.0-phase4a-fixture",
    minBlurScore: 0.5,
    minExposureScore: 0.5,
    minDepthValidityPercent: 50.0,
    characterizationStatus: "DETERMINISTIC_TEST_FIXTURE",
    systemTolerance: "NO_SYSTEM_TOLERANCE_ASSIGNED"
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "policy_version": policyVersion,
      "min_blur_score": minBlurScore,
      "min_exposure_score": minExposureScore,
      "min_depth_validity_percent": minDepthValidityPercent,
      "characterization_status": characterizationStatus,
      "system_tolerance": systemTolerance,
      "note": "Fixture keyframe thresholds are not physically optimized",
    ]
  }
}

public struct ReconstructionFrameCandidate: Codable, Sendable, Equatable {
  public var candidateID: String
  public var associationID: String
  public var cameraObservationID: String
  public var depthObservationID: String
  public var poseObservationID: String
  public var metrics: [FrameSelectionMetric]

  public func dictionary() -> [String: Any] {
    [
      "candidate_id": candidateID,
      "association_id": associationID,
      "camera_observation_id": cameraObservationID,
      "depth_observation_id": depthObservationID,
      "pose_observation_id": poseObservationID,
      "metrics": metrics.map { $0.dictionary() },
    ]
  }
}

public struct FrameSelectionDecision: Codable, Sendable, Equatable {
  public var candidateID: String
  public var selected: Bool
  public var reasonCodes: [String]
  public var evidenceIDs: [String]
  public var policyID: String
  public var policyVersion: String
  public var metrics: [FrameSelectionMetric]
  public var derivationID: String

  public func dictionary() -> [String: Any] {
    [
      "candidate_id": candidateID,
      "selected": selected,
      "reason_codes": reasonCodes,
      "evidence_ids": evidenceIDs.sorted(),
      "policy_id": policyID,
      "policy_version": policyVersion,
      "metrics": metrics.map { $0.dictionary() },
      "derivation_id": derivationID,
    ]
  }
}

public struct SelectedFrameSet: Codable, Sendable, Equatable {
  public var selectedCandidateIDs: [String]
  public var decisions: [FrameSelectionDecision]

  public func dictionary() -> [String: Any] {
    [
      "selected_candidate_ids": selectedCandidateIDs.sorted(),
      "decisions": decisions.map { $0.dictionary() },
      "selected_keyframe_count": selectedCandidateIDs.count,
      "rejected_frame_count": decisions.filter { !$0.selected }.count,
    ]
  }
}

public struct KeyframeSelector: Sendable {
  public var policy: FrameSelectionPolicy

  public init(policy: FrameSelectionPolicy = .fixture) {
    self.policy = policy
  }

  public func select(
    candidates: [ReconstructionFrameCandidate],
    cameras: [NormalizedCameraObservation],
    depths: [NormalizedDepthObservation],
    poses: [NormalizedPoseObservation]
  ) throws -> SelectedFrameSet {
    let camByID = Dictionary(uniqueKeysWithValues: cameras.map { ($0.observationID, $0) })
    let depthByID = Dictionary(uniqueKeysWithValues: depths.map { ($0.observationID, $0) })
    let poseByID = Dictionary(uniqueKeysWithValues: poses.map { ($0.observationID, $0) })
    var decisions: [FrameSelectionDecision] = []
    var selected: [String] = []
    var seenCameraArtifacts = Set<String>()

    for c in candidates.sorted(by: { $0.candidateID < $1.candidateID }) {
      guard let cam = camByID[c.cameraObservationID],
            let depth = depthByID[c.depthObservationID],
            let pose = poseByID[c.poseObservationID]
      else {
        throw ReconstructionError.frameSelectionFailed("missing_observation_for_\(c.candidateID)")
      }

      var reasons: [String] = []
      if cam.blurScore < policy.minBlurScore { reasons.append(FrameRejectionReason.blurTooHigh.rawValue) }
      if cam.exposureScore < policy.minExposureScore { reasons.append(FrameRejectionReason.exposurePoor.rawValue) }
      if depth.depthValidityPercent < policy.minDepthValidityPercent {
        reasons.append(FrameRejectionReason.depthValidityLow.rawValue)
      }
      if pose.trackingState != "NORMAL" { reasons.append(FrameRejectionReason.trackingLost.rawValue) }
      if !seenCameraArtifacts.insert(cam.artifactSHA256).inserted {
        reasons.append(FrameRejectionReason.duplicateFrame.rawValue)
      }
      if cam.frameEpochID != depth.frameEpochID || cam.frameEpochID != pose.frameEpochID {
        reasons.append(FrameRejectionReason.epochMismatch.rawValue)
      }

      let ok = reasons.isEmpty
      if ok { selected.append(c.candidateID) }
      decisions.append(
        FrameSelectionDecision(
          candidateID: c.candidateID,
          selected: ok,
          reasonCodes: ok ? ["SELECTED"] : reasons,
          evidenceIDs: [cam.sampleID, depth.sampleID, pose.sampleID],
          policyID: policy.policyID,
          policyVersion: policy.policyVersion,
          metrics: c.metrics,
          derivationID: "DER-FRAME-\(c.candidateID)"
        )
      )
    }
    return SelectedFrameSet(selectedCandidateIDs: selected, decisions: decisions)
  }
}
