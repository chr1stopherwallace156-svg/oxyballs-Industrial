import Foundation

public struct SurfaceTopologyValidator: Sendable {
  public init() {}

  public func validate(vertices: [SurfaceVertex], triangles: [SurfaceTriangle]) -> TopologyValidationRecord {
    let vertexSet = Set(vertices.map(\.vertexID))
    var edgeCount: [String: Int] = [:]
    var faceKeys: [String: Int] = [:]
    var adjacency: [String: Set<String>] = [:]

    func edgeKey(_ a: String, _ b: String) -> String {
      a < b ? "\(a)|\(b)" : "\(b)|\(a)"
    }
    func faceKey(_ ids: [String]) -> String {
      ids.sorted().joined(separator: "|")
    }

    var degenerate = 0
    for t in triangles {
      guard t.vertexIDs.count == 3 else { degenerate += 1; continue }
      let a = t.vertexIDs[0], b = t.vertexIDs[1], c = t.vertexIDs[2]
      if Set([a, b, c]).count < 3 { degenerate += 1; continue }
      if !vertexSet.contains(a) || !vertexSet.contains(b) || !vertexSet.contains(c) {
        degenerate += 1
        continue
      }
      let fk = faceKey(t.vertexIDs)
      faceKeys[fk, default: 0] += 1
      for (u, v) in [(a, b), (b, c), (c, a)] {
        edgeCount[edgeKey(u, v), default: 0] += 1
        adjacency[u, default: []].insert(v)
        adjacency[v, default: []].insert(u)
      }
    }

    let duplicateFaces = faceKeys.values.filter { $0 > 1 }.count
    let nonManifold = edgeCount.values.filter { $0 > 2 }.count
    let boundaryEdges = edgeCount.values.filter { $0 == 1 }.count

    // Connected components over triangle vertex graph
    var visited: Set<String> = []
    var components = 0
    let usedVertices = Set(triangles.flatMap(\.vertexIDs))
    for v in usedVertices.sorted() {
      if visited.contains(v) { continue }
      components += 1
      var stack = [v]
      visited.insert(v)
      while let cur = stack.popLast() {
        for n in adjacency[cur] ?? [] where usedVertices.contains(n) && !visited.contains(n) {
          visited.insert(n)
          stack.append(n)
        }
      }
    }
    if components == 0 && !triangles.isEmpty { components = 1 }
    if triangles.isEmpty { components = 0 }

    if duplicateFaces > 0 {
      return TopologyValidationRecord(
        outcome: .invalidDuplicateFaces,
        componentCount: max(components, 1),
        boundaryEdgeCount: boundaryEdges,
        nonManifoldEdgeCount: nonManifold,
        duplicateFaceCount: duplicateFaces,
        detail: "duplicate_faces"
      )
    }
    if nonManifold > 0 {
      return TopologyValidationRecord(
        outcome: .invalidNonManifold,
        componentCount: max(components, 1),
        boundaryEdgeCount: boundaryEdges,
        nonManifoldEdgeCount: nonManifold,
        duplicateFaceCount: 0,
        detail: "non_manifold_edges"
      )
    }
    if degenerate > 0 {
      return TopologyValidationRecord(
        outcome: .invalidDegenerate,
        componentCount: max(components, 1),
        boundaryEdgeCount: boundaryEdges,
        nonManifoldEdgeCount: 0,
        duplicateFaceCount: 0,
        detail: "degenerate_faces"
      )
    }
    if boundaryEdges > 0 {
      return TopologyValidationRecord(
        outcome: .validWithHoles,
        componentCount: max(components, 1),
        boundaryEdgeCount: boundaryEdges,
        nonManifoldEdgeCount: 0,
        duplicateFaceCount: 0,
        detail: "open_boundaries_present"
      )
    }
    return TopologyValidationRecord(
      outcome: .validManifoldOpen,
      componentCount: max(components, 1),
      boundaryEdgeCount: 0,
      nonManifoldEdgeCount: 0,
      duplicateFaceCount: 0,
      detail: "closed_or_empty"
    )
  }

  public struct AdjacencyExport: Sendable {
    public var adjacency: [[String: Any]]
    public var edgeAdjacency: [[String: Any]]
    public var components: [[String: Any]]
  }

  public func adjacencyAndComponents(
    vertices: [SurfaceVertex],
    triangles: [SurfaceTriangle]
  ) -> AdjacencyExport {
    let vertexSet = Set(vertices.map(\.vertexID))
    var edgeCount: [String: Int] = [:]
    var adjacency: [String: Set<String>] = [:]
    func edgeKey(_ a: String, _ b: String) -> String {
      a < b ? "\(a)|\(b)" : "\(b)|\(a)"
    }
    for t in triangles {
      guard t.vertexIDs.count == 3 else { continue }
      let a = t.vertexIDs[0], b = t.vertexIDs[1], c = t.vertexIDs[2]
      guard vertexSet.contains(a), vertexSet.contains(b), vertexSet.contains(c) else { continue }
      for (u, v) in [(a, b), (b, c), (c, a)] {
        edgeCount[edgeKey(u, v), default: 0] += 1
        adjacency[u, default: []].insert(v)
        adjacency[v, default: []].insert(u)
      }
    }
    let adjRows: [[String: Any]] = adjacency.keys.sorted().map { v in
      [
        "vertex_id": v,
        "neighbor_vertex_ids": (adjacency[v] ?? []).sorted(),
      ]
    }
    let edgeRows: [[String: Any]] = edgeCount.keys.sorted().map { k in
      let parts = k.split(separator: "|").map(String.init)
      return [
        "edge_id": k,
        "vertex_a": parts[0],
        "vertex_b": parts[1],
        "incident_triangle_count": edgeCount[k] ?? 0,
      ]
    }

    var visited: Set<String> = []
    var components: [[String: Any]] = []
    let usedVertices = Set(triangles.flatMap(\.vertexIDs))
    for v in usedVertices.sorted() {
      if visited.contains(v) { continue }
      var stack = [v]
      var members: [String] = []
      visited.insert(v)
      while let cur = stack.popLast() {
        members.append(cur)
        for n in adjacency[cur] ?? [] where usedVertices.contains(n) && !visited.contains(n) {
          visited.insert(n)
          stack.append(n)
        }
      }
      members.sort()
      components.append([
        "component_id": String(format: "CMP-%06d", components.count + 1),
        "vertex_ids": members,
        "vertex_count": members.count,
        "classification": "VALID_MANIFOLD_REGION",
      ])
    }
    return AdjacencyExport(adjacency: adjRows, edgeAdjacency: edgeRows, components: components)
  }
}

public struct SurfaceBoundaryClassifier: Sendable {
  public var policy: SurfaceMeshingPolicy

  public init(policy: SurfaceMeshingPolicy = .fixture) {
    self.policy = policy
  }

  public func classify(
    vertices: [SurfaceVertex],
    triangles: [SurfaceTriangle],
    gaps: [SpatialGap]
  ) -> (boundaries: [BoundaryLoopRecord], holes: [HoleRecord]) {
    let byID = Dictionary(uniqueKeysWithValues: vertices.map { ($0.vertexID, $0) })
    var edgeCount: [String: (String, String, Int)] = [:]
    func key(_ a: String, _ b: String) -> String { a < b ? "\(a)|\(b)" : "\(b)|\(a)" }
    for t in triangles {
      guard t.vertexIDs.count == 3 else { continue }
      let ids = t.vertexIDs
      for (u, v) in [(ids[0], ids[1]), (ids[1], ids[2]), (ids[2], ids[0])] {
        let k = key(u, v)
        if let e = edgeCount[k] {
          edgeCount[k] = (e.0, e.1, e.2 + 1)
        } else {
          edgeCount[k] = (u, v, 1)
        }
      }
    }
    let boundaryEdges = edgeCount.values.filter { $0.2 == 1 }
    // Build adjacency for boundary graph
    var adj: [String: [String]] = [:]
    for e in boundaryEdges {
      adj[e.0, default: []].append(e.1)
      adj[e.1, default: []].append(e.0)
    }
    for k in adj.keys { adj[k]?.sort() }

    var visitedEdge: Set<String> = []
    var loops: [[String]] = []
    for e in boundaryEdges.sorted(by: { key($0.0, $0.1) < key($1.0, $1.1) }) {
      let ek = key(e.0, e.1)
      if visitedEdge.contains(ek) { continue }
      var loop: [String] = [e.0]
      var prev = e.0
      var cur = e.1
      visitedEdge.insert(ek)
      var guardCount = 0
      while cur != e.0 && guardCount < boundaryEdges.count + 2 {
        loop.append(cur)
        let nexts = (adj[cur] ?? []).filter { $0 != prev }
        let next = nexts.sorted().first ?? prev
        visitedEdge.insert(key(cur, next))
        prev = cur
        cur = next
        guardCount += 1
      }
      if loop.count >= 3 {
        loops.append(loop)
      }
    }

    // Largest loop = outer; others = holes / intentional
    let ranked = loops.sorted { $0.count > $1.count }
    var boundaries: [BoundaryLoopRecord] = []
    var holes: [HoleRecord] = []

    for (idx, loop) in ranked.enumerated() {
      let bid = String(format: "BND-%06d", idx + 1)
      let centroid = loopCentroid(loop, byID: byID)
      let inIntentional = aabbContains(
        policy.intentionalHoleAABBMin, policy.intentionalHoleAABBMax, centroid
      )
      let inGap = gaps.contains { aabbContains($0.boundsMin, $0.boundsMax, centroid) }

      let classification: BoundaryClassification
      if idx == 0 {
        classification = .outerBoundary
      } else if inIntentional {
        classification = .intentionalOpenBoundary
      } else if inGap {
        classification = .unobservedRegion
      } else {
        classification = .holeBoundary
      }

      boundaries.append(
        BoundaryLoopRecord(
          boundaryID: bid,
          classification: classification,
          orderedVertexIDs: loop,
          edgeCount: loop.count,
          detail: classification.rawValue
        )
      )

      if classification != .outerBoundary {
        let holeClass: HoleClassification
        switch classification {
        case .intentionalOpenBoundary: holeClass = .intentionalOpenBoundary
        case .unobservedRegion: holeClass = .unobservedRegion
        case .sparseRegionBoundary: holeClass = .sparseCoverage
        default: holeClass = .gapBridgingAvoided
        }
        let aabb = loopAABB(loop, byID: byID)
        holes.append(
          HoleRecord(
            holeID: String(format: "HOLE-%06d", holes.count + 1),
            classification: holeClass,
            boundaryID: bid,
            aabbMin: aabb.0,
            aabbMax: aabb.1,
            automaticFillApplied: false,
            detail: "no_automatic_fill"
          )
        )
      }
    }

    // Always record intentional missing region even if no closed loop formed
    if !holes.contains(where: { $0.classification == .intentionalOpenBoundary }) {
      holes.append(
        HoleRecord(
          holeID: String(format: "HOLE-%06d", holes.count + 1),
          classification: .intentionalOpenBoundary,
          boundaryID: nil,
          aabbMin: policy.intentionalHoleAABBMin,
          aabbMax: policy.intentionalHoleAABBMax,
          automaticFillApplied: false,
          detail: "intentional_fixture_unobserved_region"
        )
      )
    }

    // Ensure at least one open boundary record if mesh has boundary edges
    if boundaries.isEmpty && !boundaryEdges.isEmpty {
      boundaries.append(
        BoundaryLoopRecord(
          boundaryID: "BND-000001",
          classification: .outerBoundary,
          orderedVertexIDs: boundaryEdges.flatMap { [$0.0, $0.1] }.sorted(),
          edgeCount: boundaryEdges.count,
          detail: "flat_boundary_edges"
        )
      )
    }

    boundaries.sort { $0.boundaryID < $1.boundaryID }
    holes.sort { $0.holeID < $1.holeID }
    return (boundaries, holes)
  }

  private func loopCentroid(_ loop: [String], byID: [String: SurfaceVertex]) -> [Double] {
    var sx = 0.0, sy = 0.0, sz = 0.0, n = 0.0
    for id in loop {
      guard let v = byID[id] else { continue }
      sx += v.x; sy += v.y; sz += v.z; n += 1
    }
    guard n > 0 else { return [0, 0, 0] }
    return [sx / n, sy / n, sz / n]
  }

  private func loopAABB(_ loop: [String], byID: [String: SurfaceVertex]) -> ([Double], [Double]) {
    var minV = [Double.greatestFiniteMagnitude, Double.greatestFiniteMagnitude, Double.greatestFiniteMagnitude]
    var maxV = [-Double.greatestFiniteMagnitude, -Double.greatestFiniteMagnitude, -Double.greatestFiniteMagnitude]
    for id in loop {
      guard let v = byID[id] else { continue }
      minV[0] = min(minV[0], v.x); minV[1] = min(minV[1], v.y); minV[2] = min(minV[2], v.z)
      maxV[0] = max(maxV[0], v.x); maxV[1] = max(maxV[1], v.y); maxV[2] = max(maxV[2], v.z)
    }
    return (minV, maxV)
  }

  private func aabbContains(_ mn: [Double], _ mx: [Double], _ p: [Double]) -> Bool {
    guard mn.count >= 2, mx.count >= 2, p.count >= 2 else { return false }
    let zOK = (mn.count < 3 || mx.count < 3 || p.count < 3)
      || (p[2] >= mn[2] && p[2] <= mx[2])
    return p[0] >= mn[0] && p[0] <= mx[0] && p[1] >= mn[1] && p[1] <= mx[1] && zOK
  }
}

public struct SurfaceConfidenceAssessor: Sendable {
  public init() {}

  public func assess(
    vertices: [SurfaceVertex],
    triangles: [SurfaceTriangle],
    holes: [HoleRecord]
  ) -> [SurfaceConfidenceRecord] {
    var records: [SurfaceConfidenceRecord] = []
    for v in vertices.sorted(by: { $0.vertexID < $1.vertexID }) {
      let cls: SurfaceConfidenceClass
      if v.confidence >= 0.75 { cls = .high }
      else if v.confidence >= 0.4 { cls = .medium }
      else { cls = .low }
      records.append(
        SurfaceConfidenceRecord(
          subjectID: v.vertexID,
          kind: "VERTEX",
          classification: cls,
          score: v.confidence,
          detail: "from_fused_confidence_mean"
        )
      )
    }
    for t in triangles.sorted(by: { $0.triangleID < $1.triangleID }) {
      let vids = Set(t.vertexIDs)
      let confs = vertices.filter { vids.contains($0.vertexID) }.map(\.confidence)
      let mean = confs.isEmpty ? 0 : confs.reduce(0, +) / Double(confs.count)
      let cls: SurfaceConfidenceClass = mean >= 0.75 ? .high : (mean >= 0.4 ? .medium : .low)
      records.append(
        SurfaceConfidenceRecord(
          subjectID: t.triangleID,
          kind: "TRIANGLE",
          classification: cls,
          score: mean,
          detail: "mean_vertex_confidence"
        )
      )
    }
    for h in holes where h.automaticFillApplied {
      records.append(
        SurfaceConfidenceRecord(
          subjectID: h.holeID,
          kind: "HOLE_FILL",
          classification: .interpolated,
          score: 0,
          detail: "INTERPOLATED_FIXTURE_SURFACE_ESTIMATE"
        )
      )
    }
    return records.sorted {
      if $0.kind != $1.kind { return $0.kind < $1.kind }
      return $0.subjectID < $1.subjectID
    }
  }
}
