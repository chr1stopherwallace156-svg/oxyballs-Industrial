import Foundation

public struct Phase4DPipelineResult: Sendable {
  public var surfaceOutputID: String
  public var eligibility: SurfaceEligibilityResult
  public var reconstruction: SurfaceReconstructionResult
  public var topology: TopologyValidationRecord
  public var boundaries: [BoundaryLoopRecord]
  public var holes: [HoleRecord]
  public var confidence: [SurfaceConfidenceRecord]
  public var lods: [SurfaceLODMesh]
  public var quality: SurfaceQualitySummary
  public var handoff: Phase4EHandoffContract
  public var lineage: SurfaceLineageManifest
  public var jobState: SurfaceReconstructionJobState
  public var cancellation: SurfaceCancellationResult?
  public var outputRoot: URL
  public var surfaceMeshCandidateSHA256: String
  public var lod0PLYSHA256: String
  public var lod1PLYSHA256: String
  public var lod2PLYSHA256: String
  public var glbSHA256: String?
  public var lineageManifestSHA256: String
  public var outputInventorySHA256: String
  public var outputClosureSHA256: String
  public var phase4COutputsUnchanged: Bool
  public var phase4EReadiness: Phase4EReadinessOutcome
  public var sealedOutputCreated: Bool
}

public struct Phase4DPipeline: Sendable {
  public var configuration: Phase4DConfiguration
  public var cancelDuring: SurfaceReconstructionJobState?

  public init(
    configuration: Phase4DConfiguration = .fixture,
    cancelDuring: SurfaceReconstructionJobState? = nil
  ) {
    self.configuration = configuration
    self.cancelDuring = cancelDuring
  }

  public func run(
    phase4COutputRoot: URL,
    outputRoot: URL,
    sourcePackageRoot: URL?,
    sourcePackageClosureSHA256: String,
    phase4COutputClosureSHA256: String?
  ) throws -> Phase4DPipelineResult {
    let job = SurfaceReconstructionJob()
    job.transition(.created, message: "job_created")

    let phase4CHashesBefore = try hashAllFiles(under: phase4COutputRoot)

    job.transition(.validating, message: "validating_input")
    if cancelDuring == .validating {
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .validating)
    }

    let bundle = try Phase4CSurfaceInputLoader.load(phase4COutputRoot: phase4COutputRoot)
    // Prefer live recomputed inventory closure over the provisional value embedded in
    // Phase 4C output_closure.json (which is written before late handoff artifacts).
    let recomputedPhase4CClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(
      entries: try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: phase4COutputRoot)
    )
    var bundleWithClosure = bundle
    bundleWithClosure.phase4COutputClosureSHA256 = recomputedPhase4CClosure

    let inventory = SurfaceInputInventory(
      sourcePackageID: sourcePackageRoot.map { _ in
        // Prefer package id from closure caller; fall back to surface fixture id when unknown
        Phase4DFixtureIDs.inputPackageID
      } ?? Phase4DFixtureIDs.inputPackageID,
      sourcePackageClosureSHA256: sourcePackageClosureSHA256,
      phase4COutputID: bundleWithClosure.phase4CReconstructionOutputID,
      phase4COutputClosureSHA256: recomputedPhase4CClosure,
      fusedPointCloudID: bundleWithClosure.fusedCloud.cloudID,
      fusedPointCount: bundleWithClosure.fusedCloud.points.count,
      validNormalCount: bundleWithClosure.normals.filter { $0.validity == .valid || $0.validity == .highCurvatureEdge }.count,
      quarantinedRegionCount: bundleWithClosure.quarantinedRegions.count,
      gapCount: bundleWithClosure.gaps.count,
      conflictCount: bundleWithClosure.conflictIDs.count,
      phase4DReadiness: bundleWithClosure.phase4DReadiness,
      units: bundleWithClosure.coordinate.units,
      handedness: bundleWithClosure.coordinate.handedness
    )

    // Prefer reading source package id from phase4C lineage if present
    let refinedInventory = refineInventory(inventory, phase4COutputRoot: phase4COutputRoot)

    let eligibility = SurfaceInputValidator(policy: configuration.eligibility).validate(
      inventory: refinedInventory,
      bundle: bundleWithClosure,
      expectedPhase4CClosure: phase4COutputClosureSHA256 ?? recomputedPhase4CClosure
    )
    guard eligibility.isEligible else {
      job.transition(.failed, message: eligibility.outcome.rawValue)
      throw SurfaceFailure.ineligible(eligibility.outcome.rawValue)
    }

    var cfg = configuration.configuration
    cfg.digest = cfg.computeDigest()

    job.transition(.generatingVertices, message: "generating_vertices")
    if cancelDuring == .generatingVertices {
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .generatingVertices)
    }

    job.transition(.generatingTriangles, message: "generating_triangles")
    if cancelDuring == .generatingTriangles {
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .generatingTriangles)
    }

    let backend = DeterministicFixtureSurfaceBackend(policy: configuration.meshing)
    let reconstruction = try backend.reconstruct(
      fusedCloud: bundleWithClosure.fusedCloud,
      normals: bundleWithClosure.normals,
      gaps: bundleWithClosure.gaps,
      quarantinedRegions: bundleWithClosure.quarantinedRegions,
      configurationDigest: cfg.digest
    )

    job.transition(.validatingTopology, message: "validating_topology")
    if cancelDuring == .validatingTopology {
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .validatingTopology)
    }
    let topology = SurfaceTopologyValidator().validate(
      vertices: reconstruction.vertices,
      triangles: reconstruction.triangles
    )

    job.transition(.classifyingBoundaries, message: "classifying_boundaries")
    if cancelDuring == .classifyingBoundaries {
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .classifyingBoundaries)
    }
    let classified = SurfaceBoundaryClassifier(policy: configuration.meshing).classify(
      vertices: reconstruction.vertices,
      triangles: reconstruction.triangles,
      gaps: bundleWithClosure.gaps
    )
    let confidence = SurfaceConfidenceAssessor().assess(
      vertices: reconstruction.vertices,
      triangles: reconstruction.triangles,
      holes: classified.holes
    )

    job.transition(.generatingLODs, message: "generating_lods")
    if cancelDuring == .generatingLODs {
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .generatingLODs)
    }
    let lods = SurfaceLODGenerator(policy: configuration.meshing).generate(
      vertices: reconstruction.vertices,
      triangles: reconstruction.triangles
    )

    job.transition(.generatingVisualDerivatives, message: "generating_visual_derivatives")
    if cancelDuring == .generatingVisualDerivatives {
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .generatingVisualDerivatives)
    }

    job.transition(.finalizing, message: "finalizing")
    if cancelDuring == .finalizing {
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .finalizing)
    }

    try FileManager.default.createDirectory(at: outputRoot, withIntermediateDirectories: true)
    if configuration.resource.cleanupTemporaryOutputs {
      try? FileManager.default.removeItem(at: outputRoot.appendingPathComponent(".tmp-partial"))
    }

    let surfaceOutputID = Phase4DFixtureIDs.surfaceOutputID
    let meshCandidate = SurfaceMeshCandidate(
      meshID: "MESH-SURFACE-FIXTURE-000001",
      surfaceOutputID: surfaceOutputID,
      authority: "RECONSTRUCTION_ESTIMATE",
      vertices: reconstruction.vertices,
      triangles: reconstruction.triangles,
      classification: "SYNTHETIC_FIXTURE_SURFACE_CANDIDATE"
    )

    let colors = SurfaceMeshExportWriter.vertexColors(vertices: reconstruction.vertices)
    let lod0 = lods.first { $0.lodLevel == 0 }!
    let lod1 = lods.first { $0.lodLevel == 1 }!
    let lod2 = lods.first { $0.lodLevel == 2 }!
    let ply0 = SurfaceMeshExportWriter.writePLY(mesh: lod0, colors: colors)
    let ply1 = SurfaceMeshExportWriter.writePLY(mesh: lod1, colors: nil)
    let ply2 = SurfaceMeshExportWriter.writePLY(mesh: lod2, colors: nil)
    let obj = SurfaceMeshExportWriter.writeOBJ(mesh: lod0, mtlName: "surface_mesh.mtl")
    let mtl = SurfaceMeshExportWriter.writeMTL()
    var glbData: Data? = nil
    var glbSHA: String? = nil
    var glbExportStatus = "GLB_EXPORT_OK"
    do {
      let data = try DeterministicGLBWriter.write(mesh: lod0)
      glbData = data
      glbSHA = ContentHasher.sha256Hex(data)
    } catch {
      glbExportStatus = "GLB_EXPORT_SKIPPED:\(error)"
      glbData = nil
      glbSHA = nil
    }

    let meanConf: Double = {
      guard !reconstruction.vertices.isEmpty else { return 0 }
      return reconstruction.vertices.map(\.confidence).reduce(0, +) / Double(reconstruction.vertices.count)
    }()

    let quality = SurfaceQualitySummary(
      summaryID: "QS-SURFACE-FIXTURE-000001",
      vertexCount: reconstruction.vertices.count,
      validTriangleCount: reconstruction.triangles.count,
      rejectedTriangleCount: reconstruction.rejected.count,
      boundaryCount: classified.boundaries.count,
      holeCount: classified.holes.count,
      componentCount: topology.componentCount,
      lodCount: 3,
      topologyOutcome: topology.outcome,
      meanVertexConfidence: meanConf,
      automaticHoleFillApplied: classified.holes.contains(where: \.automaticFillApplied),
      characterizationStatus: "DETERMINISTIC_TEST_FIXTURE"
    )

    let readiness: Phase4EReadinessOutcome
    switch topology.outcome {
    case .invalidNonManifold, .invalidDuplicateFaces, .invalidDegenerate:
      readiness = .notReadyInvalidTopology
    case .validWithHoles:
      readiness = classified.holes.isEmpty
        ? .readyForFixtureScaleAndDatum
        : .readyWithUnresolvedBoundaries
    case .validManifoldOpen:
      readiness = reconstruction.triangles.count >= 1
        ? .readyForFixtureScaleAndDatum
        : .notReadyInsufficientMesh
    case .manualReviewRequired:
      readiness = .manualReviewRequired
    }

    func writeObj(_ name: String, _ dict: [String: Any]) throws -> (String, Int, String) {
      let data = try CanonicalJSON.data(dict)
      try data.write(to: outputRoot.appendingPathComponent(name), options: .atomic)
      return (name, data.count, ContentHasher.sha256Hex(data))
    }
    func writeText(_ name: String, _ text: String) throws -> (String, Int, String) {
      let data = Data(text.utf8)
      try data.write(to: outputRoot.appendingPathComponent(name), options: .atomic)
      return (name, data.count, ContentHasher.sha256Hex(data))
    }
    func writeBin(_ name: String, _ data: Data) throws -> (String, Int, String) {
      try data.write(to: outputRoot.appendingPathComponent(name), options: .atomic)
      return (name, data.count, ContentHasher.sha256Hex(data))
    }

    var hashes: [String: String] = [:]
    var items: [ReconstructionOutputInventoryItem] = []
    func track(_ n: String, _ b: Int, _ h: String, _ role: String, media: String = "application/json") {
      hashes[n] = h
      items.append(
        ReconstructionOutputInventoryItem(
          relativePath: n, sha256: h, byteCount: b, mediaType: media, role: role
        )
      )
    }

    do {
      let (n, b, h) = try writeObj("surface_input_inventory.json", refinedInventory.dictionary())
      track(n, b, h, "surface_input_inventory")
    }
    do {
      let (n, b, h) = try writeObj("surface_eligibility.json", eligibility.dictionary())
      track(n, b, h, "surface_eligibility")
    }
    do {
      let policyDict: [String: Any] = [
        "eligibility_policy": configuration.eligibility.dictionary(),
        "meshing_policy": configuration.meshing.dictionary(),
        "resource_policy": configuration.resource.dictionary(),
        "configuration": cfg.dictionary(),
        "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
        "schema_id": "SurfaceReconstructionPolicy",
        "schema_version": Phase4DFixtureIDs.schemaVersion,
      ]
      let (n, b, h) = try writeObj("surface_policy.json", policyDict)
      track(n, b, h, "surface_policy")
    }
    do {
      let (n, b, h) = try writeObj("numeric_policy.json", configuration.numeric.dictionary())
      track(n, b, h, "numeric_policy")
    }
    do {
      let (n, b, h) = try writeObj(
        "canonical_vertices.json",
        ["vertices": reconstruction.vertices.sorted { $0.vertexID < $1.vertexID }.map { $0.dictionary() }]
      )
      track(n, b, h, "canonical_vertices")
    }
    do {
      let (n, b, h) = try writeObj(
        "canonical_triangles.json",
        ["triangles": reconstruction.triangles.sorted { $0.triangleID < $1.triangleID }.map { $0.dictionary() }]
      )
      track(n, b, h, "canonical_triangles")
    }
    do {
      let (n, b, h) = try writeObj(
        "rejected_triangles.json",
        ["rejected_triangles": reconstruction.rejected.sorted { $0.recordID < $1.recordID }.map { $0.dictionary() }]
      )
      track(n, b, h, "rejected_triangles")
    }

    let meshSHA: String
    do {
      let (n, b, h) = try writeObj("surface_mesh_candidate.json", meshCandidate.dictionary())
      meshSHA = h
      track(n, b, h, "surface_mesh_candidate")
    }
    let topologyExtras = SurfaceTopologyValidator().adjacencyAndComponents(
      vertices: reconstruction.vertices,
      triangles: reconstruction.triangles
    )
    do {
      let (n, b, h) = try writeObj("topology.json", topology.dictionary())
      track(n, b, h, "topology")
    }
    do {
      let (n, b, h) = try writeObj("adjacency.json", [
        "vertex_adjacency": topologyExtras.adjacency,
        "edge_adjacency": topologyExtras.edgeAdjacency,
        "schema_id": "SurfaceAdjacency",
        "schema_version": Phase4DFixtureIDs.schemaVersion,
      ])
      track(n, b, h, "adjacency")
    }
    do {
      let (n, b, h) = try writeObj("connected_components.json", [
        "components": topologyExtras.components,
        "component_count": topology.componentCount,
        "schema_id": "ConnectedSurfaceComponents",
        "schema_version": Phase4DFixtureIDs.schemaVersion,
      ])
      track(n, b, h, "connected_components")
    }
    do {
      let (n, b, h) = try writeObj(
        "boundaries.json",
        ["boundaries": classified.boundaries.map { $0.dictionary() }]
      )
      track(n, b, h, "boundaries")
    }
    do {
      let (n, b, h) = try writeObj(
        "holes.json",
        ["holes": classified.holes.map { $0.dictionary() }]
      )
      track(n, b, h, "holes")
    }
    do {
      let (n, b, h) = try writeObj("interpolated_regions.json", [
        "regions": [] as [[String: Any]],
        "interpolated_triangle_count": 0,
        "automatic_hole_fill_applied": false,
        "authority": "INTERPOLATED_FIXTURE_SURFACE_ESTIMATE",
        "note": "Phase 4D fixture path does not automatically fill holes",
        "schema_id": "InterpolatedSurfaceRegions",
        "schema_version": Phase4DFixtureIDs.schemaVersion,
      ])
      track(n, b, h, "interpolated_regions")
    }
    do {
      let (n, b, h) = try writeObj(
        "surface_confidence.json",
        ["records": confidence.map { $0.dictionary() }]
      )
      track(n, b, h, "surface_confidence")
    }
    do {
      let (n, b, h) = try writeObj(
        "lod_records.json",
        ["lods": lods.map { $0.dictionary() }]
      )
      track(n, b, h, "lod_records")
    }

    let ply0SHA: String
    let ply1SHA: String
    let ply2SHA: String
    do {
      let (n, b, h) = try writeText("surface_mesh_lod0.ply", ply0)
      ply0SHA = h; track(n, b, h, "lod0_ply", media: "application/x-ply")
    }
    do {
      let (n, b, h) = try writeText("surface_mesh_lod1.ply", ply1)
      ply1SHA = h; track(n, b, h, "lod1_ply", media: "application/x-ply")
    }
    do {
      let (n, b, h) = try writeText("surface_mesh_lod2.ply", ply2)
      ply2SHA = h; track(n, b, h, "lod2_ply", media: "application/x-ply")
    }
    do {
      let (n, b, h) = try writeText("surface_mesh.obj", obj)
      track(n, b, h, "surface_mesh_obj", media: "text/plain")
    }
    do {
      let (n, b, h) = try writeText("surface_mesh.mtl", mtl)
      track(n, b, h, "surface_mesh_mtl", media: "text/plain")
    }
    do {
      if let glbData {
        let (n, b, h) = try writeBin("surface_mesh.glb", glbData)
        track(n, b, h, "surface_mesh_glb", media: "model/gltf-binary")
      } else {
        let (n, b, h) = try writeObj("glb_export_status.json", [
          "status": "GLB_EXPORT_SKIPPED",
          "reason": glbExportStatus,
          "retained_derivatives": ["canonical_vertices.json", "canonical_triangles.json", "surface_mesh.obj", "surface_mesh_lod0.ply"],
          "schema_id": "GLBExportStatus",
          "schema_version": Phase4DFixtureIDs.schemaVersion,
        ])
        track(n, b, h, "glb_export_status")
      }
    }

    let visual = SurfaceMeshExportWriter.visualDerivationManifest(
      colors: colors,
      lodHashes: [
        "surface_mesh_lod0.ply": ply0SHA,
        "surface_mesh_lod1.ply": ply1SHA,
        "surface_mesh_lod2.ply": ply2SHA,
      ],
      glbSHA256: glbSHA,
      glbExportStatus: glbExportStatus
    )
    do {
      let (n, b, h) = try writeObj("visual_derivation_manifest.json", visual)
      track(n, b, h, "visual_derivation_manifest")
    }
    do {
      let (n, b, h) = try writeObj("surface_quality_summary.json", quality.dictionary())
      track(n, b, h, "surface_quality_summary")
    }

    let derivations: [SurfaceDerivationRecord] = reconstruction.vertices.map {
      SurfaceDerivationRecord(
        derivationID: "DER-\($0.vertexID)",
        kind: "SURFACE_VERTEX_FROM_FUSED_POINT",
        subjectID: $0.vertexID,
        sourceIDs: [$0.fusedPointID],
        algorithmID: backend.backendID,
        configurationDigest: cfg.digest
      )
    }
    do {
      let (n, b, h) = try writeObj(
        "derivation_records.json",
        ["records": derivations.sorted { $0.derivationID < $1.derivationID }.map { $0.dictionary() }]
      )
      track(n, b, h, "derivation_records")
    }

    let geometry = FixtureSurfaceTargetGeometry.surfaceTarget()
    do {
      let (n, b, h) = try writeObj("fixture_geometry_expected.json", geometry.dictionary())
      track(n, b, h, "expected_geometry")
    }

    let fixtureTruth: [String: Any] = [
      "schema_id": "Phase4DFixtureTruth",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
      "input_package_id": Phase4DFixtureIDs.inputPackageID,
      "fixture_geometry_id": Phase4DFixtureIDs.fixtureGeometryID,
      "surface_output_id": surfaceOutputID,
      "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
      "expected_vertex_count_min": 8,
      "expected_valid_triangle_count_min": 1,
      "expected_rejected_triangle_count_min": 2,
      "expected_boundary_count_min": 1,
      "expected_hole_count_min": 1,
      "expected_component_count": topology.componentCount,
      "expected_lod_count": 3,
      "expected_phase4e_readiness": [
        Phase4EReadinessOutcome.readyForFixtureScaleAndDatum.rawValue,
        Phase4EReadinessOutcome.readyWithUnresolvedBoundaries.rawValue,
      ],
      "observed": [
        "vertex_count": reconstruction.vertices.count,
        "valid_triangle_count": reconstruction.triangles.count,
        "rejected_triangle_count": reconstruction.rejected.count,
        "boundary_count": classified.boundaries.count,
        "hole_count": classified.holes.count,
        "component_count": topology.componentCount,
        "lod_count": 3,
        "phase4e_readiness": readiness.rawValue,
        "automatic_hole_fill_applied": false,
      ],
      "geometry_reference_authority": "TEST_FIXTURE_GROUND_TRUTH",
      "surface_authority": "RECONSTRUCTION_ESTIMATE",
      "production_mesh_claim": "FORBIDDEN",
      "engineering_metrology_claim": "FORBIDDEN",
      "complete_digital_twin_claim": "FORBIDDEN",
    ]
    do {
      let (n, b, h) = try writeObj("fixture_truth.json", fixtureTruth)
      track(n, b, h, "fixture_truth")
    }

    var lineage = SurfaceLineageManifest(
      lineageManifestID: "LINEAGE-PHASE4D-000001",
      sourcePackageID: refinedInventory.sourcePackageID,
      sourcePackageClosureSHA256: sourcePackageClosureSHA256,
      phase4COutputClosureSHA256: recomputedPhase4CClosure,
      surfacePolicyID: configuration.meshing.policyID,
      configurationDigest: cfg.digest,
      algorithmIDs: [backend.backendID, "SurfaceTopologyValidator", "SurfaceLODGenerator"],
      outputArtifactHashes: hashes,
      lineageManifestSHA256: ""
    )
    lineage.lineageManifestSHA256 = ContentHasher.sha256Hex(
      try CanonicalJSON.data({
        var d = lineage.dictionary()
        d["lineage_manifest_sha256"] = ""
        return d
      }())
    )
    let lineageSHA: String
    do {
      let (n, b, h) = try writeObj("surface_lineage_manifest.json", lineage.dictionary())
      lineageSHA = h
      track(n, b, h, "surface_lineage_manifest")
    }

    items.sort { $0.relativePath < $1.relativePath }
    func writeInventory() throws -> String {
      let sorted = items.sorted { $0.relativePath < $1.relativePath }
      let inv = ReconstructionOutputInventory(
        inventoryID: "INV-SURFACE-OUT-4D-000001",
        reconstructionOutputID: surfaceOutputID,
        items: sorted,
        inventorySHA256: ContentHasher.sha256Hex(try CanonicalJSON.data(["items": sorted.map { $0.dictionary() }]))
      )
      let data = try CanonicalJSON.data(inv.dictionary())
      try data.write(to: outputRoot.appendingPathComponent("output_inventory.json"), options: .atomic)
      return ContentHasher.sha256Hex(data)
    }
    var invSHA = try writeInventory()

    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputRoot)
    let provisionalClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)

    let handoff = Phase4EHandoffContract(
      surfaceOutputID: surfaceOutputID,
      meshArtifactID: meshCandidate.meshID,
      readiness: readiness,
      vertexCount: reconstruction.vertices.count,
      triangleCount: reconstruction.triangles.count,
      boundaryCount: classified.boundaries.count,
      holeCount: classified.holes.count,
      lodCount: 3,
      lineageManifestID: lineage.lineageManifestID,
      outputClosureSHA256: provisionalClosure,
      limitations: [
        "NO_PRODUCTION_MESH",
        "NO_ENGINEERING_METROLOGY",
        "NO_COMPLETE_DIGITAL_TWIN",
        "NO_AUTOMATIC_HOLE_FILL",
        "FIXTURE_SURFACE_NOT_VEHICLE_SURFACE",
        "SCALE_DATUM_PENDING_PHASE4E",
      ]
    )
    do {
      let (n, b, h) = try writeObj("phase4e_handoff.json", handoff.dictionary())
      track(n, b, h, "phase4e_handoff")
    }
    invSHA = try writeInventory()

    _ = try writeObj("output_closure.json", [
      "schema_id": "ReconstructionOutputClosure",
      "surface_output_id": surfaceOutputID,
      "reconstruction_output_id": surfaceOutputID,
      "output_closure_sha256": provisionalClosure,
      "source_package_id": refinedInventory.sourcePackageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "phase4c_output_closure_sha256": recomputedPhase4CClosure,
      "note": "Phase 4D derived surface outputs; Phase 4C source outputs unchanged",
    ])

    let finalEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputRoot)
    let finalClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: finalEntries)

    let phase4CHashesAfter = try hashAllFiles(under: phase4COutputRoot)
    let unchanged = phase4CHashesBefore == phase4CHashesAfter
    guard unchanged else {
      throw SurfaceFailure.deterministicReplayMismatch("phase4c_outputs_mutated")
    }

    job.transition(.complete, message: "complete")

    return Phase4DPipelineResult(
      surfaceOutputID: surfaceOutputID,
      eligibility: eligibility,
      reconstruction: reconstruction,
      topology: topology,
      boundaries: classified.boundaries,
      holes: classified.holes,
      confidence: confidence,
      lods: lods,
      quality: quality,
      handoff: handoff,
      lineage: lineage,
      jobState: job.state,
      cancellation: nil,
      outputRoot: outputRoot,
      surfaceMeshCandidateSHA256: meshSHA,
      lod0PLYSHA256: ply0SHA,
      lod1PLYSHA256: ply1SHA,
      lod2PLYSHA256: ply2SHA,
      glbSHA256: glbSHA,
      lineageManifestSHA256: lineageSHA,
      outputInventorySHA256: invSHA,
      outputClosureSHA256: finalClosure,
      phase4COutputsUnchanged: unchanged,
      phase4EReadiness: readiness,
      sealedOutputCreated: true
    )
  }

  private func cancelAndCleanup(
    job: SurfaceReconstructionJob,
    outputRoot: URL,
    during: SurfaceReconstructionJobState
  ) throws -> Never {
    job.transition(.cancelled, message: "cancelled_\(during.rawValue)")
    if configuration.resource.cleanupTemporaryOutputs {
      try? FileManager.default.removeItem(at: outputRoot)
    }
    try FileManager.default.createDirectory(at: outputRoot, withIntermediateDirectories: true)
    let contents = (try? FileManager.default.contentsOfDirectory(atPath: outputRoot.path)) ?? []
    precondition(!contents.contains("output_closure.json"))
    throw SurfaceFailure.cancelled(during.rawValue)
  }

  private func refineInventory(
    _ inventory: SurfaceInputInventory,
    phase4COutputRoot: URL
  ) -> SurfaceInputInventory {
    var inv = inventory
    let lineageURL = phase4COutputRoot.appendingPathComponent("spatial_lineage_manifest.json")
    if let data = try? Data(contentsOf: lineageURL),
       let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
    {
      if let pkg = obj["source_package_id"] as? String { inv.sourcePackageID = pkg }
      if let clo = obj["source_package_closure_sha256"] as? String, inv.sourcePackageClosureSHA256.isEmpty {
        inv.sourcePackageClosureSHA256 = clo
      }
    }
    return inv
  }

  private func hashAllFiles(under root: URL) throws -> [String: String] {
    let fm = FileManager.default
    guard let enumerator = fm.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles]) else {
      return [:]
    }
    var out: [String: String] = [:]
    for case let url as URL in enumerator {
      var isDir: ObjCBool = false
      guard fm.fileExists(atPath: url.path, isDirectory: &isDir), !isDir.boolValue else { continue }
      let rel = url.path.replacingOccurrences(of: root.path + "/", with: "")
      let data = try Data(contentsOf: url)
      out[rel] = ContentHasher.sha256Hex(data)
    }
    return out
  }
}

// MARK: - Phase 4C artifact loader

enum Phase4CSurfaceInputLoader {
  static func load(phase4COutputRoot: URL) throws -> Phase4CSurfaceHandoffBundle {
    func loadJSON(_ name: String) throws -> [String: Any] {
      let url = phase4COutputRoot.appendingPathComponent(name)
      guard FileManager.default.fileExists(atPath: url.path) else {
        throw SurfaceFailure.invalidInput("missing_\(name)")
      }
      let data = try Data(contentsOf: url)
      guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
        throw SurfaceFailure.invalidInput("invalid_\(name)")
      }
      return obj
    }

    let cloudObj = try loadJSON("fused_point_cloud.json")
    let normalsObj = try loadJSON("point_normals.json")
    let gapsObj = try loadJSON("spatial_gaps.json")
    let conflictsObj = try loadJSON("spatial_conflicts.json")
    let lineageObj = try loadJSON("spatial_lineage_manifest.json")
    let closureObj = try loadJSON("output_closure.json")
    let handoffObj = try loadJSON("phase4d_handoff_contract.json")

    let pointsArr = cloudObj["points"] as? [[String: Any]] ?? []
    var points: [ConsolidatedPoint] = []
    for p in pointsArr {
      guard let id = p["fused_point_id"] as? String,
            let pos = p["position"] as? [String: Any],
            let x = doubleVal(pos["x"]), let y = doubleVal(pos["y"]), let z = doubleVal(pos["z"])
      else { continue }
      let conf = p["confidence_summary"] as? [String: Any]
      let classificationRaw = p["classification"] as? String ?? DuplicateSpatialClass.nearbyDistinctPoint.rawValue
      let classification = DuplicateSpatialClass(rawValue: classificationRaw) ?? .nearbyDistinctPoint
      points.append(
        ConsolidatedPoint(
          fusedPointID: id,
          x: x, y: y, z: z,
          contributionCount: p["contribution_count"] as? Int ?? 1,
          sourcePointIDs: p["source_point_ids"] as? [String] ?? [],
          sourceObservationIDs: p["source_observation_ids"] as? [String] ?? [],
          confidenceMean: doubleVal(conf?["mean"]) ?? 0,
          confidenceMin: doubleVal(conf?["min"]) ?? 0,
          confidenceMax: doubleVal(conf?["max"]) ?? 0,
          voxelID: p["voxel_id"] as? String ?? "",
          derivationID: p["derivation_id"] as? String ?? "",
          classification: classification,
          authority: p["fusion_output_authority"] as? String ?? "RECONSTRUCTION_ESTIMATE"
        )
      )
    }
    let coordObj = cloudObj["coordinate_convention"] as? [String: Any] ?? [:]
    let coordinate = FusionCoordinateConvention(
      reconstructionRootFrame: coordObj["reconstruction_root_frame"] as? String ?? FusionCoordinateConvention.fixture.reconstructionRootFrame,
      units: coordObj["units"] as? String ?? "meters",
      handedness: coordObj["handedness"] as? String ?? "right",
      upAxis: coordObj["up_axis"] as? String ?? "+Y",
      matrixLayout: coordObj["matrix_layout"] as? String ?? "column_major",
      vectorConvention: coordObj["vector_convention"] as? String ?? "opencv_optical_z_forward"
    )
    let fusedCloud = FusedPointCloud(
      cloudID: cloudObj["cloud_id"] as? String ?? "FPC",
      reconstructionOutputID: cloudObj["reconstruction_output_id"] as? String ?? FixtureDenseFusionPackageBuilder.reconstructionOutputID,
      authority: cloudObj["fusion_output_authority"] as? String ?? "RECONSTRUCTION_ESTIMATE",
      points: points,
      coordinate: coordinate
    )

    let normalsArr = normalsObj["normals"] as? [[String: Any]] ?? []
    var normals: [PointNormal] = []
    for n in normalsArr {
      guard let id = n["fused_point_id"] as? String,
            let nv = n["normal"] as? [String: Any],
            let nx = doubleVal(nv["nx"]), let ny = doubleVal(nv["ny"]), let nz = doubleVal(nv["nz"])
      else { continue }
      let validity = NormalValidityClassification(rawValue: n["validity"] as? String ?? "") ?? .insufficientNeighborhood
      normals.append(
        PointNormal(
          fusedPointID: id, nx: nx, ny: ny, nz: nz,
          neighborIDs: n["contributing_neighbor_ids"] as? [String] ?? [],
          algorithmID: n["algorithm_id"] as? String ?? "",
          algorithmVersion: n["algorithm_version"] as? String ?? "",
          neighborhoodPolicy: n["neighborhood_policy"] as? String ?? "",
          orientationConvention: n["orientation_convention"] as? String ?? "",
          validity: validity,
          confidence: doubleVal(n["confidence"]) ?? 0,
          derivationID: n["derivation_id"] as? String ?? ""
        )
      )
    }

    let gapsArr = gapsObj["gaps"] as? [[String: Any]] ?? []
    let gaps: [SpatialGap] = gapsArr.compactMap { g in
      guard let id = g["gap_id"] as? String else { return nil }
      let cls = SpatialGapClassification(rawValue: g["classification"] as? String ?? "") ?? .unobserved
      return SpatialGap(
        gapID: id,
        classification: cls,
        detail: g["detail"] as? String ?? "",
        boundsMin: (g["bounds_min"] as? [Double]) ?? [0, 0, 0],
        boundsMax: (g["bounds_max"] as? [Double]) ?? [0, 0, 0]
      )
    }

    let conflictsArr = conflictsObj["conflicts"] as? [[String: Any]] ?? []
    let conflictIDs = conflictsArr.compactMap { $0["conflict_id"] as? String }.sorted()

    let quarantined = (handoffObj["quarantined_regions"] as? [String] ?? []).sorted()
    let readiness = handoffObj["phase4d_readiness"] as? String ?? ""
    let lineageID = lineageObj["lineage_manifest_id"] as? String
      ?? handoffObj["source_lineage_manifest_id"] as? String
      ?? ""
    let closure = closureObj["output_closure_sha256"] as? String
      ?? handoffObj["output_closure_sha256"] as? String
      ?? ""

    return Phase4CSurfaceHandoffBundle(
      fusedCloud: fusedCloud,
      normals: normals,
      gaps: gaps,
      conflictIDs: conflictIDs,
      quarantinedRegions: quarantined,
      lineageManifestID: lineageID,
      phase4COutputClosureSHA256: closure,
      phase4DReadiness: readiness,
      phase4CReconstructionOutputID: fusedCloud.reconstructionOutputID,
      coordinate: coordinate
    )
  }

  private static func doubleVal(_ any: Any?) -> Double? {
    if let d = any as? Double { return d }
    if let i = any as? Int { return Double(i) }
    if let n = any as? NSNumber { return n.doubleValue }
    return nil
  }
}
