import Foundation

// MARK: - Feature tracks

public struct FeatureTrackObservation: Equatable, Sendable {
  public var featureObservationID: String
  public var cameraSampleID: String
  public var pixelU: Double
  public var pixelV: Double
  public var fixtureLandmarkID: String?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "feature_observation_id": featureObservationID,
      "camera_sample_id": cameraSampleID,
      "pixel_coordinate": ["u": pixelU, "v": pixelV],
    ]
    if let fixtureLandmarkID { d["fixture_landmark_id"] = fixtureLandmarkID }
    return d
  }
}

public struct FeatureTrack: Equatable, Sendable {
  public var trackID: String
  public var observations: [FeatureTrackObservation]
  public var frameEpochID: String
  public var sessionRunID: String
  public var fixtureLandmarkID: String?
  public var derivationID: String

  public var length: Int { observations.count }

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "track_id": trackID,
      "observations": observations.map { $0.dictionary() },
      "track_length": length,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "derivation_id": derivationID,
    ]
    if let fixtureLandmarkID { d["fixture_landmark_id"] = fixtureLandmarkID }
    return d
  }
}

public struct TrackConflictRecord: Equatable, Sendable {
  public var code: String
  public var detail: String

  public func dictionary() -> [String: Any] {
    ["code": code, "detail": detail]
  }
}

public struct FeatureTrackGraph: Equatable, Sendable {
  public var tracks: [FeatureTrack]
  public var conflicts: [TrackConflictRecord]

  public var meanTrackLength: Double {
    guard !tracks.isEmpty else { return 0 }
    return Double(tracks.map(\.length).reduce(0, +)) / Double(tracks.count)
  }

  public func dictionary() -> [String: Any] {
    [
      "tracks": tracks.sorted { $0.trackID < $1.trackID }.map { $0.dictionary() },
      "conflicts": conflicts.map { $0.dictionary() },
      "feature_track_count": tracks.count,
      "mean_feature_track_length": meanTrackLength,
      "schema_id": "FeatureTrackGraph",
      "schema_version": "1.0.0-phase4b-fixture",
    ]
  }
}

public struct FeatureTrackValidationResult: Equatable, Sendable {
  public var ok: Bool
  public var conflicts: [TrackConflictRecord]
}

public struct FeatureTrackBuilder: Sendable {
  public var minTrackLength: Int

  public init(minTrackLength: Int = 2) {
    self.minTrackLength = minTrackLength
  }

  public func build(
    frameSets: [FrameFeatureSet],
    correspondences: [FramePairCorrespondenceSet],
    expectedEpoch: String,
    expectedSession: String
  ) throws -> FeatureTrackGraph {
    let obsByID = Dictionary(
      uniqueKeysWithValues: frameSets.flatMap(\.observations).map { ($0.featureObservationID, $0) }
    )
    // Union-find by landmark ID when available; else by correspondence chain
    var parent: [String: String] = [:]
    func find(_ x: String) -> String {
      if parent[x] == nil { parent[x] = x }
      if parent[x]! != x { parent[x] = find(parent[x]!) }
      return parent[x]!
    }
    func union(_ a: String, _ b: String) {
      let ra = find(a), rb = find(b)
      if ra < rb { parent[rb] = ra } else if rb < ra { parent[ra] = rb }
    }

    var conflicts: [TrackConflictRecord] = []

    for pair in correspondences {
      for m in pair.accepted {
        guard let s = obsByID[m.sourceFeatureID], let d = obsByID[m.destinationFeatureID] else {
          conflicts.append(TrackConflictRecord(code: "MISSING_OBSERVATION", detail: m.matchID))
          continue
        }
        if s.frameEpochID != expectedEpoch || d.frameEpochID != expectedEpoch {
          conflicts.append(TrackConflictRecord(code: "EPOCH_MISMATCH", detail: m.matchID))
          continue
        }
        if s.sessionRunID != expectedSession || d.sessionRunID != expectedSession {
          conflicts.append(TrackConflictRecord(code: "SESSION_MISMATCH", detail: m.matchID))
          continue
        }
        union(m.sourceFeatureID, m.destinationFeatureID)
      }
    }

    // Also seed unions by identical fixture landmark across frames
    let byLandmark = Dictionary(grouping: frameSets.flatMap(\.observations).filter { $0.fixtureLandmarkID != nil }) {
      $0.fixtureLandmarkID!
    }
    for (_, group) in byLandmark {
      let ids = group.map(\.featureObservationID).sorted()
      guard let first = ids.first else { continue }
      for id in ids.dropFirst() { union(first, id) }
    }

    var components: [String: [FeatureObservation]] = [:]
    for obs in frameSets.flatMap(\.observations) {
      let root = find(obs.featureObservationID)
      components[root, default: []].append(obs)
    }

    var tracks: [FeatureTrack] = []
    for (root, members) in components.sorted(by: { $0.key < $1.key }) {
      // Unique feature per frame
      var perFrame: [String: FeatureObservation] = [:]
      var conflict = false
      for m in members {
        if let existing = perFrame[m.cameraSampleID] {
          conflicts.append(
            TrackConflictRecord(
              code: "DUPLICATE_OBSERVATION_IN_FRAME",
              detail: "\(existing.featureObservationID)+\(m.featureObservationID)"
            )
          )
          conflict = true
        } else {
          perFrame[m.cameraSampleID] = m
        }
      }
      if conflict { continue }

      // Contradictory landmark merges
      let landmarks = Set(members.compactMap(\.fixtureLandmarkID))
      if landmarks.count > 1 {
        conflicts.append(TrackConflictRecord(code: "CONTRADICTORY_MERGE", detail: landmarks.sorted().joined(separator: ",")))
        continue
      }

      let ordered = perFrame.values.sorted { $0.cameraSampleID < $1.cameraSampleID }
      if ordered.count < minTrackLength { continue }

      // Duplicate observation identity across track
      let ids = ordered.map(\.featureObservationID)
      if Set(ids).count != ids.count {
        conflicts.append(TrackConflictRecord(code: "DUPLICATE_TRACK_OBSERVATION", detail: root))
        continue
      }

      let landmark = landmarks.first
      tracks.append(
        FeatureTrack(
          trackID: "TRACK-\(landmark ?? root)",
          observations: ordered.map {
            FeatureTrackObservation(
              featureObservationID: $0.featureObservationID,
              cameraSampleID: $0.cameraSampleID,
              pixelU: $0.pixelU,
              pixelV: $0.pixelV,
              fixtureLandmarkID: $0.fixtureLandmarkID
            )
          },
          frameEpochID: expectedEpoch,
          sessionRunID: expectedSession,
          fixtureLandmarkID: landmark,
          derivationID: "DER-TRACK-\(landmark ?? root)"
        )
      )
    }

    return FeatureTrackGraph(
      tracks: tracks.sorted { $0.trackID < $1.trackID },
      conflicts: conflicts
    )
  }
}

// MARK: - Pose graph

public struct PosePrior: Equatable, Sendable {
  public var nodeID: String
  public var translation: [Double]
  public var transform4x4: [Double]
  public var authority: String
  public var weight: Double

  public func dictionary() -> [String: Any] {
    [
      "node_id": nodeID,
      "translation": translation,
      "transform_4x4": transform4x4,
      "authority": authority,
      "weight": weight,
    ]
  }
}

public struct VisualConstraint: Equatable, Sendable {
  public var constraintID: String
  public var sourceNodeID: String
  public var destinationNodeID: String
  public var trackIDs: [String]
  public var residualPixels: Double

  public func dictionary() -> [String: Any] {
    [
      "constraint_id": constraintID,
      "source_node_id": sourceNodeID,
      "destination_node_id": destinationNodeID,
      "track_ids": trackIDs.sorted(),
      "residual_pixels": residualPixels,
    ]
  }
}

public struct DepthConstraint: Equatable, Sendable {
  public var constraintID: String
  public var nodeID: String
  public var depthSampleID: String

  public func dictionary() -> [String: Any] {
    [
      "constraint_id": constraintID,
      "node_id": nodeID,
      "depth_sample_id": depthSampleID,
    ]
  }
}

public struct ReconstructionPoseEdge: Equatable, Sendable {
  public var edgeID: String
  public var fromNodeID: String
  public var toNodeID: String
  public var kind: String
  public var relativeTranslation: [Double]

  public func dictionary() -> [String: Any] {
    [
      "edge_id": edgeID,
      "from_node_id": fromNodeID,
      "to_node_id": toNodeID,
      "kind": kind,
      "relative_translation": relativeTranslation,
    ]
  }
}

public struct ReconstructionPoseNode: Equatable, Sendable {
  public var nodeID: String
  public var cameraSampleID: String
  public var poseSampleID: String
  public var sourceTranslation: [Double]
  public var sourceTransform4x4: [Double]
  public var sourcePoseAuthority: String
  public var refinedTranslation: [Double]?
  public var refinedTransform4x4: [Double]?
  public var refinementAuthority: String?
  public var frameEpochID: String
  public var sessionRunID: String
  public var worldOriginRevision: UInt64
  public var derivationID: String

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "node_id": nodeID,
      "camera_sample_id": cameraSampleID,
      "pose_sample_id": poseSampleID,
      "source_translation": sourceTranslation,
      "source_transform_4x4": sourceTransform4x4,
      "source_pose_authority": sourcePoseAuthority,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "derivation_id": derivationID,
      "note": "Source pose is immutable observation; refined pose is RECONSTRUCTION_ESTIMATE only",
    ]
    if let refinedTranslation { d["refined_translation"] = refinedTranslation }
    if let refinedTransform4x4 { d["refined_transform_4x4"] = refinedTransform4x4 }
    if let refinementAuthority { d["refinement_authority"] = refinementAuthority }
    return d
  }

  public var activeTranslation: [Double] {
    refinedTranslation ?? sourceTranslation
  }

  public var activeTransform4x4: [Double] {
    refinedTransform4x4 ?? sourceTransform4x4
  }
}

public struct PoseGraphConfiguration: Equatable, Sendable {
  public var configurationID: String
  public var maxIterations: Int
  public var convergenceEpsilon: Double
  public var minConstraintsPerNode: Int

  public static let fixture = PoseGraphConfiguration(
    configurationID: "CFG-POSE-GRAPH-FIXTURE-000001",
    maxIterations: 10,
    convergenceEpsilon: 1e-9,
    minConstraintsPerNode: 1
  )

  public var configurationDigest: String {
    ContentHasher.sha256Hex(
      Data("\(configurationID)|\(maxIterations)|\(convergenceEpsilon)|\(minConstraintsPerNode)".utf8)
    )
  }

  public func dictionary() -> [String: Any] {
    [
      "configuration_id": configurationID,
      "max_iterations": maxIterations,
      "convergence_epsilon": convergenceEpsilon,
      "min_constraints_per_node": minConstraintsPerNode,
      "configuration_digest": configurationDigest,
      "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
      "note": "Fixture convergence is not proof of real-vehicle photogrammetry",
    ]
  }
}

public struct ReconstructionPoseGraph: Equatable, Sendable {
  public var graphID: String
  public var nodes: [ReconstructionPoseNode]
  public var edges: [ReconstructionPoseEdge]
  public var priors: [PosePrior]
  public var visualConstraints: [VisualConstraint]
  public var depthConstraints: [DepthConstraint]
  public var configuration: PoseGraphConfiguration

  public func dictionary() -> [String: Any] {
    [
      "graph_id": graphID,
      "nodes": nodes.sorted { $0.nodeID < $1.nodeID }.map { $0.dictionary() },
      "edges": edges.sorted { $0.edgeID < $1.edgeID }.map { $0.dictionary() },
      "priors": priors.sorted { $0.nodeID < $1.nodeID }.map { $0.dictionary() },
      "visual_constraints": visualConstraints.sorted { $0.constraintID < $1.constraintID }.map { $0.dictionary() },
      "depth_constraints": depthConstraints.sorted { $0.constraintID < $1.constraintID }.map { $0.dictionary() },
      "configuration": configuration.dictionary(),
      "pose_graph_node_count": nodes.count,
      "pose_graph_edge_count": edges.count,
      "schema_id": "ReconstructionPoseGraph",
      "schema_version": "1.0.0-phase4b-fixture",
    ]
  }

  public func digest() throws -> String {
    ContentHasher.sha256Hex(try CanonicalJSON.data(dictionary()))
  }
}

public struct PoseGraphValidationResult: Equatable, Sendable {
  public var ok: Bool
  public var reasons: [String]

  public func dictionary() -> [String: Any] {
    ["ok": ok, "reasons": reasons]
  }
}

public enum PoseGraphValidator {
  public static func validate(_ graph: ReconstructionPoseGraph) -> PoseGraphValidationResult {
    var reasons: [String] = []
    if graph.nodes.isEmpty { reasons.append("EMPTY_GRAPH") }
    var seen = Set<String>()
    for n in graph.nodes {
      if !seen.insert(n.nodeID).inserted { reasons.append("DUPLICATE_NODE:\(n.nodeID)") }
      if n.sourceTransform4x4.count != 16 { reasons.append("INVALID_SOURCE_TRANSFORM:\(n.nodeID)") }
      if !n.sourceTranslation.allSatisfy(\.isFinite) { reasons.append("NON_FINITE_SOURCE:\(n.nodeID)") }
    }
    let nodeIDs = Set(graph.nodes.map(\.nodeID))
    for e in graph.edges {
      if !nodeIDs.contains(e.fromNodeID) || !nodeIDs.contains(e.toNodeID) {
        reasons.append("DANGLING_EDGE:\(e.edgeID)")
      }
    }
    // Connectivity (undirected)
    if !graph.nodes.isEmpty {
      var adj: [String: Set<String>] = [:]
      for n in graph.nodes { adj[n.nodeID] = [] }
      for e in graph.edges {
        adj[e.fromNodeID, default: []].insert(e.toNodeID)
        adj[e.toNodeID, default: []].insert(e.fromNodeID)
      }
      var visited = Set<String>()
      var stack = [graph.nodes[0].nodeID]
      while let cur = stack.popLast() {
        if visited.insert(cur).inserted {
          stack.append(contentsOf: adj[cur] ?? [])
        }
      }
      if visited.count != graph.nodes.count {
        reasons.append("DISCONNECTED_GRAPH")
      }
    }
    return PoseGraphValidationResult(ok: reasons.isEmpty, reasons: reasons)
  }
}
