import Foundation

// MARK: - Quality

public struct ReconstructionQualityMetric: Equatable, Sendable {
  public var metricID: String
  public var classification: String
  public var value: Double
  public var unit: String
  public var notes: String

  public func dictionary() -> [String: Any] {
    [
      "metric_id": metricID,
      "classification": classification,
      "value": value,
      "unit": unit,
      "notes": notes,
    ]
  }
}

public struct ReconstructionCoverageMetric: Equatable, Sendable {
  public var acceptedFrameCount: Int
  public var rejectedFrameCount: Int
  public var registeredPointCount: Int
  public var invalidDepthCount: Int
  public var associationCompleteness: Double
  public var transformChainCompleteness: Double

  public func dictionary() -> [String: Any] {
    [
      "accepted_frame_count": acceptedFrameCount,
      "rejected_frame_count": rejectedFrameCount,
      "registered_point_count": registeredPointCount,
      "invalid_depth_count": invalidDepthCount,
      "association_completeness": associationCompleteness,
      "transform_chain_completeness": transformChainCompleteness,
    ]
  }
}

public struct RegistrationResidualRecord: Equatable, Sendable {
  public var residualID: String
  public var classification: String
  public var meanAbsoluteErrorMeters: Double
  public var maxAbsoluteErrorMeters: Double
  public var comparedPointCount: Int

  public func dictionary() -> [String: Any] {
    [
      "residual_id": residualID,
      "classification": classification,
      "mean_absolute_error_meters": meanAbsoluteErrorMeters,
      "max_absolute_error_meters": maxAbsoluteErrorMeters,
      "compared_point_count": comparedPointCount,
    ]
  }
}

public struct GroundTruthComparisonRecord: Equatable, Sendable {
  public var comparisonID: String
  public var geometryID: String
  public var geometryReferenceAuthority: String
  public var classification: String
  public var residual: RegistrationResidualRecord
  public var passed: Bool
  public var boundMeters: Double

  public func dictionary() -> [String: Any] {
    [
      "comparison_id": comparisonID,
      "geometry_id": geometryID,
      "geometry_reference_authority": geometryReferenceAuthority,
      "classification": classification,
      "residual": residual.dictionary(),
      "passed": passed,
      "bound_meters": boundMeters,
    ]
  }
}

public struct ReconstructionQualityRecord: Equatable, Sendable {
  public var qualityRecordID: String
  public var metrics: [ReconstructionQualityMetric]
  public var coverage: ReconstructionCoverageMetric
  public var groundTruthComparison: GroundTruthComparisonRecord?
  public var characterizationStatus: String
  public var systemTolerance: String
  public var engineeringMetrologyClaim: String

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "quality_record_id": qualityRecordID,
      "metrics": metrics.map { $0.dictionary() },
      "coverage": coverage.dictionary(),
      "characterization_status": characterizationStatus,
      "system_tolerance": systemTolerance,
      "engineering_metrology_claim": engineeringMetrologyClaim,
      "schema_id": "ReconstructionQualityRecord",
      "schema_version": "1.0.0-phase4a-fixture",
    ]
    if let groundTruthComparison { d["ground_truth_comparison"] = groundTruthComparison.dictionary() }
    return d
  }
}

public struct ReconstructionQualitySummary: Equatable, Sendable {
  public var summaryID: String
  public var record: ReconstructionQualityRecord
  public var summarySHA256: String

  public func dictionary() -> [String: Any] {
    [
      "summary_id": summaryID,
      "record": record.dictionary(),
      "summary_sha256": summarySHA256,
    ]
  }
}

public enum ReconstructionQualityAssessor {
  public static let boundMeters = 1e-9

  public static func assess(
    frames: SelectedFrameSet,
    registration: RegistrationResult,
    expectedPoints: [[String: Double]],
    geometryID: String
  ) throws -> ReconstructionQualityRecord {
    let registered = registration.points.filter { $0.validity == .valid }.sorted { $0.pointID < $1.pointID }
    var errors: [Double] = []
    let expectedByUV: [String: (Double, Double, Double)] = Dictionary(
      uniqueKeysWithValues: expectedPoints.compactMap { pt -> (String, (Double, Double, Double))? in
        guard let u = pt["u"], let v = pt["v"], let x = pt["x"], let y = pt["y"], let z = pt["z"] else {
          return nil
        }
        return (String(format: "%02d-%02d", Int(u), Int(v)), (x, y, z))
      }
    )
    for p in registered {
      let key = String(format: "%02d-%02d", p.source.pixelU, p.source.pixelV)
      guard let e = expectedByUV[key] else { continue }
      let dx = abs(p.x - e.0)
      let dy = abs(p.y - e.1)
      let dz = abs(p.z - e.2)
      errors.append(max(dx, max(dy, dz)))
    }
    let mean = errors.isEmpty ? 0.0 : errors.reduce(0, +) / Double(errors.count)
    let maxE = errors.max() ?? 0.0
    let residual = RegistrationResidualRecord(
      residualID: "RESIDUAL-FIXTURE-000001",
      classification: "FIXTURE_REGISTRATION_ERROR",
      meanAbsoluteErrorMeters: mean,
      maxAbsoluteErrorMeters: maxE,
      comparedPointCount: errors.count
    )
    let gt = GroundTruthComparisonRecord(
      comparisonID: "GT-COMPARE-FIXTURE-000001",
      geometryID: geometryID,
      geometryReferenceAuthority: "TEST_FIXTURE_GROUND_TRUTH",
      classification: "FIXTURE_GROUND_TRUTH_DELTA",
      residual: residual,
      passed: maxE <= boundMeters,
      boundMeters: boundMeters
    )
    let coverage = ReconstructionCoverageMetric(
      acceptedFrameCount: frames.selectedCandidateIDs.count,
      rejectedFrameCount: frames.decisions.filter { !$0.selected }.count,
      registeredPointCount: registered.count,
      invalidDepthCount: registration.invalidDepthCount,
      associationCompleteness: 1.0,
      transformChainCompleteness: 1.0
    )
    let metrics = [
      ReconstructionQualityMetric(
        metricID: "QM-ACCEPTED-FRAMES",
        classification: "RECONSTRUCTION_QUALITY_ESTIMATE",
        value: Double(coverage.acceptedFrameCount),
        unit: "count",
        notes: "PENDING_PHYSICAL_CHARACTERIZATION"
      ),
      ReconstructionQualityMetric(
        metricID: "QM-REGISTERED-POINTS",
        classification: "RECONSTRUCTION_QUALITY_ESTIMATE",
        value: Double(coverage.registeredPointCount),
        unit: "count",
        notes: "PENDING_PHYSICAL_CHARACTERIZATION"
      ),
      ReconstructionQualityMetric(
        metricID: "QM-FIXTURE-MAX-ERROR",
        classification: "FIXTURE_REGISTRATION_ERROR",
        value: maxE,
        unit: "meters",
        notes: "Deterministic fixture bound only; not engineering metrology"
      ),
    ]
    return ReconstructionQualityRecord(
      qualityRecordID: "QR-FIXTURE-RECONSTRUCTION-000001",
      metrics: metrics,
      coverage: coverage,
      groundTruthComparison: gt,
      characterizationStatus: "DETERMINISTIC_TEST_FIXTURE",
      systemTolerance: "NO_SYSTEM_TOLERANCE_ASSIGNED",
      engineeringMetrologyClaim: "FORBIDDEN"
    )
  }
}

// MARK: - Surface candidate (optional synthetic)

public struct SurfaceCandidateMetadata: Equatable, Sendable {
  public var classification: String
  public var geometryID: String
  public var pointCount: Int
  public var authority: String
  public var productionMeshClaim: String
  public var vehicleMeshClaim: String
  public var engineeringDigitalTwinClaim: String

  public func dictionary() -> [String: Any] {
    [
      "classification": classification,
      "geometry_id": geometryID,
      "point_count": pointCount,
      "authority": authority,
      "production_mesh_claim": productionMeshClaim,
      "vehicle_mesh_claim": vehicleMeshClaim,
      "engineering_digital_twin_claim": engineeringDigitalTwinClaim,
    ]
  }
}

public struct SurfaceCandidate: Equatable, Sendable {
  public var surfaceCandidateID: String
  public var metadata: SurfaceCandidateMetadata
  public var verticesMeters: [[Double]]
  public var derivationID: String

  public func dictionary() -> [String: Any] {
    [
      "surface_candidate_id": surfaceCandidateID,
      "metadata": metadata.dictionary(),
      "vertices_meters": verticesMeters,
      "derivation_id": derivationID,
      "schema_id": "SurfaceCandidate",
      "schema_version": "1.0.0-phase4a-fixture",
    ]
  }
}

public struct SurfaceGenerationResult: Equatable, Sendable {
  public var generated: Bool
  public var candidate: SurfaceCandidate?

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = ["generated": generated]
    if let candidate { d["candidate"] = candidate.dictionary() }
    return d
  }
}

public enum SyntheticFixtureSurfaceGenerator {
  public static func generate(
    from cloud: RegisteredPointCloud,
    geometryID: String,
    derivationID: String
  ) -> SurfaceGenerationResult {
    let valid = cloud.points.filter { $0.validity == .valid }.sorted { $0.pointID < $1.pointID }
    guard !valid.isEmpty else {
      return SurfaceGenerationResult(generated: false, candidate: nil)
    }
    let verts = valid.map { [$0.x, $0.y, $0.z] }
    let meta = SurfaceCandidateMetadata(
      classification: "SYNTHETIC_FIXTURE_SURFACE_CANDIDATE",
      geometryID: geometryID,
      pointCount: verts.count,
      authority: "TEST_FIXTURE",
      productionMeshClaim: "FORBIDDEN",
      vehicleMeshClaim: "FORBIDDEN",
      engineeringDigitalTwinClaim: "FORBIDDEN"
    )
    let candidate = SurfaceCandidate(
      surfaceCandidateID: "SURF-FIXTURE-000001",
      metadata: meta,
      verticesMeters: verts,
      derivationID: derivationID
    )
    return SurfaceGenerationResult(generated: true, candidate: candidate)
  }
}

// MARK: - Lineage

public struct ReconstructionAlgorithmDescriptor: Equatable, Sendable {
  public var algorithmID: String
  public var algorithmVersion: String
  public var description: String

  public func dictionary() -> [String: Any] {
    [
      "algorithm_id": algorithmID,
      "algorithm_version": algorithmVersion,
      "description": description,
    ]
  }
}

public struct ReconstructionConfigurationDigest: Equatable, Sendable {
  public var configurationID: String
  public var digestSHA256: String
  public var policyIDs: [String]
  public var policyVersions: [String]

  public func dictionary() -> [String: Any] {
    [
      "configuration_id": configurationID,
      "digest_sha256": digestSHA256,
      "policy_ids": policyIDs.sorted(),
      "policy_versions": policyVersions.sorted(),
    ]
  }
}

public struct ReconstructionDerivationRecord: Equatable, Sendable {
  public var derivationID: String
  public var sourcePackageID: String
  public var sourcePackageClosureSHA256: String
  public var sourceManifestSHA256: String
  public var sourceSampleIDs: [String]
  public var sourceArtifactHashes: [String]
  public var algorithm: ReconstructionAlgorithmDescriptor
  public var configuration: ReconstructionConfigurationDigest
  public var policyIDs: [String]
  public var outputArtifactIDs: [String]
  public var outputArtifactHashes: [String]
  public var generationTimestamp: String
  public var authority: String
  public var reproducibilityStatus: String

  public func dictionary() -> [String: Any] {
    [
      "derivation_id": derivationID,
      "source_package_id": sourcePackageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "source_manifest_sha256": sourceManifestSHA256,
      "source_sample_ids": sourceSampleIDs.sorted(),
      "source_artifact_hashes": sourceArtifactHashes.sorted(),
      "algorithm": algorithm.dictionary(),
      "configuration": configuration.dictionary(),
      "policy_ids": policyIDs.sorted(),
      "output_artifact_ids": outputArtifactIDs.sorted(),
      "output_artifact_hashes": outputArtifactHashes.sorted(),
      "generation_timestamp": generationTimestamp,
      "authority": authority,
      "reproducibility_status": reproducibilityStatus,
    ]
  }
}

public struct SpatialLineageManifest: Equatable, Sendable {
  public var lineageManifestID: String
  public var records: [ReconstructionDerivationRecord]
  public var lineageManifestSHA256: String

  public func dictionary() -> [String: Any] {
    [
      "lineage_manifest_id": lineageManifestID,
      "records": records.map { $0.dictionary() },
      "lineage_manifest_sha256": lineageManifestSHA256,
      "schema_id": "SpatialLineageManifest",
      "schema_version": "1.0.0-phase4a-fixture",
    ]
  }
}

public struct ReconstructionOutputInventoryItem: Equatable, Sendable {
  public var relativePath: String
  public var sha256: String
  public var byteCount: Int
  public var mediaType: String
  public var role: String

  public func dictionary() -> [String: Any] {
    [
      "relative_path": relativePath,
      "sha256": sha256,
      "byte_count": byteCount,
      "media_type": mediaType,
      "role": role,
    ]
  }
}

public struct ReconstructionOutputInventory: Equatable, Sendable {
  public var inventoryID: String
  public var reconstructionOutputID: String
  public var items: [ReconstructionOutputInventoryItem]
  public var inventorySHA256: String

  public func dictionary() -> [String: Any] {
    [
      "inventory_id": inventoryID,
      "reconstruction_output_id": reconstructionOutputID,
      "items": items.sorted { $0.relativePath < $1.relativePath }.map { $0.dictionary() },
      "inventory_sha256": inventorySHA256,
      "schema_id": "ReconstructionOutputInventory",
      "schema_version": "1.0.0-phase4a-fixture",
    ]
  }
}

public enum ReconstructionLineageBuilder {
  public static let algorithm = ReconstructionAlgorithmDescriptor(
    algorithmID: "ALG-RECONSTRUCTION-DEPTH-POSE-REGISTER-V1",
    algorithmVersion: "4A.0.0",
    description: "Fixture depth back-projection with bound transforms; not production SfM"
  )

  public static func configurationDigest(policyIDs: [String], versions: [String]) -> ReconstructionConfigurationDigest {
    let payload = (policyIDs.sorted() + versions.sorted()).joined(separator: "|")
    return ReconstructionConfigurationDigest(
      configurationID: "CFG-RECONSTRUCTION-4A-000001",
      digestSHA256: ContentHasher.sha256Hex(Data(payload.utf8)),
      policyIDs: policyIDs,
      policyVersions: versions
    )
  }

  public static func sealLineage(_ records: [ReconstructionDerivationRecord]) throws -> SpatialLineageManifest {
    let body = try CanonicalJSON.data(["records": records.map { $0.dictionary() }])
    let digest = ContentHasher.sha256Hex(body)
    return SpatialLineageManifest(
      lineageManifestID: "LINEAGE-RECONSTRUCTION-000001",
      records: records,
      lineageManifestSHA256: digest
    )
  }
}
