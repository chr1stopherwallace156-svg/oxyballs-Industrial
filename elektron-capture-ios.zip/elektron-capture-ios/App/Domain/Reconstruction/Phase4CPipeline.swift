import Foundation

// MARK: - Job runtime

public enum DenseFusionJobState: String, Codable, Sendable, Equatable {
  case created = "CREATED"
  case validating = "VALIDATING"
  case fusing = "FUSING"
  case filtering = "FILTERING"
  case estimatingNormals = "ESTIMATING_NORMALS"
  case summarizing = "SUMMARIZING"
  case finalizing = "FINALIZING"
  case complete = "COMPLETE"
  case failed = "FAILED"
  case cancelled = "CANCELLED"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public struct FusionProgressRecord: Equatable, Sendable {
  public var state: DenseFusionJobState
  public var message: String
  public var atUTC: String

  public func dictionary() -> [String: Any] {
    ["state": state.rawValue, "message": message, "at_utc": atUTC]
  }
}

public struct FusionResourcePolicy: Equatable, Sendable {
  public var maxInputPoints: Int
  public var maxVoxelCount: Int
  public var maxEstimatedWorkingSetBytes: Int
  public var maxContributorsPerVoxel: Int
  public var cleanupTemporaryOutputs: Bool

  public static let fixture = FusionResourcePolicy(
    maxInputPoints: 10_000,
    maxVoxelCount: 50_000,
    maxEstimatedWorkingSetBytes: 64 * 1024 * 1024,
    maxContributorsPerVoxel: 64,
    cleanupTemporaryOutputs: true
  )

  public func dictionary() -> [String: Any] {
    [
      "max_input_points": maxInputPoints,
      "max_voxel_count": maxVoxelCount,
      "max_estimated_working_set_bytes": maxEstimatedWorkingSetBytes,
      "max_contributors_per_voxel": maxContributorsPerVoxel,
      "cleanup_temporary_outputs": cleanupTemporaryOutputs,
    ]
  }
}

public struct FusionResourceUsageSummary: Equatable, Sendable {
  public var inputPointsProcessed: Int
  public var voxelsAllocated: Int
  public var peakContributions: Int

  public func dictionary() -> [String: Any] {
    [
      "input_points_processed": inputPointsProcessed,
      "voxels_allocated": voxelsAllocated,
      "peak_contributions": peakContributions,
    ]
  }
}

public struct FusionCancellationResult: Equatable, Sendable {
  public var cancelled: Bool
  public var duringState: DenseFusionJobState
  public var sealedOutputCreated: Bool
  public var temporaryCleaned: Bool

  public func dictionary() -> [String: Any] {
    [
      "cancelled": cancelled,
      "during_state": duringState.rawValue,
      "sealed_output_created": sealedOutputCreated,
      "temporary_cleaned": temporaryCleaned,
    ]
  }
}

public final class DenseFusionJob: @unchecked Sendable {
  public private(set) var state: DenseFusionJobState = .created
  public private(set) var progress: [FusionProgressRecord] = []
  public private(set) var cancelRequested = false
  public let jobID: String

  public init(jobID: String = "JOB-DFUSE-FIXTURE-000001") {
    self.jobID = jobID
  }

  public func requestCancel() { cancelRequested = true }
  public var isCancelled: Bool { cancelRequested }

  public func transition(_ to: DenseFusionJobState, message: String) {
    state = to
    progress.append(
      FusionProgressRecord(
        state: to,
        message: message,
        atUTC: "2026-08-04T10:00:00Z"
      )
    )
  }
}

// MARK: - Lineage / fused cloud / Phase 4D handoff

public struct DenseFusionDerivationRecord: Equatable, Sendable {
  public var derivationID: String
  public var kind: String
  public var subjectID: String
  public var sourceIDs: [String]
  public var algorithmID: String
  public var configurationDigest: String

  public func dictionary() -> [String: Any] {
    [
      "derivation_id": derivationID,
      "kind": kind,
      "subject_id": subjectID,
      "source_ids": sourceIDs.sorted(),
      "algorithm_id": algorithmID,
      "configuration_digest": configurationDigest,
    ]
  }
}

public struct DenseFusionLineageManifest: Equatable, Sendable {
  public var lineageManifestID: String
  public var sourcePackageID: String
  public var sourcePackageClosureSHA256: String
  public var phase4AClosureSHA256: String?
  public var phase4BClosureSHA256: String
  public var fusionPolicyID: String
  public var filteringPolicyID: String
  public var normalPolicyID: String
  public var configurationDigest: String
  public var algorithmIDs: [String]
  public var outputArtifactHashes: [String: String]
  public var lineageManifestSHA256: String

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "lineage_manifest_id": lineageManifestID,
      "source_package_id": sourcePackageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "phase4b_closure_sha256": phase4BClosureSHA256,
      "fusion_policy_id": fusionPolicyID,
      "filtering_policy_id": filteringPolicyID,
      "normal_policy_id": normalPolicyID,
      "configuration_digest": configurationDigest,
      "algorithm_ids": algorithmIDs.sorted(),
      "output_artifact_hashes": Dictionary(uniqueKeysWithValues: outputArtifactHashes.keys.sorted().map { ($0, outputArtifactHashes[$0]!) }),
      "lineage_manifest_sha256": lineageManifestSHA256,
      "schema_id": "DenseFusionLineageManifest",
      "schema_version": "1.0.0-phase4c-fixture",
    ]
    if let phase4AClosureSHA256 { d["phase4a_closure_sha256"] = phase4AClosureSHA256 }
    return d
  }
}

public struct FusedPointCloud: Equatable, Sendable {
  public var cloudID: String
  public var reconstructionOutputID: String
  public var authority: String
  public var points: [ConsolidatedPoint]
  public var coordinate: FusionCoordinateConvention

  public func dictionary() -> [String: Any] {
    [
      "cloud_id": cloudID,
      "reconstruction_output_id": reconstructionOutputID,
      "fusion_output_authority": authority,
      "points": points.sorted { $0.fusedPointID < $1.fusedPointID }.map { $0.dictionary() },
      "point_count": points.count,
      "coordinate_convention": coordinate.dictionary(),
      "schema_id": "FusedPointCloud",
      "schema_version": "1.0.0-phase4c-fixture",
      "note": "Canonical traceable fused cloud — not production dense fusion or mesh",
    ]
  }

  public func sha256() throws -> String {
    ContentHasher.sha256Hex(try CanonicalJSON.data(dictionary()))
  }
}

public enum Phase4DReadinessOutcome: String, Codable, Sendable, Equatable {
  case readyForSyntheticSurfaceCandidate = "READY_FOR_SYNTHETIC_SURFACE_CANDIDATE"
  case readyWithSparseRegions = "READY_WITH_SPARSE_REGIONS"
  case additionalCaptureRecommended = "ADDITIONAL_CAPTURE_RECOMMENDED"
  case notReadyInvalidNormals = "NOT_READY_INVALID_NORMALS"
  case notReadyInsufficientDensity = "NOT_READY_INSUFFICIENT_DENSITY"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public struct Phase4DHandoffContract: Equatable, Sendable {
  public var fusedPointCloudArtifactID: String
  public var pointCount: Int
  public var validNormalCount: Int
  public var readiness: Phase4DReadinessOutcome
  public var gapClassifications: [String]
  public var quarantinedRegions: [String]
  public var coordinate: FusionCoordinateConvention
  public var boundingBoxMin: [Double]
  public var boundingBoxMax: [Double]
  public var lineageManifestID: String
  public var outputClosureSHA256: String
  public var limitations: [String]

  public func dictionary() -> [String: Any] {
    [
      "fused_point_cloud_artifact_id": fusedPointCloudArtifactID,
      "point_count": pointCount,
      "valid_normal_count": validNormalCount,
      "phase4d_readiness": readiness.rawValue,
      "gap_and_boundary_classifications": gapClassifications.sorted(),
      "quarantined_regions": quarantinedRegions.sorted(),
      "reconstruction_coordinate_convention": coordinate.dictionary(),
      "spatial_bounding_box": ["min": boundingBoxMin, "max": boundingBoxMax],
      "source_lineage_manifest_id": lineageManifestID,
      "output_closure_sha256": outputClosureSHA256,
      "limitations": limitations,
      "schema_id": "Phase4DHandoffContract",
      "schema_version": "1.0.0-phase4c-fixture",
      "note": "Handoff only — does not generate a mesh",
    ]
  }
}

public enum Phase4CPLYWriter {
  public static func writeASCII(cloud: FusedPointCloud, normals: [PointNormal]) -> String {
    let nByID = Dictionary(uniqueKeysWithValues: normals.map { ($0.fusedPointID, $0) })
    let pts = cloud.points.sorted { $0.fusedPointID < $1.fusedPointID }
    var lines: [String] = [
      "ply",
      "format ascii 1.0",
      "comment Elektron Phase 4C fixture PLY — not production mesh",
      "comment reconstruction_output_id \(cloud.reconstructionOutputID)",
      "comment authority \(cloud.authority)",
      "element vertex \(pts.count)",
      "property float x",
      "property float y",
      "property float z",
      "property float nx",
      "property float ny",
      "property float nz",
      "end_header",
    ]
    for p in pts {
      let n = nByID[p.fusedPointID]
      let validN = n?.validity == .valid || n?.validity == .highCurvatureEdge
      let nx = validN ? (n?.nx ?? 0) : 0
      let ny = validN ? (n?.ny ?? 0) : 0
      let nz = validN ? (n?.nz ?? 0) : 0
      lines.append(String(format: "%.9f %.9f %.9f %.9f %.9f %.9f", p.x, p.y, p.z, nx, ny, nz))
    }
    return lines.joined(separator: "\n") + "\n"
  }
}

public struct Phase4CPipelineResult: Sendable {
  public var reconstructionOutputID: String
  public var eligibility: DenseFusionEligibilityResult
  public var inputInventory: DenseFusionInputInventory
  public var fusion: FusionResult
  public var duplicates: DuplicateConsolidationResult
  public var filtering: PointFilteringResult
  public var conflicts: [SpatialConflictRecord]
  public var normals: NormalEstimationResult
  public var quality: DensePointCloudQualitySummary
  public var fusedCloud: FusedPointCloud
  public var handoff: Phase4DHandoffContract
  public var lineage: DenseFusionLineageManifest
  public var jobState: DenseFusionJobState
  public var cancellation: FusionCancellationResult?
  public var resourceUsage: FusionResourceUsageSummary
  public var outputRoot: URL
  public var phase4bInputPointCount: Int
  public var fusedPointCloudSHA256: String
  public var fusedPointCloudPLYSHA256: String
  public var lineageManifestSHA256: String
  public var outputInventorySHA256: String
  public var outputClosureSHA256: String
  public var sourceOutputsUnchanged: Bool
  public var phase4dReadiness: Phase4DReadinessOutcome
}

public struct Phase4CPipeline: Sendable {
  public var configuration: FusionConfigurationDigest
  public var resourcePolicy: FusionResourcePolicy
  public var cancelDuring: DenseFusionJobState?

  public init(
    configuration: FusionConfigurationDigest = .fixture(),
    resourcePolicy: FusionResourcePolicy = .fixture,
    cancelDuring: DenseFusionJobState? = nil
  ) {
    self.configuration = configuration
    self.resourcePolicy = resourcePolicy
    self.cancelDuring = cancelDuring
  }

  public func run(
    packageRoot: URL,
    outputRoot: URL,
    sealedGeometry: FixtureMultiviewSurfaceGeometry? = nil,
    parentPhase4BClosureSHA256: String? = nil
  ) throws -> Phase4CPipelineResult {
    let job = DenseFusionJob()
    job.transition(.created, message: "job_created")

    let sourceBefore = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: packageRoot)
    let geometry = sealedGeometry ?? FixtureMultiviewSurfaceGeometry.multiviewSurface()

    // Build Phase-4B-shaped registered clouds from this package (refined = true poses).
    let prepared = try preparePhase4BShapedInput(
      packageRoot: packageRoot,
      geometry: geometry,
      parentPhase4BClosureSHA256: parentPhase4BClosureSHA256
    )

    // Preserve copies for immutability proof
    let sourceCloudSnapshot = prepared.sourceCloud
    let refinedCloudSnapshot = prepared.refinedCloud
    let sourceCloudDigestBefore = try sourceCloudSnapshot.sha256()
    let refinedCloudDigestBefore = try refinedCloudSnapshot.sha256()

    job.transition(.validating, message: "validating_input")
    if cancelDuring == .validating {
      job.requestCancel()
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .validating)
    }

    var cfg = configuration
    cfg.maxInputPoints = resourcePolicy.maxInputPoints
    cfg.maxVoxelCount = resourcePolicy.maxVoxelCount
    cfg.maxEstimatedWorkingSetBytes = resourcePolicy.maxEstimatedWorkingSetBytes
    cfg.maxContributorsPerVoxel = resourcePolicy.maxContributorsPerVoxel
    cfg.digest = cfg.computeDigest()

    let eligibility = DenseFusionInputValidator().validate(
      inventory: prepared.inventory,
      refinedCloud: prepared.refinedCloud,
      sourceCloud: prepared.sourceCloud,
      coordinate: .fixture,
      configuration: cfg,
      preferRefined: true
    )
    guard eligibility.isEligible else {
      job.transition(.failed, message: eligibility.outcome.rawValue)
      throw ReconstructionError.ineligible(eligibility.outcome.rawValue)
    }

    let contradictionDelta = 0.12
    let engine = DenseFusionEngine(contradictionDeltaMeters: contradictionDelta)
    var contributions = try engine.buildContributions(
      from: prepared.refinedCloud,
      inventory: prepared.inventory,
      trackSupport: prepared.trackSupport,
      poseRefinementConfidence: prepared.poseRefinementConfidence,
      useRefinedPoseIDs: true,
      maxInputPoints: cfg.maxInputPoints,
      isCancelled: { job.isCancelled }
    )

    // Inject fixture-known extras: isolated outlier, low-confidence, contradictory observation
    contributions.append(contentsOf: fixtureInjectedContributions(baseClosure: prepared.inventory.sourcePackageClosureSHA256, reconClosure: prepared.inventory.phase4BClosureSHA256))
    contributions.sort { $0.contributionID < $1.contributionID }

    if contributions.count > cfg.maxInputPoints {
      throw FusionFailure.resourceBound("max_input_points")
    }

    job.transition(.fusing, message: "fusing")
    if cancelDuring == .fusing {
      job.requestCancel()
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .fusing)
    }

    let fusion = try engine.fuse(contributions: contributions, configuration: cfg, isCancelled: { job.isCancelled })

    job.transition(.filtering, message: "filtering")
    if cancelDuring == .filtering {
      job.requestCancel()
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .filtering)
    }

    let duplicates = SpatialDuplicateDetector().consolidate(fusion: fusion, contributions: fusion.contributions)
    let filtering = PointOutlierDetector().filter(
      consolidated: duplicates.consolidated,
      duplicateResult: duplicates,
      contributions: fusion.contributions
    )
    let conflicts = ObservationConsistencyAnalyzer().analyze(
      fusion: fusion,
      contributions: fusion.contributions,
      contradictionDeltaMeters: contradictionDelta
    )

    let retained = duplicates.consolidated.filter { filtering.retainedPointIDs.contains($0.fusedPointID) }
      .sorted { $0.fusedPointID < $1.fusedPointID }

    job.transition(.estimatingNormals, message: "normals")
    let normals = PointNormalEstimator().estimate(points: retained)

    job.transition(.summarizing, message: "summarizing")
    let quality = DenseFusionCoverageAnalyzer().summarize(
      inputPointCount: prepared.refinedCloud.points.filter { $0.validity == .valid }.count,
      contributions: fusion.contributions,
      fusion: fusion,
      retained: retained,
      filtering: filtering,
      normals: normals,
      conflicts: conflicts
    )

    let outputID = FixtureDenseFusionPackageBuilder.reconstructionOutputID
    let fusedCloud = FusedPointCloud(
      cloudID: "FPC-DENSE-FUSION-000001",
      reconstructionOutputID: outputID,
      authority: "RECONSTRUCTION_ESTIMATE",
      points: retained,
      coordinate: .fixture
    )

    let readiness: Phase4DReadinessOutcome
    if normals.validCount == 0 {
      readiness = .notReadyInvalidNormals
    } else if quality.overallDensity == .additionalCaptureRecommended {
      readiness = .additionalCaptureRecommended
    } else if quality.overallDensity == .sparse {
      readiness = .readyWithSparseRegions
    } else if retained.count < 3 {
      readiness = .notReadyInsufficientDensity
    } else if !filtering.quarantinedPointIDs.isEmpty && retained.count < 5 {
      readiness = .manualReviewRequired
    } else {
      readiness = .readyForSyntheticSurfaceCandidate
    }

    job.transition(.finalizing, message: "finalizing")
    if cancelDuring == .finalizing {
      job.requestCancel()
      try cancelAndCleanup(job: job, outputRoot: outputRoot, during: .finalizing)
    }

    try FileManager.default.createDirectory(at: outputRoot, withIntermediateDirectories: true)
    // Clean any prior partials
    if resourcePolicy.cleanupTemporaryOutputs {
      let tmp = outputRoot.appendingPathComponent(".tmp-partial", isDirectory: true)
      try? FileManager.default.removeItem(at: tmp)
    }

    func writeObj(_ name: String, _ dict: [String: Any]) throws -> (String, Int, String) {
      let data = try CanonicalJSON.data(dict)
      try data.write(to: outputRoot.appendingPathComponent(name), options: .atomic)
      return (name, data.count, ContentHasher.sha256Hex(data))
    }
    func writeText(_ name: String, _ text: String) throws -> (String, Int, String) {
      let data = Data(text.utf8)
      try data.write(to: outputRoot.appendingPathComponent(name), options: .atomic)
      return (name, data.count, ContentHasher.sha256Hex(data))
    }

    var hashes: [String: String] = [:]
    var items: [ReconstructionOutputInventoryItem] = []
    func track(_ n: String, _ b: Int, _ h: String, _ role: String) {
      hashes[n] = h
      items.append(
        ReconstructionOutputInventoryItem(
          relativePath: n, sha256: h, byteCount: b,
          mediaType: n.hasSuffix(".ply") ? "application/x-ply" : "application/json",
          role: role
        )
      )
    }

    do {
      let (n, b, h) = try writeObj("dense_fusion_input_inventory.json", prepared.inventory.dictionary())
      track(n, b, h, "dense_fusion_input_inventory")
    }
    do {
      let (n, b, h) = try writeObj("fusion_policy.json", [
        "eligibility_policy": DenseFusionEligibilityPolicy.fixture.dictionary(),
        "confidence_policy": ConfidenceWeightingPolicy.fixture.dictionary(),
        "duplicate_policy": DuplicateConsolidationPolicy.fixture.dictionary(),
        "outlier_policy": OutlierDetectionPolicy.fixture.dictionary(),
        "resource_policy": resourcePolicy.dictionary(),
        "configuration": cfg.dictionary(),
      ])
      track(n, b, h, "fusion_policy")
    }
    do {
      let (n, b, h) = try writeObj("numeric_policy.json", FusionNumericPolicy.fixture.dictionary())
      track(n, b, h, "numeric_policy")
    }
    do {
      let (n, b, h) = try writeObj("point_contributions.json", [
        "contributions": fusion.contributions.map { $0.dictionary() },
      ])
      track(n, b, h, "point_contributions")
    }
    do {
      let (n, b, h) = try writeObj("fusion_voxels.json", fusion.grid.dictionary())
      track(n, b, h, "fusion_voxels")
    }
    do {
      let (n, b, h) = try writeObj("duplicate_groups.json", duplicates.dictionary())
      track(n, b, h, "duplicate_groups")
    }
    do {
      let (n, b, h) = try writeObj("outlier_records.json", filtering.dictionary())
      track(n, b, h, "outlier_records")
    }
    do {
      let (n, b, h) = try writeObj("spatial_conflicts.json", [
        "conflicts": conflicts.map { $0.dictionary() },
      ])
      track(n, b, h, "spatial_conflicts")
    }

    let fusedSHA: String
    do {
      let (n, b, h) = try writeObj("fused_point_cloud.json", fusedCloud.dictionary())
      fusedSHA = h
      track(n, b, h, "fused_point_cloud")
    }
    let plySHA: String
    do {
      let (n, b, h) = try writeText("fused_point_cloud.ply", Phase4CPLYWriter.writeASCII(cloud: fusedCloud, normals: normals.normals))
      plySHA = h
      track(n, b, h, "fused_point_cloud_ply")
    }
    do {
      let (n, b, h) = try writeObj("point_normals.json", normals.dictionary())
      track(n, b, h, "point_normals")
    }
    do {
      let (n, b, h) = try writeObj("density_records.json", [
        "records": quality.densityRecords.map { $0.dictionary() },
        "overall": quality.overallDensity.rawValue,
      ])
      track(n, b, h, "density_records")
    }
    do {
      let (n, b, h) = try writeObj("spatial_gaps.json", [
        "gaps": quality.gaps.map { $0.dictionary() },
      ])
      track(n, b, h, "spatial_gaps")
    }
    do {
      let (n, b, h) = try writeObj("fusion_quality_summary.json", quality.dictionary())
      track(n, b, h, "fusion_quality_summary")
    }

    let derivations: [DenseFusionDerivationRecord] = retained.map {
      DenseFusionDerivationRecord(
        derivationID: $0.derivationID,
        kind: "CONSOLIDATED_FUSED_POINT",
        subjectID: $0.fusedPointID,
        sourceIDs: $0.sourcePointIDs,
        algorithmID: DeterministicVoxelFusionBackend().backendID,
        configurationDigest: cfg.digest
      )
    }
    do {
      let (n, b, h) = try writeObj("derivation_records.json", [
        "records": derivations.map { $0.dictionary() },
      ])
      track(n, b, h, "derivation_records")
    }
    do {
      let (n, b, h) = try writeObj("fixture_geometry_expected.json", geometry.dictionary())
      track(n, b, h, "expected_geometry")
    }

    let fixtureTruth: [String: Any] = [
      "schema_id": "Phase4CFixtureTruth",
      "schema_version": "1.0.0-phase4c-fixture",
      "input_package_id": FixtureDenseFusionPackageBuilder.primaryPackageID,
      "fixture_geometry_id": geometry.geometryID,
      "reconstruction_output_id": outputID,
      "fixture_default_voxel_size_meters": 0.005,
      "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
      "expected_input_contribution_count_min": prepared.refinedCloud.points.filter { $0.validity == .valid }.count,
      "expected_injected_outlier_ids": ["CTR-FIXTURE-OUTLIER-000001"],
      "expected_injected_lowconf_ids": ["CTR-FIXTURE-LOWCONF-000001"],
      "expected_injected_conflict_ids": ["CTR-FIXTURE-CONFLICT-A-000001", "CTR-FIXTURE-CONFLICT-B-000001"],
      "expected_duplicate_group_min": 1,
      "expected_known_outliers_min": 1,
      "expected_contradictory_regions_min": 1,
      "expected_occupied_voxel_count_min": geometry.expectedOccupiedVoxelCount,
      "expected_consolidated_point_count_min": geometry.expectedConsolidatedPointCountMin,
      "expected_valid_normal_axis": ["nx": 0.0, "ny": 0.0, "nz": -1.0],
      "expected_normal_dot_abs_min": 0.85,
      "noise_law": "COMMITTED_EXPLICIT_OFFSETS_NO_PLATFORM_PRNG",
      "observed": [
        "fusion_contribution_count": fusion.contributions.count,
        "accepted_contribution_count": fusion.contributions.filter { !$0.rejected }.count,
        "rejected_contribution_count": fusion.contributions.filter(\.rejected).count,
        "quarantined_contribution_count": filtering.quarantinedPointIDs.count,
        "occupied_voxel_count": fusion.grid.occupiedCount,
        "consolidated_point_count": retained.count,
        "valid_normal_count": normals.validCount,
      ],
      "geometry_reference_authority": "TEST_FIXTURE_GROUND_TRUTH",
      "fusion_output_authority": "RECONSTRUCTION_ESTIMATE",
    ]
    do {
      let (n, b, h) = try writeObj("fixture_truth.json", fixtureTruth)
      track(n, b, h, "fixture_truth")
    }

    // Source clouds unchanged proof artifacts (copies, not overwriting Phase 4B paths)
    do {
      let (n, b, h) = try writeObj("phase4b_registered_point_cloud_refined_pose_snapshot.json", refinedCloudSnapshot.dictionary())
      track(n, b, h, "phase4b_refined_snapshot")
    }
    do {
      let (n, b, h) = try writeObj("phase4b_registered_point_cloud_source_pose_snapshot.json", sourceCloudSnapshot.dictionary())
      track(n, b, h, "phase4b_source_snapshot")
    }

    var lineage = DenseFusionLineageManifest(
      lineageManifestID: "LINEAGE-PHASE4C-000001",
      sourcePackageID: prepared.inventory.sourcePackageID,
      sourcePackageClosureSHA256: prepared.inventory.sourcePackageClosureSHA256,
      phase4AClosureSHA256: prepared.inventory.phase4AClosureSHA256,
      phase4BClosureSHA256: prepared.inventory.phase4BClosureSHA256,
      fusionPolicyID: DenseFusionEligibilityPolicy.fixture.policyID,
      filteringPolicyID: OutlierDetectionPolicy.fixture.policyID,
      normalPolicyID: NormalEstimationPolicy.fixture.policyID,
      configurationDigest: cfg.digest,
      algorithmIDs: [
        DeterministicVoxelFusionBackend().backendID,
        NormalEstimationPolicy.fixture.algorithmID,
        ConfidenceWeightingPolicy.fixture.policyID,
      ],
      outputArtifactHashes: hashes,
      lineageManifestSHA256: ""
    )
    lineage.lineageManifestSHA256 = ContentHasher.sha256Hex(
      try CanonicalJSON.data({
        var d = lineage.dictionary()
        d["lineage_manifest_sha256"] = ""
        return d
      }())
    )
    let lineageSHA: String
    do {
      let (n, b, h) = try writeObj("spatial_lineage_manifest.json", lineage.dictionary())
      lineageSHA = h
      track(n, b, h, "spatial_lineage_manifest")
      lineage.lineageManifestSHA256 = h
      lineage.outputArtifactHashes = hashes
    }

    items.sort { $0.relativePath < $1.relativePath }
    let inv = ReconstructionOutputInventory(
      inventoryID: "INV-RECON-OUT-4C-000001",
      reconstructionOutputID: outputID,
      items: items,
      inventorySHA256: ContentHasher.sha256Hex(try CanonicalJSON.data(["items": items.map { $0.dictionary() }]))
    )
    let invSHA: String
    do {
      let data = try CanonicalJSON.data(inv.dictionary())
      try data.write(to: outputRoot.appendingPathComponent("output_inventory.json"), options: .atomic)
      invSHA = ContentHasher.sha256Hex(data)
    }

    // Provisional handoff without final closure
    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputRoot)
    let closure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)

    let handoff = Phase4DHandoffContract(
      fusedPointCloudArtifactID: fusedCloud.cloudID,
      pointCount: fusedCloud.points.count,
      validNormalCount: normals.validCount,
      readiness: readiness,
      gapClassifications: quality.gaps.map(\.classification.rawValue),
      quarantinedRegions: filtering.quarantinedPointIDs,
      coordinate: .fixture,
      boundingBoxMin: quality.coverage.boundingBoxMin,
      boundingBoxMax: quality.coverage.boundingBoxMax,
      lineageManifestID: lineage.lineageManifestID,
      outputClosureSHA256: closure,
      limitations: [
        "NO_PRODUCTION_MESH",
        "NO_ENGINEERING_METROLOGY",
        "NO_COMPLETE_DIGITAL_TWIN",
        "FIXTURE_DENSITY_NOT_VEHICLE_DENSITY",
        "PHYSICAL_FUSION_PENDING_SPKG_DEVICE_000001",
      ]
    )
    do {
      let (n, b, h) = try writeObj("phase4d_handoff_contract.json", handoff.dictionary())
      track(n, b, h, "phase4d_handoff_contract")
    }

    _ = try writeObj("output_closure.json", [
      "schema_id": "ReconstructionOutputClosure",
      "reconstruction_output_id": outputID,
      "output_closure_sha256": closure,
      "source_package_id": prepared.inventory.sourcePackageID,
      "source_package_closure_sha256": prepared.inventory.sourcePackageClosureSHA256,
      "phase4b_closure_sha256": prepared.inventory.phase4BClosureSHA256,
      "note": "Phase 4C derived outputs; Phase 4A/4B source clouds unchanged",
    ])

    let finalEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputRoot)
    let finalClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: finalEntries)

    let sourceAfter = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: packageRoot)
    guard sourceBefore == sourceAfter else {
      throw ReconstructionError.deterministicReplayMismatch("source_package_mutated")
    }
    let sourceCloudDigestAfter = try sourceCloudSnapshot.sha256()
    let refinedCloudDigestAfter = try refinedCloudSnapshot.sha256()
    let unchanged = sourceCloudDigestBefore == sourceCloudDigestAfter && refinedCloudDigestBefore == refinedCloudDigestAfter

    job.transition(.complete, message: "complete")

    return Phase4CPipelineResult(
      reconstructionOutputID: outputID,
      eligibility: eligibility,
      inputInventory: prepared.inventory,
      fusion: fusion,
      duplicates: duplicates,
      filtering: filtering,
      conflicts: conflicts,
      normals: normals,
      quality: quality,
      fusedCloud: fusedCloud,
      handoff: handoff,
      lineage: lineage,
      jobState: job.state,
      cancellation: nil,
      resourceUsage: FusionResourceUsageSummary(
        inputPointsProcessed: contributions.count,
        voxelsAllocated: fusion.grid.voxels.count,
        peakContributions: contributions.count
      ),
      outputRoot: outputRoot,
      phase4bInputPointCount: prepared.refinedCloud.points.filter { $0.validity == .valid }.count,
      fusedPointCloudSHA256: fusedSHA,
      fusedPointCloudPLYSHA256: plySHA,
      lineageManifestSHA256: lineageSHA,
      outputInventorySHA256: invSHA,
      outputClosureSHA256: finalClosure,
      sourceOutputsUnchanged: unchanged,
      phase4dReadiness: readiness
    )
  }

  // MARK: - Helpers

  private func cancelAndCleanup(job: DenseFusionJob, outputRoot: URL, during: DenseFusionJobState) throws -> Never {
    job.transition(.cancelled, message: "cancelled_\(during.rawValue)")
    if resourcePolicy.cleanupTemporaryOutputs {
      try? FileManager.default.removeItem(at: outputRoot)
    }
    try FileManager.default.createDirectory(at: outputRoot, withIntermediateDirectories: true)
    let contents = (try? FileManager.default.contentsOfDirectory(atPath: outputRoot.path)) ?? []
    precondition(!contents.contains("output_closure.json"))
    throw FusionFailure.cancelled(during.rawValue)
  }

  private struct PreparedInput {
    var inventory: DenseFusionInputInventory
    var refinedCloud: RegisteredPointCloud
    var sourceCloud: RegisteredPointCloud
    var trackSupport: [String: Double]
    var poseRefinementConfidence: Double
  }

  private func preparePhase4BShapedInput(
    packageRoot: URL,
    geometry: FixtureMultiviewSurfaceGeometry,
    parentPhase4BClosureSHA256: String?
  ) throws -> PreparedInput {
    let ingest = try ReconstructionPackageIngestor().ingest(packageRoot: packageRoot)
    guard ingest.eligibility.isEligible, let descriptor = ingest.descriptor else {
      throw ReconstructionError.ineligible(ingest.eligibility.outcome.rawValue)
    }
    let normalized = try ObservationNormalizer().normalize(ingest: ingest)
    let fx = ReconstructionFixtureDepthPayload.fx
    let fy = ReconstructionFixtureDepthPayload.fy
    let cx = ReconstructionFixtureDepthPayload.cx
    let cy = ReconstructionFixtureDepthPayload.cy
    let calibration = DepthPoseRegistrationEngine.CalibrationIntrinsics(
      calibrationID: FixtureDenseFusionPackageBuilder.calibrationID,
      fx: fx, fy: fy, cx: cx, cy: cy,
      width: ReconstructionFixtureDepthPayload.width,
      height: ReconstructionFixtureDepthPayload.height
    )
    let engine = DepthPoseRegistrationEngine()

    let cameraSamples = ingest.sampleIndex
      .filter { ($0["stream_id"] as? String) == SpatialStreamID.camera }
      .sorted { (($0["sample_id"] as? String) ?? "") < (($1["sample_id"] as? String) ?? "") }
    let poseSamples = ingest.sampleIndex
      .filter { ($0["stream_id"] as? String) == SpatialStreamID.pose }
      .sorted { (($0["sample_id"] as? String) ?? "") < (($1["sample_id"] as? String) ?? "") }
    let artBySample = Dictionary(uniqueKeysWithValues: ingest.artifacts.compactMap { a -> (String, [String: Any])? in
      guard let sid = a["sample_id"] as? String else { return nil }
      return (sid, a)
    })
    let depthByCam: [String: NormalizedDepthObservation] = {
      var map: [String: NormalizedDepthObservation] = [:]
      for assoc in normalized.associations {
        if let cam = normalized.cameras.first(where: { $0.observationID == assoc.cameraObservationID }),
           let depth = normalized.depths.first(where: { $0.observationID == assoc.depthObservationID })
        {
          map[cam.sampleID] = depth
        }
      }
      return map
    }()

    func registerAll(useTruePoses: Bool, cloudID: String, authority: String) throws -> RegisteredPointCloud {
      var all: [RegisteredPoint] = []
      for (idx, cam) in cameraSamples.enumerated() {
        let camID = cam["sample_id"] as? String ?? ""
        guard let depth = depthByCam[camID] else { continue }
        let poseID = poseSamples[min(idx, poseSamples.count - 1)]["sample_id"] as? String ?? "df-pose-\(idx)"
        let t: [Double]
        if useTruePoses {
          t = geometry.trueCameraTranslations[min(idx, geometry.trueCameraTranslations.count - 1)]
        } else {
          let rel = artBySample[poseID]?["relative_path"] as? String ?? "payload/pose/\(String(format: "%04d.bin", idx))"
          let bytes = try Data(contentsOf: packageRoot.appendingPathComponent(rel))
          let matrix = decodeTransform(bytes)
          t = [matrix[12], matrix[13], matrix[14]]
        }
        var matrix = HomogeneousMatrix4x4.identity()
        matrix[12] = t[0]; matrix[13] = t[1]; matrix[14] = t[2]
        let poseObs = NormalizedPoseObservation(
          observationID: "OBS-POSE-\(poseID)",
          sampleID: poseID,
          timestampNanoseconds: 0,
          clockDomain: "arkit_frame",
          translation: t,
          transform4x4: matrix,
          trackingState: "NORMAL",
          frameEpochID: descriptor.frameEpochID,
          sessionRunID: descriptor.sessionRunID,
          worldOriginRevision: descriptor.worldOriginRevision
        )
        let reg = try engine.register(
          depth: depth,
          pose: poseObs,
          calibration: calibration,
          depthToCamera: HomogeneousMatrix4x4.identity(),
          sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
          derivationID: "DER-REG-4C-\(cloudID)-\(idx)"
        )
        for var p in reg.points {
          if idx > 0 {
            p = RegisteredPoint(
              pointID: "\(p.pointID)-F\(idx)",
              x: p.x, y: p.y, z: p.z,
              validity: p.validity,
              confidence: p.confidence,
              sourceFrameID: p.sourceFrameID,
              reconstructionFrameID: p.reconstructionFrameID,
              evidenceAuthority: p.evidenceAuthority,
              source: p.source
            )
          }
          all.append(p)
        }
      }
      all.sort { $0.pointID < $1.pointID }
      let valid = all.filter { $0.validity == .valid }
      return RegisteredPointCloud(
        metadata: RegisteredPointCloudMetadata(
          cloudID: cloudID,
          reconstructionOutputID: FixtureDenseFusionPackageBuilder.reconstructionOutputID,
          sourcePackageID: descriptor.packageID,
          sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
          frameEpochID: descriptor.frameEpochID,
          units: "meters",
          handedness: "right",
          authority: authority
        ),
        points: all,
        quality: PointCloudQualitySummary(
          registeredPointCount: valid.count,
          invalidDepthCount: all.filter { $0.validity != .valid }.count,
          duplicatePointCount: 0,
          boundingBoxMin: [valid.map(\.x).min() ?? 0, valid.map(\.y).min() ?? 0, valid.map(\.z).min() ?? 0],
          boundingBoxMax: [valid.map(\.x).max() ?? 0, valid.map(\.y).max() ?? 0, valid.map(\.z).max() ?? 0]
        )
      )
    }

    let sourceCloud = try registerAll(useTruePoses: false, cloudID: "RPC-SOURCE-POSE-4C-000001", authority: "TEST_FIXTURE")
    let refinedCloud = try registerAll(useTruePoses: true, cloudID: "RPC-REFINED-POSE-4C-000001", authority: "RECONSTRUCTION_ESTIMATE")

    // Synthetic Phase 4B closure digest from refined cloud (binds lineage without requiring merged 4B tree)
    let phase4BClosure: String
    if let parentPhase4BClosureSHA256 {
      phase4BClosure = parentPhase4BClosureSHA256
    } else {
      let refinedSHA = try refinedCloud.sha256()
      let sourceSHA = try sourceCloud.sha256()
      phase4BClosure = ContentHasher.sha256Hex(try CanonicalJSON.data([
        "kind": "PHASE4B_SHAPED_INPUT_DIGEST",
        "refined_cloud_sha256": refinedSHA,
        "source_cloud_sha256": sourceSHA,
        "refinement_outcome": "CONVERGED",
      ]))
    }

    let inventory = DenseFusionInputInventory(
      sourcePackageID: descriptor.packageID,
      sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
      phase4AClosureSHA256: nil,
      phase4BClosureSHA256: phase4BClosure,
      refinedPoseCloudID: refinedCloud.metadata.cloudID,
      sourcePoseCloudID: sourceCloud.metadata.cloudID,
      refinedPointCount: refinedCloud.quality.registeredPointCount,
      sourcePointCount: sourceCloud.quality.registeredPointCount,
      refinementOutcome: "CONVERGED",
      refinedPoseAuthority: "RECONSTRUCTION_ESTIMATE",
      frameEpochID: descriptor.frameEpochID,
      sessionRunID: descriptor.sessionRunID,
      worldOriginRevision: descriptor.worldOriginRevision,
      calibrationID: FixtureDenseFusionPackageBuilder.calibrationID,
      units: "meters",
      handedness: "right"
    )

    var trackSupport: [String: Double] = [:]
    for p in refinedCloud.points where p.validity == .valid {
      trackSupport[p.pointID] = 0.8
    }

    return PreparedInput(
      inventory: inventory,
      refinedCloud: refinedCloud,
      sourceCloud: sourceCloud,
      trackSupport: trackSupport,
      poseRefinementConfidence: 0.95
    )
  }

  private func fixtureInjectedContributions(baseClosure: String, reconClosure: String) -> [FusionPointContribution] {
    func make(
      id: String,
      x: Double, y: Double, z: Double,
      confidence: Double,
      weight: Double
    ) -> FusionPointContribution {
      FusionPointContribution(
        contributionID: "CTR-FIXTURE-\(id)",
        sourceRegisteredPointID: "PT-FIXTURE-\(id)",
        sourceObservationID: "OBS-FIXTURE-\(id)",
        sourceDepthSampleID: "df-depth-fixture",
        sourcePixelU: 0, sourcePixelV: 0,
        sourcePoseID: "df-pose-0",
        refinedPoseID: "REFINED-df-pose-0",
        sourcePackageClosure: baseClosure,
        sourceReconstructionClosure: reconClosure,
        x: x, y: y, z: z,
        confidence: PointConfidence(
          depthConfidence: confidence,
          poseRefinementConfidence: confidence,
          featureTrackSupport: confidence,
          observationAngleWeight: 1,
          declaredConfidence: confidence
        ),
        validity: .valid,
        observationAngleDegrees: 0,
        depthValidity: "VALID",
        fusionVoxelID: nil,
        derivationID: "DER-CTR-\(id)",
        weight: weight,
        rejected: false,
        rejectionReason: nil
      )
    }
    // Isolated outlier far from surface cluster.
    let outlier = make(id: "OUTLIER-000001", x: 1.5, y: 1.5, z: 4.0, confidence: 0.9, weight: 0.7)
    // Explicit multi-view same-surface pair inside one 5mm voxel (committed offsets, no PRNG).
    let dupA = make(id: "DUP-A-000001", x: 0.0, y: 0.0, z: 2.0, confidence: 0.95, weight: 0.95)
    let dupB = make(id: "DUP-B-000001", x: 0.001, y: 0.0, z: 2.0, confidence: 0.90, weight: 0.90)
    // Own nearby voxel so kNN finds neighbors; retained as low-confidence.
    let lowConf = make(id: "LOWCONF-000001", x: 0.012, y: 0.0, z: 2.0, confidence: 0.2, weight: 0.2)
    // Dedicated conflict voxel: same 5mm bin, > voxel*0.75 apart.
    let conflictA = make(id: "CONFLICT-A-000001", x: 1.0, y: 0.0, z: 3.0, confidence: 0.9, weight: 0.9)
    let conflictB = make(id: "CONFLICT-B-000001", x: 1.0, y: 0.0, z: 3.004, confidence: 0.9, weight: 0.9)
    return [outlier, dupA, dupB, lowConf, conflictA, conflictB]
  }

  private func decodeTransform(_ bytes: Data) -> [Double] {
    var matrix: [Double] = []
    let count = min(16, bytes.count / 8)
    for i in 0..<count {
      let o = i * 8
      var bits: UInt64 = 0
      for b in 0..<8 { bits |= UInt64(bytes[o + b]) << (8 * b) }
      matrix.append(Double(bitPattern: bits))
    }
    while matrix.count < 16 { matrix.append(0) }
    return matrix
  }
}
