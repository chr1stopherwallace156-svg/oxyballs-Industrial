import Foundation

// MARK: - Phase 4C surface geometry

public struct FixtureMultiviewSurfaceGeometry: Equatable, Sendable {
  public static let geometryID = "GEOM-FIXTURE-MULTIVIEW-SURFACE-000001"

  public var geometryID: String
  public var landmarks: [[String: Double]]
  public var trueCameraTranslations: [[Double]]
  public var injectedPosePerturbations: [[Double]]
  public var authority: String
  public var expectedOccupiedVoxelCount: Int
  public var expectedConsolidatedPointCountMin: Int
  public var voxelSizeMeters: Double

  public static func multiviewSurface() -> FixtureMultiviewSurfaceGeometry {
    // Planar Z=2 surface samples; 3 cameras along +X. Pose perturbation mirrors Phase 4B fixture style.
    let landmarks: [[String: Double]] = [
      ["landmark_id_hash": 0, "x": -0.02, "y": -0.02, "z": 2.0],
      ["landmark_id_hash": 1, "x": 0.02, "y": -0.02, "z": 2.0],
      ["landmark_id_hash": 2, "x": -0.02, "y": 0.02, "z": 2.0],
      ["landmark_id_hash": 3, "x": 0.02, "y": 0.02, "z": 2.0],
      ["landmark_id_hash": 4, "x": 0.0, "y": 0.0, "z": 2.0],
    ]
    return FixtureMultiviewSurfaceGeometry(
      geometryID: geometryID,
      landmarks: landmarks,
      trueCameraTranslations: [[0, 0, 0], [0.1, 0, 0], [0.2, 0, 0]],
      injectedPosePerturbations: [[0, 0, 0], [0.05, 0, 0], [0.05, 0, 0]],
      authority: "TEST_FIXTURE_GROUND_TRUTH",
      expectedOccupiedVoxelCount: 8,
      expectedConsolidatedPointCountMin: 8,
      voxelSizeMeters: 0.005
    )
  }

  public var landmarkIDs: [String] { (0..<landmarks.count).map { "LM-\($0)" } }

  public func landmarkPosition(_ id: String) -> (Double, Double, Double)? {
    guard let idx = Int(id.replacingOccurrences(of: "LM-", with: "")),
          idx >= 0, idx < landmarks.count,
          let x = landmarks[idx]["x"], let y = landmarks[idx]["y"], let z = landmarks[idx]["z"]
    else { return nil }
    return (x, y, z)
  }

  public func dictionary() -> [String: Any] {
    [
      "geometry_id": geometryID,
      "kind": "MULTIVIEW_PLANAR_SURFACE",
      "landmarks": landmarks,
      "landmark_ids": landmarkIDs,
      "true_camera_translations": trueCameraTranslations,
      "injected_pose_perturbations": injectedPosePerturbations,
      "voxel_size_meters": voxelSizeMeters,
      "expected_occupied_voxel_count": expectedOccupiedVoxelCount,
      "expected_consolidated_point_count_min": expectedConsolidatedPointCountMin,
      "geometry_reference_authority": authority,
      "schema_id": "FixtureMultiviewSurfaceGeometry",
      "schema_version": "1.0.0-phase4c-fixture",
      "note": "Fixture ground truth is not physical metrology or vehicle density proof",
    ]
  }

  /// Bridge for Phase 4B-style projection helpers.
  public func asMultiviewGeometry() -> FixtureMultiviewGeometry {
    FixtureMultiviewGeometry(
      geometryID: FixtureMultiviewGeometry.geometryID,
      landmarks: landmarks,
      trueCameraTranslations: trueCameraTranslations,
      injectedPosePerturbations: injectedPosePerturbations,
      authority: authority
    )
  }
}

// MARK: - Eligibility

public enum DenseFusionEligibilityOutcome: String, Codable, Sendable, Equatable {
  case eligibleRefinedDepthFusion = "ELIGIBLE_REFINED_DEPTH_FUSION"
  case eligibleSourcePoseFusion = "ELIGIBLE_SOURCE_POSE_FUSION"
  case ineligibleRefinementNotConverged = "INELIGIBLE_REFINEMENT_NOT_CONVERGED"
  case ineligibleMissingRegisteredPoints = "INELIGIBLE_MISSING_REGISTERED_POINTS"
  case ineligibleBrokenLineage = "INELIGIBLE_BROKEN_LINEAGE"
  case ineligibleCoordinateMismatch = "INELIGIBLE_COORDINATE_MISMATCH"
  case ineligibleInvalidConfidence = "INELIGIBLE_INVALID_CONFIDENCE"
  case ineligibleInsufficientOverlap = "INELIGIBLE_INSUFFICIENT_OVERLAP"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public enum DenseFusionIneligibilityReason: String, Codable, Sendable, Equatable {
  case refinementNotConverged = "REFINEMENT_NOT_CONVERGED"
  case missingRegisteredPoints = "MISSING_REGISTERED_POINTS"
  case brokenLineage = "BROKEN_LINEAGE"
  case coordinateMismatch = "COORDINATE_MISMATCH"
  case invalidConfidence = "INVALID_CONFIDENCE"
  case insufficientOverlap = "INSUFFICIENT_OVERLAP"
  case unitMismatch = "UNIT_MISMATCH"
  case nonFinitePoint = "NON_FINITE_POINT"
  case duplicatePointID = "DUPLICATE_POINT_ID"
  case invalidVoxelSize = "INVALID_VOXEL_SIZE"
  case closureMismatch = "CLOSURE_MISMATCH"
}

public struct DenseFusionEligibilityPolicy: Codable, Sendable, Equatable {
  public var policyID: String
  public var requireRefinementConverged: Bool
  public var minValidPoints: Int
  public var minFrameOverlap: Int
  public var requireFiniteConfidence: Bool

  public static let fixture = DenseFusionEligibilityPolicy(
    policyID: "DFUSE-ELIG-POL-FIXTURE-000001",
    requireRefinementConverged: true,
    minValidPoints: 8,
    minFrameOverlap: 2,
    requireFiniteConfidence: true
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "require_refinement_converged": requireRefinementConverged,
      "min_valid_points": minValidPoints,
      "min_frame_overlap": minFrameOverlap,
      "require_finite_confidence": requireFiniteConfidence,
      "schema_version": "1.0.0-phase4c-fixture",
    ]
  }
}

public struct DenseFusionEligibilityResult: Codable, Sendable, Equatable {
  public var outcome: DenseFusionEligibilityOutcome
  public var reasons: [DenseFusionIneligibilityReason]
  public var policyID: String
  public var detail: String

  public var isEligible: Bool {
    switch outcome {
    case .eligibleRefinedDepthFusion, .eligibleSourcePoseFusion: return true
    default: return false
    }
  }

  public func dictionary() -> [String: Any] {
    [
      "outcome": outcome.rawValue,
      "reasons": reasons.map(\.rawValue).sorted(),
      "policy_id": policyID,
      "detail": detail,
      "is_eligible": isEligible,
    ]
  }
}

// MARK: - Coordinate + numeric policy

public struct FusionCoordinateConvention: Codable, Sendable, Equatable {
  public var reconstructionRootFrame: String
  public var units: String
  public var handedness: String
  public var upAxis: String
  public var matrixLayout: String
  public var vectorConvention: String

  public static let fixture = FusionCoordinateConvention(
    reconstructionRootFrame: "FRAME_RECONSTRUCTION_ROOT",
    units: "meters",
    handedness: "right",
    upAxis: "+Y",
    matrixLayout: "column_major",
    vectorConvention: "opencv_optical_z_forward"
  )

  public func dictionary() -> [String: Any] {
    [
      "reconstruction_root_frame": reconstructionRootFrame,
      "units": units,
      "handedness": handedness,
      "up_axis": upAxis,
      "matrix_layout": matrixLayout,
      "vector_convention": vectorConvention,
    ]
  }
}

// FusionNumericPolicy lives in DenseFusionMath.swift (abs/rel epsilon law).

public struct FusionConfigurationDigest: Codable, Sendable, Equatable {
  public var configurationID: String
  public var voxelSizeMeters: Double
  public var maxInputPoints: Int
  public var maxVoxelCount: Int
  public var maxEstimatedWorkingSetBytes: Int
  public var maxContributorsPerVoxel: Int
  public var spatialExtentMin: [Double]
  public var spatialExtentMax: [Double]
  public var backendID: String
  public var characterizationStatus: String
  public var digest: String

  /// Fixture default voxel size = 5mm deterministic test rule (not physical metrology).
  public static func fixture(voxelSize: Double = 0.005) -> FusionConfigurationDigest {
    var cfg = FusionConfigurationDigest(
      configurationID: "DFUSE-CFG-FIXTURE-000001",
      voxelSizeMeters: voxelSize,
      maxInputPoints: 10_000,
      maxVoxelCount: 50_000,
      maxEstimatedWorkingSetBytes: 64 * 1024 * 1024,
      maxContributorsPerVoxel: 64,
      spatialExtentMin: [-2, -2, -1],
      spatialExtentMax: [2, 2, 5],
      backendID: "DeterministicVoxelFusionBackend",
      characterizationStatus: "DETERMINISTIC_TEST_FIXTURE",
      digest: ""
    )
    cfg.digest = cfg.computeDigest()
    return cfg
  }

  public func dictionary() -> [String: Any] {
    [
      "configuration_id": configurationID,
      "voxel_size_meters": voxelSizeMeters,
      "fixture_default_voxel_size_meters": 0.005,
      "max_input_points": maxInputPoints,
      "max_voxel_count": maxVoxelCount,
      "max_estimated_working_set_bytes": maxEstimatedWorkingSetBytes,
      "max_contributors_per_voxel": maxContributorsPerVoxel,
      "spatial_extent_min": spatialExtentMin,
      "spatial_extent_max": spatialExtentMax,
      "backend_id": backendID,
      "characterization_status": characterizationStatus,
      "configuration_digest": digest,
    ]
  }

  public func computeDigest() -> String {
    var d = dictionary()
    d["configuration_digest"] = ""
    let body = (try? CanonicalJSON.data(d)) ?? Data()
    return ContentHasher.sha256Hex(body)
  }
}

// MARK: - Input inventory

public struct DenseFusionInputInventory: Equatable, Sendable {
  public var sourcePackageID: String
  public var sourcePackageClosureSHA256: String
  public var phase4AClosureSHA256: String?
  public var phase4BClosureSHA256: String
  public var refinedPoseCloudID: String
  public var sourcePoseCloudID: String
  public var refinedPointCount: Int
  public var sourcePointCount: Int
  public var refinementOutcome: String
  public var refinedPoseAuthority: String
  public var frameEpochID: String
  public var sessionRunID: String
  public var worldOriginRevision: UInt64
  public var calibrationID: String
  public var units: String
  public var handedness: String

  public func dictionary() -> [String: Any] {
    var d: [String: Any] = [
      "source_package_id": sourcePackageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "phase4b_closure_sha256": phase4BClosureSHA256,
      "refined_pose_cloud_id": refinedPoseCloudID,
      "source_pose_cloud_id": sourcePoseCloudID,
      "refined_point_count": refinedPointCount,
      "source_point_count": sourcePointCount,
      "refinement_outcome": refinementOutcome,
      "refined_pose_authority": refinedPoseAuthority,
      "frame_epoch_id": frameEpochID,
      "session_run_id": sessionRunID,
      "world_origin_revision": worldOriginRevision,
      "calibration_id": calibrationID,
      "units": units,
      "handedness": handedness,
      "schema_id": "DenseFusionInputInventory",
      "schema_version": "1.0.0-phase4c-fixture",
    ]
    if let phase4AClosureSHA256 { d["phase4a_closure_sha256"] = phase4AClosureSHA256 }
    return d
  }
}

public struct DenseFusionInput: Equatable, Sendable {
  public var inventory: DenseFusionInputInventory
  public var refinedCloud: RegisteredPointCloud
  public var sourceCloud: RegisteredPointCloud
  public var featureTrackSupportByPointID: [String: Double]
  public var poseRefinementConfidence: Double
  public var coordinate: FusionCoordinateConvention
  public var numeric: FusionNumericPolicy
  public var configuration: FusionConfigurationDigest
  public var eligibility: DenseFusionEligibilityResult

  public func dictionary() -> [String: Any] {
    [
      "inventory": inventory.dictionary(),
      "eligibility": eligibility.dictionary(),
      "coordinate_convention": coordinate.dictionary(),
      "numeric_policy": numeric.dictionary(),
      "configuration": configuration.dictionary(),
      "feature_track_support_by_point_id": featureTrackSupportByPointID.keys.sorted().reduce(into: [String: Double]()) {
        $0[$1] = featureTrackSupportByPointID[$1] ?? 0
      },
      "pose_refinement_confidence": poseRefinementConfidence,
      "refined_cloud_metadata": refinedCloud.metadata.dictionary(),
      "source_cloud_metadata": sourceCloud.metadata.dictionary(),
    ]
  }
}

public struct DenseFusionInputValidator: Sendable {
  public var policy: DenseFusionEligibilityPolicy

  public init(policy: DenseFusionEligibilityPolicy = .fixture) {
    self.policy = policy
  }

  public func validate(
    inventory: DenseFusionInputInventory,
    refinedCloud: RegisteredPointCloud,
    sourceCloud: RegisteredPointCloud,
    coordinate: FusionCoordinateConvention,
    configuration: FusionConfigurationDigest,
    preferRefined: Bool
  ) -> DenseFusionEligibilityResult {
    var reasons: [DenseFusionIneligibilityReason] = []
    var detailParts: [String] = []

    if configuration.voxelSizeMeters <= 0 {
      reasons.append(.invalidVoxelSize)
      detailParts.append("voxel_size<=0")
    }

    if preferRefined {
      if inventory.refinementOutcome != "CONVERGED" && inventory.refinementOutcome != "NO_REFINEMENT_REQUIRED" {
        reasons.append(.refinementNotConverged)
        detailParts.append("refinement=\(inventory.refinementOutcome)")
      }
      if inventory.refinedPoseAuthority != "RECONSTRUCTION_ESTIMATE" {
        reasons.append(.brokenLineage)
        detailParts.append("refined_authority")
      }
    }

    let cloud = preferRefined ? refinedCloud : sourceCloud
    let valid = cloud.points.filter { $0.validity == .valid }
    if valid.count < policy.minValidPoints {
      reasons.append(.missingRegisteredPoints)
      detailParts.append("valid_points=\(valid.count)")
    }

    if cloud.metadata.units != coordinate.units || inventory.units != coordinate.units {
      reasons.append(.unitMismatch)
    }
    if cloud.metadata.handedness != coordinate.handedness || inventory.handedness != coordinate.handedness {
      reasons.append(.coordinateMismatch)
    }

    var seen = Set<String>()
    for p in cloud.points {
      if seen.contains(p.pointID) {
        reasons.append(.duplicatePointID)
        detailParts.append(p.pointID)
        break
      }
      seen.insert(p.pointID)
      if p.validity == .valid {
        if !p.x.isFinite || !p.y.isFinite || !p.z.isFinite {
          reasons.append(.nonFinitePoint)
          detailParts.append(p.pointID)
        }
        if let c = p.confidence, (!c.isFinite || c < 0) {
          reasons.append(.invalidConfidence)
          detailParts.append(p.pointID)
        }
      }
      if p.source.sourcePackageClosureSHA256.isEmpty {
        reasons.append(.brokenLineage)
        detailParts.append("empty_source_closure")
      }
    }

    let frames = Set(valid.map(\.sourceFrameID))
    if frames.count < policy.minFrameOverlap {
      reasons.append(.insufficientOverlap)
      detailParts.append("frames=\(frames.count)")
    }

    if inventory.sourcePackageClosureSHA256.isEmpty || inventory.phase4BClosureSHA256.isEmpty {
      reasons.append(.brokenLineage)
    }

    if !reasons.isEmpty {
      let outcome: DenseFusionEligibilityOutcome
      if reasons.contains(.refinementNotConverged) {
        outcome = .ineligibleRefinementNotConverged
      } else if reasons.contains(.missingRegisteredPoints) {
        outcome = .ineligibleMissingRegisteredPoints
      } else if reasons.contains(.brokenLineage) || reasons.contains(.closureMismatch) {
        outcome = .ineligibleBrokenLineage
      } else if reasons.contains(.coordinateMismatch) || reasons.contains(.unitMismatch) {
        outcome = .ineligibleCoordinateMismatch
      } else if reasons.contains(.invalidConfidence) {
        outcome = .ineligibleInvalidConfidence
      } else if reasons.contains(.insufficientOverlap) {
        outcome = .ineligibleInsufficientOverlap
      } else {
        outcome = .manualReviewRequired
      }
      return DenseFusionEligibilityResult(
        outcome: outcome,
        reasons: Array(Set(reasons)).sorted { $0.rawValue < $1.rawValue },
        policyID: policy.policyID,
        detail: detailParts.joined(separator: ",")
      )
    }

    return DenseFusionEligibilityResult(
      outcome: preferRefined ? .eligibleRefinedDepthFusion : .eligibleSourcePoseFusion,
      reasons: [],
      policyID: policy.policyID,
      detail: "ok"
    )
  }
}
