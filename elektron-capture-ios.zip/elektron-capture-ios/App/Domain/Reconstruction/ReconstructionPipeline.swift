import Foundation

/// Reads sealed Spatial Evidence Package sidecars for reconstruction ingestion.
public struct SpatialPackageReader: Sendable {
  public init() {}

  public func readManifestDict(packageRoot: URL) throws -> [String: Any] {
    let url = packageRoot.appendingPathComponent("manifest.json")
    guard FileManager.default.fileExists(atPath: url.path) else {
      throw ReconstructionError.invalidPackage("missing_manifest")
    }
    let data = try Data(contentsOf: url)
    guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
      throw ReconstructionError.invalidPackage("manifest_not_object")
    }
    return obj
  }

  public func readJSONObject(packageRoot: URL, name: String) throws -> [String: Any] {
    let url = packageRoot.appendingPathComponent(name)
    guard FileManager.default.fileExists(atPath: url.path) else {
      throw ReconstructionError.invalidPackage("missing_\(name)")
    }
    let data = try Data(contentsOf: url)
    guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
      throw ReconstructionError.invalidPackage("invalid_\(name)")
    }
    return obj
  }

  public func optionalJSONObject(packageRoot: URL, name: String) throws -> [String: Any]? {
    let url = packageRoot.appendingPathComponent(name)
    guard FileManager.default.fileExists(atPath: url.path) else { return nil }
    let data = try Data(contentsOf: url)
    return try JSONSerialization.jsonObject(with: data) as? [String: Any]
  }
}

public struct ReconstructionPackageIngestResult: Sendable {
  public var eligibility: ReconstructionEligibilityResult
  public var descriptor: ReconstructionInputDescriptor?
  public var inventory: ReconstructionInputInventory?
  public var failures: [ReconstructionIngestFailure]
  public var packageRoot: URL
  public var geometry: FixtureReconstructionGeometry?
  public var sourcePackageBytesSHA256: String
  public var depthToCameraMatrix: [Double]
  public var calibrations: [[String: Any]]
  public var rgbDepthAssociations: [[String: Any]]
  public var poseAssociations: [[String: Any]]
  public var sampleIndex: [[String: Any]]
  public var artifacts: [[String: Any]]
  public var correlations: [[String: Any]]
}

/// Fail-closed reconstruction package ingestion and eligibility.
public struct ReconstructionPackageIngestor: Sendable {
  public var policy: ReconstructionEligibilityPolicy
  public var reader: SpatialPackageReader

  public init(policy: ReconstructionEligibilityPolicy = .fixture, reader: SpatialPackageReader = SpatialPackageReader()) {
    self.policy = policy
    self.reader = reader
  }

  public func ingest(packageRoot: URL) throws -> ReconstructionPackageIngestResult {
    var failures: [ReconstructionIngestFailure] = []

    // Closure + inventory
    let inventoryURL = packageRoot.appendingPathComponent("package_inventory.json")
    guard FileManager.default.fileExists(atPath: inventoryURL.path) else {
      return ineligible(packageRoot: packageRoot, outcome: .ineligibleInvalidPackage, reasons: ["missing_package_inventory"], failures: [
        ReconstructionIngestFailure(code: "MISSING_INVENTORY", detail: "package_inventory.json"),
      ])
    }

    do {
      let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: packageRoot)
      try SpatialPackageClosureVerifier.verifyInventoryCompleteness(packageRoot: packageRoot, entries: entries)
      let invObj = try reader.readJSONObject(packageRoot: packageRoot, name: "package_inventory.json")
      guard let expected = invObj["fixture_package_closure_sha256"] as? String else {
        throw ReconstructionError.invalidPackage("missing_closure_digest")
      }
      let actual = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
      if actual != expected {
        return ineligible(packageRoot: packageRoot, outcome: .ineligibleInvalidPackage, reasons: ["package_closure_mismatch"], failures: [
          ReconstructionIngestFailure(code: "INVALID_PACKAGE_CLOSURE", detail: "expected=\(expected) actual=\(actual)"),
        ])
      }
    } catch {
      return ineligible(packageRoot: packageRoot, outcome: .ineligibleInvalidPackage, reasons: ["package_closure_verification_failed"], failures: [
        ReconstructionIngestFailure(code: "INVALID_PACKAGE_CLOSURE", detail: String(describing: error)),
      ])
    }

    let manifest: [String: Any]
    do {
      manifest = try reader.readManifestDict(packageRoot: packageRoot)
    } catch {
      return ineligible(packageRoot: packageRoot, outcome: .ineligibleInvalidPackage, reasons: ["missing_or_invalid_manifest"], failures: [
        ReconstructionIngestFailure(code: "MISSING_MANIFEST", detail: String(describing: error)),
      ])
    }

    let packageID = manifest["package_id"] as? String ?? ""
    let sessionID = manifest["capture_session_id"] as? String ?? ""
    let frameEpoch = manifest["frame_epoch_id"] as? String ?? ""
    let sessionRun = manifest["session_run_id"] as? String ?? ""
    let worldRev = (manifest["world_origin_revision"] as? UInt64)
      ?? UInt64(manifest["world_origin_revision"] as? Int ?? 0)
    let evidenceAuth = manifest["evidence_origin_authority"] as? String ?? "UNKNOWN"
    let geometryAuth = manifest["geometry_reference_authority"] as? String ?? "TEST_FIXTURE_GROUND_TRUTH"

    // Privacy
    if let privacy = try reader.optionalJSONObject(packageRoot: packageRoot, name: "privacy_policy.json") {
      let restrictions = privacy["export_restrictions"] as? [String] ?? []
      if restrictions.contains("NO_RECONSTRUCTION_INPUT") {
        return ineligible(packageRoot: packageRoot, outcome: .ineligiblePrivacyPolicy, reasons: ["privacy_forbids_reconstruction_input"], failures: [
          ReconstructionIngestFailure(code: "INELIGIBLE_PRIVACY_POLICY", detail: "NO_RECONSTRUCTION_INPUT"),
        ])
      }
      if let allowed = manifest["reconstruction_input_allowed"] as? Bool, allowed == false {
        return ineligible(packageRoot: packageRoot, outcome: .ineligiblePrivacyPolicy, reasons: ["manifest_reconstruction_input_forbidden"], failures: [
          ReconstructionIngestFailure(code: "INELIGIBLE_PRIVACY_POLICY", detail: "reconstruction_input_allowed=false"),
        ])
      }
    }

    // Signature / enrollment when present
    if let sig = try reader.optionalJSONObject(packageRoot: packageRoot, name: "package_signature.json") {
      if (sig["verification_state"] as? String) == "FAILED" {
        failures.append(ReconstructionIngestFailure(code: "SIGNATURE_FAILED", detail: "package_signature.json"))
        return ineligible(packageRoot: packageRoot, outcome: .manualReviewRequired, reasons: ["signature_verification_failed"], failures: failures)
      }
    }
    if let journal = try reader.optionalJSONObject(packageRoot: packageRoot, name: "journal_root_binding.json") {
      if journal["journal_root_sha256"] == nil {
        failures.append(ReconstructionIngestFailure(code: "JOURNAL_ROOT_MISSING", detail: "journal_root_binding.json"))
        return ineligible(packageRoot: packageRoot, outcome: .manualReviewRequired, reasons: ["journal_root_missing"], failures: failures)
      }
    }

    let sampleIndexObj = try reader.readJSONObject(packageRoot: packageRoot, name: "sample_index.json")
    let samples = sampleIndexObj["samples"] as? [[String: Any]] ?? []
    let cameraIDs = samples.filter { ($0["stream_id"] as? String) == SpatialStreamID.camera }.compactMap { $0["sample_id"] as? String }
    let depthIDs = samples.filter { ($0["stream_id"] as? String) == SpatialStreamID.depth }.compactMap { $0["sample_id"] as? String }
    let poseIDs = samples.filter { ($0["stream_id"] as? String) == SpatialStreamID.pose }.compactMap { $0["sample_id"] as? String }

    // Artifact availability
    let artifacts = (manifest["artifacts"] as? [[String: Any]]) ?? []
    for art in artifacts {
      guard let rel = art["relative_path"] as? String, let expectedSHA = art["sha256"] as? String else { continue }
      let url = packageRoot.appendingPathComponent(rel)
      guard FileManager.default.fileExists(atPath: url.path) else {
        let stream = art["stream_id"] as? String ?? ""
        let code = stream == SpatialStreamID.camera ? "MISSING_CAMERA_ARTIFACT"
          : stream == SpatialStreamID.depth ? "MISSING_DEPTH_ARTIFACT"
          : "MISSING_ARTIFACT"
        return ineligible(packageRoot: packageRoot, outcome: .ineligibleInvalidPackage, reasons: [code.lowercased()], failures: [
          ReconstructionIngestFailure(code: code, detail: rel),
        ])
      }
      let actual = ContentHasher.sha256Hex(try Data(contentsOf: url))
      if actual != expectedSHA {
        return ineligible(packageRoot: packageRoot, outcome: .ineligibleInvalidPackage, reasons: ["source_artifact_mutation"], failures: [
          ReconstructionIngestFailure(code: "SOURCE_ARTIFACT_MUTATION", detail: rel),
        ])
      }
    }

    // Calibration
    let calObj = try? reader.readJSONObject(packageRoot: packageRoot, name: "depth_calibration.json")
    let calibrations = calObj?["calibrations"] as? [[String: Any]] ?? []
    if policy.requireCalibration && calibrations.isEmpty {
      return ineligible(packageRoot: packageRoot, outcome: .ineligibleMissingCalibration, reasons: ["missing_calibration"], failures: [
        ReconstructionIngestFailure(code: "MISSING_CALIBRATION", detail: "depth_calibration.json"),
      ])
    }
    for cal in calibrations {
      let fx = cal["focal_length_x"] as? Double ?? 0
      let fy = cal["focal_length_y"] as? Double ?? 0
      if !(fx.isFinite && fy.isFinite && fx > 0 && fy > 0) {
        return ineligible(packageRoot: packageRoot, outcome: .ineligibleMissingCalibration, reasons: ["invalid_calibration"], failures: [
          ReconstructionIngestFailure(code: "INVALID_CALIBRATION", detail: cal["calibration_id"] as? String ?? "?"),
        ])
      }
    }

    // Associations
    let rgbDepth = (try? reader.readJSONObject(packageRoot: packageRoot, name: "rgb_depth_associations.json"))?["associations"] as? [[String: Any]] ?? []
    let poseAssoc = (try? reader.readJSONObject(packageRoot: packageRoot, name: "pose_associations.json"))?["associations"] as? [[String: Any]] ?? []
    if policy.requireCameraDepthAssociation && rgbDepth.isEmpty && !depthIDs.isEmpty {
      return ineligible(packageRoot: packageRoot, outcome: .ineligibleBrokenAssociation, reasons: ["broken_camera_depth_association"], failures: [
        ReconstructionIngestFailure(code: "BROKEN_CAMERA_DEPTH_ASSOCIATION", detail: "empty"),
      ])
    }
    if policy.requireCameraPoseAssociation && poseAssoc.isEmpty && !poseIDs.isEmpty {
      return ineligible(packageRoot: packageRoot, outcome: .ineligibleBrokenAssociation, reasons: ["broken_camera_pose_association"], failures: [
        ReconstructionIngestFailure(code: "BROKEN_CAMERA_POSE_ASSOCIATION", detail: "empty"),
      ])
    }
    for a in rgbDepth {
      let cam = a["camera_sample_id"] as? String ?? ""
      let dep = a["depth_sample_id"] as? String ?? ""
      if !cameraIDs.contains(cam) || !depthIDs.contains(dep) {
        return ineligible(packageRoot: packageRoot, outcome: .ineligibleBrokenAssociation, reasons: ["broken_camera_depth_association"], failures: [
          ReconstructionIngestFailure(code: "BROKEN_CAMERA_DEPTH_ASSOCIATION", detail: "\(cam)->\(dep)"),
        ])
      }
    }
    for a in poseAssoc {
      let cam = a["camera_sample_id"] as? String ?? ""
      let pose = a["pose_sample_id"] as? String ?? ""
      if !cameraIDs.contains(cam) || !poseIDs.contains(pose) {
        return ineligible(packageRoot: packageRoot, outcome: .ineligibleBrokenAssociation, reasons: ["broken_camera_pose_association"], failures: [
          ReconstructionIngestFailure(code: "BROKEN_CAMERA_POSE_ASSOCIATION", detail: "\(cam)->\(pose)"),
        ])
      }
    }

    // Clocks / frames / transforms
    let clockObj = try? reader.readJSONObject(packageRoot: packageRoot, name: "clock_correlation.json")
    let correlations = clockObj?["correlations"] as? [[String: Any]] ?? []
    if policy.requireClockCorrelation && correlations.isEmpty {
      return ineligible(packageRoot: packageRoot, outcome: .ineligibleBrokenAssociation, reasons: ["missing_clock_correlation"], failures: [
        ReconstructionIngestFailure(code: "MISSING_CLOCK_CORRELATION", detail: "clock_correlation.json"),
      ])
    }
    for c in correlations {
      let until = c["valid_until_nanoseconds"] as? UInt64
        ?? UInt64(c["valid_until_nanoseconds"] as? Int ?? 0)
      let from = c["valid_from_nanoseconds"] as? UInt64
        ?? UInt64(c["valid_from_nanoseconds"] as? Int ?? 0)
      if until < from {
        return ineligible(packageRoot: packageRoot, outcome: .ineligibleBrokenAssociation, reasons: ["stale_clock_correlation"], failures: [
          ReconstructionIngestFailure(code: "STALE_CLOCK_CORRELATION", detail: c["correlation_id"] as? String ?? "?"),
        ])
      }
    }

    _ = try reader.readJSONObject(packageRoot: packageRoot, name: "coordinate_frames.json")
    let tg = try reader.readJSONObject(packageRoot: packageRoot, name: "transform_graph.json")
    let edges = tg["edges"] as? [[String: Any]] ?? []
    if edges.isEmpty {
      return ineligible(packageRoot: packageRoot, outcome: .ineligibleBrokenAssociation, reasons: ["missing_transform_path"], failures: [
        ReconstructionIngestFailure(code: "MISSING_TRANSFORM_PATH", detail: "empty_edges"),
      ])
    }
    var seenTF = Set<String>()
    for e in edges {
      let id = e["transform_id"] as? String ?? ""
      if !seenTF.insert(id).inserted {
        return ineligible(packageRoot: packageRoot, outcome: .ineligibleBrokenAssociation, reasons: ["ambiguous_transform_path"], failures: [
          ReconstructionIngestFailure(code: "AMBIGUOUS_TRANSFORM_PATH", detail: id),
        ])
      }
    }

    // Observation counts
    if cameraIDs.count < policy.minCameraSamples
      || depthIDs.count < policy.minDepthSamples
      || poseIDs.count < policy.minPoseSamples
    {
      return ineligible(packageRoot: packageRoot, outcome: .ineligibleInsufficientObservations, reasons: ["insufficient_observations"], failures: [
        ReconstructionIngestFailure(
          code: "INSUFFICIENT_OBSERVATIONS",
          detail: "cam=\(cameraIDs.count) depth=\(depthIDs.count) pose=\(poseIDs.count)"
        ),
      ])
    }

    let hasCam = !cameraIDs.isEmpty
    let hasDepth = !depthIDs.isEmpty
    let hasPose = !poseIDs.isEmpty
    let outcome: ReconstructionEligibilityOutcome
    if hasCam && hasDepth && hasPose {
      outcome = .eligibleCameraDepthPose
    } else if hasCam && hasPose && !hasDepth {
      outcome = .eligibleCameraPose
    } else if hasDepth && hasPose && !hasCam {
      outcome = .eligibleDepthPose
    } else if hasCam && !hasDepth && !hasPose {
      outcome = .eligibleCameraOnlyExperimental
    } else {
      outcome = .manualReviewRequired
    }

    let invObj = try reader.readJSONObject(packageRoot: packageRoot, name: "package_inventory.json")
    let closure = invObj["fixture_package_closure_sha256"] as? String ?? ""
    let manifestData = try Data(contentsOf: packageRoot.appendingPathComponent("manifest.json"))
    let manifestSHA = ContentHasher.sha256Hex(manifestData)
    let bytesSHA = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: packageRoot)

    var geometry: FixtureReconstructionGeometry?
    if let g = try reader.optionalJSONObject(packageRoot: packageRoot, name: "fixture_geometry.json") {
      geometry = FixtureReconstructionGeometry.planarTarget()
      _ = g
    }

    let depthEdge = edges.first { ($0["transform_id"] as? String) == FixtureReconstructionPackageBuilder.depthToCameraTransformID }
    let depthToCamera = (depthEdge?["matrix"] as? [Double]) ?? HomogeneousMatrix4x4.identity()

    let journalRoot = (try? reader.optionalJSONObject(packageRoot: packageRoot, name: "journal_root_binding.json"))?["journal_root_sha256"] as? String

    let descriptor = ReconstructionInputDescriptor(
      packageID: packageID,
      captureSessionID: sessionID,
      packageClosureSHA256: closure,
      manifestSHA256: manifestSHA,
      journalRootSHA256: journalRoot,
      frameEpochID: frameEpoch,
      sessionRunID: sessionRun,
      worldOriginRevision: worldRev,
      evidenceOriginAuthority: evidenceAuth,
      geometryReferenceAuthority: geometryAuth
    )
    let inventory = ReconstructionInputInventory(
      cameraSampleIDs: cameraIDs,
      depthSampleIDs: depthIDs,
      poseSampleIDs: poseIDs,
      calibrationIDs: calibrations.compactMap { $0["calibration_id"] as? String },
      associationIDs: (rgbDepth + poseAssoc).compactMap { $0["association_id"] as? String },
      artifactRelativePaths: artifacts.compactMap { $0["relative_path"] as? String }
    )

    return ReconstructionPackageIngestResult(
      eligibility: ReconstructionEligibilityResult(outcome: outcome, reasons: ["ok"], policyID: policy.policyID),
      descriptor: descriptor,
      inventory: inventory,
      failures: failures,
      packageRoot: packageRoot,
      geometry: geometry,
      sourcePackageBytesSHA256: bytesSHA,
      depthToCameraMatrix: depthToCamera,
      calibrations: calibrations,
      rgbDepthAssociations: rgbDepth,
      poseAssociations: poseAssoc,
      sampleIndex: samples,
      artifacts: artifacts,
      correlations: correlations
    )
  }

  private func ineligible(
    packageRoot: URL,
    outcome: ReconstructionEligibilityOutcome,
    reasons: [String],
    failures: [ReconstructionIngestFailure]
  ) -> ReconstructionPackageIngestResult {
    ReconstructionPackageIngestResult(
      eligibility: ReconstructionEligibilityResult(outcome: outcome, reasons: reasons, policyID: policy.policyID),
      descriptor: nil,
      inventory: nil,
      failures: failures,
      packageRoot: packageRoot,
      geometry: nil,
      sourcePackageBytesSHA256: "",
      depthToCameraMatrix: HomogeneousMatrix4x4.identity(),
      calibrations: [],
      rgbDepthAssociations: [],
      poseAssociations: [],
      sampleIndex: [],
      artifacts: [],
      correlations: []
    )
  }
}

// MARK: - Observation normalization

public struct ObservationNormalizer: Sendable {
  public init() {}

  public func normalize(ingest: ReconstructionPackageIngestResult) throws -> ObservationNormalizationResult {
    guard ingest.eligibility.isEligible, let descriptor = ingest.descriptor else {
      throw ReconstructionError.ineligible(ingest.eligibility.outcome.rawValue)
    }
    var rejections: [ObservationRejectionRecord] = []
    var cameras: [NormalizedCameraObservation] = []
    var depths: [NormalizedDepthObservation] = []
    var poses: [NormalizedPoseObservation] = []
    var seenIDs = Set<String>()

    let artBySample = Dictionary(uniqueKeysWithValues: ingest.artifacts.compactMap { a -> (String, [String: Any])? in
      guard let sid = a["sample_id"] as? String else { return nil }
      return (sid, a)
    })

    let calID = ingest.calibrations.first?["calibration_id"] as? String ?? ""

    for s in ingest.sampleIndex where (s["stream_id"] as? String) == SpatialStreamID.camera {
      let sid = s["sample_id"] as? String ?? ""
      if !seenIDs.insert("cam:\(sid)").inserted {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "duplicated_observation_id"))
        continue
      }
      guard let art = artBySample[sid],
            let rel = art["relative_path"] as? String,
            let sha = art["sha256"] as? String
      else {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "unresolved_source_artifact"))
        continue
      }
      if calID.isEmpty {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "missing_calibration"))
        continue
      }
      let ts = s["acquisition_timestamp_ns"] as? UInt64 ?? UInt64(s["acquisition_timestamp_ns"] as? Int ?? 0)
      cameras.append(
        NormalizedCameraObservation(
          observationID: "OBS-CAM-\(sid)",
          sampleID: sid,
          artifactID: rel,
          artifactSHA256: sha,
          timestampNanoseconds: ts,
          clockDomain: s["clock_domain"] as? String ?? "",
          calibrationID: calID,
          frameEpochID: descriptor.frameEpochID,
          sessionRunID: descriptor.sessionRunID,
          worldOriginRevision: descriptor.worldOriginRevision,
          blurScore: 0.9,
          exposureScore: 0.9
        )
      )
    }

    for s in ingest.sampleIndex where (s["stream_id"] as? String) == SpatialStreamID.depth {
      let sid = s["sample_id"] as? String ?? ""
      if !seenIDs.insert("depth:\(sid)").inserted {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "duplicated_observation_id"))
        continue
      }
      guard let art = artBySample[sid],
            let rel = art["relative_path"] as? String,
            let sha = art["sha256"] as? String
      else {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "unresolved_source_artifact"))
        continue
      }
      let url = ingest.packageRoot.appendingPathComponent(rel)
      let bytes = try Data(contentsOf: url)
      // non-finite / format check
      let expected = ReconstructionFixtureDepthPayload.width * ReconstructionFixtureDepthPayload.height * 4
      if bytes.count != expected {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "unsupported_depth_format"))
        continue
      }
      var invalidCount = 0
      var total = ReconstructionFixtureDepthPayload.width * ReconstructionFixtureDepthPayload.height
      for i in 0..<total {
        let o = i * 4
        let bits = UInt32(bytes[o]) | (UInt32(bytes[o + 1]) << 8) | (UInt32(bytes[o + 2]) << 16) | (UInt32(bytes[o + 3]) << 24)
        let f = Float(bitPattern: bits)
        if !f.isFinite { invalidCount += 1 }
      }
      if invalidCount == total {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "non_finite_depth"))
        continue
      }
      let ts = s["acquisition_timestamp_ns"] as? UInt64 ?? UInt64(s["acquisition_timestamp_ns"] as? Int ?? 0)
      let validPct = Double(total - 1) / Double(total) * 100.0 // one sentinel expected
      depths.append(
        NormalizedDepthObservation(
          observationID: "OBS-DEPTH-\(sid)",
          sampleID: sid,
          artifactID: rel,
          artifactSHA256: sha,
          timestampNanoseconds: ts,
          clockDomain: s["clock_domain"] as? String ?? "",
          calibrationID: calID,
          width: ReconstructionFixtureDepthPayload.width,
          height: ReconstructionFixtureDepthPayload.height,
          pixelFormat: "FLOAT32_METERS",
          depthBytes: bytes,
          frameEpochID: descriptor.frameEpochID,
          sessionRunID: descriptor.sessionRunID,
          worldOriginRevision: descriptor.worldOriginRevision,
          depthValidityPercent: validPct
        )
      )
    }

    for s in ingest.sampleIndex where (s["stream_id"] as? String) == SpatialStreamID.pose {
      let sid = s["sample_id"] as? String ?? ""
      if !seenIDs.insert("pose:\(sid)").inserted {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "duplicated_observation_id"))
        continue
      }
      guard let art = artBySample[sid], let rel = art["relative_path"] as? String else {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "unresolved_source_artifact"))
        continue
      }
      let url = ingest.packageRoot.appendingPathComponent(rel)
      let bytes = try Data(contentsOf: url)
      guard bytes.count >= 16 * 8 else {
        rejections.append(ObservationRejectionRecord(observationID: sid, reason: "broken_frame_path"))
        continue
      }
      var matrix: [Double] = []
      for i in 0..<16 {
        let o = i * 8
        var bits: UInt64 = 0
        for b in 0..<8 { bits |= UInt64(bytes[o + b]) << (8 * b) }
        let v = Double(bitPattern: bits)
        if !v.isFinite {
          rejections.append(ObservationRejectionRecord(observationID: sid, reason: "non_finite_values"))
          matrix.removeAll()
          break
        }
        matrix.append(v)
      }
      if matrix.count != 16 { continue }
      let ts = s["acquisition_timestamp_ns"] as? UInt64 ?? UInt64(s["acquisition_timestamp_ns"] as? Int ?? 0)
      poses.append(
        NormalizedPoseObservation(
          observationID: "OBS-POSE-\(sid)",
          sampleID: sid,
          timestampNanoseconds: ts,
          clockDomain: s["clock_domain"] as? String ?? "",
          translation: [matrix[12], matrix[13], matrix[14]],
          transform4x4: matrix,
          trackingState: "NORMAL",
          frameEpochID: descriptor.frameEpochID,
          sessionRunID: descriptor.sessionRunID,
          worldOriginRevision: descriptor.worldOriginRevision
        )
      )
    }

    // Cross-epoch / cross-session rejection
    for c in cameras where c.frameEpochID != descriptor.frameEpochID || c.sessionRunID != descriptor.sessionRunID {
      rejections.append(ObservationRejectionRecord(observationID: c.observationID, reason: "cross_epoch_or_session_join"))
    }
    cameras.removeAll { $0.frameEpochID != descriptor.frameEpochID || $0.sessionRunID != descriptor.sessionRunID }

    var associations: [ObservationAssociationSet] = []
    for (i, a) in ingest.rgbDepthAssociations.enumerated() {
      let camSID = a["camera_sample_id"] as? String ?? ""
      let depthSID = a["depth_sample_id"] as? String ?? ""
      let poseSID = ingest.poseAssociations.first { ($0["camera_sample_id"] as? String) == camSID }?["pose_sample_id"] as? String ?? ""
      guard let cam = cameras.first(where: { $0.sampleID == camSID }),
            let depth = depths.first(where: { $0.sampleID == depthSID }),
            let pose = poses.first(where: { $0.sampleID == poseSID })
      else {
        rejections.append(ObservationRejectionRecord(observationID: a["association_id"] as? String ?? "assoc-\(i)", reason: "broken_association"))
        continue
      }
      if cam.frameEpochID != depth.frameEpochID || cam.frameEpochID != pose.frameEpochID {
        rejections.append(ObservationRejectionRecord(observationID: cam.observationID, reason: "cross_epoch_joins"))
        continue
      }
      if cam.sessionRunID != depth.sessionRunID || cam.sessionRunID != pose.sessionRunID {
        rejections.append(ObservationRejectionRecord(observationID: cam.observationID, reason: "cross_session_joins"))
        continue
      }
      associations.append(
        ObservationAssociationSet(
          associationID: a["association_id"] as? String ?? "assoc-\(i)",
          cameraObservationID: cam.observationID,
          depthObservationID: depth.observationID,
          poseObservationID: pose.observationID,
          clockCorrelationID: a["correlation_id"] as? String ?? "",
          frameEpochID: cam.frameEpochID,
          sessionRunID: cam.sessionRunID
        )
      )
    }

    return ObservationNormalizationResult(
      cameras: cameras.sorted { $0.observationID < $1.observationID },
      depths: depths.sorted { $0.observationID < $1.observationID },
      poses: poses.sorted { $0.observationID < $1.observationID },
      associations: associations.sorted { $0.associationID < $1.associationID },
      rejections: rejections
    )
  }
}

// MARK: - End-to-end pipeline

public struct ReconstructionPipelineResult: Sendable {
  public var reconstructionOutputID: String
  public var eligibility: ReconstructionEligibilityResult
  public var normalized: ObservationNormalizationResult?
  public var frames: SelectedFrameSet?
  public var registration: RegistrationResult?
  public var pointCloud: RegisteredPointCloud?
  public var quality: ReconstructionQualityRecord?
  public var surface: SurfaceGenerationResult?
  public var lineage: SpatialLineageManifest?
  public var inventory: ReconstructionOutputInventory?
  public var outputClosureSHA256: String
  public var outputRoot: URL
  public var sourcePackageUnchanged: Bool
  public var sourcePackageClosureSHA256: String
  public var pointCloudSHA256: String
  public var lineageManifestSHA256: String
  public var inventorySHA256: String
}

public struct ReconstructionPipeline: Sendable {
  public init() {}

  public func run(packageRoot: URL, outputRoot: URL) throws -> ReconstructionPipelineResult {
    let sourceBefore = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: packageRoot)
    let ingest = try ReconstructionPackageIngestor().ingest(packageRoot: packageRoot)
    guard ingest.eligibility.isEligible, let descriptor = ingest.descriptor else {
      throw ReconstructionError.ineligible(ingest.eligibility.outcome.rawValue)
    }

    let normalized = try ObservationNormalizer().normalize(ingest: ingest)
    let candidates: [ReconstructionFrameCandidate] = normalized.associations.map { a in
      ReconstructionFrameCandidate(
        candidateID: "CAND-\(a.associationID)",
        associationID: a.associationID,
        cameraObservationID: a.cameraObservationID,
        depthObservationID: a.depthObservationID,
        poseObservationID: a.poseObservationID,
        metrics: [
          FrameSelectionMetric(name: "blur_score", value: 0.9),
          FrameSelectionMetric(name: "exposure_score", value: 0.9),
          FrameSelectionMetric(name: "depth_validity_percent", value: 93.75),
        ]
      )
    }
    let frames = try KeyframeSelector().select(
      candidates: candidates,
      cameras: normalized.cameras,
      depths: normalized.depths,
      poses: normalized.poses
    )
    if frames.selectedCandidateIDs.isEmpty {
      throw ReconstructionError.frameSelectionFailed("all_frames_rejected")
    }

    let depthByID = Dictionary(uniqueKeysWithValues: normalized.depths.map { ($0.observationID, $0) })
    let poseByID = Dictionary(uniqueKeysWithValues: normalized.poses.map { ($0.observationID, $0) })
    let cal = ingest.calibrations.first!
    let calibration = DepthPoseRegistrationEngine.CalibrationIntrinsics(
      calibrationID: cal["calibration_id"] as? String ?? FixtureReconstructionPackageBuilder.calibrationID,
      fx: cal["focal_length_x"] as? Double ?? ReconstructionFixtureDepthPayload.fx,
      fy: cal["focal_length_y"] as? Double ?? ReconstructionFixtureDepthPayload.fy,
      cx: cal["principal_point_x"] as? Double ?? ReconstructionFixtureDepthPayload.cx,
      cy: cal["principal_point_y"] as? Double ?? ReconstructionFixtureDepthPayload.cy,
      width: ReconstructionFixtureDepthPayload.width,
      height: ReconstructionFixtureDepthPayload.height
    )

    var allPoints: [RegisteredPoint] = []
    var transforms: [RegistrationTransformRecord] = []
    var invalidDepth = 0
    let engine = DepthPoseRegistrationEngine()
    for candID in frames.selectedCandidateIDs.sorted() {
      guard let cand = candidates.first(where: { $0.candidateID == candID }),
            let depth = depthByID[cand.depthObservationID],
            let pose = poseByID[cand.poseObservationID]
      else { continue }
      let reg = try engine.register(
        depth: depth,
        pose: pose,
        calibration: calibration,
        depthToCamera: ingest.depthToCameraMatrix,
        sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
        derivationID: "DER-REG-\(candID)"
      )
      allPoints.append(contentsOf: reg.points)
      transforms = reg.transformsUsed
      invalidDepth += reg.invalidDepthCount
    }
    // Deduplicate by pointID keeping first (deterministic sort)
    var seen = Set<String>()
    var unique: [RegisteredPoint] = []
    var dupCount = 0
    for p in allPoints.sorted(by: { $0.pointID < $1.pointID }) {
      if seen.insert(p.pointID).inserted {
        unique.append(p)
      } else {
        dupCount += 1
      }
    }
    // For multi-frame identity poses/depths, point IDs collide — suffix by frame for second+ frames
    if dupCount > 0 {
      unique = []
      seen = []
      for (idx, candID) in frames.selectedCandidateIDs.sorted().enumerated() {
        guard let cand = candidates.first(where: { $0.candidateID == candID }),
              let depth = depthByID[cand.depthObservationID],
              let pose = poseByID[cand.poseObservationID]
        else { continue }
        let reg = try engine.register(
          depth: depth,
          pose: pose,
          calibration: calibration,
          depthToCamera: ingest.depthToCameraMatrix,
          sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
          derivationID: "DER-REG-\(candID)"
        )
        for var p in reg.points {
          if idx > 0 {
            p = RegisteredPoint(
              pointID: "\(p.pointID)-F\(idx)",
              x: p.x, y: p.y, z: p.z,
              validity: p.validity,
              confidence: p.confidence,
              sourceFrameID: p.sourceFrameID,
              reconstructionFrameID: p.reconstructionFrameID,
              evidenceAuthority: p.evidenceAuthority,
              source: p.source
            )
          }
          unique.append(p)
        }
        invalidDepth = reg.invalidDepthCount
        transforms = reg.transformsUsed
      }
      unique.sort { $0.pointID < $1.pointID }
      dupCount = 0
    }

    let registration = RegistrationResult(points: unique, transformsUsed: transforms, invalidDepthCount: invalidDepth)
    let validPts = unique.filter { $0.validity == .valid }
    let xs = validPts.map(\.x), ys = validPts.map(\.y), zs = validPts.map(\.z)
    let qualitySummary = PointCloudQualitySummary(
      registeredPointCount: validPts.count,
      invalidDepthCount: unique.filter { $0.validity != .valid }.count,
      duplicatePointCount: dupCount,
      boundingBoxMin: [xs.min() ?? 0, ys.min() ?? 0, zs.min() ?? 0],
      boundingBoxMax: [xs.max() ?? 0, ys.max() ?? 0, zs.max() ?? 0]
    )
    let outputID = FixtureReconstructionPackageBuilder.reconstructionOutputID
    let cloud = RegisteredPointCloud(
      metadata: RegisteredPointCloudMetadata(
        cloudID: "RPC-FIXTURE-000001",
        reconstructionOutputID: outputID,
        sourcePackageID: descriptor.packageID,
        sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
        frameEpochID: descriptor.frameEpochID,
        units: "meters",
        handedness: "right",
        authority: "TEST_FIXTURE"
      ),
      points: unique,
      quality: qualitySummary
    )

    let geometry = ingest.geometry ?? FixtureReconstructionGeometry.planarTarget()
    // Compare first-frame points only against expected UV positions
    let firstFramePoints = RegistrationResult(
      points: unique.filter { !$0.pointID.contains("-F") },
      transformsUsed: transforms,
      invalidDepthCount: unique.filter { !$0.pointID.contains("-F") && $0.validity != .valid }.count
    )
    let quality = try ReconstructionQualityAssessor.assess(
      frames: frames,
      registration: firstFramePoints,
      expectedPoints: geometry.expectedPointPositions,
      geometryID: geometry.geometryID
    )
    guard quality.groundTruthComparison?.passed == true else {
      throw ReconstructionError.groundTruthMismatch("FIXTURE_GROUND_TRUTH_DELTA")
    }

    let surface = SyntheticFixtureSurfaceGenerator.generate(
      from: cloud,
      geometryID: geometry.geometryID,
      derivationID: "DER-SURF-000001"
    )

    try FileManager.default.createDirectory(at: outputRoot, withIntermediateDirectories: true)
    func writeObj(_ name: String, _ dict: [String: Any]) throws -> (String, Int, String) {
      let data = try CanonicalJSON.data(dict)
      try data.write(to: outputRoot.appendingPathComponent(name), options: .atomic)
      return (name, data.count, ContentHasher.sha256Hex(data))
    }

    var items: [ReconstructionOutputInventoryItem] = []
    let cloudSHA: String
    do {
      let (n, b, h) = try writeObj("registered_point_cloud.json", cloud.dictionary())
      cloudSHA = h
      items.append(ReconstructionOutputInventoryItem(relativePath: n, sha256: h, byteCount: b, mediaType: "application/json", role: "registered_point_cloud"))
    }
    do {
      let (n, b, h) = try writeObj("selected_keyframes.json", frames.dictionary())
      items.append(ReconstructionOutputInventoryItem(relativePath: n, sha256: h, byteCount: b, mediaType: "application/json", role: "selected_keyframes"))
    }
    do {
      let (n, b, h) = try writeObj("normalized_observations.json", normalized.dictionary())
      items.append(ReconstructionOutputInventoryItem(relativePath: n, sha256: h, byteCount: b, mediaType: "application/json", role: "normalized_observations"))
    }
    do {
      let (n, b, h) = try writeObj("quality_record.json", quality.dictionary())
      items.append(ReconstructionOutputInventoryItem(relativePath: n, sha256: h, byteCount: b, mediaType: "application/json", role: "quality_record"))
    }
    do {
      let (n, b, h) = try writeObj("fixture_geometry_expected.json", geometry.dictionary())
      items.append(ReconstructionOutputInventoryItem(relativePath: n, sha256: h, byteCount: b, mediaType: "application/json", role: "expected_geometry"))
    }
    if let cand = surface.candidate {
      let (n, b, h) = try writeObj("surface_candidate.json", cand.dictionary())
      items.append(ReconstructionOutputInventoryItem(relativePath: n, sha256: h, byteCount: b, mediaType: "application/json", role: "synthetic_surface_candidate"))
    }
    do {
      let (n, b, h) = try writeObj("eligibility_result.json", ingest.eligibility.dictionary())
      items.append(ReconstructionOutputInventoryItem(relativePath: n, sha256: h, byteCount: b, mediaType: "application/json", role: "eligibility"))
    }

    let cfg = ReconstructionLineageBuilder.configurationDigest(
      policyIDs: [ReconstructionEligibilityPolicy.fixture.policyID, FrameSelectionPolicy.fixture.policyID],
      versions: [FrameSelectionPolicy.fixture.policyVersion, ReconstructionLineageBuilder.algorithm.algorithmVersion]
    )
    let derivation = ReconstructionDerivationRecord(
      derivationID: "DER-RECONSTRUCTION-000001",
      sourcePackageID: descriptor.packageID,
      sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
      sourceManifestSHA256: descriptor.manifestSHA256,
      sourceSampleIDs: (ingest.inventory?.cameraSampleIDs ?? []) + (ingest.inventory?.depthSampleIDs ?? []) + (ingest.inventory?.poseSampleIDs ?? []),
      sourceArtifactHashes: ingest.artifacts.compactMap { $0["sha256"] as? String },
      algorithm: ReconstructionLineageBuilder.algorithm,
      configuration: cfg,
      policyIDs: cfg.policyIDs,
      outputArtifactIDs: items.map(\.relativePath),
      outputArtifactHashes: items.map(\.sha256),
      generationTimestamp: "2026-08-04T04:00:00Z",
      authority: "TEST_FIXTURE",
      reproducibilityStatus: "DETERMINISTIC_FIXTURE_REPLAY"
    )
    let lineage = try ReconstructionLineageBuilder.sealLineage([derivation])
    do {
      let (n, b, h) = try writeObj("lineage_manifest.json", lineage.dictionary())
      items.append(ReconstructionOutputInventoryItem(relativePath: n, sha256: h, byteCount: b, mediaType: "application/json", role: "lineage_manifest"))
    }

    items.sort { $0.relativePath < $1.relativePath }
    let invBody = try CanonicalJSON.data(["items": items.map { $0.dictionary() }])
    let invSHA = ContentHasher.sha256Hex(invBody)
    let inventory = ReconstructionOutputInventory(
      inventoryID: "INV-RECON-OUT-000001",
      reconstructionOutputID: outputID,
      items: items,
      inventorySHA256: invSHA
    )
    _ = try writeObj("output_inventory.json", inventory.dictionary())

    // Recompute inventory including output_inventory itself
    let allEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputRoot)
    let closure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: allEntries)
    let closureDoc: [String: Any] = [
      "schema_id": "ReconstructionOutputClosure",
      "reconstruction_output_id": outputID,
      "output_closure_sha256": closure,
      "source_package_id": descriptor.packageID,
      "source_package_closure_sha256": descriptor.packageClosureSHA256,
      "note": "Derived reconstruction outputs; original SPKG unchanged",
    ]
    _ = try writeObj("output_closure.json", closureDoc)
    let finalEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputRoot)
    let finalClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: finalEntries)

    let sourceAfter = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: packageRoot)
    guard sourceBefore == sourceAfter else {
      throw ReconstructionError.deterministicReplayMismatch("source_package_mutated")
    }

    return ReconstructionPipelineResult(
      reconstructionOutputID: outputID,
      eligibility: ingest.eligibility,
      normalized: normalized,
      frames: frames,
      registration: registration,
      pointCloud: cloud,
      quality: quality,
      surface: surface,
      lineage: lineage,
      inventory: inventory,
      outputClosureSHA256: finalClosure,
      outputRoot: outputRoot,
      sourcePackageUnchanged: true,
      sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
      pointCloudSHA256: cloudSHA,
      lineageManifestSHA256: lineage.lineageManifestSHA256,
      inventorySHA256: invSHA
    )
  }
}
