import Foundation

public struct Phase4BPipelineResult: Sendable {
  public var reconstructionOutputID: String
  public var detection: FeatureDetectionResult
  public var matching: FeatureMatchResult
  public var geometric: GeometricValidationResult
  public var tracks: FeatureTrackGraph
  public var initialGraph: ReconstructionPoseGraph
  public var refinement: PoseRefinementResult
  public var sourcePoseCloud: RegisteredPointCloud
  public var refinedPoseCloud: RegisteredPointCloud?
  public var comparison: ReconstructionComparisonRecord
  public var quality: PoseRefinementQualityRecord
  public var lineage: Phase4BSpatialLineageManifest
  public var outputRoot: URL
  public var sourcePackageClosureSHA256: String
  public var sourcePosePointCloudSHA256: String
  public var refinedPosePointCloudSHA256: String
  public var outputClosureSHA256: String
  public var sourcePosesUnchanged: Bool
}

public enum Phase4BPLYWriter {
  public static func writeASCII(cloud: RegisteredPointCloud) -> String {
    let valid = cloud.points.filter { $0.validity == .valid }.sorted { $0.pointID < $1.pointID }
    var lines: [String] = [
      "ply",
      "format ascii 1.0",
      "comment Elektron Phase 4B fixture PLY — not production mesh",
      "comment reconstruction_output_id \(cloud.metadata.reconstructionOutputID)",
      "comment authority \(cloud.metadata.authority)",
      "element vertex \(valid.count)",
      "property float x",
      "property float y",
      "property float z",
      "end_header",
    ]
    for p in valid {
      lines.append(String(format: "%.9f %.9f %.9f", p.x, p.y, p.z))
    }
    return lines.joined(separator: "\n") + "\n"
  }
}

public struct Phase4BPipeline: Sendable {
  public init() {}

  public func run(
    packageRoot: URL,
    outputRoot: URL,
    sealedGeometry: FixtureMultiviewGeometry? = nil
  ) throws -> Phase4BPipelineResult {
    let sourceBefore = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: packageRoot)
    let ingest = try ReconstructionPackageIngestor().ingest(packageRoot: packageRoot)
    guard ingest.eligibility.isEligible, let descriptor = ingest.descriptor else {
      throw ReconstructionError.ineligible(ingest.eligibility.outcome.rawValue)
    }
    let geometry = sealedGeometry
      ?? (try? loadGeometry(packageRoot: packageRoot))
      ?? FixtureMultiviewGeometry.multiviewTarget()

    let fx = ReconstructionFixtureDepthPayload.fx
    let fy = ReconstructionFixtureDepthPayload.fy
    let cx = ReconstructionFixtureDepthPayload.cx
    let cy = ReconstructionFixtureDepthPayload.cy

    // --- Feature detection from TRUE poses (observations), matching source artifact digests ---
    let cameraSamples = ingest.sampleIndex
      .filter { ($0["stream_id"] as? String) == SpatialStreamID.camera }
      .sorted { (($0["sample_id"] as? String) ?? "") < (($1["sample_id"] as? String) ?? "") }
    let artBySample = Dictionary(uniqueKeysWithValues: ingest.artifacts.compactMap { a -> (String, [String: Any])? in
      guard let sid = a["sample_id"] as? String else { return nil }
      return (sid, a)
    })

    let detector = FixtureSyntheticFeatureDetector()
    var frameSets: [FrameFeatureSet] = []
    for (i, cam) in cameraSamples.enumerated() {
      let sid = cam["sample_id"] as? String ?? ""
      let art = artBySample[sid] ?? [:]
      let rel = art["relative_path"] as? String ?? ""
      let sha = art["sha256"] as? String ?? ""
      let trueT = geometry.trueCameraTranslations[min(i, geometry.trueCameraTranslations.count - 1)]
      var projections: [(String, Double, Double, Double)] = []
      for lid in geometry.landmarkIDs {
        guard let pos = geometry.landmarkPosition(lid) else { continue }
        let pv = FixtureMultiviewGeometry.project(
          worldX: pos.0, worldY: pos.1, worldZ: pos.2,
          cameraTranslation: trueT, fx: fx, fy: fy, cx: cx, cy: cy
        )
        projections.append((lid, pv.u, pv.v, 1.0))
      }
      let set = try detector.detect(
        cameraSampleID: sid,
        sourceArtifactID: rel,
        sourceArtifactSHA256: sha,
        projections: projections,
        frameEpochID: descriptor.frameEpochID,
        sessionRunID: descriptor.sessionRunID,
        worldOriginRevision: descriptor.worldOriginRevision
      )
      frameSets.append(set)
    }
    // Inject one deliberate outlier observation on frame 1 for geometric rejection testing path
    // (handled via matching of a synthetic mismatched pair in tests; detection stays clean for happy path)

    let detection = FeatureDetectionResult(
      frameSets: frameSets,
      policy: .fixture,
      algorithmID: FixtureSyntheticFeatureDetector.algorithmID,
      algorithmVersion: FixtureSyntheticFeatureDetector.algorithmVersion
    )

    // --- Matching consecutive pairs ---
    let matcher = FeatureMatcher()
    var pairs: [FramePairCorrespondenceSet] = []
    for i in 0..<(frameSets.count - 1) {
      let pair = try matcher.match(source: frameSets[i], destination: frameSets[i + 1])
      pairs.append(pair)
    }
    let matching = FeatureMatchResult(pairs: pairs, policy: .fixture)

    let obsByID = Dictionary(uniqueKeysWithValues: detection.allObservations.map { ($0.featureObservationID, $0) })
    let allAccepted = pairs.flatMap(\.accepted)
    let geometric = GeometricConsistencyValidator().validatePlanarLandmarkConsistency(
      matches: allAccepted,
      observationsByID: obsByID
    )
    // Filter matches to geometric inliers for track building
    let inlierIDs = Set(geometric.inliers.matchIDs)
    let filteredPairs = pairs.map { pair -> FramePairCorrespondenceSet in
      let kept = pair.accepted.filter { inlierIDs.contains($0.matchID) }
      var rejected = pair.rejected
      for m in pair.accepted where !inlierIDs.contains(m.matchID) {
        rejected.append(MatchRejectionRecord(matchID: m.matchID, reason: .geometricOutlier, detail: "geometric_validation"))
      }
      return FramePairCorrespondenceSet(
        sourceCameraSampleID: pair.sourceCameraSampleID,
        destinationCameraSampleID: pair.destinationCameraSampleID,
        accepted: kept,
        rejected: rejected
      )
    }

    let tracks = try FeatureTrackBuilder().build(
      frameSets: frameSets,
      correspondences: filteredPairs,
      expectedEpoch: descriptor.frameEpochID,
      expectedSession: descriptor.sessionRunID
    )

    // --- Pose graph from SOURCE (perturbed) poses ---
    let poseSamples = ingest.sampleIndex
      .filter { ($0["stream_id"] as? String) == SpatialStreamID.pose }
      .sorted { (($0["sample_id"] as? String) ?? "") < (($1["sample_id"] as? String) ?? "") }

    var nodes: [ReconstructionPoseNode] = []
    for (i, cam) in cameraSamples.enumerated() {
      let camID = cam["sample_id"] as? String ?? ""
      let poseID = poseSamples[min(i, poseSamples.count - 1)]["sample_id"] as? String ?? "mf-pose-\(i)"
      let poseArt = artBySample[poseID]
      let rel = poseArt?["relative_path"] as? String ?? "payload/pose/\(String(format: "%04d.bin", i))"
      let bytes = try Data(contentsOf: packageRoot.appendingPathComponent(rel))
      let matrix = decodeTransform(bytes)
      let t = [matrix[12], matrix[13], matrix[14]]
      nodes.append(
        ReconstructionPoseNode(
          nodeID: "NODE-\(camID)",
          cameraSampleID: camID,
          poseSampleID: poseID,
          sourceTranslation: t,
          sourceTransform4x4: matrix,
          sourcePoseAuthority: "GUIDANCE_ESTIMATE",
          refinedTranslation: nil,
          refinedTransform4x4: nil,
          refinementAuthority: nil,
          frameEpochID: descriptor.frameEpochID,
          sessionRunID: descriptor.sessionRunID,
          worldOriginRevision: descriptor.worldOriginRevision,
          derivationID: "DER-POSE-NODE-\(camID)"
        )
      )
    }

    var edges: [ReconstructionPoseEdge] = []
    for i in 0..<(nodes.count - 1) {
      let a = nodes[i], b = nodes[i + 1]
      edges.append(
        ReconstructionPoseEdge(
          edgeID: "EDGE-\(a.nodeID)-\(b.nodeID)",
          fromNodeID: a.nodeID,
          toNodeID: b.nodeID,
          kind: "SEQUENTIAL_VISUAL",
          relativeTranslation: [
            b.sourceTranslation[0] - a.sourceTranslation[0],
            b.sourceTranslation[1] - a.sourceTranslation[1],
            b.sourceTranslation[2] - a.sourceTranslation[2],
          ]
        )
      )
    }

    let visualConstraints: [VisualConstraint] = filteredPairs.enumerated().map { idx, pair in
      let srcNode = nodes.first { $0.cameraSampleID == pair.sourceCameraSampleID }!
      let dstNode = nodes.first { $0.cameraSampleID == pair.destinationCameraSampleID }!
      let trackIDs = tracks.tracks.filter { track in
        track.observations.contains { $0.cameraSampleID == pair.sourceCameraSampleID }
          && track.observations.contains { $0.cameraSampleID == pair.destinationCameraSampleID }
      }.map(\.trackID)
      return VisualConstraint(
        constraintID: "VC-\(idx)",
        sourceNodeID: srcNode.nodeID,
        destinationNodeID: dstNode.nodeID,
        trackIDs: trackIDs,
        residualPixels: 0
      )
    }

    let depthConstraints: [DepthConstraint] = ingest.inventory?.depthSampleIDs.enumerated().map { i, did in
      DepthConstraint(
        constraintID: "DC-\(i)",
        nodeID: nodes[min(i, nodes.count - 1)].nodeID,
        depthSampleID: did
      )
    } ?? []

    let priors = nodes.map {
      PosePrior(nodeID: $0.nodeID, translation: $0.sourceTranslation, transform4x4: $0.sourceTransform4x4, authority: $0.sourcePoseAuthority, weight: 1.0)
    }

    let initialGraph = ReconstructionPoseGraph(
      graphID: "PG-FIXTURE-MULTIFRAME-000001",
      nodes: nodes,
      edges: edges,
      priors: priors,
      visualConstraints: visualConstraints,
      depthConstraints: depthConstraints,
      configuration: .fixture
    )

    let refinement = try PoseGraphRefinementEngine().refine(
      graph: initialGraph,
      tracks: tracks,
      geometry: geometry,
      fx: fx, fy: fy, cx: cx, cy: cy
    )
    guard refinement.outcome == .converged, let refinedGraph = refinement.refinedGraph else {
      throw ReconstructionError.registrationFailed("pose_refinement_\(refinement.outcome.rawValue)")
    }

    // --- Register point clouds with source vs refined poses ---
    let normalized = try ObservationNormalizer().normalize(ingest: ingest)
    let depthByCam: [String: NormalizedDepthObservation] = {
      var map: [String: NormalizedDepthObservation] = [:]
      for assoc in normalized.associations {
        if let cam = normalized.cameras.first(where: { $0.observationID == assoc.cameraObservationID }),
           let depth = normalized.depths.first(where: { $0.observationID == assoc.depthObservationID })
        {
          map[cam.sampleID] = depth
        }
      }
      return map
    }()
    let poseObsBySample = Dictionary(uniqueKeysWithValues: normalized.poses.map { ($0.sampleID, $0) })

    let calibration = DepthPoseRegistrationEngine.CalibrationIntrinsics(
      calibrationID: FixtureMultiframeReconstructionPackageBuilder.calibrationID,
      fx: fx, fy: fy, cx: cx, cy: cy,
      width: ReconstructionFixtureDepthPayload.width,
      height: ReconstructionFixtureDepthPayload.height
    )
    let engine = DepthPoseRegistrationEngine()

    func cloud(using graph: ReconstructionPoseGraph, cloudID: String, outputID: String, useRefined: Bool) throws -> RegisteredPointCloud {
      var all: [RegisteredPoint] = []
      var invalid = 0
      for (idx, node) in graph.nodes.sorted(by: { $0.nodeID < $1.nodeID }).enumerated() {
        guard let depth = depthByCam[node.cameraSampleID] else { continue }
        let t = useRefined ? node.activeTranslation : node.sourceTranslation
        let matrix = useRefined ? node.activeTransform4x4 : node.sourceTransform4x4
        let poseObs = NormalizedPoseObservation(
          observationID: "OBS-POSE-\(node.poseSampleID)",
          sampleID: node.poseSampleID,
          timestampNanoseconds: poseObsBySample[node.poseSampleID]?.timestampNanoseconds ?? 0,
          clockDomain: "arkit_frame",
          translation: t,
          transform4x4: matrix,
          trackingState: "NORMAL",
          frameEpochID: node.frameEpochID,
          sessionRunID: node.sessionRunID,
          worldOriginRevision: node.worldOriginRevision
        )
        let reg = try engine.register(
          depth: depth,
          pose: poseObs,
          calibration: calibration,
          depthToCamera: HomogeneousMatrix4x4.identity(),
          sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
          derivationID: "DER-REG-\(cloudID)-\(node.nodeID)"
        )
        for var p in reg.points {
          if idx > 0 {
            p = RegisteredPoint(
              pointID: "\(p.pointID)-F\(idx)",
              x: p.x, y: p.y, z: p.z,
              validity: p.validity,
              confidence: p.confidence,
              sourceFrameID: p.sourceFrameID,
              reconstructionFrameID: p.reconstructionFrameID,
              evidenceAuthority: p.evidenceAuthority,
              source: p.source
            )
          }
          all.append(p)
        }
        invalid += reg.invalidDepthCount
      }
      all.sort { $0.pointID < $1.pointID }
      let valid = all.filter { $0.validity == .valid }
      let xs = valid.map(\.x), ys = valid.map(\.y), zs = valid.map(\.z)
      return RegisteredPointCloud(
        metadata: RegisteredPointCloudMetadata(
          cloudID: cloudID,
          reconstructionOutputID: outputID,
          sourcePackageID: descriptor.packageID,
          sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
          frameEpochID: descriptor.frameEpochID,
          units: "meters",
          handedness: "right",
          authority: useRefined ? "RECONSTRUCTION_ESTIMATE" : "TEST_FIXTURE"
        ),
        points: all,
        quality: PointCloudQualitySummary(
          registeredPointCount: valid.count,
          invalidDepthCount: all.filter { $0.validity != .valid }.count,
          duplicatePointCount: 0,
          boundingBoxMin: [xs.min() ?? 0, ys.min() ?? 0, zs.min() ?? 0],
          boundingBoxMax: [xs.max() ?? 0, ys.max() ?? 0, zs.max() ?? 0]
        )
      )
    }

    let outputID = FixtureMultiframeReconstructionPackageBuilder.reconstructionOutputID
    let sourceCloud = try cloud(using: initialGraph, cloudID: "RPC-SOURCE-POSE-000001", outputID: outputID, useRefined: false)
    let refinedCloud = try cloud(using: refinedGraph, cloudID: "RPC-REFINED-POSE-000001", outputID: outputID, useRefined: true)

    // Ground-truth delta vs planar Z=2 for valid first-frame points (fixture bound)
    func gtDelta(_ cloud: RegisteredPointCloud) -> Double {
      let pts = cloud.points.filter { $0.validity == .valid && !$0.pointID.contains("-F") }
      let errs = pts.map { abs($0.z - 2.0) }
      return errs.max() ?? 0
    }

    let comparison = ReconstructionComparisonRecord(
      sourcePointCount: sourceCloud.quality.registeredPointCount,
      refinedPointCount: refinedCloud.quality.registeredPointCount,
      sourceRegistrationResidual: refinement.residuals.initialMeanResidual,
      refinedRegistrationResidual: refinement.residuals.finalMeanResidual,
      sourceGroundTruthDelta: gtDelta(sourceCloud),
      refinedGroundTruthDelta: gtDelta(refinedCloud),
      poseResidualInitial: refinement.residuals.initialMeanResidual,
      poseResidualFinal: refinement.residuals.finalMeanResidual,
      sourceBoundingBox: [sourceCloud.quality.boundingBoxMin, sourceCloud.quality.boundingBoxMax],
      refinedBoundingBox: [refinedCloud.quality.boundingBoxMin, refinedCloud.quality.boundingBoxMax],
      sourceLineageComplete: true,
      refinedLineageComplete: true
    )

    let featureQuality = FeatureTrackQualitySummary(
      detectedFeatureCount: detection.allObservations.count,
      acceptedMatchCount: filteredPairs.reduce(0) { $0 + $1.accepted.count },
      rejectedMatchCount: matching.rejectedCount + geometric.outliers.matchIDs.count,
      geometricInlierCount: geometric.inliers.matchIDs.count,
      geometricOutlierCount: geometric.outliers.matchIDs.count,
      featureTrackCount: tracks.tracks.count,
      meanFeatureTrackLength: tracks.meanTrackLength
    )
    let poseQuality = PoseGraphQualitySummary(
      nodeCount: initialGraph.nodes.count,
      edgeCount: initialGraph.edges.count,
      initialPoseResidual: refinement.residuals.initialMeanResidual,
      finalPoseResidual: refinement.residuals.finalMeanResidual,
      convergenceStatus: refinement.outcome.rawValue
    )
    let quality = PoseRefinementQualityRecord(
      feature: featureQuality,
      poseGraph: poseQuality,
      sourcePosePointCloudError: comparison.sourceGroundTruthDelta,
      refinedPosePointCloudError: comparison.refinedGroundTruthDelta,
      lineageCompleteness: 1.0,
      engineeringMetrologyClaim: "FORBIDDEN",
      productionPhotogrammetryClaim: "FORBIDDEN"
    )

    try FileManager.default.createDirectory(at: outputRoot, withIntermediateDirectories: true)
    func writeObj(_ name: String, _ dict: [String: Any]) throws -> (String, Int, String) {
      let data = try CanonicalJSON.data(dict)
      try data.write(to: outputRoot.appendingPathComponent(name), options: .atomic)
      return (name, data.count, ContentHasher.sha256Hex(data))
    }
    func writeText(_ name: String, _ text: String) throws -> (String, Int, String) {
      let data = Data(text.utf8)
      try data.write(to: outputRoot.appendingPathComponent(name), options: .atomic)
      return (name, data.count, ContentHasher.sha256Hex(data))
    }

    var hashes: [String: String] = [:]
    var items: [ReconstructionOutputInventoryItem] = []
    func track(_ n: String, _ b: Int, _ h: String, _ role: String) {
      hashes[n] = h
      items.append(ReconstructionOutputInventoryItem(relativePath: n, sha256: h, byteCount: b, mediaType: n.hasSuffix(".ply") ? "application/x-ply" : "application/json", role: role))
    }

    do { let (n, b, h) = try writeObj("feature_observations.json", detection.dictionary()); track(n, b, h, "feature_observations") }
    do { let (n, b, h) = try writeObj("feature_matches.json", matching.dictionary()); track(n, b, h, "feature_matches") }
    do { let (n, b, h) = try writeObj("geometric_validation.json", geometric.dictionary()); track(n, b, h, "geometric_validation") }
    do { let (n, b, h) = try writeObj("feature_tracks.json", tracks.dictionary()); track(n, b, h, "feature_tracks") }
    do { let (n, b, h) = try writeObj("pose_graph_initial.json", initialGraph.dictionary()); track(n, b, h, "pose_graph_initial") }
    do { let (n, b, h) = try writeObj("pose_graph_refined.json", refinedGraph.dictionary()); track(n, b, h, "pose_graph_refined") }
    do { let (n, b, h) = try writeObj("pose_refinement_result.json", refinement.dictionary()); track(n, b, h, "pose_refinement_result") }
    let sourceSHA: String
    do {
      let (n, b, h) = try writeObj("registered_point_cloud_source_pose.json", sourceCloud.dictionary())
      sourceSHA = h
      track(n, b, h, "registered_point_cloud_source_pose")
    }
    let refinedSHA: String
    do {
      let (n, b, h) = try writeObj("registered_point_cloud_refined_pose.json", refinedCloud.dictionary())
      refinedSHA = h
      track(n, b, h, "registered_point_cloud_refined_pose")
    }
    do {
      let (n, b, h) = try writeText("registered_point_cloud_refined_pose.ply", Phase4BPLYWriter.writeASCII(cloud: refinedCloud))
      track(n, b, h, "registered_point_cloud_refined_pose_ply")
    }
    do { let (n, b, h) = try writeObj("point_cloud_comparison.json", comparison.dictionary()); track(n, b, h, "point_cloud_comparison") }
    do { let (n, b, h) = try writeObj("quality_record.json", quality.dictionary()); track(n, b, h, "quality_record") }
    do { let (n, b, h) = try writeObj("fixture_geometry_expected.json", geometry.dictionary()); track(n, b, h, "expected_geometry") }

    var lineage = Phase4BSpatialLineageManifest(
      lineageManifestID: "LINEAGE-PHASE4B-000001",
      sourcePackageID: descriptor.packageID,
      sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
      featureAlgorithmID: FixtureSyntheticFeatureDetector.algorithmID,
      matchingPolicyID: FeatureMatchPolicy.fixture.policyID,
      geometricPolicyID: "GEOM-VAL-POL-FIXTURE-000001",
      optimizationConfigurationDigest: PoseGraphConfiguration.fixture.configurationDigest,
      outputArtifactHashes: hashes,
      lineageManifestSHA256: ""
    )
    let lineageBody = try CanonicalJSON.data(lineage.dictionary())
    // provisional without sha field stable: recompute
    lineage.lineageManifestSHA256 = ContentHasher.sha256Hex(
      try CanonicalJSON.data({
        var d = lineage.dictionary()
        d["lineage_manifest_sha256"] = ""
        return d
      }())
    )
    do {
      let (n, b, h) = try writeObj("lineage_manifest.json", lineage.dictionary())
      track(n, b, h, "lineage_manifest")
      lineage.lineageManifestSHA256 = h
    }

    items.sort { $0.relativePath < $1.relativePath }
    let inv = ReconstructionOutputInventory(
      inventoryID: "INV-RECON-OUT-4B-000001",
      reconstructionOutputID: outputID,
      items: items,
      inventorySHA256: ContentHasher.sha256Hex(try CanonicalJSON.data(["items": items.map { $0.dictionary() }]))
    )
    _ = try writeObj("output_inventory.json", inv.dictionary())

    let entries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputRoot)
    let closure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: entries)
    _ = try writeObj("output_closure.json", [
      "schema_id": "ReconstructionOutputClosure",
      "reconstruction_output_id": outputID,
      "output_closure_sha256": closure,
      "source_package_id": descriptor.packageID,
      "source_package_closure_sha256": descriptor.packageClosureSHA256,
      "note": "Phase 4B derived outputs; original SPKG and Phase 4A clouds unchanged",
    ])
    let finalEntries = try SpatialPackageClosureVerifier.collectPackageInventoryEntries(packageRoot: outputRoot)
    let finalClosure = try SpatialPackageClosureVerifier.inventoryClosureHash(entries: finalEntries)

    let sourceAfter = try SpatialPackageClosureVerifier.rehashPackageBytes(packageRoot: packageRoot)
    guard sourceBefore == sourceAfter else {
      throw ReconstructionError.deterministicReplayMismatch("source_package_mutated")
    }

    return Phase4BPipelineResult(
      reconstructionOutputID: outputID,
      detection: detection,
      matching: matching,
      geometric: geometric,
      tracks: tracks,
      initialGraph: initialGraph,
      refinement: refinement,
      sourcePoseCloud: sourceCloud,
      refinedPoseCloud: refinedCloud,
      comparison: comparison,
      quality: quality,
      lineage: lineage,
      outputRoot: outputRoot,
      sourcePackageClosureSHA256: descriptor.packageClosureSHA256,
      sourcePosePointCloudSHA256: sourceSHA,
      refinedPosePointCloudSHA256: refinedSHA,
      outputClosureSHA256: finalClosure,
      sourcePosesUnchanged: refinement.sourcePosesUnchangedProof
    )
  }

  private func loadGeometry(packageRoot: URL) throws -> FixtureMultiviewGeometry {
    _ = try Data(contentsOf: packageRoot.appendingPathComponent("fixture_geometry.json"))
    return FixtureMultiviewGeometry.multiviewTarget()
  }

  private func decodeTransform(_ bytes: Data) -> [Double] {
    var matrix: [Double] = []
    let count = min(16, bytes.count / 8)
    for i in 0..<count {
      let o = i * 8
      var bits: UInt64 = 0
      for b in 0..<8 { bits |= UInt64(bytes[o + b]) << (8 * b) }
      matrix.append(Double(bitPattern: bits))
    }
    while matrix.count < 16 { matrix.append(0) }
    return matrix
  }
}
