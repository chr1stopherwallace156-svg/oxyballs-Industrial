import Foundation

// MARK: - Errors

public enum InspectionSessionError: Error, Equatable, Sendable {
  case invalidSessionID
  case emptyVehicleIdentifier
  case sessionAlreadyActive
  case noActiveSession
  case illegalStatusTransition(from: SessionStatus, to: SessionStatus)
  case terminalSessionCannotReceiveCaptures
  case corruptPersistence(String)
  case persistenceFailed(String)
  /// Optimistic concurrency failure: caller based a write on `attempted` while durable head is `current`.
  case staleRevisionConflict(current: Int, attempted: Int)
  /// `save` refused to overwrite a different session id in the current-session slot.
  /// Use ``CurrentSessionRepository/replaceCurrentSession(_:expectedIncumbentRevision:)``.
  case slotOccupied(incumbentID: String, incumbentRevision: Int)
  /// Recovery tried to install revision `recovered` over durable `durable` where recovered ≤ durable.
  case recoveryRevisionRegression(durable: Int, recovered: Int)
  case recoveryIdentityMismatch(durable: String, recovered: String)
}

// MARK: - SessionID

public struct SessionID: Hashable, Codable, Sendable, CustomStringConvertible {
  public let rawValue: String

  public init(rawValue: String) throws {
    let trimmed = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { throw InspectionSessionError.invalidSessionID }
    self.rawValue = trimmed
  }

  /// Non-throwing convenience for known-good literals in tests/fixtures.
  public static func unchecked(_ rawValue: String) -> SessionID {
    (try? SessionID(rawValue: rawValue)) ?? SessionID(unsafeUnchecked: rawValue)
  }

  private init(unsafeUnchecked rawValue: String) {
    self.rawValue = rawValue
  }

  public var description: String { rawValue }

  public init(from decoder: Decoder) throws {
    let container = try decoder.singleValueContainer()
    try self.init(rawValue: try container.decode(String.self))
  }

  public func encode(to encoder: Encoder) throws {
    var container = encoder.singleValueContainer()
    try container.encode(rawValue)
  }
}

public protocol SessionIDGenerating: Sendable {
  func makeSessionID() -> SessionID
}

/// Production ID generator: `INS-YYYYMMDD-HHMMSS-XXXX` using UTC + random suffix.
/// Not deterministic — wall clock and randomness are involved.
public struct ProductionSessionIDGenerator: SessionIDGenerating {
  public var instantProvider: any InstantProviding
  public var randomSuffixProvider: @Sendable () -> String

  public init(
    instantProvider: any InstantProviding = SystemInstantProvider(),
    randomSuffixProvider: @escaping @Sendable () -> String = {
      String(UUID().uuidString.prefix(4)).uppercased()
    }
  ) {
    self.instantProvider = instantProvider
    self.randomSuffixProvider = randomSuffixProvider
  }

  public func makeSessionID() -> SessionID {
    let formatter = DateFormatter()
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.calendar = Calendar(identifier: .gregorian)
    formatter.timeZone = TimeZone(secondsFromGMT: 0)
    formatter.dateFormat = "yyyyMMdd-HHmmss"
    let timestamp = formatter.string(from: instantProvider.now())
    let suffix = randomSuffixProvider()
    return SessionID.unchecked("INS-\(timestamp)-\(suffix)")
  }
}

public struct FixedSessionIDGenerator: SessionIDGenerating {
  public let sessionID: SessionID
  public init(sessionID: SessionID) { self.sessionID = sessionID }
  public func makeSessionID() -> SessionID { sessionID }
}

// MARK: - Instant

public protocol InstantProviding: Sendable {
  func now() -> Date
}

public struct SystemInstantProvider: InstantProviding {
  public init() {}
  public func now() -> Date { Date() }
}

public struct FixedInstantProvider: InstantProviding {
  public var instant: Date
  public init(_ instant: Date) { self.instant = instant }
  public func now() -> Date { instant }
}

// MARK: - Vehicle identifier

public enum VehicleIdentifierKind: String, Codable, Sendable, Equatable {
  /// Legacy persisted value (`"VIN"`). Still decodes; treated as validated-class for display only.
  case vin = "VIN"
  /// Future authoritative validation result — not assigned by the heuristic.
  case vinValidated = "VIN_VALIDATED"
  /// Shape-based heuristic only — not check-digit validated, not proof of VIN authority.
  case vinHeuristic = "VIN_HEURISTIC"
  case licensePlate = "LICENSE_PLATE"
  case fleetNumber = "FLEET_NUMBER"
  case assetNumber = "ASSET_NUMBER"
  /// Non-empty identifier that did not match a stronger classifier.
  case rawIdentifier = "RAW_IDENTIFIER"
  /// Absent / unresolved classification (historical default).
  case unknown = "UNKNOWN"

  /// UI label; never equates heuristic matches with validated VIN proof.
  public var displayLabel: String {
    switch self {
    case .vin, .vinValidated: return "VIN (validated)"
    case .vinHeuristic: return "VIN (heuristic)"
    case .licensePlate: return "License plate"
    case .fleetNumber: return "Fleet number"
    case .assetNumber: return "Asset number"
    case .rawIdentifier: return "Vehicle identifier"
    case .unknown: return "Unknown"
    }
  }
}

public struct VehicleIdentifier: Hashable, Codable, Sendable, Equatable {
  public let rawValue: String
  public let kind: VehicleIdentifierKind

  /// - Parameter kind: Explicit kind. When `nil`, applies ``classifyKind(from:)``.
  public init(rawValue: String, kind: VehicleIdentifierKind? = nil) throws {
    let trimmed = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty else { throw InspectionSessionError.emptyVehicleIdentifier }
    // Preserve raw stored value (trimmed only); do not rewrite historical casing into persistence
    // beyond the trim already required for non-empty validation.
    self.rawValue = trimmed
    self.kind = kind ?? Self.classifyKind(from: trimmed)
  }

  /// Lightweight VIN heuristic: exactly 17 ASCII alphanumeric characters excluding I, O, and Q.
  /// Returns ``vinHeuristic`` — never ``vinValidated`` / ``vin`` automatically.
  /// Does not claim checksum validation.
  public static func classifyKind(from raw: String) -> VehicleIdentifierKind {
    let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
    let normalized = trimmed.uppercased()
    guard normalized.count == 17 else { return .rawIdentifier }
    let forbidden: Set<Character> = ["I", "O", "Q"]
    for ch in normalized {
      guard ch.isASCII, ch.isLetter || ch.isNumber else { return .rawIdentifier }
      if forbidden.contains(ch) { return .rawIdentifier }
    }
    return .vinHeuristic
  }

  public func asDictionary() -> [String: Any] {
    [
      "raw_value": rawValue,
      "kind": kind.rawValue,
    ]
  }
}

public struct InspectionVehicle: Codable, Sendable, Equatable {
  public var primaryIdentifier: VehicleIdentifier
  public var vin: String?
  public var licensePlate: String?
  public var fleetNumber: String?
  public var assetNumber: String?
  public var make: String?
  public var model: String?
  public var year: Int?

  public init(
    primaryIdentifier: VehicleIdentifier,
    vin: String? = nil,
    licensePlate: String? = nil,
    fleetNumber: String? = nil,
    assetNumber: String? = nil,
    make: String? = nil,
    model: String? = nil,
    year: Int? = nil
  ) {
    self.primaryIdentifier = primaryIdentifier
    self.vin = vin
    self.licensePlate = licensePlate
    self.fleetNumber = fleetNumber
    self.assetNumber = assetNumber
    self.make = make
    self.model = model
    self.year = year
  }

  public func asDictionary() -> [String: Any] {
    [
      "primary_identifier": primaryIdentifier.asDictionary(),
      "vin": vin.map { $0 as Any } ?? NSNull(),
      "license_plate": licensePlate.map { $0 as Any } ?? NSNull(),
      "fleet_number": fleetNumber.map { $0 as Any } ?? NSNull(),
      "asset_number": assetNumber.map { $0 as Any } ?? NSNull(),
      "make": make.map { $0 as Any } ?? NSNull(),
      "model": model.map { $0 as Any } ?? NSNull(),
      "year": year.map { $0 as Any } ?? NSNull(),
    ]
  }
}

// MARK: - Inspector

public struct Inspector: Codable, Sendable, Equatable {
  public let id: String
  public var name: String
  public var organization: String?
  public var role: String?

  public init(id: String, name: String, organization: String? = nil, role: String? = nil) {
    self.id = id
    self.name = name
    self.organization = organization
    self.role = role
  }

  public static let localDefault = Inspector(
    id: "INSPECTOR-LOCAL",
    name: "Local Inspector",
    organization: nil,
    role: "operator"
  )

  public func asDictionary() -> [String: Any] {
    [
      "id": id,
      "name": name,
      "organization": organization.map { $0 as Any } ?? NSNull(),
      "role": role.map { $0 as Any } ?? NSNull(),
    ]
  }
}

// MARK: - Status / metrics / session

public enum SessionStatus: String, Codable, Sendable, Equatable {
  case inProgress = "IN_PROGRESS"
  case paused = "PAUSED"
  case completed = "COMPLETED"
  case canceled = "CANCELED"

  public var isTerminal: Bool {
    self == .completed || self == .canceled
  }

  public var isActiveOrPaused: Bool {
    self == .inProgress || self == .paused
  }
}

public struct SessionMetrics: Codable, Sendable, Equatable {
  public var captureCount: Int

  public init(captureCount: Int = 0) {
    self.captureCount = captureCount
  }

  public func asDictionary() -> [String: Any] {
    ["capture_count": captureCount]
  }
}

// MARK: - Plan assignment (Sprint 2.1A)
// Types: AssignedInspectionPlan.swift, SessionPlanState.swift

public struct InspectionSession: Identifiable, Codable, Sendable, Equatable {
  public let id: SessionID
  public var vehicle: InspectionVehicle
  public var inspector: Inspector
  public let startedAt: Date
  public var finishedAt: Date?
  public var status: SessionStatus
  public var metrics: SessionMetrics
  /// Immutable plan assignment. Source of truth for plan identity on this session.
  public let planState: SessionPlanState
  /// Guided point progression (Sprint 2.1C). `nil` for pre-2.1C / unassigned sessions.
  /// Mutations must go through ``InspectionProgressionEngine`` — not ad hoc on this model.
  public var progress: InspectionProgressState?
  /// Evidence→point binding metadata (Sprint 2.1D). `nil` for pre-2.1D sessions.
  /// Mutations must go through ``EvidenceBindingService`` — not ad hoc on this model.
  /// Binary payloads / camera capture are out of scope for 2.1D.
  public var evidenceBindings: EvidenceBindingCollection?
  /// Monotonic optimistic-concurrency token (Sprint 2.3).
  ///
  /// - `0` = never durably committed (or legacy payload missing the field)
  /// - First successful persist writes `1`, then `N → N+1` on each accepted commit
  /// - Callers must submit the last authoritative revision; stores reject mismatches
  public var revision: Int

  /// Convenience: full assignment package, or `nil` when legacy.
  public var assignedPlan: AssignedInspectionPlan? { planState.assignedPlan }

  /// Convenience: assigned snapshot, or `nil` when ``planState`` is `.legacyUnassigned`.
  public var inspectionPlanSnapshot: InspectionPlanSnapshot? { planState.snapshot }

  /// Alias for ``inspectionPlanSnapshot`` (blueprint naming).
  public var planSnapshot: InspectionPlanSnapshot? { inspectionPlanSnapshot }

  /// Defers to ``AssignedInspectionPlan`` — not a duplicated stored field.
  public var planID: InspectionPlanID? { assignedPlan?.planID }

  /// Defers to ``AssignedInspectionPlan`` — not a duplicated stored field.
  public var planVersion: String? { assignedPlan?.planVersion }

  /// S2-002 definition digest from the frozen snapshot.
  public var definitionDigest: String? { assignedPlan?.definitionDigest }

  /// Assignment timestamp from ``AssignedInspectionPlan`` (`nil` when legacy).
  public var assignedAt: Date? { assignedPlan?.assignedAt }

  public init(
    id: SessionID,
    vehicle: InspectionVehicle,
    inspector: Inspector,
    startedAt: Date,
    finishedAt: Date? = nil,
    status: SessionStatus = .inProgress,
    metrics: SessionMetrics = SessionMetrics(),
    planState: SessionPlanState = .legacyUnassigned,
    progress: InspectionProgressState? = nil,
    evidenceBindings: EvidenceBindingCollection? = nil,
    revision: Int = 0
  ) {
    self.id = id
    self.vehicle = vehicle
    self.inspector = inspector
    self.startedAt = startedAt
    self.finishedAt = finishedAt
    self.status = status
    self.metrics = metrics
    self.planState = planState
    self.progress = progress
    self.evidenceBindings = evidenceBindings
    self.revision = revision
  }

  /// Creates a session with a verified immutable plan snapshot + assignment metadata.
  ///
  /// Verifies `definitionDigest` against canonical snapshot payload bytes **before**
  /// the session value is formed. Leaves ``progress`` as `nil` until
  /// ``InspectionProgressionEngine/initializeProgress(for:)`` — never fabricates
  /// progression for callers that only assign a plan.
  /// Does not touch `InspectionPlanRegistry`.
  public static func assigning(
    id: SessionID,
    vehicle: InspectionVehicle,
    inspector: Inspector,
    startedAt: Date,
    finishedAt: Date? = nil,
    status: SessionStatus = .inProgress,
    metrics: SessionMetrics = SessionMetrics(),
    planSnapshot: InspectionPlanSnapshot,
    assignedAt: Date
  ) throws -> InspectionSession {
    try InspectionPlanSnapshotHasher.verify(planSnapshot)
    let assignment = AssignedInspectionPlan(snapshot: planSnapshot, assignedAt: assignedAt)
    return InspectionSession(
      id: id,
      vehicle: vehicle,
      inspector: inspector,
      startedAt: startedAt,
      finishedAt: finishedAt,
      status: status,
      metrics: metrics,
      planState: .assigned(assignment),
      progress: nil
    )
  }

  enum CodingKeys: String, CodingKey {
    case id
    case vehicle
    case inspector
    case startedAt
    case finishedAt
    case status
    case metrics
    case planState
    case inspectionPlanSnapshot
    case assignedAt
    case progress
    case evidenceBindings
    case revision
  }

  public init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    id = try c.decode(SessionID.self, forKey: .id)
    vehicle = try c.decode(InspectionVehicle.self, forKey: .vehicle)
    inspector = try c.decode(Inspector.self, forKey: .inspector)
    startedAt = try c.decode(Date.self, forKey: .startedAt)
    finishedAt = try c.decodeIfPresent(Date.self, forKey: .finishedAt)
    status = try c.decode(SessionStatus.self, forKey: .status)
    metrics = try c.decodeIfPresent(SessionMetrics.self, forKey: .metrics) ?? SessionMetrics()
    let topLevelAssignedAt = try c.decodeIfPresent(Date.self, forKey: .assignedAt)
    // Pre-2.1C payloads omit progress → nil (legacy-compatible).
    progress = try c.decodeIfPresent(InspectionProgressState.self, forKey: .progress)
    // Pre-2.1D payloads omit evidenceBindings → nil (Option A).
    evidenceBindings = try c.decodeIfPresent(EvidenceBindingCollection.self, forKey: .evidenceBindings)
    // Pre-2.3 payloads omit revision → 0 (legacy-compatible; first persist bumps to 1).
    revision = try c.decodeIfPresent(Int.self, forKey: .revision) ?? 0

    // Preferred: SessionPlanState. Fallback: flat snapshot from earliest 2.1A tip.
    // Missing both → explicit legacy. Never invent a registry default.
    if c.contains(.planState) {
      planState = try c.decode(SessionPlanState.self, forKey: .planState)
    } else if let snapshot = try c.decodeIfPresent(
      InspectionPlanSnapshot.self,
      forKey: .inspectionPlanSnapshot
    ) {
      do {
        try InspectionPlanSnapshotHasher.verify(snapshot)
      } catch {
        throw DecodingError.dataCorrupted(
          DecodingError.Context(
            codingPath: c.codingPath + [CodingKeys.inspectionPlanSnapshot],
            debugDescription:
              "inspectionPlanSnapshot failed definition-digest verification: \(error)"
          )
        )
      }
      let assignedAt = topLevelAssignedAt ?? snapshot.snapshotCreatedAt
      planState = .assigned(AssignedInspectionPlan(snapshot: snapshot, assignedAt: assignedAt))
    } else {
      planState = .legacyUnassigned
    }
  }

  public func encode(to encoder: Encoder) throws {
    var c = encoder.container(keyedBy: CodingKeys.self)
    try c.encode(id, forKey: .id)
    try c.encode(vehicle, forKey: .vehicle)
    try c.encode(inspector, forKey: .inspector)
    try c.encode(startedAt, forKey: .startedAt)
    try c.encodeIfPresent(finishedAt, forKey: .finishedAt)
    try c.encode(status, forKey: .status)
    try c.encode(metrics, forKey: .metrics)
    switch planState {
    case .assigned:
      try c.encode(planState, forKey: .planState)
    case .legacyUnassigned:
      // Omit plan keys so round-trip matches pre-2.1 shape.
      break
    }
    try c.encodeIfPresent(progress, forKey: .progress)
    try c.encodeIfPresent(evidenceBindings, forKey: .evidenceBindings)
    try c.encode(revision, forKey: .revision)
  }
}

/// Immutable evidence-package snapshot of inspection context (not the live mutable session).
///
/// Once persisted with a capture, this context must not be reassigned.
public struct InspectionSessionEvidenceContext: Codable, Sendable, Equatable {
  public static let schemaVersion = "1.1.0"

  public let schemaVersion: String
  public let sessionID: String
  public let primaryVehicleIdentifier: String
  public let primaryVehicleIdentifierKind: String
  public let inspectorID: String
  public let inspectorName: String
  public let sessionStartedAtUTC: String
  /// Session status frozen at capture/approve time (e.g. IN_PROGRESS).
  public let sessionStatusAtCapture: String

  public init(
    schemaVersion: String = InspectionSessionEvidenceContext.schemaVersion,
    sessionID: String,
    primaryVehicleIdentifier: String,
    primaryVehicleIdentifierKind: String,
    inspectorID: String,
    inspectorName: String = "",
    sessionStartedAtUTC: String,
    sessionStatusAtCapture: String = SessionStatus.inProgress.rawValue
  ) {
    self.schemaVersion = schemaVersion
    self.sessionID = sessionID
    self.primaryVehicleIdentifier = primaryVehicleIdentifier
    self.primaryVehicleIdentifierKind = primaryVehicleIdentifierKind
    self.inspectorID = inspectorID
    self.inspectorName = inspectorName
    self.sessionStartedAtUTC = sessionStartedAtUTC
    self.sessionStatusAtCapture = sessionStatusAtCapture
  }

  public static func snapshot(
    from session: InspectionSession,
    startedAtUTC: String
  ) -> InspectionSessionEvidenceContext {
    InspectionSessionEvidenceContext(
      sessionID: session.id.rawValue,
      primaryVehicleIdentifier: session.vehicle.primaryIdentifier.rawValue,
      primaryVehicleIdentifierKind: session.vehicle.primaryIdentifier.kind.rawValue,
      inspectorID: session.inspector.id,
      inspectorName: session.inspector.name,
      sessionStartedAtUTC: startedAtUTC,
      sessionStatusAtCapture: session.status.rawValue
    )
  }

  public func asDictionary() -> [String: Any] {
    [
      "schema_id": "InspectionSessionEvidenceContext",
      "schema_version": schemaVersion,
      "session_id": sessionID,
      "primary_vehicle_identifier": primaryVehicleIdentifier,
      "primary_vehicle_identifier_kind": primaryVehicleIdentifierKind,
      "inspector_id": inspectorID,
      "inspector_name": inspectorName,
      "session_started_at_utc": sessionStartedAtUTC,
      "session_status_at_capture": sessionStatusAtCapture,
    ]
  }

  enum CodingKeys: String, CodingKey {
    case schemaVersion
    case sessionID
    case primaryVehicleIdentifier
    case primaryVehicleIdentifierKind
    case inspectorID
    case inspectorName
    case sessionStartedAtUTC
    case sessionStatusAtCapture
  }

  public init(from decoder: Decoder) throws {
    let c = try decoder.container(keyedBy: CodingKeys.self)
    schemaVersion = try c.decodeIfPresent(String.self, forKey: .schemaVersion) ?? "1.0.0"
    sessionID = try c.decode(String.self, forKey: .sessionID)
    primaryVehicleIdentifier = try c.decode(String.self, forKey: .primaryVehicleIdentifier)
    primaryVehicleIdentifierKind = try c.decode(String.self, forKey: .primaryVehicleIdentifierKind)
    inspectorID = try c.decode(String.self, forKey: .inspectorID)
    inspectorName = try c.decodeIfPresent(String.self, forKey: .inspectorName) ?? ""
    sessionStartedAtUTC = try c.decode(String.self, forKey: .sessionStartedAtUTC)
    sessionStatusAtCapture = try c.decodeIfPresent(String.self, forKey: .sessionStatusAtCapture)
      ?? SessionStatus.inProgress.rawValue
  }

  /// Decode from sidecar / status JSON (supports schema 1.0.0 without status/name).
  public static func decode(from object: [String: Any]) -> InspectionSessionEvidenceContext? {
    guard let sessionID = object["session_id"] as? String, !sessionID.isEmpty else { return nil }
    let vehicle = object["primary_vehicle_identifier"] as? String ?? ""
    let kind = object["primary_vehicle_identifier_kind"] as? String ?? VehicleIdentifierKind.unknown.rawValue
    let inspectorID = object["inspector_id"] as? String ?? ""
    let inspectorName = object["inspector_name"] as? String ?? ""
    let started = object["session_started_at_utc"] as? String ?? ""
    let status = object["session_status_at_capture"] as? String ?? SessionStatus.inProgress.rawValue
    let version = object["schema_version"] as? String ?? "1.0.0"
    return InspectionSessionEvidenceContext(
      schemaVersion: version,
      sessionID: sessionID,
      primaryVehicleIdentifier: vehicle,
      primaryVehicleIdentifierKind: kind,
      inspectorID: inspectorID,
      inspectorName: inspectorName,
      sessionStartedAtUTC: started,
      sessionStatusAtCapture: status
    )
  }
}
