import Foundation

/// Capture-side lifecycle only. The phone must never assign EDTS ingest authority.
public enum CaptureSideStatus: String, Codable, Sendable, CaseIterable {
  case captureCreated = "CAPTURE_CREATED"
  case capturePersisted = "CAPTURE_PERSISTED"
  case captureHashed = "CAPTURE_HASHED"
  case captureSealed = "CAPTURE_SEALED"
  case packageExported = "PACKAGE_EXPORTED"
}

public enum StatusOwner: String, Codable, Sendable {
  case capture = "CAPTURE"
  case edts = "EDTS"
  case joint = "JOINT"
}

/// Machine-readable ownership of status codes.
/// Source of truth mirrored in `Contracts/Compatibility/status-owner-registry.json`.
public enum StatusOwnerRegistry {
  public struct Entry: Sendable {
    public var code: String
    public var owner: StatusOwner
    public var plane: String
  }

  /// Built-in registry — keep in sync with status-owner-registry.json (validated by Scripts/test-status-owner-registry).
  public static let entries: [Entry] = [
    .init(code: "CAPTURE_CREATED", owner: .capture, plane: "runtime_capture"),
    .init(code: "CAPTURE_PERSISTED", owner: .capture, plane: "runtime_capture"),
    .init(code: "CAPTURE_HASHED", owner: .capture, plane: "runtime_capture"),
    .init(code: "CAPTURE_SEALED", owner: .capture, plane: "runtime_capture"),
    .init(code: "PACKAGE_EXPORTED", owner: .capture, plane: "runtime_capture"),
    .init(code: "PACKAGE_RECEIVED", owner: .edts, plane: "runtime_ingest"),
    .init(code: "PACKAGE_QUARANTINED", owner: .edts, plane: "runtime_ingest"),
    .init(code: "PACKAGE_VALIDATED", owner: .edts, plane: "runtime_ingest"),
    .init(code: "REJECTED", owner: .edts, plane: "runtime_ingest"),
    .init(code: "VERIFIED_TRANSPORT_INTEGRITY", owner: .edts, plane: "runtime_ingest"),
    .init(code: "INGESTED_INTEGRITY_VERIFIED", owner: .edts, plane: "runtime_ingest"),
    .init(code: "CONTENT_UNVERIFIED", owner: .edts, plane: "runtime_ingest"),
    .init(code: "COMMITTED_UNVERIFIED_EVIDENCE", owner: .edts, plane: "runtime_ingest"),
    .init(code: "PACKAGE_EXPORT_READY", owner: .capture, plane: "repository_implementation"),
    .init(code: "EDTS_COMPATIBLE", owner: .joint, plane: "repository_implementation"),
    .init(code: "PHASE_1_DIRECTIVE_APPROVED", owner: .capture, plane: "phase_governance"),
    .init(code: "PHASE_1_IMPLEMENTATION_COMPLETE", owner: .capture, plane: "phase_governance"),
    .init(code: "APPROVED_FOR_PHASE_1_PREPARATION", owner: .capture, plane: "phase_governance"),
    .init(code: "EVIDENCE_CUSTODY_UNVERIFIED", owner: .capture, plane: "runtime_custody"),
    .init(code: "EVIDENCE_CUSTODY_VERIFIED", owner: .capture, plane: "runtime_custody"),
    .init(code: "EVIDENCE_CUSTODY_VERIFICATION_FAILED", owner: .capture, plane: "runtime_custody"),
    .init(code: "EVIDENCE_CUSTODY_QUARANTINED", owner: .capture, plane: "runtime_custody"),
    .init(code: "EVIDENCE_CUSTODY_ARCHIVED", owner: .capture, plane: "runtime_custody"),
    .init(code: "DRAFT_ACQUISITION_QUARANTINED", owner: .capture, plane: "runtime_draft_acquisition"),
    .init(code: "PACKAGED_BOUNDARY_REACHED", owner: .capture, plane: "runtime_spatial_boundary"),
  ]

  public static func owner(of code: String) -> StatusOwner? {
    entries.first { $0.code == code }?.owner
  }

  public static func isEdtsOwned(_ code: String) -> Bool {
    owner(of: code) == .edts
  }
}

/// Prevents capture code from self-asserting EDTS-owned status codes.
public enum CaptureSideStatusGuard {
  public static func parseCaptureSide(_ raw: String) throws -> CaptureSideStatus {
    if let status = CaptureSideStatus(rawValue: raw) {
      // Double-check registry agrees these are capture-owned runtime statuses.
      if StatusOwnerRegistry.isEdtsOwned(raw) {
        throw CaptureError.forbiddenAuthorityClaim("EDTS-owned status: \(raw)")
      }
      return status
    }
    if StatusOwnerRegistry.isEdtsOwned(raw) {
      throw CaptureError.forbiddenAuthorityClaim(
        "EDTS-only status asserted by capture client: \(raw)"
      )
    }
    throw CaptureError.contractViolation("Unknown or non-capture-side status: \(raw)")
  }
}
