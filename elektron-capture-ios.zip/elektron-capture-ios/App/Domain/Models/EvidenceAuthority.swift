import Foundation

/// Evidence authority classification — never auto-promote.
public enum EvidenceAuthority: String, Codable, Sendable, CaseIterable {
  case rawObservation = "RAW_OBSERVATION"
  case deviceReported = "DEVICE_REPORTED"
  case guidanceEstimate = "GUIDANCE_ESTIMATE"
  case algorithmEstimate = "ALGORITHM_ESTIMATE"
  case physicalReference = "PHYSICAL_REFERENCE"
  case fieldValidated = "FIELD_VALIDATED"
  case engineeringVerified = "ENGINEERING_VERIFIED"
  /// Linux/controllable fixture evidence — never promotes to DEVICE_REPORTED.
  case testFixture = "TEST_FIXTURE"
  case rejected = "REJECTED"
  case unknown = "UNKNOWN"
}

public enum UncertaintyStatus: String, Codable, Sendable {
  case known = "KNOWN"
  case unknown = "UNKNOWN"
}

public struct UncertainValue: Equatable, Sendable, Codable {
  public var value: Double
  public var unit: String
  public var uncertaintyPlusMinus: Double?
  public var uncertaintyStatus: UncertaintyStatus
  public var authority: EvidenceAuthority
  public var method: String?
  public var evidenceIds: [String]

  public init(
    value: Double,
    unit: String,
    uncertaintyPlusMinus: Double? = nil,
    uncertaintyStatus: UncertaintyStatus = .unknown,
    authority: EvidenceAuthority,
    method: String? = nil,
    evidenceIds: [String] = []
  ) {
    self.value = value
    self.unit = unit
    self.uncertaintyPlusMinus = uncertaintyPlusMinus
    self.uncertaintyStatus = uncertaintyPlusMinus == nil ? .unknown : uncertaintyStatus
    self.authority = authority
    self.method = method
    self.evidenceIds = evidenceIds
  }
}

public enum CalibrationSource: String, Codable, Sendable, CaseIterable {
  case appleReported = "APPLE_REPORTED"
  case arkitReported = "ARKit_REPORTED"
  case targetCalibrated = "TARGET_CALIBRATED"
  case fieldRevalidated = "FIELD_REVALIDATED"
  case thirdPartyEstimated = "THIRD_PARTY_ESTIMATED"
  case unknown = "UNKNOWN"
  case expired = "EXPIRED"
  case rejected = "REJECTED"
}

public enum ClockDomain: String, Codable, Sendable, CaseIterable {
  case wall = "wall"
  case monotonicUptime = "monotonic_uptime"
  case arkitFrame = "arkit_frame"
  case coreMotion = "core_motion"
  case avfoundationCapture = "avfoundation_capture"
  case serverReceipt = "server_receipt"
  case serverChallenge = "server_challenge"
  /// Deterministic synthetic / simulator replay domain (Phase 3 vertical slice). Additive; does not reinterpret historical packages.
  case syntheticDeterministic = "synthetic_deterministic"
  /// Neutral fixture camera clock (Sprint 3.3) — does not imply AVFoundation.
  case fixtureCamera = "fixture_camera"
  /// Neutral fixture depth clock (Sprint 3.3) — does not imply ARKit/LiDAR.
  case fixtureDepth = "fixture_depth"
  /// Neutral fixture motion clock (Sprint 3.4) — does not imply CoreMotion.
  case fixtureMotion = "fixture_motion"
}

public struct TimestampValue: Equatable, Sendable, Codable {
  public var value: Double
  public var clockDomain: ClockDomain
  public var iso8601: String?
  public var mappingMethod: String?
  public var mappingResidual: Double?

  public init(
    value: Double,
    clockDomain: ClockDomain,
    iso8601: String? = nil,
    mappingMethod: String? = nil,
    mappingResidual: Double? = nil
  ) {
    self.value = value
    self.clockDomain = clockDomain
    self.iso8601 = iso8601
    self.mappingMethod = mappingMethod
    self.mappingResidual = mappingResidual
  }
}

public enum VehicleIdentityStatus: String, Codable, Sendable {
  case nominalConfiguration = "NOMINAL_CONFIGURATION"
  case observedConfiguration = "OBSERVED_CONFIGURATION"
  case verifiedConfiguration = "VERIFIED_CONFIGURATION"
  case conflictDetected = "CONFLICT_DETECTED"
  case unresolved = "UNRESOLVED"
}

public enum CoverageStage: String, Codable, Sendable, CaseIterable {
  case notObserved = "NOT_OBSERVED"
  case frustumIntersected = "FRUSTUM_INTERSECTED"
  case depthSupported = "DEPTH_SUPPORTED"
  case surfaceAssociated = "SURFACE_ASSOCIATED"
  case imageSupported = "IMAGE_SUPPORTED"
  case overlapSupported = "OVERLAP_SUPPORTED"
  case reconstructionSupported = "RECONSTRUCTION_SUPPORTED"
  case technicianConfirmed = "TECHNICIAN_CONFIRMED"
  case verifiedCapture = "VERIFIED_CAPTURE"
}

public enum CaptureExceptionType: String, Codable, Sendable, CaseIterable {
  case physicalAccessBlocked = "PHYSICAL_ACCESS_BLOCKED"
  case componentNotPresent = "COMPONENT_NOT_PRESENT"
  case configurationMismatch = "CONFIGURATION_MISMATCH"
  case deviceCapabilityMissing = "DEVICE_CAPABILITY_MISSING"
  case environmentUnsafe = "ENVIRONMENT_UNSAFE"
  case lightingUnacceptable = "LIGHTING_UNACCEPTABLE"
  case calibrationExpired = "CALIBRATION_EXPIRED"
  case vehicleModified = "VEHICLE_MODIFIED"
  case requirementNotApplicable = "REQUIREMENT_NOT_APPLICABLE"
  case supervisorOverrideRequested = "SUPERVISOR_OVERRIDE_REQUESTED"
}
