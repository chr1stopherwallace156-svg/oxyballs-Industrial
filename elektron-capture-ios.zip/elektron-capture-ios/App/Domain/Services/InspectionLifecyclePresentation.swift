import Foundation

/// Inspection **workflow** lifecycle presentation (Sprint 2.1F gated parity).
///
/// Derived from the authoritative ``InspectionSession`` + progression facts.
/// Does **not** introduce new persisted ``SessionStatus`` wire values (envelope v1 unchanged).
///
/// **Explicitly separate from export readiness** — a completed inspection may still be
/// export-blocked; export readiness comes only from ``InspectionExportPolicy`` /
/// ``InspectionValidationReport``.
public enum InspectionLifecyclePresentation: String, Equatable, Sendable {
  case inProgress
  case readyForReview
  case completed
  case exported
  case paused
  case canceled

  public var displayName: String {
    switch self {
    case .inProgress: return "In Progress"
    case .readyForReview: return "Ready for Review"
    case .completed: return "Completed"
    case .exported: return "Exported"
    case .paused: return "Paused"
    case .canceled: return "Canceled"
    }
  }
}

/// Decoupled operator-facing readiness: workflow lifecycle ≠ export readiness.
public struct InspectionOperatorReadiness: Equatable, Sendable {
  public let lifecycle: InspectionLifecyclePresentation
  public let disposition: InspectionCompletionDisposition
  public let isExportReady: Bool
  public let exportBlockedMessages: [String]

  public var lifecycleLabel: String { lifecycle.displayName }

  public var exportLabel: String {
    isExportReady ? "Export Ready" : "Export Blocked"
  }
}

/// Pure derivation + completion gating for inspection lifecycle presentation.
public enum InspectionLifecycleEvaluator: Sendable {
  /// Workflow lifecycle only. `hasExportedPackage` may promote **completed** → **exported**;
  /// it never marks an incomplete inspection as completed or exported.
  public static func presentation(
    for session: InspectionSession,
    hasExportedPackage: Bool = false
  ) -> InspectionLifecyclePresentation {
    switch session.status {
    case .paused:
      return .paused
    case .canceled:
      return .canceled
    case .completed:
      // Exported is completion history, not a substitute for unresolved workflow.
      return hasExportedPackage ? .exported : .completed
    case .inProgress:
      if canCommitCompletion(session) { return .readyForReview }
      return .inProgress
    }
  }

  /// Combines lifecycle with export policy without collapsing them into one flag.
  public static func readiness(
    for session: InspectionSession,
    hasExportedPackage: Bool = false,
    validator: InspectionPreExportValidator = InspectionPreExportValidator(),
    policy: InspectionExportPolicy = InspectionExportPolicy()
  ) -> InspectionOperatorReadiness {
    let lifecycle = presentation(for: session, hasExportedPackage: hasExportedPackage)
    let raw = validator.validate(session)
    let decision = policy.evaluate(session: session, validationReport: raw)
    return InspectionOperatorReadiness(
      lifecycle: lifecycle,
      disposition: decision.report.disposition,
      isExportReady: decision.isAllowed,
      exportBlockedMessages: decision.report.blockingFindings.map(\.message)
    )
  }

  /// True when every required point is terminal via completed/skipped (not blocked/open).
  public static func canCommitCompletion(_ session: InspectionSession) -> Bool {
    guard session.status == .inProgress || session.status == .paused else { return false }
    guard session.inspectionPlanSnapshot != nil else { return false }
    let progression = InspectionProgressionEngine()
    switch progression.evaluateCompletion(of: session) {
    case .complete:
      break
    case .incomplete, .blocked:
      return false
    }
    guard let snapshot = session.inspectionPlanSnapshot,
      let progress = session.progress
    else { return false }
    let required = Set(snapshot.points.filter(\.isRequired).map(\.id))
    for row in progress.orderedPoints where required.contains(row.pointID) {
      switch row.status {
      case .completed, .skipped:
        continue
      case .blocked, .notStarted, .inProgress:
        return false
      }
    }
    return true
  }

  public static func completionBlockReason(for session: InspectionSession) -> String? {
    guard session.status == .inProgress || session.status == .paused else {
      return "Inspection is not active."
    }
    if canCommitCompletion(session) { return nil }
    let progression = InspectionProgressionEngine()
    switch progression.evaluateCompletion(of: session) {
    case .blocked:
      return "Cannot complete: one or more required points are blocked."
    case .incomplete:
      return "Cannot complete: required points still need Mark Complete, Skip, or more evidence."
    case .complete:
      return "Cannot complete: inspection is not ready for review."
    }
  }
}
