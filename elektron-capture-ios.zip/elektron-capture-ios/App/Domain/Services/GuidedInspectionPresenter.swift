import Foundation

/// Derives guided overlay presentation from authoritative session + snapshot facts.
///
/// Enablement policy (Sprint 2.1E HUD):
/// - **Complete** requires evidence satisfaction on the active open point.
/// - **Next** stays disabled until the active point is satisfied **or** already terminal,
///   and a non-terminal successor exists in frozen order.
public enum GuidedInspectionPresenter: Sendable {
  public static func makeState(
    from session: InspectionSession?,
    binding: EvidenceBindingService = EvidenceBindingService(),
    progression: InspectionProgressionEngine = InspectionProgressionEngine()
  ) -> GuidedInspectionPresentationState {
    guard let session else { return .unavailable }
    // Terminal / missing sessions must not render an "active" HUD alongside
    // a "No active inspection" banner — one authoritative active-session rule.
    guard session.status.isActiveOrPaused else { return .unavailable }
    guard let snapshot = session.inspectionPlanSnapshot else {
      return .unavailable
    }

    let progress = session.progress
    let activeID = progress?.activePointID
    let activePoint = snapshot.points.first { $0.id == activeID }
    let activeStatus = activeID.flatMap { progress?.progress(for: $0)?.status }
    let activeOrdinal: Int = {
      guard let activeID, let idx = snapshot.points.firstIndex(where: { $0.id == activeID }) else {
        return 0
      }
      return idx + 1
    }()

    let evidenceCount: Int
    let requiredCount: Int
    let satisfied: Bool
    if let activeID, let activePoint {
      evidenceCount = binding.evidenceCount(for: activeID, in: session)
      requiredCount = InspectionEvidenceRequirement.requiredBindingCount(for: activePoint)
      satisfied = binding.isPointSatisfied(pointID: activeID, in: session)
    } else {
      evidenceCount = 0
      requiredCount = 0
      satisfied = false
    }

    let sessionReady = session.status == .inProgress
    let activeIsOpen: Bool = {
      guard let activeStatus else { return false }
      return !activeStatus.isTerminal
    }()
    let activeIsTerminal = activeStatus?.isTerminal == true
    let advanceUnlocked = satisfied || activeIsTerminal

    let canAdvance =
      sessionReady && advanceUnlocked && canAdvanceEligible(session: session)
    let canReturn = sessionReady && canReturnEligible(session: session)
    let canComplete = sessionReady && activeIsOpen && (activeStatus == .inProgress) && satisfied
    let canSkip = sessionReady && activeIsOpen
    let canBlock = sessionReady && activeIsOpen
    let canCapture = sessionReady && activeIsOpen
    let canPrepare = sessionReady && (progress == nil || activeID == nil)

    let summaries: [GuidedInspectionPointSummary] = snapshot.points.map { point in
      let status = progress?.progress(for: point.id)?.status
      let count = binding.evidenceCount(for: point.id, in: session)
      let required = InspectionEvidenceRequirement.requiredBindingCount(for: point)
      return GuidedInspectionPointSummary(
        pointID: point.id,
        title: point.title,
        isRequired: point.isRequired,
        status: status,
        evidenceCount: count,
        requiredCount: required,
        isSatisfied: binding.isPointSatisfied(pointID: point.id, in: session),
        isActive: point.id == activeID
      )
    }

    let terminalCount = summaries.filter { $0.status?.isTerminal == true }.count
    let percent =
      summaries.isEmpty ? 0 : Int((Double(terminalCount) / Double(summaries.count) * 100).rounded())

    return GuidedInspectionPresentationState(
      isGuidedAvailable: true,
      activePointID: activeID,
      activePointTitle: activePoint?.title,
      guidanceText: activePoint?.guidanceInstruction,
      activeStatus: activeStatus,
      activePointOrdinal: activeOrdinal,
      totalPoints: snapshot.points.count,
      planProgressPercent: percent,
      evidenceCount: evidenceCount,
      requiredCount: requiredCount,
      isPointSatisfied: satisfied,
      canAdvance: canAdvance,
      canReturn: canReturn,
      canComplete: canComplete,
      canSkip: canSkip,
      canBlock: canBlock,
      canCapture: canCapture,
      canPrepare: canPrepare,
      completionDisposition: progression.evaluateCompletion(of: session),
      points: summaries
    )
  }

  private static func canAdvanceEligible(session: InspectionSession) -> Bool {
    guard let progress = session.progress,
      let active = progress.activePointID,
      let index = progress.index(of: active)
    else { return false }
    let next = index + 1
    guard next < progress.orderedPoints.count else { return false }
    return !progress.orderedPoints[next].status.isTerminal
  }

  private static func canReturnEligible(session: InspectionSession) -> Bool {
    guard let progress = session.progress,
      let active = progress.activePointID,
      let index = progress.index(of: active)
    else { return false }
    let prev = index - 1
    guard prev >= 0 else { return false }
    return !progress.orderedPoints[prev].status.isTerminal
  }
}
