import Foundation

// MARK: - Severity / codes

public enum InspectionValidationSeverity: String, Equatable, Sendable {
  case error
  case warning
  case information
}

/// Stable finding codes for tests and diagnostics (technician message is separate).
public enum InspectionValidationCode: String, Equatable, Sendable {
  case missingPlanSnapshot
  case progressNotInitialized
  case sessionNotExportable
  case incompletePoint
  case insufficientEvidence
  case requiredPointBlocked
  case unknownPointBinding
  case duplicateEvidenceID
  case emptyStorageKey
  case invalidSessionOwnership
  case missingSkipReason
  case missingBlockReason
  case orphanedEvidence
  case packageMetadataUnavailable
}

public struct InspectionValidationFinding: Identifiable, Equatable, Sendable {
  public let id: String
  public let severity: InspectionValidationSeverity
  public let code: InspectionValidationCode
  public let pointID: InspectionPointID?
  public let message: String

  public init(
    id: String,
    severity: InspectionValidationSeverity,
    code: InspectionValidationCode,
    pointID: InspectionPointID? = nil,
    message: String
  ) {
    self.id = id
    self.severity = severity
    self.code = code
    self.pointID = pointID
    self.message = message
  }
}

// MARK: - Per-point readiness (derived)

public enum InspectionPointExportReadiness: Equatable, Sendable {
  case satisfied
  case skipped(reason: String)
  case blocked(reason: String)
  case open(InspectionPointStatus)
  case insufficientEvidence(boundCount: Int, requiredCount: Int)
}

public struct InspectionPointValidationRow: Equatable, Sendable, Identifiable {
  public var id: InspectionPointID { pointID }
  public let pointID: InspectionPointID
  public let sequenceNumber: Int
  public let title: String
  public let isRequired: Bool
  public let status: InspectionPointStatus?
  public let boundCount: Int
  public let requiredCount: Int
  public let isSatisfied: Bool
  public let readiness: InspectionPointExportReadiness
  public let blocksExport: Bool

  public var statusTag: String {
    switch readiness {
    case .satisfied: return "✓ Satisfied"
    case .skipped(let reason): return "Skipped — \(reason)"
    case .blocked(let reason): return "Blocked — \(reason)"
    case .open(let s):
      // Evidence may already meet the plan requirement while workflow awaits explicit complete.
      if isSatisfied {
        return "Evidence satisfied — ready to complete"
      }
      switch s {
      case .notStarted: return "Not started"
      case .inProgress: return "In progress"
      default: return "Incomplete"
      }
    case .insufficientEvidence(let b, let r):
      return "● Needs Evidence (\(b) of \(r))"
    }
  }
}

public struct InspectionExportPreviewItem: Equatable, Sendable, Identifiable {
  public var id: String { storageKey }
  public let pointID: InspectionPointID
  public let pointTitle: String
  public let evidenceID: EvidenceID
  public let storageKey: String
  public let evidenceType: EvidenceType
  public let libraryEvidenceIdHint: String?
}

public struct InspectionValidationReport: Equatable, Sendable {
  public let sessionID: SessionID?
  public let isExportReady: Bool
  public let findings: [InspectionValidationFinding]
  public let disposition: InspectionCompletionDisposition
  public let points: [InspectionPointValidationRow]
  public let exportPreview: [InspectionExportPreviewItem]
  public let satisfiedRequiredCount: Int
  public let requiredPointCount: Int
  public let skippedRequiredCount: Int
  public let blockedRequiredCount: Int
  public let planTitle: String?
  public let planVersion: String?
  public let proposedExportFilename: String

  /// Back-compat alias used by early 2.1F UI.
  public var isExportable: Bool { isExportReady }

  public var blockingFindings: [InspectionValidationFinding] {
    findings.filter { $0.severity == .error }
  }

  public var warningFindings: [InspectionValidationFinding] {
    findings.filter { $0.severity == .warning }
  }

  public var summaryLine: String {
    if isExportReady {
      return "Export ready — \(exportPreview.count) evidence item(s), \(satisfiedRequiredCount)/\(requiredPointCount) required points resolved."
    }
    let n = blockingFindings.count
    return n == 0 ? "Export not ready." : "Export blocked — \(n) issue(s) require attention."
  }

  /// Canonical presentation-safe report when no active inspection session exists.
  /// Keeps report construction inside the domain module while allowing app targets
  /// to initialize review UI without exposing the full memberwise initializer.
  public static func noActiveSession() -> InspectionValidationReport {
    InspectionValidationReport(
      sessionID: nil,
      isExportReady: false,
      findings: [
        InspectionValidationFinding(
          id: "missingPlanSnapshot:session",
          severity: .error,
          code: .missingPlanSnapshot,
          message: "No active inspection session."
        )
      ],
      disposition: .incomplete,
      points: [],
      exportPreview: [],
      satisfiedRequiredCount: 0,
      requiredPointCount: 0,
      skippedRequiredCount: 0,
      blockedRequiredCount: 0,
      planTitle: nil,
      planVersion: nil,
      proposedExportFilename: "inspection-evidence.edts-pkg"
    )
  }
}

/// Back-compat name from the first 2.1F slice.
public typealias PreExportValidationReport = InspectionValidationReport

// MARK: - Export policy (explicit skip/block rules)

public struct InspectionExportDecision: Equatable, Sendable {
  public let isAllowed: Bool
  public let report: InspectionValidationReport

  public init(isAllowed: Bool, report: InspectionValidationReport) {
    self.isAllowed = isAllowed
    self.report = report
  }
}

/// Documents and applies export allowance rules on top of structural validation.
///
/// **Skip:** required skipped points with non-blank reasons **permit** export.
/// **Block:** required blocked points **deny** export.
public struct InspectionExportPolicy: Sendable {
  public init() {}

  public func evaluate(
    session: InspectionSession,
    validationReport: InspectionValidationReport
  ) -> InspectionExportDecision {
    _ = session
    return InspectionExportDecision(
      isAllowed: validationReport.isExportReady,
      report: validationReport
    )
  }
}

// MARK: - Validator

/// Stateless pre-export validation (Sprint 2.1F).
/// Pure: `(InspectionSession) → InspectionValidationReport`.
public struct InspectionPreExportValidator: Sendable {
  private let binding: EvidenceBindingService
  private let progression: InspectionProgressionEngine

  public init(
    binding: EvidenceBindingService = EvidenceBindingService(),
    progression: InspectionProgressionEngine = InspectionProgressionEngine()
  ) {
    self.binding = binding
    self.progression = progression
  }

  public func validate(session: InspectionSession) -> InspectionValidationReport {
    validate(session)
  }

  public func validate(_ session: InspectionSession) -> InspectionValidationReport {
    var findings: [InspectionValidationFinding] = []

    guard let snapshot = session.inspectionPlanSnapshot else {
      findings.append(
        finding(
          code: .missingPlanSnapshot,
          severity: .error,
          message: "No frozen inspection plan is assigned to this session."
        )
      )
      return assemble(
        session: session,
        snapshot: nil,
        findings: findings,
        points: [],
        preview: []
      )
    }

    if snapshot.points.isEmpty {
      findings.append(
        finding(
          code: .missingPlanSnapshot,
          severity: .error,
          message: "Frozen plan snapshot contains no inspection points."
        )
      )
    }

    if session.progress == nil {
      findings.append(
        finding(
          code: .progressNotInitialized,
          severity: .error,
          message: "Guided progress has not been initialized."
        )
      )
    }

    switch session.status {
    case .inProgress, .completed:
      break
    case .paused, .canceled:
      findings.append(
        finding(
          code: .sessionNotExportable,
          severity: .error,
          message: "Session status is \(session.status.displayName); export is not available."
        )
      )
    }

    // Binding integrity (all bindings, required or not)
    findings.append(contentsOf: bindingIntegrityFindings(session: session, snapshot: snapshot))

    let pointRows = rows(snapshot: snapshot, session: session)
    for row in pointRows {
      findings.append(contentsOf: pointFindings(row: row))
    }

    // Deterministic order: severity (error first), then code, then id
    findings.sort { lhs, rhs in
      let ls = severityRank(lhs.severity)
      let rs = severityRank(rhs.severity)
      if ls != rs { return ls < rs }
      if lhs.code.rawValue != rhs.code.rawValue {
        return lhs.code.rawValue < rhs.code.rawValue
      }
      return lhs.id < rhs.id
    }

    // Deduplicate by id
    var seen = Set<String>()
    findings = findings.filter { seen.insert($0.id).inserted }

    let preview = previewItems(snapshot: snapshot, session: session)
    return assemble(
      session: session,
      snapshot: snapshot,
      findings: findings,
      points: pointRows,
      preview: preview
    )
  }

  // MARK: - Internals

  private func assemble(
    session: InspectionSession,
    snapshot: InspectionPlanSnapshot?,
    findings: [InspectionValidationFinding],
    points: [InspectionPointValidationRow],
    preview: [InspectionExportPreviewItem]
  ) -> InspectionValidationReport {
    let requiredRows = points.filter(\.isRequired)
    let satisfiedRequired = requiredRows.filter {
      if case .satisfied = $0.readiness { return true }
      if case .skipped = $0.readiness { return true }
      return false
    }.count
    let skippedRequired = requiredRows.filter {
      if case .skipped = $0.readiness { return true }
      return false
    }.count
    let blockedRequired = requiredRows.filter {
      if case .blocked = $0.readiness { return true }
      return false
    }.count

    let hasErrors = findings.contains { $0.severity == .error }
    let exportReady = !hasErrors
      && (session.status == .inProgress || session.status == .completed)
      && snapshot != nil

    let filename = "\(session.id.rawValue)-evidence.edts-pkg"
    return InspectionValidationReport(
      sessionID: session.id,
      isExportReady: exportReady,
      findings: findings,
      disposition: progression.evaluateCompletion(of: session),
      points: points,
      exportPreview: preview,
      satisfiedRequiredCount: satisfiedRequired,
      requiredPointCount: requiredRows.count,
      skippedRequiredCount: skippedRequired,
      blockedRequiredCount: blockedRequired,
      planTitle: snapshot?.title,
      planVersion: snapshot?.planVersion,
      proposedExportFilename: filename
    )
  }

  private func rows(
    snapshot: InspectionPlanSnapshot,
    session: InspectionSession
  ) -> [InspectionPointValidationRow] {
    snapshot.points.enumerated().map { index, point in
      let status = session.progress?.progress(for: point.id)?.status
      let bound = binding.evidenceCount(for: point.id, in: session)
      let required = InspectionEvidenceRequirement.requiredBindingCount(for: point)
      let satisfied = binding.isPointSatisfied(pointID: point.id, in: session)
      let readiness = readiness(
        isRequired: point.isRequired,
        status: status,
        satisfied: satisfied,
        bound: bound,
        required: required
      )
      let blocks = point.isRequired && blocksExport(readiness)
      return InspectionPointValidationRow(
        pointID: point.id,
        sequenceNumber: index + 1,
        title: point.title,
        isRequired: point.isRequired,
        status: status,
        boundCount: bound,
        requiredCount: required,
        isSatisfied: satisfied,
        readiness: readiness,
        blocksExport: blocks
      )
    }
  }

  private func readiness(
    isRequired: Bool,
    status: InspectionPointStatus?,
    satisfied: Bool,
    bound: Int,
    required: Int
  ) -> InspectionPointExportReadiness {
    switch status {
    case .skipped(let reason):
      return .skipped(reason: reason)
    case .blocked(let reason):
      return .blocked(reason: reason)
    case .completed:
      if satisfied { return .satisfied }
      return .insufficientEvidence(boundCount: bound, requiredCount: required)
    case .notStarted, .inProgress, .none:
      if !isRequired && (status == nil || status == .notStarted) {
        return satisfied ? .satisfied : .open(status ?? .notStarted)
      }
      if bound < required {
        return .insufficientEvidence(boundCount: bound, requiredCount: required)
      }
      return .open(status ?? .notStarted)
    }
  }

  private func blocksExport(_ readiness: InspectionPointExportReadiness) -> Bool {
    switch readiness {
    case .satisfied, .skipped: return false
    case .blocked, .open, .insufficientEvidence: return true
    }
  }

  private func pointFindings(row: InspectionPointValidationRow) -> [InspectionValidationFinding] {
    guard row.isRequired else { return [] }
    switch row.readiness {
    case .satisfied:
      return []
    case .skipped(let reason):
      let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
      if trimmed.isEmpty {
        return [
          finding(
            code: .missingSkipReason,
            severity: .error,
            pointID: row.pointID,
            message: "“\(row.title)” is skipped but has no reason."
          )
        ]
      }
      // Valid skip permits export — no blocking finding.
      return []
    case .blocked(let reason):
      let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
      if trimmed.isEmpty {
        return [
          finding(
            code: .missingBlockReason,
            severity: .error,
            pointID: row.pointID,
            message: "“\(row.title)” is blocked but has no reason."
          )
        ]
      }
      return [
        finding(
          code: .requiredPointBlocked,
          severity: .error,
          pointID: row.pointID,
          message: "“\(row.title)” is blocked: \(trimmed)"
        )
      ]
    case .open:
      return [
        finding(
          code: .incompletePoint,
          severity: .error,
          pointID: row.pointID,
          message: "“\(row.title)” still needs to be completed or skipped."
        )
      ]
    case .insufficientEvidence(let bound, let required):
      return [
        finding(
          code: .insufficientEvidence,
          severity: .error,
          pointID: row.pointID,
          message: "“\(row.title)” needs \(required - bound) more photo(s) (\(bound) of \(required))."
        )
      ]
    }
  }

  private func bindingIntegrityFindings(
    session: InspectionSession,
    snapshot: InspectionPlanSnapshot
  ) -> [InspectionValidationFinding] {
    var out: [InspectionValidationFinding] = []
    let bindings = session.evidenceBindings?.bindings ?? []
    let knownPoints = Set(snapshot.points.map(\.id))
    var seenIDs = Set<UUID>()

    for meta in bindings {
      if !knownPoints.contains(meta.pointID) {
        out.append(
          finding(
            code: .unknownPointBinding,
            severity: .error,
            pointID: meta.pointID,
            message: "Evidence is bound to unknown point “\(meta.pointID.rawValue)”."
          )
        )
      }
      if meta.sessionID != session.id {
        out.append(
          finding(
            code: .invalidSessionOwnership,
            severity: .error,
            pointID: meta.pointID,
            message: "Evidence does not belong to this inspection session."
          )
        )
      }
      let key = meta.storageKey.trimmingCharacters(in: .whitespacesAndNewlines)
      if key.isEmpty {
        out.append(
          finding(
            code: .emptyStorageKey,
            severity: .error,
            pointID: meta.pointID,
            message: "Evidence for “\(meta.pointID.rawValue)” has a blank storage key."
          )
        )
      }
      if !seenIDs.insert(meta.id.rawValue).inserted {
        out.append(
          finding(
            code: .duplicateEvidenceID,
            severity: .error,
            pointID: meta.pointID,
            message: "Duplicate evidence ID \(meta.id.rawValue.uuidString)."
          )
        )
      }
    }
    return out
  }

  private func previewItems(
    snapshot: InspectionPlanSnapshot,
    session: InspectionSession
  ) -> [InspectionExportPreviewItem] {
    let titleByID = Dictionary(uniqueKeysWithValues: snapshot.points.map { ($0.id, $0.title) })
    let bindings = session.evidenceBindings?.bindings ?? []
    return bindings.map { meta in
      InspectionExportPreviewItem(
        pointID: meta.pointID,
        pointTitle: titleByID[meta.pointID] ?? meta.pointID.rawValue,
        evidenceID: meta.id,
        storageKey: meta.storageKey,
        evidenceType: meta.type,
        libraryEvidenceIdHint: Self.libraryIdHint(from: meta.storageKey)
      )
    }
  }

  public static func libraryIdHint(from storageKey: String) -> String? {
    let parts = storageKey.split(separator: "/", omittingEmptySubsequences: false).map(String.init)
    guard parts.count >= 4 else { return nil }
    let fragment = parts.last?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    return fragment.isEmpty ? nil : fragment
  }

  private func finding(
    code: InspectionValidationCode,
    severity: InspectionValidationSeverity,
    pointID: InspectionPointID? = nil,
    message: String
  ) -> InspectionValidationFinding {
    let suffix = pointID?.rawValue ?? "session"
    return InspectionValidationFinding(
      id: "\(code.rawValue):\(suffix)",
      severity: severity,
      code: code,
      pointID: pointID,
      message: message
    )
  }

  private func severityRank(_ s: InspectionValidationSeverity) -> Int {
    switch s {
    case .error: return 0
    case .warning: return 1
    case .information: return 2
    }
  }
}

/// Back-compat alias for the first 2.1F slice name.
public typealias PreExportValidationService = InspectionPreExportValidator

// MARK: - Presentation grouping (library / review — not persisted)

public struct EvidencePointSectionPresentation: Identifiable, Equatable, Sendable {
  public var id: String { pointID?.rawValue ?? "unassigned" }
  public let pointID: InspectionPointID?
  public let sequenceNumber: Int
  public let title: String
  public let statusLabel: String
  public let evidenceCount: Int
  public let requiredCount: Int
  public let isSatisfied: Bool
  public let requiresAttention: Bool
  public let reason: String?
  public let captures: [EvidenceLibraryIndexRecord]

  public init(
    pointID: InspectionPointID?,
    sequenceNumber: Int,
    title: String,
    statusLabel: String,
    evidenceCount: Int,
    requiredCount: Int,
    isSatisfied: Bool,
    requiresAttention: Bool,
    reason: String?,
    captures: [EvidenceLibraryIndexRecord]
  ) {
    self.pointID = pointID
    self.sequenceNumber = sequenceNumber
    self.title = title
    self.statusLabel = statusLabel
    self.evidenceCount = evidenceCount
    self.requiredCount = requiredCount
    self.isSatisfied = isSatisfied
    self.requiresAttention = requiresAttention
    self.reason = reason
    self.captures = captures
  }
}

public enum EvidencePointSectionPresenter {
  /// Derives technician-facing sections from frozen snapshot order + library group + live session.
  public static func sections(
    group: InspectionEvidenceGroup,
    session: InspectionSession?,
    validator: InspectionPreExportValidator = InspectionPreExportValidator()
  ) -> [EvidencePointSectionPresentation] {
    let legacy = InspectionPointEvidenceGrouping.sections(group: group, session: session)
    let report = session.map { validator.validate($0) }
    return legacy.enumerated().map { index, section in
      let row = report?.points.first { $0.pointID == section.pointID }
      let seq = row?.sequenceNumber ?? (index + 1)
      let status = row?.statusTag ?? section.statusLabel
      let reason: String? = {
        guard let readiness = row?.readiness else { return nil }
        switch readiness {
        case .skipped(let r), .blocked(let r): return r
        default: return nil
        }
      }()
      return EvidencePointSectionPresentation(
        pointID: section.pointID,
        sequenceNumber: seq,
        title: section.title,
        statusLabel: status,
        evidenceCount: section.boundCount,
        requiredCount: section.requiredCount,
        isSatisfied: section.isSatisfied,
        requiresAttention: row?.blocksExport ?? section.needsMoreEvidence,
        reason: reason,
        captures: section.captures
      )
    }
  }
}
