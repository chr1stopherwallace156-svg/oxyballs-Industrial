import Foundation

// MARK: - Intents (presentation → coordinator)

/// Discrete guided-inspection intents. Views emit these; they never build domain bindings.
public enum GuidedInspectionIntent: Equatable, Sendable {
  /// Initialize progress (idempotent) and activate the first eligible non-terminal point.
  case prepareGuidedSession
  case activatePoint(InspectionPointID)
  case advanceRequested
  case returnRequested
  case completePointRequested
  case skipRequested(reason: String)
  case blockRequested(reason: String)
  /// UI signal that the operator wants a capture. Coordinator validates readiness only;
  /// camera shutter remains outside this domain path.
  case captureRequested
  /// Bind an already-approved capture's opaque storage key to the active point.
  case bindApprovedCapture(
    storageKey: String,
    type: EvidenceType,
    attributes: [String: String]
  )
  /// Soft-remove bindings whose storage keys reference a library evidence id.
  case unbindLibraryEvidence(libraryEvidenceId: String)
  /// Replace a library-bound evidence item with a newly approved capture (Sprint 2.1E.1).
  /// Preserves the original pointID; satisfaction is re-derived from the returned session.
  case replaceLibraryEvidence(
    oldLibraryEvidenceId: String,
    storageKey: String,
    type: EvidenceType,
    attributes: [String: String]
  )
  /// Clear all bindings for a point (media quarantine is a separate local-media step).
  case clearPointEvidence(InspectionPointID)
  /// Explicit manual assignment of an unlinked library capture to a plan point.
  case assignLibraryEvidenceToPoint(
    libraryEvidenceId: String,
    pointID: InspectionPointID,
    type: EvidenceType,
    attributes: [String: String]
  )
  /// Skip/block a specific point (activates it first when needed).
  case skipPoint(InspectionPointID, reason: String)
  case blockPoint(InspectionPointID, reason: String)
  /// Sprint 2.1F — refresh review/validation projection (no session mutation).
  case reviewInspectionRequested
  case refreshValidationRequested
  /// Sprint 2.1F — review finding → activate point (progression mutation + persist).
  case reviewPointRequested(InspectionPointID)
  /// Sprint 2.1F — TOCTOU re-validate before existing package export path.
  case generateExportRequested
  /// Commit session-level completion only when lifecycle gating permits.
  case commitSessionCompletionRequested
}

// MARK: - Presentation errors

/// Structured errors for UI mapping — not flattened free-text from domain internals.
public enum GuidedInspectionPresentationError: Error, Equatable, Sendable {
  case noActiveSession
  case planNotAssigned
  case progressUnavailable
  case noActivePoint
  case captureNotReady(String)
  case emptySkipReason
  case emptyBlockReason
  case exportBlocked([InspectionValidationFinding])
  case completionNotAllowed(String)
  case progression(InspectionProgressionError)
  case evidenceBinding(EvidenceBindingError)
  case persistence(String)
}

// MARK: - Ephemeral UI state (never persisted on InspectionSession)

/// Presentation-only memory: dialogs, drafts, in-flight flags, alerts.
/// Must never be encoded onto ``InspectionSession`` / ``InspectionProgressState``.
public struct GuidedInspectionUIState: Equatable, Sendable {
  public var showingSkipDialog: Bool
  public var showingBlockDialog: Bool
  public var captureInProgress: Bool
  public var alert: PresentationAlert?
  public var draftSkipReason: String
  public var draftBlockReason: String

  public init(
    showingSkipDialog: Bool = false,
    showingBlockDialog: Bool = false,
    captureInProgress: Bool = false,
    alert: PresentationAlert? = nil,
    draftSkipReason: String = "",
    draftBlockReason: String = ""
  ) {
    self.showingSkipDialog = showingSkipDialog
    self.showingBlockDialog = showingBlockDialog
    self.captureInProgress = captureInProgress
    self.alert = alert
    self.draftSkipReason = draftSkipReason
    self.draftBlockReason = draftBlockReason
  }

  public static let idle = GuidedInspectionUIState()

  /// Clears drafts/dialogs/alerts — presentation memory only.
  public mutating func resetEphemeral() {
    showingSkipDialog = false
    showingBlockDialog = false
    captureInProgress = false
    alert = nil
    draftSkipReason = ""
    draftBlockReason = ""
  }
}

/// User-facing alert payload derived from ``GuidedInspectionPresentationError``.
public struct PresentationAlert: Equatable, Sendable {
  public var title: String
  public var message: String

  public init(title: String = "Guided Inspection", message: String) {
    self.title = title
    self.message = message
  }
}

// MARK: - Handle result

public struct GuidedInspectionHandleResult: Equatable, Sendable {
  public var session: InspectionSession
  /// When true, the presentation layer should invoke the existing camera shutter API.
  public var shouldTriggerShutter: Bool
  public var presentation: GuidedInspectionPresentationState
  /// Set when `generateExportRequested` succeeds TOCTOU validation.
  public var exportDecision: InspectionExportDecision?

  public init(
    session: InspectionSession,
    shouldTriggerShutter: Bool = false,
    presentation: GuidedInspectionPresentationState,
    exportDecision: InspectionExportDecision? = nil
  ) {
    self.session = session
    self.shouldTriggerShutter = shouldTriggerShutter
    self.presentation = presentation
    self.exportDecision = exportDecision
  }
}

// MARK: - Presentation state (derived from domain — never persists ephemeral UI)

public struct GuidedInspectionPointSummary: Equatable, Sendable, Identifiable {
  public var id: InspectionPointID { pointID }
  public let pointID: InspectionPointID
  public let title: String
  public let isRequired: Bool
  public let status: InspectionPointStatus?
  public let evidenceCount: Int
  public let requiredCount: Int
  public let isSatisfied: Bool
  public let isActive: Bool
}

/// Pure derived HUD model from session + frozen snapshot. Never persists.
public struct GuidedInspectionPresentationState: Equatable, Sendable {
  public var isGuidedAvailable: Bool
  public var activePointID: InspectionPointID?
  public var activePointTitle: String?
  public var guidanceText: String?
  public var activeStatus: InspectionPointStatus?
  /// 1-based index in frozen snapshot order, or `0` when none active.
  public var activePointOrdinal: Int
  public var totalPoints: Int
  /// Rough plan progress 0…100 from terminal point statuses.
  public var planProgressPercent: Int
  public var evidenceCount: Int
  public var requiredCount: Int
  public var isPointSatisfied: Bool
  public var canAdvance: Bool
  public var canReturn: Bool
  public var canComplete: Bool
  public var canSkip: Bool
  public var canBlock: Bool
  public var canCapture: Bool
  public var canPrepare: Bool
  public var completionDisposition: InspectionCompletionDisposition
  public var points: [GuidedInspectionPointSummary]

  public var pointPositionLabel: String {
    guard activePointOrdinal > 0, totalPoints > 0 else { return "No active point" }
    return "Point \(activePointOrdinal) of \(totalPoints)"
  }

  public var evidenceStatusLabel: String {
    if isPointSatisfied {
      return "Evidence: \(evidenceCount) of \(requiredCount) · Satisfied"
    }
    if requiredCount > evidenceCount {
      return "Evidence: \(evidenceCount) of \(requiredCount) · Additional required"
    }
    return "Evidence: \(evidenceCount) of \(requiredCount)"
  }

  public static let unavailable = GuidedInspectionPresentationState(
    isGuidedAvailable: false,
    activePointID: nil,
    activePointTitle: nil,
    guidanceText: nil,
    activeStatus: nil,
    activePointOrdinal: 0,
    totalPoints: 0,
    planProgressPercent: 0,
    evidenceCount: 0,
    requiredCount: 0,
    isPointSatisfied: false,
    canAdvance: false,
    canReturn: false,
    canComplete: false,
    canSkip: false,
    canBlock: false,
    canCapture: false,
    canPrepare: false,
    completionDisposition: .incomplete,
    points: []
  )
}
