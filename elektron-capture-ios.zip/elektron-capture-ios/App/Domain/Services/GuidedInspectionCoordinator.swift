import Foundation

/// Persistence port owned by ``GuidedInspectionCoordinator`` (Sprint 2.1E DoD).
/// ViewModels must not call this — only the coordinator performs session saves.
public protocol GuidedSessionPersisting: Sendable {
  func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession
}

extension InspectionSessionService: GuidedSessionPersisting {
  public func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
    // `session.revision` is the last adopted durable base (expectation), not a minted next id.
    try await applyUpdatedSession(session, expectedRevision: session.revision)
  }
}

/// Application-level intent orchestrator for guided inspection (Sprint 2.1E).
///
/// **Sole owner of:**
/// - ``EvidenceMetadata`` / storage-key construction
/// - Domain engine calls (progression + binding)
/// - Persistence side-effects via ``GuidedSessionPersisting``
///
/// Value type — no `.shared`, no retain cycle with presentation.
public struct GuidedInspectionCoordinator: Sendable {
  private let progression: InspectionProgressionEngine
  private let binding: EvidenceBindingService
  private let instantProvider: any InstantProviding
  private let persister: (any GuidedSessionPersisting)?

  public init(
    progression: InspectionProgressionEngine = InspectionProgressionEngine(),
    binding: EvidenceBindingService = EvidenceBindingService(),
    instantProvider: any InstantProviding = SystemInstantProvider(),
    persister: (any GuidedSessionPersisting)? = nil
  ) {
    self.progression = progression
    self.binding = binding
    self.instantProvider = instantProvider
    self.persister = persister
  }

  public func presentation(for session: InspectionSession?) -> GuidedInspectionPresentationState {
    GuidedInspectionPresenter.makeState(from: session, binding: binding, progression: progression)
  }

  /// Applies intent, then persists when the session mutated (DoD: coordinator owns disk writes).
  /// `captureRequested` validates readiness and signals shutter without persisting.
  /// `refreshValidationRequested` refreshes presentation without persisting.
  public func handle(
    _ intent: GuidedInspectionIntent,
    session: InspectionSession
  ) async throws -> GuidedInspectionHandleResult {
    let applied = try apply(intent, session: session)
    if applied.shouldTriggerShutter {
      return applied
    }
    switch intent {
    case .refreshValidationRequested, .reviewInspectionRequested, .generateExportRequested:
      return applied
    default:
      break
    }
    guard let persister else {
      return applied
    }
    do {
      let saved = try await persister.persistGuidedSession(applied.session)
      return GuidedInspectionHandleResult(
        session: saved,
        shouldTriggerShutter: false,
        presentation: presentation(for: saved)
      )
    } catch let error as GuidedInspectionPresentationError {
      throw error
    } catch {
      throw GuidedInspectionPresentationError.persistence(String(describing: error))
    }
  }

  /// Pure domain transition without persistence (unit tests / dry-run).
  public func apply(
    _ intent: GuidedInspectionIntent,
    session: InspectionSession
  ) throws -> GuidedInspectionHandleResult {
    switch intent {
    case .prepareGuidedSession:
      return try prepare(session)

    case .activatePoint(let pointID):
      let next = try mapProgression { try progression.activate(pointID: pointID, in: session) }
      return result(next)

    case .advanceRequested:
      let next = try mapProgression { try progression.advanceToNextEligiblePoint(in: session) }
      return result(next)

    case .returnRequested:
      let next = try mapProgression { try progression.returnToPreviousEligiblePoint(in: session) }
      return result(next)

    case .completePointRequested:
      let next = try mapProgression { try progression.completeActivePoint(in: session) }
      return result(next)

    case .skipRequested(let reason):
      let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
      guard !trimmed.isEmpty else { throw GuidedInspectionPresentationError.emptySkipReason }
      var next = try mapProgression {
        try progression.skipActivePoint(reason: trimmed, in: session)
      }
      // Deliberate skip advances to the next open point when one exists.
      if let advanced = try? progression.advanceToNextEligiblePoint(in: next) {
        next = advanced
      }
      return result(next)

    case .blockRequested(let reason):
      let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
      guard !trimmed.isEmpty else { throw GuidedInspectionPresentationError.emptyBlockReason }
      var next = try mapProgression {
        try progression.blockActivePoint(reason: trimmed, in: session)
      }
      if let advanced = try? progression.advanceToNextEligiblePoint(in: next) {
        next = advanced
      }
      return result(next)

    case .captureRequested:
      let state = presentation(for: session)
      guard state.canCapture else {
        throw GuidedInspectionPresentationError.captureNotReady(
          "Active point is missing or terminal, or session is not in progress"
        )
      }
      return GuidedInspectionHandleResult(
        session: session,
        shouldTriggerShutter: true,
        presentation: state
      )

    case .bindApprovedCapture(let storageKey, let type, let attributes):
      return try bindApproved(
        storageKey: storageKey,
        type: type,
        attributes: attributes,
        session: session
      )

    case .unbindLibraryEvidence(let libraryEvidenceId):
      return try unbindLibrary(libraryEvidenceId: libraryEvidenceId, session: session)

    case .replaceLibraryEvidence(let oldLibraryEvidenceId, let storageKey, let type, let attributes):
      return try replaceLibrary(
        oldLibraryEvidenceId: oldLibraryEvidenceId,
        storageKey: storageKey,
        type: type,
        attributes: attributes,
        session: session
      )

    case .clearPointEvidence(let pointID):
      return result(binding.unbindAllEvidence(for: pointID, from: session))

    case .assignLibraryEvidenceToPoint(let libraryEvidenceId, let pointID, let type, let attributes):
      return try assignLibrary(
        libraryEvidenceId: libraryEvidenceId,
        pointID: pointID,
        type: type,
        attributes: attributes,
        session: session
      )

    case .skipPoint(let pointID, let reason):
      let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
      guard !trimmed.isEmpty else { throw GuidedInspectionPresentationError.emptySkipReason }
      var next = try mapProgression { try progression.activate(pointID: pointID, in: session) }
      next = try mapProgression { try progression.skipActivePoint(reason: trimmed, in: next) }
      if let advanced = try? progression.advanceToNextEligiblePoint(in: next) {
        next = advanced
      }
      return result(next)

    case .blockPoint(let pointID, let reason):
      let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
      guard !trimmed.isEmpty else { throw GuidedInspectionPresentationError.emptyBlockReason }
      var next = try mapProgression { try progression.activate(pointID: pointID, in: session) }
      next = try mapProgression { try progression.blockActivePoint(reason: trimmed, in: next) }
      if let advanced = try? progression.advanceToNextEligiblePoint(in: next) {
        next = advanced
      }
      return result(next)

    case .commitSessionCompletionRequested:
      guard InspectionLifecycleEvaluator.canCommitCompletion(session) else {
        throw GuidedInspectionPresentationError.completionNotAllowed(
          InspectionLifecycleEvaluator.completionBlockReason(for: session)
            ?? "Inspection is not ready to complete."
        )
      }
      var next = session
      next.status = .completed
      next.finishedAt = instantProvider.now()
      return result(next)

    case .refreshValidationRequested, .reviewInspectionRequested:
      // No domain mutation — presentation refresh only.
      return GuidedInspectionHandleResult(
        session: session,
        shouldTriggerShutter: false,
        presentation: presentation(for: session)
      )

    case .reviewPointRequested(let pointID):
      let next = try mapProgression { try progression.activate(pointID: pointID, in: session) }
      return result(next)

    case .generateExportRequested:
      let report = InspectionPreExportValidator().validate(session)
      let decision = InspectionExportPolicy().evaluate(
        session: session,
        validationReport: report
      )
      guard decision.isAllowed else {
        throw GuidedInspectionPresentationError.exportBlocked(decision.report.blockingFindings)
      }
      return GuidedInspectionHandleResult(
        session: session,
        shouldTriggerShutter: false,
        presentation: presentation(for: session),
        exportDecision: decision
      )
    }
  }

  // MARK: - Internals

  private func prepare(_ session: InspectionSession) throws -> GuidedInspectionHandleResult {
    guard session.inspectionPlanSnapshot != nil else {
      throw GuidedInspectionPresentationError.planNotAssigned
    }
    var next = try mapProgression { try progression.initializeProgress(for: session) }
    if next.progress?.activePointID == nil,
      let firstOpen = next.progress?.orderedPoints.first(where: { !$0.status.isTerminal })
    {
      next = try mapProgression {
        try progression.activate(pointID: firstOpen.pointID, in: next)
      }
    }
    return result(next)
  }

  private func bindApproved(
    storageKey: String,
    type: EvidenceType,
    attributes: [String: String],
    session: InspectionSession
  ) throws -> GuidedInspectionHandleResult {
    guard let pointID = session.progress?.activePointID else {
      throw GuidedInspectionPresentationError.noActivePoint
    }
    let evidenceID = EvidenceID()
    let key = Self.makeStorageKey(
      sessionID: session.id,
      pointID: pointID,
      evidenceID: evidenceID,
      approvedKey: storageKey
    )
    let meta = EvidenceMetadata(
      id: evidenceID,
      pointID: pointID,
      sessionID: session.id,
      type: type,
      createdAt: instantProvider.now(),
      storageKey: key,
      payloadAttributes: attributes
    )
    let next: InspectionSession
    do {
      next = try binding.bind(evidence: meta, to: session)
    } catch let error as EvidenceBindingError {
      throw GuidedInspectionPresentationError.evidenceBinding(error)
    }
    // Keep workflow coherent with an active capture: ensure the bound active point is inProgress.
    return try resultEnsuringActiveInProgress(next)
  }

  /// If the active point is still `notStarted` after a mutation, promote it to `inProgress`
  /// so Review/HUD never show "Not started" while evidence is actively being captured.
  private func resultEnsuringActiveInProgress(_ session: InspectionSession) throws
    -> GuidedInspectionHandleResult
  {
    guard let pointID = session.progress?.activePointID,
      case .notStarted? = session.progress?.progress(for: pointID)?.status
    else {
      return result(session)
    }
    let promoted = try mapProgression { try progression.activate(pointID: pointID, in: session) }
    return result(promoted)
  }

  private func unbindLibrary(
    libraryEvidenceId: String,
    session: InspectionSession
  ) throws -> GuidedInspectionHandleResult {
    result(binding.unbindLibraryEvidence(libraryEvidenceId: libraryEvidenceId, from: session))
  }

  private func assignLibrary(
    libraryEvidenceId: String,
    pointID: InspectionPointID,
    type: EvidenceType,
    attributes: [String: String],
    session: InspectionSession
  ) throws -> GuidedInspectionHandleResult {
    let evidenceID = EvidenceID()
    let key = Self.makeStorageKey(
      sessionID: session.id,
      pointID: pointID,
      evidenceID: evidenceID,
      approvedKey: libraryEvidenceId
    )
    let meta = EvidenceMetadata(
      id: evidenceID,
      pointID: pointID,
      sessionID: session.id,
      type: type,
      createdAt: instantProvider.now(),
      storageKey: key,
      payloadAttributes: attributes
    )
    let next: InspectionSession
    do {
      next = try binding.bind(evidence: meta, to: session)
    } catch let error as EvidenceBindingError {
      throw GuidedInspectionPresentationError.evidenceBinding(error)
    }
    // Ensure the assigned point is active/inProgress for coherent workflow labels.
    if next.progress?.activePointID != pointID
      || next.progress?.progress(for: pointID)?.status == .notStarted
    {
      let activated = try mapProgression { try progression.activate(pointID: pointID, in: next) }
      return result(activated)
    }
    return try resultEnsuringActiveInProgress(next)
  }

  /// Replaces library-bound evidence while preserving the original point assignment.
  private func replaceLibrary(
    oldLibraryEvidenceId: String,
    storageKey: String,
    type: EvidenceType,
    attributes: [String: String],
    session: InspectionSession
  ) throws -> GuidedInspectionHandleResult {
    let needle = oldLibraryEvidenceId.trimmingCharacters(in: .whitespacesAndNewlines)
    let old = session.evidenceBindings?.bindings.first { $0.storageKey.contains(needle) }
    let pointID = old?.pointID ?? session.progress?.activePointID
    guard let pointID else {
      throw GuidedInspectionPresentationError.noActivePoint
    }
    let evidenceID = EvidenceID()
    let key = Self.makeStorageKey(
      sessionID: session.id,
      pointID: pointID,
      evidenceID: evidenceID,
      approvedKey: storageKey
    )
    let meta = EvidenceMetadata(
      id: evidenceID,
      pointID: pointID,
      sessionID: session.id,
      type: type,
      createdAt: instantProvider.now(),
      storageKey: key,
      payloadAttributes: attributes
    )
    let next: InspectionSession
    do {
      if let old {
        next = try binding.replace(evidenceID: old.id, with: meta, in: session)
      } else {
        next = try binding.bind(evidence: meta, to: session)
      }
    } catch let error as EvidenceBindingError {
      throw GuidedInspectionPresentationError.evidenceBinding(error)
    }
    return try resultEnsuringActiveInProgress(next)
  }

  /// Opaque storage key: session/point/evidence identity + approved library key fragment.
  public static func makeStorageKey(
    sessionID: SessionID,
    pointID: InspectionPointID,
    evidenceID: EvidenceID,
    approvedKey: String
  ) -> String {
    let fragment = approvedKey.trimmingCharacters(in: .whitespacesAndNewlines)
    return "\(sessionID.rawValue)/\(pointID.rawValue)/\(evidenceID.rawValue.uuidString)/\(fragment)"
  }

  private func mapProgression(_ body: () throws -> InspectionSession) throws -> InspectionSession {
    do {
      return try body()
    } catch let error as InspectionProgressionError {
      throw GuidedInspectionPresentationError.progression(error)
    }
  }

  private func result(_ session: InspectionSession) -> GuidedInspectionHandleResult {
    GuidedInspectionHandleResult(
      session: session,
      shouldTriggerShutter: false,
      presentation: presentation(for: session)
    )
  }
}
