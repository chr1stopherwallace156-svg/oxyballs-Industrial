import Foundation

/// Splits a library catalog into what the Evidence Library actually renders.
///
/// Extracted in Repair 02 so the deleted-inspection retention rule is executable by tests
/// instead of living only inside a SwiftUI `body`. `EvidenceLibraryListView` calls this and
/// implements none of it itself.
///
/// The rule that matters: a tombstoned inspection disappears from the **Inspections** list,
/// but its captures are **kept and still listed** under their own section. Deleting an
/// inspection never removes evidence.
public enum InspectionLibraryPartition {
  public struct Result: Sendable, Equatable {
    /// Inspections that are neither archived nor deleted.
    public let live: [InspectionEvidenceGroup]
    /// Captures whose inspection was deleted — retained intact and individually verifiable.
    public let retainedFromDeleted: [EvidenceLibraryIndexRecord]
    /// Captures that never carried an inspectionSessionID.
    public let unassigned: [EvidenceLibraryIndexRecord]

    public init(
      live: [InspectionEvidenceGroup],
      retainedFromDeleted: [EvidenceLibraryIndexRecord],
      unassigned: [EvidenceLibraryIndexRecord]
    ) {
      self.live = live
      self.retainedFromDeleted = retainedFromDeleted
      self.unassigned = unassigned
    }
  }

  public static func partition(
    groups: [InspectionEvidenceGroup],
    unassigned: [EvidenceLibraryIndexRecord],
    archivedSessionIDs: Set<String>,
    deletedSessionIDs: Set<String>
  ) -> Result {
    let live = groups.filter {
      !archivedSessionIDs.contains($0.sessionID) && !deletedSessionIDs.contains($0.sessionID)
    }
    let retained = groups
      .filter { deletedSessionIDs.contains($0.sessionID) }
      .flatMap(\.captures)
      .sorted { lhs, rhs in
        if lhs.captureTimestamp != rhs.captureTimestamp {
          return lhs.captureTimestamp > rhs.captureTimestamp
        }
        return lhs.id < rhs.id
      }
    return Result(live: live, retainedFromDeleted: retained, unassigned: unassigned)
  }
}
