import Foundation

public actor LibraryMutationCoordinator {
  public enum RequestReason: Sendable, Equatable { case initial, mutation, notification, session, refresh }

  private var generation: UInt64 = 0
  private var active = false
  private var queuedReload = false
  private var activeMutationIDs: Set<String> = []
  private var waiters: [CheckedContinuation<Void, Never>] = []

  public init() {}

  /// Serializes operation control only. Domain records remain exclusively in repositories.
  public func perform(
    reason: RequestReason,
    mutationID: String? = nil,
    mutation: @Sendable () async throws -> Void = {},
    derive: @Sendable (UInt64) async throws -> LibrarySnapshot
  ) async throws -> LibrarySnapshot? {
    if let mutationID, activeMutationIDs.contains(mutationID) {
      queuedReload = true
      return nil
    }
    if active, reason != .mutation {
      queuedReload = true
      return nil
    }
    if let mutationID { activeMutationIDs.insert(mutationID) }
    await acquire()
    generation &+= 1
    let requestedGeneration = generation
    defer {
      release()
      if let mutationID { activeMutationIDs.remove(mutationID) }
    }
    try await mutation()
    let candidate = try await derive(requestedGeneration)
    guard candidate.generation == generation else { return nil }
    return candidate
  }

  public func consumeQueuedReload() -> Bool {
    defer { queuedReload = false }
    return queuedReload
  }

  public func currentGeneration() -> UInt64 { generation }

  public func acceptsForPublication(_ candidateGeneration: UInt64) -> Bool {
    candidateGeneration == generation
  }

  private func acquire() async {
    if !active {
      active = true
      return
    }
    queuedReload = true
    await withCheckedContinuation { continuation in
      waiters.append(continuation)
    }
  }

  private func release() {
    if waiters.isEmpty {
      active = false
    } else {
      waiters.removeFirst().resume()
    }
  }
}
