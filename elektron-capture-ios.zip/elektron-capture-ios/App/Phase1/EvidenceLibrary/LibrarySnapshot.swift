import Foundation

public struct LibrarySnapshot: Sendable, Equatable {
  public let generation: UInt64
  public let revision: UInt64
  public let live: [InspectionEvidenceGroup]
  public let retainedFromDeleted: [EvidenceLibraryIndexRecord]
  public let unassigned: [EvidenceLibraryIndexRecord]

  public init(
    generation: UInt64,
    revision: UInt64? = nil,
    live: [InspectionEvidenceGroup],
    retainedFromDeleted: [EvidenceLibraryIndexRecord],
    unassigned: [EvidenceLibraryIndexRecord]
  ) {
    self.generation = generation
    self.revision = revision ?? generation
    self.live = live
    self.retainedFromDeleted = retainedFromDeleted
    self.unassigned = unassigned
  }

  public static let empty = LibrarySnapshot(
    generation: 0, revision: 0, live: [], retainedFromDeleted: [], unassigned: []
  )

  public var itemCount: Int {
    live.reduce(0) { $0 + $1.captures.count } + retainedFromDeleted.count + unassigned.count
  }
}

public enum LibrarySnapshotError: Error, Sendable, Equatable, CustomStringConvertible {
  case duplicateRowID(id: String, section: String)
  case crossSectionDuplicate(id: String, first: String, second: String)
  case duplicateSectionID(id: String)

  public var description: String {
    switch self {
    case let .duplicateRowID(id, section):
      return "Duplicate evidence id \(id) in \(section)."
    case let .crossSectionDuplicate(id, first, second):
      return "Evidence id \(id) appears in both \(first) and \(second)."
    case let .duplicateSectionID(id):
      return "Duplicate inspection section id \(id)."
    }
  }
}
