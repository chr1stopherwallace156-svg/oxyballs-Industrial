import Foundation

/// Cross-tab signal when Evidence Library catalog bytes change (store / soft-delete / attach).
public enum EvidenceLibraryNotifications {
  public static let didChange = Notification.Name("ElektronCapture.EvidenceLibraryDidChange")

  public static let userInfoEvidenceIdKey = "evidenceId"
  public static let userInfoSessionIdKey = "sessionId"

  public static func postDidChange(evidenceId: String? = nil, sessionId: String? = nil) {
    var userInfo: [AnyHashable: Any] = [:]
    if let evidenceId {
      userInfo[userInfoEvidenceIdKey] = evidenceId
    }
    if let sessionId {
      userInfo[userInfoSessionIdKey] = sessionId
    }
    NotificationCenter.default.post(name: didChange, object: nil, userInfo: userInfo)
  }
}
