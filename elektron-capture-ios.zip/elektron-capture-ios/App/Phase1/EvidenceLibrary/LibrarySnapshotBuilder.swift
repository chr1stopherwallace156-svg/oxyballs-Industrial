import Foundation

public enum LibrarySnapshotBuilder {
  public static func build(
    generation: UInt64,
    groups: [InspectionEvidenceGroup],
    unassigned: [EvidenceLibraryIndexRecord],
    archivedSessionIDs: Set<String>,
    deletedSessionIDs: Set<String>
  ) throws -> LibrarySnapshot {
    let partition = InspectionLibraryPartition.partition(
      groups: groups,
      unassigned: unassigned,
      archivedSessionIDs: archivedSessionIDs,
      deletedSessionIDs: deletedSessionIDs
    )
    let snapshot = LibrarySnapshot(
      generation: generation,
      revision: generation,
      live: partition.live,
      retainedFromDeleted: partition.retainedFromDeleted,
      unassigned: partition.unassigned
    )
    try validate(snapshot)
    return snapshot
  }

  public static func validate(_ snapshot: LibrarySnapshot) throws {
    var ownerByID: [String: String] = [:]
    var groupIDs = Set<String>()
    for group in snapshot.live {
      guard groupIDs.insert(group.sessionID).inserted else {
        throw LibrarySnapshotError.duplicateSectionID(id: group.sessionID)
      }
    }
    let sections: [(String, [EvidenceLibraryIndexRecord])] =
      snapshot.live.map { ("inspection:\($0.sessionID)", $0.captures) }
      + [("deleted-inspection-evidence", snapshot.retainedFromDeleted),
         ("unassigned", snapshot.unassigned)]

    for (section, records) in sections {
      var local = Set<String>()
      for record in records {
        guard local.insert(record.id).inserted else {
          throw LibrarySnapshotError.duplicateRowID(id: record.id, section: section)
        }
        if let first = ownerByID[record.id] {
          throw LibrarySnapshotError.crossSectionDuplicate(
            id: record.id, first: first, second: section
          )
        }
        ownerByID[record.id] = section
      }
    }
  }
}
