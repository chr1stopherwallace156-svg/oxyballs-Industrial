import Foundation

/// Optimistic concurrency for inspection session commits (Sprint 2.3 / S2-004).
///
/// Callers supply ``expectedRevision`` (last observed durable revision; `0` if none).
/// The repository is the **sole assigner** of `N+1`. Incoming `session.revision` is ignored
/// for sequencing and overwritten before persist.
///
/// **Slot policy:** ``prepareCommit`` does **not** silently replace a different session id in an
/// occupied current-session slot. Intentional replacement must use
/// ``prepareSlotReplacement(incoming:expectedIncumbentRevision:existing:)`` via
/// ``CurrentSessionRepository/replaceCurrentSession(_:expectedIncumbentRevision:)``.
///
/// Does **not** change envelope `schemaVersion` (stays v1) or S2-002 snapshot hashing.
public enum SessionRevisionGuard: Sendable {
  /// Same-id OCC or first write into an empty slot. Rejects different-id overwrite.
  public static func prepareCommit(
    incoming: InspectionSession,
    expectedRevision: Int,
    existing: InspectionSession?
  ) throws -> InspectionSession {
    var next = incoming

    guard let existing else {
      guard expectedRevision == 0 else {
        throw InspectionSessionError.staleRevisionConflict(
          current: 0,
          attempted: expectedRevision
        )
      }
      next.revision = 1
      return next
    }

    if existing.id != incoming.id {
      throw InspectionSessionError.slotOccupied(
        incumbentID: existing.id.rawValue,
        incumbentRevision: existing.revision
      )
    }

    guard expectedRevision == existing.revision else {
      throw InspectionSessionError.staleRevisionConflict(
        current: existing.revision,
        attempted: expectedRevision
      )
    }
    next.revision = existing.revision + 1
    return next
  }

  /// Explicit current-session slot replacement (new inspection identity).
  ///
  /// Requires the caller to prove awareness of the incumbent revision.
  /// Assigns revision `1` to the incoming session; does not OCC-bump the incumbent.
  public static func prepareSlotReplacement(
    incoming: InspectionSession,
    expectedIncumbentRevision: Int,
    existing: InspectionSession
  ) throws -> InspectionSession {
    guard expectedIncumbentRevision == existing.revision else {
      throw InspectionSessionError.staleRevisionConflict(
        current: existing.revision,
        attempted: expectedIncumbentRevision
      )
    }
    var next = incoming
    next.revision = 1
    return next
  }
}
