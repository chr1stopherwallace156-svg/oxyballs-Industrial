import Foundation

/// Actions offered from an inspection's detail screen.
public enum InspectionDetailAction: String, CaseIterable, Sendable, Equatable {
  case saveAndExit = "SAVE_AND_EXIT"
  case completeInspection = "COMPLETE_INSPECTION"
  case createNewFromPlan = "CREATE_NEW_FROM_PLAN"
  case restartInspection = "RESTART_INSPECTION"
  case archiveInspection = "ARCHIVE_INSPECTION"
  case unarchiveInspection = "UNARCHIVE_INSPECTION"
  case deleteInspection = "DELETE_INSPECTION"

  public var title: String {
    switch self {
    case .saveAndExit: return "Save & Exit"
    case .completeInspection: return "Complete Inspection"
    case .createNewFromPlan: return "Create New Inspection from This Plan"
    case .restartInspection: return "Restart Inspection"
    case .archiveInspection: return "Archive Inspection"
    case .unarchiveInspection: return "Unarchive Inspection"
    case .deleteInspection: return "Delete Inspection"
    }
  }

  public var isDestructive: Bool {
    self == .restartInspection || self == .deleteInspection
  }

  /// Actions that can only ever act on the live, in-progress session.
  public var requiresBeingTheActiveSession: Bool {
    switch self {
    case .saveAndExit, .completeInspection, .createNewFromPlan, .restartInspection:
      return true
    case .archiveInspection, .unarchiveInspection, .deleteInspection:
      return false
    }
  }
}

public struct InspectionActionAvailability: Sendable, Equatable {
  public let action: InspectionDetailAction
  /// The inspection this action will operate on. Always the viewed group — never an
  /// implicit "whatever is current".
  public let targetSessionID: String
  public let isEnabled: Bool
  /// Shown to the operator when the action is offered but unavailable, so a greyed-out
  /// control is never unexplained.
  public let disabledReason: String?

  public init(
    action: InspectionDetailAction,
    targetSessionID: String,
    isEnabled: Bool,
    disabledReason: String?
  ) {
    self.action = action
    self.targetSessionID = targetSessionID
    self.isEnabled = isEnabled
    self.disabledReason = disabledReason
  }
}

/// Decides which detail-screen actions apply to *the inspection being viewed*.
///
/// Before the repair, the detail menu invoked the router against `inspection.current`
/// regardless of which inspection the operator had opened, so "Complete Inspection" on a
/// historical group completed a different inspection. Every availability produced here
/// carries `targetSessionID == groupID`; there is no path that substitutes the current
/// session for the viewed one.
public enum InspectionActionScope {
  public static func availability(
    action: InspectionDetailAction,
    groupID: String,
    currentSessionID: String?,
    currentStatus: SessionStatus?,
    isArchived: Bool,
    isDeleted: Bool,
    canCommitCompletion: Bool
  ) -> InspectionActionAvailability {
    func result(_ enabled: Bool, _ reason: String?) -> InspectionActionAvailability {
      InspectionActionAvailability(
        action: action,
        targetSessionID: groupID,
        isEnabled: enabled,
        disabledReason: enabled ? nil : reason
      )
    }

    if isDeleted {
      return result(false, "This inspection has been deleted.")
    }

    let isTheActiveSession = (currentSessionID == groupID)

    if action.requiresBeingTheActiveSession {
      guard isTheActiveSession else {
        return result(false, "Only available for the inspection currently open in Capture.")
      }
      guard let currentStatus, currentStatus.isActiveOrPaused else {
        return result(false, "This inspection is finished and cannot be changed.")
      }
      if action == .completeInspection, !canCommitCompletion {
        return result(false, "Resolve every required point before completing.")
      }
      return result(true, nil)
    }

    switch action {
    case .archiveInspection:
      return result(!isArchived, "This inspection is already archived.")
    case .unarchiveInspection:
      return result(isArchived, "This inspection is not archived.")
    case .deleteInspection:
      // Deletable in every lifecycle state, including completed, and with zero captures.
      return result(true, nil)
    default:
      return result(true, nil)
    }
  }

  public static func menu(
    groupID: String,
    currentSessionID: String?,
    currentStatus: SessionStatus?,
    isArchived: Bool,
    isDeleted: Bool,
    canCommitCompletion: Bool
  ) -> [InspectionActionAvailability] {
    InspectionDetailAction.allCases.map {
      availability(
        action: $0,
        groupID: groupID,
        currentSessionID: currentSessionID,
        currentStatus: currentStatus,
        isArchived: isArchived,
        isDeleted: isDeleted,
        canCommitCompletion: canCommitCompletion
      )
    }
  }
}
