import Foundation

/// Outcome of the v1 → v2 inspection-store migration.
public enum InspectionStoreMigrationOutcome: Sendable, Equatable {
  /// Already at v2; nothing to do.
  case alreadyMigrated
  /// No v1 payload existed (fresh install).
  case nothingToMigrate
  /// A v1 current-session record was copied into the v2 record directory.
  case migrated(sessionID: String)
  /// The v1 payload could not be read. v1 is left exactly as found; v2 starts empty.
  case skippedUnreadableV1(detail: String)
}

/// Migrates the single-slot v1 layout to the multi-record v2 layout.
///
/// ```
/// v1: InspectionSessions/current_session.json
/// v2: InspectionSessions/inspections/<sessionID>.json
///     InspectionSessions/archive.json
///     InspectionSessions/tombstones.json
///     InspectionSessions/migration_v2.json      (completion marker)
/// ```
///
/// Properties:
/// - **Non-destructive.** `current_session.json` is copied, never moved or deleted. The v1
///   engine keeps working against it untouched.
/// - **Idempotent.** A marker file makes repeat runs no-ops; re-running is always safe.
/// - **Rollback.** Delete `inspections/`, `tombstones.json`, `archive.json` and
///   `migration_v2.json`. The untouched v1 file is then authoritative again. Rollback loses
///   only records created after the migration — it never damages pre-migration data.
/// - **Archive import.** The v1 archived set lived in `UserDefaults`; callers pass it in so it
///   becomes durable v2 state instead of device-local presentation state.
public enum InspectionStoreMigration {
  public static let markerFilename = "migration_v2.json"

  public struct Marker: Codable, Sendable, Equatable {
    public let layoutVersion: InspectionStoreLayoutVersion
    public let migratedAt: Date
    public let migratedSessionID: String?

    public init(
      layoutVersion: InspectionStoreLayoutVersion = .current,
      migratedAt: Date,
      migratedSessionID: String?
    ) {
      self.layoutVersion = layoutVersion
      self.migratedAt = migratedAt
      self.migratedSessionID = migratedSessionID
    }
  }

  @discardableResult
  public static func migrateIfNeeded(
    root: URL,
    legacyCurrentSessionURL: URL,
    archivedSessionIDs: Set<String> = [],
    store: FileInspectionRecordStore,
    fileManager: FileManager = .default
  ) async -> InspectionStoreMigrationOutcome {
    let markerURL = root.appendingPathComponent(markerFilename)
    if fileManager.fileExists(atPath: markerURL.path) {
      return .alreadyMigrated
    }

    var outcome: InspectionStoreMigrationOutcome = .nothingToMigrate
    var migratedSessionID: String?

    if fileManager.fileExists(atPath: legacyCurrentSessionURL.path) {
      do {
        let data = try Data(contentsOf: legacyCurrentSessionURL)
        let envelope = try InspectionSessionEnvelopeLoader.load(from: data, savedAt: Date())
        // Terminal v1 sessions migrate too. A finished inspection is history worth keeping,
        // and v2 no longer deletes a record just because it is finished.
        try await store.save(envelope.session)
        migratedSessionID = envelope.session.id.rawValue
        outcome = .migrated(sessionID: envelope.session.id.rawValue)
      } catch {
        outcome = .skippedUnreadableV1(detail: String(describing: error))
      }
    }

    for sessionID in archivedSessionIDs.sorted() {
      try? await store.archive(sessionID: sessionID)
    }

    let marker = Marker(migratedAt: Date(), migratedSessionID: migratedSessionID)
    if let encoded = try? InspectionSessionEnvelopeCoder.makeJSONEncoder().encode(marker) {
      try? fileManager.createDirectory(at: root, withIntermediateDirectories: true)
      try? encoded.write(to: markerURL, options: .atomic)
    }
    return outcome
  }

  /// Removes every v2 artifact, restoring v1 as the authoritative layout.
  /// The v1 `current_session.json` is never touched by migration or rollback.
  public static func rollback(root: URL, fileManager: FileManager = .default) {
    for name in ["inspections", "tombstones.json", "archive.json", markerFilename] {
      let url = root.appendingPathComponent(name)
      if fileManager.fileExists(atPath: url.path) {
        try? fileManager.removeItem(at: url)
      }
    }
  }
}
