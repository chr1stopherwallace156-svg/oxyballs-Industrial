import Foundation

/// Version of the **inspection store directory layout** — deliberately separate from
/// ``InspectionSessionSchemaVersion``, which versions the envelope *payload*.
///
/// The repair changes where records live (single slot → one file per inspection, plus
/// archive and tombstone documents). It does **not** change the envelope shape, so the
/// envelope schema version stays at `v1` and every existing on-device envelope keeps
/// loading through the unchanged migrator. Conflating the two would have made every
/// pre-repair envelope fail with `missingMigrationPath`.
public struct InspectionStoreLayoutVersion: RawRepresentable, Codable, Equatable, Comparable,
  Hashable, Sendable
{
  public let rawValue: Int

  public init(rawValue: Int) {
    self.rawValue = rawValue
  }

  /// Single `current_session.json` slot (pre-repair).
  public static let v1 = InspectionStoreLayoutVersion(rawValue: 1)
  /// One record per inspection + `archive.json` + `tombstones.json`.
  public static let v2 = InspectionStoreLayoutVersion(rawValue: 2)

  public static let current = v2

  public static func < (lhs: InspectionStoreLayoutVersion, rhs: InspectionStoreLayoutVersion) -> Bool {
    lhs.rawValue < rhs.rawValue
  }

  public init(from decoder: Decoder) throws {
    let c = try decoder.singleValueContainer()
    rawValue = try c.decode(Int.self)
  }

  public func encode(to encoder: Encoder) throws {
    var c = encoder.singleValueContainer()
    try c.encode(rawValue)
  }
}

/// Why an inspection record was deleted.
///
/// Deletion is always an explicit operator act. The engine never deletes an inspection
/// implicitly, and never infers deletion from the absence of captures.
public enum InspectionDeletionReason: String, Codable, Sendable, Equatable {
  case userInitiated = "USER_INITIATED"
}

/// What happened to the capture evidence of a deleted inspection.
///
/// `retainedIntact` is the only disposition this subsystem may record. Deleting an
/// inspection removes the *inspection record* only: capture directories, original JPEG
/// bytes, sidecars, packages and library index rows are left exactly as they were, and
/// every capture remains individually addressable and verifiable.
///
/// Quarantining or removing capture media is a **separate, explicitly user-initiated
/// evidence action** (`EvidenceLibraryStore.softDeleteUserInitiated`). It is never a
/// side effect of inspection deletion.
public enum InspectionEvidenceDisposition: String, Codable, Sendable, Equatable {
  case retainedIntact = "RETAINED_INTACT"
}

/// Durable proof that an inspection was deleted.
///
/// The tombstone is the **positive, recorded fact** of deletion. Nothing in the system may
/// conclude that an inspection was deleted by observing that it has no captures, that its
/// record file is missing, or that it is absent from a projection. Absence is not evidence.
///
/// Tombstones are append-only within a store generation: once written for a session id, the
/// entry is not rewritten or removed by any deletion path.
public struct InspectionTombstone: Codable, Sendable, Equatable, Identifiable {
  public var id: String { sessionID }

  /// Inspection session identity this tombstone retires. Deletion is keyed on this value only.
  public let sessionID: String
  public let deletedAt: Date
  public let reason: InspectionDeletionReason
  public let evidenceDisposition: InspectionEvidenceDisposition
  public let layoutVersion: InspectionStoreLayoutVersion
  /// Lifecycle status the session held at the moment of deletion, when it was known.
  /// `nil` means the record was already absent (deletion of a dangling projection).
  public let sessionStatusAtDeletion: String?
  /// Capture ids that were bound to the inspection and are **retained intact** on disk.
  /// Recorded so a later audit can prove which evidence survived the deletion.
  public let retainedEvidenceIDs: [String]

  public init(
    sessionID: String,
    deletedAt: Date,
    reason: InspectionDeletionReason = .userInitiated,
    evidenceDisposition: InspectionEvidenceDisposition = .retainedIntact,
    layoutVersion: InspectionStoreLayoutVersion = .current,
    sessionStatusAtDeletion: String? = nil,
    retainedEvidenceIDs: [String] = []
  ) {
    self.sessionID = sessionID
    self.deletedAt = deletedAt
    self.reason = reason
    self.evidenceDisposition = evidenceDisposition
    self.layoutVersion = layoutVersion
    self.sessionStatusAtDeletion = sessionStatusAtDeletion
    // Deterministic order so the on-disk document is stable across writes.
    self.retainedEvidenceIDs = retainedEvidenceIDs.sorted()
  }
}

/// On-disk tombstone document (`tombstones.json`).
public struct InspectionTombstoneDocument: Codable, Sendable, Equatable {
  public var layoutVersion: InspectionStoreLayoutVersion
  public var tombstones: [InspectionTombstone]

  public init(
    layoutVersion: InspectionStoreLayoutVersion = .current,
    tombstones: [InspectionTombstone] = []
  ) {
    self.layoutVersion = layoutVersion
    self.tombstones = tombstones.sorted { $0.sessionID < $1.sessionID }
  }

  public var sessionIDs: Set<String> { Set(tombstones.map(\.sessionID)) }
}

/// On-disk archive document (`archive.json`).
///
/// Archive is a **reversible visibility state**, entirely distinct from deletion.
/// Un-archiving is a user action in its own right and is never used to express,
/// implement, or undo a deletion.
public struct InspectionArchiveDocument: Codable, Sendable, Equatable {
  public var layoutVersion: InspectionStoreLayoutVersion
  public var sessionIDs: [String]

  public init(
    layoutVersion: InspectionStoreLayoutVersion = .current,
    sessionIDs: [String] = []
  ) {
    self.layoutVersion = layoutVersion
    self.sessionIDs = sessionIDs.sorted()
  }
}
