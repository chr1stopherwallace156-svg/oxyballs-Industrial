import Foundation

/// In-flight / last-result bookkeeping for manual refresh.
///
/// Extracted in Repair 02 so the behaviour the UI depends on — re-entrancy rejection, the
/// "last updated" stamp, and whether an error is visible — lives in a platform-neutral type
/// that tests can execute. `AppSessionContainer` owns one of these and does not reimplement
/// any of it; there is exactly one implementation.
public struct RefreshActivityState: Sendable, Equatable {
  public private(set) var isRefreshing: Bool
  /// Set only on a successful refresh, so a failure never advances the stamp.
  public private(set) var lastRefreshedAt: Date?
  public private(set) var lastOutcome: InspectionRefreshOutcome?

  public init(
    isRefreshing: Bool = false,
    lastRefreshedAt: Date? = nil,
    lastOutcome: InspectionRefreshOutcome? = nil
  ) {
    self.isRefreshing = isRefreshing
    self.lastRefreshedAt = lastRefreshedAt
    self.lastOutcome = lastOutcome
  }

  /// Claims the refresh slot.
  /// - Returns: `false` when a refresh is already in flight; the caller must not start another.
  public mutating func begin() -> Bool {
    guard !isRefreshing else { return false }
    isRefreshing = true
    return true
  }

  /// Records the result and releases the slot.
  public mutating func finish(outcome: InspectionRefreshOutcome, at instant: Date) {
    isRefreshing = false
    lastOutcome = outcome
    if outcome.isSuccess {
      lastRefreshedAt = instant
    }
  }

  /// Dismisses the presented outcome without touching the stamp or the in-flight flag.
  public mutating func clearOutcome() {
    lastOutcome = nil
  }

  /// Text the hosting screen must present, or `nil` when there is nothing to report.
  public var visibleErrorMessage: String? { lastOutcome?.userMessage }

  /// Toolbar stamp. Formatted here so both hosting screens render it identically.
  public func stamp(calendarLocale: Locale = Locale(identifier: "en_US_POSIX")) -> String {
    guard let lastRefreshedAt else { return "Not refreshed yet" }
    let f = DateFormatter()
    f.locale = calendarLocale
    f.dateFormat = "HH:mm:ss"
    return "Updated \(f.string(from: lastRefreshedAt))"
  }
}
