import Foundation

/// Lightweight list row for stored sessions (no UI dependency).
public struct InspectionSessionListItem: Equatable, Sendable {
  public let id: SessionID
  public let savedAt: Date
  public let status: SessionStatus
  public let isPlanAssigned: Bool

  public init(id: SessionID, savedAt: Date, status: SessionStatus, isPlanAssigned: Bool) {
    self.id = id
    self.savedAt = savedAt
    self.status = status
    self.isPlanAssigned = isPlanAssigned
  }
}

/// Multi-session persistence abstraction (Sprint 2.1B).
///
/// ``InspectionSession`` does not save itself. Paths stay outside the domain model.
public protocol InspectionSessionStore: Sendable {
  @discardableResult
  func save(
    _ session: InspectionSession,
    savedAt: Date,
    expectedRevision: Int
  ) async throws -> InspectionSession
  func load(id: SessionID) async throws -> InspectionSession
  func list() async throws -> [InspectionSessionListItem]
  func delete(id: SessionID) async throws
}

/// File-backed ``InspectionSessionStore`` under a dedicated sessions directory.
///
/// Filename: `<SessionID.rawValue>.json` (deterministic).
/// Atomic save: validate envelope → write temp → replace destination.
public actor FileInspectionSessionStore: InspectionSessionStore {
  public let directoryURL: URL
  private let encoder: JSONEncoder
  private let migrator: InspectionSessionMigrator
  private let fileManager: FileManager

  public init(
    directoryURL: URL? = nil,
    migrator: InspectionSessionMigrator = InspectionSessionMigrator(),
    fileManager: FileManager = .default
  ) {
    if let directoryURL {
      self.directoryURL = directoryURL
    } else {
      let docs = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
        ?? fileManager.temporaryDirectory
      self.directoryURL = docs
        .appendingPathComponent("InspectionSessions", isDirectory: true)
        .appendingPathComponent("sessions", isDirectory: true)
    }
    self.encoder = InspectionSessionEnvelopeCoder.makeJSONEncoder()
    self.migrator = migrator
    self.fileManager = fileManager
  }

  public func fileURL(for id: SessionID) -> URL {
    directoryURL.appendingPathComponent("\(id.rawValue).json", isDirectory: false)
  }

  @discardableResult
  public func save(
    _ session: InspectionSession,
    savedAt: Date,
    expectedRevision: Int
  ) async throws -> InspectionSession {
    try ensureDirectory()

    let dest = fileURL(for: session.id)
    let existing: InspectionSession?
    if fileManager.fileExists(atPath: dest.path) {
      do {
        existing = try await load(id: session.id)
      } catch {
        throw InspectionSessionPersistenceError.malformedEnvelope(String(describing: error))
      }
    } else {
      existing = nil
    }

    let toWrite: InspectionSession
    do {
      toWrite = try SessionRevisionGuard.prepareCommit(
        incoming: session,
        expectedRevision: expectedRevision,
        existing: existing
      )
    } catch let InspectionSessionError.staleRevisionConflict(current, attempted) {
      throw InspectionSessionPersistenceError.staleRevisionConflict(
        current: current,
        attempted: attempted
      )
    } catch let e as InspectionSessionError {
      throw InspectionSessionPersistenceError.invalidSessionPayload(String(describing: e))
    }

    let envelope: InspectionSessionEnvelope
    do {
      envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(session: toWrite, savedAt: savedAt)
    } catch let e as InspectionSessionPersistenceError {
      throw e
    } catch {
      throw InspectionSessionPersistenceError.invalidSessionPayload(String(describing: error))
    }

    let data: Data
    do {
      data = try InspectionSessionEnvelopeCoder.encode(envelope)
    } catch let e as InspectionSessionPersistenceError {
      throw e
    } catch {
      throw InspectionSessionPersistenceError.invalidSessionPayload(String(describing: error))
    }

    try writeAtomically(data, to: dest)
    return toWrite
  }

  public func load(id: SessionID) async throws -> InspectionSession {
    let url = fileURL(for: id)
    guard fileManager.fileExists(atPath: url.path) else {
      throw InspectionSessionPersistenceError.fileNotFound(id.rawValue)
    }
    let data: Data
    do {
      data = try Data(contentsOf: url)
    } catch {
      throw InspectionSessionPersistenceError.malformedEnvelope(String(describing: error))
    }
    let envelope = try InspectionSessionEnvelopeLoader.load(
      from: data,
      savedAt: Date(),
      migrator: migrator
    )
    guard envelope.session.id == id else {
      throw InspectionSessionPersistenceError.sessionIdentityMismatch(
        expected: id.rawValue,
        actual: envelope.session.id.rawValue
      )
    }
    return envelope.session
  }

  public func list() async throws -> [InspectionSessionListItem] {
    try ensureDirectory()
    let urls: [URL]
    do {
      urls = try fileManager.contentsOfDirectory(
        at: directoryURL,
        includingPropertiesForKeys: nil,
        options: [.skipsHiddenFiles]
      )
    } catch {
      throw InspectionSessionPersistenceError.invalidStorageLocation(String(describing: error))
    }

    var items: [InspectionSessionListItem] = []
    for url in urls where url.pathExtension == "json" {
      // Ignore abandoned temps (`*.json.tmp` filtered by extension anyway)
      guard let data = try? Data(contentsOf: url) else { continue }
      guard let envelope = try? InspectionSessionEnvelopeLoader.load(from: data, migrator: migrator)
      else { continue }
      items.append(
        InspectionSessionListItem(
          id: envelope.session.id,
          savedAt: envelope.savedAt,
          status: envelope.session.status,
          isPlanAssigned: envelope.session.planState.isAssigned
        )
      )
    }
    return items.sorted { $0.id.rawValue < $1.id.rawValue }
  }

  public func delete(id: SessionID) async throws {
    let url = fileURL(for: id)
    guard fileManager.fileExists(atPath: url.path) else {
      throw InspectionSessionPersistenceError.fileNotFound(id.rawValue)
    }
    do {
      try fileManager.removeItem(at: url)
    } catch {
      throw InspectionSessionPersistenceError.atomicWriteFailed(String(describing: error))
    }
    // Best-effort cleanup of abandoned temp
    let temp = temporaryURL(for: url)
    try? fileManager.removeItem(at: temp)
  }

  // MARK: - Internals

  private func ensureDirectory() throws {
    do {
      try fileManager.createDirectory(at: directoryURL, withIntermediateDirectories: true)
    } catch {
      throw InspectionSessionPersistenceError.invalidStorageLocation(String(describing: error))
    }
  }

  private func temporaryURL(for destination: URL) -> URL {
    destination.appendingPathExtension("tmp")
  }

  /// Application-level atomic replace: complete temp write, then replace destination.
  private func writeAtomically(_ data: Data, to destination: URL) throws {
    let temp = temporaryURL(for: destination)
    do {
      if fileManager.fileExists(atPath: temp.path) {
        try fileManager.removeItem(at: temp)
      }
      try data.write(to: temp, options: .atomic)
      // Ensure temp is complete before replace.
      let written = try Data(contentsOf: temp)
      guard written == data else {
        try? fileManager.removeItem(at: temp)
        throw InspectionSessionPersistenceError.atomicWriteFailed("temporary write incomplete")
      }
      if fileManager.fileExists(atPath: destination.path) {
        let backup = destination.appendingPathExtension("bak")
        if fileManager.fileExists(atPath: backup.path) {
          try fileManager.removeItem(at: backup)
        }
        try fileManager.moveItem(at: destination, to: backup)
        do {
          try fileManager.moveItem(at: temp, to: destination)
          try? fileManager.removeItem(at: backup)
        } catch {
          try? fileManager.moveItem(at: backup, to: destination)
          try? fileManager.removeItem(at: temp)
          throw InspectionSessionPersistenceError.atomicWriteFailed(String(describing: error))
        }
      } else {
        try fileManager.moveItem(at: temp, to: destination)
      }
    } catch let e as InspectionSessionPersistenceError {
      throw e
    } catch {
      try? fileManager.removeItem(at: temp)
      throw InspectionSessionPersistenceError.atomicWriteFailed(String(describing: error))
    }
  }

  /// Test seam: leave a complete temporary file without replacing the destination.
  public func writeAbandonedTemporary(
    session: InspectionSession,
    savedAt: Date
  ) async throws {
    try ensureDirectory()
    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(session: session, savedAt: savedAt)
    let data = try InspectionSessionEnvelopeCoder.encode(envelope)
    let dest = fileURL(for: session.id)
    let temp = temporaryURL(for: dest)
    if fileManager.fileExists(atPath: temp.path) {
      try fileManager.removeItem(at: temp)
    }
    try data.write(to: temp, options: .atomic)
  }
}
