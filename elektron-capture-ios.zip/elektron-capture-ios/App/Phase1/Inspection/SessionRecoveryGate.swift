import Foundation

/// Outcome of evaluating whether a recovered session payload may replace durable head.
public enum SessionRecoveryDecision: Equatable, Sendable {
  /// No durable head — recovered may be installed.
  case adoptEmptySlot
  /// Recovered revision is strictly greater than durable head — install allowed.
  case adoptNewer(durable: Int, recovered: Int)
  /// `recovered.revision ≤ durable.revision` — must not overwrite (non-regression).
  case rejectLowerOrEqualRevision(durable: Int, recovered: Int)
  /// Recovered identity does not match durable identity in the same slot.
  case rejectIdentityMismatch(durable: String, recovered: String)
}

/// Minimal Sprint 2.3 Phase D production type: recovery monotonicity only.
///
/// Full journal replay / reconstruction pipelines are **out of scope**.
///
/// **Bounds:** evaluates identity match + `recovered.revision > durable.revision` only.
/// Does **not** verify payload signatures, provenance seals, or media hashes.
public enum SessionRecoveryGate: Sendable {
  /// Non-regression rule: `recovered.revision ≤ durable.revision ⇒ reject`.
  public static func evaluate(
    durable: InspectionSession?,
    recovered: InspectionSession
  ) -> SessionRecoveryDecision {
    guard let durable else {
      return .adoptEmptySlot
    }
    if durable.id != recovered.id {
      return .rejectIdentityMismatch(
        durable: durable.id.rawValue,
        recovered: recovered.id.rawValue
      )
    }
    if recovered.revision <= durable.revision {
      return .rejectLowerOrEqualRevision(
        durable: durable.revision,
        recovered: recovered.revision
      )
    }
    return .adoptNewer(durable: durable.revision, recovered: recovered.revision)
  }
}
