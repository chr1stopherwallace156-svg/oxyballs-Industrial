import Foundation

/// What a manual refresh actually established.
///
/// The pre-repair engine returned `Bool`, which could not distinguish "there is no active
/// inspection" from "the repository failed" from "the session is finished". All three
/// collapsed into `false` — or, worse, into `true` with the session silently emptied.
public enum InspectionRefreshOutcome: Sendable, Equatable {
  /// Reload succeeded and the projection now reflects the durable record.
  case updated(sessionID: String?)
  /// Reload succeeded and there is genuinely no inspection on record.
  case noActiveSession
  /// The durable session is finished (completed/canceled). It is shown as-is.
  /// A terminal session is **never** deleted or mutated as a consequence of being read.
  case terminalSession(sessionID: String, status: String)
  /// The repository could not be read. The previous good projection is preserved.
  case repositoryFailure(detail: String)
  /// The record for a session we were holding has vanished from the repository.
  /// The previous good projection is preserved rather than silently cleared.
  case recordDisappeared(priorSessionID: String)
  /// The repository returned a different session identity than the one held.
  /// The previous good projection is preserved.
  case identityDivergence(priorSessionID: String, loadedSessionID: String)

  public var isSuccess: Bool {
    switch self {
    case .updated, .noActiveSession, .terminalSession: return true
    case .repositoryFailure, .recordDisappeared, .identityDivergence: return false
    }
  }

  /// User-facing text. `nil` for the ordinary success paths, which are reported by the
  /// "last updated" stamp rather than by an alert.
  public var userMessage: String? {
    switch self {
    case .updated, .noActiveSession:
      return nil
    case let .terminalSession(_, status):
      return "This inspection is \(status.lowercased()). It is shown read-only; nothing was changed."
    case let .repositoryFailure(detail):
      return "Refresh failed: \(detail). The previous data is still shown."
    case let .recordDisappeared(priorSessionID):
      return "The stored record for \(priorSessionID) is no longer present. The previous data is still shown."
    case let .identityDivergence(prior, loaded):
      return "Session sync error: repository returned \(loaded) while holding \(prior). The previous data is still shown."
    }
  }
}

/// Raw result handed to ``InspectionRefreshResolution``.
public enum InspectionRefreshLoad: Sendable {
  case loaded(InspectionSession?)
  case failed(String)
}

/// Pure decision function for refresh. No I/O, no UI, no actor — directly unit-testable.
///
/// The single rule that matters: **a refresh may never destroy state.** Any result that is
/// not a clean, identity-matching load preserves whatever projection the caller already had.
public enum InspectionRefreshResolution {
  public struct Decision: Sendable, Equatable {
    public let outcome: InspectionRefreshOutcome
    /// The session the caller should publish. May be the prior value.
    public let adoptedSession: InspectionSession?
    /// True when `adoptedSession` is the caller's previous value rather than the loaded one.
    public let preservedPrior: Bool

    public init(
      outcome: InspectionRefreshOutcome,
      adoptedSession: InspectionSession?,
      preservedPrior: Bool
    ) {
      self.outcome = outcome
      self.adoptedSession = adoptedSession
      self.preservedPrior = preservedPrior
    }
  }

  public static func resolve(
    prior: InspectionSession?,
    load: InspectionRefreshLoad
  ) -> Decision {
    switch load {
    case let .failed(detail):
      return Decision(
        outcome: .repositoryFailure(detail: detail),
        adoptedSession: prior,
        preservedPrior: true
      )

    case let .loaded(loaded):
      guard let loaded else {
        // Nothing on disk.
        if let prior {
          // We were holding a session and the record is gone. Do not clear on its say-so.
          return Decision(
            outcome: .recordDisappeared(priorSessionID: prior.id.rawValue),
            adoptedSession: prior,
            preservedPrior: true
          )
        }
        return Decision(outcome: .noActiveSession, adoptedSession: nil, preservedPrior: false)
      }

      if let prior, prior.id != loaded.id {
        return Decision(
          outcome: .identityDivergence(
            priorSessionID: prior.id.rawValue,
            loadedSessionID: loaded.id.rawValue
          ),
          adoptedSession: prior,
          preservedPrior: true
        )
      }

      if loaded.status.isTerminal {
        // Adopt it and show it honestly. Reading a finished inspection must not delete it.
        return Decision(
          outcome: .terminalSession(
            sessionID: loaded.id.rawValue,
            status: loaded.status.rawValue
          ),
          adoptedSession: loaded,
          preservedPrior: false
        )
      }

      return Decision(
        outcome: .updated(sessionID: loaded.id.rawValue),
        adoptedSession: loaded,
        preservedPrior: false
      )
    }
  }
}
