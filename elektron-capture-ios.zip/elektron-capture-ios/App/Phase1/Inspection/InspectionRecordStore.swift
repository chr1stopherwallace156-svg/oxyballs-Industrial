import Foundation

/// Explicit failures for the multi-inspection record store.
public enum InspectionRecordStoreError: Error, Equatable, Sendable {
  case invalidSessionID(String)
  case storageUnavailable(String)
  case writeFailed(String)
  case readFailed(String)
  case alreadyDeleted(String)
}

/// Durable, multi-inspection persistence contract.
///
/// The pre-repair engine persisted exactly one *current* session slot, so an inspection had
/// no record of its own and could only "disappear" as a side effect of its captures being
/// removed. This contract makes each inspection an addressable, independently durable record
/// and makes deletion an explicit, recorded operation.
///
/// Invariants:
/// - Deletion is keyed on `inspectionSessionID` and is proven by a durable
///   ``InspectionTombstone`` — never inferred from missing captures or a missing file.
/// - Deleting one inspection never reads, writes, moves or removes another.
/// - Deletion never touches capture evidence (see ``InspectionEvidenceDisposition``).
/// - Archive and delete are independent states. Un-archiving is never a deletion mechanism,
///   and deleting never clears the archived flag as a way of "hiding" a record.
/// - Every operation is durable before it returns; a fresh store over the same directory
///   observes the same facts after a process restart.
public protocol InspectionRecordStore: Sendable {
  /// Every non-deleted inspection record, newest `startedAt` first.
  /// Tombstoned inspections are excluded; archived inspections are included
  /// (visibility filtering is a presentation concern, not a storage one).
  func listInspections() async throws -> [InspectionSession]

  /// A single inspection by session id. Returns `nil` when no record exists.
  /// Throws ``InspectionRecordStoreError/alreadyDeleted(_:)`` when a tombstone exists,
  /// so callers cannot silently treat a deleted inspection as merely absent.
  func load(sessionID: String) async throws -> InspectionSession?

  /// Insert or replace one inspection record. Other records are untouched.
  func save(_ session: InspectionSession) async throws

  /// Mark an inspection archived (reversible visibility state).
  func archive(sessionID: String) async throws

  /// Clear the archived flag. This is a user-facing un-archive and nothing else.
  func unarchive(sessionID: String) async throws

  func archivedSessionIDs() async throws -> Set<String>

  /// Durably delete an inspection record and write its tombstone.
  ///
  /// - Parameter retainedEvidenceIDs: capture ids left intact on disk, recorded for audit.
  /// - Returns: the tombstone that now proves the deletion.
  @discardableResult
  func delete(
    sessionID: String,
    reason: InspectionDeletionReason,
    retainedEvidenceIDs: [String]
  ) async throws -> InspectionTombstone

  func tombstones() async throws -> [InspectionTombstone]

  func deletedSessionIDs() async throws -> Set<String>
}

/// File-backed JSON implementation.
///
/// Layout under `root`:
/// ```
/// inspections/<sessionID>.json   one InspectionSessionEnvelope per inspection
/// archive.json                   InspectionArchiveDocument
/// tombstones.json                InspectionTombstoneDocument
/// ```
/// Writes use the same discipline as ``FileCurrentSessionRepository``: write to a temp file,
/// read the bytes back and compare, then rename over the target, keeping a `.bak` until the
/// rename succeeds. A failed rename restores the previous file.
public actor FileInspectionRecordStore: InspectionRecordStore {
  public let root: URL
  private let fileManager: FileManager

  public init(root: URL? = nil, fileManager: FileManager = .default) {
    self.fileManager = fileManager
    if let root {
      self.root = root
    } else {
      let docs = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
        ?? fileManager.temporaryDirectory
      self.root = docs.appendingPathComponent("InspectionSessions", isDirectory: true)
    }
  }

  private var recordsDirectory: URL { root.appendingPathComponent("inspections", isDirectory: true) }
  private var archiveURL: URL { root.appendingPathComponent("archive.json") }
  private var tombstonesURL: URL { root.appendingPathComponent("tombstones.json") }

  // MARK: - Identity

  /// Session ids become file names, so they are validated exactly like capture ids.
  public static func validateSessionID(_ id: String) throws {
    let trimmed = id.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty, trimmed == id else {
      throw InspectionRecordStoreError.invalidSessionID("empty or padded session id")
    }
    let forbidden = CharacterSet(charactersIn: "/\\:\0")
      .union(.newlines)
      .union(.controlCharacters)
    if id.rangeOfCharacter(from: forbidden) != nil || id.contains("..") || id == "." || id == ".." {
      throw InspectionRecordStoreError.invalidSessionID("illegal characters: \(id)")
    }
    if id.hasPrefix(".") {
      throw InspectionRecordStoreError.invalidSessionID("session id must not start with '.'")
    }
  }

  private func recordURL(for sessionID: String) throws -> URL {
    try Self.validateSessionID(sessionID)
    return recordsDirectory.appendingPathComponent("\(sessionID).json")
  }

  // MARK: - Reads

  public func listInspections() async throws -> [InspectionSession] {
    let deleted = try loadTombstoneDocument().sessionIDs
    guard fileManager.fileExists(atPath: recordsDirectory.path) else { return [] }
    let names: [String]
    do {
      names = try fileManager.contentsOfDirectory(atPath: recordsDirectory.path)
    } catch {
      throw InspectionRecordStoreError.readFailed(String(describing: error))
    }
    var sessions: [InspectionSession] = []
    for name in names.sorted() where name.hasSuffix(".json") {
      let sessionID = String(name.dropLast(5))
      if deleted.contains(sessionID) { continue }
      let url = recordsDirectory.appendingPathComponent(name)
      guard let data = try? Data(contentsOf: url) else { continue }
      // A single unreadable record must not hide every other inspection.
      guard let envelope = try? InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(from: data)
      else { continue }
      sessions.append(envelope.session)
    }
    return sessions.sorted { lhs, rhs in
      if lhs.startedAt != rhs.startedAt { return lhs.startedAt > rhs.startedAt }
      return lhs.id.rawValue < rhs.id.rawValue
    }
  }

  public func load(sessionID: String) async throws -> InspectionSession? {
    try Self.validateSessionID(sessionID)
    if try loadTombstoneDocument().sessionIDs.contains(sessionID) {
      throw InspectionRecordStoreError.alreadyDeleted(sessionID)
    }
    let url = try recordURL(for: sessionID)
    guard fileManager.fileExists(atPath: url.path) else { return nil }
    do {
      let data = try Data(contentsOf: url)
      return try InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(from: data).session
    } catch {
      throw InspectionRecordStoreError.readFailed(String(describing: error))
    }
  }

  public func tombstones() async throws -> [InspectionTombstone] {
    try loadTombstoneDocument().tombstones
  }

  public func deletedSessionIDs() async throws -> Set<String> {
    try loadTombstoneDocument().sessionIDs
  }

  public func archivedSessionIDs() async throws -> Set<String> {
    Set(try loadArchiveDocument().sessionIDs)
  }

  // MARK: - Writes

  public func save(_ session: InspectionSession) async throws {
    let sessionID = session.id.rawValue
    try Self.validateSessionID(sessionID)
    if try loadTombstoneDocument().sessionIDs.contains(sessionID) {
      throw InspectionRecordStoreError.alreadyDeleted(sessionID)
    }
    let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(session: session, savedAt: Date())
    let data = try InspectionSessionEnvelopeCoder.encode(envelope)
    try ensureDirectory(recordsDirectory)
    try atomicWrite(data, to: try recordURL(for: sessionID))
  }

  public func archive(sessionID: String) async throws {
    try Self.validateSessionID(sessionID)
    var doc = try loadArchiveDocument()
    guard !doc.sessionIDs.contains(sessionID) else { return }
    doc = InspectionArchiveDocument(sessionIDs: doc.sessionIDs + [sessionID])
    try writeArchiveDocument(doc)
  }

  /// Clears the archived flag. Never used to express or reverse a deletion.
  public func unarchive(sessionID: String) async throws {
    try Self.validateSessionID(sessionID)
    let doc = try loadArchiveDocument()
    guard doc.sessionIDs.contains(sessionID) else { return }
    try writeArchiveDocument(
      InspectionArchiveDocument(sessionIDs: doc.sessionIDs.filter { $0 != sessionID })
    )
  }

  /// Durable delete: write the tombstone **first**, then remove the record file.
  ///
  /// Order matters. If the process dies between the two steps the tombstone already exists,
  /// so the inspection stays deleted and a stale record file is ignored by every read path.
  /// The reverse order could lose the record while leaving no proof it was ever deleted.
  ///
  /// The archived flag is deliberately left untouched — deletion is not un-archiving.
  @discardableResult
  public func delete(
    sessionID: String,
    reason: InspectionDeletionReason = .userInitiated,
    retainedEvidenceIDs: [String] = []
  ) async throws -> InspectionTombstone {
    try Self.validateSessionID(sessionID)

    var doc = try loadTombstoneDocument()
    if let existing = doc.tombstones.first(where: { $0.sessionID == sessionID }) {
      // Idempotent: a repeated delete returns the original proof rather than rewriting it.
      try? removeRecordFile(sessionID: sessionID)
      return existing
    }

    // Status is read before the record is removed so the tombstone can record it.
    let url = try recordURL(for: sessionID)
    var statusAtDeletion: String?
    if fileManager.fileExists(atPath: url.path),
      let data = try? Data(contentsOf: url),
      let envelope = try? InspectionSessionEnvelopeCoder.decodeVerifiedEnvelope(from: data)
    {
      statusAtDeletion = envelope.session.status.rawValue
    }

    let tombstone = InspectionTombstone(
      sessionID: sessionID,
      deletedAt: Date(),
      reason: reason,
      evidenceDisposition: .retainedIntact,
      sessionStatusAtDeletion: statusAtDeletion,
      retainedEvidenceIDs: retainedEvidenceIDs
    )
    doc = InspectionTombstoneDocument(tombstones: doc.tombstones + [tombstone])
    try writeTombstoneDocument(doc)
    try removeRecordFile(sessionID: sessionID)
    return tombstone
  }

  // MARK: - Documents

  private func loadTombstoneDocument() throws -> InspectionTombstoneDocument {
    guard fileManager.fileExists(atPath: tombstonesURL.path) else {
      return InspectionTombstoneDocument()
    }
    do {
      let data = try Data(contentsOf: tombstonesURL)
      return try InspectionSessionEnvelopeCoder.makeJSONDecoder()
        .decode(InspectionTombstoneDocument.self, from: data)
    } catch {
      throw InspectionRecordStoreError.readFailed("tombstones.json: \(error)")
    }
  }

  private func writeTombstoneDocument(_ doc: InspectionTombstoneDocument) throws {
    let data = try encode(doc)
    try ensureDirectory(root)
    try atomicWrite(data, to: tombstonesURL)
  }

  private func loadArchiveDocument() throws -> InspectionArchiveDocument {
    guard fileManager.fileExists(atPath: archiveURL.path) else {
      return InspectionArchiveDocument()
    }
    do {
      let data = try Data(contentsOf: archiveURL)
      return try InspectionSessionEnvelopeCoder.makeJSONDecoder()
        .decode(InspectionArchiveDocument.self, from: data)
    } catch {
      throw InspectionRecordStoreError.readFailed("archive.json: \(error)")
    }
  }

  private func writeArchiveDocument(_ doc: InspectionArchiveDocument) throws {
    let data = try encode(doc)
    try ensureDirectory(root)
    try atomicWrite(data, to: archiveURL)
  }

  private func encode<T: Encodable>(_ value: T) throws -> Data {
    do {
      return try InspectionSessionEnvelopeCoder.makeJSONEncoder().encode(value)
    } catch {
      throw InspectionRecordStoreError.writeFailed(String(describing: error))
    }
  }

  // MARK: - File primitives

  private func ensureDirectory(_ url: URL) throws {
    do {
      try fileManager.createDirectory(at: url, withIntermediateDirectories: true)
    } catch {
      throw InspectionRecordStoreError.storageUnavailable(String(describing: error))
    }
  }

  private func removeRecordFile(sessionID: String) throws {
    let url = try recordURL(for: sessionID)
    guard fileManager.fileExists(atPath: url.path) else { return }
    do {
      try fileManager.removeItem(at: url)
    } catch {
      throw InspectionRecordStoreError.writeFailed("record removal: \(error)")
    }
  }

  /// Temp write → read-back byte compare → rename, with `.bak` rollback on failure.
  private func atomicWrite(_ data: Data, to url: URL) throws {
    do {
      let temp = url.appendingPathExtension("tmp")
      if fileManager.fileExists(atPath: temp.path) {
        try fileManager.removeItem(at: temp)
      }
      try data.write(to: temp, options: .atomic)
      let written = try Data(contentsOf: temp)
      guard written == data else {
        try? fileManager.removeItem(at: temp)
        throw InspectionRecordStoreError.writeFailed("temporary write incomplete: \(url.lastPathComponent)")
      }
      if fileManager.fileExists(atPath: url.path) {
        let backup = url.appendingPathExtension("bak")
        if fileManager.fileExists(atPath: backup.path) {
          try fileManager.removeItem(at: backup)
        }
        try fileManager.moveItem(at: url, to: backup)
        do {
          try fileManager.moveItem(at: temp, to: url)
          try? fileManager.removeItem(at: backup)
        } catch {
          try? fileManager.moveItem(at: backup, to: url)
          try? fileManager.removeItem(at: temp)
          throw error
        }
      } else {
        try fileManager.moveItem(at: temp, to: url)
      }
    } catch let e as InspectionRecordStoreError {
      throw e
    } catch {
      throw InspectionRecordStoreError.writeFailed(String(describing: error))
    }
  }
}
