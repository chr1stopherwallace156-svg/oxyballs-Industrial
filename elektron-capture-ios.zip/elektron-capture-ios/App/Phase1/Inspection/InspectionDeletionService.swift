import Foundation

/// Result of an inspection deletion. There is no ambiguous boolean.
public enum InspectionDeletionOutcome: Sendable, Equatable {
  /// The tombstone was durably written **and read back**, and the record file is gone.
  case deleted(sessionID: String, retainedEvidenceCount: Int, statusAtDeletion: String?)
  /// A tombstone already existed. Idempotent success — the inspection is still deleted.
  case alreadyDeleted(sessionID: String)
  /// Nothing was durably deleted. The caller must not report success.
  case failed(sessionID: String, reason: String)

  public var isDeleted: Bool {
    switch self {
    case .deleted, .alreadyDeleted: return true
    case .failed: return false
    }
  }

  public var userMessage: String {
    switch self {
    case let .deleted(_, retained, _):
      return retained == 0
        ? "Inspection deleted."
        : "Inspection deleted. \(retained) capture\(retained == 1 ? "" : "s") retained and still verifiable in the library."
    case .alreadyDeleted:
      return "Inspection was already deleted."
    case let .failed(_, reason):
      return "Delete failed: \(reason). The inspection was not deleted."
    }
  }
}

/// Deletes an inspection record, and nothing else.
///
/// Retention policy (fixed, not configurable here):
/// **capture evidence is never quarantined, moved, overwritten or removed by this service.**
/// Original JPEG bytes, sidecars, packages and library index rows survive untouched, and every
/// capture stays individually addressable and verifiable. Removing capture media is a separate,
/// explicitly user-initiated evidence action and is never a side effect of deleting an inspection.
///
/// Because the only durable mutation is a single tombstone write, there is no partial-deletion
/// state to recover from: the tombstone either lands and is read back, or the outcome is
/// `.failed` and nothing is claimed. Success is never announced on an unverified write.
public struct InspectionDeletionService: Sendable {
  private let store: any InspectionRecordStore

  public init(store: any InspectionRecordStore) {
    self.store = store
  }

  /// - Parameter retainedEvidenceIDs: capture ids bound to this inspection. They are recorded
  ///   in the tombstone as retained; **they are not touched**.
  public func delete(
    sessionID: String,
    retainedEvidenceIDs: [String] = [],
    reason: InspectionDeletionReason = .userInitiated
  ) async -> InspectionDeletionOutcome {
    do {
      if try await store.deletedSessionIDs().contains(sessionID) {
        return .alreadyDeleted(sessionID: sessionID)
      }

      let tombstone = try await store.delete(
        sessionID: sessionID,
        reason: reason,
        retainedEvidenceIDs: retainedEvidenceIDs
      )

      // Read-back proof. A write that cannot be observed is not a deletion.
      guard try await store.deletedSessionIDs().contains(sessionID) else {
        return .failed(
          sessionID: sessionID,
          reason: "tombstone was written but could not be read back"
        )
      }

      return .deleted(
        sessionID: sessionID,
        retainedEvidenceCount: tombstone.retainedEvidenceIDs.count,
        statusAtDeletion: tombstone.sessionStatusAtDeletion
      )
    } catch {
      return .failed(sessionID: sessionID, reason: String(describing: error))
    }
  }
}
