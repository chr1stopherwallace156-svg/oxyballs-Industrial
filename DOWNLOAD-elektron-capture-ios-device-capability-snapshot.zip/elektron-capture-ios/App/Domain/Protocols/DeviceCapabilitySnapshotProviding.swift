import Foundation

#if canImport(CoreMotion)
import CoreMotion
#endif

/// Camera authorization as observed for capability discovery (not capture configuration).
public enum CameraAuthorizationState: String, Sendable, Equatable {
  case authorized
  case notDetermined
  case denied
  case restricted
}

/// Portable discovered-camera record used by injectable discovery providers.
public struct DiscoveredCameraDevice: Sendable, Equatable {
  public let uniqueID: String
  public let position: String
  public let deviceType: String
  public let supportsFocusLock: Bool
  public let supportsExposureLock: Bool
  public let supportsDepthData: Bool
  public let isLiDARDevice: Bool

  public init(
    uniqueID: String,
    position: String,
    deviceType: String,
    supportsFocusLock: Bool,
    supportsExposureLock: Bool,
    supportsDepthData: Bool,
    isLiDARDevice: Bool
  ) {
    self.uniqueID = uniqueID
    self.position = position
    self.deviceType = deviceType
    self.supportsFocusLock = supportsFocusLock
    self.supportsExposureLock = supportsExposureLock
    self.supportsDepthData = supportsDepthData
    self.isLiDARDevice = isLiDARDevice
  }

  public func asCameraCapability() -> CameraCapability {
    CameraCapability(
      cameraID: uniqueID,
      position: position,
      deviceType: deviceType,
      supportsFocusLock: supportsFocusLock,
      supportsExposureLock: supportsExposureLock,
      supportsDepthData: supportsDepthData
    )
  }
}

public protocol CameraAuthorizationStatusProviding: Sendable {
  func videoAuthorizationState() -> CameraAuthorizationState
}

public protocol CameraDeviceDiscovering: Sendable {
  /// Enumerate cameras without mutating the active capture session.
  func discoverCameras() -> [DiscoveredCameraDevice]
}

public protocol MotionCapabilityChecking: Sendable {
  func motionCapabilityState() -> CapabilityState
}

public protocol DeviceIdentityProviding: Sendable {
  func deviceModel() -> String
  func operatingSystemVersion() -> String
}

public protocol DeviceCapabilitySnapshotProviding: Sendable {
  func captureSnapshot() async -> DeviceCapabilitySnapshot
}

/// Default identity using the same sources as Phase 1 provenance.
public struct SystemDeviceIdentityProvider: DeviceIdentityProviding {
  public init() {}

  public func deviceModel() -> String {
    DeviceProvenanceService.hardwareModelIdentifier()
  }

  public func operatingSystemVersion() -> String {
    DeviceProvenanceService.systemVersion()
  }
}

/// Motion availability without requiring Core Motion samples.
public struct SystemMotionCapabilityChecker: MotionCapabilityChecking {
  public init() {}

  public func motionCapabilityState() -> CapabilityState {
    #if canImport(CoreMotion)
    return CMMotionManager().isDeviceMotionAvailable ? .supported : .unsupported
    #else
    return .unknown
    #endif
  }
}
