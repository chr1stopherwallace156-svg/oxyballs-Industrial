import Foundation

/// Injectable still-photo source (real AVFoundation on device; fixture in tests).
public protocol StillPhotoCaptureProviding: Sendable {
  func captureProcessedJPEG() async throws -> Data
}

/// Fixture provider for unit/integration tests — exact bytes, no re-encode path.
public struct FixtureStillPhotoCaptureService: StillPhotoCaptureProviding {
  public var jpegBytes: Data
  public init(jpegBytes: Data) {
    self.jpegBytes = jpegBytes
  }
  public func captureProcessedJPEG() async throws -> Data {
    jpegBytes
  }
}

public struct Phase1CaptureCoordinator: Sendable {
  public var appVersion: String
  public var photoCapture: any StillPhotoCaptureProviding
  public var clock: CaptureClockService
  public var provenanceService: DeviceProvenanceService
  public var motionService: MotionSampleService
  public var packageBuilder: EvidencePackageBuilder
  public var workRoot: URL
  /// Session-retained capability snapshot (set by app at capture-session init).
  public var deviceCapabilitySnapshot: DeviceCapabilitySnapshot?

  public init(
    appVersion: String,
    photoCapture: any StillPhotoCaptureProviding,
    workRoot: URL,
    clock: CaptureClockService = CaptureClockService(),
    provenanceService: DeviceProvenanceService? = nil,
    motionService: MotionSampleService = MotionSampleService(),
    packageBuilder: EvidencePackageBuilder = EvidencePackageBuilder(),
    deviceCapabilitySnapshot: DeviceCapabilitySnapshot? = nil
  ) {
    self.appVersion = appVersion
    self.photoCapture = photoCapture
    self.workRoot = workRoot
    self.clock = clock
    self.provenanceService = provenanceService ?? DeviceProvenanceService(appVersion: appVersion)
    self.motionService = motionService
    self.packageBuilder = packageBuilder
    self.deviceCapabilitySnapshot = deviceCapabilitySnapshot
  }

  /// Full Phase 1 pipeline to PACKAGE_EXPORTED. Does not assign EDTS statuses.
  public func captureAndExport(
    ids: Phase1CaptureIdentifiers = .generate(),
    motionInjected: MotionSampleRecord? = nil,
    hardwareModelOverride: String? = nil,
    iosVersionOverride: String? = nil,
    defaults: UserDefaults = .standard,
    deviceCapabilitySnapshot: DeviceCapabilitySnapshot? = nil
  ) async throws -> Phase1PackageResult {
    // Lifecycle: CREATED
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureCreated.rawValue)

    let jpeg: Data
    do {
      jpeg = try await photoCapture.captureProcessedJPEG()
      Phase1CaptureDiagnostics.log(
        stage: "photo_bytes",
        event: "received",
        detail: "byteCount=\(jpeg.count) empty=\(jpeg.isEmpty)"
      )
    } catch let e as Phase1RuntimeError {
      Phase1CaptureDiagnostics.log(
        stage: "photo_capture",
        event: "failed",
        detail: "reason=\(e.reasonCode) detail=\(e.detailMessage)"
      )
      throw e
    } catch {
      throw Phase1RuntimeError.photoCaptureFailed(String(describing: error))
    }
    guard !jpeg.isEmpty else {
      throw Phase1RuntimeError.fileRepresentationUnavailable
    }

    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.capturePersisted.rawValue)
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureHashed.rawValue)
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureSealed.rawValue)

    let clockSnap = clock.snapshot()
    let provenance = provenanceService.currentProvenance(
      defaults: defaults,
      hardwareModelOverride: hardwareModelOverride,
      iosVersionOverride: iosVersionOverride
    )
    let motion = motionService.sample(injected: motionInjected)

    let result = try packageBuilder.build(
      jpegBytes: jpeg,
      ids: ids,
      clock: clockSnap,
      provenance: provenance,
      motion: motion,
      calibrationAvailability: .notAvailable,
      workRoot: workRoot,
      captureAppVersion: appVersion,
      previousStatus: .captureSealed,
      deviceCapabilitySnapshot: deviceCapabilitySnapshot ?? self.deviceCapabilitySnapshot
    )
    return result
  }

  /// Pass 2 export: package **approved** frozen bytes only. Asserts hash invariance vs post-delegate SHA.
  /// Does not re-encode or replace artifact bytes.
  public func exportApproved(
    _ approved: ApprovedStillCapture,
    ids: Phase1CaptureIdentifiers = .generate(),
    motionInjected: MotionSampleRecord? = nil,
    hardwareModelOverride: String? = nil,
    iosVersionOverride: String? = nil,
    defaults: UserDefaults = .standard,
    deviceCapabilitySnapshot: DeviceCapabilitySnapshot? = nil
  ) throws -> Phase1PackageResult {
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureCreated.rawValue)
    guard !approved.jpegBytes.isEmpty else {
      throw Phase1RuntimeError.fileRepresentationUnavailable
    }

    // Integrity: recomputed digest of frozen bytes must still equal the post-delegate freeze.
    let recomputed = ArtifactHashingService().sha256HexOfData(approved.jpegBytes)
    if recomputed != approved.sha256 {
      throw Phase1RuntimeError.hashReadbackMismatch(expected: approved.sha256, actual: recomputed)
    }

    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.capturePersisted.rawValue)
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureHashed.rawValue)
    _ = try CaptureSideStatusGuard.parseCaptureSide(CaptureSideStatus.captureSealed.rawValue)

    let clockSnap = clock.snapshot()
    let provenance = provenanceService.currentProvenance(
      defaults: defaults,
      hardwareModelOverride: hardwareModelOverride,
      iosVersionOverride: iosVersionOverride
    )
    let motion = motionService.sample(injected: motionInjected)

    let result = try packageBuilder.build(
      jpegBytes: approved.jpegBytes,
      ids: ids,
      clock: clockSnap,
      provenance: provenance,
      motion: motion,
      calibrationAvailability: .notAvailable,
      workRoot: workRoot,
      captureAppVersion: appVersion,
      previousStatus: .captureSealed,
      deviceCapabilitySnapshot: deviceCapabilitySnapshot ?? self.deviceCapabilitySnapshot
    )

    if result.artifactSha256 != approved.sha256 {
      throw Phase1RuntimeError.hashReadbackMismatch(
        expected: approved.sha256,
        actual: result.artifactSha256
      )
    }
    Phase1CaptureDiagnostics.log(
      stage: "artifact_hash",
      event: "export_invariance_ok",
      detail: "sha256=\(result.artifactSha256)"
    )
    return result
  }
}
