# Sprint 2.1F — Inspection Review, Grouped Evidence & Pre-Export Validation

| Field | Value |
|---|---|
| **Status** | `SPRINT_2_1F` (Linux `swift test`; device NOT RUN) |
| **Branch** | `cursor/sprint-2-1f-inspection-review-d881` |
| **Baseline** | Sprint 2.1 architecture LOCK + 2.1E.1 |
| **Architecture** | `Docs/Capture/SPRINT_2_1_ARCHITECTURE.md` (unchanged invariants) |
| **Next** | Sprint **2.2** Hardening & Field Reliability |

## Mission delivered

1. **Pre-export validation** — `PreExportValidationService` → `PreExportValidationReport`  
   - Pure `(InspectionSession) → report`  
   - Typed `PreExportBlockingReason`  
   - Combines frozen snapshot + progression terminals + derived evidence satisfaction  
   - Unbind after complete re-locks export  

2. **Inspection Review tab** — `InspectionReviewView`  
   - Point list with status tags + disclosure details  
   - Blocking reasons section  
   - Export preview (storage keys / library id hints)  
   - **Export packages…** gated on `isExportable` (share copies; originals untouched)  
   - **Fix this point** / **Go to point** → `jumpToPoint` (activate + Capture tab)  

3. **Export gate on Capture** — when a plan is assigned, still-export disabled until validation passes; link to Review  

4. **Grouped library polish** — “Tap to add required photo” deep-links via `jumpToPoint`  

5. **HUD** — More menu includes **Open Review**  

## Out of scope (→ 2.2)

- Memory / battery profiling  
- Interruption / crash recovery campaigns  
- Export soak stress  

## Field Regression Checklist

| Area | Result |
|---|---|
| 1. Camera & HUD layout | **NOT RUN** (no device / xcodebuild on Linux host) |
| 2. Workflow & satisfaction | Domain covered by `Sprint2_1FTests` + prior 2.1E suite; device NOT RUN |
| 3. Evidence lifecycle | Domain unbind→re-lock covered; device NOT RUN |
| 4. Persistence & recovery | Force-quit NOT RUN; package share path uses existing library copy APIs |

## Execution

```text
Host: Linux (Swift 5.10.1)
Command: swift test
Result: 248 executed, 1 skipped, 0 failures
Sprint2_1FTests: 6 executed, 0 failures
xcodebuild / device: NOT RUN
```

## Boundaries preserved

- AVCapture warm-up / permission: **untouched**  
- Envelope schema: **v1**  
- Views do not construct `EvidenceMetadata`  
- Soft-delete / write-once originals: **preserved**  
