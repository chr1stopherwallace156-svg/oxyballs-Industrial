# Sprint 2.1F — Execution Prompt

| Field | Value |
|---|---|
| **Status** | `IMPLEMENTED` — see `SPRINT_2_1F_STATUS.md` |
| **Depends on** | `Docs/Capture/SPRINT_2_1_ARCHITECTURE.md` **LOCKED** |
| **Baseline** | Sprint 2.1E.1 + architecture lock |

---

## Mission (strict)

Deliver **Inspection Review, Point-Grouped Evidence Refinement & Pre-Export Validation** without expanding into 2.2 hardening or Phase 3 spatial work.

### Delivered

1. **Point-grouped Evidence hierarchy** — Review disclosures + library deep-link `jumpToPoint`.
2. **Pre-export validation engine** — `PreExportValidationService` / `PreExportValidationReport`.
3. **Inspection review & export package** — Review tab; gated export CTAs; share package copies without mutating originals.

### Out of scope → 2.2

- Memory / battery profiling, long-session soak
- Crash / interruption recovery campaigns
- Export stress beyond clean build + integrity verify
- AR / LiDAR / twin overlays

### Invariants (must not break)

All eight invariants in `SPRINT_2_1_ARCHITECTURE.md`.

### Definition of done

- [x] Validation report derived only from frozen snapshot + bindings + progression terminals
- [x] Export disabled with explicit reasons when unsatisfied
- [x] Grouped library/review hierarchy consistent with binding storage keys
- [x] `swift test` green; Field Regression Checklist filled (device NOT RUN where applicable)
- [x] Architecture invariants unchanged (no schema bump)
