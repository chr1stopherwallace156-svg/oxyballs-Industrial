# Elektron Capture — Sprint 2.1 Architecture Baseline & Invariants

| Field | Value |
|---|---|
| **Status** | `LOCKED` |
| **Series** | Sprint 2.1A → 2.1E.1 |
| **Lock tip (code)** | Capture branch `cursor/sprint-2-1e1-evidence-hud-polish-d881` |
| **Next sprint** | **2.1F** — Inspection Review, Grouped Hierarchy & Pre-Export Validation |
| **Deferred** | **2.2** Hardening · Phase 3 Spatial |

This document is the **authoritative contract** for domain layering, unidirectional data flow, and field regression before Sprint 2.1F / 2.2. Pseudocode in planning notes must yield to the types and boundaries named here.

---

## 1. Architecture Layering & Data Flow

```text
1. Immutable Plan Snapshot (`InspectionPlanSnapshot`)     → Domain Authority
2. Stateless Engine (`InspectionProgressionEngine`)       → Workflow Transitions
3. Stateless Binder (`EvidenceBindingService`)            → Evidence Lifecycle & Validation
4. Session Envelope (`InspectionSession`)                 → Immutable State Container
5. App Orchestrator (`GuidedInspectionCoordinator`)       → Async Intent & Persistence
6. Presentation Adapter (`GuidedInspectionPresenter` /
   `GuidedInspectionViewModel`)                           → UI State Mapping
7. SwiftUI Views                                          → Pure Render + Intent Emission
```

### Unidirectional flow (shipped)

```text
SwiftUI Overlay / Library
        │ emits GuidedInspectionIntent
        ▼
GuidedInspectionViewModel
        │ ephemeral GuidedInspectionUIState only
        │ delegates intent (no disk / no EvidenceMetadata construction)
        ▼
GuidedInspectionCoordinator (struct, Sendable)
        │ apply intent → domain services
        │ persist via GuidedSessionPersisting (sole owner of session saves)
        │ captureRequested → shouldTriggerShutter only (no AVCapture call)
        ▼
InspectionProgressionEngine  +  EvidenceBindingService
        │ pure (Session) → Session
        ▼
Updated InspectionSession (+ derived GuidedInspectionPresentationState)
        │
        ▼
ViewModel adopts session / publishes presentation
```

**Camera boundary:** `AVCaptureSession` warm-up, permission, resume, and shutter live in the Phase 1 capture path. The coordinator **signals** shutter readiness; it does **not** own the camera controller.

---

## 2. Strict Architecture Invariants

1. SwiftUI views **NEVER** mutate `InspectionSession` or construct domain `EvidenceMetadata`.
2. `GuidedInspectionCoordinator` (**struct**) is the **SOLE** owner of guided-session persistence side-effects (`GuidedSessionPersisting` / `persistGuidedSession`).
3. `EvidenceBindingService` and `InspectionProgressionEngine` **MUST** remain strictly stateless — no singletons, no `.shared`.
4. `InspectionPlanSnapshot` is frozen and authoritative for all point thresholds and instructions (`snapshotSHA256` per S2-002).
5. All domain mutations **MUST** be pure: `(InspectionSession) → new InspectionSession`.
6. Camera preview lifecycle (`AVCaptureSession`) operates independently of workflow state transitions.
7. Unbinding, replacing, or deleting evidence **MUST** immediately trigger dynamic requirement satisfaction re-evaluation (derived; never persisted as a flag).
8. Soft-delete **quarantines** original binary media; evidence is **never** destructively overwritten on disk (retake = new capture-id).

### Additional shipped locks

- Envelope schema remains **v1** (Option A) unless a material incompatibility forces a bump.
- Satisfaction is **derived** from binding count vs frozen `expectedEvidenceType` / `InspectionEvidenceRequirement`.
- Ephemeral UI (`GuidedInspectionUIState`: dialogs, drafts, `captureInProgress`, alerts) **MUST NOT** appear on the session wire format.
- Point identities for binding come only from the session’s frozen snapshot.

---

## 3. Intent Surface (authoritative)

```swift
public enum GuidedInspectionIntent: Equatable, Sendable {
  case prepareGuidedSession
  case activatePoint(InspectionPointID)
  case advanceRequested
  case returnRequested
  case completePointRequested
  case skipRequested(reason: String)
  case blockRequested(reason: String)
  case captureRequested                          // validate + shouldTriggerShutter
  case bindApprovedCapture(storageKey:type:attributes:)
  case unbindLibraryEvidence(libraryEvidenceId:)
  case replaceLibraryEvidence(oldLibraryEvidenceId:storageKey:type:attributes:)
}
```

Bindings live on `InspectionSession.evidenceBindings` (`EvidenceBindingCollection`), not a fictional `boundEvidence` array.

---

## 4. Presentation Split

| Type | Role |
|---|---|
| `GuidedInspectionPresentationState` | Derived HUD model from session + snapshot + binding/progression queries |
| `GuidedInspectionPresenter` | Pure factory for presentation state |
| `GuidedInspectionUIState` | Ephemeral only (sheets, drafts, in-flight, alerts) |
| `GuidedInspectionViewModel` | Thin adapter: intents in, adopt session / publish presentation |

Views bind to presentation flags (`canAdvance`, `canCapture`, …); they do not re-implement satisfaction math.

---

## 5. Field Regression Checklist (gate for every sprint ≥ 2.1F)

Every sprint from this point forward enforces this gate prior to sign-off (device when available; else honest **NOT RUN**):

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│                       FIELD REGRESSION CHECKLIST                            │
├──────────────────────────────────────┬──────────────────────────────────────┤
│ 1. CAMERA & HUD LAYOUT               │ 2. WORKFLOW & SATISFACTION           │
│  ✓ First-launch camera starts        │  ✓ "Next" unlocks ONLY when domain   │
│  ✓ App resume keeps preview active   │    evaluates requirement satisfaction│
│  ✓ Single Capture button responds    │  ✓ Skip & Block require valid text   │
│  ✓ Guidance HUD overlays correctly   │  ✓ Return / Previous navigation works│
├──────────────────────────────────────┼──────────────────────────────────────┤
│ 3. EVIDENCE LIFECYCLE                │ 4. PERSISTENCE & RECOVERY            │
│  ✓ Immediate thumbnail refresh       │  ✓ Force-quit mid-session preserves  │
│  ✓ Retake replaces & updates count   │    active point, bound evidence, and │
│  ✓ Delete quarantines & re-evaluates │    satisfaction status accurately    │
│  ✓ Satisfaction rollback re-locks    │  ✓ Export package builds cleanly with│
│    "Next" button instantly           │    correct metadata & manifest integrity│
└──────────────────────────────────────┴──────────────────────────────────────┘
```

---

## 6. Sprint 2.1F Mission Boundary (preview)

**In scope:**

1. Point-grouped Evidence hierarchy refinement (status tags, review navigation)
2. Session pre-export validation engine (all point requirements before export enablement)
3. Inspection review & export package generation (manifest integrity, ZIP / `.edts-pkg` preview)

**Explicitly out of scope (→ Sprint 2.2):**

- Memory / battery profiling under long sessions
- Offline crash recovery stress
- Phone-call / lock-screen interruption campaigns
- Large-package export soak tests beyond basic clean build

**Still no Phase 3** (AR / LiDAR / digital twin).

---

## 7. Master Roadmap Status

```text
2.1A  Immutable Plan Foundation              ✅ Complete
2.1B  Persistence Envelope                   ✅ Complete
2.1C  Progression Engine                     ✅ Complete
2.1D  Evidence Binding Service               ✅ Complete
2.1E  Guided Capture UI & Intents            ✅ Complete
2.1E.1 Technician Workflow Polish            ✅ Complete
 Docs/Capture/SPRINT_2_1_ARCHITECTURE.md     ──► LOCKED BASELINE
2.1F  Inspection Review & Pre-Export         ✅ Complete

-------------------------------------------------------------------
2.2   Hardening, Memory/Battery & Field Resilience ──► NEXT
3.0   Spatial Computing (AR Overlays, LiDAR, Digital Twin)
```

---

## 8. Related locks

- `Docs/Capture/SPRINT_2_PROGRESS_LOCK.md` (S2-001)
- `Docs/Capture/SPRINT_2_SNAPSHOT_HASH_LOCK.md` (S2-002)
- `Docs/Capture/SPRINT_2_ROADMAP.md`
- `Docs/Capture/SPRINT_2_1E_DEFINITION_OF_DONE.md`
- `Docs/Capture/SPRINT_2_1E1_STATUS.md`
