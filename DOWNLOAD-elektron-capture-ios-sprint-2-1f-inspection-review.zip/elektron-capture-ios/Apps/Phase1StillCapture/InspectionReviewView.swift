import SwiftUI
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// Sprint 2.1F — inspection review, pre-export validation, export preview.
struct InspectionReviewView: View {
  @EnvironmentObject private var inspection: InspectionSessionViewModel
  @EnvironmentObject private var guided: GuidedInspectionViewModel
  @EnvironmentObject private var session: AppSessionContainer
  @EnvironmentObject private var library: EvidenceLibraryViewModel

  @State private var statusMessage = ""
  @State private var shareItems: [Any] = []
  @State private var showShare = false
  @State private var expandedPoints: Set<String> = []

  private let validation = PreExportValidationService()

  private var report: PreExportValidationReport {
    guard let current = inspection.current else {
      return PreExportValidationReport(
        isExportable: false,
        disposition: .incomplete,
        blockingReasons: [.noAssignedPlan],
        points: [],
        exportPreview: [],
        satisfiedRequiredCount: 0,
        requiredPointCount: 0
      )
    }
    return validation.validate(current)
  }

  var body: some View {
    NavigationStack {
      List {
        Section {
          VStack(alignment: .leading, spacing: 8) {
            Text(report.summaryLine)
              .font(.headline)
            Text("Disposition: \(dispositionLabel(report.disposition))")
              .font(.subheadline)
              .foregroundStyle(.secondary)
            if let current = inspection.current {
              Text(current.id.rawValue)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
            }
          }
          .padding(.vertical, 4)
        } header: {
          Text("Export readiness")
        }

        if !report.blockingReasons.isEmpty {
          Section("Blocking reasons") {
            ForEach(report.blockingReasons) { reason in
              Label(reason.displayMessage, systemImage: "exclamationmark.triangle.fill")
                .foregroundStyle(.orange)
                .font(.subheadline)
            }
          }
        }

        Section("Inspection points") {
          ForEach(report.points) { row in
            DisclosureGroup(
              isExpanded: Binding(
                get: { expandedPoints.contains(row.pointID.rawValue) },
                set: { open in
                  if open { expandedPoints.insert(row.pointID.rawValue) }
                  else { expandedPoints.remove(row.pointID.rawValue) }
                }
              )
            ) {
              LabeledContent("Required", value: row.isRequired ? "Yes" : "No")
              LabeledContent("Evidence", value: "\(row.boundCount) / \(row.requiredCount)")
              if let status = row.status {
                LabeledContent("Workflow", value: workflowLabel(status))
              }
              if row.blocksExport {
                Text("Blocks export")
                  .font(.caption.weight(.semibold))
                  .foregroundStyle(.orange)
              }
              Button {
                Task { await session.jumpToPoint(row.pointID) }
              } label: {
                Label(
                  row.blocksExport ? "Fix this point" : "Go to point",
                  systemImage: "camera.fill"
                )
              }
            } label: {
              HStack {
                VStack(alignment: .leading, spacing: 2) {
                  Text(row.title)
                    .font(.body.weight(.semibold))
                  Text(row.statusTag)
                    .font(.caption)
                    .foregroundStyle(row.blocksExport ? Color.orange : Color.green)
                }
                Spacer()
                if row.isRequired {
                  Text("REQ")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(.secondary)
                }
              }
            }
          }
        }

        Section("Export preview") {
          if report.exportPreview.isEmpty {
            Text("No bound evidence yet.")
              .foregroundStyle(.secondary)
          } else {
            ForEach(report.exportPreview) { item in
              VStack(alignment: .leading, spacing: 4) {
                Text(item.pointTitle)
                  .font(.subheadline.weight(.semibold))
                Text(item.storageKey)
                  .font(.caption2.monospaced())
                  .foregroundStyle(.secondary)
                if let lib = item.libraryEvidenceIdHint {
                  Text("Library id: \(lib)")
                    .font(.caption2.monospaced())
                }
              }
              .padding(.vertical, 2)
            }
          }
        }

        Section {
          Button {
            Task { await prepareExportShares() }
          } label: {
            Label("Export packages…", systemImage: "square.and.arrow.up")
          }
          .disabled(!report.isExportable)

          if !report.isExportable {
            Text("Export stays disabled until every required point is satisfied or validly skipped (blocked points prevent export).")
              .font(.caption)
              .foregroundStyle(.secondary)
          }

          if !statusMessage.isEmpty {
            Text(statusMessage)
              .font(.caption)
              .foregroundStyle(.mint)
          }
        }
      }
      .navigationTitle("Review")
      .toolbar {
        ToolbarItem(placement: .topBarTrailing) {
          Button("Refresh") {
            guided.refresh()
            Task { await library.reload() }
          }
        }
      }
      .onAppear {
        guided.refresh()
        // Expand blocking points by default.
        expandedPoints = Set(report.points.filter(\.blocksExport).map(\.pointID.rawValue))
      }
      .sheet(isPresented: $showShare) {
        ActivityShareView(items: shareItems) { completed in
          statusMessage = completed
            ? "Share completed — library originals untouched."
            : "Share dismissed — library originals untouched."
        }
      }
    }
  }

  private func dispositionLabel(_ d: InspectionCompletionDisposition) -> String {
    switch d {
    case .incomplete: return "Incomplete"
    case .complete: return "Complete"
    case .blocked: return "Blocked"
    }
  }

  private func workflowLabel(_ status: InspectionPointStatus) -> String {
    switch status {
    case .notStarted: return "Not started"
    case .inProgress: return "In progress"
    case .completed: return "Completed"
    case .skipped(let r): return "Skipped (\(r))"
    case .blocked(let r): return "Blocked (\(r))"
    }
  }

  @MainActor
  private func prepareExportShares() async {
    let currentReport = report
    guard currentReport.isExportable else {
      statusMessage = currentReport.blockingReasons.first?.displayMessage
        ?? "Export is blocked."
      return
    }
    do {
      let store = try await library.storeRef()
      var urls: [URL] = []
      let staging = FileManager.default.temporaryDirectory
        .appendingPathComponent("InspectionReviewExport-\(UUID().uuidString)", isDirectory: true)
      try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)

      for item in currentReport.exportPreview {
        guard let libId = item.libraryEvidenceIdHint else { continue }
        let dest = staging.appendingPathComponent("\(libId).edts-pkg")
        do {
          let url = try await store.copyExportPackage(id: libId, to: dest)
          urls.append(url)
        } catch {
          // Package may not exist yet — still list as missing in status.
          statusMessage = "Missing package for \(libId): \(error.localizedDescription)"
        }
      }

      if urls.isEmpty {
        statusMessage =
          "No .edts-pkg copies available yet. Export each capture from Capture (when approved) or Library after packages exist. Validation passed for \(currentReport.exportPreview.count) bound item(s)."
        return
      }
      shareItems = urls
      showShare = true
      statusMessage = "Sharing \(urls.count) package copy(ies) — canonical library untouched."
    } catch {
      statusMessage = "Export prepare failed: \(error.localizedDescription)"
    }
  }
}

#endif
