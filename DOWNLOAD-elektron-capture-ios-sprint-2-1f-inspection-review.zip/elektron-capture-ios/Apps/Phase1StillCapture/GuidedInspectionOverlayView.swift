import SwiftUI
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

/// Lightweight HUD over live camera. Single primary Capture; Skip/Block behind More.
struct GuidedInspectionOverlayView: View {
  @ObservedObject var guided: GuidedInspectionViewModel
  @EnvironmentObject private var session: AppSessionContainer
  var onCaptureRequested: () -> Void

  var body: some View {
    VStack(spacing: 0) {
      if guided.presentation.isGuidedAvailable {
        hudCard
        Spacer()
        bottomBar
      } else {
        Spacer()
      }
    }
    .padding(.horizontal, 14)
    .padding(.top, 10)
    .padding(.bottom, 28)
    .alert(
      guided.ui.alert?.title ?? "Guided Inspection",
      isPresented: Binding(
        get: { guided.ui.alert != nil },
        set: { if !$0 { guided.ui.alert = nil } }
      )
    ) {
      Button("OK", role: .cancel) { guided.ui.alert = nil }
    } message: {
      Text(guided.ui.alert?.message ?? "")
    }
    .sheet(isPresented: Binding(
      get: { guided.ui.showingSkipDialog },
      set: { guided.ui.showingSkipDialog = $0 }
    )) {
      reasonSheet(
        title: "Skip Point",
        draft: Binding(
          get: { guided.ui.draftSkipReason },
          set: { guided.ui.draftSkipReason = $0 }
        ),
        confirmTitle: "Skip",
        onCancel: { guided.ui.showingSkipDialog = false },
        onConfirm: { Task { await guided.confirmSkip() } }
      )
    }
    .sheet(isPresented: Binding(
      get: { guided.ui.showingBlockDialog },
      set: { guided.ui.showingBlockDialog = $0 }
    )) {
      reasonSheet(
        title: "Block Point",
        draft: Binding(
          get: { guided.ui.draftBlockReason },
          set: { guided.ui.draftBlockReason = $0 }
        ),
        confirmTitle: "Block",
        onCancel: { guided.ui.showingBlockDialog = false },
        onConfirm: { Task { await guided.confirmBlock() } }
      )
    }
  }

  private var hudCard: some View {
    VStack(alignment: .leading, spacing: 6) {
      HStack {
        Text(guided.presentation.pointPositionLabel)
          .font(.caption.weight(.semibold))
          .foregroundStyle(.white.opacity(0.9))
        Spacer()
        Text("\(guided.presentation.planProgressPercent)%")
          .font(.caption.monospaced())
          .foregroundStyle(.white.opacity(0.8))
      }
      Text(guided.presentation.activePointTitle ?? "No active point")
        .font(.headline)
        .foregroundStyle(.white)
      if let guidance = guided.presentation.guidanceText, !guidance.isEmpty {
        Text(guidance)
          .font(.caption)
          .foregroundStyle(.white.opacity(0.9))
          .lineLimit(2)
      }
      Text(guided.presentation.evidenceStatusLabel)
        .font(.caption.monospaced())
        .foregroundStyle(
          guided.presentation.isPointSatisfied ? Color.green.opacity(0.95) : Color.white.opacity(0.88)
        )
    }
    .padding(12)
    .frame(maxWidth: .infinity, alignment: .leading)
    .background(.ultraThinMaterial.opacity(0.82))
    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
  }

  private var bottomBar: some View {
    VStack(spacing: 10) {
      if guided.presentation.canPrepare && guided.presentation.activePointID == nil {
        Button {
          Task { await guided.prepareIfNeeded() }
        } label: {
          Text("Start Guidance")
            .font(.subheadline.weight(.semibold))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
        }
        .buttonStyle(.borderedProminent)
      }

      HStack(spacing: 12) {
        Button {
          Task { await guided.goBack() }
        } label: {
          Image(systemName: "chevron.left")
            .font(.title3.weight(.semibold))
            .frame(width: 48, height: 48)
        }
        .buttonStyle(.bordered)
        .tint(.white)
        .disabled(!guided.presentation.canReturn || guided.ui.captureInProgress)

        Button {
          onCaptureRequested()
        } label: {
          Text(guided.ui.captureInProgress ? "Capturing…" : "Capture Photo")
            .font(.headline.weight(.bold))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
        }
        .buttonStyle(.borderedProminent)
        .tint(.blue)
        .disabled(!guided.presentation.canCapture || guided.ui.captureInProgress)

        Button {
          Task { await guided.advance() }
        } label: {
          Image(systemName: "chevron.right")
            .font(.title3.weight(.semibold))
            .frame(width: 48, height: 48)
        }
        .buttonStyle(.borderedProminent)
        .disabled(!guided.presentation.canAdvance || guided.ui.captureInProgress)
      }

      HStack {
        Menu {
          Button("Skip Point…") { guided.openSkipDialog() }
            .disabled(!guided.presentation.canSkip || guided.ui.captureInProgress)
          Button("Block Point…") { guided.openBlockDialog() }
            .disabled(!guided.presentation.canBlock || guided.ui.captureInProgress)
          Button("Mark Complete") {
            Task { await guided.completePoint() }
          }
          .disabled(!guided.presentation.canComplete || guided.ui.captureInProgress)
          Divider()
          Button("Open Review") {
            session.selectedTab = .review
          }
        } label: {
          Label("More", systemImage: "ellipsis.circle")
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(.white)
        }
        Spacer()
        Text(modelReadinessHint)
          .font(.caption2)
          .foregroundStyle(.white.opacity(0.7))
      }
    }
    .padding(12)
    .background(.ultraThinMaterial.opacity(0.82))
    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
  }

  private var modelReadinessHint: String {
    if guided.ui.captureInProgress { return "Capture in progress" }
    if guided.presentation.isPointSatisfied { return "Point satisfied" }
    return "Tap Capture Photo"
  }

  private func reasonSheet(
    title: String,
    draft: Binding<String>,
    confirmTitle: String,
    onCancel: @escaping () -> Void,
    onConfirm: @escaping () -> Void
  ) -> some View {
    NavigationStack {
      Form {
        Section("Reason (required)") {
          TextField("Reason", text: draft)
        }
      }
      .navigationTitle(title)
      .navigationBarTitleDisplayMode(.inline)
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Cancel", action: onCancel)
        }
        ToolbarItem(placement: .confirmationAction) {
          Button(confirmTitle, action: onConfirm)
            .disabled(draft.wrappedValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
      }
    }
    .presentationDetents([.medium])
  }
}

#endif
