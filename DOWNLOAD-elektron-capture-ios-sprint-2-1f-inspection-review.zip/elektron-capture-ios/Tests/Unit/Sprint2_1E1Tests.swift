import XCTest
@testable import ElektronCapture

/// Sprint 2.1E.1 — replace/unbind lifecycle + point-grouped library sections.
final class Sprint2_1E1Tests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_400_000)
  private let service = EvidenceBindingService()

  private func makeSnapshot() throws -> InspectionPlanSnapshot {
    let plan = try InspectionPlan(
      id: "e1_demo",
      version: "1.0.0",
      title: "E1 Demo",
      points: [
        try InspectionPoint(id: "vin", title: "VIN Plate", displayOrder: 1, isRequired: true),
        try InspectionPoint(
          id: "battery",
          title: "Battery Compartment",
          displayOrder: 2,
          isRequired: true,
          expectedEvidenceType: .multiPhoto
        ),
      ]
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession(id: String = "INS-21E1") throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "E1-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: makeSnapshot(),
      assignedAt: fixedInstant
    )
  }

  private func pointID(_ raw: String) -> InspectionPointID {
    InspectionPointID.unchecked(raw)
  }

  private func meta(
    id: EvidenceID = EvidenceID(),
    point: String,
    session: InspectionSession,
    key: String
  ) -> EvidenceMetadata {
    EvidenceMetadata(
      id: id,
      pointID: pointID(point),
      sessionID: session.id,
      type: .photo,
      createdAt: fixedInstant,
      storageKey: key,
      payloadAttributes: [:]
    )
  }

  private func libraryRecord(id: String, sessionID: String) -> EvidenceLibraryIndexRecord {
    EvidenceLibraryIndexRecord(
      id: id,
      captureTimestamp: fixedInstant,
      sessionId: "SESSION-\(id)",
      artifactId: "ART-\(id)",
      recordId: "REC-\(id)",
      inspectionSessionID: sessionID,
      inspectionVehicleIdentifier: "E1-1",
      inspectionVehicleIdentifierKind: VehicleIdentifierKind.unknown.rawValue,
      inspectionInspectorID: "INSPECTOR-LOCAL",
      inspectionInspectorName: "Local",
      inspectionStartedAtUTC: "2026-07-26T12:00:00Z",
      inspectionStatusAtCapture: SessionStatus.inProgress.rawValue,
      isSynthetic: true,
      originalRelativePath: "captures/\(id)/artifact_original.jpg",
      thumbnailRelativePath: "captures/\(id)/thumbnail.jpg",
      originalSha256: String(repeating: "a", count: 64),
      originalByteCount: 128
    )
  }

  // MARK: - Replace / unbind library

  func testReplaceSwapsEvidenceAndRecalculatesSatisfaction() throws {
    var session = try makeSession()
    let oldID = EvidenceID()
    let old = meta(
      id: oldID,
      point: "battery",
      session: session,
      key: "INS-21E1/battery/\(oldID.rawValue.uuidString)/lib-old"
    )
    let second = meta(
      point: "battery",
      session: session,
      key: "INS-21E1/battery/\(EvidenceID().rawValue.uuidString)/lib-2"
    )
    session = try service.bind(evidence: old, to: session)
    session = try service.bind(evidence: second, to: session)
    XCTAssertTrue(service.isPointSatisfied(pointID: pointID("battery"), in: session))

    let replacement = meta(
      point: "battery",
      session: session,
      key: "INS-21E1/battery/\(EvidenceID().rawValue.uuidString)/lib-new"
    )
    session = try service.replace(evidenceID: oldID, with: replacement, in: session)

    let bound = service.evidence(for: pointID("battery"), in: session)
    XCTAssertEqual(bound.count, 2)
    XCTAssertFalse(bound.contains(where: { $0.id == oldID }))
    XCTAssertTrue(bound.contains(where: { $0.id == replacement.id }))
    XCTAssertTrue(service.isPointSatisfied(pointID: pointID("battery"), in: session))
  }

  func testUnbindLibraryEvidenceDropsSatisfaction() throws {
    var session = try makeSession()
    let libId = "EVD-LIB-001"
    let e1 = meta(
      point: "battery",
      session: session,
      key: "INS-21E1/battery/\(EvidenceID().rawValue.uuidString)/\(libId)"
    )
    let e2 = meta(
      point: "battery",
      session: session,
      key: "INS-21E1/battery/\(EvidenceID().rawValue.uuidString)/lib-other"
    )
    session = try service.bind(evidence: e1, to: session)
    session = try service.bind(evidence: e2, to: session)
    XCTAssertTrue(service.isPointSatisfied(pointID: pointID("battery"), in: session))

    session = service.unbindLibraryEvidence(libraryEvidenceId: libId, from: session)
    XCTAssertEqual(service.evidenceCount(for: pointID("battery"), in: session), 1)
    XCTAssertFalse(service.isPointSatisfied(pointID: pointID("battery"), in: session))
  }

  func testCoordinatorReplaceLibraryPreservesPointID() throws {
    var session = try makeSession()
    let progression = InspectionProgressionEngine()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)

    let oldID = EvidenceID()
    let libOld = "EVD-OLD"
    let old = meta(
      id: oldID,
      point: "vin",
      session: session,
      key: GuidedInspectionCoordinator.makeStorageKey(
        sessionID: session.id,
        pointID: pointID("vin"),
        evidenceID: oldID,
        approvedKey: libOld
      )
    )
    session = try service.bind(evidence: old, to: session)

    // Move active point away — replace must still target VIN.
    session = try progression.activate(pointID: pointID("battery"), in: session)

    let coordinator = GuidedInspectionCoordinator(persister: nil)
    let handled = try coordinator.apply(
      .replaceLibraryEvidence(
        oldLibraryEvidenceId: libOld,
        storageKey: "EVD-NEW",
        type: .photo,
        attributes: ["sha256_prefix": "abc"]
      ),
      session: session
    )
    let bound = service.evidence(for: pointID("vin"), in: handled.session)
    XCTAssertEqual(bound.count, 1)
    XCTAssertNotEqual(bound[0].id, oldID)
    XCTAssertTrue(bound[0].storageKey.contains("EVD-NEW"))
    XCTAssertEqual(service.evidenceCount(for: pointID("battery"), in: handled.session), 0)
    XCTAssertTrue(service.isPointSatisfied(pointID: pointID("vin"), in: handled.session))
  }

  // MARK: - Point grouping

  func testPointGroupingSectionsAndStatusLabels() throws {
    var session = try makeSession()
    let vinLib = "EVD-VIN"
    let batLib = "EVD-BAT"
    session = try service.bind(
      evidence: meta(
        point: "vin",
        session: session,
        key: "INS-21E1/vin/\(EvidenceID().rawValue.uuidString)/\(vinLib)"
      ),
      to: session
    )
    session = try service.bind(
      evidence: meta(
        point: "battery",
        session: session,
        key: "INS-21E1/battery/\(EvidenceID().rawValue.uuidString)/\(batLib)"
      ),
      to: session
    )

    let captures = [
      libraryRecord(id: vinLib, sessionID: session.id.rawValue),
      libraryRecord(id: batLib, sessionID: session.id.rawValue),
      libraryRecord(id: "EVD-ORPHAN", sessionID: session.id.rawValue),
    ]
    let group = InspectionEvidenceGroup(
      sessionID: session.id.rawValue,
      vehicleIdentifier: "E1-1",
      vehicleIdentifierKind: VehicleIdentifierKind.unknown.rawValue,
      inspectorID: "INSPECTOR-LOCAL",
      inspectorName: "Local",
      startedAtUTC: "2026-07-26T12:00:00Z",
      sessionStatusAtLatestCapture: SessionStatus.inProgress.rawValue,
      latestCaptureAt: fixedInstant,
      captures: captures
    )

    let sections = InspectionPointEvidenceGrouping.sections(group: group, session: session)
    XCTAssertEqual(sections.count, 3) // vin + battery + unlinked
    XCTAssertEqual(sections[0].title, "VIN Plate")
    XCTAssertTrue(sections[0].isSatisfied)
    XCTAssertEqual(sections[0].statusLabel, "✓ Satisfied")
    XCTAssertEqual(sections[0].captures.map(\.id), [vinLib])

    XCTAssertEqual(sections[1].title, "Battery Compartment")
    XCTAssertFalse(sections[1].isSatisfied)
    XCTAssertTrue(sections[1].needsMoreEvidence)
    XCTAssertEqual(sections[1].statusLabel, "● 1 of 2 Required")
    XCTAssertEqual(sections[1].captures.map(\.id), [batLib])

    XCTAssertNil(sections[2].pointID)
    XCTAssertEqual(sections[2].captures.map(\.id), ["EVD-ORPHAN"])
  }
}
