import XCTest
@testable import ElektronCapture

final class Sprint2_1FTests: XCTestCase {
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_500_000)
  private let binding = EvidenceBindingService()
  private let progression = InspectionProgressionEngine()
  private let validation = PreExportValidationService()

  private func makeSnapshot() throws -> InspectionPlanSnapshot {
    let plan = try InspectionPlan(
      id: "f_demo",
      version: "1.0.0",
      title: "F Demo",
      points: [
        try InspectionPoint(id: "vin", title: "VIN Plate", displayOrder: 1, isRequired: true),
        try InspectionPoint(
          id: "battery",
          title: "Battery",
          displayOrder: 2,
          isRequired: true,
          expectedEvidenceType: .multiPhoto
        ),
        try InspectionPoint(id: "note", title: "Optional Note", displayOrder: 3, isRequired: false),
      ]
    )
    return try InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(fixedInstant)
    ).makeSnapshot(from: plan)
  }

  private func makeSession() throws -> InspectionSession {
    try InspectionSession.assigning(
      id: SessionID.unchecked("INS-21F"),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "F-1")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planSnapshot: makeSnapshot(),
      assignedAt: fixedInstant
    )
  }

  private func pointID(_ raw: String) -> InspectionPointID {
    InspectionPointID.unchecked(raw)
  }

  private func bind(
    _ session: InspectionSession,
    point: String,
    key: String
  ) throws -> InspectionSession {
    try binding.bind(
      evidence: EvidenceMetadata(
        pointID: pointID(point),
        sessionID: session.id,
        type: .photo,
        createdAt: fixedInstant,
        storageKey: key,
        payloadAttributes: [:]
      ),
      to: session
    )
  }

  // MARK: - Validation

  func testNoPlanAndNoProgressBlockExport() throws {
    let legacy = try InspectionSession(
      id: SessionID.unchecked("INS-LEGACY-F"),
      vehicle: InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "L")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      planState: .legacyUnassigned
    )
    let report = validation.validate(legacy)
    XCTAssertFalse(report.isExportable)
    XCTAssertTrue(report.blockingReasons.contains(.noAssignedPlan))
  }

  func testOpenRequiredPointsBlockExport() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)
    let report = validation.validate(session)
    XCTAssertFalse(report.isExportable)
    XCTAssertTrue(
      report.blockingReasons.contains {
        if case .requiredPointOpen(let id, _, _) = $0 { return id == pointID("vin") }
        if case .requiredPointInsufficientEvidence(let id, _, _, _) = $0 {
          return id == pointID("vin")
        }
        return false
      }
    )
  }

  func testSatisfiedCompletedRequiredPointsAllowExport() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)

    session = try progression.activate(pointID: pointID("vin"), in: session)
    session = try bind(session, point: "vin", key: "INS-21F/vin/\(EvidenceID().rawValue.uuidString)/EVD-VIN")
    session = try progression.completeActivePoint(in: session)

    session = try progression.activate(pointID: pointID("battery"), in: session)
    session = try bind(session, point: "battery", key: "INS-21F/battery/\(EvidenceID().rawValue.uuidString)/EVD-B1")
    session = try bind(session, point: "battery", key: "INS-21F/battery/\(EvidenceID().rawValue.uuidString)/EVD-B2")
    session = try progression.completeActivePoint(in: session)

    // Optional left untouched — must not block.
    let report = validation.validate(session)
    XCTAssertTrue(report.isExportable, report.summaryLine)
    XCTAssertEqual(report.blockingReasons, [])
    XCTAssertEqual(report.exportPreview.count, 3)
    XCTAssertEqual(report.satisfiedRequiredCount, 2)
    XCTAssertEqual(report.disposition, .complete)
  }

  func testSkipAllowsExportBlockDoesNot() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)

    session = try progression.activate(pointID: pointID("vin"), in: session)
    session = try bind(session, point: "vin", key: "k-vin")
    session = try progression.completeActivePoint(in: session)

    session = try progression.activate(pointID: pointID("battery"), in: session)
    session = try progression.skipActivePoint(reason: "inaccessible", in: session)

    var report = validation.validate(session)
    XCTAssertTrue(report.isExportable)
    XCTAssertEqual(report.disposition, .complete)

    // Re-open path: block battery instead (new session path via incomplete then block)
    session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)
    session = try bind(session, point: "vin", key: "k-vin-2")
    session = try progression.completeActivePoint(in: session)
    session = try progression.activate(pointID: pointID("battery"), in: session)
    session = try progression.blockActivePoint(reason: "hazmat", in: session)

    report = validation.validate(session)
    XCTAssertFalse(report.isExportable)
    XCTAssertEqual(report.disposition, .blocked)
    XCTAssertTrue(
      report.blockingReasons.contains {
        if case .requiredPointBlocked(_, _, let reason) = $0 { return reason == "hazmat" }
        return false
      }
    )
  }

  func testUnbindAfterCompleteDropsExportability() throws {
    var session = try makeSession()
    session = try progression.initializeProgress(for: session)
    session = try progression.activate(pointID: pointID("vin"), in: session)
    let eid = EvidenceID()
    session = try binding.bind(
      evidence: EvidenceMetadata(
        id: eid,
        pointID: pointID("vin"),
        sessionID: session.id,
        type: .photo,
        createdAt: fixedInstant,
        storageKey: "INS-21F/vin/\(eid.rawValue.uuidString)/EVD-X",
        payloadAttributes: [:]
      ),
      to: session
    )
    session = try progression.completeActivePoint(in: session)
    session = try progression.activate(pointID: pointID("battery"), in: session)
    session = try progression.skipActivePoint(reason: "n/a", in: session)
    XCTAssertTrue(validation.validate(session).isExportable)

    session = try binding.unbind(evidenceID: eid, from: session)
    let report = validation.validate(session)
    XCTAssertFalse(report.isExportable)
    XCTAssertTrue(
      report.blockingReasons.contains {
        if case .requiredPointInsufficientEvidence(let id, _, _, _) = $0 {
          return id == pointID("vin")
        }
        return false
      }
    )
  }

  func testExportPreviewLibraryHint() {
    let key = GuidedInspectionCoordinator.makeStorageKey(
      sessionID: SessionID.unchecked("INS-21F"),
      pointID: pointID("vin"),
      evidenceID: EvidenceID(),
      approvedKey: "EVD-LIB-99"
    )
    XCTAssertEqual(PreExportValidationService.libraryIdHint(from: key), "EVD-LIB-99")
  }
}
