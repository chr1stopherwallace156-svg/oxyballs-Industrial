import Foundation

// MARK: - Blocking reasons (typed — never free-text domain errors)

/// Why a session is not exportable. Stable for UI mapping and tests.
public enum PreExportBlockingReason: Equatable, Sendable, Identifiable {
  case noAssignedPlan
  case progressNotInitialized
  case sessionNotInProgress(SessionStatus)
  case requiredPointOpen(pointID: InspectionPointID, title: String, status: InspectionPointStatus)
  case requiredPointInsufficientEvidence(
    pointID: InspectionPointID,
    title: String,
    boundCount: Int,
    requiredCount: Int
  )
  case requiredPointBlocked(pointID: InspectionPointID, title: String, reason: String)

  public var id: String {
    switch self {
    case .noAssignedPlan: return "noAssignedPlan"
    case .progressNotInitialized: return "progressNotInitialized"
    case .sessionNotInProgress(let s): return "sessionNotInProgress:\(s.rawValue)"
    case .requiredPointOpen(let id, _, _): return "open:\(id.rawValue)"
    case .requiredPointInsufficientEvidence(let id, _, _, _): return "evidence:\(id.rawValue)"
    case .requiredPointBlocked(let id, _, _): return "blocked:\(id.rawValue)"
    }
  }

  /// Operator-facing explanation (presentation may wrap further).
  public var displayMessage: String {
    switch self {
    case .noAssignedPlan:
      return "No frozen inspection plan is assigned to this session."
    case .progressNotInitialized:
      return "Guided progress has not been initialized."
    case .sessionNotInProgress(let status):
      return "Session status is \(status.displayName); export requires an in-progress inspection."
    case .requiredPointOpen(_, let title, let status):
      return "Required point “\(title)” is still \(statusLabel(status))."
    case .requiredPointInsufficientEvidence(_, let title, let bound, let required):
      return "Required point “\(title)” has \(bound) of \(required) required evidence."
    case .requiredPointBlocked(_, let title, let reason):
      return "Required point “\(title)” is blocked: \(reason)"
    }
  }

  private func statusLabel(_ status: InspectionPointStatus) -> String {
    switch status {
    case .notStarted: return "not started"
    case .inProgress: return "in progress"
    case .completed: return "completed"
    case .skipped: return "skipped"
    case .blocked: return "blocked"
    }
  }
}

// MARK: - Per-point review row (derived)

public enum InspectionPointExportReadiness: Equatable, Sendable {
  case satisfied
  case skipped(reason: String)
  case blocked(reason: String)
  case open(InspectionPointStatus)
  case insufficientEvidence(boundCount: Int, requiredCount: Int)
}

public struct InspectionPointValidationRow: Equatable, Sendable, Identifiable {
  public var id: InspectionPointID { pointID }
  public let pointID: InspectionPointID
  public let title: String
  public let isRequired: Bool
  public let status: InspectionPointStatus?
  public let boundCount: Int
  public let requiredCount: Int
  public let isSatisfied: Bool
  public let readiness: InspectionPointExportReadiness
  public let blocksExport: Bool

  public var statusTag: String {
    switch readiness {
    case .satisfied: return "✓ Satisfied"
    case .skipped(let reason): return "Skipped — \(reason)"
    case .blocked(let reason): return "Blocked — \(reason)"
    case .open(let s):
      switch s {
      case .notStarted: return "Not started"
      case .inProgress: return "In progress"
      default: return "Open"
      }
    case .insufficientEvidence(let b, let r):
      return "● \(b) of \(r) Required"
    }
  }
}

// MARK: - Export preview item (metadata only — no binary mutation)

public struct InspectionExportPreviewItem: Equatable, Sendable, Identifiable {
  public var id: String { storageKey }
  public let pointID: InspectionPointID
  public let pointTitle: String
  public let evidenceID: EvidenceID
  public let storageKey: String
  public let evidenceType: EvidenceType
  /// Library capture id fragment when the storage key embeds one; else nil.
  public let libraryEvidenceIdHint: String?
}

// MARK: - Report

public struct PreExportValidationReport: Equatable, Sendable {
  public let isExportable: Bool
  public let disposition: InspectionCompletionDisposition
  public let blockingReasons: [PreExportBlockingReason]
  public let points: [InspectionPointValidationRow]
  public let exportPreview: [InspectionExportPreviewItem]
  public let satisfiedRequiredCount: Int
  public let requiredPointCount: Int

  public var summaryLine: String {
    if isExportable {
      return "Export ready — \(exportPreview.count) evidence item(s), \(satisfiedRequiredCount)/\(requiredPointCount) required points resolved."
    }
    if blockingReasons.isEmpty {
      return "Export not ready."
    }
    return "Export blocked — \(blockingReasons.count) issue(s)."
  }
}

// MARK: - Service

/// Stateless pre-export validation (Sprint 2.1F).
///
/// Pure: `(InspectionSession) → PreExportValidationReport`.
/// Combines frozen snapshot + progression terminals + derived evidence satisfaction.
/// Does not touch disk, camera, or package builders.
public struct PreExportValidationService: Sendable {
  private let binding: EvidenceBindingService
  private let progression: InspectionProgressionEngine

  public init(
    binding: EvidenceBindingService = EvidenceBindingService(),
    progression: InspectionProgressionEngine = InspectionProgressionEngine()
  ) {
    self.binding = binding
    self.progression = progression
  }

  public func validate(_ session: InspectionSession) -> PreExportValidationReport {
    guard let snapshot = session.inspectionPlanSnapshot else {
      return PreExportValidationReport(
        isExportable: false,
        disposition: .incomplete,
        blockingReasons: [.noAssignedPlan],
        points: [],
        exportPreview: [],
        satisfiedRequiredCount: 0,
        requiredPointCount: 0
      )
    }

    guard session.progress != nil else {
      return PreExportValidationReport(
        isExportable: false,
        disposition: .incomplete,
        blockingReasons: [.progressNotInitialized],
        points: rows(snapshot: snapshot, session: session),
        exportPreview: preview(snapshot: snapshot, session: session),
        satisfiedRequiredCount: 0,
        requiredPointCount: snapshot.points.filter(\.isRequired).count
      )
    }

    var reasons: [PreExportBlockingReason] = []
    switch session.status {
    case .inProgress, .completed:
      break
    case .paused, .canceled:
      reasons.append(.sessionNotInProgress(session.status))
    }

    let pointRows = rows(snapshot: snapshot, session: session)
    for row in pointRows where row.blocksExport {
      switch row.readiness {
      case .blocked(let reason):
        reasons.append(
          .requiredPointBlocked(pointID: row.pointID, title: row.title, reason: reason)
        )
      case .open(let status):
        reasons.append(
          .requiredPointOpen(pointID: row.pointID, title: row.title, status: status)
        )
      case .insufficientEvidence(let bound, let required):
        reasons.append(
          .requiredPointInsufficientEvidence(
            pointID: row.pointID,
            title: row.title,
            boundCount: bound,
            requiredCount: required
          )
        )
      case .satisfied, .skipped:
        break
      }
    }

    // Deduplicate while preserving order
    var seen = Set<String>()
    let uniqueReasons = reasons.filter { seen.insert($0.id).inserted }

    let requiredRows = pointRows.filter(\.isRequired)
    let satisfiedRequired = requiredRows.filter { row in
      switch row.readiness {
      case .satisfied, .skipped: return true
      default: return false
      }
    }.count

    let disposition = progression.evaluateCompletion(of: session)
    let exportable = uniqueReasons.isEmpty
      && requiredRows.allSatisfy { !$0.blocksExport }
      && (session.status == .inProgress || session.status == .completed)

    return PreExportValidationReport(
      isExportable: exportable,
      disposition: disposition,
      blockingReasons: uniqueReasons,
      points: pointRows,
      exportPreview: preview(snapshot: snapshot, session: session),
      satisfiedRequiredCount: satisfiedRequired,
      requiredPointCount: requiredRows.count
    )
  }

  // MARK: - Internals

  private func rows(
    snapshot: InspectionPlanSnapshot,
    session: InspectionSession
  ) -> [InspectionPointValidationRow] {
    snapshot.points.map { point in
      let status = session.progress?.progress(for: point.id)?.status
      let bound = binding.evidenceCount(for: point.id, in: session)
      let required = InspectionEvidenceRequirement.requiredBindingCount(for: point)
      let satisfied = binding.isPointSatisfied(pointID: point.id, in: session)
      let readiness = readiness(
        isRequired: point.isRequired,
        status: status,
        satisfied: satisfied,
        bound: bound,
        required: required
      )
      let blocks = point.isRequired && blocksExport(readiness)
      return InspectionPointValidationRow(
        pointID: point.id,
        title: point.title,
        isRequired: point.isRequired,
        status: status,
        boundCount: bound,
        requiredCount: required,
        isSatisfied: satisfied,
        readiness: readiness,
        blocksExport: blocks
      )
    }
  }

  private func readiness(
    isRequired: Bool,
    status: InspectionPointStatus?,
    satisfied: Bool,
    bound: Int,
    required: Int
  ) -> InspectionPointExportReadiness {
    switch status {
    case .skipped(let reason):
      return .skipped(reason: reason)
    case .blocked(let reason):
      return .blocked(reason: reason)
    case .completed:
      if satisfied { return .satisfied }
      return .insufficientEvidence(boundCount: bound, requiredCount: required)
    case .notStarted, .inProgress, .none:
      if !isRequired && (status == nil || status == .notStarted) {
        // Optional untouched points do not block export.
        return satisfied ? .satisfied : .open(status ?? .notStarted)
      }
      if satisfied && status == .inProgress {
        // Evidence present but point not marked complete — still open for workflow.
        return .open(.inProgress)
      }
      if bound < required {
        return .insufficientEvidence(boundCount: bound, requiredCount: required)
      }
      return .open(status ?? .notStarted)
    }
  }

  private func blocksExport(_ readiness: InspectionPointExportReadiness) -> Bool {
    switch readiness {
    case .satisfied, .skipped:
      return false
    case .blocked, .open, .insufficientEvidence:
      return true
    }
  }

  private func preview(
    snapshot: InspectionPlanSnapshot,
    session: InspectionSession
  ) -> [InspectionExportPreviewItem] {
    let titleByID = Dictionary(uniqueKeysWithValues: snapshot.points.map { ($0.id, $0.title) })
    let bindings = session.evidenceBindings?.bindings ?? []
    return bindings.map { meta in
      InspectionExportPreviewItem(
        pointID: meta.pointID,
        pointTitle: titleByID[meta.pointID] ?? meta.pointID.rawValue,
        evidenceID: meta.id,
        storageKey: meta.storageKey,
        evidenceType: meta.type,
        libraryEvidenceIdHint: Self.libraryIdHint(from: meta.storageKey)
      )
    }
  }

  /// Storage keys are `session/point/evidenceUUID/libraryFragment`.
  public static func libraryIdHint(from storageKey: String) -> String? {
    let parts = storageKey.split(separator: "/", omittingEmptySubsequences: false).map(String.init)
    guard parts.count >= 4 else { return nil }
    let fragment = parts.last?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    return fragment.isEmpty ? nil : fragment
  }
}
