import Foundation

/// Persistence port owned by ``GuidedInspectionCoordinator`` (Sprint 2.1E DoD).
/// ViewModels must not call this — only the coordinator performs session saves.
public protocol GuidedSessionPersisting: Sendable {
  func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession
}

extension InspectionSessionService: GuidedSessionPersisting {
  public func persistGuidedSession(_ session: InspectionSession) async throws -> InspectionSession {
    try await applyUpdatedSession(session)
  }
}

/// Application-level intent orchestrator for guided inspection (Sprint 2.1E).
///
/// **Sole owner of:**
/// - ``EvidenceMetadata`` / storage-key construction
/// - Domain engine calls (progression + binding)
/// - Persistence side-effects via ``GuidedSessionPersisting``
///
/// Value type — no `.shared`, no retain cycle with presentation.
public struct GuidedInspectionCoordinator: Sendable {
  private let progression: InspectionProgressionEngine
  private let binding: EvidenceBindingService
  private let instantProvider: any InstantProviding
  private let persister: (any GuidedSessionPersisting)?

  public init(
    progression: InspectionProgressionEngine = InspectionProgressionEngine(),
    binding: EvidenceBindingService = EvidenceBindingService(),
    instantProvider: any InstantProviding = SystemInstantProvider(),
    persister: (any GuidedSessionPersisting)? = nil
  ) {
    self.progression = progression
    self.binding = binding
    self.instantProvider = instantProvider
    self.persister = persister
  }

  public func presentation(for session: InspectionSession?) -> GuidedInspectionPresentationState {
    GuidedInspectionPresenter.makeState(from: session, binding: binding, progression: progression)
  }

  /// Applies intent, then persists when the session mutated (DoD: coordinator owns disk writes).
  /// `captureRequested` validates readiness and signals shutter without persisting.
  public func handle(
    _ intent: GuidedInspectionIntent,
    session: InspectionSession
  ) async throws -> GuidedInspectionHandleResult {
    let applied = try apply(intent, session: session)
    if applied.shouldTriggerShutter {
      return applied
    }
    guard let persister else {
      return applied
    }
    do {
      let saved = try await persister.persistGuidedSession(applied.session)
      return GuidedInspectionHandleResult(
        session: saved,
        shouldTriggerShutter: false,
        presentation: presentation(for: saved)
      )
    } catch let error as GuidedInspectionPresentationError {
      throw error
    } catch {
      throw GuidedInspectionPresentationError.persistence(String(describing: error))
    }
  }

  /// Pure domain transition without persistence (unit tests / dry-run).
  public func apply(
    _ intent: GuidedInspectionIntent,
    session: InspectionSession
  ) throws -> GuidedInspectionHandleResult {
    switch intent {
    case .prepareGuidedSession:
      return try prepare(session)

    case .activatePoint(let pointID):
      let next = try mapProgression { try progression.activate(pointID: pointID, in: session) }
      return result(next)

    case .advanceRequested:
      let next = try mapProgression { try progression.advanceToNextEligiblePoint(in: session) }
      return result(next)

    case .returnRequested:
      let next = try mapProgression { try progression.returnToPreviousEligiblePoint(in: session) }
      return result(next)

    case .completePointRequested:
      let next = try mapProgression { try progression.completeActivePoint(in: session) }
      return result(next)

    case .skipRequested(let reason):
      let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
      guard !trimmed.isEmpty else { throw GuidedInspectionPresentationError.emptySkipReason }
      let next = try mapProgression {
        try progression.skipActivePoint(reason: trimmed, in: session)
      }
      return result(next)

    case .blockRequested(let reason):
      let trimmed = reason.trimmingCharacters(in: .whitespacesAndNewlines)
      guard !trimmed.isEmpty else { throw GuidedInspectionPresentationError.emptyBlockReason }
      let next = try mapProgression {
        try progression.blockActivePoint(reason: trimmed, in: session)
      }
      return result(next)

    case .captureRequested:
      let state = presentation(for: session)
      guard state.canCapture else {
        throw GuidedInspectionPresentationError.captureNotReady(
          "Active point is missing or terminal, or session is not in progress"
        )
      }
      return GuidedInspectionHandleResult(
        session: session,
        shouldTriggerShutter: true,
        presentation: state
      )

    case .bindApprovedCapture(let storageKey, let type, let attributes):
      return try bindApproved(
        storageKey: storageKey,
        type: type,
        attributes: attributes,
        session: session
      )

    case .unbindLibraryEvidence(let libraryEvidenceId):
      return try unbindLibrary(libraryEvidenceId: libraryEvidenceId, session: session)

    case .replaceLibraryEvidence(let oldLibraryEvidenceId, let storageKey, let type, let attributes):
      return try replaceLibrary(
        oldLibraryEvidenceId: oldLibraryEvidenceId,
        storageKey: storageKey,
        type: type,
        attributes: attributes,
        session: session
      )
    }
  }

  // MARK: - Internals

  private func prepare(_ session: InspectionSession) throws -> GuidedInspectionHandleResult {
    guard session.inspectionPlanSnapshot != nil else {
      throw GuidedInspectionPresentationError.planNotAssigned
    }
    var next = try mapProgression { try progression.initializeProgress(for: session) }
    if next.progress?.activePointID == nil,
      let firstOpen = next.progress?.orderedPoints.first(where: { !$0.status.isTerminal })
    {
      next = try mapProgression {
        try progression.activate(pointID: firstOpen.pointID, in: next)
      }
    }
    return result(next)
  }

  private func bindApproved(
    storageKey: String,
    type: EvidenceType,
    attributes: [String: String],
    session: InspectionSession
  ) throws -> GuidedInspectionHandleResult {
    guard let pointID = session.progress?.activePointID else {
      throw GuidedInspectionPresentationError.noActivePoint
    }
    let evidenceID = EvidenceID()
    let key = Self.makeStorageKey(
      sessionID: session.id,
      pointID: pointID,
      evidenceID: evidenceID,
      approvedKey: storageKey
    )
    let meta = EvidenceMetadata(
      id: evidenceID,
      pointID: pointID,
      sessionID: session.id,
      type: type,
      createdAt: instantProvider.now(),
      storageKey: key,
      payloadAttributes: attributes
    )
    let next: InspectionSession
    do {
      next = try binding.bind(evidence: meta, to: session)
    } catch let error as EvidenceBindingError {
      throw GuidedInspectionPresentationError.evidenceBinding(error)
    }
    return result(next)
  }

  private func unbindLibrary(
    libraryEvidenceId: String,
    session: InspectionSession
  ) throws -> GuidedInspectionHandleResult {
    result(binding.unbindLibraryEvidence(libraryEvidenceId: libraryEvidenceId, from: session))
  }

  /// Replaces library-bound evidence while preserving the original point assignment.
  private func replaceLibrary(
    oldLibraryEvidenceId: String,
    storageKey: String,
    type: EvidenceType,
    attributes: [String: String],
    session: InspectionSession
  ) throws -> GuidedInspectionHandleResult {
    let needle = oldLibraryEvidenceId.trimmingCharacters(in: .whitespacesAndNewlines)
    let old = session.evidenceBindings?.bindings.first { $0.storageKey.contains(needle) }
    let pointID = old?.pointID ?? session.progress?.activePointID
    guard let pointID else {
      throw GuidedInspectionPresentationError.noActivePoint
    }
    let evidenceID = EvidenceID()
    let key = Self.makeStorageKey(
      sessionID: session.id,
      pointID: pointID,
      evidenceID: evidenceID,
      approvedKey: storageKey
    )
    let meta = EvidenceMetadata(
      id: evidenceID,
      pointID: pointID,
      sessionID: session.id,
      type: type,
      createdAt: instantProvider.now(),
      storageKey: key,
      payloadAttributes: attributes
    )
    let next: InspectionSession
    do {
      if let old {
        next = try binding.replace(evidenceID: old.id, with: meta, in: session)
      } else {
        next = try binding.bind(evidence: meta, to: session)
      }
    } catch let error as EvidenceBindingError {
      throw GuidedInspectionPresentationError.evidenceBinding(error)
    }
    return result(next)
  }

  /// Opaque storage key: session/point/evidence identity + approved library key fragment.
  public static func makeStorageKey(
    sessionID: SessionID,
    pointID: InspectionPointID,
    evidenceID: EvidenceID,
    approvedKey: String
  ) -> String {
    let fragment = approvedKey.trimmingCharacters(in: .whitespacesAndNewlines)
    return "\(sessionID.rawValue)/\(pointID.rawValue)/\(evidenceID.rawValue.uuidString)/\(fragment)"
  }

  private func mapProgression(_ body: () throws -> InspectionSession) throws -> InspectionSession {
    do {
      return try body()
    } catch let error as InspectionProgressionError {
      throw GuidedInspectionPresentationError.progression(error)
    }
  }

  private func result(_ session: InspectionSession) -> GuidedInspectionHandleResult {
    GuidedInspectionHandleResult(
      session: session,
      shouldTriggerShutter: false,
      presentation: presentation(for: session)
    )
  }
}
