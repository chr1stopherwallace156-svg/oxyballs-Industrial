import Foundation

/// Point-scoped sections inside an inspection evidence group (Sprint 2.1E.1 / 2.1F preview).
public struct InspectionPointEvidenceSection: Identifiable, Sendable, Equatable {
  public var id: String { pointID?.rawValue ?? "unassigned" }
  public let pointID: InspectionPointID?
  public let title: String
  public let requiredCount: Int
  public let boundCount: Int
  public let isSatisfied: Bool
  public let captures: [EvidenceLibraryIndexRecord]

  public var statusLabel: String {
    if pointID == nil { return "Not linked to a point" }
    if isSatisfied { return "✓ Satisfied" }
    if requiredCount > 0 {
      return "● \(boundCount) of \(requiredCount) Required"
    }
    return "\(boundCount) bound"
  }

  public var needsMoreEvidence: Bool {
    pointID != nil && !isSatisfied && requiredCount > boundCount
  }
}

public enum InspectionPointEvidenceGrouping {
  /// Groups library captures under frozen plan points using session binding storage keys.
  public static func sections(
    group: InspectionEvidenceGroup,
    session: InspectionSession?
  ) -> [InspectionPointEvidenceSection] {
    let bindings = session?.evidenceBindings?.bindings ?? []
    let snapshot = session?.inspectionPlanSnapshot
    let binding = EvidenceBindingService()

    func pointID(for record: EvidenceLibraryIndexRecord) -> InspectionPointID? {
      bindings.first { $0.storageKey.contains(record.id) }?.pointID
    }

    var byPoint: [String: [EvidenceLibraryIndexRecord]] = [:]
    var orphan: [EvidenceLibraryIndexRecord] = []
    for record in group.captures {
      if let pid = pointID(for: record) {
        byPoint[pid.rawValue, default: []].append(record)
      } else {
        orphan.append(record)
      }
    }

    var sections: [InspectionPointEvidenceSection] = []
    if let snapshot {
      for point in snapshot.points {
        let captures = byPoint[point.id.rawValue] ?? []
        let required = InspectionEvidenceRequirement.requiredBindingCount(for: point)
        let boundCount = session.map { binding.evidenceCount(for: point.id, in: $0) } ?? captures.count
        let satisfied = session.map { binding.isPointSatisfied(pointID: point.id, in: $0) }
          ?? (captures.count >= required)
        sections.append(
          InspectionPointEvidenceSection(
            pointID: point.id,
            title: point.title,
            requiredCount: required,
            boundCount: boundCount,
            isSatisfied: satisfied,
            captures: captures
          )
        )
      }
    } else {
      // No live session — flat bucket per unknown point ids found in bindings only.
      for key in byPoint.keys.sorted() {
        let captures = byPoint[key] ?? []
        sections.append(
          InspectionPointEvidenceSection(
            pointID: InspectionPointID.unchecked(key),
            title: key,
            requiredCount: 0,
            boundCount: captures.count,
            isSatisfied: false,
            captures: captures
          )
        )
      }
    }

    if !orphan.isEmpty {
      sections.append(
        InspectionPointEvidenceSection(
          pointID: nil,
          title: "Unlinked captures",
          requiredCount: 0,
          boundCount: orphan.count,
          isSatisfied: false,
          captures: orphan
        )
      )
    }
    return sections
  }
}
