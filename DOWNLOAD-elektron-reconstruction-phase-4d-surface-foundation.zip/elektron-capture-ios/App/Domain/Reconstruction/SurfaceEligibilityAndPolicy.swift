import Foundation

// MARK: - Eligibility

public enum SurfaceEligibilityOutcome: String, Codable, Sendable, Equatable {
  case eligibleSyntheticSurface = "ELIGIBLE_SYNTHETIC_SURFACE_RECONSTRUCTION"
  case eligibleWithSparseRegions = "ELIGIBLE_WITH_SPARSE_REGIONS"
  case ineligibleMissingFusedCloud = "INELIGIBLE_MISSING_FUSED_CLOUD"
  case ineligibleInvalidNormals = "INELIGIBLE_INVALID_NORMALS"
  case ineligibleBrokenLineage = "INELIGIBLE_BROKEN_LINEAGE"
  case ineligiblePhase4CNotReady = "INELIGIBLE_PHASE4C_NOT_READY"
  case ineligibleInsufficientPoints = "INELIGIBLE_INSUFFICIENT_POINTS"
  case ineligibleCoordinateMismatch = "INELIGIBLE_COORDINATE_MISMATCH"
  case ineligibleClosureMismatch = "INELIGIBLE_CLOSURE_MISMATCH"
  case manualReviewRequired = "MANUAL_REVIEW_REQUIRED"
}

public enum SurfaceIneligibilityReason: String, Codable, Sendable, Equatable {
  case missingFusedCloud = "MISSING_FUSED_CLOUD"
  case missingNormals = "MISSING_NORMALS"
  case invalidNormals = "INVALID_NORMALS"
  case brokenLineage = "BROKEN_LINEAGE"
  case phase4CNotReady = "PHASE4C_NOT_READY"
  case insufficientTrustedPoints = "INSUFFICIENT_TRUSTED_POINTS"
  case coordinateMismatch = "COORDINATE_MISMATCH"
  case closureMismatch = "CLOSURE_MISMATCH"
  case quarantinedMajority = "QUARANTINED_MAJORITY"
  case nonFiniteGeometry = "NON_FINITE_GEOMETRY"
}

public struct SurfaceEligibilityPolicy: Codable, Sendable, Equatable {
  public var policyID: String
  public var minTrustedPoints: Int
  public var minValidNormals: Int
  public var requirePhase4DHandoffReady: Bool
  public var requireFiniteGeometry: Bool
  public var allowSparseRegions: Bool

  public static let fixture = SurfaceEligibilityPolicy(
    policyID: "SURF-ELIG-POL-FIXTURE-000001",
    minTrustedPoints: 8,
    minValidNormals: 8,
    requirePhase4DHandoffReady: true,
    requireFiniteGeometry: true,
    allowSparseRegions: true
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "min_trusted_points": minTrustedPoints,
      "min_valid_normals": minValidNormals,
      "require_phase4d_handoff_ready": requirePhase4DHandoffReady,
      "require_finite_geometry": requireFiniteGeometry,
      "allow_sparse_regions": allowSparseRegions,
      "characterization_status": "DETERMINISTIC_TEST_FIXTURE",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
    ]
  }
}

public struct SurfaceEligibilityResult: Codable, Sendable, Equatable {
  public var outcome: SurfaceEligibilityOutcome
  public var reasons: [SurfaceIneligibilityReason]
  public var policyID: String
  public var detail: String
  public var trustedPointCount: Int
  public var validNormalCount: Int

  public var isEligible: Bool {
    switch outcome {
    case .eligibleSyntheticSurface, .eligibleWithSparseRegions: return true
    default: return false
    }
  }

  public func dictionary() -> [String: Any] {
    [
      "outcome": outcome.rawValue,
      "reasons": reasons.map(\.rawValue).sorted(),
      "policy_id": policyID,
      "detail": detail,
      "is_eligible": isEligible,
      "trusted_point_count": trustedPointCount,
      "valid_normal_count": validNormalCount,
    ]
  }
}

// MARK: - Meshing / resource policy

public struct SurfaceMeshingPolicy: Codable, Sendable, Equatable {
  public var policyID: String
  public var maxEdgeLengthMeters: Double
  public var minTriangleAreaMeters2: Double
  public var normalConflictDotMax: Double
  public var allowAutomaticHoleFill: Bool
  public var lod1InteriorRemovalFraction: Double
  public var lod2InteriorRemovalFraction: Double
  public var intentionalHoleAABBMin: [Double]
  public var intentionalHoleAABBMax: [Double]
  public var characterizationStatus: String

  public static let fixture = SurfaceMeshingPolicy(
    policyID: "SURF-MESH-POL-FIXTURE-000001",
    maxEdgeLengthMeters: 0.08,
    minTriangleAreaMeters2: 1e-12,
    normalConflictDotMax: 0.0,
    allowAutomaticHoleFill: false,
    lod1InteriorRemovalFraction: 0.30,
    lod2InteriorRemovalFraction: 0.60,
    intentionalHoleAABBMin: [0.08, -0.01, 1.99],
    intentionalHoleAABBMax: [0.12, 0.01, 2.01],
    characterizationStatus: "DETERMINISTIC_TEST_FIXTURE"
  )

  public func dictionary() -> [String: Any] {
    [
      "policy_id": policyID,
      "max_edge_length_meters": maxEdgeLengthMeters,
      "min_triangle_area_meters2": minTriangleAreaMeters2,
      "normal_conflict_dot_max": normalConflictDotMax,
      "allow_automatic_hole_fill": allowAutomaticHoleFill,
      "lod1_interior_removal_fraction": lod1InteriorRemovalFraction,
      "lod2_interior_removal_fraction": lod2InteriorRemovalFraction,
      "intentional_hole_aabb_min": intentionalHoleAABBMin,
      "intentional_hole_aabb_max": intentionalHoleAABBMax,
      "characterization_status": characterizationStatus,
      "schema_version": Phase4DFixtureIDs.schemaVersion,
    ]
  }
}

public struct SurfaceResourcePolicy: Equatable, Sendable {
  public var maxInputPoints: Int
  public var maxTriangles: Int
  public var maxEstimatedWorkingSetBytes: Int
  public var cleanupTemporaryOutputs: Bool

  public static let fixture = SurfaceResourcePolicy(
    maxInputPoints: 10_000,
    maxTriangles: 50_000,
    maxEstimatedWorkingSetBytes: 64 * 1024 * 1024,
    cleanupTemporaryOutputs: true
  )

  public func dictionary() -> [String: Any] {
    [
      "max_input_points": maxInputPoints,
      "max_triangles": maxTriangles,
      "max_estimated_working_set_bytes": maxEstimatedWorkingSetBytes,
      "cleanup_temporary_outputs": cleanupTemporaryOutputs,
    ]
  }
}

public struct SurfaceConfigurationDigest: Codable, Sendable, Equatable {
  public var configurationID: String
  public var backendID: String
  public var maxEdgeLengthMeters: Double
  public var minTriangleAreaMeters2: Double
  public var lod1InteriorRemovalFraction: Double
  public var lod2InteriorRemovalFraction: Double
  public var allowAutomaticHoleFill: Bool
  public var characterizationStatus: String
  public var digest: String

  public static func fixture(policy: SurfaceMeshingPolicy = .fixture) -> SurfaceConfigurationDigest {
    var cfg = SurfaceConfigurationDigest(
      configurationID: "SURF-CFG-FIXTURE-000001",
      backendID: "DeterministicFixtureSurfaceBackend",
      maxEdgeLengthMeters: policy.maxEdgeLengthMeters,
      minTriangleAreaMeters2: policy.minTriangleAreaMeters2,
      lod1InteriorRemovalFraction: policy.lod1InteriorRemovalFraction,
      lod2InteriorRemovalFraction: policy.lod2InteriorRemovalFraction,
      allowAutomaticHoleFill: policy.allowAutomaticHoleFill,
      characterizationStatus: "DETERMINISTIC_TEST_FIXTURE",
      digest: ""
    )
    cfg.digest = cfg.computeDigest()
    return cfg
  }

  public func dictionary() -> [String: Any] {
    [
      "configuration_id": configurationID,
      "backend_id": backendID,
      "max_edge_length_meters": maxEdgeLengthMeters,
      "min_triangle_area_meters2": minTriangleAreaMeters2,
      "lod1_interior_removal_fraction": lod1InteriorRemovalFraction,
      "lod2_interior_removal_fraction": lod2InteriorRemovalFraction,
      "allow_automatic_hole_fill": allowAutomaticHoleFill,
      "characterization_status": characterizationStatus,
      "configuration_digest": digest,
    ]
  }

  public func computeDigest() -> String {
    var d = dictionary()
    d["configuration_digest"] = ""
    let body = (try? CanonicalJSON.data(d)) ?? Data()
    return ContentHasher.sha256Hex(body)
  }
}

public struct Phase4DConfiguration: Equatable, Sendable {
  public var meshing: SurfaceMeshingPolicy
  public var eligibility: SurfaceEligibilityPolicy
  public var resource: SurfaceResourcePolicy
  public var configuration: SurfaceConfigurationDigest
  public var numeric: FusionNumericPolicy

  public static let fixture = Phase4DConfiguration(
    meshing: .fixture,
    eligibility: .fixture,
    resource: .fixture,
    configuration: .fixture(),
    numeric: .fixture
  )
}

// MARK: - Input inventory + validator

public struct SurfaceInputInventory: Equatable, Sendable {
  public var sourcePackageID: String
  public var sourcePackageClosureSHA256: String
  public var phase4COutputID: String
  public var phase4COutputClosureSHA256: String
  public var fusedPointCloudID: String
  public var fusedPointCount: Int
  public var validNormalCount: Int
  public var quarantinedRegionCount: Int
  public var gapCount: Int
  public var conflictCount: Int
  public var phase4DReadiness: String
  public var units: String
  public var handedness: String

  public func dictionary() -> [String: Any] {
    [
      "source_package_id": sourcePackageID,
      "source_package_closure_sha256": sourcePackageClosureSHA256,
      "phase4c_output_id": phase4COutputID,
      "phase4c_output_closure_sha256": phase4COutputClosureSHA256,
      "fused_point_cloud_id": fusedPointCloudID,
      "fused_point_count": fusedPointCount,
      "valid_normal_count": validNormalCount,
      "quarantined_region_count": quarantinedRegionCount,
      "gap_count": gapCount,
      "conflict_count": conflictCount,
      "phase4d_readiness": phase4DReadiness,
      "units": units,
      "handedness": handedness,
      "schema_id": "SurfaceInputInventory",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
    ]
  }
}

public struct Phase4CSurfaceHandoffBundle: Equatable, Sendable {
  public var fusedCloud: FusedPointCloud
  public var normals: [PointNormal]
  public var gaps: [SpatialGap]
  public var conflictIDs: [String]
  public var quarantinedRegions: [String]
  public var lineageManifestID: String
  public var phase4COutputClosureSHA256: String
  public var phase4DReadiness: String
  public var phase4CReconstructionOutputID: String
  public var coordinate: FusionCoordinateConvention
}

public struct SurfaceInputValidator: Sendable {
  public var policy: SurfaceEligibilityPolicy

  public init(policy: SurfaceEligibilityPolicy = .fixture) {
    self.policy = policy
  }

  public func validate(
    inventory: SurfaceInputInventory,
    bundle: Phase4CSurfaceHandoffBundle,
    expectedPhase4CClosure: String?
  ) -> SurfaceEligibilityResult {
    var reasons: [SurfaceIneligibilityReason] = []

    if bundle.fusedCloud.points.isEmpty {
      reasons.append(.missingFusedCloud)
    }
    if bundle.normals.isEmpty {
      reasons.append(.missingNormals)
    }

    let validNormals = bundle.normals.filter {
      $0.validity == .valid || $0.validity == .highCurvatureEdge
    }
    if validNormals.count < policy.minValidNormals {
      reasons.append(.invalidNormals)
    }

    let quarantine = Set(bundle.quarantinedRegions)
    let trusted = bundle.fusedCloud.points.filter { pt in
      !quarantine.contains(pt.fusedPointID) && !quarantine.contains(pt.voxelID)
    }
    if trusted.count < policy.minTrustedPoints {
      reasons.append(.insufficientTrustedPoints)
    }
    if !quarantine.isEmpty && trusted.count * 2 < bundle.fusedCloud.points.count {
      reasons.append(.quarantinedMajority)
    }

    if inventory.units != FusionCoordinateConvention.fixture.units
      || inventory.handedness != FusionCoordinateConvention.fixture.handedness
    {
      reasons.append(.coordinateMismatch)
    }

    if let expected = expectedPhase4CClosure, !expected.isEmpty,
       expected != inventory.phase4COutputClosureSHA256
    {
      reasons.append(.closureMismatch)
    }

    if inventory.lineageBroken(bundle: bundle) {
      reasons.append(.brokenLineage)
    }

    let readyOK: Bool = {
      switch inventory.phase4DReadiness {
      case Phase4DReadinessOutcome.readyForSyntheticSurfaceCandidate.rawValue,
           Phase4DReadinessOutcome.readyWithSparseRegions.rawValue:
        return true
      case Phase4DReadinessOutcome.additionalCaptureRecommended.rawValue:
        return policy.allowSparseRegions
      default:
        return false
      }
    }()
    if policy.requirePhase4DHandoffReady && !readyOK {
      reasons.append(.phase4CNotReady)
    }

    for p in trusted {
      if !p.x.isFinite || !p.y.isFinite || !p.z.isFinite {
        reasons.append(.nonFiniteGeometry)
        break
      }
    }

    let uniqueReasons = Array(Set(reasons)).sorted { $0.rawValue < $1.rawValue }

    if uniqueReasons.contains(.missingFusedCloud) {
      return SurfaceEligibilityResult(
        outcome: .ineligibleMissingFusedCloud, reasons: uniqueReasons,
        policyID: policy.policyID, detail: "fused_point_cloud_missing",
        trustedPointCount: trusted.count, validNormalCount: validNormals.count
      )
    }
    if uniqueReasons.contains(.invalidNormals) || uniqueReasons.contains(.missingNormals) {
      return SurfaceEligibilityResult(
        outcome: .ineligibleInvalidNormals, reasons: uniqueReasons,
        policyID: policy.policyID, detail: "normals_insufficient",
        trustedPointCount: trusted.count, validNormalCount: validNormals.count
      )
    }
    if uniqueReasons.contains(.brokenLineage) {
      return SurfaceEligibilityResult(
        outcome: .ineligibleBrokenLineage, reasons: uniqueReasons,
        policyID: policy.policyID, detail: "lineage_broken",
        trustedPointCount: trusted.count, validNormalCount: validNormals.count
      )
    }
    if uniqueReasons.contains(.phase4CNotReady) {
      return SurfaceEligibilityResult(
        outcome: .ineligiblePhase4CNotReady, reasons: uniqueReasons,
        policyID: policy.policyID, detail: inventory.phase4DReadiness,
        trustedPointCount: trusted.count, validNormalCount: validNormals.count
      )
    }
    if uniqueReasons.contains(.insufficientTrustedPoints) {
      return SurfaceEligibilityResult(
        outcome: .ineligibleInsufficientPoints, reasons: uniqueReasons,
        policyID: policy.policyID, detail: "trusted_points_below_min",
        trustedPointCount: trusted.count, validNormalCount: validNormals.count
      )
    }
    if uniqueReasons.contains(.coordinateMismatch) {
      return SurfaceEligibilityResult(
        outcome: .ineligibleCoordinateMismatch, reasons: uniqueReasons,
        policyID: policy.policyID, detail: "coordinate_mismatch",
        trustedPointCount: trusted.count, validNormalCount: validNormals.count
      )
    }
    if uniqueReasons.contains(.closureMismatch) {
      return SurfaceEligibilityResult(
        outcome: .ineligibleClosureMismatch, reasons: uniqueReasons,
        policyID: policy.policyID, detail: "closure_mismatch",
        trustedPointCount: trusted.count, validNormalCount: validNormals.count
      )
    }
    if uniqueReasons.contains(.quarantinedMajority) {
      return SurfaceEligibilityResult(
        outcome: .manualReviewRequired, reasons: uniqueReasons,
        policyID: policy.policyID, detail: "quarantined_majority",
        trustedPointCount: trusted.count, validNormalCount: validNormals.count
      )
    }

    let sparse = inventory.phase4DReadiness == Phase4DReadinessOutcome.readyWithSparseRegions.rawValue
      || inventory.phase4DReadiness == Phase4DReadinessOutcome.additionalCaptureRecommended.rawValue
    return SurfaceEligibilityResult(
      outcome: sparse ? .eligibleWithSparseRegions : .eligibleSyntheticSurface,
      reasons: [],
      policyID: policy.policyID,
      detail: "eligible",
      trustedPointCount: trusted.count,
      validNormalCount: validNormals.count
    )
  }
}

private extension SurfaceInputInventory {
  func lineageBroken(bundle: Phase4CSurfaceHandoffBundle) -> Bool {
    sourcePackageClosureSHA256.isEmpty
      || phase4COutputClosureSHA256.isEmpty
      || bundle.lineageManifestID.isEmpty
  }
}
