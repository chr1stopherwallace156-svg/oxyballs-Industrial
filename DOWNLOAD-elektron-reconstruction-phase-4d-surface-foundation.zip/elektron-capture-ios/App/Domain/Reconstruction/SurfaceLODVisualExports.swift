import Foundation

public struct SurfaceLODGenerator: Sendable {
  public var policy: SurfaceMeshingPolicy

  public init(policy: SurfaceMeshingPolicy = .fixture) {
    self.policy = policy
  }

  public func generate(
    vertices: [SurfaceVertex],
    triangles: [SurfaceTriangle]
  ) -> [SurfaceLODMesh] {
    let lod0 = SurfaceLODMesh(
      lodLevel: 0,
      meshID: "MESH-LOD0-FIXTURE-000001",
      vertices: vertices.sorted { $0.vertexID < $1.vertexID },
      triangles: triangles.sorted { $0.triangleID < $1.triangleID },
      collapseRecords: []
    )
    let lod1 = simplify(
      level: 1,
      meshID: "MESH-LOD1-FIXTURE-000001",
      vertices: vertices,
      triangles: triangles,
      removalFraction: policy.lod1InteriorRemovalFraction
    )
    let lod2 = simplify(
      level: 2,
      meshID: "MESH-LOD2-FIXTURE-000001",
      vertices: vertices,
      triangles: triangles,
      removalFraction: policy.lod2InteriorRemovalFraction
    )
    return [lod0, lod1, lod2]
  }

  private func simplify(
    level: Int,
    meshID: String,
    vertices: [SurfaceVertex],
    triangles: [SurfaceTriangle],
    removalFraction: Double
  ) -> SurfaceLODMesh {
    let boundary = boundaryVertexIDs(triangles: triangles)
    let interior = vertices.map(\.vertexID).filter { !boundary.contains($0) }.sorted()
    let removeCount = Int(floor(Double(interior.count) * removalFraction))
    let removed = Set(interior.prefix(removeCount))
    var collapses: [VertexCollapseRecord] = []
    for (i, id) in removed.sorted().enumerated() {
      collapses.append(
        VertexCollapseRecord(
          recordID: String(format: "VCR-L%d-%06d", level, i + 1),
          removedVertexID: id,
          lodLevel: level,
          reason: "DETERMINISTIC_INTERIOR_REMOVAL"
        )
      )
    }
    let keptVertices = vertices.filter { !removed.contains($0.vertexID) }.sorted { $0.vertexID < $1.vertexID }
    let keptSet = Set(keptVertices.map(\.vertexID))
    let keptTris = triangles.filter { t in
      t.vertexIDs.allSatisfy { keptSet.contains($0) }
    }.sorted { $0.triangleID < $1.triangleID }

    return SurfaceLODMesh(
      lodLevel: level,
      meshID: meshID,
      vertices: keptVertices,
      triangles: keptTris,
      collapseRecords: collapses.sorted { $0.recordID < $1.recordID }
    )
  }

  private func boundaryVertexIDs(triangles: [SurfaceTriangle]) -> Set<String> {
    var edgeCount: [String: (String, String, Int)] = [:]
    func key(_ a: String, _ b: String) -> String { a < b ? "\(a)|\(b)" : "\(b)|\(a)" }
    for t in triangles {
      guard t.vertexIDs.count == 3 else { continue }
      let a = t.vertexIDs[0], b = t.vertexIDs[1], c = t.vertexIDs[2]
      for (u, v) in [(a, b), (b, c), (c, a)] {
        let k = key(u, v)
        if let e = edgeCount[k] { edgeCount[k] = (e.0, e.1, e.2 + 1) }
        else { edgeCount[k] = (u, v, 1) }
      }
    }
    var out: Set<String> = []
    for e in edgeCount.values where e.2 == 1 {
      out.insert(e.0); out.insert(e.1)
    }
    return out
  }
}

public enum SurfaceMeshExportWriter {
  public static func writePLY(mesh: SurfaceLODMesh, colors: [String: (Int, Int, Int)]? = nil) -> String {
    let verts = mesh.vertices.sorted { $0.vertexID < $1.vertexID }
    let indexByID = Dictionary(uniqueKeysWithValues: verts.enumerated().map { ($0.element.vertexID, $0.offset) })
    let tris = mesh.triangles.sorted { $0.triangleID < $1.triangleID }
    var lines: [String] = [
      "ply",
      "format ascii 1.0",
      "comment Elektron Phase 4D fixture surface — not production mesh",
      "comment mesh_id \(mesh.meshID)",
      "comment lod \(mesh.lodLevel)",
      "comment authority RECONSTRUCTION_ESTIMATE",
      "element vertex \(verts.count)",
      "property float x",
      "property float y",
      "property float z",
      "property float nx",
      "property float ny",
      "property float nz",
    ]
    if colors != nil {
      lines += ["property uchar red", "property uchar green", "property uchar blue"]
    }
    lines += [
      "element face \(tris.count)",
      "property list uchar int vertex_indices",
      "end_header",
    ]
    for v in verts {
      if let colors, let rgb = colors[v.vertexID] {
        lines.append(String(format: "%.9f %.9f %.9f %.9f %.9f %.9f %d %d %d",
                            v.x, v.y, v.z, v.nx, v.ny, v.nz, rgb.0, rgb.1, rgb.2))
      } else {
        lines.append(String(format: "%.9f %.9f %.9f %.9f %.9f %.9f",
                            v.x, v.y, v.z, v.nx, v.ny, v.nz))
      }
    }
    for t in tris {
      let idxs = t.vertexIDs.compactMap { indexByID[$0] }
      guard idxs.count == 3 else { continue }
      lines.append("3 \(idxs[0]) \(idxs[1]) \(idxs[2])")
    }
    return lines.joined(separator: "\n") + "\n"
  }

  public static func writeOBJ(mesh: SurfaceLODMesh, mtlName: String) -> String {
    let verts = mesh.vertices.sorted { $0.vertexID < $1.vertexID }
    let indexByID = Dictionary(uniqueKeysWithValues: verts.enumerated().map { ($0.element.vertexID, $0.offset + 1) })
    var lines: [String] = [
      "# Elektron Phase 4D fixture OBJ — not production mesh",
      "mtllib \(mtlName)",
      "usemtl SurfaceFixture",
    ]
    for v in verts {
      lines.append(String(format: "v %.9f %.9f %.9f", v.x, v.y, v.z))
    }
    for v in verts {
      lines.append(String(format: "vn %.9f %.9f %.9f", v.nx, v.ny, v.nz))
    }
    for t in mesh.triangles.sorted(by: { $0.triangleID < $1.triangleID }) {
      let idxs = t.vertexIDs.compactMap { indexByID[$0] }
      guard idxs.count == 3 else { continue }
      lines.append("f \(idxs[0])//\(idxs[0]) \(idxs[1])//\(idxs[1]) \(idxs[2])//\(idxs[2])")
    }
    return lines.joined(separator: "\n") + "\n"
  }

  public static func writeMTL() -> String {
    """
    # Elektron Phase 4D fixture MTL
    newmtl SurfaceFixture
    Ka 0.200000 0.200000 0.200000
    Kd 0.700000 0.750000 0.800000
    Ks 0.050000 0.050000 0.050000
    Ns 10.000000
    illum 1
    """
  }

  /// Deterministic confidence → RGB mapping.
  public static func vertexColors(vertices: [SurfaceVertex]) -> [String: (Int, Int, Int)] {
    var out: [String: (Int, Int, Int)] = [:]
    for v in vertices {
      let t = max(0.0, min(1.0, v.confidence))
      let r = Int((1.0 - t) * 220)
      let g = Int(40 + t * 180)
      let b = Int(80 + t * 140)
      out[v.vertexID] = (r, g, b)
    }
    return out
  }

  public static func visualDerivationManifest(
    colors: [String: (Int, Int, Int)],
    lodHashes: [String: String],
    glbSHA256: String?
  ) -> [String: Any] {
    let colorRows = colors.keys.sorted().map { id -> [String: Any] in
      let c = colors[id]!
      return ["vertex_id": id, "rgb": [c.0, c.1, c.2], "mapping": "confidence_linear_rgb"]
    }
    var d: [String: Any] = [
      "schema_id": "VisualDerivationManifest",
      "schema_version": Phase4DFixtureIDs.schemaVersion,
      "color_authority": "RECONSTRUCTION_ESTIMATE",
      "per_vertex_colors": colorRows,
      "lod_artifact_sha256": Dictionary(uniqueKeysWithValues: lodHashes.keys.sorted().map { ($0, lodHashes[$0]!) }),
      "note": "Deterministic visual derivatives — not photoreal texture",
    ]
    if let glbSHA256 {
      d["glb_sha256"] = glbSHA256
    }
    return d
  }
}

/// Minimal deterministic GLB (binary glTF 2.0) writer with POSITION + NORMAL + indices.
public enum DeterministicGLBWriter {
  public static func write(mesh: SurfaceLODMesh) -> Data {
    let verts = mesh.vertices.sorted { $0.vertexID < $1.vertexID }
    let indexByID = Dictionary(uniqueKeysWithValues: verts.enumerated().map { ($0.element.vertexID, UInt32($0.offset)) })
    var positions: [Float] = []
    var normals: [Float] = []
    var minP: [Float] = [Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude, Float.greatestFiniteMagnitude]
    var maxP: [Float] = [-Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude, -Float.greatestFiniteMagnitude]
    for v in verts {
      let p: [Float] = [Float(v.x), Float(v.y), Float(v.z)]
      positions += p
      normals += [Float(v.nx), Float(v.ny), Float(v.nz)]
      for i in 0..<3 {
        minP[i] = min(minP[i], p[i])
        maxP[i] = max(maxP[i], p[i])
      }
    }
    var indices: [UInt32] = []
    for t in mesh.triangles.sorted(by: { $0.triangleID < $1.triangleID }) {
      let idxs = t.vertexIDs.compactMap { indexByID[$0] }
      guard idxs.count == 3 else { continue }
      indices += idxs
    }

    let posData = floatsToData(positions)
    let nrmData = floatsToData(normals)
    let idxData = uint32ToData(indices)

    // Buffer layout: positions | normals | indices (aligned to 4)
    var bin = Data()
    let posOffset = 0
    bin.append(posData)
    let nrmOffset = bin.count
    bin.append(nrmData)
    align4(&bin)
    let idxOffset = bin.count
    bin.append(idxData)
    align4(&bin)

    let bufferByteLength = bin.count
    let posBytes = posData.count
    let nrmBytes = nrmData.count
    let idxBytes = idxData.count

    let accessors: [[String: Any]] = [
      [
        "bufferView": 0, "componentType": 5126, "count": verts.count, "type": "VEC3",
        "max": maxP.map { Double($0) }, "min": minP.map { Double($0) },
      ],
      [
        "bufferView": 1, "componentType": 5126, "count": verts.count, "type": "VEC3",
      ],
      [
        "bufferView": 2, "componentType": 5125, "count": indices.count, "type": "SCALAR",
      ],
    ]
    let bufferViews: [[String: Any]] = [
      ["buffer": 0, "byteOffset": posOffset, "byteLength": posBytes, "target": 34962],
      ["buffer": 0, "byteOffset": nrmOffset, "byteLength": nrmBytes, "target": 34962],
      ["buffer": 0, "byteOffset": idxOffset, "byteLength": idxBytes, "target": 34963],
    ]
    let gltf: [String: Any] = [
      "asset": ["version": "2.0", "generator": "Elektron-Phase4D-DeterministicGLBWriter"],
      "buffers": [["byteLength": bufferByteLength]],
      "bufferViews": bufferViews,
      "accessors": accessors,
      "meshes": [[
        "name": mesh.meshID,
        "primitives": [[
          "attributes": ["POSITION": 0, "NORMAL": 1],
          "indices": 2,
          "mode": 4,
        ]],
      ]],
      "nodes": [["mesh": 0, "name": "SurfaceFixture"]],
      "scenes": [["nodes": [0]]],
      "scene": 0,
    ]

    let jsonData = try! JSONSerialization.data(withJSONObject: gltf, options: [.sortedKeys])
    var jsonPadded = jsonData
    while jsonPadded.count % 4 != 0 { jsonPadded.append(0x20) } // space pad
    var binPadded = bin
    while binPadded.count % 4 != 0 { binPadded.append(0) }

    var out = Data()
    // GLB header
    appendU32(&out, 0x46546C67) // glTF
    appendU32(&out, 2)
    let total = 12 + 8 + jsonPadded.count + 8 + binPadded.count
    appendU32(&out, UInt32(total))
    // JSON chunk
    appendU32(&out, UInt32(jsonPadded.count))
    appendU32(&out, 0x4E4F534A) // JSON
    out.append(jsonPadded)
    // BIN chunk
    appendU32(&out, UInt32(binPadded.count))
    appendU32(&out, 0x004E4942) // BIN\0
    out.append(binPadded)
    return out
  }

  private static func floatsToData(_ values: [Float]) -> Data {
    var d = Data(capacity: values.count * 4)
    for v in values {
      var le = v.bitPattern.littleEndian
      withUnsafeBytes(of: &le) { d.append(contentsOf: $0) }
    }
    return d
  }

  private static func uint32ToData(_ values: [UInt32]) -> Data {
    var d = Data(capacity: values.count * 4)
    for v in values {
      var le = v.littleEndian
      withUnsafeBytes(of: &le) { d.append(contentsOf: $0) }
    }
    return d
  }

  private static func align4(_ data: inout Data) {
    while data.count % 4 != 0 { data.append(0) }
  }

  private static func appendU32(_ data: inout Data, _ value: UInt32) {
    var le = value.littleEndian
    withUnsafeBytes(of: &le) { data.append(contentsOf: $0) }
  }
}
