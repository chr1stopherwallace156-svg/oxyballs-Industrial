import Foundation

/// Business logic for inspection session lifecycle and capture metering.
public final class InspectionSessionService: @unchecked Sendable {
  private let repository: any CurrentSessionRepository
  private let idGenerator: any SessionIDGenerating
  private let instantProvider: any InstantProviding
  public var defaultInspector: Inspector

  /// In-memory cache of the restored/current session (repository is source of truth for disk).
  private let lock = NSLock()
  private var cached: InspectionSession?

  public init(
    repository: any CurrentSessionRepository,
    idGenerator: any SessionIDGenerating = ProductionSessionIDGenerator(),
    instantProvider: any InstantProviding = SystemInstantProvider(),
    defaultInspector: Inspector = .localDefault
  ) {
    self.repository = repository
    self.idGenerator = idGenerator
    self.instantProvider = instantProvider
    self.defaultInspector = defaultInspector
  }

  public var currentSession: InspectionSession? {
    lock.lock(); defer { lock.unlock() }
    return cached
  }

  /// Restore unfinished session from repository. Terminal/corrupt handling per repository rules.
  @discardableResult
  public func restoreCurrentSession() async throws -> InspectionSession? {
    do {
      let session = try await repository.load()
      setCache(session)
      return session
    } catch InspectionSessionError.corruptPersistence {
      try? await repository.clear()
      setCache(nil)
      throw InspectionSessionError.corruptPersistence("cleared corrupt current session")
    }
  }

  /// Authoritative Sprint 2.1A creation path:
  /// validate plan → snapshot → verify digest → `AssignedInspectionPlan` → assign.
  ///
  /// Does not hold a live registry reference on the returned session. Rejects invalid plans and
  /// digest mismatches without silent repair.
  @discardableResult
  public func createSession(
    vehicleIdentifierRaw: String,
    inspectionPlan: InspectionPlan,
    assignedAt: Date? = nil,
    inspector: Inspector? = nil
  ) async throws -> InspectionSession {
    if let existing = currentSession, existing.status.isActiveOrPaused {
      throw InspectionSessionError.sessionAlreadyActive
    }
    try InspectionPlanValidator.validate(inspectionPlan)
    let assignmentInstant = assignedAt ?? instantProvider.now()
    let factory = InspectionPlanSnapshotFactory(
      instantProvider: FixedInstantProvider(assignmentInstant)
    )
    let snapshot = try factory.makeSnapshot(from: inspectionPlan)
    try InspectionPlanSnapshotHasher.verify(snapshot)

    let identifier = try VehicleIdentifier(rawValue: vehicleIdentifierRaw)
    let startedAt = instantProvider.now()
    let session = try InspectionSession.assigning(
      id: idGenerator.makeSessionID(),
      vehicle: InspectionVehicle(primaryIdentifier: identifier),
      inspector: inspector ?? defaultInspector,
      startedAt: startedAt,
      finishedAt: nil,
      status: .inProgress,
      metrics: SessionMetrics(captureCount: 0),
      planSnapshot: snapshot,
      assignedAt: assignmentInstant
    )
    // First durable write into empty slot, or explicit replace when slot occupied.
    let saved = try await commitNewSessionIntoCurrentSlot(session)
    setCache(saved)
    return saved
  }

  /// Starts a new inspection session.
  ///
  /// - Parameter planSnapshot: When provided, verified and frozen via ``AssignedInspectionPlan``.
  ///   When `nil`, the session is created as ``SessionPlanState/legacyUnassigned``.
  ///   Prefer ``createSession`` for new work.
  @discardableResult
  public func startInspection(
    vehicleIdentifierRaw: String,
    planSnapshot: InspectionPlanSnapshot? = nil,
    inspector: Inspector? = nil
  ) async throws -> InspectionSession {
    if let existing = currentSession, existing.status.isActiveOrPaused {
      throw InspectionSessionError.sessionAlreadyActive
    }
    let identifier = try VehicleIdentifier(rawValue: vehicleIdentifierRaw)
    let startedAt = instantProvider.now()
    let session: InspectionSession
    if let planSnapshot {
      session = try InspectionSession.assigning(
        id: idGenerator.makeSessionID(),
        vehicle: InspectionVehicle(primaryIdentifier: identifier),
        inspector: inspector ?? defaultInspector,
        startedAt: startedAt,
        finishedAt: nil,
        status: .inProgress,
        metrics: SessionMetrics(captureCount: 0),
        planSnapshot: planSnapshot,
        assignedAt: startedAt
      )
    } else {
      session = InspectionSession(
        id: idGenerator.makeSessionID(),
        vehicle: InspectionVehicle(primaryIdentifier: identifier),
        inspector: inspector ?? defaultInspector,
        startedAt: startedAt,
        finishedAt: nil,
        status: .inProgress,
        metrics: SessionMetrics(captureCount: 0),
        planState: .legacyUnassigned
      )
    }
    let saved = try await commitNewSessionIntoCurrentSlot(session)
    setCache(saved)
    return saved
  }

  /// Empty-slot `save` or explicit ``replaceCurrentSession`` when the slot is occupied.
  private func commitNewSessionIntoCurrentSlot(
    _ session: InspectionSession
  ) async throws -> InspectionSession {
    do {
      return try await repository.save(session, expectedRevision: 0)
    } catch let InspectionSessionError.slotOccupied(_, incumbentRevision) {
      return try await repository.replaceCurrentSession(
        session,
        expectedIncumbentRevision: incumbentRevision
      )
    }
  }

  public func pause() async throws {
    try await transition(to: .paused, finishedAt: nil)
  }

  public func resume() async throws {
    try await transition(to: .inProgress, finishedAt: nil)
  }

  public func complete() async throws {
    try await transition(to: .completed, finishedAt: instantProvider.now())
  }

  public func cancel() async throws {
    try await transition(to: .canceled, finishedAt: instantProvider.now())
  }

  /// Increments captureCount once after a capture is successfully approved and persisted
  /// for an in-progress session. Failed / rejected captures must not call this.
  public func recordSuccessfulCapture() async throws {
    guard var session = currentSession else {
      throw InspectionSessionError.noActiveSession
    }
    guard session.status == .inProgress else {
      throw InspectionSessionError.terminalSessionCannotReceiveCaptures
    }
    let expected = session.revision
    session.metrics.captureCount += 1
    let saved = try await repository.save(session, expectedRevision: expected)
    setCache(saved)
  }

  /// Persists an engine/coordinator-updated session as the current session.
  ///
  /// - Parameter expectedRevision: Last durable revision observed by the caller.
  ///   Defaults to `session.revision` (the adopted base), never a caller-minted next id.
  /// - Returns: Repository-assigned session (`N+1`). Does not adopt into cache on throw.
  @discardableResult
  public func applyUpdatedSession(
    _ session: InspectionSession,
    expectedRevision: Int? = nil
  ) async throws -> InspectionSession {
    let expected = expectedRevision ?? session.revision
    let saved = try await repository.save(session, expectedRevision: expected)
    setCache(saved)
    return saved
  }

  public func evidenceContext(for session: InspectionSession) -> InspectionSessionEvidenceContext {
    let snap = CaptureClockService().snapshot(now: session.startedAt)
    return InspectionSessionEvidenceContext.snapshot(from: session, startedAtUTC: snap.utcISO8601)
  }

  private func transition(to newStatus: SessionStatus, finishedAt: Date?) async throws {
    guard var session = currentSession else {
      throw InspectionSessionError.noActiveSession
    }
    guard Self.canTransition(from: session.status, to: newStatus) else {
      throw InspectionSessionError.illegalStatusTransition(from: session.status, to: newStatus)
    }
    let expected = session.revision
    session.status = newStatus
    if newStatus.isTerminal {
      session.finishedAt = finishedAt
    } else {
      // pause/resume must not set finishedAt
      session.finishedAt = nil
    }
    let saved = try await repository.save(session, expectedRevision: expected)
    setCache(saved)
  }

  public static func canTransition(from: SessionStatus, to: SessionStatus) -> Bool {
    switch (from, to) {
    case (.inProgress, .paused),
      (.inProgress, .completed),
      (.inProgress, .canceled),
      (.paused, .inProgress),
      (.paused, .completed),
      (.paused, .canceled):
      return true
    default:
      return false
    }
  }

  private func setCache(_ session: InspectionSession?) {
    lock.lock()
    cached = session
    lock.unlock()
  }
}
