import Foundation

public protocol CurrentSessionRepository: Sendable {
  func load() async throws -> InspectionSession?
  /// Persists `session` under optimistic concurrency (S2-004).
  ///
  /// - Parameter expectedRevision: Last durable revision observed by the caller (`0` if none).
  /// - Returns: Newly minted session; ``InspectionSession/revision`` assigned solely by the repository.
  ///
  /// **Forbidden:** silently overwriting a different session id in an occupied slot.
  /// That requires ``replaceCurrentSession(_:expectedIncumbentRevision:)``.
  @discardableResult
  func save(_ session: InspectionSession, expectedRevision: Int) async throws -> InspectionSession
  /// Explicit current-session slot replacement after proving awareness of the incumbent revision.
  @discardableResult
  func replaceCurrentSession(
    _ session: InspectionSession,
    expectedIncumbentRevision: Int
  ) async throws -> InspectionSession
  /// Install a recovered snapshot under Phase D monotonicity (no OCC bump).
  ///
  /// Enforces **same-id identity match** and **strict revision monotonicity**
  /// (`recovered.revision > durable.revision`). Does **not** validate payload
  /// signatures, provenance seals, or media integrity — those are out of scope.
  @discardableResult
  func installRecoveredSnapshot(_ recovered: InspectionSession) async throws -> InspectionSession
  func clear() async throws
}

/// Pre-2.1B on-disk shape for unfinished current-session persistence (`schemaVersion` string).
///
/// Retained as a legacy decode source only. New writes use ``InspectionSessionEnvelope``.
public struct CurrentSessionPersistenceEnvelope: Codable, Sendable, Equatable {
  public static let currentSchemaVersion = "1.0.0"

  public var schemaVersion: String
  public var session: InspectionSession

  public init(schemaVersion: String = currentSchemaVersion, session: InspectionSession) {
    self.schemaVersion = schemaVersion
    self.session = session
  }
}

public actor FileCurrentSessionRepository: CurrentSessionRepository {
  public let fileURL: URL
  private let fileManager: FileManager

  public init(fileURL: URL? = nil, fileManager: FileManager = .default) {
    self.fileManager = fileManager
    if let fileURL {
      self.fileURL = fileURL
    } else {
      let docs = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
        ?? fileManager.temporaryDirectory
      self.fileURL = docs
        .appendingPathComponent("InspectionSessions", isDirectory: true)
        .appendingPathComponent("current_session.json")
    }
  }

  public func load() async throws -> InspectionSession? {
    guard fileManager.fileExists(atPath: fileURL.path) else { return nil }
    do {
      let data = try Data(contentsOf: fileURL)
      let envelope = try InspectionSessionEnvelopeLoader.load(from: data, savedAt: Date())
      if envelope.session.status.isTerminal {
        try await clear()
        return nil
      }
      return envelope.session
    } catch let e as InspectionSessionPersistenceError {
      throw InspectionSessionError.corruptPersistence(String(describing: e))
    } catch let e as InspectionSessionError {
      throw e
    } catch {
      throw InspectionSessionError.corruptPersistence(String(describing: error))
    }
  }

  /// Reads durable session for OCC without clearing terminal records.
  private func loadExistingForOCC() throws -> InspectionSession? {
    guard fileManager.fileExists(atPath: fileURL.path) else { return nil }
    let data = try Data(contentsOf: fileURL)
    let envelope = try InspectionSessionEnvelopeLoader.load(from: data, savedAt: Date())
    return envelope.session
  }

  @discardableResult
  public func save(
    _ session: InspectionSession,
    expectedRevision: Int
  ) async throws -> InspectionSession {
    let existing: InspectionSession?
    do {
      existing = try loadExistingForOCC()
    } catch {
      throw InspectionSessionError.corruptPersistence(String(describing: error))
    }
    let toWrite = try SessionRevisionGuard.prepareCommit(
      incoming: session,
      expectedRevision: expectedRevision,
      existing: existing
    )
    return try await writeEnvelope(session: toWrite)
  }

  @discardableResult
  public func replaceCurrentSession(
    _ session: InspectionSession,
    expectedIncumbentRevision: Int
  ) async throws -> InspectionSession {
    let existing: InspectionSession?
    do {
      existing = try loadExistingForOCC()
    } catch {
      throw InspectionSessionError.corruptPersistence(String(describing: error))
    }
    guard let existing else {
      // Empty slot — equivalent to first save with expectedRevision 0.
      return try await save(session, expectedRevision: 0)
    }
    let toWrite = try SessionRevisionGuard.prepareSlotReplacement(
      incoming: session,
      expectedIncumbentRevision: expectedIncumbentRevision,
      existing: existing
    )
    return try await writeEnvelope(session: toWrite)
  }

  @discardableResult
  public func installRecoveredSnapshot(
    _ recovered: InspectionSession
  ) async throws -> InspectionSession {
    let existing: InspectionSession?
    do {
      existing = try loadExistingForOCC()
    } catch {
      throw InspectionSessionError.corruptPersistence(String(describing: error))
    }
    // Bounds: identity match + revision monotonicity only — no signature/provenance checks.
    switch SessionRecoveryGate.evaluate(durable: existing, recovered: recovered) {
    case .adoptEmptySlot, .adoptNewer:
      break
    case let .rejectLowerOrEqualRevision(durable, recoveredRev):
      throw InspectionSessionError.recoveryRevisionRegression(
        durable: durable,
        recovered: recoveredRev
      )
    case let .rejectIdentityMismatch(durable, recoveredID):
      throw InspectionSessionError.recoveryIdentityMismatch(
        durable: durable,
        recovered: recoveredID
      )
    }
    return try await writeEnvelope(session: recovered)
  }

  private func writeEnvelope(session: InspectionSession) async throws -> InspectionSession {
    do {
      let dir = fileURL.deletingLastPathComponent()
      try fileManager.createDirectory(at: dir, withIntermediateDirectories: true)
      let envelope = try InspectionSessionEnvelopeCoder.makeEnvelope(
        session: session,
        savedAt: Date()
      )
      let data = try InspectionSessionEnvelopeCoder.encode(envelope)
      let temp = fileURL.appendingPathExtension("tmp")
      if fileManager.fileExists(atPath: temp.path) {
        try fileManager.removeItem(at: temp)
      }
      try data.write(to: temp, options: .atomic)
      let written = try Data(contentsOf: temp)
      guard written == data else {
        try? fileManager.removeItem(at: temp)
        throw InspectionSessionError.persistenceFailed("temporary write incomplete")
      }
      if fileManager.fileExists(atPath: fileURL.path) {
        let backup = fileURL.appendingPathExtension("bak")
        if fileManager.fileExists(atPath: backup.path) {
          try fileManager.removeItem(at: backup)
        }
        try fileManager.moveItem(at: fileURL, to: backup)
        do {
          try fileManager.moveItem(at: temp, to: fileURL)
          try? fileManager.removeItem(at: backup)
        } catch {
          try? fileManager.moveItem(at: backup, to: fileURL)
          try? fileManager.removeItem(at: temp)
          throw error
        }
      } else {
        try fileManager.moveItem(at: temp, to: fileURL)
      }
      return session
    } catch let e as InspectionSessionError {
      throw e
    } catch let e as InspectionSessionPersistenceError {
      throw InspectionSessionError.persistenceFailed(String(describing: e))
    } catch {
      throw InspectionSessionError.persistenceFailed(String(describing: error))
    }
  }

  public func clear() async throws {
    if fileManager.fileExists(atPath: fileURL.path) {
      try fileManager.removeItem(at: fileURL)
    }
    let temp = fileURL.appendingPathExtension("tmp")
    try? fileManager.removeItem(at: temp)
  }
}

public actor InMemoryCurrentSessionRepository: CurrentSessionRepository {
  private var session: InspectionSession?

  public init(session: InspectionSession? = nil) {
    self.session = session
  }

  public func load() async throws -> InspectionSession? { session }

  @discardableResult
  public func save(
    _ session: InspectionSession,
    expectedRevision: Int
  ) async throws -> InspectionSession {
    let toWrite = try SessionRevisionGuard.prepareCommit(
      incoming: session,
      expectedRevision: expectedRevision,
      existing: self.session
    )
    self.session = toWrite
    return toWrite
  }

  @discardableResult
  public func replaceCurrentSession(
    _ session: InspectionSession,
    expectedIncumbentRevision: Int
  ) async throws -> InspectionSession {
    guard let existing = self.session else {
      return try await save(session, expectedRevision: 0)
    }
    let toWrite = try SessionRevisionGuard.prepareSlotReplacement(
      incoming: session,
      expectedIncumbentRevision: expectedIncumbentRevision,
      existing: existing
    )
    self.session = toWrite
    return toWrite
  }

  @discardableResult
  public func installRecoveredSnapshot(
    _ recovered: InspectionSession
  ) async throws -> InspectionSession {
    // Bounds: identity + revision monotonicity only — no signature/provenance validation.
    switch SessionRecoveryGate.evaluate(durable: self.session, recovered: recovered) {
    case .adoptEmptySlot, .adoptNewer:
      self.session = recovered
      return recovered
    case let .rejectLowerOrEqualRevision(durable, recoveredRev):
      throw InspectionSessionError.recoveryRevisionRegression(
        durable: durable,
        recovered: recoveredRev
      )
    case let .rejectIdentityMismatch(durable, recoveredID):
      throw InspectionSessionError.recoveryIdentityMismatch(
        durable: durable,
        recovered: recoveredID
      )
    }
  }

  public func clear() async throws {
    self.session = nil
  }
}
