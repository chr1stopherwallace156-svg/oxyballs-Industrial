import Foundation

public protocol CurrentSessionRepository: Sendable {
  func load() async throws -> InspectionSession?
  func save(_ session: InspectionSession) async throws
  func clear() async throws
}

/// Versioned on-disk envelope for unfinished current-session persistence.
public struct CurrentSessionPersistenceEnvelope: Codable, Sendable, Equatable {
  public static let currentSchemaVersion = "1.0.0"

  public var schemaVersion: String
  public var session: InspectionSession

  public init(schemaVersion: String = currentSchemaVersion, session: InspectionSession) {
    self.schemaVersion = schemaVersion
    self.session = session
  }
}

public actor FileCurrentSessionRepository: CurrentSessionRepository {
  public let fileURL: URL
  private let encoder: JSONEncoder
  private let decoder: JSONDecoder

  public init(fileURL: URL? = nil) {
    if let fileURL {
      self.fileURL = fileURL
    } else {
      let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        ?? FileManager.default.temporaryDirectory
      self.fileURL = docs
        .appendingPathComponent("InspectionSessions", isDirectory: true)
        .appendingPathComponent("current_session.json")
    }
    let enc = JSONEncoder()
    enc.dateEncodingStrategy = .iso8601
    enc.outputFormatting = [.sortedKeys]
    self.encoder = enc
    let dec = JSONDecoder()
    dec.dateDecodingStrategy = .iso8601
    self.decoder = dec
  }

  public func load() async throws -> InspectionSession? {
    guard FileManager.default.fileExists(atPath: fileURL.path) else { return nil }
    do {
      let data = try Data(contentsOf: fileURL)
      let envelope = try decoder.decode(CurrentSessionPersistenceEnvelope.self, from: data)
      guard envelope.schemaVersion == CurrentSessionPersistenceEnvelope.currentSchemaVersion else {
        throw InspectionSessionError.corruptPersistence(
          "unsupported schemaVersion \(envelope.schemaVersion)"
        )
      }
      // Terminal sessions must not be reactivated.
      if envelope.session.status.isTerminal {
        try await clear()
        return nil
      }
      return envelope.session
    } catch let e as InspectionSessionError {
      throw e
    } catch {
      throw InspectionSessionError.corruptPersistence(String(describing: error))
    }
  }

  public func save(_ session: InspectionSession) async throws {
    do {
      let dir = fileURL.deletingLastPathComponent()
      try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
      let envelope = CurrentSessionPersistenceEnvelope(session: session)
      let data = try encoder.encode(envelope)
      let temp = fileURL.appendingPathExtension("tmp")
      if FileManager.default.fileExists(atPath: temp.path) {
        try FileManager.default.removeItem(at: temp)
      }
      try data.write(to: temp, options: .atomic)
      if FileManager.default.fileExists(atPath: fileURL.path) {
        try FileManager.default.removeItem(at: fileURL)
      }
      try FileManager.default.moveItem(at: temp, to: fileURL)
    } catch let e as InspectionSessionError {
      throw e
    } catch {
      throw InspectionSessionError.persistenceFailed(String(describing: error))
    }
  }

  public func clear() async throws {
    if FileManager.default.fileExists(atPath: fileURL.path) {
      try FileManager.default.removeItem(at: fileURL)
    }
  }
}

public actor InMemoryCurrentSessionRepository: CurrentSessionRepository {
  private var session: InspectionSession?

  public init(session: InspectionSession? = nil) {
    self.session = session
  }

  public func load() async throws -> InspectionSession? { session }

  public func save(_ session: InspectionSession) async throws {
    self.session = session
  }

  public func clear() async throws {
    session = nil
  }
}
