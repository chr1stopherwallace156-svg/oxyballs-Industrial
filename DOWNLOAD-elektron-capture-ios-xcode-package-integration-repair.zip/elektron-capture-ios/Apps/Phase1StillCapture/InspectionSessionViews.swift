import SwiftUI
import ElektronCapture

#if canImport(UIKit) && !os(macOS)

struct NewInspectionSheet: View {
  @ObservedObject var viewModel: InspectionSessionViewModel
  @Environment(\.dismiss) private var dismiss
  @State private var vehicleIdentifier: String = ""

  var body: some View {
    NavigationStack {
      Form {
        Section {
          TextField("Vehicle Identifier", text: $vehicleIdentifier)
            .textInputAutocapitalization(.characters)
            .autocorrectionDisabled()
        } header: {
          Text("Vehicle Identifier")
        } footer: {
          Text("Stored as an unknown-kind identifier unless later enriched. Inspector defaults to Local Inspector.")
        }
        if let errorText = viewModel.errorText {
          Text(errorText).foregroundStyle(.red)
        }
      }
      .navigationTitle("New Inspection")
      .navigationBarTitleDisplayMode(.inline)
      .toolbar {
        ToolbarItem(placement: .cancellationAction) {
          Button("Cancel") { dismiss() }
        }
        ToolbarItem(placement: .confirmationAction) {
          Button("Start Inspection") {
            Task {
              await viewModel.start(vehicleIdentifier: vehicleIdentifier)
              if viewModel.hasActiveSession {
                dismiss()
              }
            }
          }
          .disabled(vehicleIdentifier.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
      }
    }
  }
}

struct ActiveInspectionBanner: View {
  @ObservedObject var viewModel: InspectionSessionViewModel

  var body: some View {
    VStack(spacing: 8) {
      HStack(alignment: .center, spacing: 12) {
        VStack(alignment: .leading, spacing: 2) {
          Text(viewModel.sessionIDLabel)
            .font(.caption.monospaced())
            .foregroundStyle(.white)
          Text(viewModel.vehicleLabel)
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(.white)
          Text("\(viewModel.statusLabel) · captures \(viewModel.captureCount) · \(viewModel.elapsedDescription)")
            .font(.caption2)
            .foregroundStyle(.white.opacity(0.85))
        }
        Spacer()
        if viewModel.current?.status == .paused {
          Button("Resume") {
            Task { await viewModel.resume() }
          }
          .font(.caption.weight(.semibold))
          .buttonStyle(.bordered)
          .tint(.white)
        } else if viewModel.current?.status == .inProgress {
          Button("Pause") {
            Task { await viewModel.pause() }
          }
          .font(.caption.weight(.semibold))
          .buttonStyle(.bordered)
          .tint(.white)
        }
        Button("Done") {
          Task { await viewModel.complete() }
        }
        .font(.caption.weight(.semibold))
        .buttonStyle(.borderedProminent)
        Button("Cancel") {
          viewModel.showCancelConfirmation = true
        }
        .font(.caption.weight(.semibold))
        .buttonStyle(.bordered)
        .tint(.red)
      }
    }
    .padding(12)
    .background(Color.blue.opacity(0.85))
    .confirmationDialog(
      "Cancel this inspection?",
      isPresented: $viewModel.showCancelConfirmation,
      titleVisibility: .visible
    ) {
      Button("Cancel Inspection", role: .destructive) {
        Task { await viewModel.cancelConfirmed() }
      }
      Button("Keep Inspection", role: .cancel) {}
    } message: {
      Text("This cannot be undone. Captures already exported remain in the Evidence Library.")
    }
  }
}

#endif
