import SwiftUI
import ElektronCapture

@main
struct Phase1StillCaptureApp: App {
  #if canImport(UIKit) && !os(macOS)
  @StateObject private var inspectionViewModel: InspectionSessionViewModel = {
    let repo = FileCurrentSessionRepository()
    let service = InspectionSessionService(repository: repo)
    return InspectionSessionViewModel(service: service)
  }()
  #endif

  var body: some Scene {
    WindowGroup {
      #if canImport(UIKit) && !os(macOS)
      Phase1MainTabView()
        .environmentObject(inspectionViewModel)
      #else
      Text("Phase 1 still capture requires iOS.")
      #endif
    }
  }
}
