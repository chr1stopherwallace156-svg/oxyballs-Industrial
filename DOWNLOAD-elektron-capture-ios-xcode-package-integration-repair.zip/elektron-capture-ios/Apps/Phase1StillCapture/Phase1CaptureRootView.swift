import SwiftUI
import Combine
import ElektronCapture

#if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
import AVFoundation
import UIKit
#endif

/// Pass 2 operator UI: live preview → Take Photo → review (Retake / Use Photo) → Export Package.
/// Pass 3 advanced controls are intentionally absent.
struct Phase1CaptureRootView: View {
  @StateObject private var model = Phase1CaptureViewModel()
  @EnvironmentObject private var inspection: InspectionSessionViewModel
  @State private var shareItems: [Any] = []
  @State private var showShareSheet = false
  @State private var showDocumentExport = false
  @State private var documentExportURLs: [URL] = []
  @State private var shareStatus: String = ""
  @State private var showNewInspection = false

  var body: some View {
    ZStack {
      Color.black.ignoresSafeArea()

      #if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
      content
      #else
      Text("Phase 1 still capture requires iOS UIKit + AVFoundation.")
        .foregroundStyle(.white)
        .padding()
      #endif
    }
    .preferredColorScheme(.dark)
    #if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
    .safeAreaInset(edge: .top, spacing: 0) {
      if inspection.hasActiveSession {
        ActiveInspectionBanner(viewModel: inspection)
      } else {
        HStack {
          Text("No active inspection")
            .font(.caption)
            .foregroundStyle(.white.opacity(0.8))
          Spacer()
          Button("New Inspection") { showNewInspection = true }
            .font(.caption.weight(.semibold))
            .buttonStyle(.borderedProminent)
        }
        .padding(10)
        .background(Color.orange.opacity(0.85))
      }
    }
    .task {
      await model.bootstrap()
    }
    .onDisappear {
      model.teardown()
    }
    .sheet(isPresented: $showShareSheet) {
      ActivityShareView(items: shareItems) { completed in
        shareStatus = completed ? "Share completed." : "Share dismissed."
      }
    }
    .sheet(isPresented: $showDocumentExport) {
      DocumentExportPicker(urls: documentExportURLs) {
        shareStatus = "Files export picker closed."
      }
    }
    .sheet(isPresented: $showNewInspection) {
      NewInspectionSheet(viewModel: inspection)
    }
    #endif
  }

  #if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
  @ViewBuilder
  private var content: some View {
    switch model.uiState {
    case .permissionRequired:
      statusPane(
        title: "Camera Access Required",
        detail: model.statusDetail,
        primary: ("Open Settings", { model.openSettings() }),
        secondary: ("Retry", { Task { await model.bootstrap() } })
      )

    case .starting:
      statusPane(title: "Starting Camera", detail: model.statusDetail, primary: nil, secondary: nil)

    case .previewing, .capturing:
      previewStage

    case .reviewing:
      reviewStage

    case .approved:
      approvedStage

    case .exporting:
      statusPane(title: "Exporting Package", detail: "Writing CapturePackageV1…", primary: nil, secondary: nil)

    case .exported:
      exportedStage

    case .interrupted:
      statusPane(
        title: "Camera Interrupted",
        detail: model.statusDetail,
        primary: ("Resume", { Task { await model.resumeAfterInterrupt() } }),
        secondary: nil
      )

    case .failed:
      statusPane(
        title: "Capture Failed",
        detail: model.statusDetail,
        primary: ("Back to Preview", { Task { await model.recoverFromFailure() } }),
        secondary: nil
      )
    }
  }

  private var previewStage: some View {
    ZStack {
      if let session = model.previewSession {
        CameraPreviewView(session: session)
          .ignoresSafeArea()
          .onAppear { model.markPreviewAttached(true) }
          .onDisappear { model.markPreviewAttached(false) }
      } else {
        Color.black.ignoresSafeArea()
      }

      VStack {
        Spacer()
        Text(model.uiState == .capturing ? "Capturing…" : model.readinessText)
          .font(.headline)
          .foregroundStyle(.white)
          .shadow(radius: 4)
          .padding(.bottom, 8)

        Button {
          Task { await model.takePhoto() }
        } label: {
          Text("Take Photo")
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
        }
        .buttonStyle(.borderedProminent)
        .disabled(model.uiState == .capturing || !model.canTakePhoto)
        .padding(.horizontal, 24)
        .padding(.bottom, 36)
      }
    }
  }

  private var reviewStage: some View {
    ZStack {
      if let image = model.reviewImage {
        Image(uiImage: image)
          .resizable()
          .scaledToFill()
          .ignoresSafeArea()
      } else {
        Color.black.ignoresSafeArea()
        Text("Review image unavailable")
          .foregroundStyle(.white)
      }

      VStack {
        Spacer()
        Text("Review")
          .font(.headline)
          .foregroundStyle(.white)
          .shadow(radius: 4)
        if let pending = model.pendingCapture {
          Text("sha256 \(String(pending.sha256.prefix(12)))…")
            .font(.caption.monospaced())
            .foregroundStyle(.white.opacity(0.85))
            .padding(.bottom, 8)
        }

        HStack(spacing: 16) {
          Button("Retake") {
            model.retake()
          }
          .buttonStyle(.bordered)
          .tint(.white)

          Button("Use Photo") {
            Task { await model.usePhoto() }
          }
          .buttonStyle(.borderedProminent)
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 36)
      }
    }
  }

  private var approvedStage: some View {
    VStack(spacing: 16) {
      Spacer()
      if let image = model.reviewImage {
        Image(uiImage: image)
          .resizable()
          .scaledToFit()
          .frame(maxHeight: 360)
          .padding(.horizontal, 16)
      }
      Text("Photo Approved")
        .font(.title2.bold())
        .foregroundStyle(.white)
      if let approved = model.approvedCapture {
        Text("Frozen sha256 \(String(approved.sha256.prefix(16)))…")
          .font(.caption.monospaced())
          .foregroundStyle(.white.opacity(0.8))
      }
      Text("Export writes CapturePackageV1 using these frozen bytes only.")
        .font(.footnote)
        .foregroundStyle(.white.opacity(0.75))
        .multilineTextAlignment(.center)
        .padding(.horizontal, 24)
      if !model.libraryStoreMessage.isEmpty {
        Text(model.libraryStoreMessage)
          .font(.caption)
          .foregroundStyle(.mint)
          .multilineTextAlignment(.center)
          .padding(.horizontal, 24)
      }
      Text("Stored under Application Support → Evidence Library (app-private; not cloud-backed yet).")
        .font(.caption2)
        .foregroundStyle(.orange.opacity(0.9))
        .multilineTextAlignment(.center)
        .padding(.horizontal, 24)

      Button {
        Task {
          await model.exportPackage(inspectionSessionContext: inspection.evidenceContextForExport())
          if model.uiState == .exported {
            await inspection.recordSuccessfulCaptureIfNeeded()
          }
        }
      } label: {
        Text("Export Package")
          .font(.headline)
          .frame(maxWidth: .infinity)
          .padding(.vertical, 16)
      }
      .buttonStyle(.borderedProminent)
      .padding(.horizontal, 24)

      Button("Retake") {
        model.retake()
      }
      .buttonStyle(.bordered)
      .tint(.white)
      .padding(.bottom, 36)
      Spacer()
    }
  }

  private var exportedStage: some View {
    VStack(spacing: 14) {
      Spacer()
      Text("Package Exported")
        .font(.title2.bold())
        .foregroundStyle(.white)
      if let zipPath = model.lastPackageZipPath {
        Text(zipPath)
          .font(.caption.monospaced())
          .foregroundStyle(.white.opacity(0.85))
          .multilineTextAlignment(.center)
          .padding(.horizontal, 20)
      }
      if let sha = model.lastExportSha {
        Text("artifact sha256 \(sha)")
          .font(.caption2.monospaced())
          .foregroundStyle(.white.opacity(0.7))
          .padding(.horizontal, 20)
      }
      Text("Canonical transport is .edts-pkg (ZIP bytes). Artifact JPEG is not re-encoded.")
        .font(.footnote)
        .foregroundStyle(.white.opacity(0.7))
        .multilineTextAlignment(.center)
        .padding(.horizontal, 24)

      Button {
        presentShare(mode: .edtsPkg)
      } label: {
        Text("Share .edts-pkg")
          .font(.headline)
          .frame(maxWidth: .infinity)
          .padding(.vertical, 14)
      }
      .buttonStyle(.borderedProminent)
      .padding(.horizontal, 24)

      Button {
        presentDocumentExport(mode: .edtsPkg)
      } label: {
        Text("Save .edts-pkg to Files")
          .frame(maxWidth: .infinity)
          .padding(.vertical, 12)
      }
      .buttonStyle(.bordered)
      .tint(.white)
      .padding(.horizontal, 24)

      Button {
        presentShare(mode: .diagnosticZip)
      } label: {
        Text("Export as ZIP copy")
          .frame(maxWidth: .infinity)
          .padding(.vertical, 12)
      }
      .buttonStyle(.bordered)
      .tint(.yellow)
      .padding(.horizontal, 24)

      Text("ZIP copy is a temporary diagnostic (same bytes, .zip extension). Canonical .edts-pkg is preserved.")
        .font(.caption2)
        .foregroundStyle(.white.opacity(0.55))
        .multilineTextAlignment(.center)
        .padding(.horizontal, 28)

      if !shareStatus.isEmpty {
        Text(shareStatus)
          .font(.caption)
          .foregroundStyle(.mint)
          .multilineTextAlignment(.center)
          .padding(.horizontal, 20)
      }

      Button("Capture Another") {
        shareStatus = ""
        model.retake()
      }
      .buttonStyle(.borderedProminent)
      .padding(.bottom, 36)
      Spacer()
    }
  }

  private enum ShareMode {
    case edtsPkg
    case diagnosticZip
  }

  private func presentShare(mode: ShareMode) {
    do {
      let url = try model.prepareShareURL(mode: mode == .edtsPkg ? .edtsPkg : .diagnosticZip)
      shareItems = [url]
      showShareSheet = true
      shareStatus = mode == .edtsPkg
        ? "Sharing canonical .edts-pkg…"
        : "Sharing diagnostic .zip copy (canonical .edts-pkg unchanged)…"
    } catch {
      shareStatus = "Share prepare failed: \(error)"
    }
  }

  private func presentDocumentExport(mode: ShareMode) {
    do {
      let url = try model.prepareShareURL(mode: mode == .edtsPkg ? .edtsPkg : .diagnosticZip)
      documentExportURLs = [url]
      showDocumentExport = true
      shareStatus = "Opening Files export…"
    } catch {
      shareStatus = "Files export prepare failed: \(error)"
    }
  }

  private func statusPane(
    title: String,
    detail: String,
    primary: (String, () -> Void)?,
    secondary: (String, () -> Void)?
  ) -> some View {
    VStack(spacing: 16) {
      Spacer()
      Text(title)
        .font(.title2.bold())
        .foregroundStyle(.white)
        .multilineTextAlignment(.center)
      Text(detail)
        .font(.body)
        .foregroundStyle(.white.opacity(0.8))
        .multilineTextAlignment(.center)
        .padding(.horizontal, 24)
      if let primary {
        Button(primary.0, action: primary.1)
          .buttonStyle(.borderedProminent)
      }
      if let secondary {
        Button(secondary.0, action: secondary.1)
          .buttonStyle(.bordered)
          .tint(.white)
      }
      Spacer()
    }
  }
  #endif
}

#if canImport(UIKit) && canImport(AVFoundation) && !os(macOS)
@MainActor
final class Phase1CaptureViewModel: ObservableObject {
  @Published private(set) var uiState: Phase1StillCaptureUIState = .starting
  @Published private(set) var statusDetail: String = "Preparing camera…"
  @Published private(set) var previewSession: AVCaptureSession?
  @Published private(set) var pendingCapture: PendingStillCapture?
  @Published private(set) var approvedCapture: ApprovedStillCapture?
  @Published private(set) var reviewImage: UIImage?
  @Published private(set) var canTakePhoto: Bool = false
  @Published private(set) var readinessText: String = "Starting Camera"
  @Published private(set) var lastExportPath: String?
  @Published private(set) var lastPackageZipPath: String?
  @Published private(set) var lastExportSha: String?
  @Published private(set) var lastPackageZipURL: URL?
  @Published private(set) var lastDiagnosticZipPath: String?
  @Published private(set) var lastLibraryCaptureId: String?
  @Published private(set) var libraryStoreMessage: String = ""

  private let controller = InteractiveStillCaptureController()
  private let capabilitySnapshotService: any DeviceCapabilitySnapshotProviding
  private var cancellables = Set<AnyCancellable>()
  private var activeCaptureIds: Phase1CaptureIdentifiers?
  private var evidenceLibrary: EvidenceLibraryStore?
  /// One immutable snapshot for the current capture session (not regenerated per photo).
  private(set) var sessionCapabilitySnapshot: DeviceCapabilitySnapshot?

  private var exportDirectoryURL: URL {
    FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
      .appendingPathComponent("CapturePackages", isDirectory: true)
  }

  private var shareStagingDirectoryURL: URL {
    FileManager.default.temporaryDirectory
      .appendingPathComponent("EdtsPkgShareStaging", isDirectory: true)
  }

  private var appVersion: String {
    Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0.1.4"
  }

  private func libraryStore() throws -> EvidenceLibraryStore {
    if let evidenceLibrary { return evidenceLibrary }
    let root = try EvidenceLibraryPaths.defaultLibraryRoot()
    let store = EvidenceLibraryStore(libraryRoot: root)
    evidenceLibrary = store
    return store
  }

  enum SharePrepareMode {
    case edtsPkg
    case diagnosticZip
  }

  init(capabilitySnapshotService: any DeviceCapabilitySnapshotProviding = AppleDeviceCapabilitySnapshotService()) {
    self.capabilitySnapshotService = capabilitySnapshotService
    bindController()
  }

  func bootstrap() async {
    transition(to: .starting, detail: "Checking camera permission…")
    pendingCapture = nil
    approvedCapture = nil
    reviewImage = nil
    lastExportPath = nil
    lastPackageZipPath = nil
    lastPackageZipURL = nil
    lastDiagnosticZipPath = nil
    lastExportSha = nil
    lastLibraryCaptureId = nil
    libraryStoreMessage = ""
    activeCaptureIds = nil
    sessionCapabilitySnapshot = nil

    // Capture once at session init (before prepare may fail on permission).
    let snapshot = await capabilitySnapshotService.captureSnapshot()
    sessionCapabilitySnapshot = snapshot
    Phase1CaptureDiagnostics.log(
      stage: "device_capability",
      event: "snapshot_retained",
      detail: "snapshotID=\(snapshot.snapshotID) cameras=\(snapshot.availableCameras.count) depth=\(snapshot.depth.rawValue) lidar=\(snapshot.lidar.rawValue)"
    )

    do {
      try await controller.prepareSession()
      previewSession = controller.session
      transition(to: .previewing, detail: "Live preview ready.")
    } catch let error as Phase1RuntimeError {
      previewSession = nil
      canTakePhoto = false
      if error == .cameraPermissionDenied {
        transition(to: .permissionRequired, detail: error.detailMessage)
      } else {
        transition(to: .failed(reasonCode: error.reasonCode), detail: error.detailMessage)
      }
    } catch {
      previewSession = nil
      canTakePhoto = false
      transition(
        to: .failed(reasonCode: Phase1RuntimeError.cameraConfigurationFailed("").reasonCode),
        detail: String(describing: error)
      )
    }
  }

  func teardown() {
    controller.stopSession()
    previewSession = nil
    canTakePhoto = false
  }

  func markPreviewAttached(_ attached: Bool) {
    controller.markPreviewAttached(attached)
  }

  func openSettings() {
    guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
    UIApplication.shared.open(url)
  }

  func takePhoto() async {
    guard uiState == .previewing, canTakePhoto else { return }
    transition(to: .capturing, detail: "Capturing still…")
    do {
      let pending = try await controller.capturePendingStill()
      // Bytes + SHA already frozen inside the photo delegate before this returns.
      pendingCapture = pending
      // Throwaway decode for review UI only — never replaces authoritative bytes.
      reviewImage = UIImage(data: pending.jpegBytes)
      canTakePhoto = false
      transition(to: .reviewing, detail: "Review captured still. SHA frozen.")
    } catch let error as Phase1RuntimeError {
      transition(to: .failed(reasonCode: error.reasonCode), detail: error.detailMessage)
    } catch {
      transition(
        to: .failed(reasonCode: Phase1RuntimeError.photoCaptureFailed("").reasonCode),
        detail: String(describing: error)
      )
    }
  }

  func usePhoto() async {
    guard uiState == .reviewing, let pending = pendingCapture else { return }
    let approved = pending.promoteToApproved()
    approvedCapture = approved
    let ids = Phase1CaptureIdentifiers.generate()
    activeCaptureIds = ids
    lastLibraryCaptureId = ids.evidenceId
    do {
      let store = try libraryStore()
      let record = try await store.storeApproved(
        jpegBytes: approved.jpegBytes,
        sha256: approved.sha256,
        ids: ids,
        captureTimestamp: Date()
      )
      libraryStoreMessage = "Stored locally \(record.shortId)"
      transition(
        to: .approved,
        detail: "Photo approved and stored in Evidence Library (\(record.shortId)). Ready to export."
      )
    } catch {
      // Approval still succeeds in UI; library persistence failure is surfaced but does not discard freeze.
      libraryStoreMessage = "Library store failed: \(error)"
      transition(
        to: .approved,
        detail: "Photo approved (library store failed — export still uses frozen bytes). \(error)"
      )
    }
  }

  func retake() {
    pendingCapture = nil
    approvedCapture = nil
    reviewImage = nil
    lastExportPath = nil
    lastPackageZipPath = nil
    lastPackageZipURL = nil
    lastDiagnosticZipPath = nil
    lastExportSha = nil
    activeCaptureIds = nil
    lastLibraryCaptureId = nil
    libraryStoreMessage = ""
    // Session remains running; return to live preview without reconfiguration.
    // Retake allocates a new capture-id on next Use Photo — never overwrites prior library original.
    transition(to: .previewing, detail: "Live preview ready.")
    canTakePhoto = controller.shutterEnabled
  }

  func exportPackage(inspectionSessionContext: InspectionSessionEvidenceContext? = nil) async {
    guard uiState == .approved, let approved = approvedCapture else { return }
    transition(to: .exporting, detail: "Writing CapturePackageV1…")
    do {
      try FileManager.default.createDirectory(at: exportDirectoryURL, withIntermediateDirectories: true)
      let ids = activeCaptureIds ?? Phase1CaptureIdentifiers.generate()
      activeCaptureIds = ids
      // photoCapture unused by exportApproved; fixture satisfies coordinator init.
      let coordinator = Phase1CaptureCoordinator(
        appVersion: appVersion,
        photoCapture: FixtureStillPhotoCaptureService(jpegBytes: Data([0xFF, 0xD8, 0xFF, 0xD9])),
        workRoot: exportDirectoryURL,
        deviceCapabilitySnapshot: sessionCapabilitySnapshot,
        inspectionSessionContext: inspectionSessionContext
      )
      let result = try coordinator.exportApproved(
        approved,
        ids: ids,
        deviceCapabilitySnapshot: sessionCapabilitySnapshot,
        inspectionSessionContext: inspectionSessionContext
      )
      // Surface the .edts-pkg *file* (ZIP transport), not only the package directory.
      lastExportPath = result.packageDirectoryURL.path
      lastPackageZipURL = result.packageZipURL
      lastPackageZipPath = result.packageZipURL.path
      lastExportSha = result.artifactSha256
      lastDiagnosticZipPath = nil
      try PackageTransportShareSupport.requireEdtsPkgFile(at: result.packageZipURL)

      // Attach portable package into Evidence Library without moving/deleting Documents export
      // and without modifying library artifact_original.jpg.
      if lastLibraryCaptureId != nil || activeCaptureIds != nil {
        do {
          let store = try libraryStore()
          // Ensure library row exists (if store-on-approve failed earlier, try again)
          if (try? await store.record(id: ids.evidenceId)) == nil {
            _ = try await store.storeApproved(
              jpegBytes: approved.jpegBytes,
              sha256: approved.sha256,
              ids: ids
            )
          }
          _ = try await store.attachPackage(
            evidenceId: ids.evidenceId,
            packageResult: result,
            markExported: true
          )
          libraryStoreMessage = "Library package attached \(ids.evidenceId)"
        } catch {
          libraryStoreMessage = "Library attach warning: \(error)"
        }
      }

      transition(to: .exported, detail: "PACKAGE_EXPORTED")
    } catch let error as Phase1RuntimeError {
      // Export failure returns to approved — frozen bytes retained.
      transition(to: .approved, detail: "Export failed; approved photo retained. \(error.detailMessage)")
    } catch {
      transition(to: .approved, detail: "Export failed; approved photo retained. \(error)")
    }
  }

  /// Prepares a shareable file URL. Never re-encodes `artifact_original.jpg`.
  func prepareShareURL(mode: SharePrepareMode) throws -> URL {
    guard let packageZipURL = lastPackageZipURL else {
      throw Phase1RuntimeError.exportFailed("no exported .edts-pkg available to share")
    }
    switch mode {
    case .edtsPkg:
      return try PackageTransportShareSupport.prepareShareableEdtsPkg(
        from: packageZipURL,
        stagingDirectory: shareStagingDirectoryURL
      )
    case .diagnosticZip:
      let zipURL = PackageTransportShareSupport.diagnosticZipURL(beside: packageZipURL)
      let written = try PackageTransportShareSupport.writeDiagnosticZipCopy(
        ofEdtsPkg: packageZipURL,
        to: zipURL
      )
      lastDiagnosticZipPath = written.path
      // Stage zip copy for share sheet as well (stable temp path).
      let stagedZip = shareStagingDirectoryURL.appendingPathComponent(written.lastPathComponent)
      try FileManager.default.createDirectory(at: shareStagingDirectoryURL, withIntermediateDirectories: true)
      if FileManager.default.fileExists(atPath: stagedZip.path) {
        try FileManager.default.removeItem(at: stagedZip)
      }
      try FileManager.default.copyItem(at: written, to: stagedZip)
      return stagedZip
    }
  }

  func resumeAfterInterrupt() async {
    do {
      // Re-prepare session after interruption — new session ⇒ new capability snapshot.
      controller.stopSession()
      let snapshot = await capabilitySnapshotService.captureSnapshot()
      sessionCapabilitySnapshot = snapshot
      Phase1CaptureDiagnostics.log(
        stage: "device_capability",
        event: "snapshot_retained",
        detail: "snapshotID=\(snapshot.snapshotID) reason=interrupt_resume"
      )
      try await controller.prepareSession()
      previewSession = controller.session
      pendingCapture = nil
      approvedCapture = nil
      reviewImage = nil
      transition(to: .previewing, detail: "Preview resumed after interruption.")
    } catch let error as Phase1RuntimeError {
      transition(to: .failed(reasonCode: error.reasonCode), detail: error.detailMessage)
    } catch {
      transition(
        to: .failed(reasonCode: Phase1RuntimeError.cameraConfigurationFailed("").reasonCode),
        detail: String(describing: error)
      )
    }
  }

  func recoverFromFailure() async {
    await bootstrap()
  }

  private func bindController() {
    controller.$shutterEnabled
      .receive(on: RunLoop.main)
      .sink { [weak self] enabled in
        guard let self else { return }
        if self.uiState == .previewing {
          self.canTakePhoto = enabled
        }
      }
      .store(in: &cancellables)

    controller.$readinessText
      .receive(on: RunLoop.main)
      .assign(to: &$readinessText)

    controller.$wasInterrupted
      .receive(on: RunLoop.main)
      .sink { [weak self] interrupted in
        guard let self else { return }
        if interrupted {
          switch self.uiState {
          case .previewing, .capturing, .reviewing:
            self.canTakePhoto = false
            self.transition(to: .interrupted, detail: "Camera session interrupted.")
          default:
            break
          }
        }
      }
      .store(in: &cancellables)
  }

  private func transition(to next: Phase1StillCaptureUIState, detail: String) {
    if uiState == next {
      statusDetail = detail
      return
    }
    do {
      uiState = try Phase1StillCaptureUIStateMachine.transition(from: uiState, to: next)
      statusDetail = detail
    } catch {
      statusDetail = "Illegal UI transition \(uiState.label) → \(next.label): \(error)"
      if case .failed = uiState {
        return
      }
      uiState = .failed(reasonCode: Phase1RuntimeError.statusAuthorityViolation("illegal_ui_transition").reasonCode)
    }
  }
}
#endif

#Preview {
  Phase1CaptureRootView()
}
