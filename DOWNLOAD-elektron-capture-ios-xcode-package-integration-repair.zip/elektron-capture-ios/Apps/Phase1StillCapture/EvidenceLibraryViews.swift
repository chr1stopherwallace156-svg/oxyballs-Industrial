import SwiftUI
import ElektronCapture
import Combine

#if canImport(UIKit) && !os(macOS)
import UIKit

/// Primary navigation: Capture | Evidence Library
struct Phase1MainTabView: View {
  @EnvironmentObject private var inspection: InspectionSessionViewModel
  @State private var showNewInspection = false

  var body: some View {
    TabView {
      Phase1CaptureRootView()
        .tabItem {
          Label("Capture", systemImage: "camera")
        }
      EvidenceLibraryListView()
        .tabItem {
          Label("Evidence Library", systemImage: "photo.on.rectangle.angled")
        }
    }
    .preferredColorScheme(.dark)
    .task {
      await inspection.restore()
      if !inspection.hasActiveSession {
        showNewInspection = true
      }
    }
    .sheet(isPresented: $showNewInspection) {
      NewInspectionSheet(viewModel: inspection)
    }
  }
}

@MainActor
final class EvidenceLibraryViewModel: ObservableObject {
  @Published var records: [EvidenceLibraryIndexRecord] = []
  @Published var isLoading = false
  @Published var errorText: String?
  @Published var disclaimerAcknowledged = false

  private var store: EvidenceLibraryStore?

  func ensureStore() async throws -> EvidenceLibraryStore {
    if let store { return store }
    let root = try EvidenceLibraryPaths.defaultLibraryRoot()
    let s = EvidenceLibraryStore(libraryRoot: root)
    _ = try await s.reconcileOnLaunch()
    store = s
    return s
  }

  func reload() async {
    isLoading = true
    errorText = nil
    defer { isLoading = false }
    do {
      let s = try await ensureStore()
      records = try await s.listRecordsNewestFirst()
    } catch {
      errorText = String(describing: error)
    }
  }

  func verify(id: String) async -> String {
    do {
      let s = try await ensureStore()
      let result = try await s.verifyIntegrity(id: id)
      await reload()
      return "\(result.integrityState.rawValue): \(result.detail)"
    } catch {
      return "Verify failed: \(error)"
    }
  }

  func storeRef() async throws -> EvidenceLibraryStore {
    try await ensureStore()
  }
}

struct EvidenceLibraryListView: View {
  @StateObject private var model = EvidenceLibraryViewModel()
  @State private var selected: EvidenceLibraryIndexRecord?

  var body: some View {
    NavigationStack {
      Group {
        if model.isLoading && model.records.isEmpty {
          ProgressView("Loading Evidence Library…")
            .tint(.white)
        } else if model.records.isEmpty {
          emptyState
        } else {
          List {
            Section {
              Text("Local library only. Deleting the app removes these records until cloud sync (Phase 2+).")
                .font(.caption)
                .foregroundStyle(.secondary)
            }
            ForEach(model.records) { record in
              NavigationLink(value: record) {
                EvidenceLibraryRow(record: record)
              }
            }
          }
          .listStyle(.insetGrouped)
        }
      }
      .navigationTitle("Evidence Library")
      .navigationDestination(for: EvidenceLibraryIndexRecord.self) { record in
        EvidenceLibraryDetailView(recordId: record.id, listModel: model)
      }
      .toolbar {
        ToolbarItem(placement: .topBarTrailing) {
          Button("Refresh") {
            Task { await model.reload() }
          }
        }
      }
      .task {
        await model.reload()
      }
      .alert("Library Error", isPresented: Binding(
        get: { model.errorText != nil },
        set: { if !$0 { model.errorText = nil } }
      )) {
        Button("OK", role: .cancel) { model.errorText = nil }
      } message: {
        Text(model.errorText ?? "")
      }
    }
  }

  private var emptyState: some View {
    VStack(spacing: 16) {
      Image(systemName: "tray")
        .font(.system(size: 48))
        .foregroundStyle(.secondary)
      Text("No Stored Evidence")
        .font(.title3.bold())
      Text("Approve a capture on the Capture tab to store the original photo in the Evidence Library.")
        .font(.body)
        .foregroundStyle(.secondary)
        .multilineTextAlignment(.center)
        .padding(.horizontal, 32)
      Text("App-private storage only — not backed up to the cloud yet.")
        .font(.caption)
        .foregroundStyle(.orange)
        .multilineTextAlignment(.center)
        .padding(.horizontal, 32)
    }
    .frame(maxWidth: .infinity, maxHeight: .infinity)
  }
}

struct EvidenceLibraryRow: View {
  let record: EvidenceLibraryIndexRecord

  var body: some View {
    HStack(spacing: 12) {
      thumbnail
      VStack(alignment: .leading, spacing: 4) {
        Text(record.captureTimestamp.formatted(date: .abbreviated, time: .shortened))
          .font(.headline)
        Text(record.shortId)
          .font(.caption.monospaced())
          .foregroundStyle(.secondary)
        if let label = record.vehicleOrSessionLabel, !label.isEmpty {
          Text(label)
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        statusChips
      }
    }
    .padding(.vertical, 4)
  }

  @ViewBuilder
  private var thumbnail: some View {
    let resolved: URL? = {
      guard let root = try? EvidenceLibraryPaths.defaultLibraryRoot() else { return nil }
      return try? EvidenceLibraryPaths(libraryRoot: root).resolve(record.thumbnailRelativePath)
    }()
    if let url = resolved, let data = try? Data(contentsOf: url), let img = UIImage(data: data) {
      Image(uiImage: img)
        .resizable()
        .scaledToFill()
        .frame(width: 56, height: 56)
        .clipped()
        .cornerRadius(6)
    } else {
      RoundedRectangle(cornerRadius: 6)
        .fill(Color.gray.opacity(0.3))
        .frame(width: 56, height: 56)
        .overlay {
          Image(systemName: "photo")
            .foregroundStyle(.secondary)
        }
    }
  }

  private var statusChips: some View {
    HStack(spacing: 6) {
      chip(record.state.storageState.rawValue, color: storageColor(record.state.storageState))
      chip(record.state.packageState.rawValue, color: .blue)
      chip(record.state.integrityState.rawValue, color: integrityColor(record.state.integrityState))
    }
  }

  private func chip(_ text: String, color: Color) -> some View {
    Text(text)
      .font(.caption2.weight(.semibold))
      .padding(.horizontal, 6)
      .padding(.vertical, 2)
      .background(color.opacity(0.2))
      .foregroundStyle(color)
      .cornerRadius(4)
  }

  private func storageColor(_ s: EvidenceStorageState) -> Color {
    switch s {
    case .storedLocally: return .green
    case .missing, .unrecognized: return .red
    case .pending: return .orange
    }
  }

  private func integrityColor(_ s: EvidenceIntegrityState) -> Color {
    switch s {
    case .verifiedPass: return .mint
    case .corruptedHashMismatch, .corruptedPackage, .missingArtifact: return .red
    case .unverified: return .orange
    }
  }
}

struct EvidenceLibraryDetailView: View {
  let recordId: String
  @ObservedObject var listModel: EvidenceLibraryViewModel

  @State private var record: EvidenceLibraryIndexRecord?
  @State private var fullImage: UIImage?
  @State private var statusMessage = ""
  @State private var shareItems: [Any] = []
  @State private var showShare = false
  @State private var showFiles = false
  @State private var filesURLs: [URL] = []
  @State private var manifestPreview = ""

  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 16) {
        if let fullImage {
          Image(uiImage: fullImage)
            .resizable()
            .scaledToFit()
            .frame(maxWidth: .infinity)
        } else {
          ProgressView()
        }

        if let record {
          Group {
            labeled("Capture ID", record.id)
            labeled("Short ID", record.shortId)
            labeled("Captured", record.captureTimestamp.formatted())
            labeled("Original SHA-256", record.originalSha256)
            if let pkg = record.packageSha256 {
              labeled("Package SHA-256", pkg)
            }
            labeled("Capture", record.state.captureState.rawValue)
            labeled("Storage", record.state.storageState.rawValue)
            labeled("Package", record.state.packageState.rawValue)
            labeled("Export", record.state.exportState.rawValue)
            labeled("Integrity", record.state.integrityState.rawValue)
            if let label = record.vehicleOrSessionLabel {
              labeled("Vehicle/Session", label)
            }
            Text("Phase: \(Phase1CStatus.current)")
              .font(.caption2)
              .foregroundStyle(.secondary)
          }
          .font(.footnote.monospaced())
        }

        if !manifestPreview.isEmpty {
          Text("Metadata preview")
            .font(.headline)
          Text(manifestPreview)
            .font(.caption2.monospaced())
            .foregroundStyle(.secondary)
        }

        Text("Deleting the app removes local Evidence Library storage. Cloud sync is not implemented yet.")
          .font(.caption)
          .foregroundStyle(.orange)

        if !statusMessage.isEmpty {
          Text(statusMessage)
            .font(.caption)
            .foregroundStyle(.mint)
        }

        Button("Verify Integrity") {
          Task {
            statusMessage = await listModel.verify(id: recordId)
            await load()
          }
        }
        .buttonStyle(.borderedProminent)

        Button("Re-export .edts-pkg") {
          Task { await reexportPackage() }
        }
        .buttonStyle(.bordered)

        Button("Save Original JPEG Copy") {
          Task { await saveOriginalCopy() }
        }
        .buttonStyle(.bordered)
      }
      .padding()
    }
    .navigationTitle("Evidence Detail")
    .navigationBarTitleDisplayMode(.inline)
    .task { await load() }
    .sheet(isPresented: $showShare) {
      ActivityShareView(items: shareItems) { completed in
        statusMessage = completed ? "Share completed." : "Share dismissed — library record untouched."
      }
    }
    .sheet(isPresented: $showFiles) {
      DocumentExportPicker(urls: filesURLs) {
        statusMessage = "Files picker closed — library record untouched."
      }
    }
  }

  private func labeled(_ title: String, _ value: String) -> some View {
    VStack(alignment: .leading, spacing: 2) {
      Text(title).font(.caption).foregroundStyle(.secondary)
      Text(value).textSelection(.enabled)
    }
  }

  private func load() async {
    do {
      let store = try await listModel.storeRef()
      let rec = try await store.record(id: recordId)
      record = rec
      let paths = store.paths
      let art = try paths.resolve(rec.originalRelativePath)
      if let data = try? Data(contentsOf: art) {
        // Decode for display only — does not write back.
        fullImage = UIImage(data: data)
      }
      let manifest = paths.captureDirectory(id: recordId).appendingPathComponent("manifest.json")
      if let data = try? Data(contentsOf: manifest), let s = String(data: data, encoding: .utf8) {
        manifestPreview = String(s.prefix(1200))
      } else {
        let libStatus = paths.captureDirectory(id: recordId).appendingPathComponent("library_status.json")
        if let data = try? Data(contentsOf: libStatus), let s = String(data: data, encoding: .utf8) {
          manifestPreview = s
        }
      }
    } catch {
      statusMessage = "Load failed: \(error)"
    }
  }

  private func reexportPackage() async {
    do {
      let store = try await listModel.storeRef()
      let staging = FileManager.default.temporaryDirectory
        .appendingPathComponent("EvidenceLibraryShare", isDirectory: true)
      try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
      let dest = staging.appendingPathComponent("\(recordId).edts-pkg")
      let url = try await store.copyExportPackage(id: recordId, to: dest)
      shareItems = [url]
      showShare = true
      statusMessage = "Sharing library export copy (canonical library untouched)."
    } catch {
      statusMessage = "Re-export failed: \(error). Export from Capture first if package missing."
    }
  }

  private func saveOriginalCopy() async {
    do {
      let store = try await listModel.storeRef()
      let staging = FileManager.default.temporaryDirectory
        .appendingPathComponent("EvidenceLibraryShare", isDirectory: true)
      try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
      let dest = staging.appendingPathComponent("\(recordId)-original.jpg")
      let url = try await store.copyOriginalJPEG(id: recordId, to: dest)
      filesURLs = [url]
      showFiles = true
      statusMessage = "Saving a copy of the original JPEG — library original not moved."
    } catch {
      statusMessage = "Save original failed: \(error)"
    }
  }
}

#endif
