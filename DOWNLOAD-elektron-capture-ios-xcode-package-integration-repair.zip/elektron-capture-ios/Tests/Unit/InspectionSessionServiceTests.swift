import XCTest
@testable import ElektronCapture

final class InspectionSessionDomainTests: XCTestCase {
  func testSessionIDRejectsEmpty() {
    XCTAssertThrowsError(try SessionID(rawValue: "  ")) { err in
      XCTAssertEqual(err as? InspectionSessionError, .invalidSessionID)
    }
  }

  func testSessionIDCodableSingleValue() throws {
    let id = try SessionID(rawValue: "INS-FIXED-001")
    let data = try JSONEncoder().encode(id)
    XCTAssertEqual(String(data: data, encoding: .utf8), "\"INS-FIXED-001\"")
    let decoded = try JSONDecoder().decode(SessionID.self, from: data)
    XCTAssertEqual(decoded, id)
  }

  func testProductionIDGeneratorUTCFormatting() {
    let instant = Date(timeIntervalSince1970: 0) // 1970-01-01T00:00:00Z
    let gen = ProductionSessionIDGenerator(
      instantProvider: FixedInstantProvider(instant),
      randomSuffixProvider: { "AB12" }
    )
    let id = gen.makeSessionID()
    XCTAssertEqual(id.rawValue, "INS-19700101-000000-AB12")
  }

  func testFixedGeneratorIsStable() {
    let fixed = SessionID.unchecked("INS-TEST-FIXED")
    let gen = FixedSessionIDGenerator(sessionID: fixed)
    XCTAssertEqual(gen.makeSessionID(), fixed)
    XCTAssertEqual(gen.makeSessionID(), fixed)
  }

  func testVehicleIdentifierUnknownByDefault() throws {
    let v = try VehicleIdentifier(rawValue: "1HGCM82633A004352")
    XCTAssertEqual(v.kind, .unknown)
    XCTAssertEqual(v.rawValue, "1HGCM82633A004352")
  }

  func testVehicleIdentifierRejectsEmpty() {
    XCTAssertThrowsError(try VehicleIdentifier(rawValue: "")) { err in
      XCTAssertEqual(err as? InspectionSessionError, .emptyVehicleIdentifier)
    }
  }

  func testEvidenceContextCanonicalEncodingStable() throws {
    let ctx = InspectionSessionEvidenceContext(
      sessionID: "INS-CTX-1",
      primaryVehicleIdentifier: "ABC123",
      primaryVehicleIdentifierKind: VehicleIdentifierKind.unknown.rawValue,
      inspectorID: "INSPECTOR-LOCAL",
      sessionStartedAtUTC: "2026-07-25T12:00:00.000Z"
    )
    let a = try CanonicalJSONEncoder.encode(ctx.asDictionary())
    let b = try CanonicalJSONEncoder.encode(ctx.asDictionary())
    XCTAssertEqual(a, b)
    let text = String(data: a, encoding: .utf8)!
    XCTAssertTrue(text.contains("\"schema_id\":\"InspectionSessionEvidenceContext\""))
    XCTAssertTrue(text.contains("\"session_id\":\"INS-CTX-1\""))
  }

  func testTransitionMatrix() {
    XCTAssertTrue(InspectionSessionService.canTransition(from: .inProgress, to: .paused))
    XCTAssertTrue(InspectionSessionService.canTransition(from: .inProgress, to: .completed))
    XCTAssertTrue(InspectionSessionService.canTransition(from: .inProgress, to: .canceled))
    XCTAssertTrue(InspectionSessionService.canTransition(from: .paused, to: .inProgress))
    XCTAssertTrue(InspectionSessionService.canTransition(from: .paused, to: .completed))
    XCTAssertTrue(InspectionSessionService.canTransition(from: .paused, to: .canceled))
    XCTAssertFalse(InspectionSessionService.canTransition(from: .completed, to: .inProgress))
    XCTAssertFalse(InspectionSessionService.canTransition(from: .canceled, to: .paused))
    XCTAssertFalse(InspectionSessionService.canTransition(from: .completed, to: .completed))
  }
}

final class InspectionSessionServiceTests: XCTestCase {
  private var repo: InMemoryCurrentSessionRepository!
  private var service: InspectionSessionService!
  private let fixedInstant = Date(timeIntervalSince1970: 1_720_000_000)

  override func setUp() async throws {
    repo = InMemoryCurrentSessionRepository()
    service = InspectionSessionService(
      repository: repo,
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("INS-FIXED-SERVICE")),
      instantProvider: FixedInstantProvider(fixedInstant)
    )
  }

  func testStartRejectsEmptyVehicle() async {
    do {
      _ = try await service.startInspection(vehicleIdentifierRaw: " ")
      XCTFail("expected throw")
    } catch let e as InspectionSessionError {
      XCTAssertEqual(e, .emptyVehicleIdentifier)
    } catch {
      XCTFail("unexpected \(error)")
    }
  }

  func testCreatePersistRestore() async throws {
    let created = try await service.startInspection(vehicleIdentifierRaw: "FLEET-42")
    XCTAssertEqual(created.id.rawValue, "INS-FIXED-SERVICE")
    XCTAssertEqual(created.vehicle.primaryIdentifier.kind, .unknown)
    XCTAssertEqual(created.startedAt, fixedInstant)
    XCTAssertNil(created.finishedAt)
    XCTAssertEqual(created.status, .inProgress)

    let fileURL = FileManager.default.temporaryDirectory
      .appendingPathComponent("insp-file-\(UUID().uuidString).json")
    let fileRepo = FileCurrentSessionRepository(fileURL: fileURL)
    try await fileRepo.save(created)
    let loaded = try await fileRepo.load()
    XCTAssertEqual(loaded?.id, created.id)

    let restoredService = InspectionSessionService(
      repository: fileRepo,
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("OTHER")),
      instantProvider: FixedInstantProvider(fixedInstant)
    )
    let restored = try await restoredService.restoreCurrentSession()
    XCTAssertEqual(restored?.id.rawValue, "INS-FIXED-SERVICE")
  }

  func testPreventsSecondActiveSession() async throws {
    _ = try await service.startInspection(vehicleIdentifierRaw: "A")
    do {
      _ = try await service.startInspection(vehicleIdentifierRaw: "B")
      XCTFail("expected already active")
    } catch let e as InspectionSessionError {
      XCTAssertEqual(e, .sessionAlreadyActive)
    }
  }

  func testLifecycleAndFinishedAt() async throws {
    _ = try await service.startInspection(vehicleIdentifierRaw: "UNIT-1")
    try await service.pause()
    XCTAssertEqual(service.currentSession?.status, .paused)
    XCTAssertNil(service.currentSession?.finishedAt)
    try await service.resume()
    XCTAssertEqual(service.currentSession?.startedAt, fixedInstant)
    XCTAssertNil(service.currentSession?.finishedAt)
    try await service.complete()
    XCTAssertEqual(service.currentSession?.status, .completed)
    XCTAssertEqual(service.currentSession?.finishedAt, fixedInstant)
  }

  func testCancelSetsFinishedAt() async throws {
    _ = try await service.startInspection(vehicleIdentifierRaw: "UNIT-2")
    try await service.cancel()
    XCTAssertEqual(service.currentSession?.status, .canceled)
    XCTAssertNotNil(service.currentSession?.finishedAt)
  }

  func testInvalidAndRepeatedTerminal() async throws {
    _ = try await service.startInspection(vehicleIdentifierRaw: "UNIT-3")
    try await service.complete()
    do {
      try await service.pause()
      XCTFail("expected illegal")
    } catch let e as InspectionSessionError {
      guard case .illegalStatusTransition(let from, let to) = e else {
        return XCTFail("wrong error \(e)")
      }
      XCTAssertEqual(from, .completed)
      XCTAssertEqual(to, .paused)
    }
    do {
      try await service.complete()
      XCTFail("expected illegal repeat")
    } catch let e as InspectionSessionError {
      guard case .illegalStatusTransition = e else {
        return XCTFail("wrong error \(e)")
      }
    }
  }

  func testCaptureCountIncrementsOnceOnlyWhenInProgress() async throws {
    _ = try await service.startInspection(vehicleIdentifierRaw: "UNIT-4")
    try await service.recordSuccessfulCapture()
    XCTAssertEqual(service.currentSession?.metrics.captureCount, 1)
    try await service.recordSuccessfulCapture()
    XCTAssertEqual(service.currentSession?.metrics.captureCount, 2)
    try await service.pause()
    do {
      try await service.recordSuccessfulCapture()
      XCTFail("paused cannot receive")
    } catch let e as InspectionSessionError {
      XCTAssertEqual(e, .terminalSessionCannotReceiveCaptures)
    }
    XCTAssertEqual(service.currentSession?.metrics.captureCount, 2)
  }

  func testCorruptPersistenceSurfacedAndCleared() async throws {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("corrupt-\(UUID().uuidString).json")
    try Data("not-json".utf8).write(to: url)
    let fileRepo = FileCurrentSessionRepository(fileURL: url)
    let svc = InspectionSessionService(
      repository: fileRepo,
      idGenerator: FixedSessionIDGenerator(sessionID: SessionID.unchecked("X")),
      instantProvider: FixedInstantProvider(fixedInstant)
    )
    do {
      _ = try await svc.restoreCurrentSession()
      XCTFail("expected corrupt")
    } catch let e as InspectionSessionError {
      guard case .corruptPersistence = e else {
        return XCTFail("\(e)")
      }
    }
    let afterClear = try await fileRepo.load()
    XCTAssertNil(afterClear)
  }

  func testTerminalOnDiskNotRestored() async throws {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("term-\(UUID().uuidString).json")
    let fileRepo = FileCurrentSessionRepository(fileURL: url)
    let session = InspectionSession(
      id: SessionID.unchecked("INS-DONE"),
      vehicle: try InspectionVehicle(primaryIdentifier: VehicleIdentifier(rawValue: "Z")),
      inspector: .localDefault,
      startedAt: fixedInstant,
      finishedAt: fixedInstant,
      status: .completed
    )
    try await fileRepo.save(session)
    let loaded = try await fileRepo.load()
    XCTAssertNil(loaded)
  }
}
