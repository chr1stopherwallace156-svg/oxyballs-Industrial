import XCTest
@testable import ElektronCapture

/// T-REF-01 … T-REF-08. Exercises the real refresh decision function and the real repository.
final class RefreshOutcomeTests: XCTestCase {
  private func makeSession(
    _ id: String,
    status: SessionStatus = .inProgress,
    captureCount: Int = 0
  ) throws -> InspectionSession {
    InspectionSession(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: try VehicleIdentifier(rawValue: "FLEET-\(id)")),
      inspector: .localDefault,
      startedAt: Date(timeIntervalSince1970: 1_700_000_000),
      status: status,
      metrics: SessionMetrics(captureCount: captureCount),
      planState: .legacyUnassigned
    )
  }

  private func tempURL() -> URL {
    FileManager.default.temporaryDirectory
      .appendingPathComponent("refresh-\(UUID().uuidString).json")
  }

  /// T-REF-01 — a change written behind the projection is observed after refresh.
  func testRepositoryChangeIsObservedAfterRefresh() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    let service = InspectionSessionService(repository: repo)

    var session = try makeSession("INS-REF-1", captureCount: 0)
    session = try await repo.save(session, expectedRevision: 0)
    let prior = try await service.restoreCurrentSession()
    XCTAssertEqual(prior?.metrics.captureCount, 0)

    // Out-of-band write, exactly as another store actor would do.
    var updated = session
    updated.metrics.captureCount = 7
    _ = try await repo.save(updated, expectedRevision: session.revision)

    let reloaded = try await service.restoreCurrentSession()
    let decision = InspectionRefreshResolution.resolve(prior: prior, load: .loaded(reloaded))
    XCTAssertEqual(decision.outcome, .updated(sessionID: "INS-REF-1"))
    XCTAssertEqual(decision.adoptedSession?.metrics.captureCount, 7)
    XCTAssertFalse(decision.preservedPrior)
  }

  /// T-REF-04 — a repository failure preserves the prior projection and is surfaced.
  func testRepositoryFailurePreservesPriorProjection() throws {
    let prior = try makeSession("INS-KEEP")
    let decision = InspectionRefreshResolution.resolve(prior: prior, load: .failed("disk offline"))

    XCTAssertEqual(decision.outcome, .repositoryFailure(detail: "disk offline"))
    XCTAssertEqual(decision.adoptedSession?.id, prior.id)
    XCTAssertTrue(decision.preservedPrior)
    XCTAssertFalse(decision.outcome.isSuccess)
    XCTAssertNotNil(decision.outcome.userMessage)
  }

  /// T-REF-05 — the headline safety rule: reloading a terminal session must not destroy it.
  func testTerminalSessionIsPreservedOnDiskAndAdoptedReadOnly() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    let completed = try makeSession("INS-DONE", status: .completed)
    _ = try await repo.save(completed, expectedRevision: 0)

    // Reload three times: the record must still be there each time.
    for _ in 0..<3 {
      let loaded = try await repo.load()
      XCTAssertEqual(loaded?.id.rawValue, "INS-DONE")
      XCTAssertEqual(loaded?.status, .completed)
      XCTAssertTrue(
        FileManager.default.fileExists(atPath: url.path),
        "reading a finished inspection must never delete its record"
      )
    }

    let decision = InspectionRefreshResolution.resolve(
      prior: nil,
      load: .loaded(try await repo.load())
    )
    XCTAssertEqual(decision.outcome, .terminalSession(sessionID: "INS-DONE", status: "COMPLETED"))
    XCTAssertEqual(decision.adoptedSession?.id.rawValue, "INS-DONE")
    XCTAssertTrue(decision.outcome.isSuccess)
  }

  /// A terminal session reached through the service is also preserved.
  func testServiceRestoreDoesNotClearTerminalSession() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    let service = InspectionSessionService(repository: repo)
    _ = try await repo.save(try makeSession("INS-CANCELLED", status: .canceled), expectedRevision: 0)

    let restored = try await service.restoreCurrentSession()
    XCTAssertEqual(restored?.status, .canceled)
    XCTAssertTrue(FileManager.default.fileExists(atPath: url.path))
  }

  /// "No inspection" and "repository failure" must not collapse into one another.
  func testNoActiveSessionIsDistinctFromFailure() throws {
    let empty = InspectionRefreshResolution.resolve(prior: nil, load: .loaded(nil))
    XCTAssertEqual(empty.outcome, .noActiveSession)
    XCTAssertTrue(empty.outcome.isSuccess)
    XCTAssertNil(empty.outcome.userMessage)

    let failed = InspectionRefreshResolution.resolve(prior: nil, load: .failed("io"))
    XCTAssertNotEqual(empty.outcome, failed.outcome)
    XCTAssertFalse(failed.outcome.isSuccess)
  }

  /// A vanished record never silently clears a held projection.
  func testVanishedRecordPreservesPrior() throws {
    let prior = try makeSession("INS-HELD")
    let decision = InspectionRefreshResolution.resolve(prior: prior, load: .loaded(nil))
    XCTAssertEqual(decision.outcome, .recordDisappeared(priorSessionID: "INS-HELD"))
    XCTAssertEqual(decision.adoptedSession?.id, prior.id)
    XCTAssertTrue(decision.preservedPrior)
  }

  /// Identity divergence keeps the prior session rather than adopting a stranger.
  func testIdentityDivergenceKeepsPrior() throws {
    let prior = try makeSession("INS-A")
    let other = try makeSession("INS-B")
    let decision = InspectionRefreshResolution.resolve(prior: prior, load: .loaded(other))
    XCTAssertEqual(
      decision.outcome,
      .identityDivergence(priorSessionID: "INS-A", loadedSessionID: "INS-B")
    )
    XCTAssertEqual(decision.adoptedSession?.id, prior.id)
    XCTAssertTrue(decision.preservedPrior)
  }

  /// T-REF-08 — a refresh of a healthy session mutates nothing on disk.
  func testRefreshDoesNotMutateStoredBytes() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    _ = try await repo.save(try makeSession("INS-STABLE"), expectedRevision: 0)

    let before = try Data(contentsOf: url)
    _ = try await repo.load()
    _ = try await repo.load()
    let after = try Data(contentsOf: url)
    XCTAssertEqual(before, after, "reading must be byte-neutral")
  }

  /// Explicit clearing still works — it is just no longer a side effect of reading.
  func testExplicitClearStillRemovesTheRecord() async throws {
    let url = tempURL(); defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    _ = try await repo.save(try makeSession("INS-CLEARABLE"), expectedRevision: 0)
    try await repo.clear()
    XCTAssertNil(try await repo.load())
    XCTAssertFalse(FileManager.default.fileExists(atPath: url.path))
  }
}
