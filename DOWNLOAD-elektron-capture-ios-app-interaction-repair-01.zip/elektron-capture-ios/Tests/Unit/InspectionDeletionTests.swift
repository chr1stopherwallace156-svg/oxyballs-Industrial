import XCTest
@testable import ElektronCapture

/// T-DEL-01 … T-DEL-13. Exercises the real `InspectionDeletionService` against the real
/// file-backed store. Nothing here inspects source text.
final class InspectionDeletionTests: XCTestCase {
  private func tempRoot() -> URL {
    FileManager.default.temporaryDirectory
      .appendingPathComponent("del-\(UUID().uuidString)", isDirectory: true)
  }

  private func makeSession(
    _ id: String,
    status: SessionStatus = .inProgress
  ) throws -> InspectionSession {
    InspectionSession(
      id: SessionID.unchecked(id),
      vehicle: InspectionVehicle(primaryIdentifier: try VehicleIdentifier(rawValue: "FLEET-\(id)")),
      inspector: .localDefault,
      startedAt: Date(timeIntervalSince1970: 1_700_000_000),
      status: status,
      planState: .legacyUnassigned
    )
  }

  private func seedThree(_ store: FileInspectionRecordStore) async throws {
    try await store.save(try makeSession("INS-1"))
    try await store.save(try makeSession("INS-2"))
    try await store.save(try makeSession("INS-3"))
  }

  /// T-DEL-01 — the selected inspection is removed.
  func testDeletesTheSelectedInspection() async throws {
    let root = tempRoot(); defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await seedThree(store)

    let outcome = await InspectionDeletionService(store: store).delete(sessionID: "INS-2")
    XCTAssertTrue(outcome.isDeleted)
    XCTAssertEqual(outcome, .deleted(sessionID: "INS-2", retainedEvidenceCount: 0, statusAtDeletion: "IN_PROGRESS"))
    XCTAssertTrue(try await store.deletedSessionIDs().contains("INS-2"))
  }

  /// T-DEL-02 — no other inspection is affected.
  func testDeletingOneNeverDeletesAnother() async throws {
    let root = tempRoot(); defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await seedThree(store)

    _ = await InspectionDeletionService(store: store).delete(sessionID: "INS-2")

    let remaining = try await store.listInspections().map(\.id.rawValue).sorted()
    XCTAssertEqual(remaining, ["INS-1", "INS-3"])
    XCTAssertNotNil(try await store.load(sessionID: "INS-1"))
    XCTAssertNotNil(try await store.load(sessionID: "INS-3"))
    XCTAssertEqual(try await store.tombstones().map(\.sessionID), ["INS-2"])
  }

  /// T-DEL-03 — deletion survives an app relaunch (fresh store over the same directory).
  func testDeletionSurvivesRelaunch() async throws {
    let root = tempRoot(); defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await seedThree(store)
    _ = await InspectionDeletionService(store: store).delete(sessionID: "INS-3")

    let relaunched = FileInspectionRecordStore(root: root)
    XCTAssertEqual(try await relaunched.listInspections().map(\.id.rawValue).sorted(), ["INS-1", "INS-2"])
    XCTAssertTrue(try await relaunched.deletedSessionIDs().contains("INS-3"))
  }

  /// T-DEL-04 — cancelling (never calling the service) preserves everything.
  func testNotConfirmingPreservesTheInspection() async throws {
    let root = tempRoot(); defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await seedThree(store)

    // No delete call — this is what "Cancel" does.
    XCTAssertEqual(try await store.listInspections().count, 3)
    XCTAssertTrue(try await store.tombstones().isEmpty)
  }

  /// T-DEL-05 — a store that cannot persist must not be reported as a successful deletion.
  func testPersistenceFailureIsNeverReportedAsSuccess() async {
    let outcome = await InspectionDeletionService(store: AlwaysFailingRecordStore())
      .delete(sessionID: "INS-FAIL")
    XCTAssertFalse(outcome.isDeleted)
    guard case let .failed(sessionID, _) = outcome else {
      return XCTFail("expected .failed, got \(outcome)")
    }
    XCTAssertEqual(sessionID, "INS-FAIL")
    XCTAssertTrue(outcome.userMessage.contains("not deleted"))
  }

  /// A tombstone that cannot be read back is not a deletion.
  func testUnverifiableTombstoneIsReportedAsFailure() async {
    let outcome = await InspectionDeletionService(store: WriteOnlyRecordStore())
      .delete(sessionID: "INS-GHOST")
    XCTAssertFalse(outcome.isDeleted)
    XCTAssertEqual(
      outcome,
      .failed(sessionID: "INS-GHOST", reason: "tombstone was written but could not be read back")
    )
  }

  /// T-DEL-06 — capture evidence is retained intact and recorded as such.
  func testEvidenceIsRetainedIntactAndRecorded() async throws {
    let root = tempRoot(); defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await store.save(try makeSession("INS-EVD"))

    let outcome = await InspectionDeletionService(store: store)
      .delete(sessionID: "INS-EVD", retainedEvidenceIDs: ["EVD-B", "EVD-A"])

    XCTAssertEqual(
      outcome,
      .deleted(sessionID: "INS-EVD", retainedEvidenceCount: 2, statusAtDeletion: "IN_PROGRESS")
    )
    let tombstone = try XCTUnwrap(try await store.tombstones().first)
    XCTAssertEqual(tombstone.evidenceDisposition, .retainedIntact)
    XCTAssertEqual(tombstone.retainedEvidenceIDs, ["EVD-A", "EVD-B"], "recorded deterministically")
    XCTAssertTrue(outcome.userMessage.contains("retained"))
  }

  /// T-DEL-08 — a completed inspection is deletable, explicitly and durably.
  func testCompletedInspectionIsDeletable() async throws {
    let root = tempRoot(); defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await store.save(try makeSession("INS-DONE", status: .completed))

    let outcome = await InspectionDeletionService(store: store).delete(sessionID: "INS-DONE")
    XCTAssertTrue(outcome.isDeleted)

    let tombstone = try XCTUnwrap(try await store.tombstones().first)
    XCTAssertEqual(tombstone.sessionStatusAtDeletion, "COMPLETED")

    let relaunched = FileInspectionRecordStore(root: root)
    XCTAssertTrue(try await relaunched.deletedSessionIDs().contains("INS-DONE"))
  }

  /// T-DEL-09 — deleting an archived inspection must not unarchive it.
  func testDeletingArchivedInspectionDoesNotUnarchive() async throws {
    let root = tempRoot(); defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await store.save(try makeSession("INS-ARCHIVED"))
    try await store.archive(sessionID: "INS-ARCHIVED")

    _ = await InspectionDeletionService(store: store).delete(sessionID: "INS-ARCHIVED")

    XCTAssertTrue(
      try await store.archivedSessionIDs().contains("INS-ARCHIVED"),
      "deletion must never be implemented by clearing the archived flag"
    )
    XCTAssertTrue(try await store.deletedSessionIDs().contains("INS-ARCHIVED"))
  }

  /// T-DEL-10 — an inspection with zero captures is addressable and deletable.
  func testZeroCaptureInspectionIsDeletable() async throws {
    let root = tempRoot(); defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await store.save(try makeSession("INS-EMPTY"))

    XCTAssertEqual(try await store.listInspections().map(\.id.rawValue), ["INS-EMPTY"])
    let outcome = await InspectionDeletionService(store: store)
      .delete(sessionID: "INS-EMPTY", retainedEvidenceIDs: [])
    XCTAssertEqual(
      outcome,
      .deleted(sessionID: "INS-EMPTY", retainedEvidenceCount: 0, statusAtDeletion: "IN_PROGRESS")
    )
    XCTAssertEqual(outcome.userMessage, "Inspection deleted.")
  }

  /// Repeat deletion is idempotent success, not a spurious failure.
  func testRepeatDeleteReportsAlreadyDeleted() async throws {
    let root = tempRoot(); defer { try? FileManager.default.removeItem(at: root) }
    let store = FileInspectionRecordStore(root: root)
    try await store.save(try makeSession("INS-TWICE"))
    let service = InspectionDeletionService(store: store)

    XCTAssertTrue(await service.delete(sessionID: "INS-TWICE").isDeleted)
    XCTAssertEqual(await service.delete(sessionID: "INS-TWICE"), .alreadyDeleted(sessionID: "INS-TWICE"))
  }

  /// The live current-session slot is retired only for the matching identity.
  func testRetireCurrentSlotIsIdentityChecked() async throws {
    let url = FileManager.default.temporaryDirectory
      .appendingPathComponent("slot-\(UUID().uuidString).json")
    defer { try? FileManager.default.removeItem(at: url) }
    let repo = FileCurrentSessionRepository(fileURL: url)
    let service = InspectionSessionService(repository: repo)
    _ = try await repo.save(try makeSession("INS-SLOT"), expectedRevision: 0)
    _ = try await service.restoreCurrentSession()

    XCTAssertFalse(try await service.retireCurrentSlot(sessionID: "INS-OTHER"))
    XCTAssertNotNil(try await repo.load(), "a mismatched id must not clear the slot")

    XCTAssertTrue(try await service.retireCurrentSlot(sessionID: "INS-SLOT"))
    XCTAssertNil(try await repo.load())
    XCTAssertNil(service.currentSession)
  }
}

// MARK: - Failure doubles

/// Fails every write. Used to prove failures are never announced as success.
private actor AlwaysFailingRecordStore: InspectionRecordStore {
  func listInspections() async throws -> [InspectionSession] { [] }
  func load(sessionID: String) async throws -> InspectionSession? { nil }
  func save(_ session: InspectionSession) async throws {
    throw InspectionRecordStoreError.writeFailed("injected")
  }
  func archive(sessionID: String) async throws {}
  func unarchive(sessionID: String) async throws {}
  func archivedSessionIDs() async throws -> Set<String> { [] }
  @discardableResult
  func delete(
    sessionID: String,
    reason: InspectionDeletionReason,
    retainedEvidenceIDs: [String]
  ) async throws -> InspectionTombstone {
    throw InspectionRecordStoreError.writeFailed("injected")
  }
  func tombstones() async throws -> [InspectionTombstone] { [] }
  func deletedSessionIDs() async throws -> Set<String> { [] }
}

/// Accepts the write but never reflects it on read — the "silent no-op store".
private actor WriteOnlyRecordStore: InspectionRecordStore {
  func listInspections() async throws -> [InspectionSession] { [] }
  func load(sessionID: String) async throws -> InspectionSession? { nil }
  func save(_ session: InspectionSession) async throws {}
  func archive(sessionID: String) async throws {}
  func unarchive(sessionID: String) async throws {}
  func archivedSessionIDs() async throws -> Set<String> { [] }
  @discardableResult
  func delete(
    sessionID: String,
    reason: InspectionDeletionReason,
    retainedEvidenceIDs: [String]
  ) async throws -> InspectionTombstone {
    InspectionTombstone(sessionID: sessionID, deletedAt: Date(), retainedEvidenceIDs: retainedEvidenceIDs)
  }
  func tombstones() async throws -> [InspectionTombstone] { [] }
  func deletedSessionIDs() async throws -> Set<String> { [] }
}
